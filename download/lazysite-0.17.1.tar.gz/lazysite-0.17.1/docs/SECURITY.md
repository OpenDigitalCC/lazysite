# lazysite - threat model

Structured security assessment for the Commercial regime (eight-dimension
review D6). Method: **STRIDE** over the attack surface, with control
verification framed against **OWASP ASVS L1** (a user-facing service; L2 items
noted where already met). This is the threat-model home; the mechanism-level
narrative it references lives in `docs/architecture/security.md`, and the
vulnerability-disclosure policy in the repo-root `SECURITY.md`.

## Assets and trust boundaries

Assets: account credentials (hashed passwords, `lzs_` tokens, TOTP seeds),
session cookies (from 0.16.7 a format an outside process on the same host may
verify read-only, SM1383, holding the same key), site content, form submissions,
the per-install HMAC secret, the audit trail, the Odoo connection user's key and a
person's Odoo session (0.15.5), and, since the visitor log names the signed-in
account (0.16.1, SM1219), account names in the log. From 0.16.8: rows' earlier values
in the data store's row history, kept for each table's period (SM1355), and, where
the offline kit is on, a person's kept reads and queued changes in their own browser
under a label of their login (SM1396). From 0.16.9: an account's passkeys, public keys
only (SM1352), its web-push endpoints and optional phone number (SM1363), the site's
own web-push signing key and an outside sign-in provider's client secret, the last in
the one secrets store (SM1351, SM1369 X6), and, in a table that names a source, the
rows another system's API sends (SM1364). Restated at the 0.16.9 walk; confirmed by the release manager on
2026-11-10 (ruling 226).

Trust boundaries (each is where an attacker's input crosses into trusted code):

1. **The public web request** -> the processor / auth wrapper (anonymous
   internet).
2. **The `X-Remote-*` header contract** -> everything downstream trusts it;
   the edge must strip client-supplied copies (the two-signal trust gate). From
   0.16.9 (SM297) it is the contract across an exec only: the auth wrapper is its one
   producer, for the surface it execs (the CGI path, and the pool's relay to the
   manager API). A surface converted to identity-as-a-value (the data endpoint first)
   holds the verified identity in `Lazysite::Auth::Identity::$HELD` and its readers are
   answered that; it writes no header and none is read.
3. **The WebDAV / control-API / MCP partner** -> a token holder with a bounded
   capability set and per-file ACLs.
4. **Authored content + layouts** -> Template Toolkit evaluates them server
   side.
5. **The manager operator** (cookie, a member of the operator group - the
   group carrying the `manager` flag, which setup-sysop makes) -> passes the
   manager's capability gates and per-file ACLs (SM991). `manage_users` is
   user and group management and nothing more: since SM979 a file's rule binds
   it, and since SM991 it passes no other capability gate and cannot change the
   operator's account or the operator group, or revoke the operator's sessions
   or access keys. `local` (the CLI) and an unsecured site pass too; a token
   never does.
6. **The served tree boundary** (SM286, 0.10.8) -> protected content is MOVED
   out of the document root into `<docroot>-lazysite-private`, so the boundary
   is now a filesystem one and not only a decision one. A front end that serves
   a file without asking the engine can no longer reach protected bytes. See
   `architecture/security.md` - "Content outside the served tree".
7. **The front door** (SM293, 0.10.8) -> `lazysite-front.pl` +
   `Lazysite::FrontDoor::route()` may be the single entry point that decides
   which surface handles a request. Where deployed, the routing table becomes
   one point of correctness for every request rather than a rule per URL class.
   See `architecture/security.md` - "The front door".
8. **The scheduled actor** (SM666, 0.13.0-0.13.1) -> a long-lived,
   privilege-dropped process acting on a clock with a capability-holding
   account and NO request. Two gates: the account must hold `run_jobs`, and
   each job faces the ordinary capability gate for the work it does. The job
   set is engine code; no configuration can add one. `daemon_job_user` is a
   delegation - a `manage_config` holder names which `run_jobs` account acts -
   bounded by that closed set.
9. **The pool worker's identity** (SM1181, 0.15.12) -> on the one-rule pool a
   signed-in request is no longer passed between two programs by headers; the
   front door calls `Lazysite::Auth::Session::request_session` and the worker
   holds the answer as a value for that request only. The worker never believes
   `LAZYSITE_AUTH_TRUSTED` from its environment, strips every identity and
   payment header when it holds a value, and clears the value at both ends of the
   request. See `architecture/security.md` - "Who a request is, decided once".
10. **The trusted proxy and the forwarded address** (SM1129-SM1131, 0.15.10;
    SM929, SM1189, SM1194, SM1196, 0.15.11) -> two lists, kept apart:
    `auth_proxy_trusted_from` (whose identity headers are believed, matched
    against the TCP peer) and `trusted_proxies` (whose `X-Forwarded-For` is
    believed about a visitor's address). A front end that passes the client's
    `X-Forwarded-For` through lets any visitor choose their address, so the rollout
    and `lazysite check` name that as a failure. Every address-keyed control and
    every address rule sits behind this boundary.
11. **The address rule** (SM1134, 0.15.10; SM1343, 0.16.5) -> named address profiles
    that pages, folders and groups allow or deny; it narrows what other rules grant
    and never widens it. From 0.16.11 (SM1435, ruling 234; confirmed by the release
    manager on 2026-11-11, ruling 237) a rule names only profiles that exist, refused at
    save at every door, and a profile a rule names cannot be deleted.
12. **The Odoo extension** (SM747, 0.15.5; SM1160, 0.15.10) -> an outbound
    connection to an ERP on the operator's URL, a connection user's key, a person's
    own Odoo session, an anonymous visitor's bounded write path, and (opt-in) the
    person's Odoo login as the site sign-in under an `odoo:<login>` identity. From
    0.16.7 (SM1369 X7 part one; confirmed by the release manager on 2026-11-07,
    ruling 149) its modules live in the extension's own payload lib,
    `extensions/odoo/lib`, and core loads them only through
    `Lazysite::Extensions::require_payload`, the X1 rule: the same code in the same
    processes, from one place; and the endpoint carries a renewal step (SM1381,
    `?renew=1`), a tokenless GET that asks Odoo once under the person's own Odoo
    session cookie and renews or ends the site session as `?csrf=1` does.
13. **oomd, the resident OOM** (SM1164, 0.15.10) -> one long-lived process per
    site, opt-in (`odoo_daemon`), supervised by lazysited as the same user, reached
    by a Unix socket in a 0700 directory, holding the connection's key files by label.
14. **The warm-fork parent of the Odoo endpoint** (SM1226, 0.16.1) -> one long-lived
    process per site with a pool conf and the Odoo extension on, supervised by
    lazysited as the request-path user, listening on a 0600 socket in the site's 0700
    `lazysite/run/`. The one-rule pool hands it the endpoint's requests; it holds
    compiled code and nothing else, and forks a fresh child per request.
15. **An extension's code in a core process** (SM1369 X1, 0.16.6; confirmed by the release
    manager on 2026-11-06, ruling 142) -> the hook loader,
    `Lazysite::Extensions::Hooks::call_hook`, runs a function an enabled extension
    declares from its own payload lib (`extensions/<stem>/lib`) inside the calling
    process, with that process's rights, once a slice gives it a caller. In 0.16.6 it has
    none and no hook kind is accepted. From 0.16.8 it has three (restated at the 0.16.8
    walk; confirmed by the release manager on 2026-11-08, ruling 182): the manager API and MCP run
    an extension's declared actions (SM1369 X2), the processor resolves its page
    sources and the handler catalogue and the timer run its handler types (X3), and
    the processor serves its asset files and renders its components and template
    variables (X5's asset part); Odoo is the first extension declaring each, and the
    offline kit (SM1396) the second asset consumer. From 0.16.9 it has more callers
    (restated at the 0.16.9 walk; confirmed by the release manager on 2026-11-10, ruling 226): the
    session code asks an extension's identity provider for its `on`,
    `still_valid` and `groups` (SM1369 X4; the `oidc` extension is the second provider,
    SM1351), an extension's endpoint runs after core's request kit has capped the body
    and checked the token (X5), the supervisor runs the services it declares (X5),
    `lazysite check` runs the checks it declares (X6), and the processor serves a page it
    ships under `/manager/` to a holder of its capability (X6). The secrets store is
    core's, not a caller: an extension passes its own id. On an engine carrying
    `SHARED-ENGINE` (SM1361, X7) the loader finds an extension only in the engine's own
    directory and refuses anything in the site's. What crosses is the extension's declaration, the
    index the manager writes from it (`lazysite/extensions.index.json`) and the module
    files it names; each is checked at the build and again at the call. See
    `architecture/security.md` - "Extension hooks, agent roles and the primary's reach".

Not yet code, so not yet boundaries: SM1128's directory groups. Its native OpenID
Connect relying party is code in 0.16.9, as the `oidc` extension (SM1351), reached
through boundary 15 and the new-external-interface its entry records. Corrected at the 0.16.9 walk; confirmed by the
release manager on 2026-11-10 (ruling 226). The visitor log's
signed-in account (SM1219) and the maintenance capability (SM1118), held out of the
0.16.0 stable, are in 0.16.1; see `architecture/security.md` and the register.

## STRIDE assessment

```datatable
columns: Category | Top threat for lazysite | Control (and where) | Residual / ASVS
widths: 2.6cm | X | X | 3.4cm
bold: 1
tone: medium
text: 2 3
---
Spoofing | Forged `X-Remote-User` / `X-Remote-Groups` headers from the client, impersonating an operator | Two-signal trust gate + mandatory edge stripping (`apply_trust_gate`; security.md "Auth proxy trust model"); cookie is HMAC-signed | Since SM293 step 4 the gate is an ENFORCED APPLICATION CONTROL (`t/lint/38`), so edge stripping is defence in depth rather than the sole control - this was the single highest-consequence operator obligation and is no longer; verified by lazysite-check --check-dav and the vhost template shipping the RequestHeader unset lines
Tampering | Hostile `layout.tt` / page executing arbitrary Perl through Template Toolkit | TT runs with `EVAL_PERL=0`; layout authoring gated by manage_layouts + webdav; content vs layout capability split (SM082) | ASVS V5: a layouts-capable partner is inside the trust boundary by design - scoped by capability, not sandboxed
Repudiation | An action taken with no attributable record | Append-only audit trail (who/what/target/origin/outcome), incl. denied attempts; login/logout audited; shell user management audited too (origin `cli`, invoking OS identity), installs/upgrades as origin `install`; the writer is failure-loud (0664 umask-proof create, self-heal, WARN naming any lost entry) | Audit read gated by the `audit` capability; ASVS V7 logging met; time is server clock
Information disclosure | Protected content served by a front end that never consults the engine (SM248, SM268 H17, SM283 - three incidents, one cause); auth secrets or raw logs readable off the docroot; visitor PII in stats | **Protecting content MOVES it out of the document root** (SM286), so this is structural rather than configurational; the front door makes the routing decisions inside the engine (SM293); secrets under `lazysite/auth/` (Apache-denied, 0660); stats export is aggregated + IP-anonymised; raw-log download removed (0.5.29); error surface synthesised | Sections protected BEFORE 0.10.8 stay in the document root until re-applied - an operator action no upgrade performs. TOTP seeds are stored recoverable (documented at-rest note, security.md) - accepted at L1, an L2 gap to close with an at-rest key
Denial of service | A flood of CGI forks, or an unbounded upload / render, exhausting the host; vulnerability-scanner probe floods | Login rate limiting (per-IP window; an extension, on by default - switched off it says NOT in force in the log and in lazysite check, SM798; unable to count it refuses every sign-in, ruling 206); upload size gate; PUT streamed in bounded chunks; checked writes fail closed on ENOSPC (review D5). SM128: the bad-URL auto-blocker (on by default) refuses an IP after it hits too many scanner-probe paths in a window, enforced in the auth wrapper | No global concurrency cap (relies on the web server / MPM); capacity test is a held pre-launch item; the auto-blocker covers auth-wrapped sites
Elevation of privilege | A token/WebDAV partner reaching manager-only actions or another account's files; a manager account driven remotely | Token clients are confined to the control-API subset + `%need` capability map; never operators; per-file ACLs bind them (SM074); manager bypass is cookie-only. SM127: an account with group-granted manager access (`ui`) is refused outright on the api/mcp transports, and a group may not combine `ui` with `api`/`mcp` - manager access is interactive-only, so a leaked/misissued token on a manager account cannot drive the site | ASVS V4 met; the capability model is groups-only + explicit (ADR 0003), removing implicit manager status
Spoofing | A request's identity decided in a long-lived pool worker: a client's own `X-Remote-User`, or `LAZYSITE_AUTH_TRUSTED` sent as a FastCGI parameter, read as a verified identity; one visitor's identity served to the next (SM1181) | `request_session` is the one function behind the wrapper and the pool; in the pool the sentinel is never believed and a held value makes `apply_trust_gate` strip every identity and payment header; the value is cleared at the start and the end of each request (t/lint/269); `auth/.secret` is read per call and never cached | The split FastCGI templates keep the CGI wrapper for signed-in requests by decision; the security review in the SM1181 filing lists fourteen threats with the test that holds each
Spoofing | A client naming its own address or account through a proxy: identity headers from an unlisted peer; `X-Forwarded-For` passed through by an old front end (SM1129-SM1131, SM1189, SM1194, SM1196) | Identity headers are believed only from `auth_proxy_trusted_from`, which fails closed; one reader honours the configured header names; the proxy's user wins over a cookie; the Hestia rollout compares and replaces an old template and reports a pass-through vhost as a failure; `lazysite check` warns while the trust set is not empty | The private-range default for `trusted_proxies` is believed behind a front end that passes the header through until the vhost is rebuilt; verified by the rollout and by a probe request
Elevation of privilege | Odoo sign-in granting site rights, or an anonymous visitor reaching an ERP through a page (SM747, SM1160) | The Odoo-minted site session grants only the mapped groups, held server-side, and a mapping to any group carrying a capability is refused at save and at load; a public or scheduled write needs `apply: immediate` and is bounded by the connection user's Odoo rights, the bound operation, hourly caps and a visitor-bound token; a session binding never falls back to the connection user; OOM's approval gate stays on | A site session lives at most `odoo_identity_ttl` past the last Odoo check; the connection user's rights are set in Odoo by whoever administers it
Elevation of privilege | A process that outlives a request taking calls without the request's gates (oomd, SM1164) | Opt-in and off by default; started only while every gate holds; the socket directory is 0700 and the config 0600 with credentials as labels; `required` refuses with `daemon-down` where `on` falls back in-process | oomd has no sign-in verb, so sign-in stays in-process
Tampering | A raw or `api:` page served as `text/html` past the ADR 0006 downgrade through a front-matter spelling the renderer read and the downgrade did not (SM1213) | One reading of `api:` and `raw:` in the renderer, the manager and the downgrade's peek; an empty key takes its own line only | Closed in 0.15.15; no gated page opened (t/integration/305)
Information disclosure | A page or a group's rights reaching an address the operator excluded (SM1134) | Named lists decided by one module; deny wins; an unreadable store, an unparseable address and a wrong-kind name each deny; every layer must admit; groups drop out for a refused address | Only as good as the request address: see the trusted-proxy row
Information disclosure | A page held back by a rule keyed by its stem (`/about` stored as `about`) published by a move or a delete that re-keys only the page's own key, its bytes synced back into the document root (SM1257, SM1242, SM1258) | `Acl::fold_page_stem` is the one function every mover and deleter calls (the manager, MCP `move_file` and `rename_page`, the control API, WebDAV MOVE and DELETE): the stem rule moves or goes with the page while no folder of that name exists, and the store sync puts the bytes where the rule says | Closed in 0.16.1; a stem key that is a folder's rule is left alone by design (t/unit/manager/160, t/unit/dav/34)
Information disclosure | A long-lived parent that every Odoo endpoint child is forked from holds a key, a secret or one visitor's request, and every later child inherits it (SM1226) | The parent requires code and runs none of it, reads no configuration or key and never reads a request; a fresh child per request, which exits; the child's environment is the parameters less every identity variable, and the endpoint verifies the cookie itself; `srand` in the child | t/integration/325 reads the parent's memory after signed-in requests and finds no secret, key, cookie signature, token or parameter; t/lint/272 classifies what it holds
Elevation of privilege | A theme archive's symbolic link copied into the served asset mirror, so a public URL under `/lazysite-assets/` named any file the web server can read - the session-signing secret `lazysite/auth/.secret` among them, from which a `manage_themes` holder could mint an operator's session (SM1303) | The theme upload checks every entry before extracting any and refuses a symbolic link, a file type the web server runs and an archive over the upload limit; `lazysite check` warns for every link under `lazysite-assets/` (SM1304) | Closed in 0.16.2; a link planted before then stays until removed, and the secret it may have served until rotated (t/integration/336, t/tools/290)
Information disclosure | A grant confined to a scope answered from the whole docroot by a listing or search that names no path, which the scope check skips; a search quoting lines of a file whose rule the caller does not pass (SM1308) | A confined grant's missing or empty path is its scope roots and every walk starts there (MCP `list_files`, `list_pages`, `search_files`, `delete_page`'s references, `rename_page`'s link rewrite; the manager API's `list` and `pages`); each search hit is asked `_acl_denied`, read_file's question | Closed in 0.16.3 (t/unit/mcp/65, t/unit/manager/415); `audit_site` is confined too and a page's title is listed only to a caller who may read it (SM1311, SM1312; t/unit/mcp/68, t/unit/mcp/69)
Elevation of privilege | A member of a protected area writing a rule on a subfolder that admits a non-member, which replaces the area's rule there by longest match (SM1309) | Writing or moving a rule that admits, to read or write, anyone its enclosing rule does not is refused unless the operator or the enclosing rule's owner does it (`Acl::widening_refusal`, `move_widening_refusal`), on every surface that writes or moves a rule | Closed in 0.16.3 (t/unit/mcp/66, t/unit/dav/36); a carve-out written before then is honoured until removed, and `lazysite check` names each for review (SM1313; t/tools/295)
Denial of service | An upgrade that moves the extensions directory and its key leaving a site's list, or one entry, under the old spelling, so each extension it names reads as off, and silently - the login rate limiter among them (SM1142) | `install.pl`'s one-time `extensions-rename` converts the list and its entries and moves the directory, and is recorded as done only when it ran without a warning; `login-rate-limit-on` runs after it; `lazysite check` names an old-spelling line by number and an old directory left beside the docroot, and says when the limiter is not in force (SM798) | 0.16.4 (t/tools/306, t/journey/06); a line written back by hand reads as off until it is corrected
Elevation of privilege | A theme's source re-mirrored into the served asset mirror on every write to it (SM1335), so a symbolic link or a file type the web server runs that reaches a theme's `assets/` by any means - a shell, a restore, a WebDAV or manager write - is published under `/lazysite-assets/` with no activation, as SM1303's archive link was | `_mirror_theme_assets`, the one writer of every copy, refuses to switch in a copy whose `assets/` holds a symbolic link or a server-run file type (`_mirror_unsafe_entry`, SM1303's two checks; links listed, never followed) and keeps the copy it had; a served copy itself is refused to every writer, the operator included (`served_artifact_refusal`, SM1339) | 0.16.5 (t/unit/manager/430, 432, t/unit/dav/38); the refusal is a log line and a `mirrored: 0` answer, so a source that holds such an entry stops reaching its copies until it is removed
Denial of service | The bad-URL blocker exempting loopback always (SM1321, ruling 83): on a site behind a front end that `trusted_proxies` does not cover, every visitor arrives as 127.0.0.1, so no probe is counted and the blocker is off for everyone | The blocker asks `request_address` under `trusted_proxies` (SM929), so behind a covered front end the exemption is the machine's own checks only; `lazysite check` warns when address rules exist and `trusted_proxies` trusts no front end (SM1141); `bad_url_exempt: none` removes loopback's exemption | 0.16.5 (t/unit/lib/98); the blocker was refusing every visitor on such a site before (T-03), so the change trades a self-inflicted refusal of everyone for no probe counting until `trusted_proxies` is set; the default trusts only the private ranges, not loopback, and a site with no address rules is not warned (UPGRADE.md, the 0.16.5 entry, says to name a front end on the same host)
Denial of service | The bad-URL blocker believed on and off behind Apache (SM1455): the auth wrapper took its path from `REDIRECT_URL`, which Apache leaves unset on the rewrite [PT] and `FallbackResource` routes into it, so the guard asked about `/` on every request and never counted a probe | The wrapper's path is `REDIRECT_URL`, else `REQUEST_URI` less its query, the front door's precedence; t/integration/732 sends probes by both routes to real Apache, the template's own rules, and is refused at the threshold | 0.17.1 (t/integration/732, 14; drafted by the developer agent, for the release manager's confirmation); access rules were never affected (the processor reads the right path), so the exposure was scanner probes going uncounted, from the line's first release
Elevation of privilege | An extension's own Perl run inside a core process (SM1369 X1): code that is not the extension's - core's, a system module's, a planted file's - run under its name, a disabled extension's entry or an edited index still honoured, a hook that dies taking the process with it | The declaration is validated before it is indexed; each module must be a regular file in the extension's payload lib, a real directory, found nowhere else on `@INC`, checked at the build and at the call; the payload lib is appended to `@INC`, never prepended; the extension and what it requires must be on at the call, read fresh; a dying hook is a failure, never an exception into core | 0.16.6 (t/unit/extensions/70, 71; t/tools/330; row confirmed, ruling 142): built with no caller and no live kind; in process a hook is a contract, not a sandbox, so trust is what is installed (ADR 0009); each later slice that adds a caller is assessed against boundary 15
Information disclosure | An account reaching the primary - one granted nothing, or the primary's row - reading and writing every secondary domain's folder under the docroot through the primary's content (SM1372, the residual risk SM1332-SM1334 recorded) | The primary's content is the docroot less the other domains' content roots, one rule (`DomainAccess::foreign_root_of`) asked by the manager API, MCP and WebDAV, on reads, writes and walks; a listing leaves those folders out for a caller refused them (ruling 137) | Closed in 0.16.6 (t/unit/manager/446, t/unit/dav/39, t/unit/mcp/74; row confirmed, ruling 142); the operator group and an account granted a domain keep it; a secondary with no content root of its own serves the primary's content
Denial of service | The site used as a mailer: a visitor typing a stranger's address in a form whose conf opts in to an acknowledgement, so the site mails it (SM1362) | The message is the form's fixed text with nothing of the submission in it; 3 an hour per address and 60 per site across every form and smtp handler, one record; the form's own per-address limit, render timestamp and honeypot first; a quarantined submission is never answered; an unreadable cap record refuses | 0.16.6 (t/unit/forms/68; row confirmed, ruling 142); opt-in per form; a visitor can still have the fixed text sent to an address they name, within the caps
Tampering | An Odoo module loaded from the wrong place now that the extension's modules live in its payload lib (SM1369 X7 part one): a stale copy an earlier release left in core's `lib/`, an edited one the upgrade kept as an orphan, a module planted in a second payload lib, or a payload linked in from elsewhere, run in place of the extension's own | `require_payload` loads only a regular file in exactly one payload lib - a real directory beside a descriptor under the engine's own `extensions/`, appended to `@INC`, never prepended - and refuses by name a module that also resolves anywhere else on `@INC`, so nothing loads; the upgrade removes the old copies and the directories they emptied, and keeps an edited copy only as a named orphan, which is then refused, never run | 0.16.7 (t/unit/extensions/75, t/lint/335, t/tools/335; row confirmed by the release manager on 2026-11-07, ruling 149): an edited old copy stops Odoo until it is removed, fail closed; whoever can write the engine tree can write either copy, as before
Information disclosure | A page source an extension declares (SM1369 X3, H-2) handed a visitor's session credential into a render that is shared and cached, so one viewer's value is served to the next; a value a remote system answered reaching a template with markup in it; a handler type an extension declares (H-3) run from an origin it did not list, or configured, scheduled and run under a capability it never declared | Core hands a source the page, the key, the request address and host and mode `render`, and the cookie header and identity only to a source that declared `per_viewer`, whose page is never read from or written to the page cache and is no-store (the gated page's treatment), and is refused outside a page's own front matter; every value a source answers is made inert by core (escaped, no link scheme) before a template sees it; a source that dies or answers nothing is the empty string and one WARN line; a type's `cap` must be a capability the engine or an extension declares, gates creating, editing and scheduling it and must be held by the timer's job account, and a delivery from an origin the type did not list is refused by core before the extension's code is loaded; two extensions cannot declare one prefix or one type name | 0.16.8 (t/unit/extensions/79, 73; drafted by the developer agent, confirmed by the release manager on 2026-11-08 with the X3 entry, ruling 177): the first callers of boundary 15's loader on the request path and in the handler catalogue; what a source reads and what a type does are the extension's own code (Odoo's refusals of a write, a visitor key, a session binding and a download moved with it), and a type's `deliver` runs with the visible fields of a submission, so the extension sees what a core type sees
Tampering | The renewal step on the Odoo endpoint, `GET /cgi-bin/lazysite-odoo.pl?renew=1`, reached with no token (SM1381): a cross-site request ending a person's site session (a forced sign-out), `next` or the renewal path as an open redirect, a redirect loop, or repeated requests driving calls to Odoo | Nothing is renewed or ended without the `lzs_odoo_session` cookie, `SameSite=Strict` and scoped to the endpoint, which a cross-site request does not carry; the step grants only what `?csrf=1` grants, under the group map's capability refusal; `next` and the site's `auth_redirect` pass `sanitise_next`, and core accepts the renewal path only as a same-site path with a query; GET only, one Odoo call per stale session, and one renewal a minute per browser (`lzs_renewed`) | 0.16.7 (t/unit/odoo/135, t/unit/auth/74, t/integration/293; row confirmed by the release manager on 2026-11-07, ruling 149): a holder of a stale session can make one Odoo call per request to the step, as with `?csrf=1`; a client that sets `lzs_renewed` itself skips only its own renewal
Spoofing | One key signing three payloads with no domain separation (SM1383, found; SM1390, closed): a theme-preview cookie `v1:<expiry>:<layout>:<theme>:<user>` read as a legacy session for an account named `v1`, a session read as a preview, a timestamp in the future outliving the lifetime, and the key itself in the hands of an outside process on the same host that verifies `lazysite_auth` | The session verifier refuses a payload beginning `v1:` before anything else is read, and a timestamp or `seen` time more than 300 seconds ahead of its clock; the preview verifier refuses a payload without exactly five fields; no account may be named `v1` on any door that creates or renames one, and `lazysite check` names one that exists; the contract document puts an outside reader in the web server's trust, forbids it the groups in the cookie and every write, and the format changes only versioned, reader before writer | 0.16.7 (t/unit/auth/75, 76; t/integration/361; t/unit/users/71; t/tools/333; row confirmed by the release manager on 2026-11-07, ruling 149): the key stays symmetric, so a process that can verify can mint, and "read-only" is that process's promise; the CSRF token shares the key and never travels with its payload
Elevation of privilege | A group deleted while an access rule, a page, a domain, a data table, an Odoo binding, a connector or a group map still names it, so a group made later under that name - by any `manage_users` holder, a token included - inherits every grant those references make (SM1387; the cookie Groups page did this) | `group-delete`, MCP `delete_group` and the Groups page all go through the users tool, the store's one writer, which refuses the operator group, a group with a member and a group anything names (`Lazysite::Auth::GroupRefs`, the twelve places), naming each; a confined caller deletes only a group it created with `group-set`; audited as `@group` | 0.16.7 (t/integration/357; row confirmed by the release manager on 2026-11-07, ruling 149): a store naming groups that GroupRefs does not read is not refused, so a new one is added there; a reference left by a deletion before 0.16.7 admits nobody through the name until it is reused
Elevation of privilege | A member - an account without `ui`, perhaps one of hundreds - writing through the manager API's cookie door once `write_content` opens it (SM1414): a path no rule governs, a file whose rule names someone else, the engine's `lazysite/` tree, another domain's content or the primary's, an action outside the content verbs, a rule widened | The door admits a `write_content` holder only for the six actions declared `member_content` (read, list, save, mkdir, move, delete), checked at load; a write needs the governing rule's write list to name the account or its group, so an ungoverned path and a rule naming others are refused; paths are refused climbing, NUL, backslash or reserved, and resolved inside the session's domain's content root, another domain's root refused; a listing shows only entries a rule lets the member read; acl-set is outside the set; CSRF and the audit row are the door's | 0.16.8 (t/integration/377; row written at the 0.16.8 walk, confirmed by the release manager on 2026-11-08 (ruling 182), with the SM1414 entry confirmed by ruling 177): a folder rule naming a members' group lets any member overwrite or delete another's file under it, which is what the rule says; a listing does not ask the address rules per entry
Information disclosure | A person's earlier values kept after the table no longer holds them (SM1355): a row's values before a change, and a deleted row's, in the row history (`_row_changes`), read back by someone who may not read the table or for longer than the site means to keep them | The history is read only with `manage_data` under the table's read rule; it is kept for the table's period (90 days by default, `row_history_days` otherwise) and pruned after each recorded write and daily by the daemon's `row-history-prune` job, which needs only `run_jobs` and is audited each run (rulings 170, 175); an undo past the period is refused | 0.16.8 (t/unit/data/81, 82; t/unit/daemon/05; row written at the 0.16.8 walk, confirmed by the release manager on 2026-11-08 (ruling 182), with the SM1355 entry, which fires new-processing-of-restricted-data, confirmed contained by ruling 177): where the daemon does not run, a store nobody writes to keeps expired changes until its next write; the store is in the site's backups as the table is
Information disclosure | The offline kit's kept reads and queued changes in a browser (SM1396) shown to, or sent as, the next person at a shared device, or kept for nobody and sent as whoever signs in next | What is kept is stored under the owner label `?csrf=1` names (a hash of the login, on a site whose Odoo sign-in is the site sign-in), shown and sent only while that owner is signed in; nothing is kept with no owner; the kit's wrapper of the Odoo helper's sign-out empties that owner's kept reads; a queued change is sent once with its `Idempotency-Key`; no token, cookie or password is stored | 0.16.8 (t/unit/extensions/78; t/unit/odoo/28, 41, 63; row written at the 0.16.8 walk, confirmed by the release manager on 2026-11-08 (ruling 182), with the SM1396 entry, which fires new-processing-of-restricted-data, confirmed contained by ruling 177): a session that ends without the helper's sign-out leaves the kept reads under the owner's label, readable in that browser's storage by whoever uses its profile; a queued change waits for its owner by design; both are kept as built (ruling 183)
Spoofing | An extension's identity provider minting a session under another provider's id or a local name, outliving its provider, or handing a group that carries a capability (SM1369 X4, H-1) | Only core signs: `mint_provider_session` and `renew_provider_session` are the provider's only way to a session; the provider is read from the index and never from the cookie, whose `<id>=` prefix cannot be a local name; the extension must be on at every check; a group that carries a capability is dropped unless the provider declares `grants`, and a provider function that fails is no session | 0.16.9 (t/unit/extensions/80; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the X4 entry, confirmed on 2026-11-10 (ruling 225)): a provider is the extension's own code under boundary 15's contract, not a sandbox
Spoofing | A forged, replayed or misdirected answer from an outside OpenID Connect provider (SM1351): a login-CSRF answer, a code started in another browser, an ID token for another issuer, client or time, a provider named inside another's family | A state in an HttpOnly, SameSite=Lax cookie must match the answer and name a single-use pending record that lasts ten minutes; the code is exchanged over TLS with PKCE (S256) and the client's secret; the ID token must name the configured issuer, this client (`azp` with several audiences) and the nonce sent, and not have expired; every call is https (http only to this host), follows no redirect, is capped at 256 KB and times out at 10 s; core refuses another extension's provider inside an instances provider's family | 0.16.9 (t/unit/extensions/170; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1351 entry, confirmed on 2026-11-10 (ruling 225)): the ID token's signature is not checked (ruling 185), so the trust rests on TLS to the token endpoint
Elevation of privilege | A provider's group claim making a manager here (SM1351, ruling 186): a group mapped to operators or any capability group, whoever controls that group at the provider | A person in no mapped group is not signed in and no account is made; the record's groups are re-read against the current map at every request; every sign-in and renewal writes a `login-grant` or `renew-grant` audit row naming the groups granted; only the operator saves a map entry whose target carries capabilities (ruling 214); the Sessions page can mark a session stale so the provider is asked again (`session-reauth`) | 0.16.9 (t/unit/extensions/170, t/unit/manager/582; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1351 entry, confirmed on 2026-11-10 (ruling 225) and ruling 186's first use): membership is read at sign-in only, so a person removed at the provider keeps the group until the session ends, is revoked or is marked stale; the map is for a provider whose membership the site controls
Spoofing | A passkey sign-in accepted for a signature the site did not ask for, one made for another site, a replayed or cloned answer, or a passkey planted in another person's account (SM1352) | A challenge is 32 random bytes, answerable for five minutes, issued for one purpose and spent by the first answer; the origin and the RP ID hash must be this host's and user presence and user verification both set; the signature is checked with the key and algorithm stored at enrolment over bytes the engine builds, a counter that does not advance is refused; the sign-in passes the password sign-in's address scope, rate limiter and account gates; a passkey is added only by its own account, and a manager can only wipe them all | 0.16.9 (t/unit/auth/107-109, t/unit/account/36; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1352 entry, confirmed on 2026-11-10 (ruling 225)): attestation is `none`, so the authenticator's make is not checked; the challenge directory holds at most 1000 for five minutes, so a flood can delay passkey sign-ins
Tampering | A web-push endpoint an account registered pointing the site at an internal address, or a notice's content leaving by a push or a webhook (SM1363) | An endpoint is stored only as https, 1024 characters at most, a bounded number per account, and at send passes `Fetch::is_safe_url`, follows no redirect and is read to 4 KB in ten seconds; a push carries no payload; the webhook body is the notice's kind, title, login and link, never its content; `webhook.per_hour` and `mail.per_hour` bound the sends; only the account adds or removes its own device | 0.16.9 (t/unit/notify/41, t/unit/account/38; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1363 entry, confirmed on 2026-11-10 (ruling 225)): a name that re-resolves between the check and the connect could still reach a private address, the window `Fetch` has
Information disclosure | An account's phone number leaving the site, or set for a stranger's (SM1363, ruling 196) | The number is carried in the webhook route's connector call alone, not in a push, a mail, the bell record or the log; the route reaches an account only where an operator set `notify_routes: webhook`, under its own bound and the connector's call record; the form is checked in the users tool | 0.16.9 (t/unit/notify/41, t/unit/account/39; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1363 phone entry, confirmed on 2026-11-10 (ruling 225), which fires new-processing-of-restricted-data): a member whose account was given the webhook route can set any number in the right form; the number is at rest with the rest of the record
Spoofing | An identity written into the data endpoint's environment, by the client or the web server or the process, believed by the endpoint's readers (SM297, boundary 2) | The endpoint holds the verified identity as a value (`local $Lazysite::Auth::Identity::HELD`), its readers are answered that and read nothing from `%ENV` while it is held, and it writes no `X-Remote-*` header; a session whose store cannot be read is refused 503 | 0.16.9 (t/unit/auth/177, t/integration/478, 479; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM297 entry, confirmed on 2026-11-10 (ruling 225)): the manager API in the pool keeps its relay and the header contract until 0.17.0 (ruling 217)
Elevation of privilege | Code planted in a site's extensions directory run in place of an engine extension, on the shared container's read-only engine (SM1361, SM1369 X7) | On an engine carrying `SHARED-ENGINE` every extension is the engine's own copy, anything in the site's extensions directory is refused by name and named by `lazysite check`, a site payload module that an engine extension's lib holds is refused, and the marker is read from the engine's own root and never a site's | 0.16.9 (t/unit/extensions/130, t/tools/391, t/lint/391, 392; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1361 entry, confirmed on 2026-11-10 (ruling 225)): every site in the container runs as www-data (ruling 210), so one site's process can read another's state; the separation is the engine's confinement of each request
Tampering | A remote system's answer writing columns of a table, rows another door could forge, or emptying the table (SM1364) | Only the one table that names a connector as its source is written by that connector's answer, through `import_rows`' coercion and all or nothing; mapped columns are refused at every write door; a row is removed only when the answer is a non-empty list, as a recorded, undoable change; the on-demand refresh needs `manage_data` and the connector's own callers rule | 0.16.9 (t/unit/data/110, t/unit/manager/512; row written at the 0.16.9 walk, confirmed by the release manager on 2026-11-10 (ruling 226), with the SM1364 entry, confirmed on 2026-11-10 (ruling 225), ruling 190): an operator who marks a sourced table `public: true` publishes what the source sends
Elevation of privilege | The root-run Hestia deploy (SM1427) writing outside the site, or acting on a site tree the site user owns: a registry entry built from the site's own files, one overwriting another site's, a claim link made for the wrong account, a `--all` naming sites the registry did not | The registry entry is built from the command line's USER and DOMAIN alone, written only when none exists (a test, then a temporary file moved with `mv -n`); `install.pl --site-url` and `setup-sysop` run as the site user through `sudo -u`, not as root; `--sysop` and `--channel` are checked before anything is touched; the claim link is `setup-sysop`'s single-use, 24-hour link; `upgrade --all` still skips a site whose `update_policy` is not `auto` | 0.16.10 (t/tools/624, 625, 627; row written at the 0.16.10 walk, confirmed by the release manager on 2026-11-10 (ruling 233), with the walk's entry and the claim-link residual risk, SM1429): the claim link is printed to the terminal of whoever runs the deploy (the summary says it is a credential for 24 hours); USER and DOMAIN are validated, USER against Hestia, before anything is touched
Elevation of privilege | A deny rule that names an address profile the store lacks, which excludes nobody and says so only in a log line; an allow rule that names one, which admits nobody; a profile deleted while a rule names it (SM1139's accept-with-warning, SM1141's force) | A rule, a group's address limit and a page's `addresses:` / `addresses_deny:` are refused at every door when they name a profile the store does not hold, naming it, with nothing written; the names a rule already carries are checked on its next save; a profile a rule names cannot be deleted, at any door, with no force; a store that cannot be read refuses and is named (ruling 206); `lazysite check` names a rule or a page already on disk that names a missing profile | 0.16.11 (t/integration/730 and 731, t/unit/mcp/489 and 490, t/unit/users/548 and 53, t/unit/manager/974; row written at the 0.16.11 walk, SM1436, confirmed by the release manager on 2026-11-11 (ruling 237), with the SM1435 entry): a rule or page saved before 0.16.11 that names a missing profile stands until it is changed, a file edited on disk outside a door is not refused, and the runtime's treatment of an unknown name is unchanged
Elevation of privilege | A full backup restored by `install.pl --restore-full` (SM1439): a tarball bringing code, modes or an owner of its own, or a restore leaving a site that does not serve | The restore is a system-user operation (a full backup carries the auth secrets; no manager or network door); every file of code it writes, every mode and the group come from the release it runs and the operator's `--serving-group`, the extraction takes no owner or mode from the archive (`--no-same-owner`, `--no-same-permissions`) and vets member names for `..`, an engine that cannot be laid refuses before anything is extracted, and the install state is written from what was laid | 0.16.12 (t/tools/628; row written at the 0.16.12 walk, SM1441, confirmed by the release manager on 11 Nov 2026 (ruling 243), with the SM1439 entry): a backup holding `lazysite/`, `lazysite/auth` or `lazysite/forms` as a symlink is refused before anything is made (t/tools/628), and the backup is still written inside the docroot (SM602)
Denial of service | A full backup taken in a detached worker that outlives its request, started again and again, or never ending (SM1446, ruling 248) | The worker is the request's own code under the same unix user, with no new action: starting one is `manage_config` (cookie) only; a second full backup is refused while a live pid marker under six hours old names one in progress (409, naming the running file); the worker holds no input after the request, its stdin, stdout and stderr are /dev/null, it ends with `_exit`, and a backup it does not finish is listed as unfinished and never restored | 0.17.0 (t/unit/manager/977; row written at the 0.17.0 walk, SM1448, confirmed by the release manager on 12 Nov 2026 (ruling 251)): one residual, that two starts in the same instant can both pass the check (it reads the markers before the claim is made), so two tars can run at once; and a worker still running after six hours is no longer counted as in progress
```

## Five priority entries (from the review)

1. **Forged trust headers** - the top spoofing risk; mitigated only if the
   edge strips `X-Remote-*`. Ship-time obligation, config-verified.
2. **Hostile `layout.tt` = code execution surface** - `EVAL_PERL=0` plus the
   manage_layouts capability boundary; a layouts partner is trusted by design.
3. **Secrets under the docroot** (HMAC secret, TOTP seeds, password hashes) -
   directory denial + mode; TOTP-at-rest is the known L2 gap.
4. **Partner write-boundary bypass** - capability map + per-file ACLs keep a
   token client off manager actions and others' files.
5. **CGI-fork DoS** - rate limiting + size/stream bounds today; a global
   concurrency cap and a capacity test are held pre-launch items.

## ASVS status (L1 baseline)

Met: session management (HMAC cookie, SameSite, HttpOnly, expiry), password
storage (salted sha256-iter, legacy auto-rehash), access control (groups-only
capabilities + per-file ACLs), input validation (path traversal, SSRF, header
injection, open redirect, upload validation - all in security.md), CSRF (HMAC
token on manager writes), security headers, logging.

Open (tracked): TOTP-seed at-rest encryption (L2); a documented pen-test
against this model (held pre-launch, review D6); a dependency CVE check (held,
review D6). See `docs/review/2026-07-01-eight-dimension/` and
`docs/review/2026-07-01-eight-dimension/90-prelaunch-operational-holds.md`.

## Significant-change assessments

The pentest gate (declared with a dated deferral waiver in
`docs/adr/0007-pentest-deferral.md`) fires ahead of schedule on significant
change unless a recorded assessment finds the change contained. This register
is that record - one dated entry per fired trigger, auditable per the
framework's letter. Verdict "accepted" means: contained, compensating
controls sufficient, no ahead-of-schedule engagement required. Entries for
changes shipped before this register existed are marked retrospective.

### 2026-07-10 (retrospective) - SM070/071/072: WebDAV, theme/layout management, self-service credentials

what changed
: the `/dav` endpoint (Basic over TLS), staged theme/layout authoring with a
  delegated sub-user model and pairing-key -> token lifecycle, claim links,
  TOTP MFA, account expiry - new external interfaces and new authentication
  methods (shipped pre-0.5.x; assessed retrospectively).

threat delta
: Spoofing, Tampering, Elevation of privilege, Information disclosure.

controls
: groups-only capability model (ADR 0001/0003), per-file ACLs, token `%need`
  map, `EVAL_PERL=0` on layouts, rate limits, single-use hashed claims; all
  folded into the STRIDE table above. Batch-1 hardening (bdb4c86): the six
  `:utf8` readers of `user-settings.json` re-paired to `:raw` so the account
  gates (disabled/expired/MFA) cannot fail open on non-ASCII bytes.

residual risk
: a layouts-capable partner is trusted by design; TOTP seeds at rest (L2 gap).

verdict
: accepted.

### 2026-07-10 (retrospective) - SM128: bad-URL auto-blocker (shipped 0.5.41, default on)

what changed
: a new enforcement surface with persistent blocking state on the anonymous
  request path - scanner-probe detection per source IP, 403 at threshold.

threat delta
: Denial of service (mitigation added, plus a new self-DoS surface),
  Tampering (the counter store).

controls
: keyed on `REMOTE_ADDR` only (not client-suppliable headers), list/unblock
  gated on `manage_config`, auto-blocks audited.

residual risk
: store fails open (corrupt counter file disables the blocker - consistent
  with the availability posture); behind a front proxy that leaves
  `REMOTE_ADDR` as the proxy address, a threshold hit blocks all visitors -
  deployment note for non-Hestia fronts.

verdict
: accepted.

### 2026-07-10 (retrospective) - SM136: notify-xmpp (shipped 0.6.2)

what changed
: XMPP notice delivery via `Net::XMPP` - a new dependency with authentication
  logic (the framework-named trigger, verbatim), a new outbound interface, and
  a new stored credential class (the per-site XMPP account password in
  `lazysite/notify-xmpp.conf`).

threat delta
: Information disclosure (credential at rest, notice content in transit),
  Spoofing (the XMPP account).

controls
: credential file WebDAV-denied and web-denied; password never shown back;
  TLS on by default with peer verification (`XML::Stream` 1.24); delivery
  lazy-loaded, best-effort, time-boxed (`alarm 15`); CR/LF stripped from
  notices. Batch-1 fix (bdb4c86): password-carrying extension configs are now
  chmod 0660 on save, and `notify-xmpp.conf` + `forms/smtp.conf` joined the
  `lazysite-check` secrets probe (world-access FAIL, `--fix` repairs).

residual risk
: authenticated outbound egress to the configured XMPP host; `Net::XMPP` in
  the SBOM/CVE surface (declared in `sbom-deps.json`).

verdict
: accepted.

### 2026-07-10 (retrospective) - SM137: SMTP password + staged validation (shipped 0.6.3–0.6.4)

what changed
: a stored SMTP password (new credential class) in `lazysite/forms/smtp.conf`,
  and a manager-driven staged connection check (DNS/TCP/TLS/auth) against the
  saved settings.

threat delta
: Information disclosure (credential at rest), Spoofing/SSRF-shaped probe
  (operator-driven TCP connect to an arbitrary configured host:port).

controls
: `smtp.conf` inside the 02770-checked `forms/` directory, WebDAV-denied by
  name, never returned to the UI; `resolve_password` shared by delivery and
  validation; the Validate action is cookie-only manager-gated, never sends
  mail, is time-boxed, probes plain-first; pinned by
  `t/unit/forms/05-smtp-validate.t`.

residual risk
: the SSRF-shaped validate primitive - acceptable at manager trust, recorded
  here.

verdict
: accepted.

### 2026-07-10 (retrospective) - SM140: first-party access log (shipped 0.6.8–0.6.9)

what changed
: a new data classification processed - visitor behavioural records, written
  anonymised to `lazysite/logs/access-YYYYMMDD.jsonl` and read by the
  analytics/export layer.

threat delta
: Information disclosure (visitor privacy), Repudiation (the log doubles as
  the availability record - see `docs/RELIABILITY.md`).

controls
: anonymise-at-write (keyed HMAC, daily-salted, truncated to 16 hex; the IP
  itself never written); log-injection defence (control chars stripped,
  length-capped, JSON-escaped); 90-day prune; `first_party: off` switch;
  recording can never break serving. Batch-1 fix (bdb4c86): the HMAC now
  keys on a persistent random salt (`lazysite/logs/.access-salt`, 0660),
  closing the empty-`.secret` brute-force corner on never-authed sites.

residual risk
: the anonymised log is group-readable on multi-user hosts (0664 under
  02775) - acceptable given anonymisation.

verdict
: accepted.

### 2026-07-10 - SM142: persistent runtime, dual-mode FastCGI accept loop (shipped 0.7.1)

what changed
: the processor gains a persistent execution mode - a long-lived worker
  servicing the anonymous request path from a FastCGI accept loop, prefork
  via `FCGI::ProcManager` - introducing the cross-request state-bleed risk
  class that per-request CGI made structurally impossible, plus two new
  (lazily required) dependencies.

threat delta
: Information disclosure / Tampering (request state leaking into a later
  request in the same worker), Denial of service (a wedged or leaking
  worker now affects subsequent requests).

controls
: per-request state reset shared by both paths (`handle_one_request`:
  `reset_request_state` + the die-guard; `local %ENV` isolates request
  environment); state isolation across consecutive requests pinned over the
  real FCGI protocol (`t/lib/MiniFcgi.pm`); worker recycling
  (`LAZYSITE_FCGI_MAX_REQUESTS`, default 500); an unhandled render error
  answers a clean 500 and the loop continues; plain-CGI invocation stays
  byte-identical. The auth wrapper is deliberately NOT pooled: the
  trust-header enforcement point keeps its per-request exec design, and in
  the shipped vhost template only cookie-less visitor traffic reaches the
  pool socket - the pool is anonymous by design.

residual risk
: `FCGI`/`FCGI::ProcManager` join the SBOM/CVE surface (declared in
  `sbom-deps.json`); a missed reset in future request-scoped state is the
  standing risk class - mitigated by the shared reset helper and the
  state-isolation test pattern, not eliminated.

verdict
: accepted.

### 2026-07-10 - SM139: packaged distribution - debs, host CLI, root-run integrator (shipped 0.7.2)

what changed
: a new distribution surface: `lazysite-common` + `lazysite-hestia` debs,
  the `lazysite` host CLI, a root-owned host registry and pool-config area
  under `/etc/lazysite/`, the root-started pool launcher
  (`lazysite-pool.pl` via the `lazysite@` systemd template unit), and
  `lazysite-hestia-domain` - a root-run-by-design panel integrator.

threat delta
: Elevation of privilege (root-run integrator; root-started launcher on the
  request path), Tampering (registry entries and pool configs as root-owned
  inputs to privileged code).

controls
: the SM139 principle enforced in code, not convention - `provision` and
  single-site `upgrade` refuse to run as root; `upgrade --all` drops to each
  site's owner via `sudo -n -u` per site; the pool launcher refuses
  `USER=root`, drops privileges before exec and verifies the drop stuck (no
  root remains in the request path); the integrator's root pass is bounded
  to domain layout/ownership, with every site-tree write behind
  `sudo -n -u <panel-user>`. Domain names are validated to the hostname
  alphabet before becoming file names, path components or unit instances;
  `--force-security` is honoured only when the payload manifest declares
  `"security_critical": true`. Invariants pinned by `t/tools/29-cli-fleet.t`
  and `t/tools/30-hestia-pkg.t` (incl. the FallbackResource-to-auth contract
  and the socket convention in the shipped templates).

residual risk
: the integrator and launcher run as root by design (bounded, reviewed
  paths); `/etc/lazysite/` is a root-owned admin surface - a compromised
  root already owns the host; correct `sudo` availability is a host
  dependency (`sudo -n` fails loudly, never prompts).

verdict
: accepted.

### 2026-07-10 - SM141: session registry + revocation (unreleased, on main)

what changed
: an auth-path change: the session cookie payload gains a random session id
  (`user:ts:sid:groups`), login writes an advisory session registry
  (`lazysite/auth/sessions.jsonl`), cookie verification gains a revocation
  check (`lazysite/auth/revoked.json`: sids + per-user `not_before`), and
  three new manager API actions (`sessions-list` / `session-revoke` /
  `user-revoke`) drive the new Sessions page.

threat delta
: Information disclosure (session metadata at rest: user, IP, sanitised UA),
  Tampering (two new files consumed by the auth path), Denial of service
  (a corrupt revocation file on every cookie check), Elevation of privilege
  (the revocation actions themselves).

controls
: signed cookies remain the sole source of authentication truth - the
  registry is advisory listing metadata, never consulted to authenticate;
  revocation is enforced at the single enforcement point (cookie
  verification in the auth wrapper; the processor keeps trusting only the
  wrapper's `X-Remote-*` headers); both files live in the web-denied,
  WebDAV-denied `lazysite/auth/`; the registry is loss-tolerant (a write
  failure never blocks login), UA-sanitised and 24-hour self-pruning; an
  absent `revoked.json` costs one stat and a corrupt one fails open with a
  loud WARN (no lockout, consistent with the availability posture); the
  actions are `manage_users`-gated, cookie-only (not in the token `%need`
  set), and revokes are audited with sid-prefix/username targets;
  `lazysite-check` probes both files alongside the secrets. Tests:
  `t/unit/auth/12-session-registry.t`, `t/unit/manager/24-sessions.t`.

residual risk
: fail-open on a corrupt `revoked.json` trades containment for availability
  (loudly logged); legacy pre-sid cookies cannot be listed or revoked
  individually - only per-user `not_before` or secret rotation reaches them,
  until they age out at 24 h.

verdict
: accepted.

### 2026-07-10 - SM085 phase 1: content history - git execution on the write path (unreleased, on main)

what changed
: an opt-in per-file version history: enabling (`git_history: enabled` +
  `git-init`) puts the docroot under git with the repository at
  `lazysite/git/`, and every content write (manager, WebDAV, MCP, uploads,
  nav/config saves, backup restores) invokes the `git` host binary to
  auto-commit. New attack surface: subprocess execution with
  attacker-influenced arguments (paths, commit messages, usernames) on
  every write; historic content exposure through the new `git-history` /
  `git-show` / `git-restore` actions; and a repository whose future remote
  sync (the git-sync extension follow-up) must never carry a secret.

threat delta
: Elevation of privilege / Tampering (command construction on the write
  path), Information disclosure (a leaked repo would expose the whole
  content history; history reads bypass "the file was edited since"),
  Denial of service (git failures on the save path).

controls
: every git invocation is LIST-FORM exec (`open '-|'` on an argument list -
  no shell anywhere; messages/paths/authors can never be interpreted);
  shas are validated against `/\A[0-9a-f]{7,40}\z/` and paths
  traversal-checked (no `..`/absolute/option-shaped segments) before any
  git call; the author string is stripped to a safe alphabet. GIT_DIR
  lives inside the protected `lazysite/` tree - no `.git` under a served
  path (and the processor/DAV deny lists refuse `/.git` anyway, defence in
  depth). The `info/exclude` written at init keeps secrets and personal
  data out of the history (`lazysite/auth/`, `lazysite/forms/`,
  `notify-xmpp.conf`, logs, the CSRF secret) - asserted literally in
  t/unit/lib/15-git.t and probed by a `lazysite-check` FAIL when
  `lazysite/auth` is not excluded. History reads run behind the same path
  validation, deny lists and per-file ACL read gate as `read`; restore
  routes through `action_save` (locks, ACLs, audit, cache invalidation) -
  no divergent write path. Token gating: reads/restore `manage_content`,
  init `manage_config`; restore and init are audited. All git work is
  eval-guarded: a git failure WARNs and the save proceeds (availability
  posture).

residual risk
: the repo doubles content at rest under `lazysite/git/` (0770, probed);
  a manage_content token may read any non-ACL-restricted file's history,
  which mirrors its live read grant; remote-sync risk is deferred to the
  git-sync extension's own assessment.

verdict
: accepted.

### 2026-07-10 - SM085 phase 1 (sync half): git-sync - egress to an operator-configured remote (unreleased, on main)

what changed
: the `git-sync` extension (opt-in) pushes/pulls the content history to a
  remote the OPERATOR configures, with a stored credential. New surface:
  outbound network connections from the site host to an
  operator-controlled address (git-over-https/ssh egress); a long-lived
  access token at rest in `lazysite/git-sync.conf`; a pull path that
  rewrites the worktree from remote-supplied content outside the normal
  save path; and a request-supplied action parameter (the
  keep_mine/take_theirs choice) reaching a child process.

threat delta
: Information disclosure (the token; the history leaving the host;
  SSRF-shaped abuse of the remote address), Tampering (remote-supplied
  content applied to the worktree; argument injection through the URL or
  branch), Repudiation (sync outcomes must be attributable).

controls
: remote address shape-validated before any git call - `https://host/path`
  (no userinfo), `git@host:path` or `ssh://` only; `javascript:`, `file:`,
  other schemes, option-shaped strings and shell metacharacters refused;
  branch name regex-validated. The token is never on a command line (no
  `ps` exposure), never in the stored remote URL or git config, and not in
  the askpass helper either: it travels in the process environment
  (same-uid visibility only) and git reads it via a transient 0700
  `GIT_ASKPASS` helper under the never-served `lazysite/git/`, removed
  after every action; `GIT_TERMINAL_PROMPT=0` + ssh BatchMode fail closed.
  `git-sync.conf` is 0660 (password-field rule) and on the never-versioned
  exclude list (init + self-heal before every sync + a `lazysite-check`
  SECURITY FAIL), so the pushed history cannot carry it - and the phase-1
  exclude list already keeps every other secret out of what egresses. The
  choice parameter is validated against the descriptor's declared ids in
  the manager AND re-validated in the extension; all git execution stays
  list-form via `Lazysite::Git::run_git`. Pull applies only fast-forwards
  or explicit `-X ours/theirs` merges, each behind a prerestore safety
  snapshot; a failed merge is aborted (worktree unchanged). Push never
  forces. Outcomes are audited (`extension-action git-sync (push|pull
  choice)`) and logged; raw git stderr goes to the server log, never to
  the operator response.

residual risk
: egress destination is operator-chosen by design (an operator could sync
  the content tree to any reachable git host - equivalent to their
  existing download rights); the token is recoverable by anything running
  as the site uid while an action runs; content pulled from the remote is
  trusted as operator content (same standing as a WebDAV write; the
  processor's normal escaping applies at render).

verdict
: accepted.

### 2026-07-18 - SM165: domain-owned access-control model (0.7.26)

what changed
: access confinement moved from a per-user/per-group `dav_scope` to a
  domain-owned model - each domain names `allowed_groups` (who may manage it)
  and `locked_users` (accounts confined to it), resolved through
  `Lazysite::Auth::DomainAccess` and the shared `resolve_user_scopes` (domain
  access intersected with the sub-user ceiling up the `created_by` chain). A
  new authorisation surface enforced on the manager UI, control-API token, MCP
  and WebDAV.

threat delta
: Elevation of privilege, Information disclosure.

controls
: a `DENY_ALL_SCOPE` sentinel so a locked user with no allowed domain is
  denied everywhere (never silently unconfined); scope intersection up the
  created_by chain so a sub-user can never out-reach its creator; enforcement
  code unchanged (only the SOURCE of `dav_scopes` moved). Verified by
  reproduction and `t/unit/lib/20-domain-access.t` (deny-all, empty allow-list,
  lock-narrowing, disjoint-intersection -> deny-all).

residual risk
: operators define the domain->group mapping; a misconfiguration is an
  operator error, not an engine bypass.

verdict
: accepted.

### 2026-07-18 - SM175: content history follows renames (0.7.26)

what changed
: git-backed content history now records renames as first-class moves (a
  `Lazysite-Renamed-From` commit trailer) and walks an incarnation-bounded
  lineage, so history follows a move but a delete truly ends the thread (a
  later file at the same path cannot inherit the deleted one's timeline). Adds
  `commit_move` on the git write path.

threat delta
: Information disclosure (history leakage across a delete/recreate).

controls
: the lineage walk follows explicit trailers (not git's `--follow` heuristic,
  which was shown to leak across delete/recreate) with a cycle guard and clean
  limit handling; the git write path keeps the existing `EVAL_PERL=0` /
  checked-write posture; the `18-git-guarantee` HOOK_RE covers `commit_move`.

residual risk
: none beyond the existing content-history trust model (an operator with
  content access already sees all versions).

verdict
: accepted.

### 2026-07-18 - SM179: multilingual language sets + engine i18n (0.7.27-0.7.28)

what changed
: a new content-partner-controllable input surface - a page's front-matter
  `lang:`, per-host `lang`/`lang_group` conf/`domain-set` keys, per-language
  content roots, `json:` content-root resolution, layout `strings/<lang>.json`,
  an engine i18n layer (`lazysite/i18n/<lang>.json`), and the `lang-status`
  control-API action.

threat delta
: Tampering (stored XSS / header injection), Information disclosure, path
  traversal.

controls
: `Lazysite::I18n` fails closed to English on any miss and never affects an
  auth decision; the i18n/lang file paths are lang-code validated (no
  traversal); `json:`/content-root resolution stays confined under the docroot
  (SM151); the 404 fallback HTML-escapes the request URI; `lang`/`lang_group`
  are validated at `domain-set`/`domain-add` and CR/LF-guarded (F6.11);
  `lang-status` is a read-only report gated on `manage_content`. FIXED during
  this assessment (F6.10, serious): the front-matter `lang:` flowed unescaped
  into `<html lang>` and `Content-Language` - now sanitised at the render point
  to a bare tag (`s/[^A-Za-z-]//g`), with regression test
  `t/integration/26-lang-injection.t`.

residual risk
: none identified after the F6.10 fix; the cross-host page cache is host-keyed
  (no cross-host poisoning).

verdict
: accepted (contingent on the F6.10 fix, which shipped in this cut).

### 2026-07-18 - raw/api script-capable content_type refusal (0.8.0)

what changed
: mechanical enforcement of ADR 0006. A `raw:`/`api:` page is served
  verbatim, with no layout and no output escaping, but a content author could
  set `content_type: text/html` (or `application/xhtml+xml`, `image/svg+xml`)
  and thereby have arbitrary page content executed as script in every
  visitor's browser - a stored-XSS vector that a `manage_content`-only
  delegate (who cannot author layouts) could reach. ADR 0006 had stated this
  was "enforced editorially, not mechanically"; a live-authoring review showed
  editorial-only is insufficient once content authorship is delegated.

threat delta
: Tampering (stored XSS) via the content-authoring surface, under the
  content/layout capability split (SM082).

controls
: at serve time (`peek_content_type`, the single content-type choke point for
  both the process and cache-serve paths) a raw/api page declaring a
  script-capable type is downgraded to `text/plain; charset=utf-8` and the
  attempt is logged (WARN). Combined with the `X-Content-Type-Options:
  nosniff` header the response already carries, the browser cannot execute or
  MIME-sniff the body back to HTML. Safe data artifacts (JSON, CSV, XML,
  plain text, images, PDF) are unaffected. Regression test
  `t/integration/27-raw-content-type.t`; authoring docs (raw-mode, frontmatter,
  ai-briefing-authoring) rewritten to use data examples and to state the
  refusal. Genuine HTML/SVG belongs in a layout (which escapes content) or a
  static file served by the web server.

residual risk
: none identified; HTML still reaches visitors only via a layout (escaped) or
  a web-server-served static file, neither of which passes through raw/api.

verdict
: accepted; closes the last serious finding from the 0.8.0 eight-dimension
  audit's security dimension (D6).

### 2026-07-19 - adversarial security-testing breadth pass (0.8.0)

what changed
: a breadth pass over the manager / MCP / control-API / WebDAV authorization
  surface before certifying the stable line. Motivated by the trust-gate gap
  (a sibling CGI consumed an identity header the processor gated) - the concern
  being that per-action negative tests leave structural gaps no single test
  guards. Two hardening fixes and a set of guarantee + negative tests.

threat delta
: Elevation of privilege (an ungated action, a channel-divergent capability
  gate, a write-guard bypass, a dropped dav_scope, a confused-deputy delegate,
  a crafted-backup auth overwrite), Tampering (path traversal), Denial of
  service (a fail-closed rate limiter).

controls
: fixes - backup restore now excludes `./lazysite` on extraction (a crafted
  content tarball cannot overwrite the auth/config namespace to escalate);
  `session-revoke`/`user-revoke`/`key-revoke` are forced to POST so the
  method-keyed CSRF gate covers them by construction. Structural guarantee
  tests (fail the build on drift): `14-capability-gate-guarantee` (token
  default-deny; every action classified/gated; cookie<->token capability
  parity), `15-write-guard-parity` (every write channel routes through the path
  guard), `16-scope-enforcement-guarantee` (dav_scope enforced on every
  channel). Negative tests: `40-subuser-escalation` (delegate confused-deputy
  confinement), `42-path-traversal-sweep` (every path-taking action), and
  `04-login-rate-failopen` (the rate limiter fails open, not closed). The
  existing trust-gate (`13`) and forged-identity (`39`) tests remain.

residual risk
: deferred as a 0.8.1 fast-follow (not gating this cut): a cross-site token
  parity test (tokens verify per-docroot, so cross-site is already structurally
  blocked) and an SSRF review of the `domain-check`/preview fetch paths. No
  open finding.

verdict
: accepted; the manager/API authorization surface now has structural backstops
  against the whole class the trust-gate gap belonged to.

### 2026-07-19 - 0.8.1 fast-follow: SSRF guard, tenant-token isolation, SM127 fix

what changed
: the two 0.8.1 items deferred above, plus a control-API/MCP regression the
  0.8.0 upgrade surfaced.

threat delta
: Server-Side Request Forgery (domain-check outbound probes), tenant
  cross-talk (a token used against another site), and an availability/usability
  regression on the token path (introspection + agent accounts wrongly refused).

controls
: (1) SSRF - `domain_check` (manage_domains) opens outbound TLS + HTTPS
  connections to a caller-influenced host. It now refuses the probes unless
  EVERY resolved address is public (`_ip_is_public`: blocks loopback, RFC1918,
  169.254/16 incl. the cloud metadata endpoint, CGNAT 100.64/10, IPv6
  ULA/link-local, v4-mapped equivalents, unspecified/reserved). Keying on the
  RESOLVED IPs closes the DNS-rebinding path and IP-literal/`localhost` hosts
  alike (both pass `_valid_host`). `domain-preview` shells the processor
  server-side and makes no outbound request. Test
  `t/unit/manager/44-domain-check-ssrf.t` (network-free via the resolve/tls/
  fetch hooks) asserts no connection is attempted for any internal range and
  that a public host is still probed. (2) Tenant isolation - a token is a
  credential in one site's per-docroot auth store, so it cannot authenticate
  against another site's docroot; pinned end-to-end by
  `t/unit/manager/45-cross-site-token.t`. (3) SM127 fix - see the commit; the
  manager-UI-remote gate now blocks only accounts that can ACTUALLY use the
  interactive UI (`manager_ui && ui`) and never blocks introspection, restoring
  the documented capability-based token contract for agent accounts.

residual risk
: none identified. The SSRF guard blocks by default; a self-hosted install
  whose legitimate domains resolve to RFC1918 would see domain-check refuse the
  reachability probes - acceptable (that deployment does not use public DNS/TLS
  checks), and revisitable behind a config opt-out if a real deployment needs it.

verdict
: accepted.

### 2026-08-11 - SM279: the retired group `dav_scope` is refused and reported

what changed
: the SM165 migration above moved confinement to the domain-owned model in
  0.7.26 and did not withdraw the mechanism it replaced. `group-set GROUP
  dav_scope PATH`, the per-account redirect that pointed at it, and
  `partner-create --scope` all kept accepting a value that
  `resolve_user_scopes` had stopped reading. Every release from 0.7.26 to
  0.10.6 stored those values and enforced none of them. The writers now
  refuse (clearing a stale value is still allowed), the dead resolvers
  `group_scopes` / `group_home_domain` and their module-free processor copies
  are deleted, and `lazysite-check` reports any group still carrying the field
  as a FAIL.

threat delta
: Elevation of privilege - specifically, a confinement an operator believes
  is in force and which is not. No enforcement path changed; nothing that was
  confined becomes unconfined.

controls
: refusal at the writer rather than a deprecation notice, so the false
  affordance cannot be exercised at all; `partner-create --scope` refused
  BEFORE the account is created, so a partner is never half-provisioned by a
  flag that would do nothing; the check reports and `--fix` deliberately does
  NOT clear, because the stale value is the only remaining evidence that
  somebody relied on it and clearing it would destroy that evidence while
  leaving the account unconfined. Verified by
  `t/unit/users/26-group-scope-retired.t`, every assertion confirmed failing
  against the pre-fix tools.

residual risk
: any site that set a group `dav_scope` between 0.7.26 and this release has an
  account that is not confined as intended, and this release detects that
  rather than repairing it - repair is an operator decision about which domain
  the group should own. `t/unit/manager/30-dav-scope.t` lost its
  `group_scopes` block: it had been testing dead code since 0.7.26 and reading
  as coverage.

verdict
: accepted.

### 2026-08-13 - SM286/SM293: protected content leaves the document root, and the front door

what changed
: two changes to the same question - where restricted content lives, and what
  decides whether a request reaches the engine. Both shipped in 0.10.7-0.10.8
  and both fire a trigger in `docs/adr/0007-pentest-deferral.md`.

  **New processing of restricted data (SM286).** Protecting a path now MOVES
  its content out of the served tree into a private store beside the docroot,
  `dirname(docroot)/basename(docroot)-lazysite-private`. Previously the content
  stayed in the document root and was protected by an access decision the
  engine made on request; now the engine is the only thing that can reach the
  bytes at all. The store is named for the docroot so two sites under one
  parent can never share one, and `Lazysite::Private` holds an invariant that
  content is in exactly one tree - the failure direction is "not moved", never
  "in both".

  **New external interface (SM293 step 5).** `lazysite-front.pl` is a new CGI
  surface. A front end is pointed at it and it makes every routing decision the
  vhost templates used to make - which URLs reach which surface, what is
  wrapped by the auth wrapper, what is refused outright - via the pure function
  `Lazysite::FrontDoor::route()`. SM293 steps 2-4 also allow the engine tree to
  move outside the docroot, generate the registries on request rather than from
  disk, and gate the trust headers in the application rather than relying on
  the front end to strip them.

threat delta
: Information disclosure, primarily, and in the reducing direction. The
  arrangement being removed is the one behind SM248, SM268 H17 and SM283: a
  front end serving a file the engine never sees, so no access rule the engine
  holds can apply. Moving the bytes out of the served tree makes that
  structurally impossible rather than configurationally avoidable. Elevation of
  privilege is unchanged - the ACL model, the capability model and the group
  resolution are untouched by both changes.

  The new surfaces this creates: a directory outside the docroot that the CGI
  identity must be able to create and write; and a single entry point whose
  routing table, if wrong, is wrong for every request rather than for one rule.

controls
: the store's location is derived, never configured, so it cannot be pointed
  somewhere unintended; `resolve_for_write` checks the public ancestor first so
  a store container cannot be mistaken for a gate; `lazysite check` reports
  whether the store exists and is writable, naming the directory, its owner and
  its mode, and speaks only on a site that actually protects something.
  `Lazysite::FrontDoor::route()` is a pure function with no I/O beyond
  existence tests, so the whole routing table is unit-tested directly
  (`t/unit/lib/21`) - which the vhost templates never could be - and driven
  through real Apache in `t/integration/49`. `t/lint/39` asserts the module and
  the shipped templates agree, so the migration cannot quietly change behaviour
  while claiming to preserve it. `t/lint/38` makes the trust-header gate an
  enforced application control rather than a front-end configuration
  requirement.

residual risk
: **A defect in the move path was live in 0.10.8 and is the reason this entry
  is not simply "accepted" (see the verdict).** `File::Path::make_path` croaks
  rather than returning false, so the guard following it was unreachable and a
  protect call died after storing the ACL and before moving the content or
  writing the audit line - leaving content stored-as-protected, still served,
  and absent from the trail. Filed as SM296, fixed on
  `claude/sm296-acl-set-crash`.

  Separately and by design: **every section protected BEFORE 0.10.8 stays in
  the document root** until its rule is re-applied, because the move happens on
  the act of protecting. Measured on an upgraded site, 19 of 25 extensions were
  still served byte-identically to an anonymous request. This is an operator
  action that no package upgrade delivers.

  The front door is CGI-only in 0.10.8; SM294 adds the pooled path and SM297
  records the auth-spine change that would remove the remaining fork.

verdict
: **accepted with a condition.** The architectural direction reduces the threat
  it addresses and is assessed as contained. The condition is SM296: until that
  fix ships and the affected sections are re-applied, a site that protected
  content on 0.10.8 may be in the state this change exists to prevent. Assessed
  as NOT requiring an ahead-of-schedule third-party engagement, because the
  defect is a local coding error with a known cause and a written fix rather
  than a weakness in the model - but the condition is recorded here so that
  judgement is auditable rather than implied.

### 2026-08-26 - SM570/SM578/SM577/SM593/SM589/SM592/SM618 (0.11.0): confinement stops being a property of how a partner was scoped, and two capabilities admit what they hand over

what changed
: The release assesses **twenty-five versions**, 0.10.10 to 0.11.0, because the
  register's previous entry stopped at 0.10.9 - that gap is itself recorded
  here rather than closed silently. Four changes move the security posture.
  **SM570**: the `acl-get`/`acl-set`/`acl-remove` trio was gated on
  `webdav || manage_content`, so a token holding neither - a zero-capability
  grant - reached them; it is `manage_content` alone now. **SM578/SM577**: the
  site-package verbs skipped their scope check entirely when a caller had no
  `dav_scope`, on the reading that no scope means unconfined. That is true of a
  cookie session and false of a token or MCP grant, so a partner holding
  `manage_domains` and no scope reached every domain's package on the instance
  - a package being a whole site. **SM593**: `manage_data` is an instance
  capability and a table's ACL path carried no domain component, so on a shared
  instance one client's grant read every other client's tables, and
  `Data::Access::may_read` returns true for a `manage_data` caller, so the ACL
  was bypassed rather than merely the listing. **SM589**: the capability floor
  returned `_script` and `config_file` - internal paths - to a caller holding
  nothing. **SM592**, found while writing coverage rather than by report: a
  cross-device collection MOVE out of an unwritable parent emptied the source
  and deleted the copy. **SM618** changes no behaviour and belongs here anyway:
  a capability-row campaign measured `audit` returning the WHOLE instance's
  trail - actor identities and raw source IPv4 addresses, including the
  operator's own manager, command-line and install sessions - under a partner
  token holding that one capability, and `manage_forms` returning live
  submission bodies (name, email, phone, message, submitter IP) under the grant
  an operator gives an agent to WIRE UP a form. Both titles described only the
  benign half. The operator's ruling is that both reaches STAND, `audit` on
  `purge`'s SM577 precedent; the titles now state them.

threat delta
: **Information disclosure moves most, and moves down.** Three separate routes
  by which one tenant of a shared instance reached another tenant's material -
  packages, data tables, and the ACL trio - are closed. **Elevation of
  privilege** is unchanged in mechanism but the capability model gained
  vocabulary: `manage_briefs`, `housekeeping` and `purge` as grants of their
  own, an exposure axis distinct from destructiveness, and groups that declare
  whether they are assignable. Each is a narrowing. **Loss of integrity**
  improves by one measured case (SM592). **Denial of service** is unchanged; no
  new long-lived execution path was added in this range. Against the movement
  down, SM618 records **no change in exposure and a change in what is known
  about it**: two capabilities disclose personal data to a partner token and
  always did. Nothing was closed, so nothing may be counted as closed - what
  changed is that an operator granting them can now read that fact before
  granting rather than after. A register that logged only the narrowings would
  make this release look better than it is.

controls
: Confinement is derived from the caller's own grant through one function per
  surface rather than per verb - SM578's field pass found two of four package
  verbs still carrying their own copy of the old test, which is why the four
  now ask one. The refusal for another domain's table is byte-identical to the
  refusal for a table that does not exist, so an instance cannot be enumerated
  by guessing names. `t/lint/87` requires the four surfaces to agree on every
  operation; `t/lint/86` refuses a channel used as an authority. For SM618 the
  DECLARATION is the control, because the reach is sanctioned: an instance-wide
  capability that says so is the model `purge` set, and `t/unit/manager/122`
  pins it for `audit` and `manage_forms` as `t/unit/manager/114` already did
  for `purge` - the three are coupled deliberately and change together.

residual risk
: **SM593's central guarantee is now field-verified, and this entry's previous
  text saying otherwise is superseded rather than deleted.** The operator issued
  a domain-scoped credential (`dav_scopes` = `sites/edge3`) on 2026-08-26 - the
  first non-`/` scope any measurement on this instance had held - and two
  throwaway tables identical but for their `domain:` field were read from it.
  The out-of-scope table was absent from the listing, and its refusal by name
  was word-for-word identical to the refusal for a table that does not exist,
  differing only in the echoed name. The property the controls paragraph claims
  from the source is therefore observed in behaviour: an instance cannot be
  enumerated by guessing table names. **A table
  naming no domain remains reachable by any `manage_data` holder** - deliberate,
  so an instance carrying live tables loses nothing on upgrade, and it means
  the protection is opt-in until an operator migrates. `lazysite-check` lists
  what is unmigrated. **The audit trail remains instance-wide and carries raw
  source IPs** - accepted, declared, and the largest single disclosure a
  one-capability partner token can obtain on this estate. It is recorded as
  residual rather than resolved because the declaration changed and the reach
  did not. **SM602** records that the full-system backup is written
  inside the docroot it backs up, so the declared RPO does not hold for
  docroot loss.

### 2026-08-14 - SM294/SM301 (0.10.9): a forked relay in the worker, and one more control-API action

what changed
: **SM294** lets the FastCGI pool worker be the site's front door. Requests it
  cannot answer as itself - another CGI surface, or anything needing the auth
  wrapper - are RELAYED to a forked child with the request body on a pipe.
  That is a new execution path inside a long-lived, privilege-dropped worker.
  **SM301** adds `regenerate-registries` to the control API; it clears
  generated registries and is the twin of an MCP tool that has existed since
  SM264.

threat delta
: Denial of service is the one that moves, and it moves in a direction worth
  naming: a worker blocked forever on a wedged child serves NOTHING else, so
  one hung request would take a site down. Elevation of privilege is unchanged
  - the child inherits the worker's already-dropped identity and the auth
  wrapper's contract is untouched, which is why SM297 (identity as a value) was
  deliberately NOT taken here. SM301 adds no new capability: the action is
  gated by `manage_content`, which the callers already hold on another channel.

controls
: a `RELAY_TIMEOUT` (120s, configurable) after which the child is TERMed then
  KILLed and the worker answers 504, so a wedged surface cannot take the site;
  `local $SIG{CHLD} = 'DEFAULT'` so FCGI::ProcManager's reaper cannot consume
  the exit status and leave `waitpid` blocking; `IO::Select` pumping both
  directions so a large body cannot deadlock against a large response; the
  relay target constrained to `lazysite-[a-z-]+\.pl` within a resolved cgi-bin,
  with an `-f` check, so no path outside it is reachable. Off entirely unless
  `FRONT_DOOR=1`. For SM301, the same implementation serves both channels so
  they cannot answer differently, and it is skip-listed from the audit
  alongside `cache-invalidate` - it removes generated artefacts and audits must
  not drown in operational noise.

residual risk
: the fork costs a process on relayed requests, which is the same cost those
  requests already pay under CGI - so a site with an ACL store pays it per
  static file (SM223 routes those through the wrapper). That is the measured
  argument for SM297 rather than a regression. The pooled front door is opt-in
  and unused by default, so the exposure of this path on the fleet is currently
  nil.

verdict
: accepted. No ahead-of-schedule third-party engagement required: the new path
  is a fork within an existing trust boundary, bounded by a timeout, and adds
  no new identity, capability or external interface.

### 2026-09-05 - SM666/SM755 (0.13.0-0.13.1): a scheduled actor without a request

what changed
: **SM666 phase 1** adds a per-site persistent runtime: a supervisor
  (`tools/lazysited.pl`, `lazysited@.service`) and under it a scheduler that
  runs engine maintenance on a clock - the statistics rollup and the expired
  session sweep in 0.13.1 - as a lazysite ACCOUNT, with no request behind it.
  It ships as an ADR 0009 extension, born disabled, where disabled means the
  process never starts. **SM755**, from the 0.13.1 eight-dimension review
  (`docs/review/0.13.1-daemon/`), corrected the supervisor's restart path
  before the service reached a host.

threat delta
: A new long-lived process, privilege-dropped like the pool, that acts
  WITHOUT a request - so the request-path controls (the two-signal trust gate,
  the `X-Remote-*` contract, per-request capability resolution) do not apply
  to it by construction and something else must. Elevation of privilege is the
  question that moves: a timer that can call anything is a second write plane
  wearing a clock. Denial of service moves too: a process restarted for ever
  is a fork every two seconds per misconfigured site, and two supervisors on
  one docroot would run the same jobs against the same files. No new external
  interface, no listener, no egress (phase 1 by decision), no new
  authentication method.

controls
: the identity gate fails closed in every direction - no account, a `system:`
  identity refused by name, an account lacking `run_jobs`, an account lacking
  the job's own capability (`analytics`, `manage_users`) - and a refusal does
  not consume the schedule slot. The job set is a closed table in engine code;
  `t/unit/daemon/02` writes a job into the daemon's config and asserts the set
  is unchanged. `needs` per job is read by `t/unit/daemon/05` from the manager
  API's own gate table, so a job cannot need less than the manager charges for
  the same work. Every subprocess is list-form; the actor travels in
  `LAZYSITE_ACTING_USER` as the API sends it. The privilege drop is the
  pool's, verbatim, with a check that both real and effective uid left 0, and
  root without `--user` is refused. SM755: exits counted with backoff and a
  ceiling (FAILED, once, with a state file), the enabled gate re-read every
  10 s so disabling the extension stops the runtime, one supervisor per docroot
  by advisory lock, an orphan adopted only with pid AND kernel start-time
  proof, a 30 s stop deadline then KILL, a torn run record logged. The unit
  carries the SEC-2026-07 sandbox set (`NoNewPrivileges`, `ProtectSystem=full`,
  `PrivateTmp`, `PrivateDevices`, `RestrictSUIDSGID`, `ProtectKernelTunables`,
  `ProtectControlGroups`). The sessions sweep REMOVES personal data (IP, UA on
  expired registry rows) on a clock; the run record carries counts, not
  contents.

residual risk
: the daemon has not yet run on a real host under the unit; the privilege
  drop is proved in its unprivileged branch and by the pool's precedent
  (`docs/review/0.13.1-daemon/dimension-5`, F5.8). `daemon_job_user` lets a
  `manage_config` holder point the scheduler at any existing `run_jobs`
  account, including a person's; the consequences are bounded by the closed
  job set, and the extension's config note says a purpose account is preferred
  and why. Memory at rest is ~10 MB PSS per instance, two processes; a
  300-site host pays ~3 GB.

verdict
: accepted. No ahead-of-schedule third-party engagement required: no new
  external interface, authentication method or dependency; the new actor acts
  through the existing capability model with a second gate in front of it.
  Trigger review at phase 2 (the local socket), which IS a new interface.

### 2026-10-06 - SM924/SM925/SM928/SM929/SM938 (0.15.2): submission content can leave the site, and three new actions reach it

Signed off by the release manager 2026-10-06, in their words: "notify - yes it
may via xmpp, as email does. it is likely more contained than email."

what changed
: **SM928**: a submission notice can carry the submitted fields - over XMPP and
  in the bell - when, and only when, the form says `notify: full`; on `on`, the
  default, the notice stays one line. **SM938 D4/D5**: two control-API/MCP
  actions and a manager page - `form-notify-save` / `set_form_notify` (writes a
  form's `notify:`, gated `manage_forms`) and `form-submission` /
  `read_form_submission` (reads one stored submission by store and row id, gated
  `read_submissions`), with `/manager/submission` showing it. **SM924**:
  deleting submissions over the API is a capability of its own,
  `delete_submissions`, off by default, with no MCP twin. **SM925 X2**: the XMPP
  endpoint is found from the domain's SRV record through `Net::DNS` - a new
  dependency, lazy-loaded only when the XMPP extension is enabled. **SM929**: the
  one reader that consulted `X-Forwarded-For` stops believing it.

threat delta
: Information disclosure is the question that moves: with `notify: full`,
  submitted personal data leaves the site to a third-party XMPP server and a
  phone, where before only the form's name did - new processing of restricted
  data, which is a named trigger. The new read action exposes nothing the
  submissions table did not, but it is an addressable URL carrying a store path
  and an id, so confinement has to hold for a crafted one. `delete_submissions`
  lets a token destroy personal data, which no token could before. `Net::DNS`
  is a dependency with no authentication logic and adds an outbound DNS query to
  the host's configured resolver. SM929 removes a spoofing path rather than
  adding one.

controls
: `notify: full` is per form and opt-in, set by a `manage_forms` holder; the
  shipped default is unchanged, so an upgrade emits nothing new. Fields in a
  notice are truncated, and the XMPP transport is TLS with peer verification by
  default (the SM136 entry). `form-submission` goes through the same
  `_submissions_path` confinement as the table - a store outside the configured
  submission directories is refused, which `t/unit/forms/34` asserts with a real
  file outside them - and the page renders values with `textContent` only.
  `delete_submissions` is held by no group after an upgrade, is named for what
  it permits (any submission on the site), and the manager's own delete is
  unchanged. Every new action is classified in the gate, audit and git
  guarantees (lints 14, 98; t/unit/lib/16, 18), and the MCP/API parity lint
  pins both twins.

residual risk
: a site that enables `notify: full` sends personal data to whoever operates
  its XMPP account - the same exposure an email handler has always had, over a
  transport that is encrypted by default. The form docs now say so (closed
  with this entry); nothing records the choice beyond the form's own conf. The SRV lookup trusts
  the resolver the host is configured with.

verdict
: accepted. The restricted-data trigger fired (SM928) and is contained: the data
  flow is the one email delivery of a submission has always been, by the release
  manager's ruling likely more contained than email, opt-in per form with an
  unchanged default and an encrypted transport. The new actions sit behind
  existing, narrower-than-admin capabilities with the table's confinement. No
  ahead-of-schedule third-party engagement required.

### 2026-10-20 - SM1042/SM1043 (0.15.5): a member changes their own password and sets up their own two-factor

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: **SM1043**: `/account`, a system page in the site's own layout (`account_page:
  disabled` withdraws it), and the `me-*` actions - a member reads and changes only
  their own account, ends their own sessions, and signs out everywhere. **SM1042**:
  a member enrols, confirms, disables and regenerates recovery codes for their own
  two-factor (`me-2fa-enrol`, `-confirm`, `-disable`, `me-recovery-codes`); manager
  enrolment is removed in the same release, so a manager can only reset a member's
  two-factor and never sees a secret or a recovery code. Ruled by the release manager
  2026-10-12 ("Self-enrol only"; "Accept, build phase 1").

threat delta
: A new interface that changes credentials, so Spoofing and Elevation of privilege
  are the questions: a stolen session that holds the password could swap the
  authenticator, and a manager door that enrols two-factor can read the secret.
  Repudiation moves too: a credential change needs an attributable record.

controls
: The actions are declared `self`, cookie-only and CSRF-gated; an access key or a
  token is refused. Each sensitive request re-authenticates with the current password
  and counts against the sign-in rate limiter, by address and by account (five in five
  minutes, "share the sign-in limit"); six guesses from six addresses close the
  account's bucket. `me-2fa-enrol` is refused while two-factor is on; disabling needs
  the password and a current code or one recovery code; a changed credential ends the
  account's other sessions (SM1040). A body naming another account changes nothing; another
  account's session id is indistinguishable from a made-up one. The audit trail records
  every change, wrong-password attempts included, and carries no password. The manager
  API refuses `mfa-enroll`, `-confirm`, `-recovery-regenerate`, `-verify` and
  `totp-code`, and the users tool refuses the enrolment verbs to any actor that is not
  the account. t/unit/account/01-05, sabotaged one control at a time.

residual risk
: The TOTP seed is still stored at rest (the L2 gap in the STRIDE table). The
  `me-sign-out-everywhere` action ends the current session too, as ruled.

verdict
: accepted, confirmed by the release manager on 2026-10-21. The new interface only reaches the caller's own account, behind
  re-authentication, the shared rate limit and an audit row; the manager lost a
  capability rather than gaining one. No ahead-of-schedule third-party engagement
  required.

### 2026-10-20 - SM1019/SM1020 (0.15.5): a notification rule over a form event

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: A `notify` handler type queues a rule over a form event, and the engine job
  `notify-outbox` sends each recipient once, by email and the per-member bell.
  Recipients may be addresses stored in a table, owners' accounts, fixed addresses or
  the submitter (ruled in SM1010, 2026-10-12). Authoring needs a new capability,
  `manage_notifications`.

threat delta
: Information disclosure: the event's visible fields reach recipients the submitter
  did not name, which is new processing of restricted data. Denial of service: a rule
  can mail many people.

controls
: `manage_notifications` is off by default, held by the manager groups only. The
  grammar is checked at save (every fixed address is exactly one address, SM1017; every
  table declared and every column present). The queue entry carries the event's
  visible fields, bounded, and never files. A quarantined submission queues nothing.
  Sending is once per recipient under a hashed ledger, capped per recipient
  (`per_recipient_hour`, default 3), leaves the actor out unless `notify_actor`, and
  writes one audit row per recipient; messages carry an unsubscribe link and a
  `List-Unsubscribe` header unless the rule turns it off. t/unit/notify/01-05.

residual risk
: The handler actions' door (`manage_forms`, `manage_data` or `manage_connectors`) is
  unchanged, so a group holding `manage_notifications` alone cannot reach the handler
  page; whether to widen it is an open question in the SM1019 filing.

verdict
: accepted, confirmed by the release manager on 2026-10-21. Recipients and their sources were ruled by the release manager;
  authoring is capability-gated and off by default; the data flow is the one a form
  mail handler has always had, with a per-recipient cap and an unsubscribe. No
  ahead-of-schedule third-party engagement required.

### 2026-10-20 - SM747 (0.15.5 onward): the Odoo extension

Assessment drafted by the developer agent; the release manager confirms.

what changed
: `extensions/odoo.pl` (born disabled) and the page endpoint `lazysite-odoo.pl`. A
  connection user (a site Odoo account, its key stored like a connector secret) runs
  named operations for pages, MCP and backend work; a public or scheduled binding may
  apply a write unattended when it declares `apply: immediate` (ruled Q1, 2026-10-12;
  an e-commerce basket becomes a quotation); a person may sign in to Odoo through a
  page and run `credential: session` bindings as themselves (slices B, C, D, 0.15.5);
  MCP uses the connection user or a per-grant account (slice E). Ruled X4: the
  extension's outbound HTTP is mode 2 inside SM579's policy.

threat delta
: Four of ADR 0007's triggers fire. A new external interface (an outbound connection
  to an ERP on the operator's URL, a page endpoint, MCP tools); a new authentication
  method (a person's own Odoo session, kept in a signed cookie); a new dependency with
  authentication logic (OOM, delivered as `libodoo-oom-perl` and vendored as a pinned
  snapshot for the tests, whose session transport takes the password); and new
  processing of restricted data (ERP records rendered into pages). Spoofing, Tampering,
  Elevation of privilege and Information disclosure are all in play: an anonymous
  write path into an ERP is the sharpest thing the extension adds.

controls
: The filing's engine controls on every public apply: the mode gate
  (`Lazysite::Egress::may_invoke`: who, the extension switch, OOM's presence and
  version, the connection); per-visitor and per-binding hourly caps taken before the call,
  where a count that cannot be taken refuses; a CSRF token bound to a 256-bit
  server-minted visitor key (`HttpOnly; SameSite=Strict`, signed); input checked against
  the operation's declared parameters, with `fixed:` and the visitor parameter
  unoverridable; a plan owned by the key or account that made it and confirmed only by
  it; an audit record naming a hash of the visitor key and the IP. Transport: `https://`
  to any host, `http://` to loopback only, no credentials in the URL; the key is a 0600
  file never returned or logged. The person's password is in one POST to OOM's session
  transport and in no URL, cookie, log or record; the cookies are signed under the
  extension's own secret, `lzs_odoo_session` is `HttpOnly; SameSite=Strict` and scoped to
  the endpoint, and the identity cookie authorises nothing. A session binding never
  falls back to the connection user. OOM's approval gate stays on. A page render never
  runs a write and never renders a visitor's binding. t/lint/240 keeps Odoo knowledge out
  of lazysite; every guard was broken on purpose and its test went red (t/unit/odoo/01-31).

residual risk
: The connection user's rights are set in Odoo by whoever administers Odoo; lazysite
  narrows nothing Odoo allows. No third-party test has covered the endpoint or its public
  write path. The binding and operation declarations are still read from OOM's registry
  in the request's process. Idle time-out for a person's Odoo session is not built.

verdict
: accepted, contingent on the first third-party engagement required by ADR 0007 before
  2026-12-31 taking the Odoo endpoint and its public write path in scope. The triggers
  fired and the engine controls are specific, tested and sabotaged. Accepted by the
  release manager on 2026-10-20 ("accept").

### 2026-10-20 - SM1160 (0.15.10): the person's Odoo login is the site sign-in

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: On a site that sets `odoo_site_signin: on` (default off), a successful Odoo sign-in
  (the password and, where Odoo asks, the authenticator code) is the site sign-in. The
  identity is `odoo:<login>`; no lazysite account is made. Ruled 2026-10-18; SM1157
  put Odoo's own two-factor code in the dialog.

threat delta
: A new authentication method. Spoofing and Elevation of privilege: a forged or stolen
  cookie, a forged header, a group mapping that grants manager rights, and a site
  session that outlives the Odoo session.

controls
: The session is the wrapper's own cookie and registry (`auth/sessions.jsonl`), so the
  one verifier chain every surface calls applies. The cookie's user field is
  `odoo=<login>` percent-encoded and its group field is empty and ignored (SEC-2026-07
  M5); the mapped groups are held in the server-side record, which is the authority: no
  record, or one for another user, is no session. A local account name cannot contain `=`
  or `:`, so `odoo:<login>` cannot be shadowed. `odoo_group_map` is asked of Odoo as the
  person (`core.has_groups`, no administrator right) and a target that carries any
  capability is refused at save and at load, by name. A record older than
  `odoo_identity_ttl` (default 900 s) grants nothing until `?csrf=1` asks Odoo once and
  renews it; sign-out ends both sessions and each ends the other. An unsecured site
  refuses the session. A forged `X-Remote-User: odoo:x` is stripped by the existing
  gates. Attempts share the site's limiter. t/unit/odoo/63, 64, sabotaged.

residual risk
: A site session keeps what it had for at most `odoo_identity_ttl` after Odoo changes
  (the operator-set bound the ruling asks for). A reader idle on one page past that is
  sent to the sign-in page by the next restricted link. The wrapper's own logout ends the
  site session and leaves the Odoo session cookie until the next `?csrf=1`. Idle time-out
  is not built, as ruled.

verdict
: accepted, confirmed by the release manager on 2026-10-21. The trigger fired and is contained: no capability can be reached
  through the door, the cookie carries no authority of its own, and the bound on a stale
  session is stated and operator-set. No ahead-of-schedule third-party engagement required
  beyond the one ADR 0007 already requires.

### 2026-10-20 - SM1164/SM1207 (0.15.10, 0.15.14): oomd, a resident OOM

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: With `odoo_daemon` set to `on` or `required` (default `off`), lazysited supervises one
  `oomd` per site and the Odoo extension sends its calls through it over a Unix socket,
  falling back to the in-process path on `on`. SM1207 verified that a pack's custom
  change applies through it. Sign-in, sign-out and the two-factor step stay in-process.

threat delta
: A new long-lived process and a new local interface (the 2026-09-05 entry marked a
  local socket as a new interface). Elevation of privilege: a process that acts without
  the request's gates; Information disclosure: a socket that carries the person's
  session id and a config that names key files.

controls
: Off by default; the supervisor lists oomd only while the Odoo extension is enabled, a
  connection loads, `odoo_daemon` is on and oomd is installed, re-read every 5 s, so with
  any gate closed no process exists. It runs as the user lazysited runs as (SM760). The
  config `lazysite/odoo/oomd.conf` is written 0600 through a temporary file under umask
  077, names credentials only as labels of key files and carries no key. The socket is
  `lazysite/run/oomd.sock` when that path is under 104 bytes, otherwise under
  `/tmp/oomd-<uid>/`, a directory the service creates 0700. The person's session id is in
  the request to the daemon and in no file (the test greps the whole site). The client
  is always `fallback => 0`; `required` refuses with `daemon-down`. A leftover oomd of the
  same socket is told to stop before a new one starts. t/unit/odoo/60-62, 79,
  t/unit/daemon/14.

residual risk
: Not yet exercised on a real host: the tests run the vendored `bin/oomd` against OOM's
  fake Odoo, not `/usr/bin/oomd`, a real Odoo's latency (D5) or the supervisor under
  `lazysited@<domain>` and systemd; the same-user arrangement is the supervisor's,
  unchanged.

verdict
: accepted, confirmed by the release manager on 2026-10-21. Opt-in, off by default, the same user and privilege drop as the
  scheduler, no key in any file it reads, and every gate closing stops it. Trigger review
  of the production unit when a host first runs it.

### 2026-10-20 - SM1129-SM1131, SM929, SM1189, SM1194, SM1196 (0.15.10-0.15.11): a proxy is believed only from its address

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: SM1129: `auth_proxy_trusted_from` (a CIDR list matched against the TCP peer,
  failing closed) gates the identity headers. SM1130: a proxy's user wins over a cookie.
  SM1131: one reader honours the configured header names everywhere. SM1189: an address
  rule of the wrong form or kind is named and denies. SM1194 and SM1196: the 0.15.10
  edge walk (F-6) found a pre-SM929 vhost passing the client's `X-Forwarded-For`
  through, so Hestia's template is refreshed on rollout and a pass-through vhost is a
  failure. `auth_proxy_trusted` was enabled on no site (release manager, 2026-10-17).
  SM1128's phases 2-3 (a native OIDC relying party, directory groups) have no code.

threat delta
: No trigger of ADR 0007's four fired: no new interface, method, dependency or data. The
  trust contract of an existing flag changed, which is a Spoofing question, and F-6 was a
  Spoofing finding: every address-keyed control (the sign-in rate limit, the bad-URL
  blocker, the form handler's limit, every address rule) took the visitor's word behind an
  old front end.

controls
: The identity headers are believed only from a listed peer and from any other are
  stripped as with the flag off; an empty or unparseable list believes nobody; the reader
  asks `proxy_identity` and a client can never make a configured name count; t/lint/267
  and 268 hold the arrangement. The rollout reports a pass-through vhost as a failure
  (exit 2) on every site not set to `trusted_proxies: none`, refreshes Hestia's copy of
  each template (keeping a `.bak-TIMESTAMP`), and names the domains to rebuild; `lazysite
  check` warns whenever the trust set is not empty. t/integration/263-265, t/tools/185,
  186, t/unit/lib/205.

residual risk
: A site behind an old front end is spoofable until its vhost is rebuilt from the
  refreshed template; the private-range default for `trusted_proxies` stays and only
  `none` trusts nothing. The `.deb` does not install the templates into Hestia's tree, so
  the copy after an upgrade is a documented step the domain tool checks.

verdict
: accepted, confirmed by the release manager on 2026-10-21. No trigger fired; recorded because identity and address trust
  changed. The F-6 exposure is closed by the rollout where the rollout is run. When SM1128
  phase 2 is built it fires the new-authentication-method trigger and, with its JWT
  verifier, the new-dependency one, and is assessed then.

### 2026-10-20 - SM1134 (SM1138-SM1141, 0.15.10): access limited by the visitor's address

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: Named allow and deny address lists in `lazysite/auth/address-lists.json`, applied to
  pages and folders (`addresses`, `addresses_deny` in front matter and `acls.json`), to
  groups (a group does not count from a refused address), and to sign-in (SM1159); a
  template test `visitor.in_list` that exposes membership only. Ruled in full 2026-10-17.

threat delta
: No trigger fired. Information disclosure and Elevation of privilege are the
  questions a new access rule raises: a rule that fails open, an inner rule that opens
  what an outer one limits, and a group's rights reaching an address the operator
  excluded.

controls
: One module answers (`Lazysite::Auth::AddressLists::decide`): deny wins; an unreadable
  store, an unparseable address and a wrong-kind name deny; a name the store does not
  hold in an allow slot admits nobody. Every layer that names a list must admit, so an
  inner rule cannot open an outer limit, and the address is asked before the who-may-read
  rule, so `auth: none` cannot lift it. Enforced in the processor, WebDAV, the manager
  API and MCP. A group dropped for an address loses its capabilities, page access and
  operator status and everything reached through it by nesting. The template test
  exposes no address, and a render that asked is never cached. A list a rule names cannot
  be deleted without `--force`. t/unit/auth/63-64, t/integration/266, 280, 281, 285.

residual risk
: A page limited only by its front matter binds where it is served; the manager's and
  WebDAV's file reads decide from `acls.json` alone, so the rule goes in `acls.json`
  (`acl-set`) to cover every door. The address is only as good as `trusted_proxies`
  (see the entry above). An IPv4-mapped address is an IPv6 address to the matcher. A
  layout changed from a shell, outside the engine, is seen only when something else
  stales the page.

verdict
: accepted, confirmed by the release manager on 2026-10-21. Nothing in it widens access; the failure direction of every
  fault is a refusal.

### 2026-10-20 - SM1181 (0.15.12): who a request is, decided once

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: On the one-rule pool a signed-in request is rendered in the pool worker with the
  identity as a value (`request_session`), where it used to cross two programs by
  identity headers; the manager API is one program; the dev server runs the four
  surfaces that verify their own caller direct. Ruled 2026-10-19 ("Yes, plan + review
  first"; "All as proposed"); the review ran before any code.

threat delta
: No trigger fired. Spoofing and Information disclosure are the questions: a long-lived
  worker that decides identity can hand one visitor's identity to the next, and a
  header or a FastCGI parameter must never be read as one.

controls
: The security review in the filing (T1-T14) names the threat, the protection and the
  test for each. In the pool the sentinel is never believed from the environment and a
  held value makes `apply_trust_gate` strip every identity and payment header; the value
  is cleared at both ends of a request and a die leaves nothing for the next
  (t/integration/290-297, two requests through one worker among them); `auth/.secret`
  is read per call and never cached; the front door runs the bad-URL guard on every
  request, closing T13; t/lint/38, 13, 267, 268 and 269 are extended, not relaxed.

residual risk
: The split FastCGI templates keep signed-in requests on the CGI wrapper by decision
  (R8), so they gain nothing and lose nothing. MCP, DAV, OAuth and the wrapper's own
  actions keep their own credentials and are not moved.

verdict
: accepted, confirmed by the release manager on 2026-10-21. No new interface, method, dependency or data; the review preceded
  the code and every threat has a test that was broken on purpose.

### 2026-10-20 - SM1213 (0.15.15): an empty front-matter key reads as empty

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21.

what changed
: The page front matter's scalar reader ran over the newline after an empty key, so
  `title:` took the next line and that key was lost. The same readers in the renderer,
  the manager's `page_form` and `raw_html_page_refusal` now read a value from its own
  line, and the ADR 0006 downgrade reads `api:` and `raw:` as the render does.

threat delta
: Tampering. No gated page opened: every reader that decides who gets a page reads the
  front matter line by line (t/integration/305, before and after). The reader did let a
  raw page be served as `text/html` past the downgrade in four spellings (`api:` above
  `true`, `api: "true"`, `raw: 'true'`, a quoted `"text/html"`), each measured before the
  fix. A Markdown page's `<script>` already reaches the browser through the layout; the
  bypass added a whole response with no layout around it.

controls
: One reading of the keys in the renderer, the manager and the downgrade's peek. The
  downgrade stays the mechanical enforcement of ADR 0006 recorded in the 2026-07-18
  entry above.

residual risk
: None identified beyond the 2026-07-18 entry's.

verdict
: accepted, confirmed by the release manager on 2026-10-21. No trigger fired; recorded because it closed a bypass of a boundary
  this register names.

### 2026-10-20 - SM1219, SM1118 (held for 0.16.1; not in the 0.16.0 stable): the visitor log's accounts and the maintenance capability

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-21 ("Confirm now"). Both are
shipped on held branches (n705, n706), written here ahead of their release so the entry
exists when they land. They are in 0.16.1 if they land, and not in the 0.16.0
stable.

what changed
: **SM1219** (ruled #339, 2026-10-20): the access record gains `u`, the account the engine
  verified, read with the `analytics` capability, a domain-confined caller seeing only its
  own domains' accounts, kept as long as the rest of the log, shown per account in the
  manager. **SM1118** (ruled #338, 2026-10-20): a switch sends page requests by 302 to a
  page that answers 503; the new capability `maintenance_access`, held by the operator
  group and assignable, gets through; MCP, the control API, WebDAV, the data endpoint and
  posted forms follow the same capability.

threat delta
: SM1219 fires new-processing-of-restricted-data: account names in a log are personal
  data. SM1118 fires none: it adds a capability and a way to refuse requests.

controls
: SM1219 reads the account from the one identity reader at the end of the request, only
  for source `cookie` (including the pool's held value) or `proxy`, never the raw
  `X-Remote-User`, so a forged header records nobody; the default analytics reply carries
  no account name; the capability text now says visits per signed-in account are shown to
  it. SM1118 sits in the processor's `main()`, so it holds on CGI, the split templates and
  the pool; a switch-on needs the capability on the account doing it (no self-lockout); a
  form posted during maintenance stores nothing. t/integration/310-312, 315-320.

residual risk
: SM1219: per-account figures are read from the raw log, so they reach back
  `retention_days`, and telling the people who sign in is the operator's duty (SM1010
  principle). SM1118: a file the web server serves by name never reaches the engine and is
  not redirected; the OAuth and Odoo endpoints are not gated; a site with no accounts is
  closed to everyone while the switch is on.

verdict
: accepted, confirmed by the release manager on 2026-10-21 ("Confirm now"). Both remain held for 0.16.1 and are not in the 0.16.0 code.

landed
: Both landed on main after the 0.16.0 stable and are in 0.16.1, as assessed above (walk
  of 2026-10-23, SM1269). Since the entry, SM1241 adopts every shipped bundle on an
  existing site, which is how `cap-maintenance` reaches one; see the 2026-10-23 entry for
  the bundle record (SM1262).

### 2026-10-21 - SM975, SM976, SM979-SM982, SM991-SM993, SM1057, SM1092 (0.15.3-0.15.7), SM1234 (0.15.16): gate-tightening fixes and a release with no code change

Decision of the release manager, 2026-10-21, at the 0.16.0 stable sign-off.

what changed
: The fixes in 0.15.3 to 0.15.7 that tightened existing gates (SM975, SM976,
  SM979-SM982, SM991-SM993, SM1057, SM1092, the set listed in
  `docs/compliance/OBLIGATIONS.md` under "Walked for 0.16.0"). 0.15.16 (SM1234)
  carries no code change.

threat delta
: None. Each narrowed a gate that already existed and added no interface, method,
  dependency or data.

controls
: The existing gates, narrowed; nothing new was added to control.

residual risk
: None identified beyond the entries above.

verdict
: accepted. No trigger fired for the 0.15.3-0.15.7 fixes, and none fires for 0.15.16,
  which has no code change. Decision of the release manager, 2026-10-21.

### 2026-10-23 - SM1226 (0.16.1): the Odoo endpoint runs warm-forked

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-23.

what changed
: On a site with a pool conf and the Odoo extension on (never on a plain-CGI site),
  lazysited supervises an `odoo-endpoint` service: a parent that has compiled
  `lazysite-odoo.pl` and the `Lazysite::` modules it names, listens on
  `lazysite/run/odoo-endpoint.sock` (0600, in the site's 0700 `lazysite/run/`) and forks
  a fresh child per request, which runs the endpoint as the CGI does and exits. The
  one-rule pool hands it the endpoint's requests, and the split FastCGI templates (nginx
  and Apache `vhost-fcgi`, Hestia's fcgi templates) send `/cgi-bin/lazysite-odoo.pl` to
  the pool. With no parent listening the pool runs the CGI.

threat delta
: A new long-lived process and a new local interface, the oomd entry's shape: the
  new-external-interface trigger fires in the sense the 2026-09-05 entry gave a local
  socket. Information disclosure and Spoofing are the questions: a parent that held a
  key or a visitor's request would hand it to every child, a forged identity could
  enter a child by its parameters, and a request could reach a child no gate saw.

controls
: The filing's W1-W7, each with its test. The parent requires code and runs none of it,
  reads no configuration or key and never reads a request (t/lint/272; t/integration/325
  reads its memory after signed-in requests and finds no session secret, connection key,
  cookie signature, token or visitor parameter). A fresh child per request, which exits;
  `srand` in the child. The child's environment is the parameters less the sentinel,
  sid, flag and every trust header, and the endpoint verifies the cookie itself, so a
  forged `X-Remote-User` is nobody (t/unit/daemon/15, t/integration/325). The program
  starts by exec, never as a fork of the supervisor, so it holds nothing the supervisor
  read; it exits when its code changes on disk or it is re-parented, and removes its
  socket. The web server reaches only the pool's socket, so the parent's socket stays the
  request-path user's (SM760). A request the parent has taken is never re-run.

residual risk
: Every gate of the endpoint is the CGI's own and runs in the child, unchanged; what is
  new is the process, which the tests hold to holding nothing. A site on a pre-SM1226
  split template keeps a parent nobody calls until its vhost is regenerated. Not yet run
  under `lazysited@<domain>` and systemd on a production host.

verdict
: accepted, confirmed by the release manager on 2026-10-23. The trigger fires on a local socket and is contained: the
  socket is the request-path user's alone, the parent holds compiled code and nothing a
  request or a configuration carries, and the endpoint's own gates run unchanged in each
  child. No ahead-of-schedule third-party engagement beyond the one ADR 0007 already
  requires, which takes the Odoo endpoint in scope (the SM747 entry).

### 2026-10-23 - SM1257, SM1242, SM1258 (0.16.1): a page's stem rule moves and goes with the page

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-23.

what changed
: A rule set on `/about` is stored as `about` and governs `about.md` (SM268 H14). Every
  mover re-keyed only the page's own key, so a moved page left its draft rule behind,
  was served to anyone at its new path, and the store sync put its bytes back in the
  document root, where a front end serves them too (SM1257). Deleting a page left the
  stem rule for the next page written there (SM1242, SM1258 for WebDAV DELETE). One
  shared function, `Lazysite::Auth::Acl::fold_page_stem`, now folds the stem rule into
  the page's key before the manager's move, MCP `move_file` and `rename_page`, the
  control API's move and WebDAV MOVE, and drops it on every delete, while no folder of
  that name exists. SM1242 also makes `set_permissions` report what the rules decide
  after the save (`draft_note` for a draft), rather than only the page's own record.

threat delta
: Information disclosure. A held-back page was published by an ordinary move, and its
  bytes crossed the served-tree boundary (boundary 6) back into the document root. No
  trigger of ADR 0007's four fired: no interface, method, dependency or data was added.

controls
: One function behind every mover and deleter, so the surfaces cannot answer
  differently; a stem key that is a folder's rule is left alone; folding takes the
  stem's value only for a mode the page's own key does not carry, so no rule is widened.
  t/unit/manager/160 and t/unit/dav/34 each fail with the change reverted: the page is
  published and its bytes land in the document root.

residual risk
: A page moved by a shell, outside the engine, is not seen. A page drafted through its
  stem and moved before 0.16.1 was published at its new path and stays published: no
  rule follows it, so neither the upgrade nor the SM1238 dry run names it, and the rule
  left at its old stem holds back only a page written there later.

verdict
: accepted, confirmed by the release manager on 2026-10-23. No trigger fired; recorded because it closed a bypass of a
  boundary this register names, as the SM1213 entry was. The remediation record ADR 0007
  asks for stays for the certified release (`docs/compliance/OBLIGATIONS.md`).

### 2026-10-23 - SM1223-SM1225, SM1244, SM1247, SM1248, SM1261 (0.16.1): the Odoo extension's options and OOM 0.42

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-23.

what changed
: SM1223: a page's `Idempotency-Key` (8 to 128 characters) is hashed with the binding and
  the caller into OOM's `idem`, so a repeat answers the first plan or result. SM1224: a
  rows key an operation declares with its own `max` (up to 1,048,576) is capped there; a
  JSON body over 64 KB names its binding and is held to that binding's budget (20 MB at
  most). SM1225: a binding with `answer: download` answers a GET with the document its
  report holds, `Cache-Control: private, no-store`, capped by `download_max_kb` (default
  10 MB) and refused over it. SM1244: `lazysite check` warns below OOM 0.38, which can
  resend a write whose answer timed out. SM1247: the vendored test snapshot moves from
  OOM 0.38 to 0.42; SM1248 adopts oomd's config `namespaces` and its `reload` verb, so a
  pack change no longer restarts oomd. SM1261: a confirm whose daemon run is gone answers
  `not-found`, naming no path.

threat delta
: No trigger fired. OOM is the SM747 entry's dependency at a newer version, reached
  through the same interfaces; the `reload` verb is a request on oomd's existing socket;
  a report is ERP data the extension already processes, answered as a file rather than as
  JSON. Denial of service (a larger declared value), Spoofing (a key that replays another
  caller's write) and Information disclosure (a cached or oversized document) are the
  questions.

controls
: The idempotency key is hashed with the binding and who sent it, so nobody collides
  with or replays another person. A declared `max` raises only that key's cap, and the
  body is held to its binding's budget. A download runs the binding's gate, callers, rate
  caps and both paths unchanged, carries a safe file name and `no-store`, and is refused
  over its cap, never cut short. Each change of OOM 0.39 to 0.42 was checked against
  lazysite (SM1247), and every Odoo test passes on the new snapshot unchanged (t/lint/207,
  261). The OOM version warning names the file the site loads.

residual risk
: An operator who raises `download_max_kb` or declares a large `max` raises what one
  call may cost. A host still on OOM 0.37 or earlier can make a write twice until it is
  upgraded; the check says so and does not refuse.

verdict
: accepted, confirmed by the release manager on 2026-10-23. No trigger fired; recorded because the extension's inputs, outputs
  and dependency version moved.

### 2026-10-23 - SM1233 (0.16.1): a Docker Compose package

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-23.

what changed
: `installers/docker/` ships in the tarball: one container running nginx, the one-rule
  FastCGI pool and lazysited, the engine in the image and the site in three volumes (the
  docroot, `lazysite/`, the private store), built locally from the unpacked release with
  `docker compose build`. No registry image and no Odoo. The first start runs `install.pl`
  into the empty volumes; the first account is `setup-sysop`.

threat delta
: A new product form, the SM139 entry's question in a container. No trigger fired: the
  container serves the engine's existing HTTP surface through the shipped one-rule
  template, adds no authentication method, and carries the debs' own dependencies.
  Elevation of privilege and Information disclosure are the questions: what the
  container runs as, what it publishes, and whether the private store stays outside the
  served tree.

controls
: The processes run as `www-data`; compose drops all capabilities and publishes the port
  on loopback by default. The vhost is made by `sed` from
  `installers/nginx/vhost-one-rule-pool.conf.example`, so the rule (with its trust-header
  blanking) is written in one place. The private store is its own volume, the docroot's
  sibling, where `install.pl` and the engine put it. Every install path is `install.pl`.
  t/tools/210 holds the compose file, the Dockerfile's `sed` on the real template and the
  entrypoint's decisions.

residual risk
: The container serves plain HTTP on 8080; TLS is the front end's, and so is HSTS (sent
  only over TLS). Built and run once by hand; the test runs without Docker. An operator
  who publishes the port beyond loopback without a TLS front end serves sign-in in clear.

verdict
: accepted, confirmed by the release manager on 2026-10-23. No trigger fired; recorded because it is a new way the product is
  distributed and run.

### 2026-10-23 - SM1240, SM1241, SM1262, SM1263, SM1266, SM1221, SM1235-SM1239, SM1249, SM1265, SM1256, SM1259, SM1260 (0.16.1): access, rollout and channel changes with no trigger

Assessment drafted by the developer agent; confirmed by the release manager on 2026-10-23.

what changed
: SM1240: the sign-in rate counter `auth/.login-rate.db` is created 0660 in the auth
  directory's group under any umask (two sites had it owned by the site user, so the
  www-data CGI could not open it and allowed every attempt). SM1241: every shipped bundle
  is adopted on an existing site, only when absent, only for the shipped roles present,
  never rewriting an edited group; SM1262 records the bundles a site has had in
  `auth/bundles-adopted.json`, so a deleted bundle stays deleted and an unreadable record
  adopts nothing. SM1263: MCP `remove_permissions`, the twin of `acl-remove`, under
  `manage_content` with the owner refusal and the `acl-remove` audit action. SM1266: a
  page may ask `<feature>: self` for any feature Permissions-Policy denies, as SM1174
  allowed the camera. SM1221: a signed-out manager API call answers 401. SM1235-SM1239,
  SM1249, SM1265: the Hestia rollout reports and repairs (the ACL dry run as the site's
  own user, `--rebuild-exposed`, a root `--fix` creating an empty private store in SM313's
  shape, 2770). SM1256, SM1259, SM1260: the certified channel is accepted where ADR 0010
  says it is.

threat delta
: None of ADR 0007's four triggers fired. SM1240 closed a sign-in limiter that had failed
  open (Denial of service, against guessing). SM1241 grants capabilities on upgrade, an
  Elevation of privilege question. SM1266 loosens a security header for one page, an
  Information disclosure question (a camera, microphone or location reaching the page's
  script). SM1263 is one more tool on an existing capability, as SM301 was one more
  action.

controls
: SM1240: the limiter still fails open when it cannot open the counter (SM798), and the
  auth log says so on each attempt and `lazysite check` reports it; a counter the process owns that lost group access gets it
  back. SM1241: only the shipped nesting, only to shipped roles a site already has, only
  on a site that has the bundle layer; SM1262's record is fail-closed. SM1263: the same
  function as the control API, so the same gate, refusal and audit. SM1266: the value
  `self` and nothing else, front matter only, honoured over https only, that page alone;
  `payment` and `browsing-topics` cannot be asked for; a page that asks for nothing sends
  the header it sent before; the validator reports an unknown or unreadable value. The
  rollout changes run in the root-run integrator SM139 bounded, and a site-tree write
  stays the site user's.

residual risk
: SM1266: an author who can save a page can give that page's scripts a device feature;
  the site-level allow list is later. SM1241: the shipped roles an existing site has
  gain the shipped bundles' capabilities on upgrade, as a new install's have them.

verdict
: accepted, confirmed by the release manager on 2026-10-23. No trigger fired; recorded because access, a sign-in control and a
  security header moved.

### 2026-10-23 - SM1303 (0.16.2): a theme archive's symbolic link reached the served asset mirror

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-05 (ruling 65). Ruling 41 as revised (2026-10-23): with the exposure able to disclose the session-signing secret, so that a `manage_themes` holder could forge an operator's session, this is a security release. Ruling 41b: the archive checks and the planted-link warning (SM1304) land alone on main and are cut as 0.16.2, marked `security_critical` (`tools/release.sh --security-critical`, SM1305) and pushed fleet-wide with `lazysite upgrade --all --force-security`, which reaches stable sites too (on a Hestia host, the updater's `--force-security`, SM1307). Ruling 44 (2026-10-23): no exploitation of SM1303 is known, so there is no CRA Article 14 notification and no advisory; the release notes carry it.

what changed
: The manager's Upload Theme (`theme-upload`, `Manager::Themes::action_theme_upload`)
  extracted a theme zip and copied it, with `cp -r`, under each layout and its `assets/`
  folder into `/lazysite-assets/LAYOUT/THEME/` in the document root. A zip member that
  is a symbolic link (what `zip --symlinks` writes) was extracted as a link and copied
  into the mirror as one, so a public URL under `/lazysite-assets/` named any file the
  link pointed at. Shown, not assumed: with the old code t/integration/336's archive left
  `lazysite-assets/default/linky/passwd` pointing at `/etc/passwd`. Every entry is now
  checked before any is extracted, and a symbolic link refuses the whole archive
  (`blocked`). The same function also applies the site's upload limit and refuses a file
  type the web server runs (`@DANGEROUS_EXT`), as WebDAV and MCP `upload_file` already
  did under a theme. `lazysite check` warns for every symbolic link under
  `lazysite-assets/`, naming it and its target, and never removes one (SM1304).

affected versions
: Every release, 0.1.0 (2026-04-21) to 0.16.1. The upload has copied with `cp -r`
  since the manager's first theme support (2026-04-18), extracting with `unzip` and,
  from the D017 remediation before 0.1.0 was tagged, Archive::Zip; both extract links.
  The fix is in 0.16.2.

who could do it
: A signed-in manager holding `manage_themes`, the capability the action has needed
  since SEC-2026-07 (0.7.19). Before 0.7.19 the cookie path was not capability-gated,
  so any signed-in manager account. Not reachable with a token (the action is
  cookie-only) or anonymously - though once a link was planted, anyone could fetch what
  it pointed at.

threat delta
: Information disclosure, and through it elevation of privilege. Whatever the web
  server's user can read, served to anyone at a public URL, where the front end follows
  symbolic links (Apache with `FollowSymLinks`, nginx by default). On a lazysite host
  that includes the engine tree beside or inside the docroot - `lazysite/auth/` is
  group-readable by the web user, so the auth secret `lazysite/auth/.secret`, the
  account and group stores - and the site's configuration, its form submissions and any
  file of the host the web user may read. A session cookie is an HMAC under that
  secret, so whoever read it could mint a session for any account, the operator's
  included. The holder of `manage_themes` is trusted with how every page looks, not
  with those files or that account, so this crossed the served-tree boundary
  (boundary 6) from inside. No trigger of ADR 0007's four fired: no interface, method,
  dependency or data was added by the fix.

controls
: The member check runs before extraction (`isSymbolicLink`, then `@DANGEROUS_EXT`),
  so nothing reaches the staging directory or the mirror. t/integration/336 drives the
  manager's own upload as a signed-in person and fails with the change reverted (the
  link is in the mirror). t/tools/290 holds the check to naming every link, with its
  target and the remedy, to removing none, and `lazysite repair` to counting such a
  site as needing a human.

residual risk
: A link already planted by an upload before 0.16.2 stays in the mirror until an
  operator removes it; the upgrade's own health check names it (SM1304, ruling 42), and
  ruling 43 takes no host-wide sweep before the release. A secret it may have served
  stays valid until rotated: the manager's Sessions page, "Log out all users"
  (`rotate-auth-secret`), writes a new one and ends every session and preview cookie.

verdict
: accepted, confirmed by the release manager on 2026-11-05. Recorded because it closed a
  bypass of a boundary this register names, as the SM1213 and SM1257 entries were. The
  remediation record ADR 0007 asks for stays for the certified release
  (`docs/compliance/OBLIGATIONS.md`).

### 2026-11-04 - SM1308, SM1309, SM1311-SM1313 (0.16.3): a confined agent reached outside its scope, and a member could widen an area's rule

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-05 (ruling 65). Ruling 94 (2026-11-05): no exploitation of SM1308 or SM1309 is known, so there is no CRA Article 14 notification and no advisory; the 0.16.3 release notes carry what was exposed and what to do. Both were reported on 2026-10-27 by a site building a protected, agent-first intranet (gaps G3 and G4), verified against the source in the inbox triage of 2026-11-04 (T-01, T-02), and ruled on the same day (rulings 47 and 46): both are fixed in 0.16.3, the edge batch, with this entry. No exploitation outside the reporter's own test site is known. 0.16.3 is cut as an edge release, not marked security-critical, so the fixes reach each site by its own update channel.

what changed
: SM1308 (T-01). MCP's scope pass checks each path argument a tool declares and skips
  one that is absent or empty, so a grant confined to a scope, refused `/` when it named
  it, was answered from the whole document root when it named nothing: `list_files`
  defaulted to `/`, `search_files` walked the docroot, `list_pages` (which takes no path)
  walked it too, as did `delete_page`'s reference list and `rename_page`'s link rewrite,
  which saved pages outside the scope. The manager API's `pages` took no path, and its
  `list` with an empty path listed the docroot. And `search_files` quoted lines of any file
  it walked, with no per-file rule asked, where `read_file` refuses a file whose read list
  or address rule the caller does not pass. Shown, not assumed: the reporter's agent found
  a line of a page outside its area and was listed 108 site pages, and with the fix
  reverted t/unit/mcp/65 and t/unit/manager/415 reproduce each. A confined grant's missing
  or empty path is now its scope roots, every one of those walks starts there, and the
  search asks each file read_file's question (`_acl_denied`) before it quotes it.
  Rulings 59 and 60 close the two walks left: `audit_site` audits a confined grant's scope
  and lists a link outside it as outside the scope, never as broken (SM1311), and
  `list_pages` asks a page's rule before it lists the title (SM1312).
: SM1309 (T-02). A mode's list is decided by the longest match, so a rule on a subfolder
  replaces the enclosing rule there rather than narrowing it, and anyone with write access
  to a path may write its first rule. A member of a protected area, or the member's agent,
  therefore opened a subfolder to a non-member with one `set_permissions` call, and the
  non-member read its pages (the reporter measured 403, then 200). Longest match stays, so
  an operator can still carve a wider audience out of a private site (SM287, SM223).
  Writing a rule that admits, to read or to write, anyone the enclosing rule does not is
  now refused unless the operator or the enclosing rule's owner writes it, naming the
  enclosing rule; a move that would carry such a rule inside the area is refused the same
  way, since a move carries the rules under it to the target (within ruling 46, ruling
  64). `lazysite check` names each stored rule of that kind for the operator to review,
  and changes nothing (SM1313, ruling 61).

affected versions
: SM1308: 0.7.19 (2026-07-16), when MCP and the control API began confining a partner to
  its scope (SEC-2026-07 M2, SM155), to 0.16.2. Before 0.7.19 nothing confined a partner,
  so there was no scope to reach outside. The search's missing per-file check is older:
  `search_files` shipped in 0.4.11 (2026-06-25) and has quoted files under a read rule
  since then. From 0.10.8 (SM286) such a file is moved out of the document root, so after
  that it is reached only where content stayed in the docroot: a section protected before
  0.10.8 and not re-applied, or a rule carrying only address lists (SM1134, 0.15.10),
  which moves nothing.
: SM1309: 0.10.5 (2026-08-09), when a folder rule began to govern its section by longest
  match (SM181, SM223; on the manager, MCP and WebDAV from SM268 H3 in the same release),
  to 0.16.2. The move route is from 0.10.19 on WebDAV (CF-2) and 0.10.32 on the manager
  (SM518), inside that range.
: Both are fixed in 0.16.3.

who could do it
: SM1308: an MCP grant holding `mcp` and `manage_content` and confined to a scope (a token
  or OAuth partner whose account's group a domain names in `allowed_groups`); on the manager
  API, a signed-in editor or a token so confined, through `pages` (`manage_content` or
  `manage_nav`) and, for a cookie session, `list` with an empty path. It could read the
  names, titles and text of pages outside its scope, other domains' among them, and, through
  `rename_page`'s link rewrite, change the links in them. The search's per-file half reached
  any `manage_content` grant, confined or not, for the files described above. Not
  anonymous, and not a write beyond the link rewrite.
: SM1309: an account that may write a path inside a protected area: a member of the
  area's write list (or, with no write list, anyone with `manage_content` there), through
  the manager, the control API, MCP `set_permissions`, `lazysite acl set` as that account,
  or a move over the manager, MCP or WebDAV. The audience it could add is any account or
  group, so the area's content reached people its owner had not admitted; with a write
  list, they could change it too. Not anonymous: an anonymous visitor matches no read list.

threat delta
: Information disclosure, and for SM1309 elevation of privilege inside the access model.
  SM1308 crossed the confinement boundary SEC-2026-07 drew between a domain's partner and
  the rest of the instance; SM1309 let a member decide an audience the area's owner
  decides, which the documented "a folder rule gates its section" read as closed. No trigger
  of ADR 0007's four fired: the fixes add no interface, method, dependency or data. The
  refusals are new answers on existing calls (`widens-enclosing-rule`; a confined
  listing's `scope_roots`).

controls
: SM1308: `_walk_roots` (the grant's scope roots, nested ones dropped) for every MCP walk;
  `Files::action_list_scope_roots`, the one answer to a confined listing that names no
  folder on both doors; `outside_all_scopes` asked again of every search candidate; and
  `Acl::_acl_denied` at each file's first matching line, before the match is counted.
  t/unit/mcp/65 and t/unit/manager/415 fail with the change reverted.
: SM1309: `Acl::widening_refusal` (the enclosing rule by the readers' own walk with the
  path's key taken out; only principals the path's present rule does not already admit;
  nesting and case as the readers read them), asked by `Files::action_acl_set`, which
  every rule writer calls, before it writes or answers a dry run; and
  `Acl::move_widening_refusal`, asked by `Files::action_move` and WebDAV MOVE before
  anything moves. t/unit/mcp/66 and t/unit/dav/36 fail with the change reverted.

residual risk
: SM1308: protected content is not searched at all (T-15, 0.16.4).
: SM1309: a carve-out a member wrote before 0.16.3 is honoured until an operator removes
  it. The check is on writing; `lazysite check` names each such rule as a WARN and changes
  nothing, and `lazysite repair` leaves it for a person (SM1313). A group's membership is
  read when the rule is written, so a group a carve-out names admits whoever joins it
  later, as it always has. A site package restore (`site_apply`) writes its rules as
  packaged; it is an operator's act and is not checked (ruling 62).

verdict
: accepted, confirmed by the release manager on 2026-11-05. Recorded because each
  closed a bypass of a boundary this register names (confinement; the access rule), as the
  SM1257 and SM1303 entries were. The 0.16.3 notes tell an operator to read the check's
  new warning and review each rule it names (ruling 61).

### 2026-11-05 - SM1270, SM1272, SM1273, SM1275-SM1280, SM1283-SM1286, SM1290, SM1291, SM1294, SM1295, SM1299, SM1310, SM1314, SM1315 (0.16.3): access, serving, Odoo and release-path changes with no trigger

Assessment drafted by the developer agent at the 0.16.3 compliance walk; confirmed by the release manager on 2026-11-05 (ruling 93). The rest of 0.16.3 is styling, wording and tests and moves no control: SM1274 (Dismiss all), SM1288 and SM1289 (stylesheets), SM1296 (get_permissions names the rule that governs a page; it reads and changes nothing), SM1297 (an empty `maintenance` means off, as absent did), SM1298 (one warning wording), SM1301, SM1302 (test harness) and SM1316 (the updater's command written with one stage).

what changed
: Access. SM1270: the control API `acl-remove` with no path or an empty one, which
  removed the site-wide rule, is refused on every channel and in
  `Files::action_acl_remove`; `path=/` removes it (ruling 17). SM1272, SM1273: `lazysite
  repair` runs the users tool's top-up (`group-reach`) for each manager group, so a
  capability a release added is granted there and then, where it was granted on the next
  use of the users tool (SM645); a declined one stays declined (ruling 25). SM1310: MCP
  `replace_text` saves with the modification time it read, so a page changed under it is
  refused as a conflict. SM1294: `permissions_policy_allow`, an optional ceiling on the
  browser features a page may ask for (ruling 29).
: Serving. SM1284: the `/docs` manual ships in the engine tree
  (`{LAZYSITE}/templates/docs/`) and serves at `/docs/` whenever the site has no page of
  its own there; access rules over `docs/` govern it by the path it serves at, and it
  stays out of the site's search, sitemap, feeds and `llms.txt` unless
  `engine_docs_public: true`. The upgrade removes each docroot copy whose checksum still
  matches the install state, with its cached renders, and keeps an edited one (rulings 27,
  32, 34, 35). SM1283: the render path's content-root confinement accepts a source the
  system-page fallback itself chose when its real path is under one of the engine's page
  trees; every other source is confined as before. SM1285: a new site has no starter pages
  unless `--starter` asks (ruling 33); SM1286: `lazysite starter --remove-unmodified`
  removes the unmodified ones, as the site user, never as root, audited, never an edited
  page or one the site needs (ruling 34). SM1295, SM1299: `/odoo-signin`, a system page
  for a site whose sign-in is the Odoo login (SM1160), present only while
  `odoo_site_signin` is on, reachable in maintenance as `/login` is, returning to `?next=`
  only when it is a path on the site (rulings 36-39).
: Themes over MCP. SM1291: MCP `install_theme` (`manage_themes`) installs a theme zip
  through `Manager::Themes::action_theme_upload`, the function the manager's Upload Theme
  calls, so the theme upload, cookie-only until now, is reachable with a token. SM1290: MCP
  `preview_page` takes `theme` (`manage_themes` or `manage_layouts`, with
  `manage_content`) and renders with an installed theme that is not active, writing
  nothing.
: Odoo. SM1275-SM1279: a run that ended unknown is read back and resumed, and a change no
  read can tell is settled by its maker or a holder of `settle_odoo_writes`, a capability
  the Odoo extension declares (every operator group holds it, an older site's by the SM645
  top-up); the manager, the control API and MCP list, settle and dismiss such runs, and an
  open one is kept until it is settled or dismissed (rulings 10a-10c). SM1280: a binding's
  `address_profile` gives its operation 1 or 0, whether the call came from inside a named
  address list, never the address (rulings 3, 58).
: Release path. SM1314: `release.sh build --security-critical` refuses without `--final`
  (or `--certified`). SM1315: the deploy hook (`tools/lazysite-deploy.sh`) reads the
  `release-manifest.json` inside the tarball it deploys and passes the Hestia updater
  `--force-security` when the manifest declares `security_critical` (ruling 45).

threat delta
: None of ADR 0007's four triggers fired: no new interface (`install_theme`, the
  `odoo-*` run actions and `/odoo-signin` are actions and a page on existing surfaces, as
  SM301 and SM1263 were), no new sign-in method (`/odoo-signin` is a page in front of
  SM1160's), no new dependency and no new restricted data (SM1280 passes one bit and
  never the address). The questions are these. SM1291: the code path SM1303 exposed
  becomes reachable by a token (Elevation of privilege, through what an upload can place
  in the served tree). SM1283, SM1284: content served from outside the document root, on a
  path an access rule governs, and the upgrade deleting files in the docroot (Information
  disclosure; Tampering). SM1299: a sign-in page that redirects (Spoofing, through an open
  redirect). SM1276: a new capability that decides whether an ERP write happened
  (Tampering, of the record of what Odoo was sent). SM1273: capabilities granted inside a
  repair (Elevation of privilege). SM1315: a field of the deployed release widening which
  sites the deploy reaches.

controls
: SM1291: the upload's checks are the function's, so the token path has every refusal the
  manager's has, 0.16.2's among them (no symbolic link, no file type the web server runs,
  the site's upload limit, no absolute or `..` entry), and nothing is activated; the audit
  row is `theme-upload`'s and `delete_theme` reaches only what the caller installed (SM262).
  t/unit/mcp/61. SM1283: the exception is for a source the fallback chose, resolved with
  `realpath` (t/integration/340). SM1284: the engine's page is named by the path it serves
  at, so a rule, address list, draft section or section theme over `docs/` holds it; the
  site's own page wins; the upgrade removes only a copy whose checksum matches what it
  installed, and `lazysite check` names an edited copy that shadows the engine's
  (t/tools/280, t/unit/processor/160). SM1286 runs as the site user and refuses root.
  SM1299: `Lazysite::Util::sanitise_next`, the one check behind `/login` and
  `/odoo-signin`, now also refuses a `//` anywhere in the path. SM1276: the capability is
  grantable only where the extension is installed; a dismissal sends nothing to Odoo; each
  decision is one call record and one audit line naming the run; a visitor never resumes a
  public binding's run. SM1273: the top-up is SM645's, on an operator's explicit
  `repair`, and grants nothing a group declined (SM685 stands). SM1315: the deploy hook
  already runs, as root, whatever release it finds in its dist directory; the key is read
  from that same tarball, a missing, false or unreadable manifest adds nothing, and the
  hook still deploys only a strictly higher version. SM1314 makes a security release a
  stable cut, so the standard deploy reaches every site and no push is left to a hand.

residual risk
: SM1291: a token holding `manage_themes` can now install a theme's CSS and fonts site-wide
  as the manager's upload could, which is what the capability grants. SM1284: a site that
  relied on deleting `docs/` to hide the manual now serves the engine's copy; access rules
  over `docs/` still govern it. SM1276: a holder of `settle_odoo_writes` can record a write
  as made that was not, or the reverse; OOM reads each change back first, and only a change
  no read can tell reaches a person. SM1315: whoever can place a tarball in the watcher's
  dist directory decides what is deployed, as before.

verdict
: accepted, confirmed by the release manager on 2026-11-05. No trigger fired;
  recorded because access, the served tree, the theme upload's reach, an Odoo control and
  the deploy path moved, as the 0.16.1 entry of 2026-10-23 recorded its own.

### 2026-11-06 - SM1142 (0.16.4): one name for extensions, on disk, in lazysite.conf and on the wire

Assessment drafted by the developer agent at the 0.16.4 compliance walk; confirmed by the release manager on 2026-11-06 (ruling 127). 0.16.4 is SM1142 alone (ruling 63), cut as an edge release, not marked security-critical. Ruling 95: the response keys move with the rest of the wire (`extensions` on extension-list and whoami, `capability_extension` on groups-read), a breaking change for an external reader, recorded in the CHANGELOG and UPGRADE.md.

what changed
: On disk. The engine's extensions ship in `extensions/` beside the docroot (deb:
  `/usr/share/lazysite/extensions`), and every lookup of an extension's script asks one
  resolver, `Lazysite::Extensions::locate` (t/lint/306 refuses another). A site's
  `lazysite.conf` lists the enabled ones as `- extensions/<file>.pl` under
  `extensions:`, the only spelling a reader accepts.
: The upgrade step. `install.pl`'s one-time `extensions-rename` moves each entry left in
  the old directory beside the docroot into `extensions/` (a copy of a shipped file the
  site edited is kept beside the release's, under a suffix naming the old directory),
  rewrites the conf's list and its
  entries so every extension that was on stays on, re-points a cgi-bin symbolic link into
  the old directory at the moved file, rewrites a start page stored as the old Extensions
  page, removes the emptied old directory, and lists what it did in the upgrade summary
  under `Extensions:`. It is recorded as done in the install state only when it ran
  without a warning, so a step that warned runs again on the next upgrade. On HestiaCP
  the root-run deploy (`lazysite-hestia-deploy.sh`) makes `extensions/` and gives it and
  the old directory to the site user before the install, and removes the old directory
  with `rmdir` after it.
: On the wire. The actions, the parameter and whoami's switch in the old spelling
  are refused with `not-found`, naming the `extension-*` spelling, before
  authentication. The responses name `extensions` (extension-list, whoami) and
  `capability_extension` (groups-read) (ruling 95). An audit row for the seven extension
  actions records `extension-*` where it recorded the old spelling, SM831's
  `spelling=deprecated` flag goes with the spelling, and the runner's refusal of a
  disabled extension logs as `extension-gate`. The manager pages are
  `/manager/extensions` and `/manager/extension-config`; the old addresses are not kept.
  MCP's tool names, arguments and responses are unchanged; its descriptions say
  extension.
: `lazysite check` names, by line, a list or an entry in the old spelling written
  back by hand, and an old directory left beside the docroot.

threat delta
: None of ADR 0007's four triggers fired: no new interface (actions, parameters and
  pages are renamed, none added), no new sign-in method, no new dependency and no new
  restricted data. The questions are these. The step moves files and re-points links in
  every site's tree, on HestiaCP after a root-run `chown` (Tampering; Elevation of
  privilege, through a link planted in the old directory or a link re-pointed out of the
  site). The conf rewrite decides which extensions run, the login rate limiter among them
  (Denial of service, against guessing, if the limiter read as off). The audit's action
  names change (Repudiation: a reader filtering the old names stops matching). The
  old-spelling refusal answers before authentication (Information disclosure).

controls
: The step refuses to run unless its two directories resolve to the old directory's
  name and `.../extensions`, skips an old directory that is itself a symbolic link, moves each
  entry with `rename` (a link is moved as a link, never followed), and never overwrites:
  an entry whose kept-copy name is taken too is left in place and named. It
  re-points only a
  cgi-bin link whose target is a file in the old directory, and only at a regular file of that name
  in `extensions/`. The conf and the start-page store are rewritten through
  `_replace_conf`, a temporary file renamed over the original with its mode and group,
  as the other conf conversions are. The root-run `chown -R` is the one the deploy
  already ran on the old directory with the docroot, `lib/` and `tools/` (it does not
  follow links); the removal is `rmdir`, which removes only an empty directory. The rate
  limiter's entry is converted with the rest, `login-rate-limit-on` runs after the step,
  and `lazysite check` says when the limiter is not in force (SM798) as well as naming
  an old-spelling line. The refusal says how an action is spelled and nothing about the
  site. t/tools/306 (the step), t/tools/307 (the Hestia deploy's order and its
  removal), t/unit/manager/168 (the refusals), t/journey/06 (a pre-rename site upgraded
  in place: the sign-in CGI's rate limiter, the data gate, the runtime's start gate, the
  notifier and the registry see what they saw before); t/lint/306, t/lint/307.

residual risk
: A reference the upgrade cannot see stays the operator's: a crontab or pipe naming the
  old directory's `stats.pl` or `form-smtp.pl` stops running (a form's mail pipe stops
  sending), a script on the old spelling is refused, a reader of the old response keys
  reads nothing, and an audit filter on the old action names matches no row written
  from 0.16.4. UPGRADE.md and the 0.16.4 notes list all four. An
  old-spelling entry line written back by hand under `extensions:` reads as off in the manager and as on in
  the notifier and the processor nav, which match an entry by its file name (older than
  the rename and not widened by it); `lazysite check` names the line. A step that warned
  leaves its files in the old directory, run by nothing, until the next upgrade.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired;
  recorded because the upgrade moves files and links in every site's tree (on HestiaCP
  after a root-run step), decides which extensions stay on, the login rate limiter among
  them, and changes what an external reader and the audit trail see (ruling 95).

### 2026-11-05 - SM1324 (0.16.5): a protected folder keeps a history, by choice

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 127). Ruling
50 (T-16) made history for a protected folder an opt-in. It creates a second copy of
protected content, so it is recorded here.

what changed
: A folder rule may carry `history: true`. The folder's versions are kept in a second git
  repository whose work tree is the private store, with its own object store, at
  `<store>/lazysite/git` (02770, as the store). The public repository never holds them,
  so a git-sync remote never receives them. Off by default: a site with no such rule never
  creates the repository.

who can do it
: whoever may set the folder's rule (`Files::action_acl_set`: the operator, or the rule's
  owner), on the manager, the control API, MCP and the CLI.

who can read it
: whoever may read the file. Every history reader resolves its target through
  `_git_target`, which applies the file's read rule; a restore goes through `action_save`
  and its write rule; the overview filters each path by the read rule (SM683 step one).

data and privacy
: a second copy of protected content, kept for as long as the repository is kept. A
  folder's flag covers the rules nested in it unless one says `history: false` (ruling
  100), so a nested folder an owner did not think about is copied too unless it says
  otherwise. Clearing the flag or removing the rule keeps what was recorded; only the
  operator deletes it, with `lazysite acl purge-history` (ruling 99), which rewrites the
  folder out of the history and prunes its objects, and is audited. It is in a site
  backup, as the store is, and a backup taken before a purge still holds it. The public repository still holds a
  file's versions from before its folder was protected (SM683's third step, open).

residual risk
: the repository's permissions are set when it is made and are not probed by
  `lazysite check`.

verdict
: accepted, confirmed by the release manager on 2026-11-06 (ruling 125): the
  new-processing-of-restricted-data trigger the walk records below is contained.

walked
: At the 0.16.5 compliance walk (2026-11-06), against the code on the stack's tip: the
  repository is made 02770 inside the private store (`Lazysite::ProtectedHistory`), the
  purge is the operator's and audited, and `lazysite check`'s mode probe covers the
  docroot's `lazysite/git`, not this one, as the residual risk says. ADR 0007's
  new-processing-of-restricted-data trigger fires: protected content gains a second
  store, kept for as long as the repository is, as SM286's move of where protected
  content lives fired it. The entry above is that trigger's assessment; the release
  manager confirms it with the verdict. No other trigger fires: the `history` key is a
  new value on the existing rule writers, and the readers are the existing history
  actions.

### 2026-11-05 - SM1325 (0.16.5): a site can audit the AI reads of its content

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 127). Ruling
50 (T-17) made an audit of successful AI reads a per-site opt-in. It adds personal data to
the trail, so it is recorded here.

what changed
: `audit_reads: on` in lazysite.conf records each successful MCP `read_file`, `read_page`,
  `view_version` and `preview_page`, and a token's control-API `git-show`, as one `ok` row
  (time, account, path, address, origin) in `logs/audit-reads.log`, beside the trail
  (ruling 97). Off by default; any value
  but on is off. A signed-in person's reads and WebDAV are not recorded.

who can switch it
: an account or token holding `manage_config` AND `audit_switch` (the Config page,
  `config-set`), the gate of the trail's own switch (ruling 96); and whoever edits
  lazysite.conf on the host. The switch itself is on the change trail.

data and privacy
: the trail gains which account read which file, and when, and from which address. That
  is about agents' accounts, and it names protected paths to whoever may read the audit
  (the Audit page's AI reads view, scoped as the trail is). It is kept and rotated as the
  trail is (the logrotate stanza covers `logs/*.log`: weekly, eight kept, where installed),
  and forwarded to syslog if `forward_audit` is on.

residual risk
: volume, bounded by rotation only. The reads have their own file and view, so they do
  not push a change off the change view.

verdict
: accepted, confirmed by the release manager on 2026-11-06 (ruling 125): the trigger
  the walk records below is contained. Added at the 0.16.5
  compliance walk: the entry as filed carried no verdict.

walked
: At the 0.16.5 compliance walk (2026-11-06), against the code on the stack's tip: the
  rows go to `logs/audit-reads.log` (`Lazysite::Audit`), and the Config page's switch
  needs `manage_config` and `audit_switch` together (`Manager::Config`). ADR 0007's
  new-processing-of-restricted-data trigger fires: which account read which protected
  path, when and from which address, is personal data added to a log, as SM1219's account
  names in the visitor log fired it (2026-10-20). The entry above is that trigger's
  assessment. No other trigger fires: the switch is a new key on the existing Config
  page and `config-set`, and the view is a filter on the existing Audit page. Telling the
  people whose agents' reads are recorded is the operator's, as SM1219's notice is
  (OBLIGATIONS.md, the operate-side row added at this walk).

### 2026-11-05 - SM1332-SM1334 (0.16.5): a domain grant adds, the primary can be granted, and a group can pin

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 127).

what changed
: Ruling 78. The primary site is a grantable row in the domain list (the bare
  `allowed_groups:` line in `lazysite.conf`). A grant there adds the scope `/` (the
  docroot, `DomainAccess::PRIMARY_SCOPE`) to its members; grants add, so an account keeps
  the other domains it is granted. An account granted nothing keeps the primary, as
  before. `caller_may_reach_domain` reads `/` as the primary only; the content checks read
  it as the whole docroot, as they read an unbound account's empty list.
: SM1333: the primary's row is written through `domain-set` with host `(default)`
  (control API, MCP `domain_set`, `lazysite-domains.pl`, the Domains page), access
  keys only; a secondary row no longer displays the primary's access as inherited.
: SM1334: a domain's `locked_groups` pins every member of the groups it names, as
  `locked_users` pins an account; a pin on the primary confines to the primary; a
  request's scopes are held inside the account's whole, so a group its address leaves
  out cannot lift a pin.

threat delta
: Elevation of privilege is the question: a scope that by path contains every domain's
  content root, read as such by the domain rule, would reach every domain. It does not:
  the domain rule sets it apart (t/unit/manager/425 holds beta.test out of reach of a
  caller granted alpha and the primary), and the sub-user ceiling lets it meet only
  itself. Reach widens only through an explicit grant on the primary's row, and only to
  what an unbound account already had there - the primary's content, which by path is the
  whole docroot as it always was for an unbound account, and the primary's
  instance-wide settings (SM976 R1, for a caller not confined to other domains). Nothing
  widens at upgrade: no primary row named a group before (t/unit/lib/210). No trigger of
  ADR 0007's four fires: no interface, method, dependency or data is added; the row is a
  new value for an existing key, written through the existing `domain-set`.
: SM1334 only narrows: a pin removes domains and never adds one, and it closes a
  widening the group pin would otherwise have opened (a request's group left out by its
  address taking the pin with it; t/unit/lib/211).

controls
: One resolver (`DomainAccess::effective_scopes`, with the processor's rooting copy held
  to it by t/unit/processor/175) and one domain rule (`caller_may_reach_domain`, asked by
  every host-addressed action, t/lint/218). Writing the primary's row needs what writing
  any domain's access does: `manage_domains` and `manage_users`, and a confined caller
  reaches the row only when it already reaches the primary.

residual risk
: An account granted the primary reaches the primary's content as an unbound account
  does, and by path that holds the other domains' folders (sites/...). This is today's
  unbound reach, carried over; whether the primary's content should exclude the other
  domains' roots was put to the release manager: ruling 126 (2026-11-06), it will, for
  granted and unbound accounts alike, in 0.16.6.

verdict
: accepted, confirmed by the release manager on 2026-11-06.

walked
: At the 0.16.5 compliance walk (2026-11-06): no trigger fires, as the entry finds. The
  question in the residual risk (whether the primary's content should exclude the other
  domains' roots) was carried to the 0.16.5 "what a person must confirm" list in
  OBLIGATIONS.md and ruled there (126).

### 2026-11-05 - SM1343-SM1345 (0.16.5): an address rule's allow or deny moves from the list to the use

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 127).

what changed
: The release manager's request of 24 October 2026 (rulings 56-58, 105-108). SM1134's
  named address lists each carried a kind (allow or deny) fixed at creation; they are now
  address profiles with no kind, in `lazysite/auth/address-profiles.json`. Whether a
  profile allows or denies is the slot the rule names it in (`addresses` /
  `addresses_deny`, the manager's and sign-in's `_deny` keys, a session binding's), so one
  profile may be allowed by one rule and denied by another. SM1189's "wrong kind" refusal
  (a rule naming a list in the other slot refused everyone) goes with the kind. The names
  are renamed outright (actions, MCP tool, CLI, store, page, the template test
  `visitor.in_profile` / `visitor.in_any_profile`); an old action, tool or command is
  refused naming the new one, and a `kind` sent is refused by name. The upgrade converts
  the store once (same names and entries; the old file kept as
  `address-lists.json.converted`) and rewrites the site's template calls, reporting each
  file. The Files card and the Groups page choose Allow or Deny per profile.

threat delta
: A control's semantics change: what a stored name means is now decided by where it is
  used, not by the record it names. Elevation of privilege is the question: a rule whose
  effect widens with no edit to the rule. Every rule a save could write already named its
  list in the slot its kind meant, so for those nothing changes. A rule in the other slot
  (a hand edit only) refused every visitor before and now applies in its slot - it can
  widen. And a store left unconverted, read as empty, would let every deny rule block
  nobody.

controls
: `Lazysite::Auth::AddressProfiles::decide` is still the one answer: deny wins, every layer
  must admit, a faulted store denies wherever a profile is named, a name the store does not
  hold admits nobody where it is allowed. A site with `address-lists.json` and no profile
  store is a fault (`unconverted`), not an empty store: every rule naming a profile
  refuses, and the writer will not start a profile store beside it. The conversion never
  overwrites a profile store, leaves an undecodable old store in place (still refusing),
  and is re-tried until it finishes. `lazysite check` names every rule whose slot differs
  from its old list's kind (read from the kept `.converted` file, ruling 106) and every
  template call left under the old names (which are now false). Writes stay the operator's
  and cookie-only; a profile a rule names is not deleted without a second confirmation.
  t/unit/auth/63, t/integration/144, 145, 266, t/unit/tools/85, t/tools/315, t/lint/320.

residual risk
: A hand-edited wrong-slot rule widens at the upgrade until the operator acts on the
  check's warning; the 0.16.5 notes tell operators to run `lazysite check` after
  upgrading. A template call written back under an old name is false (fails closed for a
  block shown only inside a profile, open for one hidden from it) until the check's
  warning is acted on. The template rewrite edits files outside content history.

verdict
: accepted, confirmed by the release manager on 2026-11-06. Recorded because the
  meaning of an access control's stored value changes (the kind moves from the profile to
  the use), and the upgrade can widen a hand-edited rule; the check names each, and every
  fault on the way fails closed.

walked
: At the 0.16.5 compliance walk (2026-11-06), against the code on the stack's tip: the
  conversion keeps the old store as `address-lists.json.converted` and renames the
  template calls in the pages, layouts, themes, templates and private store
  (`install.pl`), `lazysite check` names an unconverted store, each wrong-slot rule and
  each old call, and the old action, tool and command names are refused naming the new
  ones (`ControlApi::Actions`, the users tool). No trigger fires: the actions, tool and
  page are renamed, none added, and no data is added. SM1321's `bad_url_exempt` (the
  2026-11-06 entry) names profiles too, membership only.

### 2026-11-06 - SM1335, SM1336, SM1339 (0.16.5): a theme's served copies follow its source, and are not written

Assessment drafted by the developer agent at the 0.16.5 compliance walk; confirmed by the release manager on 2026-11-06 (ruling 127; ruling 81; rulings 109-112, 120).

what changed
: SM1335. A write to a theme's source, on any surface (the manager's save, upload,
  delete, move and copy, WebDAV PUT, DELETE, MOVE and COPY, MCP `create_theme`, theme
  delete), re-mirrors that theme to every host's copy, the docroot's and each content
  root's (`Themes::follow_source_write`), or removes the copies when the source is gone,
  and drops the cached renders that link it. Before, a copy was written at activation,
  apply, domain-add and creation only. One theme per write, never the site's.
: SM1336. An installed theme (Upload Theme, MCP `install_theme`) and a copied theme
  (`theme-copy`, `copy_theme`) have their copies written by the same writer,
  `_mirror_theme_assets`, with the tokens and the fingerprint (SM830), where they were
  built by hand from `assets/` or from the docroot's copy.
: SM1339. A write into a host's `/lazysite-assets/<layout>/<theme>/`, the layout folder or
  `lazysite-assets` itself is refused for every caller, the operator included, naming
  the source to write instead (`served_artifact_refusal`, the SM976 F1 rule the choke
  point and WebDAV share). Reading a copy, copying out of one and removing the copy of a
  theme no longer installed are not refused. The theme and the layout a secondary domain
  serves as its own are read-only on every surface, as the primary's are
  (`active_artifact_refusal`, `Common::domain_active_artifacts`; rulings 109, 120).
  `list_files` and the Files page mark each copy `served_copy`. `theme-copy` and
  `copy_theme` take the theme by its path as well as by its name.

threat delta
: None of ADR 0007's four triggers fired: no new interface (the refusals and the
  `served_copy` mark are on existing actions; the theme's path is a new spelling of an
  existing argument), no new sign-in method, no new dependency and no new restricted data
  (a theme's assets are public by design). The question is SM1303's: what reaches the
  served asset mirror (boundary 6). Before, a theme's source reached a copy only at an
  activation or an upload, both checked; now every source write reaches every copy with
  no activation, so whatever lands in a theme's `assets/` - by a manager or WebDAV write,
  a restore or a shell - is published under `/lazysite-assets/` at the next write
  (Elevation of privilege, through a symbolic link to the session secret, as in SM1303;
  Tampering, through a server-run file). The refusal on the copies narrows: no writer,
  the operator included, edits a published copy directly.

controls
: `_mirror_theme_assets` is the one writer of every copy, and refuses to switch in a copy
  whose `assets/` holds a symbolic link or a file type the web server would run
  (`_mirror_unsafe_entry`: SM1303's two archive checks, links listed and never followed),
  keeping the copy it had and logging the entry. The copy is built in a staging directory
  and swapped in, as before. A write to a source needs what it did: the theme's layout
  capability and the path's own reach; a secondary domain's active theme and layout are
  refused to every caller, so a domain's served look changes only by copy, edit and
  activate with `host`. t/unit/manager/430, 431, 432, t/unit/dav/38, t/unit/mcp/73,
  t/integration/116.

residual risk
: A theme's source holding a link or a server-run file stops reaching its copies, and
  says so in the log and the write's answer, until it is removed. An edit to a theme
  reaches every visitor of every page that uses it at once, with no activation step to
  review it. A copy planted before 0.16.2 stays until `lazysite check` names it and the
  operator removes it (SM1304; OBLIGATIONS.md).

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired;
  recorded because the path into the served asset mirror (SM1303's) now runs on every
  theme write, and a served copy is refused to the operator.

### 2026-11-06 - SM1321, SM1322, SM1327, SM1328, SM1340, SM1341, SM1347, SM1365 (0.16.5): access, sign-in, serving and Odoo changes with no trigger

Assessment drafted by the developer agent at the 0.16.5 compliance walk; confirmed by the release manager on 2026-11-06 (ruling 127). The rest of 0.16.5 moves no control: SM1330 and SM1346 are the test harness and the pinned OOM snapshot in `t/vendor/oom` (0.42 to 0.44, never installed; lazysite's code is unchanged by it, ruling 82), and SM1342 is the manual's anchors. The other changes of 0.16.5 have their own entries: SM1324 and SM1325 (2026-11-05, each firing new-processing-of-restricted-data, recorded at this walk), SM1332-SM1334 and SM1343-SM1345 (2026-11-05), SM1335, SM1336 and SM1339 (2026-11-06).

what changed
: SM1321, the bad-URL blocker (rulings 48, 83, 84). A path that resolves to a regular file
  under the docroot is never counted as a probe (`Lazysite::BadUrl::site_has_file`: the
  path less its query, percent-decoded once, plain segments `lstat`'d from the docroot
  down; a `.` or `..`, a symbolic link on the way, a dot name, the engine tree, a NUL or a
  backslash is not the site's file). Loopback (127.0.0.0/8, ::1) is always exempt, never
  counted or refused, a block on file included; `bad_url_exempt` names address profiles
  whose addresses are exempt too, and the value `none` removes loopback's exemption. The
  Config page refuses an address, an unknown profile, or `none` beside names.
: SM1322, `/login` (rulings 49, 85). `lazysite-auth.pl?action=session` (GET) answers only
  `signed_in` yes or no for the request's own cookie, from
  `Lazysite::Auth::Session::request_session`, the verdict every surface asks; `no-store`,
  logged as a session line, and a no clears the display marker. The chrome script asks
  it on a page carrying `data-ls-auth-check`. "Sign in as someone else" is the sign-out
  with `then=signin`, landing on the sign-in page with `next` through `sanitise_next`.
: SM1327, MCP `write_file` (ruling 51). An optional `base_mtime` makes a write conditional
  on the version read: stale, or for a file gone, nothing is written and the answer is a
  conflict. `rename_page`'s alias and link rewrite save with the time they read.
: SM1328, the Odoo name (ruling 52). `odoo_display_name` in the Odoo extension's
  settings is said by the sign-in dialog, `/odoo-signin`, `/login`'s link, the browser
  helper's messages, the page endpoint's errors and the Unknown Odoo writes panel; one
  reader, `Lazysite::Odoo::Name`, and the helper script carries it as an attribute.
: SM1340, the design guide (rulings 79, 114). `design_guide: /path`, and
  `alias.<host>.design_guide` for a domain, put a link at the head of `/docs/layouts` and
  `/docs/ai-briefing-layouts`; only a same-site path counts (the processor's copy of
  `sanitise_next`'s rule), written through `url_safe`.
: SM1341, the AI docs (rulings 80, 113, 115). Connect an AI assistant
  (`/docs/ai-connector-setup`) becomes public, carrying the endpoints, the connection
  modes and how a client authenticates (pairing key, access token, checking access), with
  placeholders only; `.well-known/ai-partner` lists it. The tools reference stays
  signed-in.
: SM1347, Odoo results (rulings 103, 104). A write Odoo did not keep names its fields
  (`not_kept`), never the values asked or found, with a note the helper draws as text;
  `refused/access` and `refused/missing` each have their own sentence.
: SM1365, the ACL 403. A signed-in visitor refused by an `auth/acls.json` read list who
  opens a page gets the site's 403 page, naming the list's groups (never a user on it), as
  the front-matter group gate does; a file keeps the short 403.

threat delta
: None of ADR 0007's four triggers fired: no new interface (`action=session` is an action
  on the existing sign-in CGI, as `/odoo-signin` was a page on existing surfaces (SM1299); `base_mtime`,
  `bad_url_exempt`, `odoo_display_name` and `design_guide` are a parameter and keys on
  existing surfaces), no new sign-in method (the session check asks the existing
  verdict), no new dependency and no new restricted data. The questions are these.
  SM1321: an exemption on a guard (Denial of service: the blocker counts nothing from an
  exempt address, and behind a front end `trusted_proxies` does not cover, every visitor
  is loopback; a STRIDE row records it), and a path resolved against the disk from a
  request (Information disclosure, by probing which files exist). SM1322: an
  unauthenticated endpoint about a session (Information disclosure, Spoofing). SM1328,
  SM1340: a site-set value written into pages and scripts (Tampering, by markup in the
  value; Spoofing, by an open redirect through the link). SM1341: how a client
  authenticates, readable before sign-in (Information disclosure). SM1365: the 403 page
  names groups (Information disclosure). SM1347: what an ERP write held reaching a page
  (Information disclosure). SM1327 reduces Tampering: a lost update between two writers.

controls
: SM1321: the file test changes only whether a hit is counted, never what is served, and
  answers the same as a fetch of the path would; the exemption is asked only for an
  address on file or a probe about to be counted, of the address `request_address` gives
  under `trusted_proxies` (SM929); profile names only, validated at save, and
  `lazysite check` names an unknown one (t/unit/lib/98, t/integration/296). SM1322: the
  answer is one bit about the requester's own cookie, never why; nothing is set but the
  marker's clearing, and the HttpOnly cookie is left to the endpoints that own it
  (t/unit/auth/74). SM1328: the name is set by a holder of the extension's settings and is
  escaped where it is written (t/unit/odoo/121, t/unit/processor/172). SM1340: a full URL,
  `//`, a backslash or any character outside a path's is no guide at all
  (t/unit/processor/180). SM1341: the page carries placeholders only, held by
  t/lint/311, and describes the engine's own mechanisms, which ship in every release's
  source; no site's addresses, accounts or credentials are on it. SM1365: the groups are the ones the front-matter gate's 403 already names for a
  page; users on the list are never named; draft sections keep their 404 and anonymous
  requests the bounce to sign in (t/integration/345). SM1347: field names only
  (t/unit/odoo/122-124). SM1327: t/unit/mcp/70.

residual risk
: SM1321: a site behind a front end on the same host with `trusted_proxies` unset (the
  default trusts the private ranges, not loopback) counts no probe until it is set (the
  STRIDE row); `lazysite check` warns about it only where address rules are in use, so
  UPGRADE.md says to name such a front end. A probe can learn whether a path is a real file by whether it is counted,
  which a fetch of the path already tells it. SM1341: a site that kept the setup steps
  private by the signed-in manual now publishes them; an access rule over `docs/` or a
  page of the site's own at that path governs it (SM1284). SM1365: a signed-in visitor
  refused a folder learns the names of the groups that may read it, as a front-matter
  gate already told them. SM1322: the answer is uncached and per request, so it is one
  more request a page makes while the marker is set.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired;
  recorded because a guard's exemption, the sign-in page's check, a page's public status
  and what a refusal names moved, as the 0.16.3 entry of 2026-11-05 recorded its own.

### 2026-11-06 - SM1369 X0, X1 (0.16.6): an extension's own code can be loaded into a core process

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 134).
Ruling 55; the design is the extension-hooks proposal, whose security model (G-1 to
G-10, and what an extension can never do) these slices begin to build.

what changed
: X0. `t/lint/321` fails a new core line that names Odoo (`odoo`, `OOM`, `oomd`; ruling
  136 counts Odoo's names only, not every extension's script name); the lines there today
  are an allow-list that may only shrink. No behaviour changes.
: X1. An extension's `owns` may declare `hooks` (a mapping) and `requires` (extension
  ids). `Lazysite::Extensions::Hooks` validates both. The manager writes
  `lazysite/extensions.index.json` from the enabled extensions' descriptors on enable,
  disable and save, and `install.pl` does it on every upgrade and reinstall, as the
  site user. `Hooks::call_hook` loads an indexed function from the extension's payload
  lib (`extensions/<stem>/lib`, put on `@INC` by `Lazysite::Extensions::add_payload_lib`)
  and calls it in the calling process. Enabling an extension whose `requires` names one
  that is off is refused by name. In this release no hook kind is live: every
  declaration of one is refused, naming the slice that builds it, and no core code calls
  `call_hook`.

threat delta
: ADR 0007's new-external-interface trigger fires. Until now an extension ran only as
  a separate process (`--describe`, its declared actions); X1 builds an interface
  through which an extension's own Perl runs inside a core process - the manager, and
  from later slices the request path - with that process's rights, its open handles and
  its memory. Nothing reaches it in 0.16.6 (no live kind, no caller), but the interface
  is built here, and each later slice adds only a caller, so the assessment is recorded
  now rather than at the first caller. The other three triggers do not fire: no sign-in
  method (H-1 is X4), no new dependency (Cwd, JSON::PP and Time::HiRes are core and
  declared), no restricted data. The questions are these. Elevation of privilege and
  Tampering: an extension's code running as core, or code that is not the extension's
  (core's, a system module's, a planted file's) run under its name. Denial of service:
  a hook that dies or hangs in a core process. Spoofing: a disabled extension's index
  entry, or a dependency switched off, still being honoured. Tampering: the index file
  itself, between the write and the read.

controls
: The declaration is validated before anything is indexed: unknown hooks and hooks not
  yet built are refused by name, a function is a fully qualified name never in
  `main::`, `CORE::` or `UNIVERSAL::` and never `import`, `DESTROY` or a phase block.
  Only the extension's own code runs: each module a declaration names must be a regular
  file in its payload lib, which is a real directory at each step (a link is refused),
  and must not resolve anywhere else on `@INC`, checked at the build and again at the
  call, with a module already loaded from elsewhere refused; the payload lib is appended
  to `@INC`, never prepended, so it cannot replace core's modules. Only what the index
  lists runs: `call_hook` refuses a function the indexed declaration does not name. Off
  means off (G-1): the extension and every extension it requires must be in
  `lazysite.conf` at the call, read fresh, never cached; the payload lib must be the one
  the index was built from, so an edited index runs nothing. A hook that dies is a
  failure with its reason, never an exception into core (G-9). The index is written
  atomically by the manager, and the build runs extension code only as `--describe`,
  out of process, as before (G-10). t/unit/extensions/70 (the validator),
  t/unit/extensions/71 (the build and the loader, including a stale index after a
  disable, a shadowing module, a linked payload, a dying hook and an unmet `requires`),
  t/tools/330 (the upgrade step), t/lint/125 (the call's enabled-list reader), t/lint/321.

residual risk
: In process the hooks are a contract, not a sandbox (the proposal's "What the model
  does not claim"): an extension is Perl running as the site user and, once a caller
  exists, could do in core's process anything core can. Trust comes from what is
  installed, and ADR 0009 keeps third-party extensions out of tree aside until a signing
  story exists; that boundary is unchanged and is what holds this. A hook that loops is
  not bounded by `call_hook`; each slice that adds a caller decides that caller's
  budget. A long-lived process (a pool worker, from later slices) keeps a payload lib on
  `@INC` and a module loaded once it has run a hook, and two extensions cannot ship a
  module of the same name (the second is refused as found elsewhere). Whoever can write
  `lazysite/` can write the index, as they can already write `lazysite.conf` and
  `handlers.conf`; the call-time checks bound what an edited index can name to an
  enabled extension's own payload.

verdict
: accepted, confirmed by the release manager on 2026-11-06 (ruling 134): the trigger
  fires and the change is contained for 0.16.6, because no hook kind is live and nothing
  calls the loader. The first slice that makes a kind live (X2) adds a caller to this interface
  and should be assessed against this entry, in its own.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): `Lazysite::Extensions::Hooks::call_hook` has no caller (no
  file under `lib/`, `lazysite-processor/`, the manager API or `extensions/` calls it), no
  hook kind is accepted, `add_payload_lib` appends to `@INC` and never prepends, and
  `call_hook` reads the enabled list fresh at each call (`enabled_keys`).
  `lib/Lazysite/Extensions/Hooks.pm` is the one shipped file 0.16.6 adds (the SBOM's 462nd
  component; its `use` lines are core modules, declared). ADR 0007's new-external-interface
  trigger fires as the entry says, and the entry is its assessment, confirmed contained
  (ruling 134). The walk records the interface as trust boundary 15 and a STRIDE row, both
  confirmed by the release manager on 2026-11-06 (ruling 142).

### 2026-11-06 - SM1370 (0.16.6): a token follows its account's grant

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: Ruling 121. Measured, before any change: no token door fixes a capability into a
  credential. The pairing exchange (`cmd_token_exchange`) replaces the account's
  credential and sets its expiry; an lzs_ token verifies through
  `Auth::Verify::verify_credential`, which resolves `caps_for` from the group store at that
  request (manager API `%token_caps` and MCP `verify_bearer`, per request); an OAuth access
  token maps to a partner, resolved through `partner-caps` at each MCP call, and a refresh
  mints no capability; WebDAV asks `caps_for` once per CGI process. What changes is
  reporting: both whoamis carry a `grant` block (`Capabilities::whoami_roles`) saying the
  grant is the account's at each request, and the layouts briefing stops advising a token
  rotation.

threat delta
: Elevation of privilege is the question: a token holding more than its account now holds,
  after a grant is taken away. It does not, on any door, and did not before
  (t/unit/manager/460 subtests 1-3 pass on b7f178856): a removed grant is refused on the
  token's next request over the control API, MCP bearer and MCP OAuth, and a token confined
  to one domain is refused another's page, read and write, after the account gains four
  capabilities. The `grant` block is a fixed sentence about the engine, no account data. No
  trigger of ADR 0007's four fires: no interface, method, dependency or data is added.

controls
: One resolver (`caps_for`, ADR 0001), asked per request by every door; t/unit/manager/460
  pins each door in each direction, so a capability cache or a snapshot in a credential
  fails there.

residual risk
: An MCP client keeps the tool list it fetched at connect: after a grant is removed it may
  still show a tool, which the server refuses (the call is refused and audited, -32002);
  after a grant is added it may not show the tool until it lists again. The server declares
  `listChanged: false` and has no push channel, so the remedy is the client's (the whoami
  note and the docs). There is no per-token narrowing in this release; what narrows a token
  is its account's domain scope and address rule (SM1140), both per request.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because ruling 121 is an access-control rule and this is where it is shown to hold.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): both whoamis carry the `grant` block
  (`Capabilities::whoami_grant` and `whoami_roles`, from `lazysite-mcp.pl` and
  `Manager::Users`), and t/unit/manager/460 holds each door both ways. No trigger fires.

### 2026-11-06 - SM1371 (0.16.6): agent roles, the role summary, the extension offer, and a form's config

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: Ruling 122. Four assignable groups ship in the seed, each over MCP with one job's
  capabilities on the record: `content-agent` (`manage_content`, `manage_nav`,
  `manage_forms`), `data-agent` (`manage_data`, `write_data`, `manage_briefs`),
  `forms-reader` (`read_submissions`), `analytics-agent` (`analytics`). An existing site
  with the shipped role layer adopts each absent one once, with no members, recorded in
  `bundles-adopted.json` (`_adopt_agent_roles`).
: `Auth::Settings::role_summary`: the account's direct assignable groups that grant
  something, less its own `role-<account>` group, and the capabilities it holds that none
  of them grants (`beyond`), reported by both whoamis and by `users-page` to the Users page.
: The Groups page's capability map (`channel-services`) carries each owning extension's
  `script`; ticking a grant whose extension is off asks to enable it, through
  `extension-enable`.
: `manage_forms` reads and writes `lazysite/forms/<name>.conf` through MCP `read_file` /
  `write_file` and the manager's `read` / `save`, as over WebDAV since 0.8.1: the carve-out
  gate requires it (`carveout_requirement`, `form_conf_name`), and the choke point asks it
  again from `Manager::Files::$CALLER_CAPS`; a write meets WebDAV's rules (UTF-8, targets
  naming existing handlers only, the form in the caller's reach, handlers it may use).

threat delta
: Elevation of privilege is the question for each part.
: The roles: a shipped group is a grant waiting for a member. Adoption adds no member, so
  no account's capabilities change at the upgrade (t/unit/users/70); putting an account in
  a role is the existing `group-add`, with SM195's conferral ceiling (a delegate confers
  only what it may). No role carries `ui`, `api`, `webdav`, design, settings, people,
  audit or purge.
: The role summary and the map's `script`: read-only, shown to callers who already see the
  account's settings (users-page) or their own grant (whoami); the script path is the one
  the Extensions page already lists.
: The extension offer: the enable stays a separate request that needs `manage_config`
  (`cookie_cap` on `extension-enable`) and is audited as a mutating action; a grant never
  enables anything by itself. A Groups-page user without `manage_config` is refused the
  enable as before.
: The form config: this widens what `manage_forms` reaches on two doors to what it
  already reached on the third. A form's config names which handlers a form dispatches to,
  and `manage_forms` already writes it through `bind_form`, `set_form_uploads`,
  `set_form_notify` and `form-targets-save`; the raw write meets the same binding rules,
  so it reaches no handler, destination or form those verbs refuse. Credentials
  (`smtp.conf`), handler definitions (`handlers.conf`) and the schedule stay refused
  (t/unit/manager/461). Undef caps (an unsecured site, where the gate is skipped) refuse.
: No trigger of ADR 0007's four fires: no new interface (two blocks on whoami, a field on
  an existing response, existing actions), no new sign-in method, no new dependency, no new
  restricted data.

controls
: Groups-only resolution (ADR 0003, `caps_for`), the adoption rules of SM1241/SM1262
  reused, the carve-out definition shared by both dispatchers (SM268 H4) and answered again
  at the choke point, `Handlers::form_conf_problems` and `handler_bind_refusal` as on the
  other doors. Tests: t/unit/users/70, t/unit/manager/460 (subtest 4), 461, 462.

residual risk
: A site that granted `manage_forms` to an account it would not trust with a form's raw
  config gains nothing it could not already do through the binding verbs, but the raw file
  is now one more way to do it; UPGRADE.md says to check who holds `manage_forms`. An
  operator who puts an agent in `data-agent` gives it `manage_briefs` with the data
  capabilities (a choice recorded in the filing). The four roles appear on every site with
  the shipped role layer; an operator who does not want them deletes them once.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because shipped grants, a capability's reach on two doors and the Groups page's enable
  path moved.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): the four roles are added by `_adopt_agent_roles` in
  `tools/lazysite-users.pl`, run on ordinary use of the users tool, with no members;
  `carveout_requirement` and `form_conf_name` gate a form's conf in `Manager::Common` and
  `Manager::Files`; t/unit/users/70 and t/unit/manager/461 and 462 are on the tip. No
  trigger fires. OBLIGATIONS.md gains an operate-side row: who holds `manage_forms`, and
  which of the four roles a site keeps.

### 2026-11-06 - SM1373 (0.16.6): an extension's settings read answers only its own keys

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: `extension-read` (`Lazysite::Manager::Extensions::action_extension_read`) answered
  every `key: value` pair in an extension's `config_file`. For the two extensions whose
  file is `lazysite/lazysite.conf` (bad-url-blocker, log) that was the site's whole main
  config; for one with its own file, any key its schema does not name. Only the
  extension's own `type: password` fields were dropped. The answer is now the keys the
  extension's `config_schema` or `config_keys` names, whatever its file, with password
  fields still dropped.

threat delta
: Information disclosure, narrowed: a read of one extension's settings no longer carries
  site settings and secrets kept in the same file that the extension does not own (a
  credential another extension keeps in `lazysite.conf`, for one). Who may call it is
  unchanged: `extension-read` is absent from the token gate (`%GATE` in
  `Lazysite::ControlApi::Actions`), so no access token, MCP client or partner reaches
  it; it is reachable by a manager cookie session only, with `manage_config` (its
  `cookie_cap`; the dispatcher's cookie check in `lazysite-manager-api.pl` asks it).
  The exposure was to an account trusted with the site's settings, but wider than its
  own door: `config-read`, the Config page's reader, answers a named safe subset of
  `lazysite.conf` with no secrets (SM122), and `extension-read` answered the rest.
  No trigger of ADR 0007's four fires: no interface,
  method, dependency or data is added, and the change removes output.

controls
: One key list, the extension's own declaration, read where the values are chosen;
  t/unit/manager/445 puts a foreign key (and a foreign password-shaped key) beside
  bad-url-blocker's and log's in `lazysite.conf` and a key outside form-smtp's schema in
  its own file, and finds none answered, and the password field still dropped.

residual risk
: An extension that declares a key also kept by another extension in the same file is
  answered it; that is a shared key by the extensions' own declarations. Whoever
  can read `lazysite/lazysite.conf` as a file on the host still reads it whole.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because what a settings read discloses moved.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): `extension-read` carries `cookie_cap => 'manage_config'` and no
  `%GATE` line in `Lazysite::ControlApi::Actions`, so no token reaches it, and
  t/unit/manager/445 is on the tip. No shipped extension keeps a credential in
  `lazysite/lazysite.conf`: the two that keep their settings there (bad-url-blocker, log)
  have none, and the credentials are each extension's own file (`forms/smtp.conf`,
  `notify-xmpp.conf`, the Odoo key files), whose own password fields were already
  dropped. What the read answered beyond the extension's keys was the site's other
  settings, to an account trusted with them, on a cookie session only. Judged at this walk
  a hardening of what a trusted role's read shows, not the fix of a vulnerability: 0.16.6
  is not cut security-critical for it (OBLIGATIONS.md, the vulnerability-handling row). A
  credential an operator wrote into `lazysite.conf` by hand was answered to a
  `manage_config` holder until 0.16.6. No trigger fires.

### 2026-11-06 - SM1374 (0.16.6): a plan Odoo refused shows the visitor only validation text

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: An Odoo plan that failed at Odoo answered `apply-incomplete` with "the plan did not
  apply completely - see the counts", and each failed change carried Odoo's message
  through SM1186's filter (`_usage_text`: control characters, a cap, a path, a trace or a
  secret's name withholds it), whatever kind of fault it was. Now the message is shown
  only for a change whose journal entry's OOM category is `validation` (ValidationError,
  UserError), without the "Odoo Server Error:" prefix, and that message is the answer's
  `error`; a refusal raised by the operation itself (kind `refused`, SM1198) keeps its
  sentence; every other failure, and one whose journal cannot be read, is withheld, and
  `error` is a plain sentence for the visitor. The counts stay in `result`, the journal
  and a WARN log line (binding, operation, plan, counts; never a change's text).

threat delta
: Information disclosure, narrowed. An access fault's text names a model and the groups
  that may reach it, a missing record's its id, an unclassified fault anything Odoo's
  server says (a table or column name); the filter's patterns did not catch those, and
  a public binding's visitor received them. No trigger of ADR 0007's four fires: no
  interface, method, dependency or data is added; the change removes output.

controls
: The category is OOM's (`Odoo::Error::fault_category`, from the server's exception
  class), read from the journal OOM kept of the apply, by change; a change with no
  readable category is withheld (fail closed). A shown message still passes the filter.
  t/unit/odoo/125 drives UserError and ValidationError (shown, prefix gone), and
  AccessError, MissingError and an unclassified fault (the plain sentence, and none of
  the text anywhere in the answer), with the shop fixture's fake transport; t/unit/odoo/77
  holds the same through the real oomd.

residual risk
: A validation message is Odoo's text, written for the person who sent the data; one a
  module writes with internals in it reaches the visitor unless the filter catches it.
  A change whose answer never came (`unknown`, SM1218) still carries the transport's
  message through the filter, as before.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because what a refusal tells a visitor moved.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): the category is `fault_category`'s, read in `Lazysite::Odoo`
  and `Lazysite::Odoo::Session`, and t/unit/odoo/125 and 77 are on the tip. No trigger
  fires.

### 2026-11-06 - SM1366 (0.16.6): an Odoo call's record names the signed-in account

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: Ruling 124. An Odoo call made under a person's Odoo session was recorded (the call
  record and the audit line) with `actor` `session:<hash>` alone (design B: the session
  id is a credential). Where the request is also signed in to the site, the Odoo endpoint
  names that identity (`$Lazysite::Odoo::SIGNED_IN`, local to the request) and the
  record's `actor` is it, with the hash kept in a new `session` field and as
  `session=<hash>` on the audit row.

threat delta
: Repudiation, reduced: the row says who acted, as the processor's line for the same
  request already did. Information disclosure is the question: the audit log and the
  call record now carry an account name (`odoo:<login>` is an e-mail-shaped login) beside
  the session hash. The audit log already carries it (a site sign-in's audit row is
  `odoo:<login> | login`; the processor's ACL line writes `user=odoo:<login>`), and the
  call record already names the account of a call that is not a session binding's; both
  are read by the same readers as before: the audit trail by a holder of `audit` (a
  `create_sub_users` holder sees its own sub-users' rows only, SM173) and the call record
  through `odoo-calls`, which needs `manage_connectors`. The
  session id is still never written, a refused sign-in keeps `signin:<hash>` (a typed
  login is not an account), and the identity named is the one the session cookie
  verified, never a header. No trigger of ADR 0007's four fires: no interface, method or
  dependency is added, and no new kind of data is kept (the account name is in the same
  log already).

controls
: The rewrite is in `record_call`, the one writer, and applies only to an actor of the
  exact `session:<16 hex>` shape while an identity is set; the context's actor, which
  owns a session binding's plans and decides who may confirm, withdraw or resume them,
  is untouched (t/unit/odoo/126). The record's fixed field list gains `session` and still
  refuses any other (t/unit/odoo/03). The endpoint's wiring is held through the real
  endpoint (t/unit/odoo/63).

residual risk
: A person signed in to the site as one local account who signs in to Odoo as another
  person is recorded under the site account: the row names who was at the site, with the
  Odoo session's hash beside it to tell them apart.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because what the audit trail names moved.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): `$Lazysite::Odoo::SIGNED_IN` is local to the request and read
  only by `record_call` in `Lazysite::Odoo`; t/unit/odoo/03, 63 and 126 are on the tip. No
  trigger fires. A script that reads the audit row's actor for an Odoo session call reads
  the account from 0.16.6, with `session=` beside it (UPGRADE.md).

### 2026-11-06 - SM1362 (0.16.6): a form mails its owner, and can answer the submitter

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: Ruling 123. (1) `lazysite/notify.conf` `owner_contact:` names one address, and each
  form submission's notice is also mailed there through SM485's `send_mail` (the Form
  SMTP extension, the per-site `mail.per_hour` bound, `logs/notice-mail.jsonl`).
  (2) A form's conf may opt in to an acknowledgement: `acknowledge_field` (the field
  holding the address), `acknowledge_subject`, `acknowledge_message`; after the
  submission is stored, the form's own text is mailed to the one address in that field,
  under SM877's per-recipient (3/hour) and per-site (60/hour) caps, counted with the
  smtp handler's acknowledgements in `logs/submitter-mail.jsonl`.

threat delta
: The question is (2): the site sends an email to an address a visitor typed. That is
  abuse of the site as a mailer (Denial of service against a third party's inbox, and
  the site's own sending reputation; Spoofing, by mail that comes from the site), and
  it is the open-relay shape SM877's caps were built for. Three things bound it. The
  message is the form's fixed text with no part of the submission in it (not a field,
  not the name), so an attacker chooses only the recipient, never the words: the form
  cannot carry their content to a stranger. The rate: per recipient, 3 an hour, so one
  inbox cannot be flooded; per site, 60 an hour across every form and every smtp
  handler's acknowledgements (one shared record, so a second door is not a second
  bucket); the form's own limit per source address (SM401, 5 submissions an hour, waived for a signed-in member) and the
  render timestamp and honeypot apply before any of it. And a quarantined submission
  (links, shorteners, a repeated value, the site's keywords) is never answered (SM913).
  An unreadable cap record refuses rather than counts as zero (within_caps). (1) sends
  to an address the site's configuration names, never one a request carries; its
  abuse case is volume, bounded by `mail.per_hour` and by the notice's own rules (no
  notice on `notify: off` or for a quarantined submission). Information disclosure:
  the owner mail carries the submitted fields only for a form set to `notify: full`,
  as the chat notice does; otherwise a line and a link that needs a sign-in.
  ADR 0007: no new interface (keys in existing configuration files, the existing form
  CGI), no new authentication method, no new dependency (the Form SMTP extension is
  the existing transport). New processing of restricted data: no new data is kept
  (the address is not written to either cap record, only a hash for the
  per-recipient count, as SM877), but personal data now leaves the site to a second
  party, the owner, for a `notify: full` form - the same disclosure an smtp handler
  makes, chosen by the operator. Ruling 140 (2026-11-06): an owner notice under
  `notify: full` carries a submission's contents by email, so ADR 0007's
  new-processing-of-restricted-data trigger fires, and it is assessed contained: it is
  off by default (no `owner_contact`, and `notify: full` set per form), it goes only to
  the one address the operator names in `owner_contact`, never to one a request
  carries, and it is rate-limited by `mail.per_hour`.

controls
: t/unit/forms/68 through the real form CGI and Form SMTP with a mock sendmail: the
  acknowledgement carries the form's words and none of the visitor's text and never the
  owner's address; nothing is sent without the opt-ins; a quarantined submission tells
  nobody; the per-address cap, the form's per-site cap, `mail.per_hour` and the bucket
  shared with the smtp handler each hold; two addresses in `owner_contact` mail nobody.
  The address is checked by `Lazysite::Mail::one_address` (SM1017) on both paths.

residual risk
: A visitor can still make the site send its fixed acknowledgement to an address they
  name, three times an hour per address and up to the site's 60; the owner should
  word it so that receiving it unasked is harmless. The acknowledgement does not ask
  whether the Form SMTP extension is enabled (as SM877's does not): its settings file
  is what sends it.

verdict
: accepted, confirmed by the release manager on 2026-11-06 (ruling 140): the
  new-processing-of-restricted-data trigger fires for a `notify: full` form's owner
  mail, and the change is contained (off by default, only to the operator's named
  `owner_contact` address, rate-limited by `mail.per_hour`).

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): `owner_contact` is read in `Lazysite::Notify`,
  `acknowledge_field` in `Lazysite::Handlers`, and both addresses pass
  `Lazysite::Mail::one_address`; t/unit/forms/68 is on the tip. ADR 0007's
  new-processing-of-restricted-data trigger fires as the entry says, and the entry is its
  assessment, confirmed contained (ruling 140). OBLIGATIONS.md gains an operate-side row:
  the owner's address, the personal data a `notify: full` form's mail carries, and the
  acknowledgement's wording.

### 2026-11-06 - SM1372 (0.16.6): the primary's content leaves out the other domains' roots

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: Ruling 126, closing the residual risk SM1332-SM1334's entry (2026-11-05) recorded. An
  account whose scopes reach the primary's content - an unbound account (an empty scope
  list) or one granted the primary's row (`PRIMARY_SCOPE`) - read the whole docroot as
  its content, and by path the docroot holds every secondary domain's content root
  (`sites/...`). Now the primary's content is the docroot less those roots: one rule,
  `Lazysite::Auth::DomainAccess::foreign_root_of` (the root a path lies in, for a list
  that reaches the docroot and names no scope covering it), asked by
  `Lazysite::Manager::Common::outside_all_scopes` and `caller_may_reach_path` (so the
  manager API's dispatch gate `_confine_scope`, now asked for an empty list too, the
  file actions, the zip download, the sections listing, PDF parts and the form and
  brief rules), by the MCP path gate and its docroot walks (`list_pages`, `search_files`
  and the other `_each_page` walks), and by WebDAV's `authorise`. Kept: the unconfined
  operator (the manager's cookie operator, whose scopes are never resolved; on WebDAV
  a member of the operator group, SM991), and any root the account is granted on its own.
  A manager holding `manage_users` outside the operator group is not the operator and is
  held to it, as are tokens, MCP grants and WebDAV accounts.

threat delta
: Elevation of privilege and Information disclosure, reduced: an account given the
  primary, or nothing, no longer reads or writes another domain's pages through it. Who
  can lose access: a non-operator account that worked on a secondary domain's folder
  without a grant on it (UPGRADE.md says how to find and grant it). No trigger of ADR
  0007's four fires: no interface, method, dependency or data is added; the change
  narrows an existing content-path rule. The domain rule (`caller_may_reach_domain`) and
  the scope resolver (`effective_scopes`, and the processor's copy held to it by
  t/unit/processor/175) are unchanged, so who is confined, who may write instance-wide
  settings and the sub-user ceiling do not move.

controls
: t/unit/manager/446 (the rule; the token, primary-granted token and unbound cookie
  manager refused another domain's page; a granted domain kept; the operator kept) and
  t/unit/dav/39 (WebDAV, with the real resolver: GET and PUT refused for unbound and
  primary-granted accounts, nothing written; a granted domain and the operator group kept).
  Each fails with the change reverted.

residual risk
: Ruling 137 (2026-11-06) closes what this entry first left: the folder names. A listing
  (the manager's Files, `Manager::Files::action_list`; MCP `list_files`, which answers
  through it with the grant's scopes; WebDAV PROPFIND) leaves out another domain's
  content root for a caller refused it, so a listing of `sites/` no longer names them.
  The operator (the operator group, SM991, confirmed as intended) and an account granted
  the domain still see them. t/unit/manager/446, t/unit/dav/39 and t/unit/mcp/74 each
  fail with the listing's filter reverted. What stays: the manager's file browser roots
  such an account at the docroot, and a folder holding only other domains' roots lists
  as present (its `empty` flag counts them). A content root that is not a folder of its own
  (a secondary domain with no `content_root`) serves the primary's content and is the
  primary's. The WebDAV operator test is `account_is_operator` (the operator group), as the
  manager's cookie operator is decided (SM991); a token is never an operator.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because a content boundary moved and closes a recorded residual risk.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): `Lazysite::Auth::DomainAccess::foreign_root_of` is asked by
  `Manager::Common`, `Manager::Files`, `lazysite-manager-api.pl`, `lazysite-mcp.pl` and
  `lazysite-dav.pl`, and t/unit/manager/446, t/unit/dav/39 and t/unit/mcp/74 are on the
  tip. No trigger fires. It closes the residual risk SM1332-SM1334's entry recorded
  (ruling 126); a STRIDE row records it. OBLIGATIONS.md gains an operate-side row: grant
  the domain an account relied on.

### 2026-11-06 - SM1379 (0.16.6): the quarantine reads email fields for probes and leaves them out of the repetition rule

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: The form handler's quarantine (`extensions/form-handler.pl`, `_spam_assessment`) gains
  one signal and corrects another. An email field (named so, or holding only an address)
  that holds a quote, an SQL comment marker or SQL-shaped text quarantines
  the submission, the reason naming the field and never the value. Ruling 138
  (2026-11-06): a single apostrophe in an address's local part passes
  (`o'brien@example.org`); double quotes, backticks, a second apostrophe or one outside
  the local part, SQL comments and SQL-shaped text still quarantine. SM913 S3's "one value
  in every field" rule leaves email fields out, so a random address no longer defeats it.

threat delta
: Abuse detection widened on a public, unauthenticated surface. Quarantine stores and
  flags; nothing is refused, so a false positive costs a message read from the
  Quarantine filter instead of the bell; the commonest one, an address with a legal
  apostrophe, is no longer one (ruling 138). A probe made of one apostrophe in an
  otherwise plain address passes; it carries no SQL, which the other shapes read.
  The probe's text is stored as submitted, as before, and is never interpolated into a
  query: storage is the file and table handlers' own, unchanged. The stored reason holds
  the field name only. No trigger of ADR 0007's four fires: no interface,
  authentication method, dependency or data processing is added.

controls
: t/unit/forms/75 posts built probes and honest addresses through the handler and
  asserts each outcome; each part, reverted, fails it. t/unit/forms/23 still passes.

residual risk
: A heuristic: a probe written without any of the listed shapes is not seen, and a form
  that names its email field otherwise and posts a non-address is read only by the
  value test (which a probe with spaces fails). A form with a rules sidecar declaring
  `type: email` refuses a non-address there first (SM934).

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because what a public form's quarantine reads moved.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): the quarantine is `_spam_assessment` in
  `extensions/form-handler.pl`, and t/unit/forms/75 is on the tip. No trigger fires.

### 2026-11-06 - SM1377 (0.16.6): the data endpoint refuses a query parameter it does not read

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 140).

what changed
: `/cgi-bin/lazysite-data.pl` answered a read carrying a query parameter outside
  `table`, `order_by`, `order`, `limit`, `offset` and `csrf` with 200 and every row the
  caller may read, naming the parameter in `ignored` (SM606). It now answers 400,
  `kind: unknown-parameter`, before any value is read or any row resolved. `_` (a
  cache-buster) is accepted and unread.

threat delta
: None to access. The endpoint still resolves as the visitor with no operator bypass
  (SM476), so what a caller may read is unchanged; what changes is that a script asking
  for a subset by an unsupported filter is refused instead of handed the whole readable
  table as if filtered, which an app scoping rows by a column displayed. The refusal
  names only the caller's own parameter names and the four the endpoint reads. No
  trigger of ADR 0007's four fires: no interface, authentication method, dependency or
  data processing is added; an existing endpoint refuses more.

controls
: The read set is one declared list in lazysite-data.pl; t/integration/355 asserts the
  refusal, `_`, and the four parameters, and fails with the change reverted.

residual risk
: Ruling 139 (2026-11-06) closes what this entry first left: the control API's
  `data-rows` action, reached only with `manage_data`, refuses an unknown parameter the
  same way (400, `kind: unknown-parameter`), reading only what its declaration lists
  (`table`, `order_by`, `order`, `limit`, `offset`) and `action`, with `_` and
  `csrf_token` accepted and unread; t/integration/355 fails with it reverted.

verdict
: accepted, confirmed by the release manager on 2026-11-06. No trigger fired; recorded
  because what a public endpoint answers moved.

walked
: At the 0.16.6 compliance walk (2026-11-06), against the code on the stack's tip
  (41c47b006): the endpoint's read set is one list in `lazysite-data.pl`
  (`table order_by order limit offset csrf _`), and `data-rows`'s is
  `_data_rows_unknown_parameters` in `lazysite-manager-api.pl` (the declaration's
  parameters, `action`, `_`, `csrf_token`); t/integration/355 is on the tip. No trigger
  fires. OBLIGATIONS.md gains an operate-side row: a site's own scripts that send a
  parameter the endpoint does not read.

### 2026-11-06 - SM1375, SM1378 (0.16.6): the 403 page's group list and a layout's engine requirement, with no trigger

Assessment drafted by the developer agent at the 0.16.6 compliance walk; confirmed by the release manager on 2026-11-06 (ruling 142). The rest of 0.16.6 moves no control: SM1376 is a filing (file write-back to a source's API, a candidate for 0.17.0) and SM1350's commit is its umbrella's row; SM1380 is this walk. The other changes of 0.16.6 have their own entries: SM1369 (firing new-external-interface, ruling 134), SM1362 (firing new-processing-of-restricted-data, ruling 140), SM1366, SM1370-SM1374, SM1377 and SM1379.

what changed
: SM1375, the 403 page. The shipped `templates/system/403.md` writes the groups a page
  needs as an HTML list (`<ul class="auth-required-groups">`, one `<li>` per group), on a
  front-matter group gate and on an `auth/acls.json` read-list refusal alike, where the
  Markdown list never started. A site's own `403.md` is unchanged.
: SM1378, a layout's engine. `requires.lazysite` in a layout's `layout.json` is read when
  the layout is installed (Upload, MCP `install_layout`), activated, or bound to a domain
  (`domain-set` with `layout`), by `Lazysite::Manager::Themes::layout_engine_requirement`;
  when the site's engine (`.install-state.json`) is older, or the value is not a version,
  the answer carries `requires` and a `warning` naming both, and a WARN log line. It goes
  ahead either way.

threat delta
: None of ADR 0007's four triggers fired: no new interface (a field and a warning on
  existing answers; a template's markup), no new sign-in method, no new dependency and no
  new restricted data. The questions are these.
: SM1375: Tampering, by markup in a group name reaching the 403 page. Found at this walk:
  `auth_required_groups` is not among the values the stash escapes. SM709 escapes
  `auth_user`, `auth_name`, `auth_email` and each of `auth_groups` at the one point they
  enter the stash (`lazysite-processor/render.pm`), and `auth_required_groups` enters raw
  with the rest of `%AUTH_CONTEXT`, where SM1375's commit says the stash escapes it.
  Measured on the tip: a read list naming `@<i>bad</i>` in `auth/acls.json` renders
  `<li><i>bad</i></li>` on the 403 page of a refused signed-in visitor. It is not new with
  SM1375: before it the same value reached the page unescaped after Markdown had run, on
  the read-list path since SM1365 (0.16.5) and on the front-matter gate's path before
  that. Who writes it: a read list's names are written by whoever may set the folder's
  rule. Group names the users tool makes are `[A-Za-z0-9_-]`, but a rule's `@name` is not
  checked for shape (an unknown name beside a known one is stored and reported, SM912). A
  front-matter `auth_groups` name is: `Lazysite::Validate` reads `[A-Za-z0-9_.-]` only, and
  a name with markup makes the rule unreadable, refused with a sentence that names no
  group. A rule's writer can already put markup in a page it writes (a page's content
  passes HTML through, by design; boundary 4), so nobody gains a power they lacked; what
  differs is that a rule's name renders on the 403 of every page in its folder.
: SM1378: the warning quotes a layout's own `requires.lazysite` value and name in a JSON
  answer to the manager, MCP and the control API, never into a page; a layout is trusted
  code by boundary 4, installed by a holder of `manage_layouts`.

controls
: SM1375: t/integration/350 renders both refusals and finds the list. SM1378:
  t/unit/manager/470 (older, equal, newer, absent and malformed requirements, on install,
  activation and a domain's layout); the version compared is the installed engine's, read
  from the install state, never from a request.

residual risk
: SM1375: closed in 0.16.6 by ruling 141, which escapes `auth_required_groups` where the
  stash is built (the next entry). SM1378: the warning is advice; a
  layout that needs a newer engine is installed and served, and may render without parts
  of itself until the engine is upgraded.

verdict
: accepted, confirmed by the release manager on 2026-11-06 (ruling 142). No trigger fired; recorded because what the 403 page renders,
  and how it is escaped, was found at this walk to differ from what its change says.

### 2026-11-06 - SM1375, ruling 141 (0.16.6): the 403 page escapes the groups it names

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-06 (ruling 141).

what changed
: `auth_required_groups`, the groups a refused page needs, which the 403 page lists
  (SM1375), is HTML-escaped where `lazysite-processor/render.pm` builds the stash, with
  the same `_esc_html` SM709 gives `auth_user`, `auth_name`, `auth_email` and
  `auth_groups`. It entered the stash raw, so an `auth/acls.json` read list naming a group
  with markup rendered that markup on the 403 page (the previous entry, found at the
  0.16.6 compliance walk).

threat delta
: Tampering, narrowed: a read list's names reach the 403 page as text. Hardening, not a
  vulnerability fix: the names are written only by accounts that can already put markup
  in a page (boundary 4), and a front-matter gate's names were already shape-checked. No
  trigger of ADR 0007's four fires: no interface, method, dependency or data is added.
  `%AUTH_CONTEXT` stays raw for access control; only the rendering copy is escaped, as
  SM709 rules.

controls
: t/integration/356 renders an `auth/acls.json` read list naming `@<i>bad</i>` for a
  refused signed-in visitor and finds `&lt;i&gt;bad&lt;/i&gt;` in the list and no
  `<i>bad</i>` on the page; it fails with the escape removed. The same test holds that a
  front-matter gate naming markup is refused naming no group, and that a plain gate's
  list is unchanged; t/integration/350 still passes.

residual risk
: A site's own `403.md` that prints a group name with the `| none` filter, or reads
  `%AUTH_CONTEXT` another way, is the site's own markup.

verdict
: accepted, confirmed by the release manager on 2026-11-06 (ruling 141). No trigger
  fired; 0.16.6 stays edge and not security-critical (ruling 142).

### 2026-11-07 - SM1369 X2 (0.16.8): an extension's capabilities and actions reach core's tables from the index

Assessment drafted by the developer agent (n768); confirmed by the release manager on 2026-11-08 (ruling 177).
Rulings 71 (D-6) and 135; the design is the extension-hooks proposal's H-7 and H-9.
Ruling 134 asked X2 to reassess X1's new-external-interface finding when the first
caller lands; this is that caller.

what moves
: Out of core: the ten Odoo rows of `%GATE` and `%ACTION`, the ten `elsif` branches of
  the manager API, the ten `%TOOLS` entries of the MCP server, `settle_odoo_writes` in
  `@CAP_KEYS`, the capability map, the check's list and the two grids, and the Odoo
  refusal kinds of `%REFUSAL_STATUS`. Into the extension's descriptor
  (`extensions/odoo.pl`, `owns.hooks`): `capability_info` (two capabilities, one new:
  `manage_odoo`, topped up from `manage_connectors` by the upgrade and on next use), `api_actions` (ten rows, each with
  its gate, its twin's description and schema, and a handler in
  `extensions/odoo/lib/Lazysite/Odoo/Actions.pm`) and `refusal_kinds`. Into core: the
  validators (`Lazysite::Extensions::Hooks`), a `declared` view of the index built from
  every installed extension's descriptor, one mirror that fills the four tables from it
  once per process, one table-driven branch per door, and the loader call that runs the
  handler.

the boundary
: No action without a gate row: the index build refuses a row with none, an ALWAYS row
  with no reason, a row whose name or twin is not prefixed by the extension's id, a row
  or capability or refusal kind that names something core has, a cookie gate weaker
  than the token gate, a twin requiring what the action does not; the extension is then
  not enabled (X1's C-7), and the mirror refuses the same things a second time from a
  hand-edited index. Every declared row then meets every rule a core row does, because
  it is the same row in the same tables: the token gate, the CSRF gate, the required-
  parameter check, the instance-wide and scope rules, the audit decision and the parity
  lints (14, 23, 52, 58, 90, 98, 218) all read the merged table. A declared action runs
  only through `Lazysite::Extensions::Declared::run_action`: the extension must be on in `lazysite.conf` at the
  call (a stale index answers "this extension is off" and runs nothing), its hooks
  indexed, its handler a file in its own payload lib found nowhere else on `@INC`. A
  capability is grantable while its extension is installed and never shadows a core
  name. The request path reads one file; nothing runs `--describe` there.

threat delta
: ADR 0007's new-external-interface trigger, which X1 found fired by the loader with no
  caller, now has its first callers: the two doors run an extension's own Perl in a
  core process for ten actions that were core's own branches before. The code that
  runs is the engine's `Lazysite::Odoo` functions, reached through a thin adapter in the
  payload lib instead of a branch in the door; the identity, capabilities, groups,
  address and door handed to it are what the branches handed before. No sign-in
  method, no new dependency, no new processing of restricted data. The names on the
  wire, the parameters, the hints and the listing are unchanged (t/unit/odoo/136 holds
  them to a 0.16.7 capture). The one grant change is ruling 71's, and the top-up keeps
  every group's reach as it was: the upgrade runs it (ruling 167; absent only, so a 0 an
  operator set stays, and one line names the groups), and the users tool on next use. Tampering: a descriptor or an index that declares a
  core name, or a handler outside the payload lib - refused at the build and again at
  the mirror and the call. Elevation: a declared ALWAYS row that gates nothing - refused
  without a reason, and the extension's own code still decides (the binding, as before).

residual risk
: An extension is Perl running as the site user; the hooks are a contract, not a
  sandbox (the proposal's "What the model does not claim"), and trust comes from what
  is installed, as before. A site whose index build failed keeps the previous index:
  the check says so, and a declared capability stays grantable there until the rebuild.
  Groups saved while an extension is off keep their grant (the declaration is indexed
  while the extension is installed).

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): contained, and
  no trigger fires of its own: the new-external-interface trigger X1 recorded
  (ruling 134) is now exercised, by the same code behind the same names, under the
  same gates. The Odoo handler type is X3's and stays under `manage_connectors` in
  0.16.8 (C-14; ruling 178): the one grant change here is ruling 71's.

### 2026-11-07 - SM1369 X7 part one (0.16.7): Odoo's modules load from the extension's payload lib

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (ruling 149).
Ruling 135; the design is the extension-hooks proposal's Packaging and "Upgrade for a
site already using Odoo".

what changed
: Odoo's modules (`Lazysite::Odoo`, `Lazysite::Odoo::*`, `Daemon::Service::Oomd`,
  `Daemon::Service::OdooEndpoint`) move from `lib/` to the extension's payload lib,
  `extensions/odoo/lib`, installed at `{DOCROOT}/../extensions/odoo/lib`. Core's lines
  that call them now load them with `Lazysite::Extensions::require_payload`: the copy in
  the payload lib beside the lib core was loaded from, put on `@INC` by the X1 rule
  (appended). The processor's `_lazy_lib` and the manager's config validator fall back
  to it for a module that is not core's. The upgrade removes the old copies and the
  directories they emptied.

threat delta
: None of ADR 0007's four triggers fires. The same code runs in the same processes as
  before, from a new directory. No interface, sign-in method, dependency or data is
  added, and nothing is gated differently: whether Odoo is on stays each caller's
  question. The questions are Tampering and Elevation of privilege by a module found in
  the wrong place. One is a stale copy an earlier release left in core's lib, which
  would shadow the payload's. Another is a module planted in a second payload lib, or a
  payload linked in from elsewhere.

controls
: `require_payload` loads only a regular file in exactly one payload lib. Each payload
  lib is a real directory at each step, beside a descriptor, under the engine's own
  `extensions/`. The module must resolve nowhere else on `@INC`, or it is refused by
  name and nothing loads. The payload lib is appended to `@INC`, so it cannot replace a
  core module. The name must be a module name. t/unit/extensions/75 covers a stale copy
  in core's lib, two payloads, a linked payload, a missing descriptor and a bad name.
  t/lint/335 holds that core's `lib/` holds no extension module and that no core file
  loads one but through the rule. t/tools/335 upgrades a site from the old layout and
  checks the old copies are gone.

residual risk
: An edited old copy is kept by the upgrade (its orphan warning). Odoo then refuses to
  load until it is removed: fail closed, an outage rather than stale code. Whoever can
  write the engine tree can change either copy, as before.

verdict
: accepted, confirmed by the release manager on 2026-11-07 (ruling 149): no trigger
  fires and the change is contained.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): core's `lib/` holds no `Lazysite/Odoo.pm`, `Lazysite/Odoo/` or
  `Daemon/Service/Oomd.pm`; the fifteen files are renames into `extensions/odoo/lib/`
  (git reads thirteen as identical, `SiteSignin.pm` and `OdooEndpoint.pm` with the
  SM1381 and depth changes), so the SBOM's component count does not move for them
  (463 at 0.16.7, the one more being `lib/Lazysite/Auth/GroupRefs.pm`, SM1387).
  `require_payload` puts the payload lib on `@INC` with `push`, and no `unshift` is in
  `Lazysite::Extensions`; no core file `require`s an Odoo module but through the rule
  (t/lint/335). The upgrade removes the directories a removed module left empty
  (`install.pl`). The hooks proposal's "X7, part one" section says what shipped: the
  modules moved, the tests and the OOM snapshot kept in `t/` for 0.16.9, no separate
  deb yet (ruling 143). No trigger fires, as the entry says. The walk restates trust
  boundary 12 for the payload lib and adds a STRIDE row (a module found in the wrong
  place), both confirmed by the release manager on 2026-11-07 (ruling 149).

### 2026-11-07 - SM1381 (0.16.7): a stale Odoo site session is renewed through the Odoo endpoint

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (ruling 150).

what changed
: The `odoo-stale` verdict (a site session the Odoo sign-in minted, past
  `odoo_identity_ttl`) carries the extension's renewal path. A protected page that
  meets it redirects to `GET /cgi-bin/lazysite-odoo.pl?renew=1&next=/path` instead of
  to the sign-in. The auth CGI's `?action=session` redirects to `?renew=1&answer=session`.
  The step runs the renewal `?csrf=1` already runs (`_site_state`), once, then answers.
  Renewed: back to `next`, or `signed_in: true`. Odoo has ended the session: both
  sessions end, as on `?csrf=1`, and the step goes to the site's sign-in page
  (`auth_redirect`, else `/login`) with `next`, or answers
  `signed_in: false`. Every answer sets `lzs_renewed=1` (60 s), and a gate that meets
  the verdict while that cookie is held goes to the sign-in instead. The refusal is
  logged at INFO.

threat delta
: ADR 0007's new-external-interface trigger fires. `?renew=1` is a new GET action on a
  public endpoint. With no token, it can cause one Odoo call and the renewal or end of
  a site session. The other three do not fire. No sign-in method is added: this is the
  existing renewal, reached from a new place. No dependency is added, and no
  restricted data is processed in a new way. The questions:
  - Spoofing and Elevation of privilege: could the step make a session hold more than
    Odoo says?
  - Tampering: could a cross-site request end a victim's session (a forced sign-out),
    or could `next` or the renewal path be an open redirect?
  - Denial of service: could a redirect loop, or repeated renewal requests, drive
    calls to Odoo?

controls
: The step grants only what `_site_state` grants on `?csrf=1`: the record is renewed
  with the groups Odoo now holds, under the group map's capability refusal (SM1160). The
  page gate grants nothing. It changes only where a refusal redirects, and serves the
  page only once the verifier accepts the session.
: Nothing is renewed or ended without the Odoo session cookie. That cookie is
  SameSite=Strict and scoped to the endpoint, so a cross-site request does not carry it.
  Such a request is sent to the sign-in and the session is left as it was.
: `next` passes the sign-in's `sanitise_next`, so a foreign one becomes `/`. The renewal
  path comes from the extension's constant, and core accepts it only as a same-site path
  with a query (the gate and the auth CGI each check its shape).
: The step is GET only, and it calls Odoo only for a session that is stale. Once
  renewed, nothing calls Odoo until the ttl passes again, as with `?csrf=1`.
: The loop guard bounds the redirects to one renewal a minute per browser.
  `?action=session` is answered by the step directly and cannot loop.
: t/unit/odoo/135 covers each of these: renewal and the page served; an ended session
  to `/login` with `next`; `?action=session`; the guard; no Odoo cookie, nothing ended
  and no call; a foreign `next`; POST refused. t/unit/auth/74 covers the auth CGI's
  redirect.

residual risk
: A visitor holding a stale session can make one Odoo call per request to the step,
  as they could already with `?csrf=1`. The rate is no higher than today's. A client
  can set `lzs_renewed` itself, which only skips its own renewal. The step's sign-in
  target is the site's `auth_redirect` (held to a same-site path, else `/login`), as
  the gate's own refusal goes. The pool
  path (the front door's verdict, `renew`) is held by t/integration/293, the plain-CGI
  wrapper's (the gate re-asks the verifier) by t/unit/odoo/135.

verdict
: accepted, confirmed by the release manager on 2026-11-07 (ruling 150): the trigger
  fires and the change is contained, so the ADR 0007 waiver stands.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): `lazysite-odoo.pl` dispatches to `_renew` only when the method is GET and
  `renew=1`; `_renew` passes `next` through `Lazysite::Util::sanitise_next`, and
  `_signin_page` answers `auth_redirect` only when `sanitise_next` returns it unchanged,
  else `/login`; every answer sets `lzs_renewed=1` with `Max-Age=60`; the refusal is
  logged at INFO. In core, `lazysite-processor/auth.pm`'s `_session_renewal` accepts
  the verdict's renewal path only when it matches a same-site path with a query and
  holds no `//`, and sends a visitor holding `lzs_renewed` to the sign-in instead;
  `SiteSignin::renew_path` is the one place the path is written, and core names no
  endpoint (lint 321's list is unchanged). ADR 0007's new-external-interface trigger
  fires as the entry says, and the entry is its assessment. The walk adds the step to
  trust boundary 12 and a STRIDE row (the renewal step reached with no token), confirmed
  by the release manager with this entry (rulings 149, 150).

### 2026-11-07 - SM1383 (0.16.7): the session cookie is an externally relied-on credential format

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (ruling 146).

what changed
: No code. Ruling 132 lets an outside process on the same host share a lazysite
  sign-in by verifying the `lazysite_auth` cookie itself, read-only, and
  `docs/architecture/session-cookie-contract.md` states the format it relies on: the
  HMAC-SHA256-signed `username:timestamp:sid:groups` payload, the legacy
  `username:timestamp:groups` variant valid until natural expiry, the key
  (`auth/.secret` in the engine tree, used as its hex text), constant-time comparison,
  expiry against `session_lifetime`, `revoked.json` (revoked sids, per-user
  `not_before`, the SM1040 `kept` exception), and fresh groups. The format will not
  change silently; a change is versioned, reader before writer.

threat delta
: new-external-interface fires, in a narrow form: no endpoint, method or listener is
  added, but an existing credential format gains a reader outside the engine, and that
  reader holds the signing key. The key is symmetric, so a process that can verify can
  mint a cookie for any account, the operator's included (Spoofing, Elevation): "read-
  only" is a promise about the outside process's behaviour, not a limit the engine
  enforces. The document says so plainly and puts the outside process in the same trust
  as the web server. The other three triggers do not fire: no new sign-in method (the
  sign-in stays lazysite's), no new dependency (the reader needs Digest::SHA only), no
  new restricted data. Assessed contained: the key is already readable by the web server
  and the site user (`0660`, group-shared), and a process granted the same group gains
  no access those two lack.

controls
: t/unit/auth/75 mints a cookie through the real sign-in, verifies it as the document
  describes with Digest::SHA and file reads alone, and requires the engine's verifier to
  agree on every case the document names (current and legacy shapes, attributes, the
  key as text, expiry and a configured lifetime, a removed or disabled account, a revoked
  sid, `not_before` and `kept`, fresh groups, a rotated key, that verification writes
  nothing). It fails when the sid length or the separator changes in `_mint_session`,
  and when the legacy shape stops verifying.

residual risk
: Found while verifying: the same key signs the theme-preview cookie
  (`v1:<exp>:<layout>:<theme>:<user>`) and the CSRF tokens, with no domain separation
  from the session payload. A preview value parsed as a legacy session cookie for an
  account named `v1` with the preview's future expiry as its timestamp; measured on
  792a0413b with `tmp/n763-preview-as-session.pl`, it verified as that account, with
  that account's groups, when such an account existed. The verifier also accepted a
  timestamp in the future, and its five-field "sliding" branch was unreachable. All
  three are closed on the same branch under SM1390 (ruling 147, the next entry).

verdict
: accepted, confirmed by the release manager on 2026-11-07 (ruling 146): contained.
  Documentation and a test; the format is unchanged.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): the contract document's statements that SM1390 added resolve in
  `Lazysite::Auth::Session` (`PREVIEW_MARKER` is `v1`, `CLOCK_SKEW` is 300, the payload
  is split to five fields, and the marker is refused before anything else is read),
  the constant-time comparison is `Lazysite::Util::const_eq`, and the writer is
  `_mint_session` in `lazysite-auth.pl`, as the document names them; t/unit/auth/75
  holds the rest. No code changed under this entry, and nothing more is asked of the
  release manager for it. The walk restates the assets line (a session cookie as a
  format an outside process may verify) and records the residual risk's three
  findings, closed by SM1390, in one STRIDE row with that entry, confirmed by the
  release manager on 2026-11-07 (ruling 149).

### 2026-11-07 - SM1390 (0.16.7): another signed value is not a session, a future timestamp is refused, and the sliding reader is reachable

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (ruling 149; ruling 147 named the fixes).

what changed
: Hardening of `Lazysite::Auth::Session::verify_session_cookie` and
  `lazysite-processor/gates.pm` `check_preview`, both reading values signed with
  `auth/.secret`. (1) A session payload whose first field is `v1`, the preview cookie's
  marker, is refused as `malformed` before anything else is read; a preview payload
  without exactly five fields is refused as not a preview. (2) A session whose issue
  time, or `seen` time, is more than 300 seconds ahead of the verifier's clock is
  refused as `expired`. (3) The payload is split to five fields, not four, so the
  five-field sliding shape the reader was written for is read as itself (sid, age from
  `seen`) rather than as a legacy cookie with no sid. Nothing issues it.

threat delta
: Spoofing, narrowed. Before: a preview cookie - minted only for a signed-in manager,
  for a layout and theme that exist - was also a session for an account named `v1`,
  carrying that account's groups, valid for the preview's hour; and a session for such
  an account was a preview. Neither crosses a trust boundary a manager is not already
  past, and no site is known to hold an account named `v1`; the fix is that one signed
  value now means one thing. A future timestamp let a forged-key or key-holder-minted
  cookie outlive the lifetime; with the key the holder can mint at will anyway, so the
  refusal bounds a leaked cookie's life, not the holder's power. The reachable
  five-field branch adds a shape the verifier accepts; its fields are checked as the
  four-field shape's are, groups never contain colons, and the two issued shapes parse
  as before (t/unit/auth/76). No trigger of ADR 0007's four fires: no interface,
  sign-in method, dependency or data is added. Chosen over a purpose prefix in the
  signed text, which would change the format every cookie in flight carries and every
  outside reader (SM1383) was just told; the verifiers can tell the shapes apart as
  they are, and the contract document states the rules.

controls
: t/unit/auth/76: a preview value as a session (fresh and expired), a future `ts` and
  `seen` outside and inside the 300 s skew, the five-field cookie with its sid and its
  age from `seen`, and the current and legacy shapes still verifying; t/integration/361:
  a four- and a three-field value as a preview refused, a five-field preview with an
  empty user still previewing. Each part reverted fails its test
  (tmp/n763-sabotage-2.sh). t/unit/auth/75 (the contract) still passes; t/unit/auth/16's
  groundwork assertion now describes a branch that runs.

residual risk
: An account named `v1` cannot be created: every door that creates or renames an
  account (`lazysite-users.pl add`, `rename`, `account-create`; the manager's Users add
  and an import's approval go through add; an import's `stage_accounts`) refuses the
  name with a reason naming the marker, asked of the verifier's own constant
  (`PREVIEW_MARKER`), never a literal (t/unit/users/71). An existing one, if any, is
  named by `lazysite check` with the rename as its remedy (t/tools/333); it cannot sign
  in until renamed. The CSRF token shares the key but never travels with its payload.
  Sliding expiry has a reader and no writer.

verdict
: accepted, confirmed by the release manager on 2026-11-07 with the 0.16.7 walk
  (ruling 149). Hardening, not a vulnerability fix; no trigger fired.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): the three rules are where the entry says, in
  `Lazysite::Auth::Session::verify_session_cookie` (the `PREVIEW_MARKER` refusal at the
  top of the verifier, `CLOCK_SKEW` 300 against `ts` and `seen`, `split /:/, $payload,
  5`) and in `gates.pm`'s `check_preview` (five fields); the account doors ask
  `_reserved_reason` in `tools/lazysite-users.pl` (add, rename, account-create) and
  `Lazysite::Manager::AccountImport` reads the same constant; `lazysite check` names an
  existing account. Judged at this walk against the vulnerability-handling row
  (OBLIGATIONS.md): a preview cookie is minted only for a signed-in manager, no site is
  known to hold an account named `v1`, and a holder of the key can mint at will, so the
  walk records 0.16.7 as edge and not security-critical, SM1390 a hardening by ruling
  147, confirmed by the release manager with this entry (ruling 149). The walk's STRIDE
  row (one key, three payloads) is confirmed with the SM1383 entry (ruling 149).

### 2026-11-07 - SM1387 (0.16.7): a group is deleted on every door, once nothing uses it

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (rulings 149, 151).

what changed
: A new action deletes access state. Control API `group-delete` (in %GATE behind
  `manage_users`, mutating, destructive, access-changing, audited with the group as
  `@group`), its MCP twin `delete_group`, and the manager's Groups page, which now calls
  it. `Manager::Groups::group_delete` refuses the operator group (the `manager` flag or
  nested into one) to everyone, and to a domain-confined caller any group it did not
  create with `group-set`; the users tool's `group-delete`, the store's owner and the one
  writer, refuses the operator group too, a group with any member, and a group anything
  names (`Lazysite::Auth::GroupRefs`: a page's `auth_groups`, an access rule's `@group`,
  a domain's `allowed_groups` / `locked_groups`, `auth_group_map`, a table's
  `writable_by`, an Odoo binding's or a connector's `callers`, `odoo_group_map`), naming
  each. A store that cannot be read refuses.

threat delta
: Before it, the cookie Groups page deleted an empty group that rules still named; the
  rule then admitted nobody through the name, and a group created later under it (by
  any `manage_users` holder, a token included, SM1050) inherited every grant those rules
  made - a privilege a later creator was never given. Refusing while anything names the
  group closes that, on every door. The new token and MCP reach is bounded: a confined
  caller (every token and MCP grant) deletes only groups it created, and only empty,
  unreferenced ones, so it removes nobody's access. The operator group cannot be
  deleted (SM991), so no door removes the site's operator. ADR 0007: new-external-
  interface is the trigger to weigh - one control-API action and one MCP tool, on the
  existing authenticated doors and gate, deleting only what nothing uses; no new
  authentication method, dependency or data processing.

controls
: t/integration/357 drives the cookie operator, a confined token, an MCP grant and an
  account without `manage_users` through each refusal and each of twelve reference
  places; with the users tool as on main every reference case fails. t/lint/98 counts
  126 token actions; t/lint/218 lists `group-delete` as not instance-wide with its
  reason; t/lint/23 pairs the twin.

residual risk
: A reference the walk does not know is not refused: the places are those surveyed in
  SM1387 and listed in GroupRefs; a new store naming groups must be added there (as
  AddressRefs is extended for profiles). A group named only in a sign-in session's copy
  of the account's groups is not counted; the session refreshes at the next sign-in.

verdict
: accepted, confirmed by the release manager on 2026-11-07 (rulings 149, 151): a new
  action on an existing authenticated door is not a new external interface, and the
  assessment above holds.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): `group-delete` is in `%GATE` and the capability map (`manage_users`),
  `delete_group` is in `lazysite-mcp.pl`, `Manager::Groups::group_delete` holds the
  operator-group and confined-caller refusals, the users tool answers `in-use` with
  `members` or `references`, and `Lazysite::Auth::GroupRefs::refs` reads the places the
  entry lists (a page's `auth_groups`, `acls.json`, `lazysite.conf`'s primary and
  `alias.<host>` rows and `auth_group_map`, a table's `writable_by`, `handlers.conf`'s
  Odoo callers, `connectors.json`'s callers, `odoo.conf`'s `odoo_group_map`); the
  Groups page calls `group-delete`. The audit row carries `@group`. On the trigger the
  entry leaves to be weighed: the walk reads a new action on an existing authenticated
  door, under the existing gate, as no new external interface, as the actions of
  SM1332-SM1334 and SM1240 were recorded; the release manager ruled it so on
  2026-11-07 (ruling 151), and the entry's assessment holds. The walk adds a STRIDE row
  (a group deleted while something names it), confirmed by the release manager (ruling
  149).

### 2026-11-07 - SM1393 (0.16.7): the agent roles and the shipped bundles reach a site the mark never reached

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (ruling 149).

what changed
: The two adoptions in the users tool (`_adopt_added_bundles`, SM1118/SM1241/SM1262;
  `_adopt_agent_roles`, SM1371) ran only where some group record carried `seeded`. A
  site bootstrapped before 0.11.3 wrote the mark, or whose manager group
  `_migrate_conf_manager_groups` wrote without it, carries the mark on no record and
  adopted nothing from any release. Both now run on a bootstrapped site (a record with
  the `manager` flag, `_bootstrapped`). Which records count as shipped
  (`_shipped_groups`) is read from the manager group, which no adoption writes: where a
  manager group carries the mark, shipped is marked, SM608's reading; where none does,
  shipped is present under a shipped name. The bundles still need the bundle layer (one
  shipped bundle present), are nested only into shipped roles present, and every
  adoption is once, through `bundles-adopted.json`, which an unreadable record stops.

threat delta
: Elevation of privilege is the question. A role is adopted with no member, so no
  account's capabilities change (t/unit/users/72 holds the groups file). A bundle is
  nested into the roles that draw on it: on a marked store, only marked ones, as before;
  on an unmarked store, roles present under the shipped names - which on such a store
  are the roles the tool seeded, the mark having not existed to be written. The case a
  name alone could get wrong - an operator's own group under a shipped name - is kept
  where it can be told (the marked store, t/unit/users/72 subtest 4); on an unmarked
  store it cannot be told, and the bundle a role of that name would gain is the one a
  fresh site nests into it. No trigger of ADR 0007's four fires: no interface, method,
  dependency or data is added; the stores and their modes are unchanged.

controls
: t/unit/users/72: a site with manager groups and no mark adopts the four roles and the
  three bundles once, as shipped, with no member; a deleted role and a deleted bundle
  stay deleted; an unreadable record adopts nothing; on a marked store an operator's
  unmarked `analysts` is not nested into; a site with a manager group and no role layer
  gets the roles and no bundle; a store with no manager group adopts nothing. With the
  guard as on main, subtests 1, 2 and 5 fail. t/unit/users/56, 70, 39 and
  t/integration/321 pass unchanged; t/unit/users/34 and t/unit/manager/159 hold that the
  SM576 `assignable` backfill, now run before the adoptions, still reaches a store that
  predates the flag.

residual risk
: `reset-groups` and `group-reset` restore only a marked group, and the Groups page's
  "shipped" badge reads the mark, so on a pre-mark site those still answer as before;
  reported in SM1393's filing, not changed here. A store first written by `group-create`
  or `group-set` before any seeding read never seeds (the seed runs only where the file
  is absent); such a store has no manager group until `setup-sysop`, which marks it.

verdict
: accepted, confirmed by the release manager on 2026-11-07 (ruling 149); no trigger
  fired.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): `_bootstrapped` and `_shipped_groups` guard both adoptions in
  `tools/lazysite-users.pl`, and `_shipped_groups` reads the mark from the manager
  group, which neither adoption writes; t/unit/users/72 holds that an adopted role has
  no member. No trigger fires. The walk restates the 0.16.6 operate-side row (which
  roles a site keeps) for a site the mark never reached, where the four roles and the
  bundles appear at the first users-tool read after the upgrade.

### 2026-11-07 - SM1392 (0.16.7): the editor opens a form's own conf, and every door names manage_forms for it

Assessment drafted by the developer agent; confirmed by the release manager on 2026-11-07 (rulings 149, 152).

what changed
: `starter/manager/edit.md`'s `isReservedPath` exempts `lazysite/forms/<name>.conf`
  (`isFormConfPath`, never `smtp.conf`, `handlers.conf` or `schedule.conf`), so the page
  asks the server's `read` and `save`, whose gate (`carveout_requirement`,
  `Manager::Files::_form_conf_refusal`, SM1371) requires `manage_forms`. In
  `lazysite-mcp.pl`'s tool gate, `read_file` and `write_file` on a path
  `form_conf_name` recognises ask `manage_forms` in place of the tool's `manage_content`,
  as a `lazysite/layouts/` path asks `manage_themes or manage_layouts`; the carve-out
  pass and the write's rules (targets naming existing handlers, reach, bindable handlers)
  run after it unchanged.

threat delta
: The editor change moves a client-side stop to the server's gate: the page could never
  grant anything (the `read` and `save` actions decide), so a manager without
  `manage_forms` now sees the server's refusal where it saw the page's text. The MCP
  change widens one door for one grant: `manage_forms` without `manage_content` now
  reads and writes a form's own conf through `read_file`/`write_file`, which it has
  done over WebDAV since 0.8.1 and which the cookie `read`/`save` already allowed; the
  file names handlers and nothing else (`form_conf_problems`), and the three non-form
  files stay with the blocklist. `manage_content` without `manage_forms` is refused as
  it was, now told the capability the path needs. Every other path keeps the tool's
  capability (t/unit/manager/475: a page still needs `manage_content`). The tool
  listing, ruling 152: a `manage_forms`-only grant is now OFFERED `read_file` and
  `write_file`, with each description saying it reaches a form's own configuration and
  nothing else - discovery widened to match the gate, through the one declaration
  (`cap_path`) the gate reads, so the two cannot disagree; no other tool and no other
  path shape is offered to a path grant (t/unit/mcp/75). What a grant can DO is
  unchanged by the listing. No trigger of ADR 0007's four fires.

controls
: t/unit/manager/475: the rule's source and, under node, thirteen paths through
  `isReservedPath`; the Files page's link for a `.conf`; over MCP a grant holding
  neither is refused `needs manage_forms` (not `manage_content`) and a page still
  `needs manage_content`; `manage_forms` alone reads and writes the conf and nothing
  else; the cookie `read` without `manage_forms` names it. With the change reverted the
  rule reserves the conf and the MCP refusal names `manage_content`.
  t/unit/manager/461, 137, t/unit/mcp/23, t/lint/90 and 92 pass unchanged.

residual risk
: The editor's exemption is by path shape; a site that keeps a non-form `.conf` under
  `lazysite/forms/` by another name opens it to `manage_forms` on every door already,
  the editor now included.

verdict
: accepted, confirmed by the release manager on 2026-11-07 (rulings 149, 152); no
  trigger fired.

walked
: At the 0.16.7 compliance walk (2026-11-07), against the code on the stack's tip
  (58d5d6e26): `isFormConfPath` and the exemption are in `starter/manager/edit.md`,
  and `lazysite-mcp.pl`'s tool gate asks `manage_forms` for a path `form_conf_name`
  recognises; the server's `read` and `save` gate is SM1371's, unchanged. No trigger
  fires. The question the filing leaves - whether `read_file` and `write_file` should
  be offered to a `manage_forms`-only grant in the tool listing (SM210's shape) - was
  ruled on the same day: from ruling 152 the two tools are offered to that grant for a
  form's own configuration alone, through the `cap_path` declaration the gate reads,
  which widens discovery and nothing a grant can do (SM1392's second commit, its
  register entry's threat delta, t/unit/mcp/75).

### 2026-11-07 - SM1385, SM1389, SM1391 (0.16.7): a theme deleted by its path, the check's walk past the history repository, and a schedule entry under the floor, with no trigger

Assessment drafted by the developer agent at the 0.16.7 compliance walk; confirmed by
the release manager on 2026-11-07 (ruling 149). The rest of 0.16.7 moves no control: SM1382 is a
spike and a documented recipe (live data), SM1383 has its own entry, SM1384 is a
filing (a connector cannot express a job protocol, a candidate), SM1386 adds a warning
to a theme install and SM1388 a sentence to a refusal; SM1394 is this walk. The other
changes of 0.16.7 have their own entries: SM1369 X7 part one, SM1381 (firing
new-external-interface, ruling 150), SM1383 (ruling 146), SM1390 (ruling 147), SM1387
(ruling 151), SM1393 and SM1392 (ruling 152). 0.16.7 is edge and not security-critical
(ruling 149).

what changed
: SM1385, a theme deleted by its path. `delete_theme` (MCP), `theme-delete` (control
  API) and the manager's Themes page found a theme only under the active layout;
  `action_theme_delete` now takes `lazysite/layouts/<layout>/themes/<name>` as
  `theme-copy` does (SM1339), the bare name still meaning the active layout's theme.
  The active theme, a theme any domain serves under that layout and, for a
  creator-restricted caller, a theme another account made are refused by path as by
  name; a path into a served copy is refused by `served_artifact_refusal`, naming its
  source. Lint 218: the action now asks the domain rule through the served-artifact
  rule.
: SM1389, the check's stray-copy walk. `lazysite check`'s `report_stray_public` walked
  the whole private store, so the SM1324 history repository (`<store>/lazysite/git`)
  matched the docroot's content-history repository file for file and the 0.16.6 edge
  deploy reported the site not serviceable. The walk now prunes that one repository,
  found by `ProtectedHistory::history_git_dir`; a layout a rule moved into the store's
  `lazysite/layouts` is still walked and a copy beside it still reported.
: SM1391, a schedule entry under the floor. A hand-written `every:` below 300 seconds
  in `schedule.conf` was passed over in silence; the first tick that meets it records a
  refusal against the entry in `lazysite/daemon/schedule-runs.json`, naming the value
  and the floor, and logs it at WARN; later ticks write nothing for it; `lazysite
  check` names each such entry with the remedy.

threat delta
: None of ADR 0007's four triggers fired: no new interface (an existing action takes a
  path; a check and a daemon record say more), no new sign-in method, no new
  dependency and no new restricted data. The questions are these.
: SM1385: Elevation of privilege, by a delete reaching a theme the caller could not
  delete by name. The refusals are the same checks asked by path: a path into a served
  copy by `served_artifact_refusal`, the active theme by the active pair, a theme a
  domain serves by `_domains_using`, another account's theme by `_theme_creator` for a
  creator-restricted caller; what is new is that a theme under a layout no domain
  serves can be removed at once rather than file by file over WebDAV, which
  `manage_themes` could already do.
: SM1389: Information disclosure, by a public copy the check no longer reports. Only
  the history repository is pruned, which is inside the private store and never
  served; a stray copy anywhere else in the store, a moved layout's included, is
  reported as before.
: SM1391: Denial of service, none: an entry under the floor never ran and still does
  not; what changes is that it is recorded once, and `lazysite check` names it, where
  it was silent.

controls
: SM1385: t/unit/manager/471 (by path under another layout; the active, served and
  creator refusals by path; a served copy's path refused naming its source). SM1389:
  t/tools/04 (the repository pruned; a copy beside it still reported). SM1391:
  t/unit/daemon/17 (refused once, recorded, runs at the floor), t/tools/332 (the check
  names it); t/integration/360's floor subtest.

residual risk
: SM1385: a theme deleted under an inactive layout is gone with its history as a theme
  deleted by name was; the page's Delete under every layout is the same destructive
  action, declared so (lint 109). SM1389: none beyond the pruned repository. SM1391: a
  refused entry's record stays in `schedule-runs.json` until the entry is raised to the
  floor and runs.

verdict
: accepted, confirmed by the release manager on 2026-11-07 (ruling 149). No trigger
  fired; recorded because SM1385 widens where a destructive action reaches and
  SM1389 narrows what a check reports.

### 2026-11-07 - SM1369 X3 (0.16.8): page sources and delivery handler types are declared by the extension

Assessment drafted by the developer agent (n769); confirmed by the release manager on 2026-11-08 (ruling 177).
Ruling 55; the design is the extension-hooks proposal, H-2 and H-3; the first callers of
the X1 loader (boundary 15), on the request path and in the handler catalogue.

what changed
: H-2. An enabled extension's `owns.hooks.page_sources` declares a page-variable prefix
  (`x: odoo:shop-list`), a `resolve(spec, ctx)` function in its payload lib, an optional
  `check(spec, docroot)` for the page's save, and three flags: `per_viewer`, `live` and
  `read_only` (required, 1). The processor resolves a prefix it does not own (scan:, db:,
  json:, url: are tried first) by calling `resolve` through `Hooks::call_hook` with the
  page, the key, the request address through the trusted-proxy rule, the host, the site
  and mode `render`; the value is made inert by core; a source that dies, cannot be
  loaded, is off or answers nothing is the empty string and one WARN line in one shape.
  `per_viewer` replaces the three `odoo-identity:` peeks (the processor's front-matter
  peek, the offline-app rule in the processor and in the manager): the page takes the
  gated page's cache treatment, and the source is handed the cookie header and the
  request's identity. `live` sets the live-source flag as `url:` does. Odoo's `odoo:` and
  `odoo-identity:` are declared this way; its refusals (a write, a visitor key, an address
  parameter, a session binding, a download) moved into `Lazysite::Odoo::Hooks` unchanged.
: H-3. `owns.hooks.handler_types` declares a type - `label`, `cap`, `schema`, `origins`,
  `parse`, `on_save`, `on_delete`, `deliver` - that `Lazysite::Handlers` merges into the
  catalogue from the site's hook index on every read of it. Core runs `parse` and
  `on_save` at save, `on_delete` at delete and `deliver(h, fields, ctx)` from a form or
  the timer, and keeps handlers.conf, the schema check that refuses an unknown key, the
  cap gate, the schedule and the delivery record. `origins` is where the type may run;
  a delivery from any other origin is refused by core before the extension's code loads.
  Odoo's type is declared this way, with its schema, and its `cap` stays
  `manage_connectors`, as before X3 (C-14; ruling 178: it moves to `manage_odoo` with
  X4 in 0.16.9). The `address_profiles` field type lets
  `AddressRefs` find the profiles a handler names by the field's type and `slot`, not by
  the type name `odoo` (I-13).
: The validator refuses, by name and before anything is indexed: a prefix core owns or
  one declared twice, a source without `read_only`, a type named for a core or retired
  type, a `cap` that is not a capability the engine or an extension declares, an origin
  core has not got, a schema key every handler carries or a field type the catalogue does
  not draw. The build leaves out the later of two extensions declaring one prefix or one
  type name, naming why. No site-facing file changes shape: handlers.conf rows, page
  variables and bindings are as they were.

threat delta
: ADR 0007's triggers: no new external interface (the page variables, the handler
  actions and the timer are the interfaces they were; what is new is which code answers
  them, which boundary 15 already records); no new sign-in method; no new dependency;
  no new processing of restricted data (a per-viewer source reads the cookie the
  `odoo-identity:` render already read). The questions are these. Information
  disclosure: a session credential handed to a source whose render is shared and
  cached, so one viewer's value is the next viewer's page; a per-viewer value reaching a
  render the per-viewer mark did not (a site-wide variable, an error page). Tampering
  and injection: a remote system's records reaching a template as markup or a link
  scheme. Elevation of privilege: a handler type run under a capability it never
  declared, from an origin it did not list, or by the timer's job account without the
  cap. Denial of service: a source that dies or hangs on the render path. Spoofing: two
  extensions claiming one prefix or one type name.

controls
: No credential to a shared render (G-8): the context core hands a source carries the
  cookie header and identity only when the declaration says `per_viewer`, and such a
  page is never read from or written to the page cache and is no-store on output (the
  mark main sets from the peek, `_protected`); a per-viewer source anywhere the mark did
  not reach is refused with a WARN and the empty string (SM857's mechanism). Inert by
  core (G-8): every scalar a source answers is HTML-escaped and made unable to spell a
  link or break JSON before a template sees it, and a reference that is not a list or a
  mapping is dropped. Fails closed (G-9): a source that dies, cannot be loaded, is off or
  answers no value is the empty string with one WARN line naming the prefix, the key and
  the reason; the page renders. The cap rule: a type's `cap` must be in the engine's
  capability list, it gates creating, editing, deleting and scheduling a handler of the
  type as a core type's does, and the scheduler refuses an entry whose job account does
  not hold it (`Daemon::Jobs`, `cap_for_type`, unchanged). The origin gate: `deliver` runs
  only from an origin the type lists; the timer and a form are the two core has. The
  schema check refuses a key the type does not declare, as for a core type. What crosses
  to `deliver` is the visible fields (never a `_`-prefixed key) and a context without the
  handler list or the uploads. Off means off (G-1): a type whose extension is off leaves
  the catalogue, so a saved handler of it is a named problem and is not delivered, and a
  source whose extension is off resolves empty. One owner per name: the build refuses the
  later claimant of a prefix or a type name. The loader's own rules (boundary 15) hold:
  the extension's module, from its payload lib, found nowhere else. t/unit/extensions/79
  (sources, through the real processor), t/unit/extensions/73 (types), t/lint/321 (seven
  core files leave the allow-list), and Odoo's own tests unchanged in what they assert.

residual risk
: What a source reads and what a type does are the extension's own code, under
  boundary 15's contract-not-sandbox: the Odoo source's refusal of a writing operation
  is now Odoo's line, not core's, and a second extension's source is trusted to be the
  read it declares (`read_only` is a declaration core cannot verify). A source's cost on
  the render path is unbounded by core, as `db:` and `url:` are; `live` and `per_viewer`
  keep such a page out of the cache's proof, so a slow source is a slow page, not a stale
  one. The peek that marks a page per viewer is a trigger on the prefix, wider than the
  grammar (a false positive costs a cached render); a per-viewer source the peek cannot
  see (a site-wide variable) is refused at the render, never cached. The manager's copy
  of the offline-app rule reads the same index (t/unit/manager/368 runs both). A page
  naming `odoo-identity:` on a site whose Odoo extension is off now renders the literal,
  where it rendered an empty mapping before; such a page cannot have a cookie to read.

verdict
: accepted, confirmed by the release manager on 2026-11-08 at the 0.16.8 compliance
  walk (ruling 177). No ADR 0007 trigger fires; recorded because the request path and
  the handler catalogue gain their first callers of boundary 15's loader, as the X1
  entry said each slice would be. The Odoo handler type keeps `manage_connectors` in
  0.16.8 (C-14, ruling 178).

walked
: At the 0.16.8 compliance walk (2026-11-08), against the code on the stack's tip
  (d092a5b8c): the Odoo handler type's declaration in `extensions/odoo.pl`
  (`owns.hooks.handler_types`) carries `cap => 'manage_connectors'`, so creating,
  editing, deleting and scheduling an Odoo handler needs `manage_connectors` as before
  X3, while the ten actions X2 moved are `manage_odoo`'s (ruling 71); `schedule` is in
  `@CORE_SOURCE_PREFIXES` beside `scan`, `db`, `json` and `url`, so an extension
  declaring SM1356's prefix is refused by name at the build (f0916415c,
  t/unit/extensions/79).

### 2026-11-07 - SM1369 X5, the asset part (0.16.8): an extension's files and variables reach the page through the index

Assessment drafted by the developer agent (n770); confirmed by the release manager on 2026-11-08 (ruling 177).
Ruling 55; the design is the extension-hooks proposal's H-10 and "How a hook is found
and run".

what changed
: Three hook kinds go live: `assets` (a file in the extension's payload, served by the
  processor at `/assets/<id>-<file>` and at a declared alias, on every domain, and
  added to a page whose rendered markup carries the attribute `inject_when` names, with
  the data attributes an `attrs` function answers), `components` (a component template
  in the payload) and `template_vars` (a layout variable rendered by the extension's
  function). A new processor part, `lazysite-processor/extensions.pm`, reads the hook
  index module-free and reads the enabled list again, and reaches an extension's
  function only through `Hooks::call_hook`. Odoo's helper, sign-in component, banner
  and display name become declarations; the helper and the component move into
  `extensions/odoo/`; the four core lines that knew them leave.

threat delta
: None of ADR 0007's four triggers fires. No new external interface: the asset paths
  are the existing `/assets/` surface, serving files the package already shipped into
  the docroot, now from the extension's payload; a template variable and a component
  are rendered server side as the core ones are. No new sign-in method, no new
  dependency, no new restricted data. The questions are Tampering and Information
  disclosure through what a declaration can name, and Elevation of privilege through
  the code it reaches. A declaration could name a file outside the payload, an alias
  that replaces an engine asset, a variable that shadows a core one, a module that is
  not the extension's, or an attribute that is not a data attribute; an index left
  behind could serve a disabled extension's file.

controls
: A file is one name with an extension, never a path (`_plain_file`), and the index
  build refuses a declaration whose file is not a regular file, not a link, in the
  payload's `assets/` or `templates/components/` (`check_payload_files`); the
  processor serves only a path built from the index's id and the declared name,
  under the payload the index names, re-checked as a regular file, of a type in
  `%STATIC_CT`. An alias is a path under `/assets/` that is not one of the engine's
  own assets (`%CORE_ASSETS`); a variable's name is a plain identifier that no core
  variable uses (`%CORE_VARS`); an injected attribute is dropped unless it is
  `data-*` with a plain value, and its value is escaped. A function is reached only
  through `call_hook`: the extension and what it requires on at the call, the module
  the extension's own and found nowhere else on `@INC` (C-3, unchanged); a function
  that dies answers nothing. The processor reads the enabled list again
  (`_extension_entries`), so an index left behind serves nothing of an extension the
  conf does not list. t/unit/extensions/76 covers each: served at both paths, injected
  once with the escaped attribute and the non-data attribute dropped, nothing when
  disabled or absent from the conf, the two index readers to one answer, and the
  refusals (a file not in the payload, an alias of a core asset, a path as a file
  name, a non-data `inject_when`, a core variable's name).

residual risk
: A shipped extension is trusted code (the proposal's "What the model does not
  claim"): its `attrs` and `render` functions run in the processor as the site user
  and answer what they answer; only the attribute names and the escaping are core's.
  With the extension off the helper is not served, where before the docroot carried a
  copy: a page that loaded it with the extension off loses a script that had nothing
  to talk to.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): no trigger
  fires; recorded because the processor now serves files and renders markup named by
  an extension's declaration, under the checks above.

### 2026-11-07 - SM1396 (0.16.8): the offline kit keeps a person's reads and queued writes in their browser, owned by login

Assessment drafted by the developer agent (n770); confirmed by the release manager on 2026-11-08 (ruling 177).
Ruling 53 (the condition: owned by login, an item with no owner is nobody's), ruling 74.
SM1397 (a favicon fallback: two fixed public bytes-strings, a site's file winning) and
SM1398 (`page_url_raw`, under the SM824 raw-twin contract) move no control.

what changed
: A new extension, `app-offline` (`requires: odoo`), declares one script and one
  template variable through SM1369 X5's hooks. The script wraps the Odoo browser
  helper: it keeps the last good answer to each read, queues a change made with no
  signal (or cut off before an answer) and sends it once the signal is back with the
  `Idempotency-Key` the endpoint already honours (SM1223), and shows the connection,
  the signed-in state and the app's install and update state in a layout's slots. The
  page endpoint's `?csrf=1` answers one more field, `owner`: `Session::login_label`, the
  hash of the login the call records already name a sign-in by, taken from the site
  session's identity (`odoo:<login>`), so only on a site whose Odoo sign-in is the site
  sign-in (`odoo_site_signin: on`; rulings 161, 163). The identity cookie is unchanged
  and carries no label of the login; `?csrf=1` asks Odoo nothing; on a default Odoo
  site there is no owner and the kit keeps nothing. The kit stores what it keeps in the browser's localStorage, under the
  site's origin, keyed by owner.

threat delta
: ADR 0007's new-processing-of-restricted-data trigger fires (ruling 177, which names
  it new processing of personal data): a person's data - the answers a page was given
  for them and the changes they asked to send - is kept in their browser across pages
  and sign-ins, where before it lived only in the page. It is contained by the purge
  at sign-out keyed to the login: the kit wraps the Odoo helper's `signOut` and, for
  the owner label of the login signing out, empties that owner's kept reads in
  localStorage; nothing is kept without an owner, and an owner's items are shown and
  sent only while that login is signed in. The other three triggers do not fire: the
  kit posts to the existing endpoint through the existing helper and header, and no
  sign-in method or dependency is added (the label is what the records already hold).
  The questions are
  Information disclosure on a shared browser (one person's kept answers or queued
  changes shown to, or sent as, another), Tampering of the queue (a change sent twice,
  or a change kept for nobody sent as whoever signs in next). The identity cookie is
  unchanged (rulings 161, 163).

controls
: Owned by login: a kept read or a queued change is stored under the owner the
  endpoint named, shown only while the same owner is signed in, and a flush sends
  only the current owner's queue; a write with no owner is refused (`no-owner`) and
  kept nowhere; signing out drops the person's kept reads. The label is a truncated
  SHA-256 of the login under a fixed prefix (`signin:` + 16 hex,
  `Session::login_label`), made from the verified site session's user and only while
  its Odoo session stands, and checked to that shape before the kit accepts it; it
  names nobody to a reader and authorises nothing. Sent once: every change carries an `Idempotency-Key`, a queued
  change is sent again only with the same key, one flush runs at a time, and an item
  leaves the queue on any answer. The store holds what the endpoint answered a page
  and what the page asked to send: never the visitor token, a cookie (HttpOnly, the
  script cannot read them) or a password. t/unit/extensions/78 drives the kit against
  a 127.0.0.1 endpoint stand-in: two `online` events send each queued change once; a
  cut-off send is sent again with the same key; no owner is refused; another login's
  queue is not sent and stays theirs; another login finds no kept read; sign-out drops
  the reads and keeps the queue; the store holds no token; on a default Odoo site's
  answer (signed in, no owner) nothing is kept, queued or sent. t/unit/odoo/63: on a
  site with the Odoo site sign-in `owner` is the login's label; t/unit/odoo/41: a
  default Odoo site, signed in and named, answers no owner and asks Odoo nothing, nor
  does a visitor; t/unit/odoo/28: the cookie's keys are the contract's, and it carries
  no login label however it is minted.

residual risk
: What the browser keeps is as safe as the browser's storage for that origin: a
  person who leaves a shared device signed in leaves their kept answers readable by
  the next person at that device, as the page itself would be; signing out drops them.
  A queued change waits in storage until its owner signs in again, or the person
  clears the site's data. The kit keeps data only on a site with the Odoo site
  sign-in; on any other Odoo site it keeps nothing, which is the safe failure (SM1396
  K-1, answered by rulings 161 and 163: the identity cookie stays as OI2 states).

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): the
  new-processing-of-restricted-data trigger fires (a person's data kept in their
  browser) and the change is contained by the purge at sign-out keyed to the login and
  by the owner rule above, so the ADR 0007 waiver stands. The identity cookie is
  unchanged (rulings 161, 163).

walked
: At the 0.16.8 compliance walk (2026-11-08), against the code on the stack's tip
  (d092a5b8c): `extensions/app-offline/assets/kit.js` keeps one localStorage item,
  `lazysite-app-offline:v1`, holding `owners`, one bucket of `reads` (at most 50) and
  `queue` (at most 100) per owner; `keep` and the queue write nothing when there is no
  owner, and `askOwner` accepts `owner` from `?csrf=1` only in the `signin:` + 16 hex
  shape. The purge is the kit's wrapper of `LazysiteOdoo.signOut`: once the helper's
  sign-out answers, it sets the signing-out owner's `reads` to empty and clears the
  owner, and leaves that owner's `queue`, which is sent for that owner alone at their
  next sign-in. `lazysite-odoo.pl` answers `owner` from
  `Lazysite::Odoo::Session::login_label` of the site session's `odoo:<login>` user.
  What the purge does not reach: a queued change (kept for its owner, by design), and
  kept reads where the session ends without the helper's sign-out (the site's own
  `/logout`, an expired session, a closed browser), which stay under the owner's label
  and are shown to no other login. Kept reads have no age limit of their own; the
  50-read cap per owner is the bound. Ruling 183 keeps the purge as built and recorded
  here. t/unit/extensions/78 holds the sign-out
  (reads dropped, queue kept) and the owner rules.

### 2026-11-07 - SM1395 (0.16.8): an anonymous public write binding keeps no join

Assessment drafted by the developer agent (n771); confirmed by the release manager on
2026-11-08 at the 0.16.8 walk (ruling 177); ruling 154 asked for the setting.

what changed
: A binding setting `anonymous: 1` on the Odoo extension's bindings
  (`Lazysite::Odoo::Binding::parse`), allowed only with `public` in `modes` and refused
  otherwise naming why. Under it: (1) the call record's line for the call, its
  refusals and its confirm, withdraw and resume (`Lazysite::Odoo::_rec_base`, and
  `_anon_rec` for a record built before its binding is known) is written without
  `ip` and without `visitor`; the binding, the time, the phase, the outcome and the
  idempotency key OOM holds stay, and the shared audit row, read from the same
  record, carries no address either; (2) once the plan is spent - an immediate apply
  as it answers, a confirmed plan when it is confirmed, withdrawn, settled or
  dismissed - the parameters leave the plan and run records
  (`_redact_spent_plan`: in `plan.json`, `run.json`, `result.json` and the journal,
  here and in the daemon's run folder, every value under `params`, `vals`, `before`,
  `after` and `values` is set to null and the keys stay); (3) ruling 160, at the same
  point the visitor's hash leaves them too: `meta.json`'s owner and OOM's own records
  in the plan and run folders (`plan.json`'s `actor`, `run.json`'s `planned`,
  `approval` and `applied` `by`, the journal's and OOM's `audit.jsonl`'s `actor`)
  become `visitor`, with no hash (`_unhash_visitor`). Until the plan is spent its
  owner keeps the hash, so a plan is still confirmed by its maker and nobody else:
  the confirm's ownership check reads it before the apply that spends the plan. A
  spent plan is nobody's: a later confirm or withdraw of it is refused as not found,
  and that refusal line, built once the plan's binding is known, carries no hash
  either. The per-visitor rate cap is unchanged: it counts by the visitor's hash in
  `recent.jsonl`, a rolling hour's counter no call line now joins to. Default off: a
  binding without the setting records as before. (4) Ruling 168: a repeat of a spent
  plan's confirm or withdraw that carries the same `Idempotency-Key` gets the first
  stored outcome back (`Lazysite::Odoo::_spent_repeat`), as SM1223 answers any
  caller: `ok`, `repeat`, the outcome from `result.json` (the plan folder's, or the
  daemon's run folder's), which the redaction has already stripped of values, and
  nothing sent to Odoo. The match is by the plan's own idempotency record - the key
  scoped to binding and sender (`idem_derive`) that `meta.json` keeps as `idem` -
  derived from the request and compared, never by the visitor: no hash is written to
  the line (`_rec_base`, carrying `idem` and `repeat`), the audit row, the plan or run
  records or the rate counter (the repeat takes no rate count, as the not-found it
  replaces took none). A confirm's repeat passes the gate and the plan's hour, as any
  confirm does. Without the key, with another, or from another visitor holding the
  key, it stays not found. The withdraw takes the endpoint's `Idempotency-Key` too,
  checked as a confirm's (malformed, or other than the plan's, refused), and a key
  the first confirm or withdraw carried is kept on a plan made without one.

threat delta
: Information disclosure, narrowed: less processing of personal data, which is the
  point of the ruling. Before, a public write binding kept, for the plan's retention
  (`$PLAN_KEEP_DAYS`) and the call record's 90 days, two records that together said
  who sent what from where: the parameters and the owner hash in the plan store, the
  address and the same hash on every call line. The hash was the join. After, on an
  anonymous binding, no stored record holds the address, and the parameters are gone
  once nothing will read them again, and so is the hash (ruling 160); what remains
  is the hash in a plan waiting for its confirm (at most `$PLAN_TTL`, then the plan
  is refused as expired and kept until its retention ends) and in the rate counter
  for an hour - a pseudonymous key joined to a binding and a time, and to nothing a
  person sent once the plan is spent.
  Nothing is widened: the setting takes nothing away from the gate (mode, switch,
  OOM, connection), the caps, the CSRF token or the plan's ownership; a confirm is
  still refused to anyone but the maker. Repudiation, slightly widened by design: an
  operator reading the record of an anonymous binding can no longer say which
  visitor made which call or from where - the trade the ruling makes, taken only
  where the operator sets it, per binding. Ruling 168 widens nothing: a repeat is
  answered only to a request whose visitor key and Idempotency-Key derive the plan's
  own scoped key, with the outcome that request's first send was already given, and
  nothing reaches Odoo. ADR 0007: no trigger fires - no new interface, sign-in
  method, dependency or data; a setting on an existing door that stores less, and an
  answer on an existing door (the withdraw now reads the header the confirm already
  read).

controls
: t/unit/odoo/139: after an anonymous immediate apply the call line and its audit
  row carry no address and no hash; the plan, run and journal records hold no
  parameter value and keep their field names, fingerprint and outcomes; the setting
  is refused on a non-public binding and for a value that is neither 0 nor 1; the
  per-visitor cap still trips and is counted by the hash in `recent.jsonl`; a
  confirmed plan keeps its parameters until the confirm and loses them after, with
  both lines bare; a binding without the setting records the address and the hash as
  before. Ruling 160: the owner keeps the hash until the confirm, the maker's confirm
  still works, and after it (and after an immediate apply) the owner is `visitor`
  and no file in the plan folder names the hash; a second confirm is not found and
  its line names no hash. t/unit/odoo/137, through the real oomd: the same for a
  confirmed plan and an immediate apply, in both the plan folder and the daemon's run
  folder (which names the hash before the confirm). Fails with the setting reverted
  (the binding cannot be saved) and with the record and redaction reverted (the lines
  carry both, the records keep the values and the hash).
  Ruling 168: t/unit/odoo/138 (in-process) - a repeated confirm with the plan's key
  gets the first outcome (`repeat`, the same counts, nothing sent to Odoo, no value in
  the answer), its line is bare and carries the scoped key, it adds no rate count, and
  no file in the plan folder, call line or audit row names the hash (which the same
  measure finds before the confirm); without the key, with another, or from another
  visitor with the key, not found; a confirm's or a withdraw's own key on a plan made
  without one is kept (scoped, never the caller's) and matched; a withdraw refuses a
  malformed key and one other than the plan's, and its repeat with the key answers
  `withdrawn` and `repeat`, without the key or with another not found.
  t/unit/odoo/137 adds the confirm's repeat through the real oomd, answered from the
  daemon's run folder, with neither folder, the call record nor the audit naming the
  hash. Each fails with the change reverted (every repeat is not found).
  t/unit/odoo/03 (the record takes fixed fields only), 11 (the caps), 12 and 69 (a
  plan's life), 96 and 97 (SM1223) still pass.

residual risk
: Ruling 160 closes what the first draft left: once the plan is spent no record in
  the plan or run folder names the visitor's hash. What remains: a plan that is never
  confirmed, withdrawn or dismissed - one left to expire, or one whose apply left a
  change unknown and is kept for its resume (SM1279) - keeps the owner hash, and the
  parameters, until its retention ends, since it is not spent; the hash is joined
  there to the values a visitor sent but to no address. A file the redaction cannot
  rewrite is left as it is (as `purge_plan_blobs` leaves one), so a failed write
  keeps the hash in that file. The engine's event log carries the
  binding and the operation for a refusal, never the parameters, as before. A page
  that puts personal data into a parameter the operation writes to Odoo puts it in
  Odoo, which this does not touch. A binding switched from anonymous to not keeps the
  records it wrote while anonymous as they are (bare), and vice versa.
  Ruling 168: the scoped key in `meta.json` is a hash of the binding, the visitor's
  hash and the caller's key; it names no visitor, and can be matched only by someone
  holding both the visitor's key and the caller's Idempotency-Key, who learns the
  first outcome they were already given. A repeat answered from a file takes no rate
  count, so its cost is a file read, as a not-found refusal's is. A spent plan whose
  first answer was a refusal (stale, applied elsewhere) has no stored outcome and a
  repeat of it stays not found.

verdict
: accepted, confirmed by the release manager on 2026-11-08 at the 0.16.8 walk (ruling
  177): a hardening (less processing of personal data), no trigger fired.

### 2026-11-07 - SM1413 (0.16.8): a notify handler's recipients may name a group

Assessment drafted by the developer agent (n771); confirmed by the release manager on
2026-11-08 at the 0.16.8 walk (ruling 177); ruling 158.

what changed
: `Lazysite::Outbox`'s recipient grammar gains `{"groups":[...]}`. At send time the
  notify-outbox job reaches every member account of each named group (the group
  store's own walk, `Auth::Settings::group_closure_in`, so nested members count) at
  the address its account record holds. A member with no address is skipped and
  counted (a `no-address` ledger line, the rule's status). A named group must exist
  at save. Authoring a notify handler still needs `manage_notifications`.

threat delta
: None new. A group source reaches the same people an `{"accounts":[...]}` list
  naming them would, at the same addresses, through the same send: one address per
  recipient, once, the per-recipient cap, one audit row each, the unsubscribe link.
  What a group adds is reach that follows membership: a person added to a named
  group, or to a group nested in it, is mailed by the rule from then on without the
  rule changing. Who may change membership is the users tool's existing control
  (conferral and nesting rules, SM268); a group's address limits (SM1140) are a
  request's and do not narrow who the job mails - the job has no visitor. A group
  store that will not open makes the entry retry rather than read as nobody, so a
  fault never silently drops recipients and never widens them. ADR 0007: no trigger
  - no new interface, sign-in method or dependency; account addresses were already
  mailed by rules naming accounts, so no new processing of personal data.

controls
: t/unit/notify/10: direct and nested members each mailed once; a member with no
  address skipped, counted and not audited; the unsubscribe link carried; the cap
  holds; the operator group named and reached; an unknown group refused at save
  naming it. Fails with the groups source removed. t/unit/notify/01-09 unchanged.

residual risk
: A rule naming a large group mails every member: the per-event bound
  (`$MAX_RECIPIENTS`, 5000) and the per-recipient cap apply as for a table source.
  An operator who nests a group inside a named group widens the rule's reach; the
  rule's row does not say how many members it resolves to before it runs (the
  outbox card shows who each queued event resolves to).

verdict
: accepted, confirmed by the release manager on 2026-11-08 at the 0.16.8 walk (ruling
  177): no trigger fired.

### 2026-11-07 - SM1412 (0.16.8): owner_contact is retired

Assessment drafted by the developer agent (n771); confirmed by the release manager on
2026-11-08 at the 0.16.8 walk (ruling 177); ruling 159.

what changed
: `Lazysite::Notify` no longer mails a form's submission notice to `owner_contact` in
  `lazysite/notify.conf` (SM1362, 0.16.6; its 2026-11-06 entry above, ruling 140):
  `_mail_owner`, its call and the built-in templates it used are removed and the key is
  ignored. `lazysite check` names a site that still sets it. No form mails anyone unless
  it names a notify handler (ruling 158).

threat delta
: Information disclosure, narrowed: less processing of personal data. A `notify: full`
  form no longer sends a submission's fields to an address written in a config file; a
  site that wants people told does it through a notify handler, which reaches accounts
  under SM1010's controls (once each, the cap, the audit row, the unsubscribe link).
  Nothing is widened. The SM1362 STRIDE row's owner-mail half ("the site used as a
  mailer") no longer applies; its acknowledgement half stands. ADR 0007: no trigger -
  a removal.

controls
: t/unit/forms/78: with every mail prerequisite in place and `owner_contact` still set,
  a form naming no notify handler mails nobody and stores its submission; fails with the
  owner path restored. t/tools/337: the check names the key with the remedy. SM1362's
  acknowledgement tests (t/unit/forms/68) still pass.

residual risk
: A site that relied on the owner mail on 0.16.6 or 0.16.7 stops getting it at the
  upgrade until it adds a handler; `lazysite check` and UPGRADE.md say so. OBLIGATIONS.md's
  row for "a form's owner address" named `owner_contact`; the 0.16.8 walk restates it
  for a notify handler naming a group (SM1413).

verdict
: accepted, confirmed by the release manager on 2026-11-08 at the 0.16.8 walk (ruling
  177): a hardening (less processing of personal data), no trigger fired.

### 2026-11-07 - SM1354 (0.16.8, PENDING): a page's copy, and publish_copies on existing doors

Assessment drafted by the developer agent (n772); confirmed by the release manager on 2026-11-08 (ruling 177).

what changed
: A page can be copied to `lazysite/copies/pages/<page path>`, the copy changed by path
  like any page, and the copy published over the page or discarded (control API
  `page-copy`, `page-copy-publish`, `page-copy-discard`, `page-copies`; MCP `copy_page`,
  `publish_copy`, `discard_copy`; `preview_page` and the manager's preview render a copy;
  the editor's Copy, Publish, Discard and Undo). `lazysite/copies/pages/` joins
  `Manager::Common`'s carve-outs from the `lazysite/` blocklist, gated `manage_content`.
  A new capability, `publish_copies` (Content section), is needed with `manage_content`
  to publish over MCP or the control API; no seed, top-up, migration or shipped role
  grants it (`Auth::Settings::@OFF_BY_DEFAULT`).

threat delta
: No ADR 0007 trigger fired: the actions are new verbs on the existing control-API and
  MCP doors under existing authentication, no new sign-in method, no new dependency,
  and a copy holds the page's own data class. The questions are these.
: Information disclosure, by a copy read by someone who may read the page but not
  change it, or by a scoped grant reaching another folder's copy through the `lazysite/`
  skip. `Auth::Acl::_acl_allows` and `_acl_denied` map a copy to its page in WRITE mode
  for both read and write, and the MCP and control-API scope checks ask the copy's page
  (`Lazysite::PageCopy::scope_path`) before they skip `lazysite/`. A copy is never
  served: it is in the engine tree, rendered only as a draft that writes no cache, and
  excluded from content history.
: Elevation of privilege, by an agent putting its own text live. Publishing over MCP or
  the control API needs `publish_copies`, off by default (ruling 155), as well as
  `manage_content` and the page's write rule; the publish is `Manager::Files::action_save`
  at the page's path, so every refusal a save applies (raw HTML, form binding, encoding,
  the active artifacts, the page's rule) applies. A person publishes with
  `manage_content` only through a cookie session, as they save.
: Tampering, by a copy carried out of the folder past the publish: upload (single and
  multipart), delete, mkdir, move and file copy are refused in the folder, and a save
  there needs an open copy. WebDAV still denies the folder outright. A copy taken before
  someone else's change is refused at publish (`stale-copy`, the page's byte digest),
  so a publish never overwrites a newer page unseen.
: Repudiation: each publish is one content-history commit naming the publisher, the
  door and who prepared the copy, and the audit trail records the action as before.

controls
: t/unit/mcp/76 (the tools, the publish_copies gate, the stale refusal, the folder's
  refusals, the page's write rule over the copy), t/unit/mcp/77 (a copy is in its page's
  scope), t/unit/manager/490 (the manager and control-API doors; a token needs
  publish_copies and manage_content; a manager group seeded without publish_copies and
  offered it; the multipart upload refusal).

residual risk
: An open copy holds the page's text in the engine tree until it is published or
  discarded. Where content history is
  not kept, a publish has no version to undo to and the answer says so. An operator who
  grants `publish_copies` lets that group's agents publish without a person looking.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): no trigger
  fired; recorded because a new capability gates writes on existing doors and a new
  carve-out opens part of `lazysite/` to the file verbs.

### 2026-11-07 - SM1355 (0.16.8, PENDING): availability switches, row history and undo, and wizards

Assessment drafted by the developer agent (n772); confirmed by the release manager on 2026-11-08 (ruling 177).

what changed
: Seven control-API actions on the existing door (`data-row-switch`, `data-row-undo`,
  `data-row-changes`, `data-wizards`, `data-wizard`, `data-wizard-run`,
  `data-wizard-save`) and six MCP tools (`switch_row`, `undo_row_change`,
  `list_row_changes`, `list_wizards`, `run_wizard`, `save_wizard`), all under the data
  extension's gate. A descriptor may name an `availability` field; a binding may say
  `(available)`. Every row save and delete through `Manager::Data` is recorded in a new
  store table, `_row_changes`, with the row before and after. Wizard definitions are
  YAML files under `lazysite/db/wizards/`; ruling 180 adds a `date` step (YYYY-MM-DD,
  refused in any other shape by name) to the step types, and the schedule's wizard
  (SM1356) ships as an example in `/docs/data-tables` (`opening_hours`), saved by a site
  over its own schedule table, not installed as a file. Ruling 170 adds a daemon job,
  `row-history-prune` (daily), to the scheduler's closed job set.

threat delta
: ADR 0007's new-processing-of-restricted-data trigger fires (ruling 177, which names
  it new processing of personal data): the history keeps rows' earlier values, a
  person's data among them, including values a later write or a delete removed from
  the table, for the table's period (90 days by default, rulings 170 and 175). It is
  contained by the period and the prune: the write path prunes after each recorded
  change, and the daemon's daily `row-history-prune` job prunes every table the history
  names, so a store nobody writes to keeps nothing past its period either. The other
  three triggers do not fire: new actions on the existing doors under existing
  authentication and capabilities (`manage_data`, `write_data`), no new sign-in
  method, and no new dependency (YAML::PP and DBD::SQLite were declared). The
  questions are these.
: Elevation of privilege, by a switch, an undo or a wizard reaching a row its caller
  may not write. Each is a row write through `update_row`, `delete_row` or
  `Tables::reinsert_row`: the control API asks `row_write_refusal` (writable_by) and
  passes `row_authority` exactly as `data-row-save` does, `table_rule_refusal` binds a
  table's own rule, and putting back a deleted personal row is refused to anyone but
  its owner or an operator. MCP stays `manage_data`, as `save_data_row` is.
: Information disclosure, by the history showing rows' old values. `data-row-changes`
  and `list_row_changes` are `manage_data`'s (a `write_data` holder is refused) and ask
  the table's read rule; the history holds nothing the table did not.
: Tampering, by an undo overwriting a newer change: refused as `stale-change` unless
  the row is exactly as the change left it, and a change is undone once. A wizard
  writes only through the row save, so every value is coerced as any write's; its
  definition is checked against the table at save and at load, and saved only with
  `manage_data`, as a descriptor is.
: Repudiation: each change names its actor and its door (`manager`, `api`, `mcp`,
  `endpoint`, `wizard:<name>`, a fixed word set, never caller text); the audit trail
  records the mutating actions as before.
: Denial of service: one extra read and one insert per row write, and (ruling 170) a
  prune: one delete per table the history names, past that table's period; listing is
  capped at 200. The stored history is bounded by time: 90 days by default, or the
  table's `row_history_days` (a positive whole number of days, at most 36500, refused
  otherwise), a deleted row's changes included. Pruning runs after each recorded
  change and once a day in the daemon's `row-history-prune` job, which makes the same
  call (`RowHistory::prune` with `RowHistory::period_for`) for every table the history
  names, so a store nobody writes to is pruned too. A prune that fails is logged; the
  write stands, and the job records an error with its reason.
: Elevation of privilege, by the job: none. It runs as the configured
  `daemon_job_user`, the account the daemon's other housekeeping jobs
  (`sessions-sweep`, `connectors-sweep`) run as, and needs only `run_jobs` (ruling
  175: retention is never refusable by a missing grant). It reads and changes no
  current row: it removes only changes past their table's period, which the write
  path removes anyway, returns nothing of what it removed, and on a site with no data
  store opens nothing and creates no store. Repudiation: each run is one audit row
  (`row-history-prune`, origin `daemon`) naming the job account, the tables the
  history held and how many changes went, or the failure. The job fires no trigger of
  its own: no new interface, account, sign-in method or dependency, and the job is
  engine code in the closed set; it is the control that contains the history's.
: Tampering, by undoing a change from outside the period: refused as `expired-change`
  (409) even while a not-yet-pruned change is still listed, and the listing marks it
  `undoable: false`.

controls
: t/unit/manager/491 (a write_data token switches only where writable_by names its
  group; its undo refused the same way; the history and wizard definitions refused to
  write_data; the door and account recorded; a deleted row put back with its authors),
  t/unit/mcp/78 (the tools, the stale and repeat undo refusals, the required question,
  a manage_content account refused), t/unit/data/80 (the definition rules, the step
  walk, `(available)` refused without the field), t/unit/data/81 (ruling 170: a change
  past the period is refused as expired and pruned by the next write and not by a read,
  a table's period overrides the default, a deleted row's history goes after the
  period, a bad `row_history_days` refused by name), t/unit/data/82 (a store nobody
  writes to loses its expired changes when the job runs and keeps those inside the
  period, a table's own period and the default for a table no longer declared; no
  store is created; the job runs for an account holding only `run_jobs`; each run one
  audit row with the tables and the count), t/unit/daemon/05 (the job is in the closed
  set and needs nothing beyond `run_jobs`).

residual risk
: `_row_changes` keeps rows' earlier values, including values a later write removed,
  for up to the table's period (90 days by default) after the change, and past it by
  at most a day while the daemon runs its job. Where the daemon is not enabled, or has
  no usable job account (the job is then refused, and the run record says so), a
  store nobody writes to keeps expired changes until its next write, as before.
  A table that sets a long period keeps them that long. A write that could not be
  recorded stands without an undo, and says so.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): the
  new-processing-of-restricted-data trigger fires (rows' earlier values kept for the
  table's period) and the change is contained by the daily `row-history-prune` job
  with the write path's prune, so the ADR 0007 waiver stands; recorded too because new
  actions write rows on existing doors.

walked
: At the 0.16.8 compliance walk (2026-11-08), against the code on the stack's tip
  (d092a5b8c): the scheduler's closed job table (`Lazysite::Daemon::Service::Scheduler`)
  holds `row-history-prune` with `every => 86400` and `needs => undef`, so `run_jobs`
  alone admits it (ruling 175); its body, `Lazysite::Daemon::Jobs::row_history_prune`,
  calls `Lazysite::Data::RowHistory::prune` with `RowHistory::period_for`, opens no
  store where none exists, and writes one audit row per run (`row-history-prune`,
  origin `daemon`, the tables and the count, or the failure). `$DEFAULT_KEEP_DAYS` is
  90. `Lazysite::Manager::Data` makes the same call after each recorded write. The prune
  runs where the daemon is enabled with a usable job account; elsewhere the write path
  is the bound, as the residual risk says. The wizard's `date` step is in
  `Lazysite::Data::Wizard` and the `opening_hours` definition in
  `starter/lazysite/templates/docs/data-tables.md`, read and run by t/unit/data/89
  (8f23fa7ef, ruling 180).

### 2026-11-07 - SM1356 (0.16.8, PENDING): schedules, dated rows, and a daemon job that deletes rows

Assessment drafted by the developer agent (n773); confirmed by the release manager on 2026-11-08 (ruling 177).

what changed
: A table whose descriptor says `schedule: true` gets the engine's schedule fields
  (`Lazysite::Data::Schedule::schedule_fields`) and its rows are checked at every write
  (`Tables::_write_prep`, `import_rows`). A page or the conf may bind `schedule:<table>`
  (`resolve_schedule`, sources.pm), read through `Tables::resolve_binding` as the visitor,
  as `db:` is. Any table may declare `shows_from` / `shows_until`; `resolve_binding` (the
  page bindings and the data endpoint) leaves out a row outside its window
  (`SQLite::_where`, bound values). The site's `time_zone:` is read from the host's
  zoneinfo (`valid_zone`: a zoneinfo-shaped name that exists there). The render records an
  expiry (`@<epoch>` in the dependency record) and the cache serves no render past it. A
  new daemon job, `schedule-exceptions` (hourly, `needs => manage_data`), deletes passed
  exceptions after writing each to the audit trail with the row (ruling 164), and deletes
  nothing when the trail is off. The schedule's wizard ships as an example in
  `/docs/data-tables` (`opening_hours`), which a site saves over its own schedule table
  with `save_wizard` or `data-wizard-save` (`manage_data`); it asks for a period's or
  an exception's fields one at a time, its dates through the `date` step wizards gain,
  and `opens` and `closes` are optional steps, so the schedule's own row check refuses
  an incomplete row at the save, as for any door (ruling 180).

threat delta
: No ADR 0007 trigger fired. `schedule:` is a new page source on the existing render,
  reading through the existing table gate; no new interface, sign-in method or
  dependency (POSIX and Time::Local are core), and the data is the site's own schedule.
: Information disclosure: a schedule is read as the visitor, so a table that is not
  `public: true` shows nothing (tested), and every value is HTML-escaped and made inert
  as a `db:` value is (`_schedule_inert`; a note carrying `<script>` renders as text,
  tested). A dated row outside its window is withheld from the anonymous surfaces; the
  `manage_data` surfaces still list it, which is intended.
: Tampering / elevation: the daemon job deletes rows, which no job did before. It runs
  under the scheduler's existing identity gate (`run_jobs`, then `manage_data`, the grant
  that deletes a row through the manager) and deletes only exception rows of schedule
  tables whose last day is before today in the site's zone; the zone name cannot name a
  file outside zoneinfo. `TZ` is set and restored around each computation in-process.
: Repudiation: each removal is an audit line naming the job account, the table and key,
  with the removed row as JSON (`|` escaped), read back by `removed_exceptions`; with the
  trail off nothing is removed (tested).
: Denial of service: the schedule is read with `limit=500` and computed over fifteen days;
  a page showing it is cached until its next change of state rather than live.

controls
: t/unit/data/85 (fields, write refusals, open-now across boundaries, exceptions, the
  zone across both clock changes, an unknown zone), t/unit/data/86 (the dated-row window
  on bindings and counts, the expiry), t/unit/data/87 (the removal, its record, the trail
  off, the job's grant), t/unit/processor/185 (escaped output, the expiry on both cache
  branches and in max-age).

residual risk
: A site whose host lacks the named zone reads its schedule in UTC until `lazysite check`
  is read. The schedule's state is only as fresh as the clock of the host.
: The sweep's removals are not recorded in the row history (ruling 179): it deletes
  through `Tables::delete_row`, not the manager's recorded delete, so a removed
  exception is not listed by `list_row_changes` and cannot be undone. The daemon's
  audit row for each removal, carrying the removed row, is the trail
  (`removed_exceptions` reads it back); with the audit trail off nothing is removed.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): no trigger
  fired; recorded because a daemon job now deletes rows and the data endpoint now
  withholds rows by date.

### 2026-11-07 - SM1357 (0.16.8, PENDING): JSON-LD, every public page in the sitemap, llms.txt on by default

Assessment drafted by the developer agent (n773); confirmed by the release manager on 2026-11-08 (ruling 177).

what changed
: The engine adds a `<script type="application/ld+json">` block to the pages a table's
  `structured_data:` mapping names (checked at descriptor load,
  `Lazysite::Data::StructuredData::check_mapping`) and an organisation entry to the home
  page from `site_type`, `site_address`, `site_phone`, `site_email` and `site_hours`
  (`layout.pm _inject_structured_data`). `sitemap.xml` and `llms.txt` list every public
  page, not only registered ones (`registries.pm _registry_lists`); `llms.txt` is on by
  default with an organisation section, and `llms_txt: off` stops it being generated or
  served (ruling 165). Every engine write to a table touches a change stamp
  (`Tables::touch_stamp`) that a render records and the cache honours on both branches.

threat delta
: No ADR 0007 trigger fired, and the two that come closest are named. new-external-
  interface: `llms.txt` and `sitemap.xml` were already served registries; JSON-LD is new
  markup on pages already served. new-processing-of-restricted-data: none - **the
  summary file and the JSON-LD publish only data the site already serves publicly**:
  the registries list a page only when `_registry_hidden` finds it neither draft, ACL
  governed nor gated (identity plays no part), and the JSON-LD reads rows as an anonymous
  visitor through `resolve_binding`, so a non-public table, a `where:` condition and the
  dated window all apply, exactly as at the data endpoint.
: Information disclosure: tested that a protected page (auth:, auth_groups:, a read
  rule), a draft section, an api/raw page, a page copy under `lazysite/copies/` and the
  engine's system pages are in neither the sitemap nor `llms.txt` (t/unit/processor/187),
  and that a non-public table's rows appear nowhere on a mapped page
  (t/unit/processor/186). The organisation entry publishes only conf values an operator
  set for the purpose, and only once one is set.
: Tampering (script injection through a row): every JSON-LD value goes through one
  encoder - ASCII JSON with `<`, `>` and `&` as `<`, `>`, `&` - so no row
  value can close the script element, open a comment or start markup; a link property
  with a script-capable scheme is dropped (`unsafe_link_scheme`). Tested with a row
  spelling `</script><script>alert(1)</script>` and a `javascript:` URL.
: Denial of service: one mapping emits at most 100 objects; the descriptor scan is a
  line grep before any module loads, so a site with no mapping loads nothing.

controls
: t/unit/processor/186 (mapped pages only, public rows only, inert encoding, refresh on
  a row write, the organisation entry, mapping refusals), t/unit/processor/187 (the
  listing rule, the summary's content and its off switch), t/unit/processor/185 (a
  db: page with a ttl: refreshes on a row write), t/tools/340 (check's findings).

residual risk
: On upgrade the sitemap and `llms.txt` grow to every public page; a page an operator
  meant to keep out of search engines but left public and unmarked is now listed (the
  UPGRADE note says how to keep one out: `search: false`). A row changed outside the
  engine touches no stamp.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): no trigger
  fired; recorded because the summary and the sitemap now list by default and pages
  gain machine-readable copies of table rows.

### 2026-11-07 - SM1407 (0.16.8): analysts and lead-readers reach a site bootstrapped before them

Assessment drafted by the developer agent (n774); confirmed by the release manager on 2026-11-08 (ruling 177).

what changed
: The users tool adopts the two roles the seed alone carried, `analysts` and
  `lead-readers` (SM631, 0.11.2), on a site that lacks them (`_adopt_layer_roles`, run
  before `_adopt_added_bundles` in `_ensure_groups_seeded`). The rules are the agent
  roles' (SM1371, SM1393): a bootstrapped site, an absent role only, adopted with no
  member, once through `bundles-adopted.json`, which an unreadable record stops. Two
  more: only where the bundle layer is there (a shipped bundle present), and never on a
  store whose manager group carries the `seeded` mark - the mark came after the roles,
  so absent there is an operator's delete, recorded as had. Each adopted role is nested
  into the shipped bundles present that list it (`analysts` into cap-analytics and
  ch-ui, `lead-readers` into ch-script), and cap-audit, which only `analysts` draws on,
  is then adopted by `_adopt_added_bundles` with it inside.

threat delta
: Elevation of privilege is the question. A role is adopted with no member, so no
  account's capabilities change until an operator puts one in it; its grants are a new
  install's (`analysts` reads analytics and the audit trail through its bundles;
  `lead-readers` holds `read_submissions` and the script channel). The bundles it is
  nested into gain a sub-group with no member, which confers nothing. What a name alone
  could get wrong - an operator's own group under one of the two names - is not
  touched: a present group is never rewritten or nested. No trigger of ADR 0007's four
  fires: no interface, method, dependency or data is added; the stores and their modes
  are unchanged.

controls
: t/unit/users/74: a store from before the two roles gains both on first use, as
  shipped, with no member, nested as a new install nests them, cap-audit with
  `analysts` inside, and the next use changes nothing; a role the had-record names does
  not come back, nor one an operator deletes after adoption; on a marked store neither
  is adopted and both are recorded as had; a site without the bundle layer gets
  neither. With the change reverted, subtests 1 to 3 fail. t/unit/users/72 passes
  unchanged.

residual risk
: An operator who deleted either role on an unmarked store before the had-record
  existed (SM1262, 0.16.1) gets it back once, with no member, as SM1371's roles would
  have been; deleting it again is final. A pre-0.11.3 store whose manager group was
  later rewritten by `setup-sysop` (which marks it) reads as marked and adopts
  neither.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177); no trigger
  fired.

### 2026-11-07 - SM1414 (0.16.8): a member saves content over their own session

Assessment drafted by the developer agent (n775); confirmed by the release manager on 2026-11-08 (ruling 177).

what changed
: A new capability, `write_content`, opens the manager API's cookie door
  (`/cgi-bin/lazysite-manager-api.pl` over a signed-in session) to an account that
  holds it and does not hold `ui`, for six actions: `read`, `list` (ruling 173), `save`,
  `mkdir`, `move` and `delete` (declared `member_content` in
  `Lazysite::ControlApi::Actions`). Since
  SM1057 (0.15.5) that door refused every such account. Every other action keeps
  SM1057's refusal, as does every account holding neither capability. A `ui` holder
  never takes this door and is unchanged. The capability implies nothing and no
  shipped role holds it. The operator group is topped up with it, as with every
  capability (SM645), which changes nothing for an operator.

threat delta
: ADR 0007's new-external-interface trigger fires: an authenticated write door is
  opened to a class of account (members, who may number in the hundreds and are not
  managers) that it was closed to. No sign-in method is added (the session is the
  existing cookie, verified by the auth wrapper). No dependency is added, and no
  restricted data is processed in a new way. The other three triggers do not fire.
  The questions are SM1057's two causes and the reach of the door:
  - Elevation of privilege: could a member write a path no rule governs, or a file
    whose rule names someone else? (SM1057's first cause: an ungoverned path is open
    to every writer.)
  - Tampering: could a domain member's path land in the primary's tree or another
    domain's? (SM1057's second cause.) Could a path reach the engine's tree
    (`lazysite/`: the auth store, the ACLs, nav, forms)?
  - Elevation of privilege: could a member reach any other action (acl-set, config,
    users, uploads, copy) or widen a rule?
  - Spoofing and Tampering: could a cross-site page drive a member's session?
  - Information disclosure (ruling 173, `list`): could a listing show a member
    content a rule keeps from them, the engine's tree, another domain's content
    (a domain nested in the session's own tree included), or the account names a
    rule's lists, owner and lock carry?

controls
: The set is closed. The `ui` gate admits a `write_content` holder only for an action
  declared `member_content`, and a load-time check in Actions refuses that
  declaration on any action outside the ruled six, or on one that is not scoped
  and on the file surface. acl-set, acl-get, acl-remove, copy, file-upload, the
  locks, config and users all answer SM1057's refusal.
: A write is an allow-list. For save, mkdir, delete and both ends of a move, the rule
  governing the path for writing (its own key, its page stem, the longest ancestor
  folder, the site-wide rule) must name the account or one of its groups in its write
  list (`Lazysite::Auth::Acl::write_rule_names`). An ungoverned path is refused, a
  rule naming others is refused, and an owner who is not in the list is not admitted.
  A folder moved is refused when any rule beneath it does not name the caller. The
  handler's own rule check, blocklist and extension guards run after this one. An
  unreadable ACL store refuses (`cannot-tell`).
: The paths are the session's domain's. `path` and `to` are refused empty, climbing
  (`..`), with a NUL or a backslash, or in the reserved tree (before and after
  resolution). They are then resolved inside the content root of the domain the
  request arrived on, in place, so the scope check, the carve-out check, the handler
  and the audit row read the one file that is written. The caller is confined to its
  own domain scopes where its domain access resolves any (a locked member stays
  locked), else to the session's content root; on the primary that is the docroot
  less the other domains' roots (SM1372). A resolved path inside another domain's
  content root, as one nested in the session's own tree is, is refused for every
  action.
: A listing is cut to what a rule lets the member read
  (`Lazysite::Manager::Files::member_listing`). An entry is shown only when a rule
  governs it (a read list or a write list) and the read the file's rules allow
  admits the member (`Lazysite::Auth::Acl::list_rule_admits`); an entry no rule
  governs is not shown. The reserved tree and every other domain's content root are
  left out. Each entry keeps its name, type, size, time, store label and file facts
  only: no rule lists, owner, lock holder or served-copy hosts, and the answer
  carries no picker lists. Its paths are the site's, the session's root taken off.
  An unreadable ACL store refuses the listing (`cannot-tell`).
  A write answers by the site's paths too (`path`, and a move's `from` and `to`):
  no answer names the folder holding the domain (n776, t/integration/377).
: A member creates no rule: acl-set is outside the set, and the manager's
  manage_content gate is not what admits it, so a rule's first-rule and widening
  checks (SM1057, SM1309) are not reachable from this door.
: CSRF is the door's own (method-keyed, before any gate), and every write and every
  refusal is one audit row naming the account, the action and the docroot path.
: t/integration/377 covers each: saves, reads, mkdir, move and delete where a rule
  names the group, landing in the domain signed in on (two domains and the
  primary); refusals where a rule names others, where none governs, of the domain's
  tree from the primary, of the engine's tree and of a climbing path; acl-set,
  acl-get, config-read, config-set, users, copy and lock refused; an account without
  either capability refused as SM1057 refuses it. Listings: the readable entries
  only, by the site's paths and without rule lists or pickers; an unruled folder
  showing nothing; a protected entry naming someone else hidden; no reserved tree
  and no other domain's root, a nested domain included, with a site-wide rule in
  force. Each control reverted fails a subtest. t/integration/220 and 221 pass
  unchanged.

residual risk
: A member whose group a folder rule names may overwrite or delete any file under it,
  another author's included, unless a rule on that file names only its author: the
  rule is the operator's statement of who writes there, as for a manager. Content a
  member writes is published as written (front matter included), within what any
  writer of that path could already do; the content checks a save applies to every
  writer apply to it. A site-wide rule whose write list names a members' group admits
  that group everywhere it governs, which is what the rule says.
: A listing does not ask the address rules (SM1139) per entry, so an entry under an
  address rule that refuses the member's address is listed by name and its read is
  refused. A listing of a folder the member may not read answers an empty list where
  a missing folder is refused, so the folder's existence is told, as a read's
  `permission` against `not-found` already tells it.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 177): the trigger
  fires and the change is contained by the closed set, the allow-list, the domain
  resolution, the reserved tree and the listing's cut to readable entries, so the ADR
  0007 waiver stands.

### 2026-11-08 - SM1400, SM1402, SM1404, SM1405, SM1409, SM1411 (0.16.8): a backup is not a layout, a conf for no form, a listing's pickers, a notice mail's shape, a mixed pair, the editor's lock, with no trigger

Assessment drafted by the developer agent at the 0.16.8 compliance walk; confirmed by
the release manager on 2026-11-08 (ruling 182). The rest of 0.16.8 moves no control: SM1397 answers
`/favicon.ico` and `/favicon.svg` with two fixed public images where a site has none,
its own file winning; SM1398 adds `page_url_raw`, a raw twin under the SM824 contract,
that names nothing a page could not already name; SM1399 is a filing (a candidate);
SM1401 adds a sentence to an account's removal and a `lazysite check` finding (a rule
whose owner is no account), changing no rule; SM1408 rewords a refusal whose rule
stands; SM1410 keeps no staging record for a run that staged no account, which was a
record of nothing; SM1403 and SM1406 were withdrawn before landing (ruling 159), so
nothing of them ships; n776's commits renumber three tests and add one
(t/unit/users/75) where the seed and top-up rules meet, changing no code; SM1415 is
this walk. The other changes of 0.16.8 have their own entries, confirmed by the release
manager on 2026-11-08 (ruling 177): SM1369 X2, X3 and X5's asset part, SM1396 (firing
new-processing-of-restricted-data), SM1395, SM1413, SM1412, SM1354, SM1355 (firing
new-processing-of-restricted-data), SM1356, SM1357, SM1407 and SM1414 (firing
new-external-interface).

what changed
: SM1400, a layout's backup snapshot. `themes-list-all`, the listing the Appearance
  page, MCP `list_themes` and the control API draw installed layouts from, walked
  every directory under `layouts/`, so a `<name>-backup-<stamp>` snapshot that
  `delete_layout` keeps came back as a layout, and a second delete removed it. Every
  snapshot now leaves `themes` and is listed under `backups`, with the path
  `artifact-backups-delete` takes (t/unit/manager/476).
: SM1402, a notify setting for a form that does not exist. `set_form_notify` (MCP)
  and `form-notify-save` (control API) wrote `lazysite/forms/<name>.conf` for any
  name; a name neither registered nor bound on a page is now refused (`not-found`)
  (t/unit/forms/76).
: SM1404, a listing's picker choices. `Manager::Files::action_list` returned the
  permissions editor's address-profile choices on every listing, so MCP `list_files`
  carried an entry named after a rule's address profile; they ride only on the
  manager API's listing for the Files page (`pickers`) and on `acl-get`
  (t/unit/manager/477).
: SM1405, a notice mail's shape. `Notify::_mail_send` handed a notice to the Form
  SMTP extension as a form submission, with Submitted and IP lines; it is sent as a
  composed message (`send_message`, SM1020's path) with no IP line, through the same
  send, transport and hourly bound (t/unit/forms/77).
: SM1409, a layout set without its own theme. `domain-set` of the layout alone, with
  the domain's theme still the other layout's, mirrored that mixed pair into the
  served assets; the set is still accepted, the pair is not mirrored, and the warning
  names what to send (t/unit/manager/481).
: SM1411, the editor's lock. The editor sent `lock` and `renew-lock`, both declared
  mutating, as GETs, which the API refuses, so from 0.7.19 no editor open held its
  lock; both are POSTs, and a lint keeps every manager page's fetch of a mutating
  action a POST (t/unit/manager/480, t/lint/340).

threat delta
: None of ADR 0007's four triggers fired: no new interface (existing actions answer
  less, refuse more or are sent as they were declared), no new sign-in method, no new
  dependency and no new restricted data (SM1405's mail carries less). The questions
  are these.
: SM1400: Tampering, by a destructive action reaching a snapshot as if it were a
  layout. The listing no longer offers it as one; the snapshot is removed only by the
  backups action, which names it as a backup.
: SM1402: Tampering, by a write creating configuration nobody asked for. The refusal
  narrows the action; the capability and the form rules are unchanged.
: SM1404: Information disclosure, narrowed: an MCP or token listing no longer carries
  the site's address-profile names, which only the permissions editor reads.
: SM1405: Information disclosure, narrowed: a notice mail carries no submitter address
  line, and nothing in the message comes from a visitor that the notice did not carry.
: SM1409: Elevation of privilege and Tampering, none: what is mirrored is the pair a
  domain serves, and a mixed pair is mirrored no longer; nothing becomes servable that
  was not.
: SM1411: Tampering, narrowed: the editor's lock, a concurrency aid between people who
  may all write the file, is granted again, and the API's refusal of a mutating action
  sent as GET (the CSRF gate's precondition) is now met by the shipped page, not worked
  around; saves were gated as before throughout.

controls
: SM1400: t/unit/manager/476. SM1402: t/unit/forms/76. SM1404: t/unit/manager/477.
  SM1405: t/unit/forms/77. SM1409: t/unit/manager/481. SM1411: t/unit/manager/480 and
  t/lint/340.

residual risk
: SM1400: snapshots left by earlier releases are listed as backups from 0.16.8 and
  removed only by the operator. SM1402: a conf written for a form that never existed,
  before 0.16.8, stays until removed. SM1411: a lock is advisory; a second writer who
  ignores it still saves, as any writer with the capability could.

verdict
: accepted, confirmed by the release manager on 2026-11-08 (ruling 182). No
  trigger fired; recorded because SM1400 changes what a destructive action is offered
  and SM1411 restores a lock the shipped editor had stopped taking. 0.16.8 is edge and
  not security-critical (ruling 182): no change in it fixes a
  vulnerability (OBLIGATIONS.md, the vulnerability-handling row).

### 2026-11-08 - SM1369 X4 (0.16.9, PENDING): a sign-in method changed - the Odoo site sign-in is an identity provider an extension declares

Assessment drafted by the developer agent (n781); confirmed by the release manager on
2026-11-10 (ruling 225). Ruling 55; the design is the extension-hooks proposal, H-1 (G-1, G-2, G-3,
G-9; risk R-1, "X4 ships alone with a sabotage test per guarantee"); rulings 178, 181,
184 and 186. ADR 0007's sign-in-method trigger fires.

what changed
: H-1. An enabled extension's `owns.hooks.identity_provider` declares an identity
  provider: `on`, `still_valid` and `groups` (required), `login_option` and `banner`
  (functions in its payload lib, called through boundary 15's loader), `renew` (a same-site
  path with a query), `signin_page` (a page name that is not one of the engine's) and
  `grants` (0 or 1). The provider's id is the extension's id. The SM1160 session is
  generalised in place: the same cookie, the same registry, the same revocation, the same
  CSRF key. `mint_provider_session` and `renew_provider_session` replace the Odoo-named
  functions; the record now names its `provider`, and a record written before (the
  provider's id as a flag, `odoo => 1`) is read as that provider's. The verifier
  dispatches on the cookie's `<id>=` prefix to the provider the index names, asks its
  `on`, refuses on an unsecured site, checks revocation and the record, asks
  `still_valid` (stale: refused with the provider's `renew` path), and asks `groups`.
: Odoo is the first provider (`Lazysite::Odoo::SiteSignin::provider_*`): `on` is
  `odoo_site_signin`, `still_valid` is `odoo_identity_ttl`, `groups` the current map,
  `/odoo-signin` its sign-in page, its /login option "Sign in with <name>", its banner
  the existing one. It does not declare `grants`.
: The processor serves a provider's sign-in page as a system page while `on` says so,
  exempts it from maintenance, and gives the layouts `signin_banner` and
  `login_options`; /login renders the options. Core names no extension in the session
  verifier, the auth wrapper's actor rule, the identity reader, the maintenance rule,
  the render path or /login (lint 321: 24 files to 18).
: Ruling 178: the Odoo delivery handler type's `cap` is `manage_odoo` (was
  `manage_connectors`, C-14). A handler type may name its own extension's capability.

threat delta
: The sign-in-method trigger fires: who may cause a session to be minted is now any
  enabled extension that declares a provider, where it was one named code path (R-1).
  Spoofing: an extension minting a session under another provider's id or a local
  name; a session outliving its provider. Elevation of privilege: a provider handing a
  group that carries a capability (G-3), and ruling 186's widening, a provider that
  declares its groups grant. Denial of service and failure: a provider function that
  dies, hangs or answers something else. Tampering: a provider writing or reading the
  key or the registry itself. The other three triggers do not fire: no new external
  interface (the endpoints, pages and actions are the ones that were; the loader is
  boundary 15's), no new dependency, no new processing of restricted data (the record
  holds what SM1160's held).

controls
: Only core signs (G-2): the provider has no key and no way to the registry but
  `mint_provider_session` and `renew_provider_session`; the cookie is HMAC-signed by
  core with the site key, a cookie signed with any other key is `signature`. A cookie's
  `<id>=` prefix cannot be a local name ('=' and ':' are not in one), and its provider is
  read from the index, never from the cookie; a record names its provider, and a record
  of another provider over the same sid is no session. Off means off (G-1): the
  extension must be enabled and indexed at the mint and at every verification
  (`Hooks::identity_provider` reads lazysite.conf again) and the provider's `on` must
  say yes; an index left behind for an extension the conf no longer lists verifies
  nothing. No external identity gets a capability (G-3): every group a provider's
  `groups` answers is checked by core (`Auth::Settings::group_carries_capability`,
  nested groups and declared capabilities included) and one that carries any
  capability is dropped with a WARN naming it; an unsecured site refuses every provider
  session. Fails closed (G-9): a function that cannot be loaded, dies or answers outside
  its contract is `<id>-failed`, no session; stale holds no groups. Ruling 186's
  allowance is a declaration (`grants => 1`), which only OIDC (SM1351, the next wave) is
  to make; every sign-in and renewal through such a provider writes an audit row
  (`login-grant`, `renew-grant`) naming the groups it granted. The provider's sign-in
  page is the provider's while `on`, and a page name of the engine's own is refused; one
  page has one provider. t/unit/extensions/80 (a fixture provider) holds each guarantee
  and was sabotaged per guarantee: the enabled check (G-1), the capability filter (G-3),
  the failed `on` (G-9), the record's provider, the pre-X4 record, the grant audit, the
  sign-in page's `on`, and the maintenance exemption - each fails it (and t/tools/335,
  t/unit/processor/171 where they reach). t/tools/335: a person signed in as 0.16.8 did,
  byte for byte, stays signed in across the real upgrade, with /odoo-signin and the /login
  option served by the installed code. Ruling 178: t/unit/odoo/140 (the upgrade's
  top-up keeps a manage_connectors group's reach; a declined manage_odoo stays declined). Ruling 192:
  the six handler and schedule actions open, on every door, for a capability a declared
  handler type names (the gate row, the cookie gate, the MCP twins and the capability's
  unlocks, from the index's `declared` view, put back by the unmirror); the type's
  capability still decides each handler, and a caller let in by such a capability alone
  is listed only its types' handlers and schedule entries. t/integration/378: manage_odoo
  alone manages an Odoo binding and its schedule and is refused a core destination's
  handler past the door; sabotaged (the widening, the schedule list's narrowing).

residual risk
: A provider is the extension's own code under boundary 15's contract-not-sandbox: in
  process it could read the key file as the site user. What core guarantees is the path
  - nothing signs but core, and a disabled or failing provider signs nobody in - not
  that an installed extension is honest; trust stays what is installed (ADR 0009). A
  declared `grants` provider can grant any group, operators included (ruling 186); its
  audit rows are the record, and the widening is recorded here for OIDC's own entry to
  assess. A site that had `odoo_site_signin: on` with the Odoo extension off had working
  sessions and now has none (off means off; UPGRADE.md), an unsecured site refuses every
  provider's session, and a downgrade to 0.16.8 signs out sessions minted after the
  upgrade (the record drops `odoo => 1`): all three accepted as built (ruling 193). The
  handler door's widening (ruling 192) lets an extension's own capability open the six
  handler and schedule actions; what such a holder may then do is decided by each
  handler's type, as for a core destination capability, and it sees no other type's
  handlers or schedule entries.

verdict
: accepted, contained, confirmed by the release manager on 2026-11-10 (ruling 225). The
  trigger fires and is contained: the sign-in path is SM1160's, generalised, with the
  guarantees core held for Odoo now held for any provider, each sabotaged; no capability
  reaches a provider session unless a provider declares `grants`, which only the OIDC
  extension does in this release (SM1351, the entry that follows). No ahead-of-schedule
  third-party engagement beyond the one ADR 0007 already requires; the OIDC entry
  (SM1351) is where ruling 186's widening is first used.

### 2026-11-08 - SM1369 X5, H-4 and H-5 (0.16.9, PENDING): an extension endpoint's request kit, and its declared services and warm endpoint

Assessment drafted by the developer agent (n782); confirmed by the release manager on
2026-11-10 (ruling 225). Ruling 55; the design is the extension-hooks proposal's H-4 and H-5, G-4, and the 0.16.9
simplicity notes (rulings 181, 184).

what changed
: H-4: `Lazysite::Endpoint`, the request kit an extension's endpoint uses. It caps a body
  before reading it (`read_body`), parses a multipart one (moved from the Odoo upload
  module), holds the visitor key, cookie and token (moved from `Lazysite::Odoo::Visitor`,
  per extension: `lzs_<id>_visitor`, `lazysite/<id>/visitor.secret`, the names and
  signatures Odoo's always had) and checks a POST (`post_guard`) for the session's CSRF
  token of the verified account or the visitor token bound to the visitor cookie, before
  the extension's code runs (G-4). `hooks.endpoints` goes live; the Odoo page endpoint
  declares itself and uses the kit at its unchanged `lazysite-odoo.pl` location.
: H-5: `hooks.services` goes live. The supervisor lists, gates (`wanted`), starts (`run`),
  stops and reports a service an enabled extension declares, reaching each function
  through `Hooks::call_hook`; Odoo's oomd and its endpoint's warm-fork parent are
  declared, their code unchanged. An endpoint declares `warm` and a `preload` list: the
  front door hands a declared warm endpoint to its parent by reading the index, the
  parent's socket is named for its endpoint (`odoo-endpoint.sock` unchanged), and the
  parent compiles the declared list, handed to it as arguments.

threat delta
: ADR 0007's new-external-interface trigger is assessed and does not fire: no route,
  socket, port or wire format is added or changed (the endpoint's location and the
  socket path are what they were; the split templates and vhosts are untouched). The
  in-process interface through which an extension's code runs in a core process is
  X1's, already assessed; H-5 gives it a new caller, the supervisor. No sign-in method,
  no dependency, no restricted data. The questions:
: Spoofing and Tampering (CSRF) at an extension endpoint: an extension that wrote its
  own body read or token check could get either wrong. The kit is the one place both
  are done; t/lint/351 refuses a declared endpoint that reads STDIN itself, makes an HMAC
  or calls the session verifier itself, or runs anything of its payload between a body
  read and the kit's guard.
: Denial of service by a body: a body over the endpoint's cap is refused before a byte
  is read, by the kit, whatever the endpoint decided its cap to be.
: Elevation of privilege by a declared service or preload list: a service runs code the
  site did not mean to run, or the warm parent compiles something that holds state into
  every child.

controls
: `post_guard` runs on every JSON and multipart POST of the Odoo endpoint right after the
  body is read, before the engine loads; the endpoint's own, stricter per-binding check
  (`_csrf_ok`, now through the kit's functions) still runs after it. The visitor cookie is
  HttpOnly and SameSite=Strict, its token an HMAC under the extension's own secret,
  compared in constant time; another extension's secret is its own, so one extension's
  visitor token is not another's (t/unit/extensions/90). A service's functions are the
  extension's own, in its payload lib, found nowhere else on `@INC`, run only while the
  extension and what it requires are on at the call (C-3, G-1); a gate that cannot be
  asked or dies is "not wanted" (G-9); a service may not take the scheduler's name and a
  name has one owner (t/unit/daemon/28). The warm parent requires a declared name only
  when it is a module name; t/lint/272 holds the declared list to module names, none of
  them lazysite's (lazysite's own code reaches the parent only through the endpoint's
  `use` lines, which that lint classifies); t/integration/325 still reads the parent's
  memory after signed-in requests.

residual risk
: A POST to the Odoo endpoint that carries no token at all is now refused 403 `csrf`
  whole, before anything runs - a session binding with no Odoo session answered 401, and
  a batch answered per call. The browser helper always sends a token, and fetches fresh
  ones once on a `csrf` refusal; a hand-written client that sent none sees 403 where it
  saw 401. The data extension's endpoint (`lazysite-data.pl`) is not yet declared in
  `hooks.endpoints` and keeps its own checks. A shipped extension is trusted code (the
  proposal's "What the model does not claim"): the kit makes the right path the only
  one a lint accepts; it is not a sandbox.

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225): no trigger
  fires; recorded because the CSRF and body checks of an extension's endpoint move into
  core and the supervisor now runs services an extension declares.

### 2026-11-08 - SM1369 X6, H-6, H-8 and H-11 (0.16.9, PENDING): an extension's checks, its manager pages, and one secrets store

Assessment drafted by the developer agent (n782); confirmed by the release manager on
2026-11-10 (ruling 225). Ruling 55, ruling 188 (panels are pages); the design is the extension-hooks proposal's
H-6, H-8 and H-11, G-7, and the 0.16.9 simplicity notes.

what changed
: H-6: `lazysite check` calls the checks an enabled extension declares and prints their
  findings with its own `report()`; Odoo's five checks move into the extension.
: H-8: `hooks.panels` - a manager page in the extension's payload (`manager/<name>.md`),
  served by the processor at `/manager/<id>-<name>` to a manager who holds the
  capability it declares (one of the extension's own), and linked from its card on the
  extension-config page for a caller who holds it (ruling 194: filtered at render from
  whoami; the cached listing knows no caller). Odoo's Unknown Odoo writes panel becomes its page,
  `/manager/odoo-unknown-writes`, under `settle_odoo_writes`.
: H-11: `Lazysite::Secrets`, the one secrets store: one secret per file,
  `lazysite/<owner>/keys/<name>.key`, for the connectors and for each extension by its
  id. The Odoo keys are read where they were; a connector's secret moves from
  `connectors/secrets.json` into the store on its next set, and is read from the map
  until then.

threat delta
: ADR 0007's new-external-interface trigger is assessed for H-8: a new path under
  `/manager/` serves a page an extension ships. It is judged not to fire as a new
  interface - it is a manager page behind the existing manager gate (`ui`, the
  manager-address rule, the sign-in redirect), with an added capability gate, and the
  page reaches the API only through actions the API already gates - but it is the
  release manager's to confirm. No sign-in method, no dependency. H-11 moves where
  credentials are kept; it is not new restricted data, and is assessed here as
  Information disclosure. The questions:
: Information disclosure: a secret readable by group or other, or listed; a secret
  that cannot be read reported as absent and re-entered over (SM768); an extension
  reading another's secret.
: Elevation of privilege: an extension page drawn for a manager who does not hold its
  capability, or served from outside the payload, or while the extension is off.
: Repudiation and Denial of service by a check: an extension's check that dies ends the
  run, or invents a level the summary does not count.

controls
: A secret is written under a 077 umask to a temporary file and renamed, 0600 with its
  group following the directory, in a 0700 directory; nothing in the store lists; has()
  is undef for a secret that is there and cannot be opened, and a put over it is
  refused; the owner and the name are ids, never paths; an extension passes its own id
  (t/unit/manager/502). The connectors' listing names the store it could not read and
  set, delete and call refuse past it, as before (t/unit/manager/159). An extension's
  page is served only from the payload the index names, re-checked as a regular file and
  allowed by its real path, only while the extension is on (the conf read again), only
  inside the manager gate, and only to a holder of its declared capability, which the
  index build requires to be the extension's own (t/unit/extensions/92). A check runs
  only for an extension the conf has on; one that dies is a WARN naming it; a finding of
  another level is a WARN, never printed as a finding (t/tools/351).

residual risk
: Until a connector's secret is next set, its value stays in the older map as well as
  being read from there; the map keeps the 0600 it always had. An extension's page is
  ordinary manager-page markup run in the manager's frame: what its script can do is what
  the signed-in manager's API calls can do, gated by the API's rows. With the Odoo
  extension off, its checks no longer run (two of them ran on any site that held Odoo's
  files); `lazysite check` says "installed, off" instead. A shipped extension is trusted
  code; G-7's "an extension reads only its own secrets" is a contract of its code, not a
  sandbox.

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225): H-8's new
  manager path is assessed under new-external-interface and confirmed within the existing
  manager surface (the `/manager/` path is that surface); no other trigger fires;
  recorded because credentials move to one store and the manager serves pages an
  extension ships.

### 2026-11-08 - SM1364 (0.16.9, PENDING): a table reads its rows from another system's API

Assessment drafted by the developer agent (n783); the trigger ruled by the release
manager (ruling 190); confirmed by the release manager on 2026-11-10 (ruling 225).

what changed
: A data table's descriptor may name a `source:` - a GET connector, the schedule entry
  that refreshes it, where the list is in the answer and a map from each item's fields to
  its columns (`Descriptor::_check_source`). A connector's answer is written into the rows
  of every table whose `source.connector` names it (ruling 191: one link;
  `Connectors::sourced_by`) (`Connectors::_keep_answer` ->
  `Tables::refresh_from_answer` -> `import_rows`) instead of appending a call row. A new
  action and tool, `data-table-refresh` / `refresh_data_table` (`manage_data`), make the
  entry's call on demand, as the caller. Mapped columns are refused at every write door
  (`Tables::_sourced_refusal`, from `_write_prep` and `import_rows`). The schedule's run
  record gains `last_ok`, which `data-table` reads to say how old the rows are.

threat delta
: ADR 0007's new-processing-of-restricted-data trigger fires (ruling 190, as ruling
  177, which names it new processing of personal data): a remote system's values, a
  person's data among them (a booking's guest), now become column values a page can
  render, where before they sat whole in one `answer` text column, and a refresh removes
  rows the source stops sending. It is contained by the connector's callers (who may
  cause the call), the table's read rules (`public`, `where`, its access rule - who may
  read the rows) and the read-only mapping (no local door can write a source column).
  The other three triggers do not fire. new-external-interface does not fire: the
  outbound call is the existing connector egress (its URL, secret, modes, callers, rate cap, no redirects, the 64 KB answer cap
  and the call record, all unchanged), and the refresh action is a new action on the
  existing doors under existing authentication and `manage_data`. new-authentication-
  method and new-dependency-with-authentication-logic do not fire (no sign-in change; no
  new module).
: Tampering: a remote can only write the mapped columns of the one table that names its
  connector as source; `_keep_answer` refuses an answer from any other connector. Values
  go through `import_rows`' coercion (each column's type, required, unique, a schedule
  table's row check) and the store's bound statements; a structure in a mapped field is
  refused, never stringified. The answer is decoded JSON only; text refuses the refresh.
: Information disclosure: a sourced table is read as any table is - its `public`,
  `where`, access rule and the template escaping apply to source values as to any other.
  An operator who marks a sourced table `public: true` publishes what the source sends.
: Elevation: the on-demand refresh is gated by `manage_data` and the table's own write
  rule, and the call by the connector (mode `authenticated`: its callers groups or
  `manage_connectors`), so a `manage_data` holder outside the callers cannot cause the
  call (tested). Mapped columns cannot be written locally by any door (tested on the
  manager, the control API, MCP and a CSV import), so a local writer cannot forge a value
  that reads as the source's.
: Denial of service: an answer is capped at 64 KB, so a refresh is bounded; it is all or
  nothing in one transaction, so a bad answer leaves the last good rows.

controls
: t/unit/data/110 (a refresh against a 127.0.0.1 fixture fills the table; a second keeps
  unmapped columns; the remote down and an unmappable answer leave the last good rows and
  are recorded; the age counts from the last good refresh; the on-demand refresh, and its
  refusal outside the connector's callers; the descriptor's refusals), t/unit/manager/512
  (mapped columns refused on the manager, the control API, MCP and a CSV import, naming
  the source; unmapped columns written on each; both refresh doors).

residual risk
: A refresh removes the rows its source stops sending (ruling 189): each removal is a
  recorded delete in the row history, undoable, and only a non-empty, well-formed list
  removes anything, so an empty or failed answer cannot empty a table. A source that
  wrongly omits a row removes it until it sends it again. The run record's two writers
  (the daemon, an on-demand refresh) share one lock file (ruling 191) and the daemon
  merges only its own entries; a writer that cannot open the lock writes without it and
  logs that it did. The manager's data page gains Refresh now (`data-table-refresh`,
  CSRF-gated like every POST there). The connector's secret store is
  unchanged by this work; if it changes, the refresh reaches it only through
  `Connectors::call`.

verdict
: accepted, ruled by the release manager (ruling 190): ADR 0007's
  new-processing-of-restricted-data trigger fires and is contained by the connector's
  callers, the table's read rules and the read-only mapping, so the ADR 0007 waiver
  stands. The other three triggers do not fire. Drafted by the developer agent (n783);
  stays as ruling 190 has it, confirmed by the release manager on 2026-11-10 (ruling 225).

### 2026-11-09 - SM1351 (0.16.9, PENDING): a new sign-in method - an outside OpenID Connect provider, whose groups may grant

Assessment drafted by the developer agent (n792); confirmed by the release manager on
2026-11-10 (ruling 225). Rulings 185, 186 and 206; built on H-1 (SM1369 X4, n781). ADR 0007's
sign-in-method trigger fires, with ruling 186's widening exercised for the first time.
Its new-external-interface trigger fires too: a new endpoint, and outbound calls to the
providers the operator configures.

what changed
: A new extension, `oidc` (off until enabled), and its endpoint
  `/cgi-bin/lazysite-oidc.pl` (GETs only; H-4's kit refuses any body and any POST before
  the extension's code). A person is signed in through any of the providers
  `lazysite/oidc.conf` names, by the authorisation code flow with PKCE (S256); the
  identity is `oidc-<name>:<sub>`. H-1 gains `instances`: one extension is several
  providers, each its own session prefix, record, why codes and audit rows. The client
  secret is in the one secrets store (H-11), set on the settings form (ruling 214) or
  from the command line. Discovery is
  fetched on save and by Refresh, and cached.

threat delta
: Spoofing: a forged or replayed answer from the provider (login CSRF, a code injected
  from another browser, an ID token for another client or issuer, a replayed or stale
  token); a provider named inside another's family. Elevation of privilege: ruling 186
  lets a provider group map to a capability group, operators included, so whoever
  controls that group's membership at the provider can make a manager here. Information
  disclosure: the client secret, and the PKCE verifier and nonce kept between the start
  and the answer. Tampering: a discovery document or token endpoint redirecting the
  call. Denial of service: an issuer that hangs or answers a large body; a broken
  provider taking the others down.

controls
: The state is 256 random bits in an HttpOnly, SameSite=Lax cookie scoped to the
  endpoint; the answer must carry the same state (constant-time compare) and name a
  record made here, which is single use and expires in ten minutes, so an answer
  started in another browser is refused. Ruling 185: the code is exchanged at the
  token endpoint over TLS with client authentication and the PKCE verifier; the ID
  token in that answer must name the configured issuer, this client (aud, and azp with
  several audiences) and the nonce sent, and must not have expired (60 s skew); its
  signature is not checked (OIDC Core 3.1.3.7). Userinfo is read only for claims the
  token lacks, and its sub must be the token's. Every call is https:// (http:// only to
  this host, the connectors' rule), follows no redirect, is capped at 256 KB and times
  out at 10 s; discovery must name the configured issuer exactly and offer S256. The
  secret is never in the config and never shown: the settings form's secret field (the
  `records` type, ruling 214) writes it only into the secrets store under the
  extension's id, the reader answers only whether it is set, a blank keeps it and a
  removed provider takes it with it (t/unit/manager/582); the command line sets it for a
  repair; the
  verifier and nonce sit in a 0660 record under lazysite/oidc/pending/, deleted on use.
  Core keeps the session (H-1: only core signs; off means off at every request; an
  unsecured site refuses it). Ruling 186: `grants => 1`, so groups that carry
  capabilities are kept, and every sign-in writes core's `login-grant` audit row with
  the provider, the subject and the groups granted; a person in no mapped group is
  refused and no account is made; the record's groups are re-read against the current
  map at every request. Ruling 206: a provider whose config, secret or discovery is
  broken is refused and its sessions end, the others untouched; the log and
  `lazysite check` name the fault and the remedy; an unreadable oidc.conf refuses all.
  Core refuses another extension's provider inside an instances provider's family.
  t/unit/extensions/170 against a 127.0.0.1 fixture issuer, sabotaged by hand: the iss,
  aud, nonce and expiry checks, the state cookie compare, the no-group refusal, the
  secret check, `grants`, the `instances` resolution, the mint's provider id, the
  /login list and the family clash each fail it. Ruling 214 (Q128), the same test: the
  Sessions page's mark makes the session stale, a protected page sends it to the renew
  path with `next`, the same person renews the same session with the groups read afresh,
  another person gets a session of their own, and a local session is signed out;
  sabotaged (the mark ignored, the mark kept on renewal, always revoking, no audit act,
  no renewal sid, renewal for anyone).

residual risk
: Ruling 186's widening: a provider group mapped to operators makes the provider's
  administrators managers of this site; the audit rows are the record, and the docs say
  to map such a group only from a provider whose membership the site controls. Ruling
  214 (Q129): a map entry whose target carries capabilities is saved only by the
  operator; a manage_config holder maps to plain groups and keeps a capability mapping
  already there, and adding one is refused `forbidden`, naming why (t/unit/manager/582).
  A token is never the operator (SM991), so such a mapping is made in the manager, and
  the settings have no MCP door. The sysadmin can still write lazysite/oidc.conf. Membership is read at sign-in only: someone removed
  from a group at the provider keeps it until their session ends (session_lifetime) or
  is revoked, or until it is marked "require sign-in again" on the Sessions page (ruling
  214: stale until the provider is asked again, the same session then renewed only for
  the same subject, with its groups read afresh; no token is stored; audited
  `session-reauth`); removing the map entry takes it away at the next request. The ID token's
  signature is not checked (ruling 185), so the trust rests on TLS to the token
  endpoint; plain http:// is accepted only to this host. TLS is verified against the
  system's certificate store, or the provider's own `<name>.ca_file` (ruling 213); a
  bundle that is named and cannot be read refuses that provider, never falls back. A
  start is a sign-in attempt for the sign-in limiter (ruling 213: its switch, five per
  address in five minutes), counted before anything is written, so unsigned GETs
  cannot fill the pending store while the limiter is on; with it switched off, records
  older than ten minutes are swept at each start.

verdict
: accepted, contained, confirmed by the release manager on 2026-11-10 (ruling 225). The
  sign-in-method and new-external-interface triggers fire and are contained: the session
  is core's H-1 session, the answer is bound to the browser and to this client, and the
  widening is a declaration that is audited at every sign-in. No early third-party
  review: the OIDC grant mapping (ruling 186's first use) is named in the scope of the
  engagement ADR 0007 already requires (docs/compliance/OBLIGATIONS.md, the first
  third-party penetration test).

### 2026-11-09 - SM297 (0.16.9, PENDING): identity is a value - the data endpoint stops writing its own trust headers

Assessment drafted by the developer agent (n793); confirmed by the release manager on
2026-11-10 (ruling 225). The filing is SM297; the brief converts one surface at a time, on X4
(SM1369). Ruling 206 (a fault refuses). The trust boundary changes (boundary 2).

what changed
: One accessor. `Lazysite::Auth::Identity::request_identity` answers a value held in
  `$Lazysite::Auth::Identity::HELD` (set with `local`, so it ends with its scope) to any
  caller that names no `identity` of its own, and reads nothing from `%ENV` while it
  is held. `request_session`, which decides the value, says `identity => undef` and so
  reads the request. The processor's own reader is unchanged (it names
  `$REQUEST_IDENT`).
: One surface converted. `lazysite-data.pl` verified its caller and then deleted every
  `X-Remote-*`, wrote the verified user and groups back under the fixed names, set the
  wrapper's sentinel `LAZYSITE_AUTH_TRUSTED`, and let every reader it called (its own,
  the ACL's operator check, the capability gates) read them out of its environment. It
  now holds the value (an anonymous value for nobody) and writes nothing; its readers
  are answered the value.
: Ruling 206: a session whose store cannot be read (`cannot-tell`) is refused by the
  endpoint with a 503 naming the store, and the auth line names it in the log; it was
  served as anonymous.

threat delta
: No ADR 0007 trigger fires: no new interface, method, dependency or data. Spoofing is
  the question, and it narrows: an identity in the endpoint's environment - sent by the
  client, passed by the web server as a parameter, or written by anything in the process
  after the identity was decided - was believed by the endpoint's readers because the
  endpoint itself set the sentinel; with a value held it has no effect. The new
  element is the held value: a reader in the same process that does not name an
  identity is answered it, so a value left held past its request would answer the next.

controls
: The hold is `local`, so it ends with the endpoint's `main()` (and a die), and a CGI
  is one request per process. A caller naming its own identity is answered that, and
  the deciding function never reads a held value. t/unit/auth/177 pins the accessor
  (forged fixed names, sentinel and configured proxy names have no effect while a value
  is held; the hold ends with its scope; the CGI path reads as before). t/integration/478
  runs the endpoint: an identity forged in the request, and one written into `%ENV`
  mid-request, have no effect on a member or on nobody; a sabotaged copy with the hold
  removed is fooled by the same write (the bypass is caught); a store that cannot be
  read is a 503 naming it. t/lint/268 no longer allows the data endpoint to name a
  fixed header and t/lint/38 asserts it reads none, so a return to the old channel fails
  both. t/integration/290 (the wrapper and the endpoint decide one identity, against the
  recorded base) passes with the endpoint's identity read where its readers read it.
  Each fails with its change reverted.

residual risk
: The manager API in the pool is not converted: its relay still forks, clears and writes
  the wrapper's contract from the value (SM1181 S4) and execs the API, because the API
  is a top-level script that answers by `exit` in eighteen places and keeps its
  crash-audit row and registry rebuild in END blocks, so it cannot be called in a
  long-lived worker as it stands. Its readers of the session id (`LAZYSITE_AUTH_SID`
  in Account, Sessions, Users) stay on the contract with it; ruling 217 moves its
  conversion to 0.17.0 as its own change. The CGI wrapper and its contract are
  unchanged by design. The Odoo endpoint and the form handler already verify their own
  caller as a value and write nothing.
: Ruling 217 (pages refuse too): a request carrying a session cookie whose session
  store cannot be read is refused 503 by the auth wrapper before it execs (CGI) and by
  the pool's front door in the worker, from request_session's fault value
  (`cannot-tell`, with the store); the log line names the store and the repair. At the
  restack (rulings 216, 217; n795) the response became the engine's one refusal for a
  store it cannot tell, the same words as n789's gate and n790's manager door, and it
  names no file to the visitor (SM494); t/integration/498 holds every path to it.
  No cookie, an expired cookie or a removed account stay an ordinary signed-out
  visitor. t/integration/479 holds both paths and the controls; each fails with its
  change reverted, and a widening to every signed-out request fails the controls.

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225). No trigger
  fires; the change removes a channel and adds a held value whose scope is the request.
  No ahead-of-schedule third-party engagement proposed.

### 2026-11-08 - SM1352, SM1363 (0.16.9, PENDING): CryptX, one Recommends for passkeys and web push

Assessment drafted by the developer agent (n784); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: CryptX (Debian `libcryptx-perl`) joins the deb's Recommends (ruling 187). It is
  lazy-required only by passkeys (SM1352: verifying an authenticator's ECDSA P-256, RSA
  or Ed25519 signature, and importing the public key the browser hands over) and by web
  push (SM1363: signing the VAPID token with the site's own P-256 key). The one
  question "does it load" is asked in `Lazysite::Crypto::cryptx_missing`; without it the
  two features say they need it - on the account and sign-in pages, in the API answer
  and in `lazysite check` (a WARN when the site uses either, an OK line otherwise) - and
  nothing else changes. Declared in `dist/config/sbom-deps.json` (`Crypt::PK::ECC`,
  `Crypt::PK::RSA`, `Crypt::PK::Ed25519`).

threat delta
: ADR 0007's new-dependency-with-authentication-logic trigger fires: a passkey sign-in
  is decided by a signature CryptX verifies, so a flaw in its verification (accepting a
  forged ECDSA signature, a malformed key, a wrong curve) would be a sign-in bypass. Web
  push's use is signing only, of a token that authorises nothing on this site. The
  other three triggers are assessed in the SM1352 and SM1363 entries.

controls
: CryptX is the distribution's package (Debian security support), wraps LibTomCrypt,
  and is not reached unless a passkey is used or a notice is pushed. The engine never
  hands it a signature format it chose: an ES256 key must import as `secp256r1`, the
  algorithm is the one stored at enrolment (-7, -257 or -8) and never the one a sign-in
  names, the signed bytes are built by the engine (authenticator data then the SHA-256
  of the client data), and verification is the only call made on a sign-in. Missing,
  it refuses rather than degrades: no passkey is verified by anything else.
  t/unit/tools/118 (the check), and the SM1352 tests, which sign fixture keys made with
  CryptX in the test and are refused a wrong signature.

residual risk
: A vulnerability in CryptX's verification is the distribution's to fix, and reaches a
  site through the host's package updates, not lazysite's release. A host without the
  package simply has neither feature.

verdict
: accepted, contained, confirmed by the release manager on 2026-11-10 (ruling 225): the
  new-dependency-with-authentication-logic trigger fires; one dependency for two
  features, loaded only by them, and refusing when absent. No ahead-of-schedule
  third-party engagement beyond the one ADR 0007 already requires.

### 2026-11-08 - SM1352 (0.16.9, PENDING): passkeys

Assessment drafted by the developer agent (n784); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: A second interactive sign-in method beside the password: a passkey (WebAuthn). The
  auth wrapper gains `?action=passkey-challenge` (a fresh challenge, JSON) and
  `?action=passkey-login` (the signed answer, a form POST that ends in the password's
  own session and landing); `?action=claim` accepts a passkey in place of a password,
  so the first one is enrolled through the existing emailed one-time link. The control
  API gains four `self`, cookie-only actions (`me-passkeys`, `me-passkey-begin`,
  `me-passkey-add`, `me-passkey-remove`), and the users tool `passkey-add`,
  `passkey-remove`, `passkey-used` and the operator's `passkey-wipe` (through the
  `users` action, `manage_users`, not delegable). A group key, `passkey_only`, refuses
  its members' passwords in the password branch of sign-in. Public keys only are stored,
  in the account's record; challenges are one file each under
  `lazysite/auth/passkey-challenges/`. Built as ruled (ruling 187): attestation `none`,
  the key from `getPublicKey()` (SPKI DER), no CBOR; an ordinary local session.

threat delta
: ADR 0007's new-authentication-method trigger fires, and new-external-interface (two
  unauthenticated wrapper actions, four account actions). New-dependency is the CryptX
  entry. No restricted data is processed: a public key, a counter and a label. The
  questions:
  - Spoofing: could a signature the site did not ask for, one made for another site, a
    replay of a captured answer, or a cloned authenticator sign someone in? Could a
    passkey be planted in someone else's account?
  - Elevation of privilege: could a passkey sign-in skip a gate a password sign-in
    passes (disabled, expired, `ui` off, address limits, the rate limiter)?
  - Tampering: could a manager add a passkey to another person's account, as SM1042
    stopped them enrolling two-factor?
  - Denial of service: could an anonymous caller fill the disk with challenges?
  - Repudiation: is every sign-in, enrolment and wipe attributable?

controls
: A challenge is 32 random bytes, issued for one purpose (signin, enrol or claim; enrol
  and claim bound to one account), answerable for five minutes, and spent by the first
  answer that names it (a rename, so of two answers only one can have it). The client
  data's origin must be this request's own host over https, and the authenticator
  data's RP ID hash must be that host's; the user-present flag and the user-verified
  flag are both required (ruling 198: a passkey counts as two factors, so an
  authenticator without user verification is refused at enrolment, saying why); the
  signature is verified with the key and the algorithm stored at enrolment, over the
  bytes the engine builds; a counter that does not move forward is refused. At most
  1000 challenges wait at once; expired ones are removed as new ones are issued.
: A passkey sign-in passes the address scope, the shared rate limiter and every account
  gate of the password sign-in, in the same order, and mints the same session through
  the same code (`_land_signed_in`); only the TOTP step is skipped, a passkey being a
  second factor. A failure sleeps as a wrong password does and is audited with its
  reason.
: A passkey is added only by the account it signs in: through its own session
  (re-authenticated with the current password when it has one) or its own setup link.
  The manager API refuses `passkey-add`, `-remove` and `-used`; the users tool refuses
  an actor that is not the account; the operator may only wipe them all, which also
  ends the account's sessions and is audited. An account enrolled through a link has a
  locked credential marker, never an empty one, so the localhost no-password door does
  not open for it.
: `passkey_only` is checked after the password matched (it tells a guesser nothing),
  and a group store that cannot be read refuses every password sign-in, the
  operator's included (cannot tell, SM1024; ruling 206 withdrew ruling 197's
  operator exception): the log line and `lazysite check` name the file and its
  remedy, and the sysadmin repairs it from the command line.
: t/unit/auth/107 (ES256, RS256 and Ed25519 fixture keys made with CryptX in the test;
  a wrong signature, a replayed challenge, a wrong origin, another RP ID, a made-up
  challenge and a stale counter are refused), t/unit/auth/108 (passkey only),
  t/unit/auth/109 (the setup link), t/unit/account/36 (the account's own passkeys, the
  manager's refusals, the wipe), each sabotaged one control at a time.

residual risk
: An account that signs in by passkey only adds another only after a fresh assertion
  by a passkey it holds, answering a challenge issued to it (ruling 199); a stolen
  session alone cannot plant one. The
  authenticator's make is not checked (attestation `none`), so a software
  authenticator is as good as a phone's. The challenge directory is per site, so a
  flood of anonymous challenge requests can hold the 1000 slots for five minutes and
  delay passkey sign-ins (passwords are unaffected). User verification is the
  authenticator's own claim (its flag), as WebAuthn defines it.

verdict
: accepted, contained, confirmed by the release manager on 2026-11-10 (ruling 225). The
  method reuses the password sign-in's gates and session, adds no secret to the store,
  and its enrolment is the account's alone. No early third-party review: the passkey
  paths (the two unauthenticated wrapper actions, the account's enrolment and the
  `passkey_only` check) are named in the scope of the engagement ADR 0007 already
  requires (docs/compliance/OBLIGATIONS.md, the first third-party penetration test).

### 2026-11-08 - SM1363 (0.16.9, PENDING): notices by web push and by webhook

Assessment drafted by the developer agent (n784); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: Two new routes in Notify's existing route table, `webpush` and `webhook`, for a notice
  addressed to one account whose record chooses them (`notify_routes`, beside
  `notify_email`). Web push (`Lazysite::WebPush`) sends an empty POST, signed with the
  site's own VAPID key (`lazysite/auth/webpush-vapid.pem`, P-256, made on first use,
  0660), to each push endpoint the account's browsers handed over; the endpoints are kept
  in the account's record. The webhook route calls the named connector
  `webhook.connector`, in scheduled mode (ruling 188: SMS goes this way, to the
  operator's gateway). Three `self`, cookie-only account actions (`me-push`,
  `me-push-subscribe`, `me-push-unsubscribe`) and the users tool's `push-subscribe` and
  `push-unsubscribe`; `notify_routes` is a `settings-set` key, not a self-service one.
  The app's worker gains `push` and `notificationclick` handlers. `mail.per_hour` now
  bounds every route.

threat delta
: ADR 0007's new-external-interface trigger fires: an outbound interface to an address
  a browser chose (the push endpoint), and three account actions. The webhook adds no
  interface: it is a connector call, the existing outbound path. New-dependency is the
  CryptX entry. No sign-in method is added; no restricted data is processed in a new
  way, because nothing of a notice's content travels. The questions:
  - Tampering / Elevation of privilege (SSRF): could an account point the site at an
    internal address by registering an endpoint?
  - Information disclosure: could a notice's content (a submission, a message) leave the
    site by either route, or an endpoint (a capability for the device) leak?
  - Denial of service and cost: could a loop, or a public form, make the site push or
    text without bound?
  - Spoofing: could someone push to another person's device, or register a device on
    another's account?

controls
: An endpoint is stored only if it is https (or, in a test, a 127.0.0.1 fixture) and at
  most 1024 characters, at most five per account; at send time it must pass
  `Lazysite::Fetch::is_safe_url` (no loopback, private, link-local, CGNAT or multicast
  address), no redirect is followed, the body read is capped at 4 KB and the timeout is
  ten seconds. A push has no payload at all, so nothing of the notice reaches a push
  service; the webhook body is the notice's kind, title, the account's login and the
  link, never the message or a submitted field. The log names a device by host only.
: A device is added and removed by the account itself (the manager API refuses
  `push-subscribe` and `push-unsubscribe`; the users tool refuses an actor that is not
  the account). The webhook route needs the operator to name a connector, to permit it
  scheduled calls, and to set `notify_routes: webhook` on each account (not
  self-service, a text may cost money).
: Two hourly bounds count sends from one record (rulings 195, 199): `mail.per_hour`
  (default 60) every route but webhook, `webhook.per_hour` (default 20) the webhook
  alone, so a form flood cannot spend one through the other; each refuses when the
  record cannot be read; the connector's own rate cap and
  call record apply on top. Every attempt is a log line with its outcome.
: t/unit/notify/41 (a 127.0.0.1 fixture for both routes: the empty signed push and its
  JWT verified, the webhook's header and body, the refusals, the bound, the log lines,
  web push without CryptX), t/unit/account/38 (the devices, the route field, the
  refusals), each sabotaged one control at a time.

residual risk
: A push service learns that the site sent a notice to a device, and when; it learns
  nothing of what. The endpoint is checked by DNS at send time, so a name that
  re-resolves between the check and the connect could still reach a private address
  (the same window `Lazysite::Fetch` has). A device that has unsubscribed answers 404 or
  410 and is removed (ruling 199), through the users tool, as turning it off would be.

verdict
: accepted, contained, confirmed by the release manager on 2026-11-10 (ruling 225): the
  new-external-interface trigger fires and is contained. The new outbound path carries
  no content, is held to the SSRF guard's rules and a shared bound, and its other half is
  the existing connector path. No ahead-of-schedule third-party engagement beyond the one
  ADR 0007 already requires.

### 2026-11-09 - SM1363 (0.16.9, PENDING, ruling 196): an account's phone number

Assessment drafted by the developer agent (n784); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: Accounts gain an optional `phone` (international form, `+` and 8 to 15 digits), kept
  in the account's record in `user-settings.json`. The person sets or clears their own on
  `/account` (`::: account-phone`, the `self`, cookie-only action `me-phone`, a
  self-service `settings-set` key); an operator sets it on the Users page. It is carried
  in exactly one place: the body of the webhook route's connector call, so the
  operator's SMS gateway knows where a text goes.

threat delta
: ADR 0007's new-processing-of-restricted-data trigger fires: a phone number is personal
  data the engine did not hold before, and it now leaves the site to the gateway the
  operator configured. No interface beyond `me-phone`, no sign-in method, no dependency.
  The questions:
  - Information disclosure: where does the number go, and who reads it?
  - Tampering / abuse: could a member point the site's texts at a stranger's number?

controls
: The number appears in the webhook body only - not in web push (no payload), not in
  mail, not in the bell record, not in the log (t/unit/notify/41 asserts the bell). The
  webhook route reaches an account only when an operator set `notify_routes: webhook` on
  it, under its own low bound (`webhook.per_hour`, 20), through a connector the operator
  configured, whose call record carries no payload. The Users page and `settings-get`
  show it to managers, as they show the address. `me` shows it to the account. The form
  is checked in the users tool, the store's one writer (t/unit/account/39).

residual risk
: A member whose account an operator gave the webhook route can set any number in the
  right form, so texts can be sent to a person who did not ask; the bound caps how many,
  and the operator chose to give the route. The number is at rest with the rest of the
  account record (no at-rest encryption, as for the address). Retention follows the
  account: it goes when the account or the field is removed.

verdict
: accepted, contained, confirmed by the release manager on 2026-11-10 (ruling 225): the
  new-processing-of-restricted-data trigger fires and is contained - one optional field,
  one destination the operator chose, bounded. To be listed in the site's personal-data
  records with the address.

### 2026-11-08 - SM1357 (0.16.9, PENDING): the processor lists a domain's public page set for `lazysite check`

Assessment drafted by the developer agent (n785); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: `lazysite-processor.pl --page-set` prints, as JSON, the public page set of the
  domain HTTP_HOST names: each page's address, title and description, the pages its
  `sitemap.xml` and `llms.txt` list (`registries.pm _public_page_set_listing`, over
  `scan_pages` and ruling 174's `_public_page_set`). `lazysite check` runs it once per
  domain for its title and description checks, in place of its own walk of the docroot.

threat delta
: No ADR 0007 trigger fired. new-external-interface comes closest and is not met: the
  mode answers only on the command line - it is refused when GATEWAY_INTERFACE or
  REQUEST_METHOD is set, which every web server sets, so a CGI query string with no `=`
  (which a server may pass as arguments) cannot reach it. What it prints is the set the
  domain's sitemap and summary already publish, so nothing in it is new to a visitor.
: Information disclosure: the listing is the registries' own set, so a protected,
  draft, copied, api/raw or `search: false` page and another domain's pages are left out
  as they are from the sitemap (t/unit/processor/187 holds the set; t/tools/381 holds
  the per-domain reading).

controls
: t/tools/381 (per domain, ruling 171's folders not counted), t/tools/340 (the
  findings), t/unit/processor/187 (the page set).

residual risk
: `lazysite check` run as root runs the processor as root; it reads the docroot and the
  conf and writes nothing (its log lines go to standard error, which the check discards).

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225): no trigger
  fired; recorded because the processor gains an entry point outside a request.

### 2026-11-09 - SM1416 (0.16.9, PENDING): the FastCGI pool runs the site's own engine (ruling 203)

Assessment drafted by the developer agent (n791); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: A version-consistency hardening. The pool launcher (`tools/lazysite-pool.pl`, run by
  `lazysite@.service`) exec'd the package's processor, so after a package upgrade a site
  had not taken, its pool rendered with the package's engine and its manager, auth and
  DAV CGIs with the site's own: one site, two engine versions, and two sets of controls
  (n788). It now execs the site's own processor, from the cgi-bin the pool already relays
  to (`CGIBIN=`, else the docroot's sibling), with the lib beside the docroot. A site
  whose processor, processor parts or lib is missing or unreadable to the pool's account
  is answered 503, logged by path, and never served by the package's engine; `lazysite
  check` reports it as a FAIL with the remedy (ruling 206). A shared read-only engine
  (SM1361's `SHARED-ENGINE` marker at the launcher's own engine root) keeps running that
  engine, as before.

threat delta
: ADR 0007's code-loading boundary is touched: which processor the pool runs. None of
  the four triggers fires: no new external interface, sign-in method, dependency or
  processing of restricted data. The questions:
  - Tampering and Elevation of privilege: could the pool now be pointed at other code?
    It runs the file the site's own CGIs already run, as the site's account, after the
    privilege drop; the pool conf naming `CGIBIN=` is root's file in `/etc`, as before.
  - Tampering: could a site plant the shared-engine marker to get the package's engine?
    The marker is read from the launcher's own tree, never the site's, and a link is no
    marker.
  - Denial of service: a broken site tree now gets 503 rather than a silently skewed
    render; that is the fault being refused, named, and fixable from the command line.

controls
: t/integration/458 runs the launcher from a package tree whose engine leaves a mark:
  with the site's tree in place the page renders with the site's engine and the mark is
  never made; with the site's processor gone the request gets 503, the mark is never
  made, the log names the file and `lazysite check` names the fault and the remedy. It
  fails with either change reverted.

residual risk
: A site that has not run `upgrade` keeps its own engine's behaviour, including any
  fix the package carries, until it does; that is the one-version rule ruling 203 asks
  for, and the upgrade path is unchanged. A security release still reaches it through
  `upgrade --all --force-security`.

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225): no trigger
  fires; a version-consistency hardening.

### 2026-11-09 - SM1417, ruling 206 items 1-8 (0.16.9, PENDING): a broken store or setting refuses access

Assessment drafted by the developer agent (n789); confirmed by the release manager on
2026-11-10 (ruling 225). A hardening: eight places that worked around a damaged access store or setting now
refuse (cannot-tell, 503 or the sign-in page's "unavailable"), and `lazysite check` and
the log name each fault and its remedy, repaired from the command line (rulings 206,
207). An absent store is still "nothing configured" in every case.

what changed
: 1, data loss. A rule set or removal, a file copy, a `.url` migration or a table rule
  over an acls.json that would not read or decode replaced it with the one rule written,
  dropping every other; each writer, and save_acls itself, now refuses and leaves the
  file byte-identical (t/integration/438).
: 2. A broken acls.json still let the operator (file_rule_bypass) read and write every
  file, and every table's rows; the operator is refused with everyone (t/integration/188).
: 3. The auth store lock failed open, so an account change or a single-use secret's
  redemption ran unlocked and a reset link could be redeemed twice; both doors of the
  users tool refuse (t/unit/users/136).
: 4. The login rate limiter allowed every sign-in without DB_File or with a counter it
  could not open; it refuses every sign-in, the extension switched off excepted
  (t/unit/auth/24, t/tools/70).
: 5. On the render path an undecodable groups-settings.json read as {}, losing SM1140's
  address-refused groups so their members still matched `@group`; a signed-in request
  is refused 503 (t/integration/439).
: 6. An unreadable groups file minted a session with no groups, lifting deny-by-group
  rules; sign-in and every session are refused (t/integration/440).
: 7. A rejected or missing content_root served the docroot root under the host's name;
  that host is refused 503 (t/integration/17).
: 8. An out-of-range session_lifetime or password_min_length became the default; sign-in
  and sessions, or every password set, are refused (t/integration/441).

threat delta
: None of ADR 0007's four triggers fired: no new interface (existing doors refuse more),
  no new sign-in method, no new dependency, no new restricted data.
: Tampering, closed (1): an ordinary write could destroy the whole rule set. Elevation of
  privilege, closed (2, 5, 6): rules the engine could not read were passed, or deny rules
  silently lifted. Spoofing, closed (3, 4): a single-use secret could be spent twice, and
  guessing went unthrottled. Information disclosure, closed (7): another site's pages
  were served under a host's name. Repudiation, unchanged.
: Denial of service, by design: each fault now stops sign-in, a host, or rule changes
  until it is repaired. That is ruling 206's choice over a guessed answer; the
  sysadmin repairs it from the command line, and nothing a visitor sends can cause any of
  these states.

controls
: One wording family: the existing cannot-tell refusals (_acl_denied's SM1024 refusal,
  now acls_fault_refusal; session_store_fault; the sign-in page's error=unavailable),
  each naming the store and `lazysite check --docroot`. `lazysite check` lines: the
  acls.json and groups-settings.json FAILs (existing, item 1's restated); new FAILs for
  .consume.lock, the rate counter (unopenable, missing DB_File, not a database), the
  groups file the CGI cannot read, every rejected content_root and both settings. The
  tests named above, each failing with its change reverted.

residual risk
: A refusal is loud only where it is looked at: the visitor sees "unavailable" and the
  operator must read the log or run the check. When the limiter cannot count, the Odoo
  sign-in (extensions/odoo) and an OIDC sign-in start each answer cannot-tell, 503, in
  the limiter's own `fault_refusal` words (rulings 212, 223, 226; t/unit/odoo/260,
  t/unit/extensions/200), not "too many attempts"; over the cap a working limiter still
  answers rate. A host on
  which DB_File is genuinely absent (it is core Perl on Debian; perl-DB_File on RHEL) now
  refuses sign-in until it is installed or the extension is switched off.

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225). No trigger
  fired; recorded because it changes what eight access decisions answer on a damaged
  host.

### 2026-11-09 - SM1417 (0.16.9, PENDING): a damaged store refuses writes and sends, and says so (ruling 206, survey items 9-21), a hardening

Assessment drafted by the developer agent (n790); confirmed by the release manager on
2026-11-10 (ruling 225). Items 1-8 of the same survey (access) are n789's, under the same number.

what changed
: Ruling 206: a store that exists and cannot be told is a fault; the engine refuses
  (cannot-tell, 503 where it answers a request) and never works around it, and
  `lazysite check` and the log name the store and the remedy. One wording,
  Lazysite::Util::store_fault. Absent stores stay legitimate throughout.
: Item 9: an upload counter (`manager/.upload-rate.db`) that will not open, or no
  DB_File, refused nothing - the hourly budget was off. Every upload is now refused.
: Items 10 and 11: a line of `notify/suppressed.jsonl` or `notify/ledger.jsonl` that is
  not a record was skipped, so a person who unsubscribed was mailed again, or a notice
  went twice. The outbox run now sends nothing and keeps its queue.
: Item 12: the submitter-mail, notice-mail and connector-call records skipped a bad
  line, so their caps undercounted. Each cap now refuses.
: Items 13, 14 and 15: the scheduler's run record, the notify status and the connector
  call sweep healed a damaged file by rewriting it without the damage. Each now leaves
  the file as found; the scheduler runs no job, the sweep sweeps nothing.
: Item 16: a failed query in a migration, rebuild or import pre-flight read as "no
  rows". Each now refuses.
: Item 17: a damaged daemon service state file hid an orphaned service, so the
  supervisor started a second copy. It now starts no service (exit 4).
: Items 18-21 (display): the manager door answers cannot-tell, not "ask for a grant",
  for an undecodable groups-settings.json; a forgot-password request the host cannot
  match answers `error=unavailable`, not the generic reset page; an undecodable
  install state and an unreadable notice template are logged and said.

threat delta
: None of ADR 0007's four triggers fires: no new interface (existing doors refuse more
  or say more), no new sign-in method, no new dependency, no new restricted data.
: Tampering and repudiation, narrowed: a person able to damage one of these files (the
  site user, or a fault on the host) could switch a cap off, re-send to someone who
  unsubscribed, or erase the record of the damage through a self-healing rewrite. Each
  of those now stops the action and leaves the file for the sysadmin.
: Denial of service, by design: a damaged store stops the action it guards for every
  caller until it is repaired - uploads, notification sends, scheduled jobs, the
  daemon's services. That is ruling 206's trade (a damaged site, the sysadmin
  resolves); no fault is reachable from a request.
: Information disclosure: unchanged. Refusals to a caller name docroot-relative stores
  (SM494); the forgot-password answer says only that the host is unavailable, the same
  for every identifier; the manager page names no file.

controls
: t/unit/manager/562, 563, 564; t/unit/notify/81, 82; t/unit/forms/149;
  t/unit/daemon/07, 11, 88; t/unit/data/160; t/unit/processor/258; t/unit/auth/147;
  t/tools/411. Each fails with its change reverted.

residual risk
: A damaged store refuses until a person repairs it; nothing repairs it for them, by
  ruling. The ruling's other side is that the check must name every such store:
  t/tools/411 holds the list for this branch. The unsubscribe store's `record` still
  appends past a bad line (an append loses nothing and the read refuses).

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225). A hardening; no
  trigger fires.

### 2026-11-09 - SM1361, SM1369 X7 (0.16.9, PENDING): the shared read-only engine's loader rule

Assessment drafted by the developer agent (n788); confirmed by the release manager on
2026-11-10 (ruling 225).

what changed
: A volume-hosted site runs the image's read-only engine (rulings 200, 201, 205). The
  image marks itself with a file, `SHARED-ENGINE`, at the engine's root. On an engine
  carrying it, where an extension's code is found changes (`Lazysite::Extensions`,
  `Manager::Extensions::extension_registry`, `Hooks::_shadowed`):
  - every extension is the engine's copy;
  - anything in the site's extensions dir is refused by name: never found, never
    registered, logged, and named by `lazysite check` (ruling 210: the shared container
    belongs to one operator and only the image's own extensions run in it);
  - a site payload's module that an engine extension's payload lib holds is refused.

  An engine without the marker (every package and tarball install, so Hestia and the deb
  hosts) is unchanged. `install.pl` gains `--engine shared` (and the marker as its
  default): a site laid that way holds no engine copy. Separately, the Odoo extension
  ships in its own deb, `lazysite-odoo`, and an upgrade from a payload without it refuses
  a site that has it on, before anything changes.

threat delta
: ADR 0007's code-loading boundary is touched: which file runs for an extension. No
  trigger of the four fires (no new external interface, sign-in method, dependency of the
  engine itself, or new processing of restricted data). `lazysite-odoo` Depends on
  libodoo-oom-perl, which `lazysite-common` already listed in the SBOM as the
  extension's. The questions:
  - Tampering and Elevation of privilege: could a file planted in a site's extensions
    dir run in place of an engine extension, or could a site's own extension name an
    engine extension's module as its own?
  - Tampering: could the marker be planted to switch a host site onto the shared rule?
  - Tampering: could a link anywhere on the path point the loader at other code?

controls
: Only the engine's directory is read; every site extension file is refused, logged
  and named by the check with its remedy. A hook module is checked against every engine
  payload lib, loaded or not, at the index build and at the call. The marker is read from
  the engine's own root, found from where the loaded lib is, never from a site's tree; the
  image is root-owned and read-only to every site process. Links are refused at the
  descriptor, the payload, its lib and the module file, as before, and a linked marker is
  no marker. Tests: t/unit/extensions/130, t/tools/391, t/tools/392, t/lint/391,
  t/lint/392.

residual risk
: Every site in the shared container runs as www-data (ruling 210): the container is one
  operator's, and a site's code is the image's code. One site's engine process can read
  another site's state there; the separation between sites is the engine's own
  confinement of each request to its docroot, not the operating system's. A site whose
  end user takes it over moves to a dedicated service (Hestia, or a container of its own).

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225): no trigger
  fires; the code-loading boundary is touched and recorded.

### 2026-11-09 - T-115 (0.16.9, PENDING): the account and form stores on a site whose engine tree is beside its docroot

Assessment drafted by the developer agent (n788); confirmed by the release manager on
2026-11-10 (ruling 225). A hardening.

what changed
: On the beside layout (SM293/SM850: `<docroot>-lazysite`, which `lazysite
  migrate-engine-tree` makes and the shared container lays from the start), released
  0.16.8 had four gaps:
  - `install.pl`'s `mode_for` named the engine tree as `/lazysite/` only, so it laid the
    auth and forms seeds and `forms/smtp.conf` at 0644;
  - its group-write step joined the declared `{LAZYSITE}/...` rows to the docroot and
    so reached no file at all, on either layout;
  - `forms/`, declared 2770, was applied by the check alone;
  - `lazysite check` tested world bits on the secrets list only.

  Now:
  - `mode_for` asks for the tree;
  - the group-write step resolves its rows through the placeholders;
  - the install applies `forms/` 2770 (repaired on every upgrade, as `auth/` is);
  - `forms/*.conf` is laid 0640;
  - `lazysite check` fails a world bit on `auth/users`, `auth/groups`,
    `auth/acls.json`, the `auth/` and `forms/` examples and either directory, and
    `--fix` (with `lazysite repair`) sets 0660, 0640 or 2770 to match the declared
    mode. Both layouts are covered, through `model_path`.

threat delta
: None of ADR 0007's triggers fires. Information disclosure, narrowed: a local account
  on the host could read a beside site's seeds, its form configs and an SMTP password
  saved into `smtp.conf` by hand while it was 0644, where `forms/` had world access.
  `auth/` itself was 2770 and repaired on every upgrade, so the account store's files
  were unreachable to others. The exposure was low, and it was real only for
  `forms/`.

controls
: t/tools/394 provisions a beside site with the real `install.pl`, puts it in the state
  0.16.8 left, and upgrades it. It checks that no world bit is left under `auth/` or
  `forms/`, that `forms/` is 2770, and that the user store is group-writable again. The
  real check then names a world-readable user store and a world-readable `forms/`, and
  `--fix` sets each to its declared mode. It fails on the previous commit.

: Ruling 215: every install (`align_store_modes`) also sets the declared mode on each of
  those paths, whether or not it was edited. It changes modes only, never content, and
  never acts through a link, so an upgrade never leaves a site unserviceable over a mode
  lazysite set wrongly itself. The auth code's lock (`auth/.consume.lock`) and the
  sidecar lock beside a store (`Lazysite::Util::store_lock`) are set to 0660, not left
  to the umask. t/tools/394 covers an edited 0644 example passing the check after the
  upgrade with no repair, and both locks at 0660 under umask 022.

residual risk
: A mode that drifts after an install is named by the check, and `lazysite repair`
  fixes it. A path owned by another account, which the install cannot chmod, is left
  for the same repair.

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 225): no trigger
  fires; a hardening.

### 2026-11-10 - SM1418, SM1407 (T-112), SM1404 (T-113), SM1398 (T-114), the container's tooling and the restack's wording (0.16.9): the rest of 0.16.9, with no trigger

Assessment drafted by the developer agent at the 0.16.9 compliance walk (SM1419);
confirmed by the release manager on 2026-11-10 (ruling 226); ruling 225 puts n794
(SM1418) in this list.
The walk read the CHANGELOG's `## Unreleased` section and `git log
8a2806723..63e8f1970` (102 commits). The rest of 0.16.9 moves no control:
SM1418 (n794) makes the XMPP notice account answer a presence subscribe from the
configured recipient only, and ask for its own subscription once; SM1407 (T-112) runs
the layer-role adoptions from the Groups page as the Users page already ran them, and a
groups listing carries each group's `seeded` mark; SM1404 (T-113) takes the permissions
editor's address-profile choices out of the manager API's `list`, so the operator's
listing is MCP's; SM1398 (T-114) gives a page body the `| json` filter and refuses on
save a filter a body lacks; the shared container's tooling, `lazysite-sites`, the
per-site pools, the 503 for a refused site and the supervisor's refusals (SM1361's
commits after the loader rule, rulings 206, 208, 218, 220) is operator packaging inside
the container; the restack's wording (rulings 216, 217) gives a damaged store the
engine's one refusal and the front door's status a number; the rest is lint and test fix-ups and renumbering; SM1419 is this
walk. The other changes of 0.16.9 have their own entries, confirmed by the release
manager on 2026-11-10 (ruling 225): SM1369 X4 (firing the sign-in-method trigger,
contained), X5, X6 and X7, SM1351 (firing the sign-in-method and new-external-interface
triggers, contained), SM1352 passkeys (firing new-authentication-method and
new-external-interface) and the CryptX dependency (firing
new-dependency-with-authentication-logic), SM1363 web push and webhook (firing
new-external-interface) and the phone number (firing
new-processing-of-restricted-data), SM1364 (firing new-processing-of-restricted-data,
ruling 190), SM297, SM1357, SM1416, SM1417 (items 1-8 and 9-21), SM1361 and T-115.

what changed
: SM1418 (n794). `Notify`'s XMPP delivery connected, sent and left, so the account never
  answered a presence subscribe and a chat client showed an unusable contact. While
  connected for a send to a person, it approves a `subscribe` whose bare JID is the
  configured recipient's and no one else's, and asks for its own subscription once
  (not when the roster says `to`, or one is pending). A group chat gets no step; a
  presence step that fails is logged and the notice is still sent; messages stay plain
  body and nothing is published under OMEMO (t/unit/lib/322).
: SM1407 (T-112). The Groups page's read did not run the adoptions the users tool runs
  where it seeds, so `analysts` and `lead-readers` did not arrive until the Users page
  was opened. It runs them (t/unit/users/116); each role is adopted once with no
  members and stays deleted after an operator deletes it, as SM1407's 0.16.8 entry
  assessed. The groups listing carries each group's `seeded` mark.
: SM1404 (T-113). The manager API's `list` still carried the address-profile choices
  beside the entries, so an operator's listing of a folder under a rule naming a profile
  showed an entry named after it where MCP `list_files` did not; the Files page reads
  them with the other picker lists, from `principals`, and `acl-get` carries them as
  before (t/unit/manager/532).
: SM1398 (T-114). `[% page_url_raw | json %]` in a page body was left as written: `json`
  was a layout's and a component's filter only. The page-body render has it, and a
  filter a body lacks (beyond Template Toolkit's own, `json` and `url_safe`) fails the
  body at render, so it is refused on save and named by `validate_page`
  (t/unit/processor/228). The guard reads Template Toolkit's standard filter names from
  `Template::Filters`, a module of the dependency already declared, now declared in
  sbom-deps.json.
: The container's tooling. `lazysite-sites` runs inside the container, by whoever holds
  `docker compose exec` on the host, and talks to the supervisor by SIGHUP; a site that
  fails or is newer than the image is refused, answers 503 and is named while the others
  serve; the run directory belongs to www-data and the supervisor refuses what it cannot
  supervise (t/tools/393, 395, 396).
: The restack's wording. A damaged store gets the engine's one refusal, which names no
  file to a visitor (t/integration/498, 499).

threat delta
: None of ADR 0007's four triggers fired: no new interface (the delivery makes the
  connection it already made; the container's tooling has no request path), no new
  sign-in method, no new dependency and no new restricted data. The questions are these.
: SM1418: Spoofing, by someone else's presence request approved as the recipient's. The
  comparison is the bare JID of the sender against the configured recipient's, and any
  other sender is not answered. Information disclosure: the account's presence now
  reaches the recipient, who already receives the notices. The account asks to
  subscribe to a recipient it already sends to.
: SM1407: none. The adoption is the one SM1407's 0.16.8 entry assessed, run from one more
  door, with no member and no capability granted by it.
: SM1404: Information disclosure, narrowed: the operator's listing no longer carries the
  site's address-profile names, which only the permissions editor reads.
: SM1398: Tampering and Elevation of privilege, none: `json` encodes a value for output
  and gives a page body no data a body could not name; refusing an unknown filter on
  save narrows what a body may contain.
: The container's tooling: Elevation of privilege, none beyond the loader rule's own entry
  (SM1361, SM1369 X7): it is reached by the host's operator, acts with the container's
  rights, and no visitor's request reaches it.
: The restack's wording: Information disclosure, narrowed, since the one refusal names
  no file to a visitor.

controls
: SM1418: t/unit/lib/322 (a subscribe from the recipient is approved, one from another
  is not, the account asks once, a failed step still sends). SM1407: t/unit/users/116.
  SM1404: t/unit/manager/532. SM1398: t/unit/processor/228. The container: t/tools/393,
  395, 396. The restack: t/integration/498.

residual risk
: SM1418: the approval holds only while the account is connected for a send, so a request
  the recipient makes between sends waits for the next send. SM1407: a role an
  operator deleted stays deleted. SM1398: a page body
  already saved with a filter it lacks is refused when it next renders and when it is
  next saved. The container: the loader rule's entry carries its residual risk (every
  site runs as www-data).

verdict
: accepted, confirmed by the release manager on 2026-11-10 (ruling 226). No trigger
  fired; recorded because SM1418 makes the notice account answer a presence request and
  the rest changes what a listing, a refusal and a page body carry. 0.16.9 is edge, not
  security-critical (ruling 226): it fixes no known vulnerability (SM1417 and T-115 are
  hardenings; OBLIGATIONS.md, the vulnerability-handling row).

### 2026-11-10 - SM1422 (PENDING): a manager cannot point a new OIDC map entry at a capability group

Assessment drafted by the developer agent (n801); confirmed by the release manager on 2026-11-10 (ruling 233). Found proving SM1351 against a local authentik (ruling 227).

what changed
: `Lazysite::Ext::OIDC::validate_group_map`, the settings form's check of a provider's
  group map (ruling 214, Q129), kept for a caller who is not the operator every site
  group the stored map already named, whatever provider group it came from. With the
  operator's `staff = staff` saved, a `manage_config` holder saved `members = staff`, and
  a person in the provider's `members` group alone signed in audited `groups granted:
  readers,staff`. It now keeps an entry only as saved: the provider group and the site
  group together. A new entry to a capability group, or the operator's moved to another
  provider group, is refused `forbidden`; the operator's saves are unchanged.

threat delta
: Elevation of privilege, narrowed: before the fix a `manage_config` holder could widen
  who holds a capability group's capabilities (operators included, once the operator had
  mapped any provider group to it) to any group at the provider, which ruling 214 keeps
  to the operator. No ADR 0007 trigger fires: no new interface, sign-in method,
  dependency or processing of restricted data; it restores the control SM1351's entry
  records ("only the operator saves a map entry whose target carries capabilities").

controls
: t/unit/manager/743 through the manager API: the editor's new entry to a capability
  group the map names, and the operator's entry moved, are refused 403 and nothing is
  written; the editor keeps the operator's entry while adding a plain one; the operator
  may add the entry. It fails with the old comparison put back. t/unit/manager/582 still
  passes.

residual risk
: An entry a manager saved before the fix stays in the map until the operator removes
  it; the audit trail's `extension-save` rows name who saved each map, and every
  sign-in's `login-grant` row names the groups it granted.

verdict : accepted, confirmed by the release manager on 2026-11-10 (ruling 233): a fix to a control 0.16.9 shipped
  (SM1351, ruling 214). Ruling 229 (2026-11-10) rules how it ships: in 0.16.10, not
  security-critical, with no advisory, because the code is only in 0.16.9 (edge), off by
  default (the `oidc` extension is off until an operator turns it on), in no stable
  release, and fixed before the beta. 0.16.10 is edge, not security-critical, with no advisory (ruling 229, ruling 233).

### 2026-11-10 - SM1420, SM1421, SM1423, SM1424, SM1425, SM1426, SM1427 (0.16.10): the rest of 0.16.10, with no trigger

Assessment drafted by the developer agent at the 0.16.10 compliance walk (SM1429); confirmed by the release manager on 2026-11-10 (ruling 233).
The walk read the CHANGELOG's `## Unreleased` section and `git log 64d5c3c11..17a681a71`
(23 commits). SM1422 has its own entry above. The rest of 0.16.10 moves no control and
fires none of ADR 0007's four triggers (no new interface, sign-in method, dependency or
processing of restricted data). Each item below was checked against the code it names.
Two defects the walk found were fixed in the same branch, one commit each, with a test
that fails without it (see "what changed").

what changed
: SM1427 (n807). `installers/hestia/lazysite-hestia-deploy.sh` runs as root on a host
  that runs lazysite from the tarball. On a first-time deploy it now also applies the
  `lazysite-proxy` template when Hestia has it, sets `site_url` through the new
  `install.pl --site-url` (run as the site user), writes `/etc/lazysite/sites.d/DOMAIN`,
  and with `--sysop NAME`, once the health check passes, runs `setup-sysop` as the site
  user and prints the claim link as a full URL. `--all` on the fleet verbs (check,
  repair, probe, upgrade, users, sites) is now the registry's sites and the Hestia
  list's together, merged by docroot with the registry entry winning
  (`_all_sites`, ruling 231); `repair` and `probe` take `--docroot D`, as their usage
  line said; the installer's group message and `setup-sysop`'s wording are fixed
  (t/tools/621-625).
: SM1423 (n803). The container image installs Debian's `git`, so content history can be
  turned on in it; the move from the 0.16.1 Docker recipe is written out as numbered
  commands in `installers/docker/README.md`. On an upgrade, `align_store_modes` also sets
  the declared mode (mode only) on every directory the install model declares
  (`install_dirs`) and on the runtime paths marked `on_upgrade: repair` (t/lint/563,
  t/tools/581).
: SM1424 (n804). Wording only. A change (save, delete or move) refused by an address
  rule says the rule limits changes to its allowed addresses and that the change must
  be made from one (`address_denial`'s `write` mode); `kind: address` and
  `retryable: false` are unchanged and a read keeps its sentence. `lazysite check` and
  `validate_page` say a `description:` front-matter key is not read (the engine reads
  `meta_desc`, else `subtitle`; `description-not-read`). The 0.16.9 upgrade note says
  when `analysts` and `lead-readers` arrive; the Odoo capability's description and the
  capability map name Extensions - configure as the page that has the card.
: SM1425 (n805), SM1426 (n806). The display-only `lzs_session` marker, which carries no
  authority, is written by one function, `Lazysite::Auth::Session::session_marker_header`.
  The sign-in wrapper (`_land_signed_in`), `session_cookie_headers`, the OIDC endpoint's
  and the Odoo endpoint's renewals all call it, so a session renewed in place sets the
  marker again (the verifier's stale answer had cleared it) with the attributes a
  sign-in gives it (t/lint/592, t/unit/extensions/170, t/unit/odoo/135).
: SM1426 (n806). `debian/control` lists `git` in `lazysite-common`'s Recommends,
  beside the image's own install (t/lint/593).
: Fixed at the walk (SM1429). `lazysite repair` ran the check before the repair, the
  `--fix` run and the check after as one string through the shell with the docroot and
  cgi-bin unquoted; they are now list-form pipes (`_capture`), the output read as before
  (t/tools/626: a docroot named with `;touch MARK` and `$(touch MARK2)` is repaired and
  no file appears; it fails without the change). The deploy now refuses, with exit 2 before
  anything is touched, a DOMAIN that is not a plain host name (letters, digits, dots and
  hyphens, no slash or space, no leading dot or hyphen), a USER that is not a plain name,
  and a USER Hestia does not hold (`v-list-user`); its summary says the claim link is a
  credential for 24 hours (t/tools/627, which fails without the change).
: SM1420, SM1421 (n799, n800). Output and docs only. Eight shipped docs pages get titles
  that say what they are and two get a subtitle, so the shipped docs pass their own
  `lazysite check` (t/tools/552). `lazysite check` over a sound DB_File counter prints
  nothing on STDERR, a check message quotes its apostrophe, and `lazysite repair` says
  how many changes it applied beside the "awaiting your decision" count and shows its
  report as one block (t/tools/562-564).

threat delta
: None of the four triggers fired. The questions are these.
: SM1427, Elevation of privilege: a root-run script writing into `/etc/lazysite` and
  acting on a site tree the site user owns. Nothing it writes into the registry comes
  from the site tree: the five fields (docroot, cgibin, owner, channel, policy) are
  built from the command line's USER and DOMAIN, the entry is written only when none
  exists (tested with `-e`, written to a temporary file and moved with `mv -n`), mode
  0644, in the order `lazysite provision` writes (t/tools/624). The one thing it reads
  from the site tree as root is `site_url` in `lazysite.conf`, matched in a `case` and
  never run. `install.pl --site-url` and `setup-sysop` run as the site user through
  `sudo -u`, not as root, and the site user already writes that configuration file
  and that tool. The sign-in method is `setup-sysop`'s existing single-use claim link
  (24 hours, `$CLAIM_TTL`), made by the person running the deploy as root; nothing new
  signs anyone in. The fleet merge widens which sites a root-run `--all` names, but
  `upgrade --all` still skips a site whose `update_policy` is not `auto`
  (`site_update_policy`, read from the site's own conf, `manual` when unset) unless
  forced, and a host with an empty registry already took the Hestia list alone.
: SM1423, Tampering: `git` in the image, and a mode set on upgrade. `git` was already a
  declared optional host binary (dist/config/sbom-deps.json, SM085), invoked list-form
  and never through a shell; the image installs it from Debian unpinned and content
  history stays off until a site turns it on. The upgrade sets only the mode, never an
  owner, group or content, only below the docroot or the `lazysite/` tree, never
  through a link, and only on an upgrade, never on a provision or reinstall; the
  declared modes are 0755, 2770 and 2775 (no world-writable directory), the ones
  `lazysite check` already fails a directory for missing.
: SM1424, Information disclosure: the write refusal tells a caller that a rule limits
  changes by address; the read sentence it replaces implied the same, and it names no
  address and no profile. `description-not-read` and the check line name the pages that
  carry the key to an operator who can already list them.
: SM1425 and SM1426, Spoofing: a marker set when no session exists shows a signed-in
  control to a visitor. No server code reads `lzs_session` (a search of `lib/`, the
  `lazysite-*.pl` scripts, the processor, the extensions and `tools/` finds it only set
  or cleared); the HttpOnly session cookie, verified by `verify_session_cookie` and
  `request_session` on every request, stays the gate, and the renewals set the marker
  only after a successful renewal (`$renewed`). The attributes are the sign-in's:
  `SameSite=Lax; Path=/`, `Max-Age` from `session_lifetime`, `Secure` under https, and
  deliberately not HttpOnly (SM099).
: SM1426, deb Recommends: `git` on a host that did not have it. It is a Recommends and
  history is off until a site turns it on.
: SM1420, SM1421: none. Titles and wording, and the text a verb prints.

controls
: SM1427: t/tools/621-625 and 627 (the group message, the options a verb takes, `setup-sysop`'s
  wording, a first deploy with its registry entry, site address, claim link and refusals
  before anything is touched, and `--all` over the registry and the Hestia list
  together). `--sysop NAME` is held to letters, digits, `.`, `_` and `-` and `--channel`
  to the four channels before the script touches anything. `install.pl --site-url`
  takes an absolute http or https origin with no path and no placeholder, and records
  `site-url-set` in the audit log. SM1423: t/lint/563 (the image installs the programs
  the engine runs), t/tools/581 (an upgrade sets the declared mode on a directory the
  0.16.1 recipe left wrong). SM1424: t/tools/591, t/unit/extensions/381, t/unit/mcp/258,
  t/integration/281, t/unit/users/317. SM1425/SM1426: t/unit/extensions/170,
  t/unit/odoo/135, t/lint/592 (one writer, fails without the change), t/lint/593.
  SM1420/SM1421: t/tools/552, 562-564. The walk's two fixes: t/tools/626, 627.

residual risk
: SM1427: the claim link is printed to the terminal of whoever runs the deploy, as
  `setup-sysop` prints it by hand, and is a credential until used or 24 hours pass, so a
  deploy whose output is logged logs it; the summary now says not to paste it into a
  ticket or a log, and the behaviour is left as it is. The output of `setup-sysop`, which
  runs as the site user, is printed as it came. USER and DOMAIN are validated (fixed at
  the walk, above), so the earlier residual risk that they were checked only by the
  docroot existing is closed; the repair's shell use (SM1421) is fixed too. SM1423: a directory a sysop had tightened below its declared mode is set back to it
  at the next upgrade.

verdict : accepted, confirmed by the release manager on 2026-11-10 (ruling 233). No trigger fired; recorded because
  the Hestia deploy now acts as root on a site and writes the registry, the fleet verbs
  name more sites, and the upgrade sets modes. 0.16.10 is edge, not security-critical
  (ruling 229): it fixes no vulnerability that reached a stable release (SM1422 is
  its own entry); the two defects fixed at the walk were a shell use of a path (the check
  calls predate 0.16.10, the `--fix` call is its own) and 0.16.10's own deploy; neither
  reached a stable release, and each needs a path or argument the root operator supplies.

### 2026-11-11 - SM1435 (PENDING): address profiles are chosen from those that exist

Assessment drafted by the developer agent (n812, with the 0.16.11 compliance walk, SM1436); confirmed by the release manager on 2026-11-11 (ruling 237). Ruling 234 (the release manager, 2026-11-11) reverses SM1139's accept-with-warning; ruling 235 (a developer call) extends it to a page's front matter, and is confirmed with the entry.

what changed
: Before, a rule could name an address profile the store did not hold. An `acl-set` answered
  `ok: true` with a warning, and the rule was stored. A name no profile carries matches no
  address (`Lazysite::Auth::AddressProfiles`, logged once per name per process), so a rule
  that allowed it admitted nobody and a rule that **denied** it excluded nobody: a deny list
  naming a profile that was misspelt, not yet created or since deleted failed open, and the
  save said nothing a person had to read. Address profiles are now predefined and selectable
  only, and a save that names a missing one is refused, naming each, with nothing written.
: The doors, all of them (`Manager::Common::address_profiles_missing` is the one lookup):
  a rule on a path, through `Files::action_acl_set`, which the manager API's `acl-set`, MCP
  `set_permissions` and `lazysite acl set` all run (a list of paths is refused whole, and the
  names the rule already carries are checked too, so a rule left naming a profile removed by
  hand is refused on its next save until the name is cleared); a group's address limit
  (`addresses`, `addresses_deny`, `address_limit` in `group-settings-set`, the Groups page and
  the users tool); a page's front matter `addresses:` and `addresses_deny:` (ruling 235)
  through the content write choke point (`Files::_content_write_refusal`: the manager save,
  the control API, MCP `write_file` and `create_page`, and `preview_page`'s draft check) and
  WebDAV `PUT`, which asks the same function before its rename; `validate_page` reports it as
  an issue, and `lazysite check` keeps warning of a page already on disk.
: A profile a rule names cannot be deleted. `address-profile-delete` had a force path (the
  users tool's `--force`, the API's `force`, the page's "Delete anyway") that deleted a profile
  a rule still named and left that rule refusing everyone (an allow) or excluding nobody (a
  deny). It is gone at every door: `--force` is an unknown option, `force` is not read and
  no longer declared, and the Address profiles page shows the refusal, naming the rules. A
  profile in use may still be changed, and MCP exposes no delete.

threat delta
: Elevation of privilege and information disclosure, narrowed. The fail-open case is the one
  that mattered: an operator who meant to keep an address range out of a path wrote a deny
  list the engine honoured as empty. It is now refused where it is written. No ADR 0007
  trigger fires: no new interface, sign-in method or dependency, and no new processing of
  restricted data (a profile's entries are read and written as before). The refusal adds a
  read of the profile store at save time, from the process that already reads it to decide.

controls
: t/integration/730 (acl-set through the manager API and `lazysite acl set`, a list of paths,
  a carried name, a store that cannot be read), t/integration/731 (a page at every content
  door, WebDAV included), t/unit/mcp/489 and 490, t/unit/users/548 (a group's limit),
  t/unit/users/53, t/unit/manager/395 and 974 (a profile in use, no force). Each is recorded
  by n812 as failing with the change reverted. A store that cannot be read is a fault: the save
  is refused and the fault named, never read as "no profile" (ruling 206).

residual risk
: A rule or page saved before 0.16.11 that already names a missing profile stands and
  behaves as before (an allow admits nobody, a deny excludes nobody); `lazysite check` names
  each rule and each page, and the Files page's permissions card marks the name "no such profile" so
  it can be set to Not used. A person who edits the stores or a page file on disk, outside a
  door, is not refused. The runtime's treatment of an unknown name is unchanged. The refusal
  of a rule's carried names means a path's rule cannot be changed for an unrelated reason
  until a stale name is cleared; that is intended.

verdict : accepted, confirmed by the release manager on 2026-11-11 (ruling 237). A hardening of the operator's own
  mistakes, not a fix to a vulnerability that reached a stable release: the fail-open needed an
  operator to write a name no profile held. 0.16.11 is the beta (ruling 236) and, with this
  entry, not security-critical.

### 2026-11-11 - SM1430, SM1437, SM1435 (the rest) (0.16.11): the beta's other changes, with no trigger

Assessment drafted by the developer agent at the 0.16.11 compliance walk (SM1436); confirmed by the release manager on 2026-11-11 (ruling 237). 0.16.11 is the **beta** (ruling 236): cut with `--beta` from 0.16.10 plus n811 (SM1430), n812 (SM1435) and n814 (SM1437), the code 0.17.0 is promoted from (rulings 227, 228), and the feature freeze on main starts at this cut. The walk read the CHANGELOG's `## Unreleased` section and `git log bc1d27efd..17c1edb13` (14 commits). SM1435's address-profile hardening has its own entry above. The rest moves no control and fires none of ADR 0007's four triggers (no new interface, sign-in method, dependency or processing of restricted data). Each item below was checked against the code it names.

what changed
: SM1430 (n811). `output_page`, which every page response passes through, now clears the
  display-only `lzs_session` marker (SM099) when the request carries it and has no signed-in
  identity: the wrapper's verified session on plain CGI, the front door's held value in the
  pool, or a listed proxy's user. A revoked session, a "Require sign-in again" on a local
  session and a removed account no longer leave public pages drawing "Sign out". The header
  is `Lazysite::Auth::Session::session_marker_clear_header`, the clearing twin of
  `session_marker_header`, which `session_clear_headers` uses too. That one response is sent
  `Cache-Control: no-store, private`; a visitor without the marker gets no Set-Cookie and a
  cached public page keeps its own Cache-Control. A session refused only as stale (SM1381)
  keeps its marker for its renewal (`_session_renew_verdict`, split out of
  `_session_renewal`, which still answers as before). The HttpOnly session cookie is left
  alone (t/integration/720, t/unit/odoo/135).
: SM1435 (n812). The Groups page's text for `settle_odoo_writes` names where the panel is, the
  Unknown Odoo writes page linked from its card on Extensions - configure; the Odoo
  declaration is the one source and a test holds the phrase equal in `grants`, `unlocks` and
  the capability map (t/unit/extensions/612). The Address profiles page, the CLI help, the
  MCP descriptions and the docs say to choose an existing profile; the users tool's statement
  count in the bench baseline moves from 4344 to 4348.
: SM1437 (n814). Output of `lazysite check` and `lazysite repair`, which reads and writes
  nothing new. The page check (`_public_page_set_listing` and `scan_pages`, which take an
  optional hash of what they could not read) names each directory it could not open and each
  page it left out, with the user it ran as, reports a WARN and does not print the "ok" line;
  run as a user who cannot open a directory it said "0 public page(s), each with a title and
  a description of its own" about a site with 17 undescribed pages (t/tools/582, ruling 206).
  The `/docs` shadow check runs for the primary's content root and each declared
  `content_root`, naming the domain on its line (t/tools/583). `check --fix` prints
  `--fix: nothing to change` when it changed nothing (t/tools/584), and `repair` says
  "nothing to repair" when it applied no change (t/tools/585).
: The record, not the code. This walk stamps OBLIGATIONS.md and TECHNICAL-FILE.md 0.16.11,
  channel beta, and adds docs/architecture/security.md's 0.16.11 section; it changes no
  engine file.

threat delta
: None of the four triggers fired. The questions are these.
: SM1430, Spoofing: the marker is display only and carries no authority. A request that
  sets one by hand gets, at most, a response clearing it. The page script's "Sign out" was
  drawn from the marker alone, so it showed a state the session no longer had; the HttpOnly
  cookie, verified on every request, stays the gate and is not touched. The server now reads
  the marker once, to clear it, never to admit anyone. Where the identity reader cannot answer
  (`_request_identity` returns no answer), nothing is cleared: unknown is not signed out.
: SM1430, Denial of service and cache: the response that clears the marker is not stored, and
  a visitor without the marker gets no Set-Cookie, so no cached public page loses its
  cacheability. The cost is one identity read on a request that carries the marker and no
  session, which a request with a valid session already pays.
: SM1435 (wording): none. A page's text and a test.
: SM1437, a finding the check did not make, narrowed: a check that could not
  read part of the site now says so and does not print ok, and names the unread paths and the
  user it ran as, so an operator is not told a site is clean over pages the check never saw. This
  is a hardening of what the check reports, not of what the engine does: no request path, store,
  rule or credential changes. The paths and the user's name it prints go to the person running
  the check, who can already list them. The shadow check's wider reach reads the `.md` files
  under each declared content root's `docs/` directory, as it read the primary's, and compares
  them with the engine's own copies (the same `find_noting` walk the primary's check used, over
  more roots). None of the four ADR 0007 triggers fires.

controls
: SM1430: t/integration/720 (plain CGI through the wrapper and the pool's worker: a revoked
  session, an unknown account and a marker alone each clear it; a live session keeps it; no
  cookies, and a revoked cookie without the marker, get no Set-Cookie and keep
  `public, max-age`, fresh and cached) and t/unit/odoo/135 (a stale Odoo session keeps its
  marker, and clears once Odoo has ended it). SM1435 wording: t/unit/extensions/612. SM1437:
  t/tools/582 (an unreadable directory is named and the ok line is not printed), 583 (a
  shadow in a declared content root is named with its domain), 584 and 585 (the two
  summaries).

residual risk
: SM1430: the marker is still not an authority, and a browser that never loads a page keeps
  it until it does. A provider session refused as stale keeps its marker until its renewal
  succeeds or the provider ends the session, as designed.

verdict : accepted, confirmed by the release manager on 2026-11-11 (ruling 237). No trigger fired; recorded because
  every page response now reads the signed-in identity once when the marker is present, and
  one response's cache header changes. 0.16.11 is the beta (ruling 236) and is not
  security-critical: no change in it fixes a known vulnerability (SM1435 is a hardening,
  its own entry above). It is the release the stable promotion is drawn from; the feature
  freeze (ruling 228) starts at this cut.

### 2026-11-11 - SM1439 (PENDING): a full restore gives a site that serves

Assessment drafted by the developer agent (n820, with the 0.16.12 compliance walk, SM1441); confirmed by the release manager on 11 Nov 2026 (ruling 243). Ruling 239 (the release manager, 2026-11-11) makes `install.pl --restore-full` the whole procedure after the SM1438 rehearsal found it left a site that could not serve.

what changed
: Before, `--restore-full` extracted the backup's docroot and stopped. The restored site had no
  cgi-bin entry points and no serving group, and the command ended on "Check file
  ownership/permissions on the target host". It now does the work an install does: it lays the
  engine's entry points (the cgi-bin scripts, and the lib, tools and extensions beside the
  docroot) from the release it runs, by the plan and `execute_plan` that provision uses, narrowed
  to the engine's entries (`is_engine_entry`); links the extension endpoints
  (`link_extension_endpoints`); after the extraction creates the runtime paths and applies the
  group and modes (`apply_site_modes`, split out of `post_install_steps` so an install and a
  restore run the same code); rewrites `.install-state.json` with `write_state`; and ends with the
  health check (exit 4 when the site is not serviceable yet). It takes `--cgibin`, required as
  provision requires it, and `--serving-group`. `lazysite backups --restore-full` passes both
  and carries the exit status. When the engine cannot be laid (no `--cgibin`, no release manifest,
  an unwritable cgi-bin) it refuses before extracting anything and names the command to run
  (ruling 206).

threat delta
: The trust boundary is the one install and restore already had, and it is unchanged: a full
  backup carries the auth secrets (the session signing secret, password hashes, TOTP seeds), so
  `--restore-full` is a system-user operation on the host, in the installer and the CLI, and is
  not in the manager UI or any network door. What the restore trusts is the tarball the operator
  names and the release they unpacked, as an install trusts its payload.
: What now comes from the release, never the tarball: every file of code the restore writes (the
  cgi-bin entry points, the lib, tools and extensions beside the docroot, the extension endpoint
  links); every mode and group it sets (the manifest's runtime files, the store modes 0660 and
  02770 and 0640, the setgid bit on `lazysite/`, the runtime paths), since the extraction passes
  `--no-same-owner` and `--no-same-permissions` and takes no mode or owner from the archive; and
  the group (`--serving-group`, the operator's word). What comes from the tarball is data: the
  docroot's content and its `lazysite/` tree (stores, auth secrets, conf, templates, themes), the
  domain rewritten by `--domain`, and, in `.install-state.json`, the backup's entries for the
  seed and content files, its `once` list, its `dirs_left` and its starter mark. The state's
  engine entries and version are the release's (`write_state` over the backup's), so a later
  upgrade does not read the laid engine as operator-edited. The `once` list and the starter mark
  from the tarball decide which one-time upgrade steps a later upgrade runs; a list that says too
  much skips a step, and `lazysite check` and the upgrade are what name it.
: A backup whose `lazysite/` (or its `auth/` or `forms/`) is a symlink is refused (ruling 206).
  `apply_site_modes` adds group-write and setgid to `lazysite/` (a `chmod` that follows a link),
  and `align_ownership`, when run as root, starts its walk at `lazysite/`, so a link would carry
  the mode and the owner to its target. The restore reads the archive's own listing first
  (`linked_site_dir`) and refuses, before it makes the docroot, lays the engine or extracts
  anything, naming the link and saying "Nothing was changed". Found at the walk: the
  `create_runtime_paths` refusal of a symlinked directory already stopped the restore before the
  mode and ownership steps, but only after the docroot was made, the cgi-bin laid and the tree
  extracted; the listing check refuses before any of that. Every other mode and ownership step
  skips a symlink (`-l`).
: No ADR 0007 trigger fires. No new interface (two flags on an existing system-user command, no
  listener and no network), no new sign-in method, no new dependency (the code is the installer's
  own), and no new processing of restricted data: the same backup is restored as before. The
  restore writes more than it did (code and modes), all from the release.

controls
: t/tools/628 (provisions a scratch site, takes a full backup, destroys the site, restores onto a
  new docroot with `--serving-group`, and runs the check: no failures, the three entry points
  present; fails on the code before the change). t/tools/03-install-pl.t and t/lint/149 follow
  the new flags and the single naming of the install verb. A restore that cannot lay the engine
  refuses before it extracts (no half-restored docroot); the engine is laid by `execute_plan`,
  which refuses a symlinked destination (`_refuse_symlink`); a backup holding `lazysite/`, `lazysite/auth` or
  `lazysite/forms` as a symlink is refused before anything is made (t/tools/628, its last
  subtest); the extraction's member vetting
  (`..`), `--no-same-owner` and `--no-same-permissions` are unchanged (SM268 H16).

residual risk
: A restore run as root onto a docroot whose
  owner is not the web server's group relies on `--serving-group` being named; the health check
  at the end says when it was not. The backup is still written inside the docroot it backs up
  (SM602, ruling 240: after stable), so a restore needs a copy kept off the box.

verdict : accepted, confirmed by the release manager on 11 Nov 2026 (ruling 243). A repair of a restore that left a
  site unable to serve, found in the field pass (SM1438, ruling 239); not a fix to a
  vulnerability. No trigger fires. 0.16.12 is the second beta and is not security-critical.

### 2026-11-11 - SM1440 (PENDING): refusals name the user to run as, and the check says ok only about what it read

Assessment drafted by the developer agent (n820, with the 0.16.12 compliance walk, SM1441); confirmed by the release manager on 11 Nov 2026 (ruling 243).

what changed
: Messages and check text, and one refusal. A root refusal of `lazysite acl set`, and of the
  handlers tool, names the unix user that owns `lazysite/auth/` (`Lazysite::Util::path_owner_name`)
  and spells the command with it. A refusal for a store the process cannot read (`acl set`, the
  address-profile refusals of the users tool, the manager's profile list and its address-limit
  setting) appends `Lazysite::Util::unreadable_note`: on the CLI, the user it ran as, the user that owns the
  file, and the command to run as that owner; through a web door (the manager API, MCP) it says
  "the web server's user" and "the owner of the file", names no unix user, and advises running
  the command on the host as that owner (ruling 243; the one switch is `Lazysite::Util::web_door`,
  a request environment); empty when the file opens. `lazysite check` does not
  print its two address "ok" lines when a store they read could not be read: it warns, naming the
  file, the user and the owner. The "re-run with --fix" hint shows only when `--fix` has a repair
  to apply (`fix_available`). All of that is wording and which line is printed; no gate moves.
: The one behaviour change: `group-settings-set` with `addresses`, `addresses_deny` or
  `address_limit` on a group that does not exist is refused ("The group 'X' does not exist ...
  Nothing was changed"), before its profiles are read. Before, a missing profile was named; and
  where the profile existed, a settings record was written for a group nothing held, so a limit
  could be laid for a group created later. A group counts as existing when it has members or a
  settings record. The refusal is the operator's (a sysop only, as before), writes nothing, and
  narrows what the tool accepts.

threat delta
: Information disclosure, narrowed. The release manager ruled (ruling 243) that a refusal shown
  through a web door names no unix user, so the notes do not widen what a signed-in manager or an
  MCP token learns. Through the manager API and MCP (`acls_write_refusal`, reached by `acl-set` and
  `set_permissions`; the manager's address-profile list and address-limit setting; the users tool
  as the manager API runs it) the text says "the web server's user" and "the owner of the file",
  and the advice is to run the command on the host as that owner. The unix users are named only by
  the CLI tools (`lazysite acl`, the handlers tool, the users tool, `lazysite check`), to the
  person who ran them and who can run `ls` on the same path. `lazysite check`'s address fault
  lines (`Lazysite::Auth::AddressRefs`) go through the same switch (`unreadable_clause`).
: The refusals keep their meaning: the same stores are refused and the same text says "Nothing
  was changed". The check's change is that it says less (it does not say ok about what it did
  not read), as SM1437 did for pages. The group refusal is a tightening of one write path, and
  needs no new capability. No ADR 0007 trigger fires: no new interface, sign-in method or
  dependency, and no new processing of restricted data.

controls
: t/tools/634 (a refusal through a web door, the users tool as the manager API runs it and the access-rule writer, names no unix user; it fails on the code before, where the name is in both), 630 (a root refusal names the owner and spells the command with it), 631 (the check
  prints no ok about an unreadable store, and names the file, the user and the owner), 632 (no
  `--fix` hint with nothing to fix) and 633 (a missing group is named before a missing profile, and
  no group record is made; a group that exists still gets the missing-profile refusal); each
  fails on the code before the change. t/unit/users/548 and t/unit/users/60 make their groups with
  `group-create`, which they had called through a verb that does not exist.

residual risk
: A message is not a control, and the operator may read "run as OWNER" and use `sudo` on a host
  where that user has no login; the check's wording still names the repair. A limit laid for a
  group before it is created now needs the group first (`group-create`).

verdict : accepted, confirmed by the release manager on 11 Nov 2026 (ruling 243). Wording of refusals and of the check,
  with one write path narrowed. No trigger fires. 0.16.12 is the second beta and is not
  security-critical.

### 2026-11-11 - SM1438, SM1439, SM1440 (0.16.12): the second beta, with no trigger

Assessment drafted by the developer agent at the 0.16.12 compliance walk (SM1441); confirmed by the release manager on 11 Nov 2026 (ruling 243). 0.16.12 is the second **beta** (ruling 242): cut with `--beta` from 0.16.11 plus the field-pass fixes, n816 (SM1438), n817 (SM1439) and n818 (SM1440), the code 0.17.0 is promoted from (rulings 227, 242). The feature freeze (ruling 228) holds: only fixes land. The walk read the CHANGELOG's `## Unreleased` section and `git log b050272f9..2920a8f8a` (10 commits). SM1439 and SM1440 have their own entries above. The rest moves no control. Each change was checked against the code it names, and none of ADR 0007's four triggers (new interface, sign-in method, dependency, processing of restricted data) fires.

what changed
: SM1438 (n816). The restore rehearsal record of 11 Nov 2026 in docs/RELIABILITY.md and its
  filing: a full cycle against the shipped 0.16.11 tarball, 91 ms, content, auth store and conf
  intact, and the gap SM1439 closes (no cgi-bin entry points, no serving group). Docs only; it
  changes no engine file. The OBLIGATIONS restore-rehearsal row stays OPEN: the rehearsal is rerun
  on the shipped 0.16.12 tarball and the release manager confirms it (rulings 241, 242).
: SM1439 (n817). `install.pl --restore-full` lays the engine, applies the serving group and the
  modes, writes the install state and ends with the health check (ruling 239). Its own entry above:
  a system-user operation on the host, the code and the modes from the release and the data from
  the tarball; no trigger.
: SM1440 (n818). Refusals name the unix user to run as; the check says ok only about what it
  read; no `--fix` hint with nothing to fix; a missing group is named before a missing profile; a
  `group-settings-set` address key on a group that does not exist is refused. Its own entry above:
  the one behaviour change is that refusal; no trigger.
: The record, not the code. This walk stamps OBLIGATIONS.md and TECHNICAL-FILE.md 0.16.12, channel
  beta, and adds docs/architecture/security.md's 0.16.12 section; it changes no engine file.

threat delta
: None of the four triggers fired. SM1438: none, a record. SM1439: Elevation of privilege and
  Tampering, assessed in its entry: the code and modes come from the release; the tarball supplies
  data, the same data as before; the symlinked `lazysite/` found at the walk is refused before anything is changed.
  SM1440: Information disclosure, narrowed in its entry (ruling 243: a web door names no unix user);
  the group refusal narrows one write path.

controls
: SM1439: t/tools/628. SM1440: t/tools/630 to 634. SM1438: none, a record. One STRIDE row was added
  at this walk (the full restore), and no trust boundary changed.

residual risk
: As each entry says. The restore is rerun on the shipped 0.16.12 tarball before 0.17.0 (ruling 242).

verdict : accepted, confirmed by the release manager on 11 Nov 2026 (ruling 243). No trigger fired. 0.16.12 is the second
  beta (ruling 242) and is not security-critical: no change in it fixes a known vulnerability (SM1439
  repairs a restore that left a site unable to serve, SM1440 is wording and one tightened write).
  It is the release the stable promotion is drawn from; the feature freeze (ruling 228) holds.

### 2026-11-12 - SM1446 (PENDING): a backup that did not finish is never listed as a backup

Assessment drafted by the developer agent (n824), finished at the 0.17.0 compliance walk (SM1448); confirmed by the release manager on 12 Nov 2026 (ruling 251), with its residual accepted as written (two starts in the same instant can both pass the one-at-a-time check; a worker past six hours stops counting as in progress).

what changed
: `Manager::Backups::action_backup_list` lists an empty claim, and a file with no sha256 beside
  it whose gzip stream fails `gzip -t`, under `unfinished` instead of `backups`; the per-domain
  filter of `backup-list` applies to both. `backup-restore`, site-package apply and
  `install.pl --restore-full` refuse such a file by name, before a safety snapshot or anything is
  laid. While tar runs, TERM, INT and HUP stop tar, remove the claim and the staging directory and
  re-raise. The manager API writes a `started` audit row naming the file before tar runs; the
  outcome row names the file, and a full backup's target is `full`. `lazysite check` names each
  unfinished backup and `.stage-*` directory. The Backups page shows the outcome and the
  unfinished list, with a Delete through the existing `backup-delete` and `site-backup-delete`.
: Ruling 248: a full backup runs in a DETACHED WORKER. `backup-create&scope=full` claims the
  name, forks twice and calls setsid (`Lazysite::Util::detach`, shared with the registry
  rebuild), and answers at once with `in_progress`. The worker is a copy of the manager API
  process, so it runs as the same unix user the manager runs as (the CGI's or the pool's; it gains
  nothing), with stdin, stdout and stderr on /dev/null and descriptors 3-63 closed, in its own
  session, so the request's end, the relay's TERM/KILL and the web server's kill do not reach it.
  It does one thing - `action_backup_create` on the claimed name, then the outcome audit row -
  and ends with `_exit`; it lives as long as the tar does, which nothing bounds but the size of
  the tree. A `.<name>.pid` marker (pid, start time) beside the claim says it is in progress; the
  listing trusts it only while that pid is alive and for under six hours. Restore and
  backup-delete refuse a backup in progress (409).
: Who, how long, how many. WHO: the unix user the manager API runs as, the same process image
  continued after the request; the worker's account for the trail is the requesting account's,
  and it takes no input after it starts. HOW LONG: as long as tar runs. The page and `backup-list`
  call it in progress for at most six hours; after that, if the pid still lives, it is listed as
  unfinished (and a later full backup may start) while the worker goes on, and a worker that
  ends later removes its marker and is listed as a backup as soon as its sha256 is there. HOW
  MANY: one full backup at a time per instance. `action_backup_start` looks for a live marker
  beside a claim of the same kind before it claims a name, and refuses with kind `in-progress`
  (409) naming the file and the time it started.

threat delta
: Repudiation, narrowed: a backup started and never finished now has a trail row; before, a
  killed request left none. Tampering and integrity: an empty or cut-off archive is no longer
  offered as a backup or restored, which closes a partial restore from a file the operator took
  for whole. No new action, capability, interface or dependency (`gzip` was already run by the
  backup path); the deletes are the existing actions under their existing checks. No ADR 0007
  trigger fires.
: The worker (ruling 248) is the request's own code and identity continued after the request:
  it adds no interface, reads no input after the request, and its effects are those the request
  had - one archive and its digest in `lazysite/backups/`, two trail rows. Denial of service:
  each full backup started is one tar running to completion, where a killed request stopped its
  tar or left it orphaned; starting them is manage_config (cookie) only, as before, and a
  second full backup is refused while one is in progress (a live marker under six hours old;
  kind in-progress, 409, naming the running one), so one runs at a time per instance.
  Repudiation: the start and outcome rows are written by the worker as the requesting account,
  so a backup is attributed to who asked.

controls
: t/unit/manager/975 (listing, restore and apply refusal, TERM and KILL mid-tar, the start and
  outcome rows), 976 (the page), t/tools/645 (the check) and 646 (`--restore-full`); each fails
  on 3d869ef6e. t/unit/manager/977 (the detached worker: answered in progress, listed in
  progress, finished with a verified sha256 and its own two trail rows; a KILLed worker and a
  stale marker are unfinished) fails on de7843a65; its one-at-a-time refusal fails on 13a0693a9.

residual risk
: A KILL still leaves the empty claim, and a tar that outlives its request can leave a staging
  directory; both are reported, not removed, since only the operator knows that no backup is
  running. One full backup runs at a time, with one residual: the check that refuses a second
  start reads the markers and the claim follows it, with no lock between, so two starts in the
  same instant (two requests, or two managers pressing the button together) can both pass it and
  two tars run at once. Each has its own name, marker, digest and trail rows, so nothing is lost
  or mixed; the cost is the one the check exists to avoid, two reads of the same tree, and the
  Backups page lists both. A lock would close it and is not built (ruling 248 asked for no new
  setting; the simpler way did not need one). Nothing bounds how long one runs but the tree, and
  past six hours a still-running worker is no longer counted, so a start then is not refused;
  retention (SM268 03-F11) still bounds how many are kept. A worker's
  log lines reach no error log (its stderr is /dev/null), only the syslog forwarding where it is
  configured: its outcome is the trail row.

ADR 0007 triggers: none fires. The detached worker is the request's own code and identity continued
  after it, so it is no new interface; no sign-in method, no dependency (`gzip` and `tar` were
  already run by the backup path) and no new processing of restricted data (the archive is what
  `backup-create` always wrote, to the same place, under the same mode).

verdict : accepted, confirmed by the release manager on 12 Nov 2026 (ruling 251). A field-pass fix (rulings 206, 227,
  228, 248); not security-critical. No trigger fires. The residual (two starts in the same
  instant can both pass the check; a worker past six hours stops counting) is accepted as written.

### 2026-11-12 - SM1444 (PENDING): the bad-URL blocker counts probes for credential files

Assessment drafted by the developer agent (n823, with the 0.17.0 compliance walk, SM1448); confirmed by the release manager on 12 Nov 2026 (ruling 251). Ruling 245 (the release manager, 2026-11-12) took one request (R3) into 0.17.0 as a field-pass hardening, dotfile secrets only.

what changed
: The built-in pattern list of the bad-URL auto-blocker (`Lazysite::BadUrl`, SM128) gains paths
  no lazysite site serves and scanners fish for credentials: the dot-directories `/.docker/`,
  `/.claude/`, `/.cursor/`, `/.kube/`, `/.azure/`, `/.vscode/`, `/.idea/`, `/.terraform/` and
  `/.gnupg/`, `appsettings.json` (and `appsettings.ENV.json`), `aws-exports.js`, and
  `/wp-json/batch`. The stats extension's noise set (`extensions/stats.pl`) gains the same block
  but for `wp-json/batch`, so the two lists stay in step (t/tools/640 compares them). `/app.js` and
  `/app.config.js` are left out on purpose: a real site can serve them. A request for one of these
  paths is counted as a bad URL, and an address that reaches the threshold in the window is
  blocked, exactly as `/.env` always was. `bad_url_extra` still adds to the list, a real file is
  still spared (`site_has_file`), and the loopback exemption and `bad_url_exempt` are unchanged.
  No setting, tool or page is added.

threat delta
: A hardening of a default list, and the only direction it moves a control is towards counting
  more. Denial of service, by false positive: a visitor who requests one of these paths on a site
  that does not serve it is counted; the visitor who does so deliberately several times in the
  window is blocked, as for `/.env`. A path a site really serves is spared by the real-file
  test, and `bad_url_extra` is the site's own addition, not its removal. Information disclosure,
  narrowed: a scanner's session of credential-file probes now reaches the threshold instead of
  staying under it (the answer to each such request is the same 404 as before). No new
  interface, capability, input or output, and no ADR 0007 trigger fires: no new interface,
  sign-in method or dependency, and no new processing of restricted data (the block store keeps
  the same address, count and time).

controls
: t/tools/640: each new path counts as a bad URL, and `/app.js`, `/app.config.js`, an ordinary
  page and look-alike names do not; `bad_url_extra` adds beside the built-ins; four of the paths
  block an address through the guard at threshold 1 and `/app.js` blocks nobody; the stats block
  equals the blocker's. 23 of its 39 assertions fail on 299a10408 (the commit before the change).

residual risk
: An address shared by many people (a school, a mobile carrier's NAT) is blocked if one of them
  trips the threshold; that is the blocker's existing trade-off, not widened by a pattern a
  person does not type by accident. The list is a signature list: a scanner that asks for a path
  not on it is not counted. The owner's other requests (an agent adding patterns, an agent seeing
  blocked addresses, a built-in pattern edited or switched off) are SM1445, for 0.17.x.

verdict : accepted, confirmed by the release manager on 12 Nov 2026 (ruling 251). A hardening, no trigger. A field-pass hardening (ruling 245),
  not security-critical: no known vulnerability is fixed.

### 2026-11-12 - SM1447 (PENDING): a refusal names the user who can run the command, and the check says what it spells

Assessment drafted by the developer agent (n825, with the 0.17.0 compliance walk, SM1448); confirmed by the release manager on 12 Nov 2026 (ruling 251). A field-pass fix from the 0.16.12 edge pass.

what changed
: Messages and check text. On a Hestia host `lazysite/auth/` is owned by one user and the store
  files in it by the web server's, so the user SM1440 named (the directory's owner) was the one
  user for whom the command failed. `Lazysite::Util::store_run_as` names the owner of the store
  files the command reads and writes (each owner, where they differ), and `lazysite acl`, the
  handlers tool, `lazysite check` and the users tool use it. The address-profile refusal of a
  rule and of a page appends the note SM1440 added (`Lazysite::Auth::AddressProfiles::fault_note`),
  which names the user that ran, the file's owner and the user to run as. The upgrade's ADDRESS
  PROFILES line says it could not check an unread directory, names its owner and the rerun, and
  no longer says calls are false. `lazysite check` prints no ok line for a walk that could not read
  part of the tree (the form patterns, protected content, the template cache, ownership, content
  history, content provenance, theme assets, the asset mirror) and warns, naming the user who owns
  what was not read. Every remedy the check prints spells the command through `cli_spelling`, never
  a bare `lazysite`. A refusal shown through a web door still names no unix user (ruling 243): the
  one switch is still `Lazysite::Util::web_door`.
: The one behaviour change, and it is a diagnostic: when `acls.json` does not decode, the page
  walk that `lazysite check` makes (`scan_pages` in the processor's registries) now records the
  store as unread, so the check warns instead of printing "0 public page(s)" about a site whose
  pages the rules hid. Nothing a visitor or a writer sees changes: `_registry_hidden` already
  governed every page on a store that would not load (fail closed, ruling 206), and the walk is
  the check's own. No write path, refusal or gate moves. The detach helper moved from the registry
  rebuild into `Lazysite::Util` with SM1446, unchanged in effect.

threat delta
: Information disclosure, held at ruling 243. The unix names are printed by the CLI tools and
  the check to the person who ran them, and who can run `ls` on the same path; the web doors
  (the manager API, MCP) still say "the web server's user" and "the owner of the file". The note
  now names the owner of each file where owners differ, which is the file's owner and a
  name the same `ls` shows. Repudiation and operability, improved: advice that sent an operator to
  the user for whom the command failed is replaced by advice that names a user who can run it,
  and the check no longer says ok about a tree it did not read (as SM1437 and SM1440 did for
  pages and addresses). No ADR 0007 trigger fires: no interface, sign-in method, dependency or
  new processing of restricted data.

controls
: t/tools/650 (the helper and the three tools, with different real owners), 651 (the profile
  refusal names the file's owner and the user to run as), 652 (the check prints no ok for a
  tree it did not walk, and the page check says when `acls.json` would not load), 653 (every piece
  of advice is spelled through `cli_spelling`), t/tools/331 (the upgrade's words) and 645's, 108's,
  126's, 295's, 336's and 582's expectations of the remedy and the command as the check now spells
  them; each new test names in its header the change that makes it fail (a sabotage note).

residual risk
: A message is not a control: an operator may follow "run as OWNER" on a host where that user
  has no login. When the store files have different owners no one user can change them all, and
  the text says so and names each; `lazysite check` names the fix.

verdict : accepted, confirmed by the release manager on 12 Nov 2026 (ruling 251). Messages and check text, with one diagnostic made honest. No
  trigger. A field-pass fix (rulings 206, 227, 228), not security-critical.

### 2026-11-12 - SM1442-SM1447 (0.17.0): the stable, promoted from 0.16.12 with the field-pass fixes, with no trigger

Assessment drafted by the developer agent at the 0.17.0 compliance walk (SM1448); confirmed by the release manager on 12 Nov 2026 (ruling 251). 0.17.0 is the first **stable** since 0.16.0, cut with `--final` (rulings 227, 242). It is the stable promotion of the 0.16.12 beta: the 0.16.12 code plus only the fixes of the 0.16.11 and 0.16.12 field passes, and it carries everything since 0.16.0, 0.16.1 to 0.16.12, each of which has its own register entries. The feature freeze (ruling 228) ends with this cut. The walk read the CHANGELOG's `## Unreleased` section and `git log 930e7f32a..f02c7cbb0` (19 commits: SM1442 on n821, SM1443 on n822, SM1444 and SM1445 on n823, SM1446 on n824, SM1447 on n825), stacked on the 0.16.12 release commit 930e7f32a. SM1444, SM1446 and SM1447 have their own entries above. The rest moves no control. Each change was checked against the code it names, and none of ADR 0007's four triggers (new interface, sign-in method, dependency, processing of restricted data) fires.

what changed
: SM1442 (n821). t/tools/158 proves a killed cover is not a test failure in a fraction of the
  time. Test only; no shipped file changes.
: SM1443 (n822). The restore rehearsal rerun on the shipped 0.16.12 tarball: one `install.pl
  --restore-full` command, 743 ms, content, auth store, conf, the three cgi-bin entry points and
  the 0.16.12 install state present, `lazysite check --group` 0 failures. The release manager
  confirmed it on 12 Nov 2026 (ruling 247) as the 0.17.0 stable cycle's rehearsal and the
  obligations row closed. A record in docs/RELIABILITY.md; no shipped file changes.
: SM1444 (n823). The bad-URL blocker counts probes for credential files (ruling 245). Its own
  entry above: a hardening of a default list, no trigger.
: SM1445 (n823). Filed for 0.17.x (ruling 246): an agent adding blocker patterns, an agent seeing
  blocked addresses and a built-in pattern edited or switched off. No code.
: SM1446 (n824). An unfinished backup is never listed or restored, and a full backup runs
  detached, one at a time (ruling 248). Its own entry above: the request's own code and identity
  continued, no new interface, one residual (two starts in the same instant).
: SM1447 (n825). Refusals name the user who can run the command, and the check says ok only
  about what it read. Its own entry above: messages and check text, no trigger.
: The promotion. 0.17.0 adds no feature to 0.16.12. A site on the stable line (0.16.0) takes
  0.16.1 to 0.16.12 in one step. Their register entries stand as confirmed (the release manager,
  rulings 65, 93, 127, 142, 149, 177, 182, 225, 226, 233, 237 and 243). Two of the releases it
  passes carry fixes a stable site has not had: 0.16.2 (SM1303, a theme archive could plant a
  link in the served asset mirror) was cut security-critical, so `upgrade --all --force-security`
  already pushed it past every site's channel; 0.16.3 (SM1308, SM1309) owes no notice or advisory
  (ruling 94). No change since 0.16.12 fixes a known vulnerability, so 0.17.0 is not cut with
  `--security-critical`.
: The record, not the code. This walk stamps OBLIGATIONS.md and TECHNICAL-FILE.md 0.17.0, channel
  stable, restamps the unsigned draft Declaration of Conformity to 0.17.0, and adds
  docs/architecture/security.md's 0.17.0 section and one STRIDE row (the detached backup worker);
  it changes no engine file.

threat delta
: None of the four triggers fired. SM1442, SM1443, SM1445: none, a test, a record and a filing.
  SM1444: a hardening, assessed in its entry. SM1446: Repudiation and Tampering narrowed, Denial
  of service assessed (a detached worker, one at a time), in its entry. SM1447: Information
  disclosure held at ruling 243, in its entry. The stable channel adds no threat: it is the
  channel a site already on stable takes, and the support period (five years from 0.7.0) is
  unchanged.

controls
: SM1442: the test itself. SM1444: t/tools/640. SM1446: t/unit/manager/975 to 977, t/tools/645,
  646. SM1447: t/tools/650 to 653. SM1443, SM1445: none, a record and a filing. One STRIDE row was
  added at this walk (the detached backup worker), and no trust boundary changed.

residual risk
: As each entry says. The Declaration of Conformity is an unsigned draft, advisory on stable and
  blocking at the certified cut (ADR 0010); the bench baseline (captured 2026-09-30) is
  re-captured on a quiet host after the 0.17.0 cut, at the release manager's chosen moment and before the certified cut it blocks (ruling 250). The 0.17.0 stable is not the beginning of general-availability marketing in ADR 0007's waiver (ruling 249), so the first third-party penetration test stays due by 31 Dec 2026. SM602 (the full backup is written inside the
  docroot it backs up) stands for 0.17.x (ruling 240).

verdict : accepted, confirmed by the release manager on 12 Nov 2026 (ruling 251). No trigger fired. 0.17.0 is the stable (ruling 227), promoted
  from the 0.16.12 beta with only the fixes of the 0.16.11 and 0.16.12 field passes (rulings
  227, 242), and is not security-critical: no change in it since 0.16.12 fixes a known
  vulnerability. The feature freeze (ruling 228) ends with the cut.

### 2026-11-16 - SM1455 (PENDING): the bad-URL guard reads the request's path behind Apache

Assessment drafted by the developer agent; for the release manager's confirmation. A fix for 0.17.1 (stable), found on the 0.17.0 field walk (T3.1).

what changed
: `lazysite-auth.pl` took its path from `REDIRECT_URL`, else `/`. Apache sets `REDIRECT_URL` only
  on an internal redirect. Run against a real Apache 2.4 with the Hestia template's two routes
  into the wrapper, the SM797 source-type `RewriteRule ... [PT]` and `FallbackResource`, it is
  unset on both and `REQUEST_URI` carries the path. The bad-URL guard (SM128) therefore asked
  whether `/` is a probe, for every request: eleven requests for `/wp-login.php` from one address
  were all answered 404, and no hit file was written. The wrapper's path is now `REDIRECT_URL`,
  else `REQUEST_URI` with its query removed, else `/`, the precedence the pool's front door and
  the processor already had. The line is the one change; the other uses of the path in the
  wrapper are its log lines.

threat delta
: What was believed on and was off: the blocker (SM128, on by default) did not count a probe
  that reached a site through the auth wrapper behind Apache. The line predates the blocker
  (it dates from 2026-04-18; SM128 shipped in 0.5.41), so the blocker never counted such a
  probe on those routes. Not exposed: access rules, which the processor decides from the path
  it reads correctly, so no page, file or area was reachable that a rule closed. The cost was
  Denial of service, narrowed less than documented: a scanner's session stayed under the
  threshold. The fix moves the control towards counting what it was meant to count, so the
  false-positive surface (a visitor who requests probe paths several times is blocked) is the
  documented one and now real. A real file is still spared and the loopback exemption and
  `bad_url_exempt` are unchanged. No new interface, sign-in method or dependency, and no new
  restricted data (the block store keeps the same address, count and time): no ADR 0007
  trigger fires.

controls
: t/integration/732 runs real Apache with the template's two routing rules read out of
  `installers/hestia/lazysite-cgi.tpl`, the real wrapper and the real processor, at
  `bad_url_threshold: 3`: probes of `/wp-login.php` (the rewrite) and `/.kube/config`
  (FallbackResource) are each refused at the threshold, the address is then refused for a
  normal page, and a fresh address is served. It fails on the unfixed line (the third and
  fourth subtests). t/integration/14 sends REQUEST_URI, with a query, where Apache would not
  set REDIRECT_URL, and keeps one REDIRECT_URL case (an internal redirect); its first two
  assertions fail on the unfixed line.

residual risk
: A site whose address rules leave `trusted_proxies` unset behind a front end still counts the
  front end's address (SM1321, as recorded). Sites that were scanned before the fix start
  counting from the upgrade.

verdict
: for the release manager's confirmation. A stable patch; no trigger fires.
