#!/usr/bin/perl
# lazysite-payment-demo.pl - DEMO ONLY payment simulator
# Simulates payment via signed cookie. NOT for production use.
# In production, use an upstream x402 payment proxy that sets
# X-Payment-Verified after on-chain validation.
use strict;
use warnings;
use Digest::SHA qw(hmac_sha256_hex);
use File::Path  qw(make_path);
use POSIX       qw(strftime);

BEGIN {
    # Locate the Lazysite module tree relative to this script (run-in-place,
    # tar and Hestia installs), falling back to the system @INC (package
    # installs). Nothing is loaded here: the loads are lazy, so --describe
    # answers even where the tree is not found.
    require Cwd;
    require File::Basename;
    # SM1078: then the docroot's ../lib, where install.pl puts it whatever
    # --cgibin was (one rule in every script a cgi-bin runs, t/lint/263).
    my $bin = File::Basename::dirname( Cwd::abs_path(__FILE__) );
    my $doc = $ENV{DOCUMENT_ROOT} || $ENV{REDIRECT_DOCUMENT_ROOT} || '';
    for my $cand ( "$bin/lib", "$bin/../lib", "$bin/../../lib", ( length $doc ? "$doc/../lib" : () ) ) {
        if ( -d "$cand/Lazysite" ) { unshift @INC, $cand; last }
    }
}

my $LOG_COMPONENT = 'payment-demo';

# Extension interface uniformity: every shipped extension answers --describe (the
# manager's discovery probe). Handled BEFORE the DOCUMENT_ROOT check - the probe
# runs without a CGI environment, and without this handler the probe used to
# fall through to a full page render under CGI. Minimal contract: id is the
# only required key; demo marks it as not-for-production.
if ( grep { $_ eq '--describe' } @ARGV ) {
    require JSON::PP;
    print JSON::PP::encode_json( {
            id          => 'payment-demo',
            name        => 'Payment Demo',
            description => 'DEMO ONLY x402 payment simulator (signed cookie). Not for '
                . 'production - use an upstream payment proxy that sets '
                . 'X-Payment-Verified after on-chain validation.',
            version => '1.0',
            demo    => JSON::PP::true(),
            # Hidden from the Extension Manager until a real payment integration exists
            # (it is a demo helper for the 402 paywall, wired via cgi-bin, not a
            # user-facing feature to toggle). The helper + docs stay in place.
            unlisted      => JSON::PP::true(),
            config_schema => [],
            actions       => [],
    } );
    exit 0;
}

my $DOCROOT = $ENV{DOCUMENT_ROOT} || $ENV{REDIRECT_DOCUMENT_ROOT}
    or die "DOCUMENT_ROOT not set\n";
my $LAZYSITE_DIR = _lz($DOCROOT);
# SM929: THE request address for this request - the visitor, not the front proxy.
# One reader, cached, because everything below asks the same question about one
# request. Behind a front proxy REMOTE_ADDR is a single constant for every visitor
# a site will ever have, so an address column held the infrastructure's identity
# and anything keyed on it shared one bucket with the world.
{
    my $request_ip;

    sub _request_ip {
        return $request_ip if defined $request_ip;
        require Lazysite::Util;
        $request_ip = Lazysite::Util::request_address(
            Lazysite::Util::trusted_proxy_spec($LAZYSITE_DIR) );
        return $request_ip;
    }
}

my $AUTH_DIR    = "$LAZYSITE_DIR/auth";
my $COOKIE_NAME = 'lazysite_payment_demo';
my $COOKIE_MAX  = 3600;                      # 1 hour - demo payments expire

# --- Main ---

my $method = $ENV{REQUEST_METHOD} // 'GET';
my $uri    = $ENV{REDIRECT_URL}   // '/';
my $query  = $ENV{QUERY_STRING}   // '';

my %params;
for my $pair ( split /&/, $query ) {
    my ( $k, $v ) = split /=/, $pair, 2;
    next unless defined $k;
    $k =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
    $v //= '';
    $v =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
    $params{$k} = $v;
}

my $action = $params{action} // '';

if ( $action eq 'pay' ) {
    handle_pay();
}
elsif ( $action eq 'unpay' ) {
    handle_unpay();
}
else {
    handle_request();
}

# --- Handlers ---

sub handle_pay {
    my $page = $params{page} // '/';
    $page = '/' unless $page =~ m{\A/[\w/.-]*\z};

    my $ts      = time();
    my $secret  = load_secret();
    my $payload = "$page:$ts";
    my $sig     = hmac_sha256_hex( $payload, $secret );
    my $cookie  = uri_encode("$payload:$sig");

    my $secure = $ENV{HTTPS} ? '; Secure' : '';

    log_event( 'INFO', $page, 'demo payment created', ip => _request_ip() );

    binmode( STDOUT, ':utf8' );
    print "Status: 302 Found\r\n";
    print "Set-Cookie: $COOKIE_NAME=$cookie; HttpOnly; SameSite=Lax; Path=/; Max-Age=$COOKIE_MAX$secure\r\n";
    print "Location: $page\r\n\r\n";
}

sub handle_unpay {
    my $page = $params{page} // '/';
    $page = '/' unless $page =~ m{\A/[\w/.-]*\z};

    my $secure = $ENV{HTTPS} ? '; Secure' : '';

    binmode( STDOUT, ':utf8' );
    print "Status: 302 Found\r\n";
    print "Set-Cookie: $COOKIE_NAME=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0$secure\r\n";
    print "Location: $page\r\n\r\n";
}

sub handle_request {
    # Check demo payment cookie for current page
    my $cookie = read_cookie($COOKIE_NAME);

    if ($cookie) {
        my $decoded = uri_decode($cookie);
        if ( $decoded =~ /^(.+):(\d+):([a-f0-9]{64})$/ ) {
            my ( $page, $ts, $sig ) = ( $1, $2, $3 );
            my $secret   = load_secret();
            my $expected = hmac_sha256_hex( "$page:$ts", $secret );

            if ( $sig eq $expected && ( time() - $ts ) < $COOKIE_MAX ) {
                # Check if cookie page matches current URI
                if ( $uri eq $page ) {
                    $ENV{HTTP_X_PAYMENT_VERIFIED} = '1';
                    $ENV{HTTP_X_PAYMENT_PAYER}    = 'demo-wallet';
                    log_event( 'INFO', $page, 'payment verified', ip => _request_ip() );
                }
            }
        }
    }

    # Exec processor. The block form of exec suppresses perl's
    # "statement unlikely to be reached" compile-time warning while keeping
    # the failure path (exec returns only on error).
    my $processor = $ENV{LAZYSITE_PROCESSOR}
        // "$DOCROOT/../cgi-bin/lazysite-processor.pl";

    unless ( exec {$^X} $^X, $processor ) {
        log_event( 'ERROR', $uri, 'exec failed', error => $! );
        die "exec failed: $!\n";
    }
}

# --- Utilities ---

sub load_secret {
    my $path = "$AUTH_DIR/.secret";
    make_path($AUTH_DIR) unless -d $AUTH_DIR;

    if ( -f $path ) {
        open( my $fh, '<', $path ) or return 'demo-fallback-secret';
        chomp( my $s = <$fh> );
        close $fh;
        return $s if $s;
    }

    # M-6: fail closed if CSPRNG unavailable rather than falling back to rand().
    open( my $rand, '<:raw', '/dev/urandom' )
        or die "Cannot open /dev/urandom - no CSPRNG available: $!\n";
    my $raw = '';
    my $got = read( $rand, $raw, 32 );
    close $rand;
    die "Short read from /dev/urandom ($got of 32 bytes)\n"
        unless defined $got && $got == 32;
    my $s = unpack( 'H*', $raw );

    open( my $fh, '>', $path ) or return $s;
    # 0660: identity-shared secret (CLI/dev-server + www-data CGI) - never world.
    chmod 0o660, $path;
    print $fh "$s\n";
    close $fh;
    return $s;
}

sub read_cookie {
    my ($name) = @_;
    my $cookies = $ENV{HTTP_COOKIE} // '';
    for my $pair ( split /;\s*/, $cookies ) {
        my ( $k, $v ) = split /=/, $pair, 2;
        $k =~ s/^\s+|\s+$//g if defined $k;
        return $v            if defined $k && $k eq $name;
    }
    return '';
}

sub uri_encode {
    my ($str) = @_;
    $str =~ s/([^a-zA-Z0-9_.~:-])/sprintf('%%%02X', ord($1))/ge;
    return $str;
}

sub uri_decode {
    my ($str) = @_;
    $str =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
    return $str;
}

# --- Logging ---

sub log_event {
    my ( $level, $context, $message, %extra ) = @_;
    my $min_level = $ENV{LAZYSITE_LOG_LEVEL} // 'INFO';
    my %rank      = ( DEBUG => 0, INFO => 1, WARN => 2, ERROR => 3 );
    return if ( $rank{$level} // 1 ) < ( $rank{$min_level} // 1 );
    my $ts     = strftime( '%Y-%m-%d %H:%M:%S', localtime );
    my $format = $ENV{LAZYSITE_LOG_FORMAT} // 'text';
    if ( $format eq 'json' ) {
        my $pairs = join ',',
            map { '"' . _json_str($_) . '":"' . _json_str( $extra{$_} ) . '"' }
            keys %extra;
        my $json = '{"ts":"' . $ts . '"'
            . ',"level":"' . _json_str($level) . '"'
            . ',"component":"' . _json_str($LOG_COMPONENT) . '"'
            . ',"context":"' . _json_str($context) . '"'
            . ',"message":"' . _json_str($message) . '"'
            . ( $pairs ? ",$pairs" : '' )
            . '}';
        print STDERR "$json\n";
        _forward_diag( $level, $json );
    }
    else {
        my $extras = join ' ',
            map { "$_=" . $extra{$_} } keys %extra;
        my $line = "[$ts] [$level] [$LOG_COMPONENT] [$context] $message";
        $line .= " $extras" if $extras;
        print STDERR "$line\n";
        _forward_diag( $level, $line );
    }
}

# SM850: the engine's tree - inside the docroot, or beside it on a site that
# moved it out (SM293). Asked of the resolver, never built by hand: a path built
# here kept working until the day a site migrated, then read and wrote a
# directory that was no longer there.
sub _lz {
    my ($docroot) = @_;
    require Lazysite::Paths;
    return Lazysite::Paths::lazysite_dir($docroot);
}

# SM540: a best-effort copy of the line to syslog through Lazysite::Util's
# forward_line, so this extension's diagnostics are covered by the
# forward_diagnostics DEFAULT of WARN and above (SM932) as well as by an
# explicit setting - it needed `forward_diagnostics: true` before that, and
# the docs promised syslog either way. The rest of this extension's
# diagnostics as the docs promise. The module tree is found by the bootstrap at
# the top (the SM473 lesson: `prove -l` puts lib/ on @INC and a real install does not) and
# the require is eval-guarded, the SM425 posture: a missing lib costs the
# operator a syslog copy, never a submission - STDERR has the line either way.
sub _forward_diag {
    my ( $level, $line ) = @_;
    my %prio = ( DEBUG => 'debug', INFO => 'info', WARN => 'warning', ERROR => 'err' );
    eval {
        require Lazysite::Util;
        Lazysite::Util::forward_line( 'diag', $prio{$level} // 'info', $line );
        1;
    };
    return;
}

sub _json_str {
    my ($s) = @_;
    $s //= '';
    $s =~ s/\\/\\\\/g;
    $s =~ s/"/\\"/g;
    $s =~ s/\n/\\n/g;
    $s =~ s/\r/\\r/g;
    $s =~ s/\t/\\t/g;
    return $s;
}
