#!/usr/bin/perl
# bad-url-blocker.pl - the bad-URL auto-blocker's descriptor (SM128).
#
# The blocker recognises vulnerability-scanner probes (/wp-login.php, /.env,
# the credential dot-directories of developer and cloud tools such as /.docker/ and
# /.claude/, appsettings.json, aws-exports.js, *.php on a Markdown site, ...), counts them per source IP in a rolling window,
# and blocks an IP after a threshold. Detection + counting + the block store live
# in Lazysite::BadUrl; enforcement runs in the auth wrapper (lazysite-auth.pl).
# This descriptor just exposes the settings on the Extension Config page and marks
# the feature enabled by default. The blocked-IP list + unblock live on this
# extension's own config page, under Blocked addresses (moved from the Stats page
# by SM703; control-API actions bad-url-blocks / bad-url-unblock).

use strict;
use warnings;

if ( grep { $_ eq '--describe' } @ARGV ) {
    require JSON::PP;
    print JSON::PP::encode_json(
        {
            id          => 'bad-url-blocker',
            name        => 'Bad-URL auto-blocker',
            description => 'Auto-blocks source IPs that hammer scanner/probe URLs '
                . '(/wp-login.php, /.env, /.docker/, /.claude/, appsettings.json, *.php on a Markdown site, ...). On by '
                . 'default. A blocked address is REFUSED THE SITE - it receives '
                . '403 and is served nothing. The current blocks, with per-address '
                . 'unblock, are on this page.',
            version     => '1.0',
            config_file => 'lazysite/lazysite.conf',
            config_keys => [qw(bad_url_block bad_url_threshold bad_url_window bad_url_extra bad_url_exempt)],
            config_schema => [
                {
                    key     => 'bad_url_block',
                    label   => 'Auto-block scanner IPs',
                    type    => 'toggle',
                    on      => 'enabled',
                    off     => 'disabled',
                    default => 'enabled',
                    note    => 'Refuse an IP after it hits too many probe URLs in the '
                        . 'window. Enforced in the auth wrapper, so it protects '
                        . 'auth-wrapped sites.',
                },
                {
                    key     => 'bad_url_threshold',
                    label   => 'Probes before block',
                    type    => 'text',
                    default => '10',
                    note    => 'Number of probe hits from one IP within the window that '
                        . 'triggers a block.',
                },
                {
                    key     => 'bad_url_window',
                    label   => 'Window (seconds)',
                    type    => 'text',
                    default => '3600',
                    note    => 'Rolling window over which probe hits are counted.',
                },
                {
                    key     => 'bad_url_extra',
                    label   => 'Extra probe paths',
                    type    => 'text',
                    default => '',
                    note    => 'Comma-separated substrings to treat as probes on top of '
                        . 'the built-ins.',
                },
                # SM1321 (rulings 48, 83, 84): address profiles never counted or refused.
                {
                    key      => 'bad_url_exempt',
                    label    => 'Never block',
                    type     => 'text',
                    default  => '',
                    validate => 'Lazysite::BadUrl::validate_exempt',
                    note => 'Comma-separated names of address profiles (Access -> Address profiles) '
                        . 'whose addresses are never counted or blocked. Loopback (127.0.0.0/8, ::1) '
                        . 'is always exempt; the value none exempts nothing, loopback included. '
                        . 'A path to a file the site has is never counted.',
                },
            ],
        }
    );
    exit 0;
}

print "usage: bad-url-blocker.pl --describe\n";
exit 0;
