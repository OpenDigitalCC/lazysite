#!/usr/bin/perl

# DP-3: the data endpoint - a page's own JavaScript reading a table.
#
# WHY THIS EXISTS SEPARATELY FROM THE CONTROL API. The control API is the
# sysop's and the agent's door: it is capability-gated, CSRF-gated on the
# cookie path, and every action is audited. A rendered PAGE asking for rows is
# a different question with a different answer - it is a visitor, usually
# anonymous.
#
# READS ARE GATED (SM476), and this endpoint used to be the reason they were
# not. A page bound to a table inherits the PAGE's gate; this endpoint is
# reached by its own URL and inherited nothing, so it was a second door to the
# same rows with no lock on it. A table now has to be PUBLISHED before an
# anonymous visitor sees anything, and an acls.json read list narrows it
# further. The decision lives in Lazysite::Data::Access, and read_rows will not
# answer at all without being told who is asking.
#
# IT VALIDATES ITS OWN IDENTITY, and that is the whole reason SM411 exists.
#
# The front door routes lazysite-*.pl, but only the processor and manager-api
# are WRAPPED - so a direct-CGI extension sees X-Remote-User exactly as the client
# sent it. Trusting it here would be SM402's defect reintroduced by
# specification: a header anybody can set, believed. So this verifies the
# session cookie itself, through the same module lazysite-auth.pl mints with,
# and treats an unverified request as ANONYMOUS rather than as whoever it
# claimed to be.
#
# WRITES ARE AUTHENTICATED, ALWAYS, AND `writable=` DOES NOT CHANGE THAT.
#
# The plan called this half "inline writable= writes", and the obvious reading -
# a page declaring a table writable makes it writable - is the one thing this
# must not do. The endpoint is reached by a URL; it cannot see which page
# called it, so a marker in a page's front matter could never gate anything. A
# page saying `writable` would be a promise the enforcement layer never hears.
#
# So the rule is stated where it can be enforced: a write needs a VERIFIED
# session whose account holds manage_data, and a CSRF token. `writable=` on a
# binding is a note to the page's own JavaScript about whether to offer editing
# controls - presentation, and deliberately not a permission.
#
# ANONYMOUS WRITES ARE WHAT FORMS ARE FOR. A public visitor submitting data is
# a solved problem here, with rate limits, spam controls and a handler that
# vets what it accepts. Letting a data binding take anonymous writes would
# rebuild that surface without any of it, so it does not.

use strict;
use warnings;
use JSON::PP ();

BEGIN {
    require Cwd;
    require File::Basename;
    # SM1078: then the docroot's ../lib, where install.pl puts it whatever
    # --cgibin was (one rule in every script a cgi-bin runs, t/lint/263).
    my $bin = File::Basename::dirname( Cwd::abs_path(__FILE__) );
    my $doc = $ENV{DOCUMENT_ROOT} || $ENV{REDIRECT_DOCUMENT_ROOT} || '';
    for my $cand ( "$bin/lib", "$bin/../lib", "$bin/../../lib", ( length $doc ? "$doc/../lib" : () ) ) {
        if ( -d "$cand/Lazysite" ) { unshift @INC, $cand; last }
    }
}

use Lazysite::Timing (); # SM1144: after the lib search, so its load phase covers what is loaded below

exit main() if !caller;

sub reply {
    my ( $status, $data, $extra ) = @_;    # SM1118: $extra, response header lines

    # SM700: ->utf8, and the Content-Length that depends on it.
    #
    # Connect.pm opens SQLite with sqlite_unicode => 1, so a TEXT column comes
    # back as a CHARACTER string - `u` with a circumflex is one character,
    # U+00FB. Encoding without ->utf8 returns JSON as characters, and printing
    # that to a STDOUT with no encoding layer writes each codepoint as one byte:
    # U+00FB becomes 0xFB. The header says charset=utf-8, so the browser tries
    # to UTF-8-decode a lone high byte and gets U+FFFD - the black diamond an
    # operator sees on familyhq, where "Jeune federal" (accented) rendered with
    # a replacement character for each accent.
    #
    # The control API never had this because it uses encode_json, which is UTF-8
    # by definition, with STDOUT in binmode. The two endpoints read the same
    # rows and diverged only here.
    #
    # Content-Length MUST be taken after encoding. length() on a character
    # string counts characters; it matched only because the bug emitted one byte
    # per character, so fixing the encoding without this would under-report the
    # length and truncate every response carrying an accent.
    my $body = JSON::PP->new->utf8->canonical->encode($data);

    # Bytes now. Say so, rather than relying on the absence of a layer.
    binmode STDOUT;
    print "Status: $status\r\n";
    print "$_\r\n" for @{ $extra || [] };
    print "Content-Type: application/json; charset=utf-8\r\n";

    # Never cached by anything in front. What a visitor may see depends on who
    # they are, so a shared cache holding one answer would hand it to the next
    # person.
    print "Cache-Control: no-store\r\n";
    my $tm = Lazysite::Timing::header_line();    # SM1144
    print "$tm\r\n" if length $tm;
    print "Content-Length: " . length($body) . "\r\n\r\n";
    print $body;
    return 0;
}

sub main {
    my $docroot = $ENV{DOCUMENT_ROOT} // '';
    Lazysite::Timing::begin();                   # SM1144: where this request's time goes
    require Lazysite::Paths;
    Lazysite::Timing::configure( Lazysite::Paths::lazysite_dir($docroot) ) if length $docroot;
    return reply( 500, { ok => 0, error => 'no document root' } )
        unless length $docroot && -d $docroot;

    my $method = $ENV{REQUEST_METHOD} // 'GET';
    return reply( 405,
        { ok => 0, error => 'this endpoint takes GET to read and POST to write' } )
        unless $method eq 'GET' || $method eq 'POST';

    # SM557: the package is require'd at runtime, so this file mentions the
    # variable once by design - t/lint/04 refuses the 'used only once' warning.
    no warnings 'once';
    require Lazysite::Manager::Extensions;
    local $Lazysite::Manager::Extensions::DOCROOT = $docroot;
    return reply( 403,
        { ok => 0,
            error => 'The data extension is disabled. A sysop can enable it '
                . 'on the Extensions page.' } )
        unless Lazysite::Manager::Extensions::extension_enabled('extensions/data.pl');

    my %q;
    for my $pair ( split /&/, ( $ENV{QUERY_STRING} // '' ) ) {
        my ( $k, $v ) = split /=/, $pair, 2;
        next unless defined $k && length $k;
        for ( $k, $v ) {
            next unless defined;
            tr/+/ /;
            s/%([0-9A-Fa-f]{2})/chr hex $1/ge;
        }
        $q{$k} = $v // '';
    }

    # A CSRF request names no table, so the requirement comes after it.
    my $table = $q{table} // '';
    return reply( 400, { ok => 0, error => 'table required' } )
        unless length $table || ( $q{csrf} // '' ) eq '1';

    Lazysite::Timing::to('identity');    # SM1144
    no warnings 'once';    # SM557
                           # THE IDENTITY, verified here rather than taken from a header.
    require Lazysite::Auth::Session;
    require Lazysite::Paths;
    local $Lazysite::Auth::Session::LAZYSITE_DIR = Lazysite::Paths::lazysite_dir($docroot);
    # IT RETURNS A SESSION, NOT A NAME. verify_session_cookie answers
    # ( { user, sid, groups }, undef ) on success and ( undef, $why ) on
    # failure - so treating the first value as a username put the string
    # "HASH(0x...)" into the identity below, which is the value the ACL layer
    # then reads. It failed closed here only by accident.
    #
    # SM1137 (left open by SM1130, which covered lazysite-auth.pl only): UNDER
    # PROXY TRUST THE PROXY'S IDENTITY WINS HERE TOO. This endpoint always used
    # its own verified session, so on a site behind an identity provider a visitor
    # the directory had signed in (and who held no lazysite cookie) was anonymous
    # to a page's data - while the page itself, gated by the same headers, served
    # them - and a visitor with a stale cookie was the cookie's account, not the
    # directory's. Now, when auth_proxy_trusted is on, the peer is listed in
    # auth_proxy_trusted_from (SM1129: Lazysite::Util::proxy_identity, the one
    # answer) and the request carries a user (SM1131: the one identity reader,
    # under the configured name), that identity is the requester and the cookie is
    # not consulted. With no proxy user the session check below is unchanged.
    require Lazysite::Util;
    require Lazysite::Auth::Identity;
    my $lz    = Lazysite::Paths::lazysite_dir($docroot);
    #
    # SM1181 S1 (SM1082 C2, R2): that rule is Lazysite::Auth::Session::request_session,
    # the function the auth wrapper asks too, so the two cannot come to decide
    # differently (T10, t/integration/290). The proxy answer is asked here, once, and
    # passed in, because the write path below asks the same question of it.
    my $pid = Lazysite::Util::proxy_identity($lz);
    my ( $session, $why, %detail ) = Lazysite::Auth::Session::request_session(
        lazysite_dir => $lz, proxy => $pid, cookie => $ENV{HTTP_COOKIE} // '' );

    # SM297 (ruling 206): A SESSION WHOSE STORE CANNOT BE READ IS REFUSED, not served
    # as anonymous. The cookie's signature held and the account's record could not
    # be read, so who this is cannot be told: the endpoint answers 503 naming the
    # store, and the log line (the wrapper's, from the same function) names it too,
    # so the sysop repairs it from the command line (lazysite check).
    if ( !$session && ( $why // '' ) eq 'cannot-tell' ) {
        require Lazysite::Util;
        require Lazysite::Auth::Settings;
        my @line = Lazysite::Auth::Session::session_log_line( undef, $why, \%detail, cookie_sent => 1 );
        Lazysite::Util::log_event( $line[0], $ENV{REQUEST_URI} // '-', @line[ 1 .. $#line ] ) if @line;
        return reply( 503, Lazysite::Auth::Settings::cannot_tell_refusal( $detail{store} ) );
    }
    my $user = $session ? $session->{user} : '';

    # SM297: THE IDENTITY IS A VALUE, held for the rest of this request. Every reader
    # this endpoint reaches - its own below, the ACL's operator check, the capability
    # gates - asks Lazysite::Auth::Identity::request_identity, which answers the held
    # value and reads nothing from %ENV. Nothing is written to the environment for
    # them to read back, so there is no header to forge and none to strip. An
    # anonymous caller holds an anonymous value, so nothing in %ENV makes it someone.
    my %anonymous = ( user => '', groups => [], name => '', email => '', sid => '', source => 'anonymous' );
    local $Lazysite::Auth::Identity::HELD = $session || \%anonymous;

    # A proxy identity is presented as one, never as a cookie session (see the
    # sentinel below).
    my $via_proxy = ( $session && $session->{source} eq 'proxy' ) ? 1 : 0;

    # SM1144: a verified account that holds `ui` is an operator and is shown the
    # phases - whether the account was established by the session cookie or by a
    # trusted proxy (SM1137) - and a signed-in member of the public is not.
    if ( length $user ) {
        require Lazysite::Auth::Settings;
        local $Lazysite::Auth::Settings::AUTH_DIR = "$lz/auth";
        Lazysite::Timing::operator(1) if ( Lazysite::Auth::Settings::caps_for($user) || {} )->{ui};
    }
    Lazysite::Timing::to('render');

    # SM1118 (ruled 2026-10-20, #338): a site in maintenance refuses the data
    # endpoint, as it refuses a posted form, to anyone who does not hold
    # `maintenance_access` - the verified account, or nobody. JSON 503 with
    # Retry-After.
    {
        require Lazysite::Maintenance;
        my $mst = Lazysite::Maintenance::status( lazysite_dir => $lz, host => $ENV{HTTP_HOST} );
        if ( $mst->{on} ) {
            my $held = 0;
            if ( length $user ) {
                require Lazysite::Auth::Settings;
                local $Lazysite::Auth::Settings::AUTH_DIR = "$lz/auth";
                $held = ( Lazysite::Auth::Settings::caps_for($user) || {} )->{maintenance_access} ? 1 : 0;
            }
            my $retry = Lazysite::Maintenance::retry_after($mst);
            return reply( 503,
                { ok => 0, kind => 'maintenance', error => Lazysite::Maintenance::message($mst), retry_after => $retry },
                ["Retry-After: $retry"] )
                unless $held;
        }
    }

    # DISABLED AND REVOKED ARE ALREADY DECIDED, and re-deciding them here was
    # wrong twice: verify_session_cookie returns undef with 'disabled' or
    # 'revoked' for both, so the account never reaches this line - and the
    # re-check called session_revoked() with NO ARGUMENTS, which reads the
    # revocation list and asks it about an undefined user. A second
    # implementation of a decision already made cannot agree with the first;
    # it can only disagree eventually.

    # SM297: the requester's groups, from the one reader - which answers the value
    # held above (a cookie session's groups as request_session resolved them, fresh
    # and less those this address is refused for; a trusted proxy's as the reader
    # gave them, SM1188). The writable_by narrowing and the read binding both use
    # this one answer. Before SM297 the endpoint wrote the identity into its own
    # environment (the fixed names and the sentinel) and read it back here: a
    # channel inside its own address space, which anything in the process could
    # have written over.
    my @groups = @{ Lazysite::Auth::Identity::request_identity( lazysite_dir => $lz )->{groups} };

    # A token for this session, so a page's JavaScript can write. Minted only
    # for a verified account: an anonymous caller has nothing to protect and
    # gets nothing to replay.
    if ( ( $q{csrf} // '' ) eq '1' ) {
        return reply( 403, { ok => 0, error => 'not signed in' } )
            unless length $user;
        return reply( 200,
            { ok => 1,
                token => Lazysite::Auth::Session::generate_csrf_token($user) } );
    }

    require Lazysite::Data::Tables;

    # --- writes ------------------------------------------------------------
    if ( $method eq 'POST' ) {
        return reply( 403,
            { ok => 0, kind => 'anonymous',
                error => 'writing needs a signed-in account. A public form is '
                    . 'the way to collect data from visitors.' } )
            unless length $user;

        # CSRF. The cookie travels automatically, so without this any page
        # anywhere could make a signed-in reader's browser write to this site.
        my $sent = $ENV{HTTP_X_CSRF_TOKEN} // '';
        return reply( 403,
            { ok => 0, kind => 'csrf',
                error => 'missing or stale CSRF token - fetch a fresh one from '
                    . '?csrf=1 and retry' } )
            unless Lazysite::Auth::Session::verify_csrf_token( $sent, $user );

        no warnings 'once';    # SM557
        require Lazysite::Manager::Data;
        local $Lazysite::Manager::Data::DOCROOT = $docroot;

        # SM860: THE ACTOR, from the identity this endpoint has already proved.
        #
        # `our $auth_user = ''` in Manager::Data is a declaration that says "set
        # by each surface". lazysite-manager-api.pl and lazysite-mcp.pl set it;
        # this file did not - so action_data_row_save passed the empty default,
        # Tables::_stamp resolved it to undef, and every row written through the
        # endpoint an app's own users write through recorded NO AUTHOR.
        #
        # That is not a blank field. _stamp's contract is that an empty
        # created_by means "the writer was not a signed-in account (a public
        # form): an absence, never a guess" - so absence MEANS anonymous, and a
        # signed-in account's row was making a false claim about itself.
        #
        # $user, never the request: it is the verified session's account, the
        # same value the trusted headers above are rebuilt from. Empty for an
        # anonymous caller, which is the one case that SHOULD record nobody -
        # and the POST branch refuses those before this matters.
        #
        # AFTER the require, not before: assigning a package global that the
        # module has not loaded yet is overwritten by its own `our` at compile
        # time, which is a silent no-op.
        local $Lazysite::Manager::Data::auth_user = $user;

        # THE CAPABILITY, resolved for the verified account. `writable=` on a
        # page cannot reach here and does not try; this is the only gate.
        require Lazysite::Auth::Settings;
        require Lazysite::Paths;
        local $Lazysite::Auth::Settings::AUTH_DIR = Lazysite::Paths::lazysite_dir($docroot) . "/auth";
        my $caps = Lazysite::Auth::Settings::caps_for($user) || {};

        # SM1135 (R1): a proxy user's groups the operator marked
        # `directory_grants` add their capabilities to the account's own; an
        # unmarked directory group adds none. A cookie session adds nothing.
        if ($via_proxy) {
            $caps = { %$caps,
                # SM1188: the identity read before the strip (the proxy session
                # request_session returned), not a second read of headers the
                # strip has deleted.
                %{ Lazysite::Auth::Settings::request_group_caps($session) } };
        }
        # SM682: manage_data OR write_data reaches a row write. They differ in
        # what `writable_by` then means - see below - so the check is here and
        # the distinction is there, rather than one tangled condition.
        return reply( 403,
            { ok => 0, kind => 'forbidden',
                error => 'this account holds neither manage_data nor '
                    . 'write_data, so it cannot write rows' } )
            unless $caps->{manage_data} || $caps->{write_data};
        Lazysite::Timing::to('write');    # SM1144: the row write

        # `writable_by` NARROWS, and only narrows. The descriptor has carried
        # it since DP-1 - validated, exported, named in the MCP tool's own
        # documentation - and NOTHING HAS EVER ENFORCED IT. A sysop writing
        # `writable_by: [editors]` was given a promise no code kept, which is
        # worse than the key not existing: they would have stopped looking for
        # another way to say it.
        #
        # NARROWING ONLY, deliberately. Widening - letting a listed group write
        # WITHOUT manage_data - would make a YAML file a grant of capability,
        # and that file can be written over MCP by an agent holding
        # manage_data. An agent could then hand write access to a group it
        # chose. So the capability is still required and the list only takes
        # access away.
        #
        # An EMPTY list means "no extra narrowing", which is what every
        # existing descriptor has.
        # SM682 round 2: ONE DECISION, ASKED HERE AND BY THE CONTROL API.
        #
        # This logic used to live only here, and the control-API data-row-save
        # carried the capability gate alone - so a write_data-only partner token
        # wrote every table on that surface, which the edge agent measured. The
        # rule now lives in Manager::Data::row_write_refusal and both surfaces
        # ask it, per SM578: a rule copied into two places is a rule that will
        # disagree with itself.
        require Lazysite::Manager::Data;
        {
            no warnings 'once';
            local $Lazysite::Manager::Data::DOCROOT = $docroot;
            if ( my $refusal
                = Lazysite::Manager::Data::row_write_refusal( $table, $caps, \@groups ) )
            {
                return reply( 403, $refusal );
            }

            # SM982: and the table's own write rule, which binds a manage_data
            # holder as it binds anyone. Asked here so the refusal is a 403, as
            # the one above is; the row action asks it again for every surface.
            if ( my $refusal = Lazysite::Manager::Data::table_rule_refusal( $table, 'write' ) ) {
                return reply( 403, $refusal );
            }
        }

        my $len = $ENV{CONTENT_LENGTH} || 0;
        return reply( 413, { ok => 0, error => 'body too large' } )
            if $len > 256 * 1024;
        my $body = '';
        read( STDIN, $body, $len ) if $len;
        # SM700, the same defect inverted. read() gives BYTES; decoding them without
        # ->utf8 treats each byte as a codepoint, so a posted accent arrives as two
        # characters and is stored double-encoded. The read path made the mojibake
        # visible; this one would have written it.
        my $req = eval { JSON::PP->new->utf8->decode($body) } // {};
        return reply( 400, { ok => 0, error => 'body must be a JSON object' } )
            unless ref $req eq 'HASH';

        # SM857: WHOSE ROW, from the same caps the table gate above used. This is
        # the surface an app's own users write through, so it is the one where
        # "ten applicants may each edit the other nine's rows" was true.
        my $as = Lazysite::Manager::Data::row_authority( $caps, $user );
        my $r
            = $req->{delete}
            ? Lazysite::Manager::Data::action_data_row_delete( $table,
            $req->{key}, as => $as, source => 'endpoint' )
            : Lazysite::Manager::Data::action_data_row_save( $table,
            $req->{key}, $req->{row}, as => $as, source => 'endpoint' );
        return reply( $r->{ok} ? 200 : 400, $r );
    }

    # THE SAME PARSER THE PAGE BINDING USES, and it has to be. This built its
    # own %opt and handed it to read_rows, so the two doors into one table
    # applied DIFFERENT RULES - a grammar restriction on the page, none here.
    # That is the shape of the SM476 defect exactly, and it would have grown
    # back every time the grammar changed on one side.
    #
    # The binding is assembled from the query string, so every part is checked
    # against a strict pattern FIRST. A value carrying a comma or a bracket
    # would otherwise inject a second parameter into the grammar - `order_by`
    # arriving as `name,limit=99999` is not a hypothetical, it is what a query
    # string is for.
    #
    # SM1377 (ruling 131): AN UNKNOWN PARAMETER IS REFUSED, before any value is
    # read. SM606 named it and still answered every row, on the argument that a
    # refusal would break a caller passing a harmless extra; that was a
    # behaviour change deserving its own decision, and ruling 131 is the
    # decision. A reply naming `chunk` as ignored was still a 200 carrying every
    # row, and a script that never read `ignored` displayed them as the subset
    # it asked for. A bad VALUE was already a 400; an unknown NAME now is too.
    #
    # `_` is the one exception, and the reason it exists: the ordinary
    # cache-buster (`?table=t&_=1700000000`) changes nothing a reply holds, so
    # refusing it would break callers for no gain. It is accepted and unread.
    my %READS   = map       { $_ => 1 } qw(table order_by order limit offset csrf _);
    my @unknown = sort grep { !$READS{$_} } keys %q;
    if (@unknown) {
        return reply( 400,
            { ok => 0, kind => 'unknown-parameter',
                parameters => \@unknown,
                error      => 'unknown parameter'
                    . ( @unknown == 1 ? '' : 's' ) . ': '
                    . join( ', ', @unknown )
                    . ' - this endpoint reads table, order_by, order, limit and '
                    . 'offset (and ignores _, a cache-buster). Filter on the '
                    . 'page binding, or in your own script.' } );
    }

    my @args;
    if ( defined $q{order_by} && length $q{order_by} ) {
        return reply( 400, { ok => 0, error => 'order_by must be a field name' } )
            unless $q{order_by} =~ /\A[a-z][a-z0-9_]*\z/;
        my $dir = ( ( $q{order} // '' ) =~ /\Adesc\z/i ) ? '-' : '';
        push @args, "order=$dir$q{order_by}";
    }
    for my $n (qw(limit offset)) {
        next unless defined $q{$n} && length $q{$n};
        return reply( 400, { ok => 0, error => "$n must be a whole number" } )
            unless $q{$n} =~ /\A\d+\z/;
        push @args, "$n=$q{$n}";
    }
    my $binding = $table . ( @args ? '(' . join( ',', @args ) . ')' : '' );

    # THE VISITOR (SM476), with no sysop bypass. This endpoint is the page's
    # data source, so it must answer exactly what the page's own binding would
    # - a sysop who saw more here than their site's visitors do would be
    # testing a different site.
    # A BAD BINDING IS A 400, NOT A 404. "no such table" for a limit that is
    # not a number would send a caller looking for a table that is right there.
    my $r = Lazysite::Data::Tables::resolve_binding(
        $docroot, $binding,
        { user => $user,
            groups => [ grep { length } @groups ],
        }
    );
    unless ( $r->{ok} ) {
        return reply( 400, { ok => 0, error => $r->{error} } )
            unless ( $r->{kind} // '' ) eq 'no_such_table';

        # A table nobody declared and a table this caller may not read answer
        # the SAME WAY, which is why the wording was chosen before the gate
        # existed: adding the gate changed no caller-visible string. Telling an
        # anonymous caller which tables a site has is most of what is worth
        # having from a store they cannot read.
        return reply( 404,
            { ok => 0, error => 'no such table, or not available to you' } );
    }

    return reply( 200,
        { ok => 1,
            table => $r->{table},
            rows  => $r->{rows},

            # SM511: the endpoint answers exactly what the page's binding
            # does - the true count beside the (possibly capped) rows, and
            # any clamp warning said rather than swallowed.
            ( defined $r->{total} ? ( total => 0 + $r->{total} ) : () ),

            # SM1377: an unknown parameter is refused above, so the SM606
            # `ignored` list and its warning line are gone: a reply that
            # reaches here read every parameter it was sent.
            ( $r->{warnings}       ? ( warnings       => $r->{warnings} ) : () ),
            ( $r->{pending_schema} ? ( pending_schema => JSON::PP::true ) : () ),
        } );
}

1;
