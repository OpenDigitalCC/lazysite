package Lazysite::Capabilities;

# SM126: the machine-parseable capability map. One builder, consulted by the
# MCP `describe_capabilities` tool and the control-API `describe-capabilities`
# action (and, later, a static generated doc), so a connecting agent can learn
# up front what it may do and how - instead of discovering by trial and error.
#
# The channel/action split derives from @CAP_KEYS (the single source of truth in
# Auth::Settings), so a new capability appears here automatically. The per-action
# "unlocks" and the task recipes are curated here; t/unit/lib/05-capabilities.t
# cross-checks them against the live control-API %need and MCP %TOOLS maps so
# they cannot silently drift.

use strict;
use warnings;
use JSON::PP                 ();
use Lazysite::Paths          ();
use Lazysite::Util           ();
use Lazysite::Auth::Settings qw(@CAP_KEYS);
use Exporter 'import';
our @EXPORT_OK = qw(describe capability_keys reachability reach_for channel_keys action_keys channel_service action_channel_surface implied_by implications whoami_grant whoami_roles);

# The four channels (WHERE you operate). Fixed concept; the rest of @CAP_KEYS are
# actions (WHAT you may do).
my @CHANNELS   = qw(ui webdav api mcp);
my %IS_CHANNEL = map { $_ => 1 } @CHANNELS;

sub channel_keys    { return @CHANNELS }
sub action_keys     { return grep { !$IS_CHANNEL{$_} } @CAP_KEYS }
sub capability_keys { return @CAP_KEYS }

# Channel descriptions. All four are enforced at the transport (SM126): ui at
# login, webdav by webdav_enabled_for, api on the control-API token path, mcp on
# the MCP tools/call dispatch.
my %CHANNEL_INFO = (
    ui => 'Interactive manager UI over a browser cookie session.',
    webdav => 'The /dav publishing endpoint (files, themes, layouts). Also gates the per-file ACL actions on the control API (acl-get / acl-set / acl-remove) - alongside manage_content since SM431, because a capability that lets you CREATE gated content must let you inspect and set the rule governing it, on the same surface.',
    api =>
        'The token-authenticated control API (structured actions). Call '
        . '`action=actions-list` for the actions THIS account may use, with '
        . 'the parameters each takes and where each is read from - the '
        . "control API's equivalent of MCP's tools/list (SM350). This map "
        . 'says what you may do; that says what you may call.',
    mcp => 'The MCP connector (Claude.ai / ChatGPT / Code tools).',
);

# SM180: each CHANNEL capability only DOES anything while its site service is
# enabled - the two planes (per-principal grant, per-site killswitch) are
# independent, so a grant can be dormant. This is the map from a channel to the
# lazysite.conf key that gates it: 'ui' by the `manager` key, the three remote
# channels by their *_enabled flags. The manager consults it to flag a
# granted-but-dormant capability (service off) in the Groups/Users grids. Single
# source of truth: surfaced in describe() and read by the control API.
my %CHANNEL_SERVICE = (
    ui     => 'manager',
    webdav => 'webdav_enabled',
    api    => 'control_api_enabled',
    mcp    => 'mcp_enabled',
);
sub channel_service { return {%CHANNEL_SERVICE} }

# Action capabilities: a title and what holding it unlocks, per channel. The
# lists name real MCP tools, control-API actions, or WebDAV path shapes; the
# consistency test keeps the tool/action names honest against the live maps.
my %ACTION_INFO = (
    manage_content => {
        section => 'Content',
        title   => 'Read and write site content (pages, assets).',
        grants => 'Create, edit, move and delete pages and assets, and set who may read them. Over WebDAV it is direct file access to the content tree.',
        unlocks => {
            api => [ qw(aliases-list git-status git-history git-history-summary
                    git-show git-restore lang-status site-export-primary
                    regenerate-registries preview-public
                    acl-get acl-set acl-remove
                    data-table-acl-get data-table-acl-set data-table-acl-remove
                    brief-read briefs-list
                    page-pdf pages
                    page-copy page-copy-discard page-copies) ],
            mcp => [ qw(list_files read_file write_file upload_file replace_text copy_file
                    move_file delete_file create_page delete_page rename_page
                    list_pages read_page preview_page page_status search_files
                    validate_page invalidate_cache regenerate_registries audit_site create_form
                    get_permissions set_permissions remove_permissions read_brief
                    list_briefs
                    list_versions list_content_history view_version restore_version preview_public_page
                    copy_page discard_copy)
            ],
            webdav => ['write anywhere in the content namespace (within dav_scope)'],
        },
    },
    # SM1414 (ruling 169): THE MEMBER'S CONTENT DOOR, the content twin of
    # write_data. A member app's authors (members without `ui`) save files over
    # their own signed-in session: the manager API's cookie door, for read, save,
    # list, mkdir, move and delete only. A WRITE IS AN ALLOW-LIST, as write_data's
    # writable_by is: only a file rule whose write list names the account or its
    # group admits it, and a path no rule governs is refused - where for a
    # manager it is open. Implies nothing and is implied by nothing: a
    # manage_content holder without `ui` is refused this door, and a `ui` holder
    # never uses it. Granted to no shipped role.
    write_content => {
        section => 'Content',
        title => 'Write content files where a file rule names you, over your own signed-in session.',
        grants => 'Read, list, save, make folders in, move and delete content files through the '
            . 'manager API over your own signed-in session, without the manager. A write lands '
            . 'only where a file rule on the file or its folder names you or one of your groups in '
            . 'its write list; a path no rule governs is refused, and the engine\'s own tree is never '
            . 'reached. A listing shows only the files a rule lets you read. Paths are inside the '
            . 'content root of the domain you signed in on. Grant '
            . 'this to an app\'s own authors where `manage_content` and the manager would be far '
            . 'too wide. It grants nothing to an account that holds `ui`, which uses the manager.',
        unlocks => {
            ui => [ 'the manager API over a signed-in session, without the manager: read, list, save, '
                    . 'mkdir, move and delete, where a file rule names you' ],
        },
    },
    manage_nav => {
        section => 'Content',
        title   => 'Edit site navigation.',
        grants => 'Edit the site\'s navigation - what appears in the menu, and in what order.',
        # SM568: `pages` is a read a content author needs as much as a nav
        # editor, so manage_content admits it too and it is listed under both.
        # SM943 ruling 2 (2026-10-09): the structured nav read (nav-read,
        # read_nav) needs no capability at all - the nav is public - so it is
        # listed under none; this capability is the WRITE, and the WebDAV GET
        # of the raw file.
        unlocks => {
            api    => [qw(nav-save pages)],
            mcp    => [qw(set_nav)],
            webdav => ['lazysite/nav.conf'],
        },
    },
    manage_forms => {
        section => 'Content',
        # SM618: the title said what this capability CONFIGURES and stayed
        # silent on what it READS, while the sentence it did spend words on -
        # that the notification never carries content - reads as a reassurance
        # about the grant. It is a statement about the BELL. `form-submissions`
        # WAS gated on [manage_forms, read_submissions], either admitting - so
        # this grant returned live submission bodies. SM652 narrowed it to
        # read_submissions on both channels; the measurement below is what that
        # capability now hands over, not this one. Measured on edge
        # 2026-08-26: name, email, phone, message and the submitter's IP, under
        # a capability a sysop grants to let an agent wire up a form.
        # SM594/SM652: THIS TEXT WAS STALE AND OVERSTATED THE GRANT. SM652
        # narrowed form-submissions to read_submissions on both channels and
        # updated the comment above while leaving the title saying this
        # capability "returns live submission CONTENT". It is the sentence an
        # operator reads when deciding whether to hand this over, and it
        # described a reach the grant had stopped having - the direction that
        # causes over-granting, since a sysop reading it would reach for
        # read_submissions when manage_forms would have done.
        title => 'Wire forms to delivery handlers - which handlers a form '
            . 'calls - and configure the email and file handlers. This '
            . 'grant does NOT read submissions - SM652 narrowed '
            . '`form-submissions` and `form-list` to `read_submissions` on '
            . 'every channel, so an agent that processes leads needs that '
            . 'capability and this one only changes how forms are wired. '
            . 'SM660: deleting or confirming a submission needs BOTH, because '
            . 'destroying what you may not read is not a coherent grant. '
            . 'A submitted form also raises an '
            . 'sysop notification of its own accord (the manager bell, plus chat '
            . 'where notify-xmpp is configured) naming the form and the time but '
            . 'never the content - so nothing needs to poll to learn that something '
            . 'arrived. See /docs/forms.',
        # SM457: the API list was MISSING, and its absence sent a real
        # operator's agent guessing.
        #
        # form-submissions needs read_submissions (SM652 narrowed it from
        # [manage_forms, read_submissions], where either admitted).
        # read_submissions advertises it correctly; this one advertised no api
        # key at all, so a partner
        # holding manage_forms was told about MCP tools and a WebDAV path and
        # nothing about the control API, while enforcement let them straight
        # in. They tried describe_capabilities, list_form_handlers, forms,
        # form_submissions, list_submissions and submissions - six names, none
        # of them real, four of them snake_case guesses at a kebab-case
        # surface and two of them MCP tool names aimed at the API.
        #
        # SM842: THE GRANT NO LONGER NAMES A NEW DESTINATION. It used to reach any
        # URL through an inline form target; inline targets are gone, and
        # outbound HTTP goes through a connector, which is manage_connectors'.
        # What this grant configures is email and file delivery, and which
        # existing handlers a form calls.
        grants => 'Choose which handlers each form calls, and create, change and delete the email and file handlers - whose settings name the address mail goes to and the store a submission is kept in. A table handler needs manage_data and a connector handler manage_connectors. It also reads and writes a form\'s own configuration, lazysite/forms/<name>.conf, over WebDAV, MCP read_file/write_file and the manager\'s file editor (SM1371). It does not read what was submitted; read_submissions does.',
        # SM435 was this defect pointed the other way: the descriptor CLAIMED
        # a path enforcement refused. Under-claiming is the quieter failure -
        # nothing 403s, nothing errors, the agent simply cannot find a door it
        # is holding the key to.
        unlocks => {
            # SM632: form-delete/delete_form are the inverse of bind_form.
            # Declared on both surfaces at the same time, because a capability
            # that advertises the create and not the destroy is how an agent
            # concludes the object is permanent (t/lint/71, t/lint/23).
            # SM652: form-submissions and form-list are GONE from here - they
            # need read_submissions on both channels now, and a map that still
            # advertised them would tell a holder it can do something the gate
            # refuses. That is the same stale claim SM652's own test caught in
            # form_list's MCP description.
            # SM842: the handler actions are gated ANY-OF the three destination
            # capabilities (then the handler's type decides), so all three
            # name them - SM457's rule for cross-gated actions.
            api => [ qw(form-delete form-targets-read form-targets-save form-uploads-save form-notify-save
                    handler-list handler-save handler-delete
                    schedule-list schedule-save schedule-delete) ],
            # SM1392 (ruling 152): read_file and write_file on a form's own
            # configuration only - the tools declare it (cap_path), the
            # listing says it, and t/lint/90 reads the declaration.
            mcp => [ qw(bind_form delete_form set_form_uploads set_form_notify
                    list_handlers save_handler delete_handler
                    list_schedule save_schedule delete_schedule
                    read_file write_file) ],
            webdav => ['lazysite/forms/<name>.conf (its targets name existing handlers; not smtp.conf, handlers.conf or schedule.conf)'],
        },
    },
    manage_themes => {
        section => 'Appearance',
        title   => 'Install and activate themes.',
        grants => 'Install, author and activate themes, which decide how every page on the site looks - and, with manage_content, preview a page in a theme that is not active (preview_page with theme, SM1290).',
        unlocks => {
            # SM457: these are gated on [manage_themes, manage_layouts] -
            # EITHER admits - so both must name them. A partner holding only
            # one was admitted and never told.
            api => [ qw(theme-activate theme-copy theme-list themes-for-layout themes-list-all
                    artifact-manifest artifact-validate preview-grant theme-delete
                    layouts-available layouts-manifest) ],
            mcp => [qw(list_themes theme_tokens activate_theme create_theme copy_theme delete_theme install_theme)],
            webdav => ['lazysite/layouts/<layout>/themes/<theme>/ (active theme read-only)'],
        },
    },
    manage_layouts => {
        section => 'Appearance',
        title   => 'Install, author and activate layouts.',
        grants => 'Install, author and activate layouts, which decide the shape of every page on the site - and, with manage_content, preview a page in a theme that is not active (preview_page with theme, SM1290).',
        unlocks => {
            # SM457: as above - cross-gated actions belong on both lists.
            api => [ qw(layout-activate layout-install layout-delete layouts-available
                    layouts-manifest
                    artifact-manifest artifact-validate preview-grant
                    theme-list themes-for-layout themes-list-all) ],
            mcp => [qw(activate_layout install_layout delete_layout list_layout_catalogue)],
            webdav => ['lazysite/layouts/<layout>/ (active layout read-only)'],
        },
    },
    manage_domains => {
        section => 'Site',
        title   => 'Manage the domains this instance serves, and portable site packages.',
        grants => 'Add and remove the domains this instance serves, and export or apply a whole site as a package.',
        unlocks => {
            api => [ qw(domains-list domain-add domain-alias-add domain-set domain-remove
                    domain-preview domain-check remap-list remap-save
                    site-backup-create site-backup-download site-backup-upload
                    site-backup-apply site-backup-delete site-backup-inspect) ],
            mcp => [qw(list_domains domain_set preview_domain site_backup site_apply)],
        },
    },
    # SM447 / ADR 0009. DECLARED BY extensions/data.pl and mirrored here; the
    # extension is the owner and t/lint/76 refuses a mirror with no extension
    # claiming it, or one claimed twice.
    #
    # THE UNLOCK LISTS ARE EMPTY AND THAT IS ACCURATE. The typed core is built
    # and nothing routes to it yet: no control-API action and no MCP tool is
    # gated on this capability. Granting it today therefore admits an account
    # to nothing, which is honest - what it must never do is CLAIM actions that
    # do not exist, which is SM457's defect pointed the other way and the one
    # t/lint/71 exists to catch.
    # SM682: row-write on NAMED tables, and nothing else.
    #
    # manage_data is all-or-nothing: it carries table create, alter and drop AND
    # read/write across every table on the instance. An app with external,
    # semi-trusted users - a learner submitting their own work - had two options
    # and both were wrong: hand instance-wide data administration to the least
    # trusted user class, or collect nothing.
    #
    # `writable_by` MEANS SOMETHING DIFFERENT FOR THIS CAPABILITY, and that is
    # what makes it safe rather than a rename of the problem:
    #
    #   manage_data + empty list  -> may write (unchanged)
    #   manage_data + a list      -> may write only if in it (unchanged, narrows)
    #   write_data  + empty list  -> may NOT write
    #   write_data  + a list      -> may write only if in it
    #
    # For manage_data the list NARROWS; for this one it is an ALLOW-LIST. A
    # table naming nobody is closed to a write_data holder - otherwise this
    # would be instance-wide write under a new name, which is the thing being
    # fixed.
    #
    # The descriptor is still NOT a grant. `data-table-save` is gated on
    # manage_data, so an agent holding it can edit the list - but it cannot
    # invent write_data, which comes from the group store where an operator put
    # it under SM195's ceiling. The most such an agent can do is widen a group
    # the operator already trusted with row-writes elsewhere, and SM682 records
    # the SM647 remedy for that residue.
    write_data => {
        section => 'Data',
        title   => 'Write rows in data tables that name your group, and nothing else.',

        # SM740: a HIERARCHY, declared. manage_data admits every action this
        # unlocks (the gate is ANY-OF, SM662), so an account holding manage_data
        # loses nothing when this is withheld - and two sibling booleans in
        # whoami said otherwise. The field read them as a partition, withheld
        # this to stop row writes, and watched a row land. Declared here, not
        # derived from the unlock lists: manage_services' one unlock is also in
        # manage_config's and is NOT implied (config-set needs both for a
        # service key - an AND), so subsumption alone would lie. t/lint/117
        # holds that a declaration is true and that every undeclared
        # subsumption is exempted with its reason.
        implied_by => ['manage_data'],
        grants     =>
            'Insert, update and delete ROWS in the data tables whose `writable_by` names one of your groups - and no others. It does NOT declare, alter, migrate or drop a table, and it reaches no table that does not name you. Grant this to an app\'s own users where `manage_data` (every table on the instance, plus schema control) would be far too wide.',
        unlocks => {
            api => [ qw(data-row-save data-row-delete
                    data-row-switch data-row-undo data-wizards data-wizard data-wizard-run) ], # SM1355
            # SM943: NO `mcp` HALF, and it was an over-claim while it stood.
            # save_data_row and delete_data_row are gated on manage_data alone
            # (`cap` in lazysite-mcp.pl), so a write_data-only partner is
            # refused both and this map told it otherwise. The gate is what is
            # right: neither tool asks Manager::Data::row_write_refusal, so
            # admitting write_data there would make it an instance-wide row
            # write over MCP - the SM682 round-2 escalation, on the other
            # door. A write_data MCP door needs that check first. t/lint/90
            # now compares the map with each tool's gate in this direction.
        },
    },

    # SM579 phase 1: WHERE THE SITE'S DATA GOES. A connector is a credentialed
    # destination that forms, callers and jobs send through; creating one
    # names a place site data is disclosed to and holds a secret for it.
    # That is a conferral in the SM647/SM682 sense - authority over the data,
    # not over pages - so it is its own capability and not part of
    # manage_config. Invoking a connector (mode 2) is gated by the connector's
    # own `callers` groups, or this capability.
    manage_connectors => {
        section => 'Site',
        title => 'Configure connectors: where site data may be sent, with what credential, by whom, how often.',
        grants =>
            'Create, change and delete connectors (a destination URL, the header its secret travels in, the modes it permits, the groups that may call it, its rate cap, the table its answers land in), set their secrets, read the record of every call, and call any connector. A connector reachable from a public form is opt-in on the connector and never the default. Every call is one audit row naming the connector, the trigger, the mode and the class of data - never the payload.',
        unlocks => {
            # connector-call is NOT here: the connector gates it (callers
            # groups, or this capability) and the API gate admits any
            # logged-in caller to the action, so the map may not claim it.
            # SM1369 X2 (ruling 71): an extension's connection user is its own
            # capability now, declared by the extension and topped up from this one.
            api => [ qw(connector-list connector-save connector-secret-set connector-delete connector-calls
                    handler-list handler-save handler-delete form-targets-read
                    schedule-list schedule-save schedule-delete) ],
            # SM842: a connector handler is this capability's to configure.
            mcp => [qw(list_handlers save_handler delete_handler list_schedule save_schedule delete_schedule)],
        },
    },
    # SM1019 (SM1010, ruled 2026-10-12 "New 'manage_notifications' cap"): WHO MAY
    # WRITE A NOTIFICATION RULE. A notify handler sends mail and bell notices to
    # recipients it resolves at send time - accounts, the owners of rows,
    # addresses held in a table, fixed addresses, the submitter - so authoring
    # one is its own decision, off by default and held by the operator (manager)
    # groups, which are topped up with every capability. It is asked by the
    # handler contract (cap_for_type 'notify'). SM1010 R5 (ruled 2026-10-12, with
    # SM1034 Q9): it also opens the handler actions' door - list, save, delete -
    # and the contract keeps it to notify handlers: a holder without
    # manage_forms, manage_data or manage_connectors is shown only the handlers
    # it may configure, and may save or delete only those.
    manage_notifications => {
        section => 'Site',
        title   => 'Write notification rules: notify handlers, which mail and bell '
            . 'people when something happens - a form is submitted, the schedule '
            . 'fires. Recipients may be accounts, the owners of matching rows, '
            . 'addresses held in a table, fixed addresses or the submitter; the '
            . 'engine guards technical safety (one address per recipient, queued '
            . 'and sent once, a per-recipient cap, an audit row each) and whether a '
            . 'recipient may be written to is the operator\'s responsibility.',
        grants => 'Create, change and delete notify handlers on the Handlers page or its actions, which it reaches on its own (SM1010 R5) and where it sees only notify handlers unless another handler capability shows more; binding one to a form needs manage_forms. Read the notification outbox - queued, held and failed events and who each resolves to (SM1072); a domain-confined holder sees only its own domains\' rules. Retry that outbox now (SM1107): make a rule\'s waiting events, or one, due at once after a mail fix; the cap and held messages still apply. Off by default; held by the operator groups.',
        unlocks => {
            api => [qw(handler-list handler-save handler-delete notify-outbox-list notify-outbox-retry)],
            mcp => [qw(list_handlers save_handler delete_handler read_notify_outbox retry_notify_outbox)],
        },
    },
    manage_data => {
        section => 'Data',
        title   => 'Read and write the site\'s data tables.',
        grants => 'Read and write the data tables on this instance, and declare new ones. A table that names no domain is reachable by any holder, on any site here. A table\'s own access rule still binds the holder (SM982): its read list decides who reads its rows, its write list who changes them.',
        unlocks => {
            api => [
                qw(handler-list handler-save handler-delete form-targets-read
                    schedule-list schedule-save schedule-delete
                    data-tables data-table data-table-save data-rows
                    data-migrate data-rebuild data-row-save data-row-delete
                    data-export data-import data-table-source data-migrate-plan
                    data-safety-exports
                    data-safety-export-read data-safety-export-restore
                    data-row-switch data-row-undo data-row-changes
                    data-wizards data-wizard data-wizard-run data-wizard-save
                    data-table-refresh)
            ],

            mcp => [
                qw(list_handlers save_handler delete_handler list_schedule save_schedule delete_schedule
                    list_data_tables describe_data_table save_data_table
                    read_data_rows migrate_data_table rebuild_data_table
                    save_data_row delete_data_row
                    list_data_safety_exports
                    read_data_safety_export restore_data_safety_export
                    read_data_table_source plan_data_migration
                    switch_row undo_row_change list_row_changes
                    list_wizards run_wizard save_wizard
                    refresh_data_table)
            ],
            # NO WEBDAV ENTRY, and this used to claim one. WebDAV allows
            # only lazysite/layouts/ - "the rest of lazysite/ is protected" -
            # so `lazysite/db/tables/<table>.yaml` was a path this capability
            # advertised and the front door refused. That is SM435's defect
            # exactly, and t/lint/68 exists for it on this plane. Descriptors
            # are written through data-table-save / save_data_table, which
            # validate before storing.
        },
    },
    # SM576 part 1: DECLARED BY extensions/briefs.pl and mirrored in @CAP_KEYS,
    # the manage_data pattern (ADR 0009), so that writing another principal's
    # authoring record is a grant of its own rather than a side effect of being
    # allowed to edit pages - which is what SM575 measured happening.
    #
    # THE READS ARE LISTED TWICE ON PURPOSE. brief-read / briefs-list appear
    # here AND under manage_content, because the gate admits either: the
    # migration keeps brief reads with a long-standing manage_content grant and
    # moves only the writes. A capability's unlocks list states what holding it
    # gives you, not what it exclusively gives you (manage_nav's pages and
    # manage_forms' form-submissions are listed twice for the same reason).
    manage_briefs => {
        section => 'Content',
        title => 'Write authoring briefs - the "why" record kept beside a content file. '
            # SM654 (R-18): this said DELETING needs manage_briefs. It needs
            # `purge` - brief-delete is gated on it because no copy survives
            # (SM591), and the map immediately below says so correctly. A title
            # contradicting the map beside it is the same hand-kept drift as the
            # unlocks omissions, in prose rather than in data.
            . 'Reading a brief is also admitted by manage_content; creating and '
            . 'appending to one needs this. DELETING a brief needs `purge`, not '
            . 'this capability, because no copy survives it. Declared by the '
            . 'briefs extension, so it is grantable only where that extension is '
            . 'installed.',
        grants => 'Read and write authoring briefs - the record of WHY a page is as it is. Does not reach the page itself.',
        unlocks => {
            api => [qw(brief-read brief-append briefs-migrate briefs-list)],
            mcp => [qw(read_brief append_brief list_briefs)],
        },
    },
    run_jobs => {
        section => 'Operations',
        title   => 'Be the account the scheduler runs timed jobs as. This is not '
            . 'permission to DO anything in particular - a job\'s own action '
            . 'faces the ordinary capability gate unchanged, so an account '
            . 'holding only this can carry a job and still be refused the work. '
            . 'It is the separate question of whether an account may be used by '
            . 'the runtime at all, asked so that a job cannot be attached to an '
            . 'account nobody meant to carry one. A job never runs as `system`, '
            . 'because a timer that can call anything is a second write plane '
            . 'wearing a clock. Declared by the daemon extension, so it is '
            . 'grantable only where that extension is installed.',
        grants => 'Lets the persistent runtime act as this account when it runs a scheduled job. It confers no ability of its own - whatever the job does still needs the capability for that action, and every run is recorded against this account by name.',
        unlocks => {},
    },
    # SM591: THE LATERAL GRANTS. Deletion and tidying are the same job wherever
    # they happen, so they answer these rather than the module capability that
    # lets a partner USE the module. Which tier an action joins is SM587's copy
    # test and nothing else - see the rule beside %MUTATING / %DESTRUCTIVE /
    # %CHANGES_ACCESS in lazysite-manager-api.pl, which is where an action is
    # classified.
    #
    # THE ACL VERBS ARE DELIBERATELY ABSENT. acl-set, acl-remove, preview-grant
    # and preview-clear stay under manage_content / manage_themes /
    # manage_layouts, carrying SM587's `changes_access` flag. Folding them in
    # here would mean whoever may clear old backups may also un-gate content -
    # a sysop who wanted a housekeeper handing over the permission surface.
    # Housekeeping and permission management are different jobs.
    housekeeping => {
        section => 'Operations',
        title   => 'Destroy things the engine keeps a copy of. The RECOVERABLE tier of '
            . 'the housekeeping grant: a drop mints a safety export of every row before '
            . 'anything goes, so the object is gone and the data is not. Granting a '
            . 'module capability lets a partner USE that module; this is what lets them '
            . 'destroy inside it, which are two different decisions.',
        grants => 'Delete things the engine keeps a copy of - drop a data table, clear an old backup. Recoverable: the safety export survives a table drop. Deleting that export is `purge`, which is a separate grant.',
        unlocks => { api => [qw(data-table-drop)], mcp => [qw(drop_data_table)] },
    },
    purge => {
        section => 'Operations',
        title   => 'Destroy things NO copy survives. The IRREVERSIBLE tier: deleting a '
            . 'safety export is what makes an earlier table drop permanent, and deleting '
            . 'a brief or a backup ends the only record there was. Held separately from '
            . '`housekeeping` and not implied by it. SM577: A BACKUP STORE IS '
            . 'INSTANCE-WIDE - one instance serves many domains from one backups '
            . 'directory, so this reaches archives of OTHER sites on the same instance '
            . 'and a deletion is NOT scoped by the site whose grant authorised it.',
        grants => 'Destroy things NO copy survives: a safety export, a brief, a backup. The backup store is instance-wide, so this reaches other sites\' archives on the same instance.',
        unlocks => {
            api => [qw(brief-delete data-safety-export-delete artifact-backups-delete)],
            mcp => [qw(delete_brief delete_data_safety_export)],
            # Cookie-only on the API (see Actions.pm), so it is named on the
            # surface that serves it. A capability claiming it under `api` would
            # send a token client after a door that is not there.
            ui => ['the manager Backups page: backup-delete (instance-wide store)'],
        },
    },
    manage_config => {
        section => 'Site',
        title   => 'Read and set safe site configuration.',
        grants => 'Read and change ordinary site settings - title, cache lifetime, search defaults, the active layout and theme. The switches that decide whether the remote surfaces answer at all are `manage_services`, held separately.',
        # SM435: this listed lazysite/nav.conf and lazysite/forms/<name>.conf
        # over WebDAV, which 0.8.1 moved to manage_nav and manage_forms
        # respectively - see authorise() in lazysite-dav.pl, which admits
        # neither of them under this capability. Both new entries were written
        # and this one was never trimmed, so the descriptor promised a partner
        # holding manage_config alone a write it would be refused. Nothing was
        # over-permitted; enforcement was always the strict side. The cost was
        # that the descriptor is the ONE per-capability account of the boundary
        # readable from outside the code, so being wrong sent an agent to a 403
        # and then to trial and error - which is what RI-002's deny reasons
        # exist to end. t/lint/68 now checks the two against each other.
        unlocks => {
            # SM664: git-history-summary is reachable with manage_content OR
            # manage_config, so BOTH capabilities claim it. Listing it only
            # under manage_content left this map under-claiming - a holder of
            # this capability could call the action and nothing said so, which
            # is the half of SM654 a lint does not catch (it refuses
            # over-claiming, not silence).
            api => [ qw(config-read config-set git-init bad-url-blocks bad-url-block bad-url-unblock
                    git-history-summary) ],
        },
    },

    # SM633: the switches that decide whether anyone can reach the instance at
    # all are a different size of decision from the site's title and its cache
    # lifetime, and they sat under one capability whose own name says "SAFE".
    #
    # SM612 closed the sharpest edge - a token can no longer switch off the
    # manager surface that would revoke it - by restricting `manager` and
    # `manager_path` to the cookie channel. That was a fix at the KEY level.
    # This is the LOCK being the right shape: an operator can now hand a partner
    # the ability to tune caching without handing it the ability to turn WebDAV
    # off for everyone.
    manage_services => {
        section => 'Site',
        title   => 'Switch the remote surfaces on and off (WebDAV, MCP, OAuth, '
            . 'the control API, the pairing-key exchange).',
        grants => 'Turn the site\'s remote surfaces on or off. Switching one '
            . 'off does not narrow a grant - it stops the surface answering for '
            . 'EVERYONE, including partners and agents already using it, and the '
            . 'manager UI is unaffected.',
        unlocks => { api => [qw(config-set)] },
    },
    manage_users => {
        section => 'Accounts',
        title => 'Manage user accounts and group membership - and nothing else: not the operator (SM991).',
        grants => 'Create and delete accounts, and change who belongs to which group - including what those groups may do. User and group management ONLY (SM991): it passes no other capability gate, a file\'s rule binds it, and it does not change the operator\'s account or the operator group - the operator is a member of the operator group. Accounts and membership are managed in the manager UI only. Over the control API and MCP (SM1050) it lists the groups - a domain-confined caller the ones relevant to its domains - and creates a group and sets its capabilities, giving only capabilities the caller holds, never the operator flag; it deletes a group nothing uses (no member, no rule naming it), never the operator group (SM1387).',
        # SM858: with read_submissions, the Approve button on a registration
        # form's submissions.
        unlocks => { ui => [ 'the manager Users and Groups pages',
                'Approve (an account) on a submission whose form declares account_email' ],
            api => [qw(groups-list group-set group-delete accounts-import-stage accounts-import-remove address-profiles)], # SM1050, SM1053, SM1138, SM1387
            mcp => [qw(list_groups set_group delete_group stage_accounts list_address_profiles)] },
    },
    analytics => {
        section => 'Insight',
        title => 'Read sanitised, IP-anonymised visitor analytics, including which signed-in accounts visited.',
        grants => 'Read this site\'s visitor figures. Addresses are anonymised before this capability sees them; a visit made while signed in carries the account name, and the visits per account are shown. A caller confined to some domains sees only the accounts that visited those domains.',
        unlocks => { api => [qw(analyse_visitors)], mcp => [qw(analyse_visitors)] },
    },
    # N13-04, ruled 2026-09-10 and 2026-09-11: THE AUDIT TRAIL'S SWITCH IS NOT
    # SITE CONFIGURATION. Turning the trail off is a different authority from
    # configuring a site, so it does not travel with manage_config - the switch
    # needs manage_config AND this. It sits in a group of its own
    # (cap-audit-switch), which no role draws on by default: nobody can silence
    # the trail until an administrator decides somebody should. Reading the
    # trail is `audit`, a different grant in a different group.
    audit_switch => {
        section => 'Operations',
        title   => 'Switch the audit trail off and on again. Always recorded: the '
            . 'switch-off is written to the trail, naming who, before it stops, and '
            . 'the switch-on as it resumes - so the gap has named edges.',
        grants => 'Switch the audit trail off and on (audit-trail-set), together with Site config. Off stops recording and keeps everything already recorded. Granted to no role by default.',
        unlocks => { api => [qw(audit-trail-set)] },
    },
    # SM1118, ruled 2026-10-20 (#338): WHO GETS THROUGH A SITE IN MAINTENANCE.
    # With `maintenance: on` every page request goes to the maintenance page and
    # every machine door (MCP, the control API, WebDAV, the data endpoint, the form
    # handler) answers 503. A request whose verified identity holds this
    # capability is the exception. Assignable to any group like the others; the
    # operator group holds it by default (a manager group is topped up with every
    # capability, on upgrade as at first run). It unlocks no action of its own:
    # it changes how every other door answers while the switch is on.
    maintenance_access => {
        section => 'Operations',
        title   => 'Use the site while it is in maintenance. Without this, a page '
            . 'request is sent to the maintenance page and the remote doors '
            . '(MCP, control API, WebDAV) answer 503 until maintenance is switched off.',
        grants => 'Browse the site, and use MCP, the control API and WebDAV, while the site is in maintenance (the `maintenance` setting, per domain or for the whole instance). Held by the operator group and the site-admins role by default. Has no effect while the site is not in maintenance.',
        unlocks => {},
    },
    # SM1369 X2 (H-7): AN EXTENSION'S CAPABILITIES ARE NOT HERE. Each is
    # described by its extension's `hooks.capability_info` and reaches this map
    # from the site's extension index (declare_capability, below), with its
    # api and mcp unlocks derived from the gate rows that name it.
    # SM1354 (ruling 155): AN AGENT PUTS ITS OWN COPY OF A PAGE OVER THE PAGE only
    # where the site said it may. Taking, changing and discarding a copy is
    # manage_content's; a person in the manager publishes with manage_content as
    # they save today; over MCP and the control API a publish needs this as well.
    # Off by default and held by no shipped role: no seed or top-up grants it
    # (Auth::Settings @OFF_BY_DEFAULT) - it is offered, and an operator decides.
    publish_copies => {
        section => 'Content',
        title => 'Publish a copy of a page over the page, over MCP or the control API. Taking, '
            . 'changing and discarding a copy needs manage_content; a person in the manager '
            . 'publishes with manage_content. Off by default.',
        grants => 'Put an open copy of a page (copy_page / page-copy) over the page as one recorded '
            . 'version naming who published it and where from - with manage_content and the page\'s '
            . 'own write rule as well. Refused when the page changed after the copy was taken. Undo '
            . 'is restore_version of the version before. No role holds it until an operator grants it.',
        unlocks => {
            api => [qw(page-copy-publish)],
            mcp => [qw(publish_copy)],
        },
    },
    audit => {
        section => 'Insight',
        # SM618: measured on edge 2026-08-26 under a grant holding `analytics`
        # + `audit` and nothing else - 93 pages, six distinct actors, 180 full
        # IPv4 dotted-quads in 192 sampled entries, and origins `ui`, `cli` and
        # `install`, which are the OPERATOR's own sessions rather than partner
        # traffic. The engine states `scoped: false` in the reply itself.
        #
        # The reach is SANCTIONED, on `purge`'s SM577 precedent: an agent asked
        # "what changed here, and who changed it" needs the whole trail, and a
        # redacted one answers less. What was wrong is that `purge` SAYS SO and
        # this did not. It sat beside `analytics` - which promises anonymisation
        # in its own title and keeps that promise - so the pair invited exactly
        # the wrong inference: that the trail read is at least as careful with
        # personal data as the visitor read. It is the opposite, and an operator
        # learned that only by granting it.
        title => 'Read the append-only audit trail. SM618: THE TRAIL IS '
            . 'INSTANCE-WIDE and is NOT scoped by the grant that authorised the '
            . 'read - one instance serves many domains into one trail, so this '
            . 'reaches entries for OTHER sites, and every entry names the actor '
            . 'and carries a RAW source IP, the sysop\'s own manager, '
            . 'command-line and install sessions among them. Sanctioned '
            . 'instance-wide for the same reason as `purge`. Its sibling '
            . '`analytics` is the sanitised, anonymised read; this one is '
            . 'neither, and the two sit together deliberately.',
        grants => 'Read the WHOLE INSTANCE\'s audit trail - every action, the account behind it, and the raw source IP it came from, including your own manager, command-line and install sessions. It is not scoped to one site.',
        unlocks => { api => [qw(audit)] },
    },
    notifications => {
        section => 'Insight',
        title => 'See sysop notifications (the manager bell: new form submissions, requests awaiting a response).',
        grants => 'See the sysop bell - new submissions and requests awaiting an answer. It names the form and the time, never the content.',
        # SM281 item 3: it unlocked a manager page and nothing else - a
        # capability with no remote surface, which is an SM239 parity gap and
        # the reason remote agents had been editing a shared briefing document
        # to talk to each other. `notices` is READ; emission stays SM231's.
        # SM918: and the MCP twin, so this capability now has a remote surface on
        # BOTH channels rather than one. The ruling was full parity with the
        # capability as the gate, not the channel, and it is literally the same
        # reader behind each door (Lazysite::Manager::Notices).
        #
        # `notices-seen` is on neither remote list on purpose: the seen-marker is
        # a per-principal read cursor for a human's unread badge, and a cursor
        # per partner is where a bell turns into an inbox.
        unlocks => {
            ui  => ['the notifications bell + unread badge in the manager header'],
            api => ['notices'],
            mcp => ['read_notices'],
        },
    },
    feedback => {
        section => 'Insight',
        title => 'Submit agent feedback over MCP. Off by default: the operator opts a group in so an agent may write to lazysite/feedback/ and notify the operator.',
        grants => 'Write files into lazysite/feedback/ and raise an operator notification. Off unless an operator opts the group in.',
        unlocks => { mcp => [qw(submit_feedback)] },
    },
    read_submissions => {
        # SM758 follow-up (133E-03): an operator hunting for who may READ what
        # visitors sent looks under Insight, not Content - the field said so.
        section => 'Insight',
        title => 'Read form submissions over the API/MCP. A least-privilege, read-only grant for an agent that processes form leads - it does NOT include managing form configs (that is manage_forms). Off by default.',
        grants => 'Read what visitors have submitted through forms - whatever each form collects, with the submitter\'s IP address. Read-only: it cannot change where submissions go.',
        unlocks => { api => [qw(form-submissions form-submission form-list)], mcp => [qw(read_form_submissions read_form_submission form_list)] },
    },
    # SM924: DELETING A SUBMISSION, as a grant of its own.
    #
    # A partner account could READ submissions (read_submissions) and delete none of
    # them: submission delete was interactive-only, so the test rows an agent's own
    # work left behind could only be cleared by a person in the manager. SM214 held
    # it back deliberately and the reason stands for the DEFAULT; what was missing
    # was any way to say yes.
    #
    # THE NAME IS THE RULING. The filing's own recommendation was "delete rows the
    # caller created", and that was measured FALSE before it could be recorded: a
    # stored submission carries no actor at all (form-handler.pl records a public
    # submission as having none, deliberately - a forged `_auth_user` had been
    # reaching the audit trail's actor column), and `_ip` is the front proxy's
    # address on every row of every site behind it (SM929). So there is no
    # provenance to key on, and this capability permits deleting ANY submission on
    # the site. It is named and described for that, because an operator who grants
    # it on the softer reading has granted the harder thing.
    #
    # OFF BY DEFAULT: it appears in no seeded group, so a site that upgrades grants
    # it to nobody and the interactive path is unchanged.
    delete_submissions => {
        section => 'Insight',
        title => 'Delete ANY form submission on this site, over the API/MCP. Not "delete '
            . 'your own" - a stored submission records no author, so this cannot be '
            . 'narrowed to the rows a caller created. Off by default.',
        grants => 'Delete any stored submission on this site, one at a time or in bulk. A '
            . 'submission is often the only copy of what a visitor sent, and nothing on the '
            . 'row says who submitted it, so this grant cannot be confined to an agent\'s '
            . 'own test data: it is the authority to remove anybody\'s. Pair it with '
            . 'read_submissions for an agent that clears up after itself, and withhold it '
            . 'from one that only reads.',
        unlocks => {
            api => [qw(form-submission-delete form-submissions-delete-bulk)],
            mcp => [],
        },
    },
    # SM979 (ruled 2026-10-11, "New approve capability"): APPROVING AN ACCOUNT
    # REQUEST IS A GRANT OF ITS OWN. It needed manage_users with read_submissions,
    # and manage_users is the operator: a group made to approve registrations
    # held the whole manager. This reaches exactly what approving reads - the
    # rows of a form that declares `account_email:`, which are the requests -
    # and the one verb that turns such a row into an account. Not the Users
    # API's account-approve, which takes a name of the caller's choosing rather
    # than a request somebody sent. Manager UI only, off by default.
    approve_accounts => {
        section => 'Accounts',
        title => 'Approve account requests: read the submissions of a form that declares '
            . 'account_email, and approve one into an account.',
        grants => 'See the rows of the forms that request accounts (a form whose conf declares '
            . 'account_email) and press Approve on one, which creates the account from the '
            . 'address on that row, in the registration groups the site flags, with a setup '
            . 'link. It reads no other form\'s submissions, creates no account it was not asked '
            . 'for, and manages no account or group. Manager UI only: no remote surface offers it.',
        unlocks => { ui => [ 'Approve (an account) on a submission whose form declares account_email',
                'the Submissions page, showing only the forms that declare account_email' ] },
    },
    create_sub_users => {
        section => 'Accounts',
        title   => 'Create sub-accounts under your own account.',
        grants => 'Create accounts beneath this one. A sub-account cannot be given capabilities its creator does not hold, or reach further than its creator reaches.',
        unlocks => { ui => ['sub-user creation'] },
    },
    delegate_sub_user_creation => {
        section => 'Accounts',
        title   => 'Grant sub-accounts the ability to create their own sub-users.',
        grants => 'Let the accounts this group creates make sub-accounts of their own, so delegation continues one level further without a sysop.',
        unlocks => { ui => ['onward delegation of sub-user creation'] },
    },
);

# SM197: the per-action channel SURFACE - which channels a capability actually
# exposes something on, derived from the keys of its `unlocks` map. The manager's
# permission grid consults this so a capability x channel cell is ticked only
# where the capability has a REAL surface on that channel (e.g. manage_domains on
# api+mcp, not webdav), rather than merely "granted AND channel held". Same single
# source of truth as describe(); a new capability's surface appears automatically.
sub action_channel_surface {
    my %surface;
    for my $cap ( action_keys() ) {
        my $u = $ACTION_INFO{$cap}{unlocks} || {};
        $surface{$cap} = { map { $_ => 1 } grep { @{ $u->{$_} || [] } } keys %{$u} };
    }
    return \%surface;
}

# Engine-owned paths: protected surface an agent must NOT try to write (the DAV
# blocklist / whole-lazysite denial already enforce this - this list makes the
# boundary legible so an agent uses the API instead of hunting for a workaround).
my @ENGINE_OWNED = (
    'lazysite/auth/**  (credentials, tokens, TOTP seeds, HMAC secret)',
    'lazysite/cache/** (generated HTML cache)',
    'lazysite/forms/smtp.conf, lazysite/forms/handlers.conf (delivery secrets)',
    'lazysite/manager/** (manager UI internals)',
    'cgi-bin/**, *.pl   (the engine scripts)',
);

# Task recipes: the sanctioned sequence for common jobs, machine-readable so an
# agent can plan without prose. The human quickstarts (Phase B) are the twins.
my @TASKS = (
    { id => 'install-theme', title => 'Install and activate a theme',
        requires => ['manage_themes'],
        steps    => [
            'PUT the theme files under lazysite/layouts/<layout>/themes/<name>/ over WebDAV (or use the MCP write_file tool on those paths)',
            'call activate_theme (MCP) or POST action=theme-activate (control API)',
        ],
    },
    { id => 'author-layout', title => 'Author and activate a layout',
        requires => ['manage_layouts'],
        steps    => [
            'PUT layout files (layout.tt, layout.json, components) under lazysite/layouts/<name>/ over WebDAV',
            'call activate_layout (MCP) or POST action=layout-activate (control API)',
        ],
    },
    { id => 'switch-layout', title => 'Switch the site to a different layout',
        requires => ['manage_layouts'],
        steps    => [
            'call list_layout_catalogue (MCP) or GET action=layouts-manifest (control API) to see what is available and installed',
            # SM348: this said "it installs AND activates the new layout in one
            # step". SM314 corrected the TOOL to say installing does not
            # activate, and left this - so the document an agent reads FIRST
            # contradicted the tool it was describing, and an agent following
            # this sequence would install a layout, believe the site had
            # switched, and find it unchanged.
            #
            # Two steps now, because it is two operations. SM176's reasoning
            # holds: activating is the part that changes what visitors see, so
            # it is always asked for explicitly.
            'call install_layout (MCP) or POST action=layout-install (control API) - this places the layout on the site and changes NOTHING a visitor sees',
            'call activate_layout (MCP) or POST action=layout-activate (control API) - this is the step that switches the live site. The response says whether the layout renders the site navigation and page body (SM337); a layout that renders no [% nav %] is activated anyway and warns, because a showcase layout is a legitimate choice',
            'ONLY THEN, if the old layout is no longer wanted: delete_layout / layout-delete. Deleting the ACTIVE layout is always refused - install/activate the replacement first, never delete first',
        ],
    },
    { id => 'restore-from-history', title => 'Undo a content change (restore a recorded version)',
        requires => ['manage_content'],
        steps    => [
            'call list_versions (MCP) or GET action=git-history (control API) for the file - needs the site\'s Content history extension enabled',
            'call view_version / git-show to confirm the version (content + diff against the current file)',
            'call restore_version / git-restore - the historic content is saved back through the normal save path and the restore itself becomes the newest version, so nothing is lost',
        ],
    },
    { id => 'publish-page', title => 'Publish a page',
        requires => ['manage_content'],
        steps    => [
            'create the page with the MCP create_page tool, or PUT the .md over WebDAV in the content namespace',
            'optionally preview_page (MCP) to confirm the render before it goes live',
        ],
    },
    { id => 'build-from-figma', title => 'Build or restyle a site from a Figma design',
        requires => [ 'manage_themes', 'manage_layouts', 'manage_content' ],
        steps => [ 'Read /docs/integrations/figma for the extraction + translation sequence',
            'Connect the Figma MCP server alongside the lazysite connection; run whoami on both',
            'Extract tokens/structure/screenshots via the Figma MCP (get_metadata, get_variable_defs, get_screenshot)',
            'Map design tokens onto the layout vocabulary (theme_tokens) and rebuild rhythm/scale in CSS',
            'Adapt the nearest layout (copy-and-stage) or scaffold a theme (create_theme)',
            'Verify with preview_page before activating' ] },
    { id => 'wire-form', title => 'Wire a form to a handler',
        requires => ['manage_forms'],
        steps    => [
            'call list_handlers (MCP) or handler-list (control API) to see the handlers',
            'call bind_form (MCP) or form-targets-save (control API), or PUT lazysite/forms/<name>.conf over WebDAV, naming existing handlers - never a destination',
            'a handler that does not exist yet is made with save_handler / handler-save, and the destination decides the capability: manage_forms for email or file, manage_data for a table, manage_connectors for a connector',
        ],
    },
    { id => 'migrate-site', title => 'Migrate a site (package one domain and apply it elsewhere)',
        requires => ['manage_domains'],
        steps    => [
            'ON THE SOURCE: call site_backup (MCP) or POST action=site-backup-create (control API) with the domain host - this writes a portable package (lazysite-site-<host>-<stamp>.tar.gz) holding that domain\'s content + nav + its theme/layout + a manifest. It excludes extensions, instance settings and secrets, so it is safe to hand over',
            'MOVE THE PACKAGE to the target instance if different: GET action=backup-download to fetch it, then POST action=site-backup-upload (multipart) on the target to import it into that instance\'s backups area. Same-instance moves skip this - the package is already there',
            'BEFORE APPLYING, make sure the target domain exists (register it with domain-add if needed) and, if you want a rollback point, take a backup - apply overwrites the target content root',
            'ON THE TARGET: call site_apply (MCP) or POST action=site-backup-apply (control API) with the package name and the target host (omit host to apply to the default site; pass clean:true to clear the target content first). This copies the content in, installs the bundled theme/layout if the target lacks it, places the nav, and sets the target domain\'s presentation. The control-API action also takes a safety snapshot automatically',
            'verify with a domain preview (domain-preview) or by loading the target host',
        ],
    },
);

# SM225: the documentation index. A partner told to "call this first" learns the
# capability model and nothing about the ~30 documentation pages the site
# publishes, so it reasons from the tool surface alone and reinvents documented
# behaviour (or concludes a feature is absent). The index is DERIVED, not curated:
# a scan of {DOCROOT}/docs reading each page's own `title:` / `subtitle:` front
# matter, so a site that adds or removes a doc reports the truth instead of a
# hard-coded list going stale. Briefings are listed first because an agent should
# read those before designing anything; everything else is reference.
#
# Top-level pages only. Subtrees (docs/features/, docs/integrations/) are reached
# from the pages that cite them, and enumerating them here would bury the entry
# points the index exists to surface.
sub _doc_meta {
    my ($path) = @_;
    open my $fh, '<', $path or return;
    my ( $title, $subtitle );
    my $n = 0;
    while ( my $line = <$fh> ) {
        last if ++$n > 20;
        if ( $line =~ /^title\s*:\s*(.+?)\s*$/ )    { $title    = $1 }
        if ( $line =~ /^subtitle\s*:\s*(.+?)\s*$/ ) { $subtitle = $1 }
        last if defined $title && defined $subtitle;
    }
    close $fh;
    for ( $title, $subtitle ) {
        next unless defined;
        s/\A(["'])(.*)\1\z/$2/;    # front matter may quote the value
    }
    return ( $title, $subtitle );
}

sub _scan_docs {
    my ($docroot) = @_;
    return unless defined $docroot && length $docroot;
    # SM1284: the manual is the engine's (lazysite/templates/docs/), served at
    # /docs/ when the site has no page of its own there - so it is indexed from
    # both, and the site's copy of a page is the one described, as it is the one
    # served. A site that cleared its docs/ still answers with the whole manual.
    my %src;
    for my $dir ( Lazysite::Paths::lazysite_dir($docroot) . '/templates/docs', "$docroot/docs" ) {
        opendir my $dh, $dir or next;
        for my $f ( readdir $dh ) {
            next unless $f =~ /\A([A-Za-z0-9][A-Za-z0-9._-]*)\.md\z/;
            $src{$1} = "$dir/$f" if -f "$dir/$f";    # the docroot's, read last, wins
        }
        closedir $dh;
    }
    return unless %src;
    my ( @briefings, @reference );
    for my $slug ( sort keys %src ) {
        my ( $title, $subtitle ) = _doc_meta( $src{$slug} );
        next unless defined $title && length $title;
        my %entry = ( path => "/docs/$slug", title => $title );
        $entry{answers} = $subtitle if defined $subtitle && length $subtitle;
        push @{ $slug =~ /^ai-briefing-/ ? \@briefings : \@reference }, \%entry;
    }
    return unless @briefings || @reference;
    return {
        note =>
            'The site publishes its own documentation. Read the briefings before '
            . 'designing anything - they answer most questions about what lazysite '
            . 'can do, and a capability you cannot see may be documented rather '
            . 'than absent. Every path below is a public page you can fetch '
            . 'without a credential.',
        briefings => \@briefings,
        reference => \@reference,
    };
}

# SM226: why each entry in `holds` reads the way it does. A false is always the
# same story - the capability exists and was not granted - and saying so is what
# stops a reader treating it as absence. The case worth real explanation is the
# opposite one: a channel capability that IS granted while its site service is
# off, which today renders as a bare true and does nothing. `capabilities` and
# `holds` disagreeing with observable behaviour is exactly the confusion this
# block exists to remove. Needs a docroot to read the killswitches; without one
# the dormancy answer is simply omitted rather than guessed.
# SM740: the declared hierarchy. implied_by($cap) lists the capabilities that
# admit everything $cap unlocks; implications($caps) says, for an account, which
# withheld capabilities are nonetheless satisfied and by what - so whoami can
# print a false that does not read as a withholding.
sub implied_by {
    my ($cap) = @_;
    my $i = ( $ACTION_INFO{$cap} || {} )->{implied_by} || [];
    return @$i;
}

# SM1369 X2 (H-7): A CAPABILITY AN EXTENSION DECLARES. The index build
# validated the info (Lazysite::Extensions::Hooks); the mirror hands it here
# with the api and mcp unlocks derived. A core name is refused (the build
# refused it first; this is the second wall), and so is a name another
# extension holds. Returns the problems, as sentences.
my %DECLARED_INFO;    # capability => the extension id

sub declare_capability {
    my ( $id, $cap, $info ) = @_;
    return ("'$cap' is not a capability name") unless defined $cap && $cap =~ /\A[a-z][a-z0-9_]*\z/;
    return ("'$cap' is a core capability") if exists $ACTION_INFO{$cap} && !exists $DECLARED_INFO{$cap};
    return ("'$cap' is already declared by $DECLARED_INFO{$cap}")
        if exists $DECLARED_INFO{$cap} && $DECLARED_INFO{$cap} ne $id;
    return ("'$cap' is described without a section") unless ref $info eq 'HASH' && defined $info->{section};
    $ACTION_INFO{$cap}   = { %{$info}, extension => $id };
    $DECLARED_INFO{$cap} = $id;
    return ();
}

sub undeclare_capabilities {
    delete $ACTION_INFO{$_} for keys %DECLARED_INFO;
    %DECLARED_INFO = ();
    return;
}

# The extension that declared a capability, or undef for a core one.
sub capability_extension { return $DECLARED_INFO{ $_[0] // '' } }

# The grid's short name for a declared capability (a core one's label is the
# page's own; see t/lint/19).
sub label {
    my ($cap) = @_;
    return ( $ACTION_INFO{$cap} || {} )->{label};
}

# Ruling 71 (D-6): the capabilities a group holding any of which is topped up
# with this one on next use, so nothing changes for a group when a capability
# moves out of a core one and into an extension's own (manage_odoo from
# manage_connectors). Empty for a core capability.
sub top_up_from {
    my ($cap) = @_;
    my $t = ( $ACTION_INFO{$cap} || {} )->{top_up_from} || [];
    return @$t;
}

# SM821: WHAT AN ACCOUNT MAY DO, AND WHAT IT IS - APART, AND THE SAME ON EVERY
# SURFACE. Takes the account's resolved settings (Lazysite::Auth::Verify::
# effective_settings - what both whoamis start from) and returns
# ( capabilities => {...}, account => {...} ).
#
# `capabilities` is exactly @CAP_KEYS, as booleans. `ui` among them is the
# CAPABILITY - manager access granted by a group - which the settings map calls
# `manager_ui`, because its own `ui` is a different thing: whether the account
# may sign in interactively. The two sat side by side under one name each, with
# opposite values on an ordinary partner account, and read as a contradiction.
# That setting is `account.interactive_login` here.
#
# `account` is everything else the map carries - the record, not the grant:
# groups, email, provenance, token and MFA state, scopes. MCP returned all of it
# under `capabilities` and the control API returned none of it, so an agent that
# changed surface saw a different shape for the same account.
sub whoami_grant {
    my ($s) = @_;
    $s ||= {};
    my %is_cap = map { $_ => 1 } @CAP_KEYS;
    my %caps   = map {
        my $held = $_ eq 'ui' ? $s->{manager_ui} : $s->{$_};
        $_ => ( $held ? JSON::PP::true() : JSON::PP::false() )
    } @CAP_KEYS;
    my %account = map { $_ => $s->{$_} }
        grep { !$is_cap{$_} && $_ ne 'manager_ui' } keys %$s;
    $account{interactive_login} = ( exists $s->{ui} && !$s->{ui} ) ? JSON::PP::false() : JSON::PP::true();
    return ( capabilities => \%caps, account => \%account );
}

# SM1370 (ruling 121) and SM1371 (ruling 122): the two blocks both whoamis add,
# from one builder so the doors cannot disagree (SM288).
#
# `grant` says where this credential's capabilities come from: the account's
# groups, resolved at each request, so a grant made or taken away at the account
# reaches the token on its next request with no new pairing key. A client that
# lists tools once when it connects keeps its old list until it lists again;
# the note says so, because that is what an agent sees as "my grant did not
# arrive".
#
# `roles` is Lazysite::Auth::Settings::role_summary over the same settings the
# `capabilities` block reports: the roles held, and what is held beyond them.
sub whoami_roles {
    my ( $user, $s ) = @_;
    $s ||= {};
    my %held = map { $_ => ( $_ eq 'ui' ? $s->{manager_ui} : $s->{$_} ) ? 1 : 0 } @CAP_KEYS;
    my $r    = Lazysite::Auth::Settings::role_summary( $user, \%held );
    return (
        grant => {
            source => 'account',
            note => 'Capabilities are resolved from your account\'s groups at each request. '
                . 'A grant added or removed at the account applies from your next request; '
                . 'no new pairing key or token is needed. If a tool you have just been '
                . 'granted is missing, your client is showing the tool list it fetched '
                . 'when it connected: list tools again (or reconnect the connector).',
        },
        roles => $r,
    );
}

sub implications {
    my ($caps) = @_;
    $caps ||= {};
    my %out;
    for my $k (@CAP_KEYS) {
        next if $caps->{$k};
        my ($by) = grep { $caps->{$_} } implied_by($k);
        next unless defined $by;
        $out{$k} = {
            satisfied_by => $by,
            note => "$k is false above because it was not granted directly; $by is "
                . "held and admits everything $k unlocks, so this account can do all of "
                . "it. Withholding $k here changes nothing.",
        };
    }
    return \%out;
}

# SM758: the CATEGORY each action is shown under, and the order of the
# categories. Twenty-two actions in registry order were a list to be read
# end to end; a grid drawn by category, alphabetised within, is a short
# sorted list in the one place a reader looks. Here beside the title and the
# grant sentence for the reason those are here: the Groups page, the Users
# page and anything else that draws the actions must say the same thing, and
# a copy in JavaScript would drift from this the moment either changed.
# sections() lists every action once, under the section it declares, in
# @CAP_KEYS order (the pages sort by label); t/lint/19 holds that every action
# declares one of @SECTIONS.
our @SECTIONS = qw(Content Appearance Data Site Accounts Operations Insight);

sub section {
    my ($cap) = @_;
    return ( $ACTION_INFO{$cap} || {} )->{section};
}

sub sections {
    my %by;
    push @{ $by{ section($_) // 'Other' } }, $_ for action_keys();
    return [ map { [ $_, $by{$_} ] } grep { $by{$_} } @SECTIONS, 'Other' ];
}

sub _holds_why {
    my ( $caps, $docroot ) = @_;
    my %why;
    for my $k (@CAP_KEYS) {
        if ( !$caps->{$k} ) {
            my ($by) = grep { $caps->{$_} } implied_by($k);
            $why{$k} = defined $by
                ? "not granted directly, but SATISFIED by $by, which admits everything "
                . "$k unlocks - withholding $k from this account changes nothing (SM740)."
                : 'not granted to this account. The capability exists in '
                . 'lazysite - ask the sysop to grant it.';
            next;
        }
        next unless $IS_CHANNEL{$k};
        my $svc = $CHANNEL_SERVICE{$k};
        next unless defined $svc;
        next unless defined $docroot && length $docroot;
        next if Lazysite::Util::service_enabled( $docroot, $svc );
        $why{$k} = "granted, but DORMANT: this site's `$svc` service is off, so "
            . 'the channel refuses regardless of the grant. Ask the operator to '
            . 'enable the service.';
    }
    return \%why;
}

# Build the map. Pass caps => { cap => 0|1 } (the caller's resolved grant) and,
# optionally, groups => [...] and account => "name" to include the "holds" block;
# docroot => "..." adds the SM225 documentation index. Omit caps for the static
# model only (e.g. the generated doc).
# SM491: WHICH OF THIS GRANT'S CHANNELS CAN ACTUALLY REACH EACH CAPABILITY.
#
# A capability is a permission; a channel is a door. An account can hold a
# capability whose every door is shut on a different switch - analytics:true
# with mcp:false was the field case - and whoami reported a bare `true`,
# which is not operationally true. The sysop saw the grant applied, the
# agent saw the capability held, and neither could use it.
#
# Derived from the `unlocks` map rather than declared, so a capability that
# gains or loses a surface changes this answer without anybody remembering to.
# Returns, per capability the account holds, the channels it is reachable on
# and the channels that would unlock it but are off for this grant.
sub reachability {
    my ($settings) = @_;
    my %out;
    for my $cap (@CAP_KEYS) {
        next unless $settings->{$cap};
        my $u = ( $ACTION_INFO{$cap} || {} )->{unlocks} || {};
        my ( @via, @shut );
        for my $ch (qw(api mcp)) {
            next unless ref $u->{$ch} eq 'ARRAY' && @{ $u->{$ch} };

            if   ( $settings->{$ch} ) { push @via,  $ch }
            else                      { push @shut, $ch }
        }
        # `ui` is the manager itself; webdav carries no capability-gated
        # actions of its own. A capability with NO api/mcp surface is a
        # manager-page capability and reachability is not the question.
        next unless @via || @shut;
        $out{$cap} = { via => \@via, ( @shut ? ( requires => \@shut ) : () ) };
    }
    return \%out;
}

# SM564: a group is judged by its REACH, not its record. Given a capability
# set as the resolver returns it ({ cap => 0|1 }), the effective callable set
# per channel, derived from the same `unlocks` tables describe() publishes:
#
#   { api => { held => 0|1, unlocked => [...], callable => [...] }, ... }
#
# `unlocked` is what the ACTION capabilities held would expose on that
# channel; `callable` is that list when the channel itself is held, and empty
# when it is not. Two rules fall out of the tables rather than being declared
# here: a channel flag alone unlocks nothing (SM570 - a door is not an
# authority), and an action capability without its door reaches nothing.
# SM570 is also why this exists: an account's declared capabilities and what
# it can actually call were found to be different things.
sub reach_for {
    my ($caps) = @_;
    $caps ||= {};
    my %out;
    for my $ch (@CHANNELS) {
        my ( %seen, @unlocked );
        for my $cap ( action_keys() ) {
            next unless $caps->{$cap};
            my $u = ( $ACTION_INFO{$cap} || {} )->{unlocks} || {};
            push @unlocked, grep { !$seen{$_}++ } @{ $u->{$ch} || [] };
        }
        my $held = $caps->{$ch} ? 1 : 0;
        $out{$ch} = {
            held     => $held,
            unlocked => \@unlocked,
            callable => [ $held ? @unlocked : () ],
        };
    }
    return \%out;
}

# SM979: WHAT THE CAPABILITY TABLE DOES NOT SAY, said beside it.
#
# The report above reads the `unlocks` tables, and two reaches are not in them:
#
#   * the OPERATOR passes every capability gate on the manager's cookie channel
#     (lazysite-manager-api.pl, the `!_operator()` block), so its reach on `ui`
#     is every manager action. Until SM991 that was any manage_users holder, and
#     a report that said "2 callable" for it understated it by the whole
#     manager; since SM991 it is the operator group's members, and manage_users
#     is what its table entry says.
#   * FILES are decided by each path's access rule, never by a capability: the
#     manager's file actions (save, move, copy, mkdir, delete, upload) take no
#     capability, and the rule of the path decides. The report said "0 callable"
#     for a group that, before SM979, could write every file on the site.
#
# So for a group with a door to the files (ui or webdav) this lists the rules
# that name it - directly or through a group it is nested in - and says what
# happens where no rule governs. It reads the store; it decides nothing. The
# users tool prints what this returns (it is compiled on every credential
# check, so the work lives here, loaded only when group-reach asks).
sub group_reach_notes {
    my ( $docroot, $g, $caps ) = @_;
    my @out;
    # SM991 (ruled 2026-10-12, "Operators bypass, others bound"): the OPERATOR
    # is a member of the operator group (the `manager` flag setup-sysop puts on
    # the group it makes), not a holder of manage_users. Said for the group that
    # is one, and for manage_users what it is now - and the operator groups are
    # named either way, so a reader of one group's reach knows where the
    # operator is.
    my $is_op = Lazysite::Auth::Settings::groups_are_operator($g);
    my @ops   = Lazysite::Auth::Settings::operator_groups();
    if ($is_op) {
        push @out, "   operator: this group is the OPERATOR group - its members pass EVERY capability gate on\n"
            . "             the manager (ui) channel and every file rule there. Tokens never count.\n";
    }
    elsif ( $caps->{manage_users} ) {
        push @out, "   manage_users: user and group management only - the Users and Groups pages and account\n"
            . "             approval. It passes no other gate, and file rules apply to it. It is not\n"
            . "             the operator.\n";
    }
    push @out, '   operator group' . ( @ops == 1 ? '' : 's' ) . ': '
        . ( @ops ? join( ', ', @ops ) : '(none - on a secured site only `local` passes every gate)' ) . "\n"
        if $is_op || $caps->{manage_users} || $caps->{ui};
    return @out unless $caps->{ui} || $caps->{webdav};

    require Lazysite::Auth::Acl;
    my $acls = eval {
        no warnings 'once';
        local $Lazysite::Auth::Acl::DOCROOT = $docroot;
        Lazysite::Auth::Acl::load_acls();
    } || {};
    my %as = map { lc $_ => 1 } Lazysite::Auth::Settings::group_closure($g);
    my ( %by_mode, $root_write );
    for my $k ( sort keys %$acls ) {
        my $e = $acls->{$k};
        next unless ref $e eq 'HASH';
        my $label = ( $k eq '/' || $k eq '' || $k eq '.' ) ? '/ (site-wide)' : $k;
        for my $mode (qw(write read)) {
            my $list = $e->{$mode};
            next unless ref $list eq 'ARRAY' && @$list;
            $root_write = 1 if $mode eq 'write' && $label eq '/ (site-wide)';
            next unless grep { defined && /\A\@(.+)\z/ && $as{ lc $1 } } @$list;
            push @{ $by_mode{$mode} }, $label;
        }
    }
    push @out, "   files   by rule - a path's access rule decides, never a capability:\n";
    for my $mode (qw(write read)) {
        my @p = @{ $by_mode{$mode} || [] };
        push @out, sprintf "           %-5s named in %d rule%s%s\n", $mode, scalar @p, ( @p == 1 ? '' : 's' ),
            ( @p ? ': ' . join( ', ', @p ) : '' );
    }
    push @out, "           a path no write rule governs is writable by any account that reaches the\n"
        . "           file actions" . ( $root_write ? ' (a site-wide write rule governs every path here)' : '' ) . "\n";
    return @out;
}

sub describe {
    my (%opt) = @_;
    my $T     = JSON::PP::true();
    my $F     = JSON::PP::false();

    my %channels;
    $channels{$_} = { enforced => $T, note => $CHANNEL_INFO{$_},
        service => $CHANNEL_SERVICE{$_} } for @CHANNELS;

    my %capabilities;
    for my $a ( action_keys() ) {
        my $info = $ACTION_INFO{$a} || { title => $a, unlocks => {} };
        # SM427: `grants` is the plain-sentence answer to "what am I handing
        # over?" - carried beside the title so the Groups page, describe_
        # capabilities and the generated capability map all get the same
        # words. A second copy written for the UI alone would be the shape of
        # defect this project keeps filing.
        my @imp = @{ $info->{implied_by} || [] };
        $capabilities{$a} = {
            title  => $info->{title},
            grants => ( $info->{grants} // '' )
                . ( @imp
                ? ' IMPLIED BY ' . join( ' / ', @imp ) . ': an account holding '
                    . ( @imp > 1 ? 'any of those' : $imp[0] )
                    . ' may already do everything this unlocks, so withholding this from '
                    . 'such an account changes nothing. Grant THIS, alone, for the lower level of privilege.'
                : '' ),
            unlocks => $info->{unlocks},
            ( @imp ? ( implied_by => \@imp ) : () ),
            # SM1369 X2: a declared capability says whose it is, and the grids'
            # short name for it.
            ( defined $info->{extension}
                ? ( extension => $info->{extension}, label => $info->{label},
                    ( @{ $info->{top_up_from} || [] } ? ( top_up_from => [ @{ $info->{top_up_from} } ] ) : () ) )
                : () ),
        };
    }

    my %map = (
        channels     => \%channels,
        capabilities => \%capabilities,
        tasks        => \@TASKS,
        engine_owned => \@ENGINE_OWNED,
    );

    if ( my $docs = _scan_docs( $opt{docroot} ) ) { $map{docs} = $docs }

    if ( $opt{caps} ) {
        my $caps = $opt{caps};
        # SM226: `capabilities` above is what lazysite OFFERS; `holds` is what THIS
        # account was GRANTED. Readers flatten the two and read a false as absence -
        # a partner tabulated read_submissions:false, concluded submissions could not
        # be read at all, and specified a replacement store. The scope line is prose
        # in the payload deliberately: the consumer is a language model and the
        # misreading is a language misreading.
        $map{holds} = {
            ( defined $opt{account} ? ( account => $opt{account} ) : () ),
            # SM779: the account's display name beside its login - a partner
            # rendering bylines had no route from a login to a name, not even
            # its own.
            ( defined $opt{display_name} && length $opt{display_name}
                ? ( display_name => $opt{display_name} ) : () ),
            ( $opt{groups} ? ( groups => $opt{groups} ) : () ),
            scope =>
                'What THIS account has been granted. A false value means "not '
                . 'granted to this account", never "not available in lazysite" - see '
                . '"capabilities" for what the platform offers, and ask the sysop '
                . 'for a grant. See "why" for the reason each false is false.',
            capabilities => { map { $_ => ( $caps->{$_} ? $T : $F ) } @CAP_KEYS },
            why          => _holds_why( $caps, $opt{docroot} ),

            # SM740: the pairs where a false above is not a withholding.
            implied => implications($caps),
        };
    }

    return \%map;
}

1;
