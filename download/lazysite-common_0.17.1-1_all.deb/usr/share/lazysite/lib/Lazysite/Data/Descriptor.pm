package Lazysite::Data::Descriptor;

# SM447: field descriptors - load, validate, REJECT.
#
# The data layer's central claim is that an agent can persist and recall data
# without seeing SQL, and that typing is strict BECAUSE agents do the work.
# Everything downstream - the generated DDL, the bound-parameter DML, the
# migration diff, the form generation - reads its identifiers and its types
# from here. So this file is the boundary, and it has two jobs that must not
# be confused:
#
#   1. TYPING. A mistyped datum is corruption, not a cosmetic fault. This
#      deliberately inverts the theme layer's warn-only philosophy: a missing
#      theme token falls back gracefully; a wrong type does not.
#
#   2. IDENTIFIER SAFETY. Values reach SQL only as bound parameters, but
#      identifiers - table and column names - CANNOT be bound. They are
#      interpolated into generated statements. So the only thing standing
#      between a descriptor and an injected identifier is this validation,
#      and it runs at LOAD, once, rather than at query time, repeatedly.
#      Rejecting here means nothing downstream has to remember to escape.
#
# Errors follow the connector convention so an agent can act on them without
# parsing prose: { ok => 0, kind => 'descriptor'|'validation', error, field,
# rule }. `descriptor` faults are in the FILE; `validation` faults are in a
# VALUE offered against a loaded descriptor.
#
# YAML (pure Perl) rather than YAML::XS: the SBOM posture prefers a declared
# dependency without a compiled one, and descriptors are read once and cached,
# so parse speed decides nothing here.

use strict;
use warnings;
use Exporter qw(import);
use Lazysite::Data::Owned qw(reserved_column is_owned);

our @EXPORT_OK = qw(load_descriptor TYPES);

# The v1 type set, kept deliberately tight - extended later only with cause.
# A type is present here or it is rejected; there is no permissive default,
# because a default is how an unknown type becomes a silent text column.
my %TYPE = map { $_ => 1 } qw(text integer decimal boolean date datetime enum);

# The list, not `return sort ...` - perlcritic severity 5, and it is right:
# `return sort` behaves differently in scalar context, so a caller writing
# `my $n = TYPES()` gets something undefined rather than a count.
sub TYPES {
    my @types = sort keys %TYPE;
    return @types;
}

# Identifiers: [a-z][a-z0-9_]* and nothing else.
#
# Not a style rule. These are interpolated into generated SQL because SQL
# cannot bind an identifier, so this pattern is the whole defence. It is
# deliberately narrower than any engine would accept - no quotes, no dots, no
# spaces, no capitals, no leading digit - so that a name which passes here
# needs no quoting or escaping in any dialect we generate for.
my $IDENT = qr/\A[a-z][a-z0-9_]*\z/;

# Reserved because the extension owns them: `timestamps: true` creates them, and
# a descriptor declaring its own would collide with the ones we maintain. The
# names live in Data::Owned, which is also where the per-table question ("does
# this table have them?") is answered - a different question from this one, and
# the header there says why they must not be confused.


sub _err {
    my ( $kind, $error, %extra ) = @_;
    return { ok => 0, kind => $kind, error => $error, %extra };
}

sub _bad_ident {
    my ($name) = @_;
    return 'a name is required' unless defined $name && length $name;
    return "'$name' must be lower-case letters, digits and underscores, "
        . 'starting with a letter'
        unless $name =~ $IDENT;
    return undef;
}

# SM519: NO MEANS NO. YAML::PP implements YAML 1.2, where `no`, `No`, `off`,
# `yes` and `on` are plain STRINGS - only `true`/`false` are booleans - and a
# flag tested with Perl truth reads `public: no` as public. That exposed rows
# to anonymous visitors, refused writes under `required: no`, and built an
# index under `unique: off`. So every boolean the descriptor reads comes
# through here, and the answer is 1, 0, or a refusal - never a guess.
#
# yes/no/on/off are honoured rather than refused: they are the natural
# spelling of the thing, and refusing them would be the surprising
# alternative. Case does not matter. A JSON::PP boolean (a descriptor that
# arrived through the API rather than a YAML file) is a boolean. Absent is
# false, because every flag here defaults closed. Anything else is refused
# with the message this file already promised.
#
# Returns ( value, undef ) or ( undef, 'must be true or false' ).
my %TRUE = map { $_ => 1 } qw(1 true yes on);

# SM586: the EMPTY STRING is false, because that is what YAML::PP hands back
# for a bare `false` - a defined, zero-length scalar. SM519 tested definedness
# and then membership, so the one spelling meaning "not public" matched
# neither set and was refused while `'false'`, `0` and `true` all passed. The
# key that says a table is private is the key that must never be fussy.
my %FALSE = map { $_ => 1 } ( qw(0 false no off), '' );

sub _bool {
    my ($v) = @_;
    return ( 0, undef ) unless defined $v;
    if ( ref $v ) {
        return ( ( $v ? 1 : 0 ), undef ) if ref $v eq 'JSON::PP::Boolean';
        return ( undef,          'must be true or false' );
    }
    my $word = lc $v;
    $word =~ s/\A\s+|\s+\z//g;
    return ( 1,     undef ) if $TRUE{$word};
    return ( 0,     undef ) if $FALSE{$word};
    return ( undef, 'must be true or false' );
}

# --- field-level descriptor checks -----------------------------------------
#
# Each returns an error string, or undef. Split per type so a new type adds
# one branch rather than editing a conditional nobody can read.
sub _check_field {
    my ( $name, $spec ) = @_;

    return "field '$name': must be a mapping of properties"
        unless ref $spec eq 'HASH';

    my $type = $spec->{type};
    return "field '$name': no type given (one of: " . join( ', ', TYPES() ) . ')'
        unless defined $type && length $type;
    return "field '$name': unknown type '$type' (one of: "
        . join( ', ', TYPES() ) . ')'
        unless $TYPE{$type};

    # F-5: `unique: true` - a field the site guarantees no two rows share,
    # without making it the key. The field agent could not say "slug is
    # unique" while keying on something else, and worked around it by keying
    # on the slug, which changes what a row IS in order to express a
    # constraint about one of its values.
    #
    # Both flags are written back normalised: Schema, Value and SQLite read
    # `$spec->{required}` directly, and they must see the same answer this
    # file gave.
    for my $k (qw(unique required)) {
        next unless exists $spec->{$k};
        my ( $val, $why ) = _bool( $spec->{$k} );
        return "field '$name': $k $why" if $why;
        $spec->{$k} = $val;
    }

    # F-4: WIDGET IS ONLY MEANINGFUL ON TEXT, and until now saying otherwise
    # was silently accepted - the existing check lives inside the `text` branch
    # below, so `widget: textarea` on an integer passed straight through and
    # became an editor hint nothing could honour.
    #
    # The vocabulary is NOT restated here. A second list of allowed widgets
    # would be a second answer to "which widgets exist", and the two would
    # disagree the first time one of them gained a value.
    return "field '$name': widget is only meaningful on a text field, and "
        . "'$name' is $type"
        if defined $spec->{widget} && $type ne 'text';

    if ( $type eq 'enum' ) {
        my $v = $spec->{values};
        return "field '$name': enum needs a values list"
            unless ref $v eq 'ARRAY' && @{$v};
        for my $val ( @{$v} ) {
            return "field '$name': enum values must be simple scalars"
                if ref $val;
            return "field '$name': enum values cannot be empty"
                unless defined $val && length $val;
        }
        my %seen;
        for my $val ( @{$v} ) {
            return "field '$name': duplicate enum value '$val'" if $seen{$val}++;
        }
        if ( defined $spec->{default} ) {
            return "field '$name': default '$spec->{default}' is not one of "
                . 'its enum values'
                unless grep { $_ eq $spec->{default} } @{$v};
        }
    }
    elsif ( $type eq 'decimal' ) {
        # Declared precision, because money must never be a float. Both parts
        # are required: a decimal without them is a float wearing a name.
        for my $k (qw(digits places)) {
            return "field '$name': decimal needs '$k'"
                unless defined $spec->{$k};
            return "field '$name': '$k' must be a non-negative whole number"
                unless $spec->{$k} =~ /\A\d+\z/;
        }
        return "field '$name': places ($spec->{places}) cannot exceed "
            . "digits ($spec->{digits})"
            if $spec->{places} > $spec->{digits};
    }
    elsif ( $type eq 'text' ) {
        if ( defined $spec->{max} ) {
            return "field '$name': max must be a positive whole number"
                unless $spec->{max} =~ /\A\d+\z/ && $spec->{max} > 0;
        }
        if ( defined $spec->{widget} ) {
            return "field '$name': widget must be 'input' or 'textarea'"
                unless $spec->{widget} =~ /\A(?:input|textarea)\z/;
        }
    }
    elsif ( $type eq 'integer' ) {
        for my $k (qw(min max)) {
            next unless defined $spec->{$k};
            return "field '$name': $k must be a whole number"
                unless $spec->{$k} =~ /\A-?\d+\z/;
        }
        return "field '$name': min cannot exceed max"
            if defined $spec->{min}
            && defined $spec->{max}
            && $spec->{min} > $spec->{max};
    }

    # `values` on a non-enum is almost certainly a mistake rather than
    # harmless surplus - it reads as a constraint and enforces nothing.
    return "field '$name': 'values' only applies to enum"
        if $type ne 'enum' && defined $spec->{values};

    return undef;
}

# --- whole-descriptor checks ------------------------------------------------
#
# DA-17: load_descriptor was one 135-line ladder of four unrelated checks, and
# a reader had to hold all of them to follow any one. Each is its own sub now.
#
# WHY THESE RETURN A FORMED ERROR rather than a message the way _check_field
# does: a field-level refusal always carries `rule => 'type'`, so its caller
# can add that one key for all of them. These four carry `field` and `rule`
# keys that DIFFER per branch - 'key', 'index', 'order', 'writable_by', and
# `field` present or absent - and those keys are read by the surfaces that
# report the refusal. A bare message would lose them.
#
# Each returns ( <the value it validated>, undef ) or ( undef, $err ).

# The key: 'id' means an auto integer the extension owns and no field may
# shadow. Anything else must name a declared field.
sub _check_key {
    my ( $name, $raw, $fields ) = @_;
    my $key = defined $raw->{key} ? $raw->{key} : 'id';
    if ( my $why = _bad_ident($key) ) {
        return ( undef,
            _err( 'descriptor', "table '$name': key: $why", rule => 'key' ) );
    }
    if ( $key eq 'id' ) {
        return ( undef,
            _err( 'descriptor',
                "table '$name': 'id' is the automatic key and cannot also be a field",
                field => 'id', rule => 'key' ) )
            if $fields->{id};
    }
    else {
        return ( undef,
            _err( 'descriptor',
                "table '$name': key '$key' is not one of its fields",
                field => $key, rule => 'key' ) )
            unless $fields->{$key};

        # A natural key carries required+unique by implication, and saying so
        # here means the DDL generator does not have to infer it.
        return ( undef,
            _err( 'descriptor', "table '$name': key '$key' must be type text",
                field => $key, rule => 'key' ) )
            unless ( $fields->{$key}{type} // '' ) eq 'text';
    }
    return ( $key, undef );
}

# Indexes name declared fields, in order.
sub _check_indexes {
    my ( $name, $raw, $fields, $key ) = @_;
    my $indexes = $raw->{indexes} // [];
    return ( undef,
        _err( 'descriptor', "table '$name': indexes must be a list" ) )
        unless ref $indexes eq 'ARRAY';
    for my $ix ( @{$indexes} ) {
        return ( undef,
            _err( 'descriptor',
                "table '$name': each index must be a list of field names",
                rule => 'index' ) )
            unless ref $ix eq 'ARRAY' && @{$ix};
        for my $f ( @{$ix} ) {
            next if $fields->{$f};
            next if $key ne 'id' && $f eq $key;
            return ( undef,
                _err( 'descriptor',
                    "table '$name': index names '$f', which is not a field",
                    field => $f, rule => 'index' ) );
        }
    }
    return ( $indexes, undef );
}

# F-1: THE ORDER THE SITE MEANS. A gallery is an ordered list - somebody
# chose the sequence - and without this a bare `db:gallery` returns rows in
# whatever order the store hands back, which is insertion order until it is
# not. Saying it once in the descriptor beats repeating `order=` in every
# binding and getting it wrong in one of them.
#
# `-field` is descending, the same spelling the query grammar uses.
#
# Returns ( $field, $dir, undef ) - $field undef when none was declared.
# $flags is the part of the descriptor being built that decides which columns the
# extension owns - a hash shaped like a loaded descriptor so is_owned can read it.
# It used to be the `timestamps` boolean alone, which meant this sub had to know
# that the owned set IS the stamp set. That was true and is not a rule.
sub _check_default_order {
    my ( $name, $raw, $fields, $key, $flags ) = @_;
    my $dord = $raw->{default_order};
    my ( $do_field, $do_dir ) = ( undef, 'asc' );
    return ( $do_field, $do_dir, undef ) unless defined $dord && length $dord;

    return ( undef, undef,
        _err( 'descriptor', "table '$name': default_order must be a "
                . 'field name, optionally prefixed with -', rule => 'order' ) )
        if ref $dord;
    ( $do_field = $dord ) =~ s/\A-// and $do_dir = 'desc';
    return ( undef, undef,
        _err( 'descriptor',
            "table '$name': default_order names '$do_field', which is not one "
                . 'of its fields',
            field => $do_field, rule => 'order' ) )
        unless $fields->{$do_field}
        || $do_field eq $key
        || is_owned( $flags, $do_field );
    return ( $do_field, $do_dir, undef );
}

# SM677: is row auditing switched OFF for this table?
#
# Only an explicit off counts. A typo, a missing key, a `true`, a number - all
# leave the table AUDITED, because the failure this must not have is a
# descriptor that silently stops recording who changed what. Defaulting the
# other way would make a misspelling into a quiet loss of the audit trail.
sub _audit_rows_off {
    my ($raw) = @_;
    my $v = $raw->{audit_rows};
    return 0 unless defined $v;
    return ( lc "$v" eq 'off' || lc "$v" eq 'false' || "$v" eq '0' ) ? 1 : 0;
}

sub _check_writable_by {
    my ( $name, $raw ) = @_;
    my $wb = $raw->{writable_by} // [];
    return ( undef,
        _err( 'descriptor', "table '$name': writable_by must be a list" ) )
        unless ref $wb eq 'ARRAY';
    for my $g ( @{$wb} ) {
        return ( undef,
            _err( 'descriptor',
                "table '$name': writable_by group names must be plain names",
                rule => 'writable_by' ) )
            unless defined $g && !ref $g && $g =~ /\A[A-Za-z0-9_-]+\z/;
    }
    return ( $wb, undef );
}

# SM982 (ruled 2026-10-11, "Table ACLs bind it + row filter"): THE ROWS A
# VISITOR SURFACE MAY SHOW. `public: true` published a table to the last row, so
# rows a moderator had marked hidden or spam were served to an anonymous request
# at the data endpoint, and a site's only alternative was a second, private
# table. `where:` names the rows the page bindings and the data endpoint show:
#
#   where: status = ok        only rows whose status is ok
#   where: status != spam     every row but those marked spam (a row with no
#                             status is shown - it has not been marked)
#
# ONE condition, `field = value` or `field != value`, on a DECLARED field, the
# value read as that field's type would read it in a row (so an enum's value must
# be one of its values, a boolean is yes/no). No expressions, no AND/OR, no other
# operators: this is a filter an author can read at a glance and the engine can
# bind as a parameter, never a query language. The manager, the control API and
# MCP - the surfaces behind manage_data - see every row, which is how a moderator
# finds the hidden ones.
#
# Returns ( { field, op, value } or undef, undef ) or ( undef, $err ).
sub _check_where {
    my ( $name, $raw, $fields ) = @_;
    my $w = $raw->{where};
    return ( undef, undef ) unless defined $w;
    my $shape = "table '$name': where must be one condition, 'field = value' or 'field != value'";
    return ( undef, _err( 'descriptor', $shape, rule => 'where' ) ) if ref $w;
    $w =~ s/\A\s+|\s+\z//g;
    return ( undef, _err( 'descriptor', "$shape - it is empty", rule => 'where' ) ) unless length $w;
    my ( $f, $op, $v ) = $w =~ /\A([A-Za-z_][A-Za-z0-9_]*)\s*(!=|=)\s*(.*?)\z/s
        or return ( undef, _err( 'descriptor', "$shape - '$w' is not", rule => 'where' ) );
    return ( undef,
        _err( 'descriptor', "table '$name': where names '$f', which is not a declared field",
            field => $f, rule => 'where' ) )
        unless exists $fields->{$f};
    $v =~ s/\A"(.*)"\z/$1/s or $v =~ s/\A'(.*)'\z/$1/s;
    return ( undef,
        _err( 'descriptor', "table '$name': where '$w' compares '$f' with nothing - give a value",
            field => $f, rule => 'where' ) )
        unless length $v;
    require Lazysite::Data::Value;
    my ( $why, $cv ) = Lazysite::Data::Value::coerce_field( $f, $fields->{$f}, $v );
    return ( undef,
        _err( 'descriptor', "table '$name': where: $why", field => $f, rule => 'where' ) )
        if defined $why;
    return ( { field => $f, op => $op, value => $cv }, undef );
}

# --- whole-descriptor load --------------------------------------------------
#
# The orchestrator. The ORDER the checks run in is part of the contract - a
# descriptor with two faults is told about the first one, and which one that
# is has to stay the same - so it is: fields, key, indexes, public,
# timestamps, default_order, writable_by.

sub load_descriptor {
    my ( $name, $raw ) = @_;

    if ( my $why = _bad_ident($name) ) {
        return _err( 'descriptor', "table name: $why", field => $name );
    }
    return _err( 'descriptor', "table '$name': descriptor must be a mapping" )
        unless ref $raw eq 'HASH';

    # SM1356: a SCHEDULE is a table whose fields are the engine's - the weekly
    # periods and the exceptions Lazysite::Data::Schedule reads - so every
    # schedule reads the same way and a layout learns one shape. The descriptor
    # may declare more fields beside them, never one of their names.
    my ( $schedule, $sch_why ) = _bool( $raw->{schedule} );
    return _err( 'descriptor', "table '$name': schedule $sch_why", rule => 'schedule' )
        if $sch_why;

    my $fields = $raw->{fields};
    if ($schedule) {
        return _err( 'descriptor', "table '$name': fields must be a mapping of field definitions" )
            if defined $fields && ref $fields ne 'HASH';
        require Lazysite::Data::Schedule;
        my $own = Lazysite::Data::Schedule::schedule_fields();
        for my $f ( sort keys %{ $fields || {} } ) {
            return _err( 'descriptor',
                "table '$name': '$f' is one of a schedule's own fields (schedule: true gives it)",
                field => $f, rule => 'schedule' )
                if $own->{$f};
        }
        return _err( 'descriptor', "table '$name': a schedule's key is its automatic id",
            rule => 'schedule' )
            if defined $raw->{key} && $raw->{key} ne 'id';
        $fields = { %{ $fields || {} }, %$own };
    }
    return _err( 'descriptor', "table '$name': no fields declared" )
        unless ref $fields eq 'HASH' && %{$fields};

    for my $f ( sort keys %{$fields} ) {
        if ( my $why = _bad_ident($f) ) {
            return _err( 'descriptor', "table '$name': field name: $why",
                field => $f, rule => 'identifier' );
        }
        return _err( 'descriptor',
            "table '$name': '$f' is maintained by the extension "
                . '(set timestamps: true to have it)',
            field => $f, rule => 'reserved' )
            if reserved_column($f);

        if ( my $why = _check_field( $f, $fields->{$f} ) ) {
            return _err( 'descriptor', "table '$name': $why",
                field => $f, rule => 'type' );
        }
    }

    my ( $key, $key_err ) = _check_key( $name, $raw, $fields );
    return $key_err if $key_err;

    my ( $indexes, $index_err ) = _check_indexes( $name, $raw, $fields, $key );
    return $index_err if $index_err;

    # SM476: `public` is the publication flag, and it DEFAULTS TO FALSE.
    #
    # Chosen while there was still no installed base to break - the extension has
    # only ever shipped to edge, is born disabled, and the only tables in
    # existence were three test tables. A closed default costs nothing today
    # and cannot be chosen at all once this reaches stable.
    my ( $public, $public_why ) = _bool( $raw->{public} );
    return _err( 'descriptor', "table '$name': public $public_why",
        rule => 'public' )
        if $public_why;

    my ( $timestamps, $ts_why ) = _bool( $raw->{timestamps} );
    return _err( 'descriptor', "table '$name': timestamps $ts_why",
        rule => 'timestamps' )
        if $ts_why;

    # SM857: does a row carry its own disposition? The flag creates the column;
    # what the values mean is Data::Owned's to say and the write path's to
    # enforce.
    my ( $row_policy, $rp_why ) = _bool( $raw->{row_policy} );
    return _err( 'descriptor', "table '$name': row_policy $rp_why",
        rule => 'row_policy' )
        if $rp_why;

    # A PERSONAL ROW IS UNTESTABLE WITHOUT created_by, so the flag that supplies
    # it is required rather than assumed. Refused by name at load, which is the
    # only place an author can be told before a visitor's row depends on it: a
    # policy column on a table with no stamps would record "personal" against
    # nobody, and an ownership test with no owner to compare admits everybody.
    return _err( 'descriptor',
        "table '$name': row_policy needs timestamps: true - a personal row is "
            . 'owned by the account in created_by, and without the stamps there is no '
            . 'created_by to own it',
        rule => 'row_policy' )
        if $row_policy && !$timestamps;

    my ( $do_field, $do_dir, $order_err )
        = _check_default_order( $name, $raw, $fields, $key,
        { timestamps => $timestamps, row_policy => $row_policy } );
    return $order_err if $order_err;

    my ( $wb, $wb_err ) = _check_writable_by( $name, $raw );
    return $wb_err if $wb_err;

    my ( $where, $where_err ) = _check_where( $name, $raw, $fields );    # SM982
    return $where_err if $where_err;

    # SM1356: DATED ROWS. A field named shows_from or shows_until is the row's
    # own window: outside it the row is not shown on a page or by the data
    # endpoint, with no update needed. A date is a day in the site's zone, a
    # datetime an instant (UTC); anything else could not be compared with now.
    my %shows;
    for my $f (qw(shows_from shows_until)) {
        next unless $fields->{$f};
        my $t = $fields->{$f}{type} // '';
        return _err( 'descriptor',
            "table '$name': $f must be a date or a datetime - it is when the row shows, compared with today",
            field => $f, rule => 'shows' )
            unless $t eq 'date' || $t eq 'datetime';
        $shows{ $f eq 'shows_from' ? 'from' : 'until' } = $t;
    }

    # SM1357: the table's schema.org mapping, checked here so a wrong one is
    # refused at the door that saves it, by name.
    my $sd;
    if ( defined $raw->{structured_data} ) {
        require Lazysite::Data::StructuredData;
        my ( $m, $why ) = Lazysite::Data::StructuredData::check_mapping(
            $raw->{structured_data}, $fields, $key,
            sub { is_owned( { timestamps => $timestamps, row_policy => $row_policy }, $_[0] ) },
            $schedule );
        return _err( 'descriptor', "table '$name': $why", rule => 'structured_data' ) if $why;
        $sd = $m;
    }

    # SM593: which DOMAIN declared this table, on an instance carrying several.
    #
    # Optional, and its absence is not a default that means "everyone" - it
    # means the table predates the key, and the manager surface treats it
    # exactly as it did before. Validated as a hostname rather than passed
    # through, because it is compared against a configured domain's host and a
    # value that could never match would confine the table to nobody while
    # looking like it confined it to somebody.
    # SM1355 (ruling 156): WHICH FIELD SAYS A ROW IS AVAILABLE NOW - a menu's dish
    # today, a service this week. Optional; when given it names a declared
    # boolean field, so a switch is one value and a page's `(available)` binding
    # has one column to filter on. Refused by name at load otherwise: a switch
    # on a text field would store whatever it was sent.
    my $availability = $raw->{availability};
    if ( defined $availability ) {
        return _err( 'descriptor', "table '$name': availability must name one field",
            rule => 'availability' )
            if ref $availability || !length $availability;
        return _err( 'descriptor',
            "table '$name': availability names '$availability', which is not a declared field",
            field => $availability, rule => 'availability' )
            unless ref $fields->{$availability} eq 'HASH';
        return _err( 'descriptor',
            "table '$name': availability names '$availability', which is not a boolean field - "
                . 'a row is available or it is not',
            field => $availability, rule => 'availability' )
            unless ( $fields->{$availability}{type} // '' ) eq 'boolean';
    }

    # SM1355 (ruling 170): HOW LONG THIS TABLE'S ROW HISTORY IS KEPT, in whole
    # days. Optional; absent is Lazysite::Data::RowHistory's default (90). Refused
    # by name unless a positive whole number: a zero, a fraction or a word would
    # either keep nothing or leave the period to the engine's guess.
    my $history_days = $raw->{row_history_days};
    if ( defined $history_days ) {
        return _err( 'descriptor',
            "table '$name': row_history_days is how many days the row history is kept - "
                . 'a positive whole number of days, at most 36500',
            rule => 'row_history_days' )
            if ref $history_days
            || $history_days !~ /\A[1-9][0-9]{0,4}\z/
            || $history_days > 36500;
    }

    my ( $source, $src_err ) = _check_source( $name, $raw, $fields, $key );
    return $src_err if $src_err;

    my $domain = $raw->{domain};
    $domain = '' unless defined $domain && !ref $domain;
    $domain =~ s/\A\s+|\s+\z//g;
    if ( length $domain && $domain !~ /\A[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?\z/ ) {
        return _err( "table '$name': domain '$domain' is not a hostname",
            kind => 'invalid', rule => 'domain' );
    }

    return {
        ok          => 1,
        table       => $name,
        title       => $raw->{title} // $name,
        key         => $key,
        auto_key    => ( $key eq 'id' ? 1 : 0 ),
        fields      => $fields,
        indexes     => $indexes,
        writable_by => $wb,
        # SM677: whether a ROW WRITE on this table writes an audit line.
        #
        # SM505 and SM465 each decided deliberately that a row action's audit
        # entry carries the row KEY - "someone edited that table" is half an
        # answer when the question the trail gets asked is which row. That
        # stands, and remains the DEFAULT: absent, undef, or anything other
        # than an explicit off leaves the table audited.
        #
        # The switch exists because a table with thousands of rows produces
        # thousands of lines, and the operator who has that table is the one
        # who knows it. `audit_rows: off` is theirs to set, per table, where the
        # volume is visible - rather than the engine guessing globally.
        audit_rows => ( _audit_rows_off($raw) ? 0 : 1 ),
        public      => $public,
        ( defined $do_field
            ? ( default_order => $do_field, default_order_dir => $do_dir )
            : () ),
        unique     => [ sort grep { $fields->{$_}{unique} } keys %{$fields} ],
        timestamps => $timestamps,
        row_policy => $row_policy,
        ( length $domain ? ( domain => $domain ) : () ),
        ( defined $availability ? ( availability => $availability ) : () ),    # SM1355
        ( defined $history_days ? ( row_history_days => 0 + $history_days ) : () ), # ruling 170
        ( $where ? ( where => $where ) : () ),   # SM982: the rows a visitor surface shows
        ( $schedule ? ( schedule        => 1 )       : () ),    # SM1356
        ( %shows    ? ( shows           => \%shows ) : () ),
        ( $sd       ? ( structured_data => $sd )     : () ),    # SM1357
        ( $source   ? ( source          => $source ) : () ),    # SM1364
    };
}

# SM1364: A TABLE THAT READS ITS ROWS FROM ANOTHER SYSTEM'S API.
#
# `source:` names a GET connector (its URL, credential, egress bounds and call
# record are the connector's - nothing here reaches the network), the schedule
# entry that refreshes it (a schedule.conf entry calling a connector handler for
# that connector; its run record says how old the rows are), where the list sits
# in the answer (`rows`, a dotted path; absent, the answer itself), and `map`:
# which field of each item fills which column.
#
# THE MAPPED COLUMNS ARE THE SOURCE'S. Tables::_write_prep refuses a write to
# one at every door, so `map` is the one flag that makes them read-only; an
# unmapped column stays the site's own and is written as any other.
#
# THE KEY IS MAPPED, AND IS NOT THE AUTOMATIC id: a refresh updates the row the
# source calls by that identifier and inserts one it has not seen, so the key
# has to be the source's own - an id this store assigned would make every
# refresh a new set of rows.
#
# Returns ( \%source or undef, undef ) or ( undef, $err ).
my $FIELD_PATH = qr/\A[A-Za-z0-9_][A-Za-z0-9_-]{0,63}(?:\.[A-Za-z0-9_][A-Za-z0-9_-]{0,63}){0,7}\z/x;

sub _check_source {
    my ( $name, $raw, $fields, $key ) = @_;
    my $s = $raw->{source};
    return ( undef, undef ) unless defined $s;
    my $bad = sub { return ( undef, _err( 'descriptor', "table '$name': source: $_[0]", rule => 'source', @_[ 1 .. $#_ ] ) ) };
    return $bad->('must be a mapping of connector, schedule, map and (optionally) rows')
        unless ref $s eq 'HASH';
    for my $k ( sort keys %{$s} ) {
        return $bad->("'$k' is not a source setting (connector, schedule, rows, map)")
            unless $k =~ /\A(?:connector|schedule|rows|map)\z/;
    }
    my $conn = $s->{connector};
    return $bad->('connector must name a connector (a-z, 0-9, - or _)')
        unless defined $conn && !ref $conn && $conn =~ /\A[a-z0-9][a-z0-9_-]{0,63}\z/;
    my $sched = $s->{schedule};
    return $bad->( 'schedule must name the schedule.conf entry that refreshes this table - '
            . 'its run record is how old the rows are' )
        unless defined $sched && !ref $sched && $sched =~ /\A[A-Za-z0-9][A-Za-z0-9_-]{0,63}\z/;
    my $rows = $s->{rows};
    return $bad->("rows must be a dotted path to the list in the answer, such as 'data.items'")
        if defined $rows && ( ref $rows || $rows !~ $FIELD_PATH );
    my $map = $s->{map};
    return $bad->('map must be a mapping of column: field in each item of the answer')
        unless ref $map eq 'HASH' && %{$map};
    return $bad->( "the key is 'id', which this store assigns - a sourced table's key is the "
            . "source's own identifier, so name it (key: <column>) and map it" )
        if $key eq 'id';
    my %out;
    for my $col ( sort keys %{$map} ) {
        return $bad->( "map names '$col', which is not a declared field", field => $col )
            unless ref $fields->{$col} eq 'HASH';
        my $from = $map->{$col};
        return $bad->( "map: the field '$col' reads from must be a dotted path, such as 'id' or 'customer.name'",
            field => $col )
            unless defined $from && !ref $from && $from =~ $FIELD_PATH;
        $out{$col} = "$from";
    }
    return $bad->( "map must fill the key '$key' - a refresh finds each row by it", field => $key )
        unless exists $out{$key};
    return ( { connector => $conn, schedule => $sched, map => \%out,
            ( defined $rows ? ( rows => "$rows" ) : () ) }, undef );
}

1;
