package Lazysite::Manager::Themes;

# SM079: the theming CORE - theme + layout listing, activation, the active
# pointer, validation, backups/snapshots, theme delete/rename/upload, HTML-cache
# invalidation, cache-list/invalidate, and the artifact-manifest actions. The
# layouts-repo install/release subsystem lives in Manager::Layouts (which
# depends one-way on this module); the pure manifest/digest helpers live in
# Manager::Artifact. Context ($DOCROOT, $LAZYSITE_DIR, $auth_user, $action) set
# by the dispatcher; Archive::Zip is required inline.

use strict;
use warnings;
use JSON::PP qw(decode_json);
use File::Find;
use File::Path                  qw(make_path);
use File::Copy                  qw(copy);
use File::Basename              qw(dirname);
use Cwd                         qw(realpath);
use POSIX                       qw(strftime);
use Digest::SHA                 qw(sha256_hex);
use Lazysite::Util              qw(log_event);
use Lazysite::Manager::Common   ();
use Lazysite::Manager::Files    qw(acquire_lock release_lock);
use Lazysite::Manager::Artifact qw(_artifact_dir _compute_manifest _artifact_digest);
use Lazysite::Manager::Domains  ();    # SM177: domains_using (delete-safety scan)
use Lazysite::Paths             ();
use Exporter 'import';

our @EXPORT_OK = qw(
    action_theme_list action_themes_list_all dispatch_themes_list_all action_theme_activate
    action_theme_tokens action_create_theme theme_config_issues
    _layout_declared_tokens _theme_config_tokens _token_mismatch
    _token_warning_list
    action_layout_activate action_theme_delete action_theme_copy
    active_layout_and_theme
    action_theme_upload action_cache_list action_cache_invalidate _record_theme_creator
    _read_active_layout_and_theme _install_theme_from_dir
    action_artifact_manifest action_artifact_validate
    _snapshot_artifact _prune_backups _snapshot_wanted _swap_in _staging_for _mirror_theme_assets _mirror_warning _mirror_layout_themes
    _read_json_file layout_engine_requirement
);

our $DOCROOT;

# SM293: this site's engine tree - beside the docroot once migrated,
# inside it before. Asked, never computed, so both layouts work on one
# code path and a site migrates by moving the directory.
sub _lz { return Lazysite::Paths::lazysite_dir($DOCROOT) }
our $LAZYSITE_DIR;
our $auth_user = '';
our $action    = '';

# SM255 (completion): the pointer setters below used a bare open('>') - not
# atomic, not locked, and unrecorded - on the same file config-set writes
# through the locking writer. Route them through the one writer; this module
# carries its own $DOCROOT and $auth_user (the dispatcher sets both per
# request), so bridge them for the duration of the write or the shared writer
# looks in the wrong docroot and attributes the commit to nobody.
sub _write_conf_content {
    my ( $content, $message ) = @_;
    no warnings 'once';
    local $Lazysite::Manager::Common::DOCROOT   = $DOCROOT;
    local $Lazysite::Manager::Common::auth_user = $auth_user;
    return Lazysite::Manager::Common::write_conf_content( $content, $message );
}

# SM583: the same conf value as Domains::_parse reads, answered the same way.
#
# This matched \S+ and then stripped the capture to [A-Za-z0-9_-], while _parse
# took the whole trimmed line - so `layout: my layout` was `my` here and
# `my layout` on every domain surface. The strip was the worse half: it handed
# back a layout name nobody wrote, as the ACTIVE layout, indistinguishable from
# a working answer.
#
# So it now reads the WHOLE trimmed value, as _parse always did, and runs it
# through the one rule (Domains::presentation_value): a name passes, anything
# else is refused to unset. Empty is what an unconfigured site returns already,
# and the refusal is logged once naming the value.
# The published name (SM749): Files.pm asks this from another package, and a
# fully qualified call to an underscore sub is what perlcritic refuses. The
# in-package callers and the importers keep the old name.
sub active_layout_and_theme { return _read_active_layout_and_theme() }

sub _read_active_layout_and_theme {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my $layout = '';
    my $theme  = '';
    if ( open my $fh, '<', _lz() . "/lazysite.conf" ) {
        while (<$fh>) {
            $layout = $1 if /^layout\s*:\s*(.*?)\s*$/;
            $theme  = $1 if /^theme\s*:\s*(.*?)\s*$/;
        }
        close $fh;
    }
    return (
        Lazysite::Manager::Domains::presentation_value( 'layout', $layout ) // '',
        Lazysite::Manager::Domains::presentation_value( 'theme',  $theme )  // '',
    );
}

# SM234: which domains resolve to each theme/layout. The delete guard already
# consults this (a theme a configured domain depends on cannot be removed) but the
# LISTING did not, so a theme pinned only by a sub-domain showed a Delete button
# and the sysop learned it was protected from the error that followed. One
# parse for the whole listing - see Domains::domain_usage.
sub _usage {
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
    return Lazysite::Manager::Domains::domain_usage();
}

# The same bridge for the delete-safety scan: this module carries its own
# $DOCROOT (the dispatcher sets it per request), so point Domains at it for the
# duration of the query. Both the delete and the rename guard ask this.
sub _domains_using {
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
    return Lazysite::Manager::Domains::domains_using(@_);
}

# SM234: the theme rows under ONE layout's themes/ directory, each carrying the
# domains that resolve to it. Both listings walk the same directory in the same
# way and differ only in which layouts they ask about, so the walk is written
# once; action_themes_list_all adds the `layout` key its rows carry.
sub _themes_under {
    my ( $dir, $layout, $use, $active_layout, $active_theme ) = @_;
    my @out;
    opendir my $dh, $dir or return @out;
    for my $name ( sort readdir $dh ) {
        next if $name =~ /^\./;
        next unless -d "$dir/$name";
        my $by = $use->{themes}{"$layout\0$name"} || [];
        push @out, {
            name   => $name,
            active => ( $layout eq $active_layout && $name eq $active_theme )
            ? 1 : 0,
            valid   => -f "$dir/$name/theme.json" ? 1 : 0,
            used_by => $by,           # SM234: domains that resolve to it
            in_use  => scalar @$by,
        };
    }
    closedir $dh;
    return @out;
}

sub action_theme_list {
    my ( $active_layout, $active_theme ) = _read_active_layout_and_theme();
    my $use = _usage();

    my @themes;
    if ( length $active_layout ) {
        my $themes_dir = _lz() . "/layouts/$active_layout/themes";
        @themes = _themes_under( $themes_dir, $active_layout, $use,
            $active_layout, $active_theme )
            if -d $themes_dir;
    }

    return {
        ok     => 1,
        themes => \@themes,
        active => $active_theme,
        layout => $active_layout,
    };
}

# SM1400 (triage T-87): A BACKUP SNAPSHOT IS NOT A LAYOUT. delete_layout and an
# activate keep `<layout>-backup-<stamp>` beside the layouts (recoverable, pruned
# by backup_retention), and this listing walked every directory under layouts/,
# so the snapshot came back as a layout of its own, with the deleted layout's
# themes under it - on the Appearance page, over MCP (list_themes) and on the
# API - and a second delete removed it. The walk now leaves every snapshot out
# of `themes` (a layout's and a theme's alike) and lists them under `backups`:
# {artifact, layout, name, path}, the path being what artifact-backups-delete takes.
sub action_themes_list_all {
    my ( $active_layout, $active_theme ) = _read_active_layout_and_theme();
    my $use = _usage();

    my $layouts_dir = _lz() . "/layouts";
    my ( @themes, @backups );

    if ( -d $layouts_dir ) {
        opendir my $ld, $layouts_dir or return {
            ok            => 1, themes => [], backups => [], active => $active_theme,
            active_layout => $active_layout,
        };
        for my $layout_name ( sort readdir $ld ) {
            next if $layout_name =~ /^\./;
            next unless -d "$layouts_dir/$layout_name";
            if ( $layout_name =~ /-backup-\d/ ) {
                push @backups, { artifact => 'layout', layout => _backup_base($layout_name),
                    name => $layout_name, path => "lazysite/layouts/$layout_name" };
                next;
            }
            my $themes_path = "$layouts_dir/$layout_name/themes";
            next unless -d $themes_path;

            for my $row ( _themes_under( $themes_path, $layout_name, $use, $active_layout, $active_theme ) ) {
                if ( $row->{name} =~ /-backup-\d/ ) {
                    push @backups, { artifact => 'theme', layout => $layout_name, name => $row->{name},
                        path => "lazysite/layouts/$layout_name/themes/$row->{name}" };
                    next;
                }
                push @themes, { layout => $layout_name, %$row };
            }
        }
        closedir $ld;
    }

    return {
        ok            => 1,
        themes        => \@themes,
        backups       => \@backups,
        active        => $active_theme,
        active_layout => $active_layout,
    };
}

# SM944 S33: themes-list-all's dispatch branch, moved here from
# lazysite-manager-api.pl with its statements unchanged: the listing, and for a
# domain-confined caller the domains it activates on (Manager::Common's request
# context, read by full name; this module's own $auth_user is a log copy).
sub dispatch_themes_list_all {
    my $result;
    $result = action_themes_list_all();
    # SM976 F4 (ruled 2026-10-09, "Activate on its domain"): a domain-confined
    # caller activates on its own domains, never on the instance (R1). The
    # Appearance page reads which from here - the listing it already loads -
    # and binds there through theme-activate/layout-activate with host. Absent
    # for the operator and every unconfined caller, whose page is unchanged.
    if ( ref $result eq 'HASH' && Lazysite::Manager::Common::caller_is_confined() ) {
        $result->{acts_on} = [ grep { $_ ne '(default)' } Lazysite::Manager::Common::reachable_domains() ];
    }
    return $result;
}

# TL-2: the one open-slurp-decode this module and Manager::Layouts share.
# Returns exactly what decode_json returned - so a caller may test the result
# as it always has - or undef when the file could not be opened. The three
# readers that tell "could not open" apart from "did not parse" keep their own
# open: _validate_theme_dir quotes the parse error back to the operator,
# action_artifact_validate reports 'unreadable' and 'invalid' as separate
# findings, and _install_theme_from_dir refuses an upload differently for each.
sub _read_json_file {
    my ($path) = @_;
    open my $fh, '<:utf8', $path or return undef;
    my $raw = do { local $/; <$fh> };
    close $fh;
    return eval { decode_json($raw) };
}

# SM204: read a layout.json under a given layout and return its decoded hash
# (or {} if absent/unparseable). Used by the token-vocabulary tool to read
# default_theme and the optional (SM203) declared `tokens` block.
sub _read_layout_json {
    my ($layout) = @_;
    return {} unless defined $layout && $layout =~ /^[A-Za-z0-9_-]+$/;
    my $meta = _read_json_file("$LAZYSITE_DIR/layouts/$layout/layout.json");
    return ( ref $meta eq 'HASH' ) ? $meta : {};
}

# SM204: decode a theme's theme.json under a layout. Returns the parsed hash or
# undef when the theme is missing / unnamed / unparseable.
sub _read_theme_json {
    my ( $layout, $theme ) = @_;
    return undef
        unless defined $layout
        && $layout =~ /^[A-Za-z0-9_-]+$/
        && defined $theme
        && $theme =~ /^[A-Za-z0-9_-]+$/;
    my $meta
        = _read_json_file("$LAZYSITE_DIR/layouts/$layout/themes/$theme/theme.json");
    return ( ref $meta eq 'HASH' ) ? $meta : undef;
}

# SM268 04-F6: who created a theme, kept where the caller cannot write it.
#
# theme.json is inside the tree manage_themes makes writable, so provenance
# stored there is self-certified by the party the delete rule restricts. This
# store lives in lazysite/auth/, which the blocklist denies on every authoring
# surface. Keyed "<layout>/<theme>", because the same theme name under two
# layouts is two objects.
sub _created_registry_path { return "$LAZYSITE_DIR/auth/themes-created.json" }

sub _read_created_registry {
    my $path = _created_registry_path();
    return {} unless -f $path;
    open my $fh, '<:raw', $path or return {};
    my $raw = do { local $/; <$fh> };
    close $fh;
    my $map = eval { decode_json( $raw // '{}' ) };
    return ( ref $map eq 'HASH' ) ? $map : {};
}

sub _write_created_registry {
    my ($map) = @_;
    my $path = _created_registry_path();
    make_path( dirname($path) ) unless -d dirname($path);
    my $tmp = "$path.tmp.$$";
    open my $fh, '>:raw', $tmp or return 0;
    print {$fh} JSON::PP->new->canonical->pretty->encode($map);
    close $fh;
    chmod 0640, $tmp;
    return rename $tmp, $path;
}

sub _record_theme_creator {
    my ( $layout, $theme, $who ) = @_;
    return unless length( $layout // '' ) && length( $theme // '' );
    return unless length( $who    // '' );
    my $map = _read_created_registry();
    $map->{"$layout/$theme"} = $who;
    _write_created_registry($map);
    return;
}

sub _theme_creator {
    my ( $layout, $theme ) = @_;
    my $map = _read_created_registry();
    my $who = $map->{"$layout/$theme"};
    return ( defined $who && length $who ) ? $who : '';
}

sub _forget_theme_creator {
    my ( $layout, $theme ) = @_;
    my $map = _read_created_registry();
    return unless exists $map->{"$layout/$theme"};
    delete $map->{"$layout/$theme"};
    _write_created_registry($map);
    return;
}

# Carry provenance across a rename, or the theme stops being deletable by the
# account that made it - which would turn this fix into the litter problem
# SM262 set out to solve.
# SM204: the config (GROUP->KEY->value) map of a theme.json, keeping only
# scalar leaf values (mirrors generate_theme_css: nested objects under a group
# key are a shape error and skipped).
sub _theme_config_tokens {
    my ($theme_data) = @_;
    my %tokens;
    my $config = ( ref $theme_data eq 'HASH' ) ? $theme_data->{config} : undef;
    return \%tokens unless ref $config eq 'HASH';
    for my $group ( sort keys %{$config} ) {
        next unless ref $config->{$group} eq 'HASH';
        my %kv;
        for my $key ( sort keys %{ $config->{$group} } ) {
            my $val = $config->{$group}{$key};
            next if ref $val;
            $kv{$key} = $val;
        }
        $tokens{$group} = \%kv;
    }
    return \%tokens;
}

# SM203: the declared token vocabulary of a layout as GROUP -> { key => 1 }.
# Reads the OPTIONAL `tokens` block of layout.json (via _read_layout_json).
# Returns an empty hash when the block is absent - callers treat "no declared
# block" as "nothing to compare against" and skip the coverage check.
sub _layout_declared_tokens {
    my ($layout) = @_;
    my $ljson    = _read_layout_json($layout);
    my $decl     = ( ref $ljson eq 'HASH' ) ? $ljson->{tokens} : undef;
    my %declared;
    return \%declared unless ref $decl eq 'HASH';
    for my $group ( sort keys %{$decl} ) {
        my $keys = $decl->{$group};
        my @list =
            ( ref $keys eq 'ARRAY' )  ? @{$keys}
            : ( ref $keys eq 'HASH' ) ? ( sort keys %{$keys} )
            :                           ();
        $declared{$group} = { map { $_ => 1 } @list };
    }
    return \%declared;
}

# SM203/SM205: compare a layout's declared token vocabulary against a theme's
# supplied config. Returns undef when the layout declares no `tokens` block (the
# check is skipped); otherwise a hashref with:
#   declared => 1
#   missing  => [ "group.key", ... ]  # declared but the config omits them
#   extra    => [ "group.key", ... ]  # config supplies them, undeclared
# Warn-only by contract; never used to reject.
sub _token_mismatch {
    my ( $declared, $supplied ) = @_;
    return undef unless ref $declared eq 'HASH' && %{$declared};
    $supplied ||= {};
    my ( @missing, @extra );
    for my $group ( sort keys %{$declared} ) {
        for my $key ( sort keys %{ $declared->{$group} } ) {
            push @missing, "$group.$key"
                unless ref $supplied->{$group} eq 'HASH'
                && exists $supplied->{$group}{$key};
        }
    }
    for my $group ( sort keys %{$supplied} ) {
        next unless ref $supplied->{$group} eq 'HASH';
        for my $key ( sort keys %{ $supplied->{$group} } ) {
            push @extra, "$group.$key" unless $declared->{$group}{$key};
        }
    }
    return { declared => 1, missing => \@missing, extra => \@extra };
}

# SM203: mismatch between a layout's declared tokens and an ON-DISK theme's
# config (used at activation). Returns undef when there is no declared block.
sub _declared_token_mismatch {
    my ( $layout, $theme ) = @_;
    my $declared = _layout_declared_tokens($layout);
    return undef unless %{$declared};
    my $td = _read_theme_json( $layout, $theme );
    return _token_mismatch( $declared, _theme_config_tokens($td) );
}

# SM203/SM205: render a mismatch hashref as a flat list of human-readable
# warning strings for the action's return payload.
sub _token_warning_list {
    my ($tw) = @_;
    my @w;
    push @w, "theme omits declared token '$_' (layout CSS fallback applies)"
        for @{ $tw->{missing} };
    push @w, "config supplies undeclared token '$_'" for @{ $tw->{extra} };
    return \@w;
}

# SM205: eager value/name validation for a theme scaffold. Returns a list of
# specific rule-failure strings (empty = valid). The value rule mirrors the
# render-time emitter generate_theme_css, which strips ; { } < > and any
# non-ASCII from every value; catching those up front tells the author before a
# write rather than letting them be silently stripped at render. Kept in sync
# with that emitter by design (SM205 spec).
sub theme_config_issues {
    my ( $config, $name ) = @_;
    my @issues;
    if ( !defined $name || $name !~ /^[A-Za-z0-9_-]+$/ ) {
        push @issues, "name '" . ( defined $name ? $name : '' )
            . "' must match [A-Za-z0-9_-]+";
    }
    if ( ref $config eq 'HASH' ) {
        for my $group ( sort keys %{$config} ) {
            my $gv = $config->{$group};
            next unless ref $gv eq 'HASH';
            for my $key ( sort keys %{$gv} ) {
                my $v = $gv->{$key};
                next if ref $v;
                next unless defined $v;
                if ( $v =~ /[^\x00-\x7f]/ ) {
                    push @issues,
                        "config value at '$group.$key' contains non-ASCII characters";
                }
                if ( $v =~ /[;{}<>]/ ) {
                    push @issues,
                        "config value at '$group.$key' contains a forbidden character (one of ; { } < >)";
                }
            }
        }
    }
    return @issues;
}

# SM204 (feature theme_tokens): token-vocabulary discovery. A READ tool
# (manage_themes, not audited). Resolves a (layout, theme) pair, then returns
# the theme's config as the token vocabulary plus exemplar values.
#
#   theme given  -> that theme's config (under its layout, else the active one)
#   layout only  -> the layout's declared `tokens` block (SM203, if present)
#                   PLUS its default theme's config as exemplar values; when no
#                   block is declared the vocabulary is DERIVED from that config
#                   (derived => 1).
#   neither      -> the active layout + active theme.
sub action_theme_tokens {
    my ($params) = @_;
    $params ||= {};

    my ( $active_layout, $active_theme ) = _read_active_layout_and_theme();

    my $req_layout = $params->{layout};
    my $req_theme  = $params->{theme};
    $req_layout = undef unless defined $req_layout && length $req_layout;
    $req_theme  = undef unless defined $req_theme  && length $req_theme;

    for my $v ( $req_layout, $req_theme ) {
        next unless defined $v;
        return { ok => 0, error => 'Invalid layout/theme name.' }
            unless $v =~ /^[A-Za-z0-9_-]+$/;
    }

    # Explicit theme wins: report that theme's own config verbatim.
    if ( defined $req_theme ) {
        my $layout = defined $req_layout ? $req_layout : $active_layout;
        return { ok => 0, error => 'No layout to resolve the theme under.' }
            unless length $layout;
        my $td = _read_theme_json( $layout, $req_theme );
        return { ok => 0, error => "No such theme: $req_theme (layout $layout)." }
            unless $td;
        return {
            ok      => 1,
            layout  => $layout,
            theme   => $req_theme,
            derived => JSON::PP::false,
            tokens  => _theme_config_tokens($td),
        };
    }

    # Layout-scoped (or the active pair): resolve the exemplar theme.
    my $layout = defined $req_layout ? $req_layout : $active_layout;
    return { ok => 0, error => 'No layout is active or named.' }
        unless length $layout;

    my $ljson = _read_layout_json($layout);

    # The exemplar theme: the active theme when it is THIS layout's, else the
    # layout's declared default_theme.
    my $exemplar =
        ( $layout eq $active_layout && length $active_theme )
        ? $active_theme
        : ( $ljson->{default_theme} // '' );
    $exemplar = '' unless $exemplar =~ /^[A-Za-z0-9_-]+$/;

    my $td            = length $exemplar ? _read_theme_json( $layout, $exemplar ) : undef;
    my $config_tokens = _theme_config_tokens($td);

    # SM203 declared `tokens` block (GROUP -> [keys]); optional and may be absent.
    my %declared;
    my $decl = $ljson->{tokens};
    if ( ref $decl eq 'HASH' ) {
        for my $group ( sort keys %{$decl} ) {
            my $keys = $decl->{$group};
            $declared{$group} =
                ( ref $keys eq 'ARRAY' )  ? [ @{$keys} ]
                : ( ref $keys eq 'HASH' ) ? [ sort keys %{$keys} ]
                :                           [];
        }
    }

    my %out = (
        ok      => 1,
        layout  => $layout,
        theme   => $exemplar,
        derived => ( %declared ? JSON::PP::false : JSON::PP::true ),
        tokens  => $config_tokens,
    );
    $out{declared} = \%declared if %declared;
    return \%out;
}

sub action_theme_activate {
    my ( $theme_name, $params ) = @_;
    $params ||= {};
    $theme_name =~ s/[^a-zA-Z0-9_-]//g;

    # SM247: deactivation must be ASKED FOR, never inferred from a missing
    # parameter. The control API used to default this name to '/', which this
    # sanitiser reduces to '', so calling theme-activate with the name in the wrong
    # parameter used to strip the site's theme and return ok:1. A site agent did
    # exactly that to a live site and only caught it by checking theme-list
    # afterwards; an agent trusting ok:1 would have walked away leaving the site
    # unstyled.
    #
    # An empty name is now an error. A caller that means it passes
    # deactivate => 1, which is a thing you can only do on purpose.
    #
    # SM920: the refusal names `theme`, which is the ONE parameter this action
    # takes now. It said `path` - the spelling that has been retired - so a caller
    # who reached this error was being sent back to the parameter that caused it.
    if ( $theme_name eq '' ) {
        return _set_theme_pointer('') if $params->{deactivate};
        return { ok => 0, kind => 'missing-parameter',
            error => 'No theme name given. The theme name goes in the `theme` '
                . 'parameter for this action. To deliberately remove the site\'s '
                . 'theme, pass deactivate=1 - an absent name is treated as a '
                . 'mistake, not as an instruction to de-theme the site.' };
    }

    my ( $active_layout, $old_theme ) = _read_active_layout_and_theme();
    return { ok => 0, error => "No active layout set" } unless length $active_layout;

    my $themes_dir = "$LAZYSITE_DIR/layouts/$active_layout/themes";
    my $theme_dir  = "$themes_dir/$theme_name";
    return { ok => 0, error => "Theme not found" } unless -d $theme_dir;

    # Artifact-level lock across validate -> snapshot -> flip.
    my $lock_rel = "lazysite/layouts/$active_layout/themes/$theme_name";
    my $lk       = acquire_lock( $lock_rel, $auth_user );
    unless ( $lk->{ok} ) {
        return { ok => 0, locked => 1, error => "Theme is locked by "
                . ( $lk->{locked_by} // 'another session' ) };
    }

    my $out = eval {
        my $v = _validate_theme_dir( $theme_dir, $active_layout );
        return { ok => 0, error => "Theme invalid: " . join( '; ', @{ $v->{errors} } ) }
            unless $v->{valid};

        if ( defined $params->{base} && length $params->{base} ) {
            return { ok => 0, conflict => 1,
                error => "Theme changed since the supplied base manifest" }
                if _artifact_digest($theme_dir) ne $params->{base};
        }

        if ( length $old_theme && $old_theme ne $theme_name ) {
            _snapshot_artifact( $themes_dir, $old_theme );
            _prune_backups( $themes_dir, $old_theme );
        }
        my $res = _set_theme_pointer($theme_name);
        my $mirror;
        if ( $res->{ok} ) {
            # SM315: keep the mirror result - zero assets is the signal that the
            # site will render unstyled, and the acknowledgement is the only
            # place a caller will see it.
            $mirror = _mirror_theme_assets( $active_layout, $theme_name );
            # SM820: and every OTHER theme this layout carries, so a per-page
            # `theme:` naming one that has never been activated has a mirror to
            # point at. Idempotent, so re-mirroring the one above costs nothing.
            _mirror_layout_themes($active_layout);
            # SM203: warn (never reject) when the just-activated theme does not
            # match the layout's declared token vocabulary. The layout.json
            # `tokens` block is OPTIONAL; the check is skipped entirely when it
            # is absent. The fallback chain (var(--theme-*, <fallback>)) makes a
            # mismatch survivable by design, so this is documentation-grade
            # signal only.
            my $tw = _declared_token_mismatch( $active_layout, $theme_name );
            if ( $tw && ( @{ $tw->{missing} } || @{ $tw->{extra} } ) ) {
                log_event( 'WARN', 'theme-activate', 'declared token mismatch',
                    layout     => $active_layout,
                    theme      => $theme_name,
                    missing    => join( ',', @{ $tw->{missing} } ),
                    undeclared => join( ',', @{ $tw->{extra} } ) );
                $res->{token_warnings} = _token_warning_list($tw);
            }
        }

        # SM315: report the mirror, always - a count of zero is the whole point.
        # A theme that declares colours and fonts and mirrors nothing is a site
        # about to render unstyled, and at the HTTP level that is
        # indistinguishable from a working one: every page returns 200.
        if ( ref $mirror eq 'HASH' ) {
            $res->{assets_mirrored} = $mirror->{mirrored};
            push @{ $res->{warnings} ||= [] },
                _mirror_warning( $mirror, 'no theme assets were mirrored: ',
                'The site will render with no stylesheet, and every '
                    . 'page will still return 200.' )
                unless $mirror->{mirrored};
        }
        return $res;
    };
    my $err = $@;
    release_lock( $lock_rel, $auth_user );
    die $err if $err;
    return $out;
}

# SM205: validated theme scaffolding. Creates
# lazysite/layouts/LAYOUT/themes/NAME/ with a theme.json (layouts:[LAYOUT],
# name, version, author, config) and assets/main.css, optionally activating.
# EAGER validation (name + config value rules, layout installed) returns
# { ok => 0, kind => 'validation', ... } BEFORE writing anything. The
# declared-token coverage check (SM203) is warn-only.
sub action_create_theme {
    my ($params) = @_;
    $params ||= {};

    my $layout = $params->{layout};
    my $name   = $params->{name};
    my $config = $params->{config};
    $config = {} unless ref $config eq 'HASH';

    return { ok => 0, kind => 'validation', error => 'layout is required.' }
        unless defined $layout && length $layout;
    return { ok => 0, kind => 'validation', error => 'name is required.' }
        unless defined $name && length $name;

    # Eager name + value validation (before any write).
    my @issues = theme_config_issues( $config, $name );
    if ( defined $layout && $layout !~ /^[A-Za-z0-9_-]+$/ ) {
        push @issues, "layout '$layout' must match [A-Za-z0-9_-]+";
    }
    return { ok => 0, kind => 'validation',
        error  => 'theme validation failed: ' . join( '; ', @issues ),
        issues => \@issues }
        if @issues;

    my $layout_dir = "$LAZYSITE_DIR/layouts/$layout";
    return { ok => 0, kind => 'validation',
        error => "layout '$layout' is not installed." }
        unless -f "$layout_dir/layout.tt";

    my $theme_dir = "$layout_dir/themes/$name";
    return { ok => 0, kind => 'exists',
        error => "a theme named '$name' already exists under layout '$layout'." }
        if -d $theme_dir;

    # SM203 coverage check (warn, never reject).
    my $declared = _layout_declared_tokens($layout);
    my $tw = _token_mismatch( $declared, _theme_config_tokens( { config => $config } ) );
    my @warnings = $tw ? @{ _token_warning_list($tw) } : ();

    # SM243/SM250: a theme that hides the layout's chrome, or hides content until
    # a script reveals it, is a silent and total failure - and it survives casual
    # checking, because the part above the fold is usually unaffected. Both were
    # paid for on live sites: one left a site's navigation unreachable while
    # looking correct, the other left every section below the hero invisible
    # through four successive visual checks. Warn, never reject: both patterns are
    # legitimate with a fallback, and a platform that refused them would be wrong
    # more often than the authors it protected.
    if ( defined $params->{css} && length $params->{css} ) {
        my $css = $params->{css};
        if ( $css =~ m{ (?:\.site-header|\.site-footer|\bheader\b|\bfooter\b)
                        [^{}]* \{ [^{}]*? display \s*:\s* none }six )
        {
            push @warnings,
                'this theme hides the layout\'s header or footer. If the page '
                . 'content carries its own, the site navigation becomes '
                . 'unreachable - a sysop can set nav items that never appear '
                . 'anywhere. Remove the chrome from the content instead.';
        }
        # opacity:0 (or visibility:hidden) revealed by a class a script adds. A
        # rule inside prefers-reduced-motion is NOT a neutraliser - it applies to
        # a minority of visitors, and reading it as one is exactly what caused
        # the reported outage.
        if ( $css =~ m{ opacity \s*:\s* 0 \b }six
            || $css =~ m{ visibility \s*:\s* hidden \b }six )
        {
            push @warnings,
                'this theme sets content invisible by default (opacity:0 / '
                . 'visibility:hidden). If only a script reveals it, then visitors '
                . 'without JavaScript and most crawlers see nothing - and removing '
                . 'that script later hides the site silently. Start from a visible '
                . 'state, or provide a non-script fallback. A rule inside '
                . '@media(prefers-reduced-motion) does NOT count: it applies only '
                . 'to visitors who asked for reduced motion.';
        }
    }

    # Scaffold. theme.json + assets/main.css (never a root-level main.css - it
    # 404s after the asset mirror). CSS: caller-supplied, else copy the layout
    # default theme's main.css as the copy-nearest-and-adapt starting point.
    make_path("$theme_dir/assets");

    my $author = ( defined $auth_user && length $auth_user ) ? $auth_user : 'unknown';
    my $meta   = {
        name    => $name,
        version => ( defined $params->{version} && length $params->{version} )
        ? $params->{version}
        : '1.0.0',
        layouts => [$layout],
        author  => $author,
        # SM262: provenance for the delete rule, kept SEPARATE from `author`.
        # `author` is a descriptive theme.json field the theme itself may carry
        # and edit; this one exists to answer "may this caller remove it", and
        # conflating a description with an authorisation would mean a theme could
        # rewrite its own permissions. Absent means "not created through this
        # path", which is the safe reading: an agent can never delete a theme
        # that predates the field.
        created_by => $author,
        config     => $config,
        ( defined $params->{description} && length $params->{description}
            ? ( description => $params->{description} ) : () ),
        ( ref $params->{tags} eq 'ARRAY' ? ( tags => $params->{tags} ) : () ),
    };

    my @created;
    {
        my $tj  = "$theme_dir/theme.json";
        my $enc = JSON::PP->new->utf8->pretty->canonical->encode($meta);
        open my $fh, '>:raw', $tj
            or return { ok => 0, error => "Cannot write theme.json" };
        print {$fh} $enc;
        close $fh;
        push @created, "lazysite/layouts/$layout/themes/$name/theme.json";
        # SM268 04-F6: the authoritative copy of "who made this", out of reach
        # of the caller. theme.json's created_by above is now description only.
        _record_theme_creator( $layout, $name, $author );
    }

    {
        my $css_path = "$theme_dir/assets/main.css";
        if ( defined $params->{css} ) {
            open my $fh, '>:utf8', $css_path
                or return { ok => 0, error => "Cannot write main.css" };
            print {$fh} $params->{css};
            close $fh;
        }
        else {
            # Copy the layout default theme's main.css as the starting point.
            my $ljson = _read_layout_json($layout);
            my $dt    = ( ref $ljson eq 'HASH' ) ? ( $ljson->{default_theme} // '' ) : '';
            $dt = '' unless $dt =~ /^[A-Za-z0-9_-]+$/;
            my $src =
                length $dt
                ? "$layout_dir/themes/$dt/assets/main.css"
                : '';
            if ( length $src && -f $src ) {
                copy( $src, $css_path );
            }
            else {
                # No default CSS to copy - leave a minimal placeholder so the
                # asset exists (a missing main.css would 404 after the mirror).
                open my $fh, '>:utf8', $css_path
                    or return { ok => 0, error => "Cannot write main.css" };
                print {$fh} "/* $name theme for $layout - starting point */\n";
                close $fh;
            }
        }
        push @created, "lazysite/layouts/$layout/themes/$name/assets/main.css";
    }

    # SM176: record a pristine baseline so an unedited theme does not spawn a
    # pointless backup when switched away from.
    _write_pristine( "$layout_dir/themes", $name, _artifact_digest($theme_dir) );

    log_event( 'INFO', $action, 'theme created',
        layout => $layout, theme => $name, user => $author );

    my %out = ( ok => 1, layout => $layout, theme => $name, created => \@created );
    $out{warnings} = \@warnings if @warnings;
    # SM1335: a theme made is a source written, so every host has its copy now -
    # a page may pin it (SM120) before anything activates it.
    follow_source_write( $DOCROOT, "lazysite/layouts/$layout/themes/$name" );

    # Preview guidance: pre-activation, the theme is served from its SOURCE
    # assets path; post-activation (activate:true) from the mirror.
    my $activated = 0;
    if ( $params->{activate} ) {
        my $act = action_theme_activate( $name, {} );
        $out{activation} = $act;
        if ( $act && $act->{ok} ) {
            $activated = 1;
            # Fold activation-time token warnings in too.
            if ( ref $act->{token_warnings} eq 'ARRAY' && @{ $act->{token_warnings} } ) {
                push @{ $out{warnings} }, @{ $act->{token_warnings} };
            }
        }
    }

    $out{preview} = $activated
        ? "Activated. The theme's assets are served from "
        . "/lazysite-assets/$layout/$name/main.css (mirror)."
        : "Not activated. Preview the source CSS at "
        . "/lazysite/layouts/$layout/themes/$name/assets/main.css, "
        . "or call activate_theme to make it live.";

    return \%out;
}

sub _set_theme_pointer {
    my ($theme_name) = @_;
    my $conf_path = _lz() . "/lazysite.conf";
    return { ok => 0, error => "Cannot read conf" } unless -f $conf_path;
    open my $fh, '<:utf8', $conf_path or return { ok => 0, error => "Cannot read conf" };
    my $conf = do { local $/; <$fh> };
    close $fh;
    if    ( $theme_name eq '' )      { $conf =~ s/^theme\s*:.*\n?//m }
    elsif ( $conf =~ /^theme\s*:/m ) { $conf =~ s/^theme\s*:.*$/theme: $theme_name/m }
    else                             { $conf .= "\ntheme: $theme_name\n" }
    my ( $wok, $werr ) = _write_conf_content( $conf,
        ( length $theme_name ? "activate theme $theme_name" : 'deactivate theme' ) );
    return { ok => 0, error => "Cannot write conf: $werr" } unless $wok;
    _invalidate_html_cache();
    return { ok => 1, theme => $theme_name };
}

# SM531: what counts as the SOURCE of a <page>.html render - one answer for
# every cache walk in this module. The processor renders <page>.md and
# <page>.url alike, so an .html beside either is a generated cache. Four walks
# once answered this separately and disagreed on .url: the activation sweep
# dropped its render, the wildcard invalidate kept it, the listing said it had
# no source, and the single-path branch refused it as not-a-cache. An .html
# with NEITHER sibling is legacy static content (SM133) and is never a cache.
# SM852: the rule itself lives in Manager::Common, so Files' nav-save sweep
# answers it the same way - it was the one walk that did not ask.
sub _cache_source_exists { return Lazysite::Manager::Common::render_source_exists( $_[0] ) }

# Public: Layouts drops the renders after an update switched in (SM1141).
sub invalidate_html_cache { return _invalidate_html_cache() }

sub _invalidate_html_cache {
    find( sub {
            return unless /\.html$/;
            my $rel = $File::Find::name;
            $rel =~ s{^\Q$DOCROOT\E/?}{/};
            return if $rel =~ m{^/lazysite/};
            # Only delete a GENERATED cache file: a <page>.html whose <page>.md or
            # <page>.url source exists. An author-supplied .html with no such
            # source (e.g. an include partial) is content, not cache - never
            # delete it (deleting author partials gutted pages, SM072 report).
            ( my $base = $File::Find::name ) =~ s/\.html$//;
            unlink $_ if _cache_source_exists($base);
    }, $DOCROOT );
    # SM110: a theme/layout change re-chromes every page of every host -
    # drop the per-alias-host cache tree wholesale too.
    Lazysite::Util::clear_host_cache($DOCROOT);
    return;
}

# SM080: build the web-served asset mirror at /lazysite-assets/LAYOUT/THEME/ so
# the processor's `theme_assets` variable resolves after ACTIVATION, not only
# after a repo install. Without this a copied-then-activated layout/theme 404s
# its CSS (theme_assets points at a mirror that was never built), which forced
# layout.tt to hardcode the source path and blocked drop-in layout copies.
# Idempotent; a no-op when the theme has no assets/ dir.
# SM315: say how many assets were mirrored, and where they were expected.
#
# This returned nothing and no-opped silently when the theme had no `assets/`
# directory. Put a theme's CSS one level higher - at `themes/<theme>/` beside
# theme.json, which is where an author who has not dissected a working layout
# will naturally put it - and: the upload succeeds, activate_layout returns
# ok:1, the mirror is empty, `theme_assets` resolves to nothing, the stylesheet
# link is never emitted, and every page returns 200 completely unstyled.
#
# Measured on edge/0.10.9 while authoring a layout. The diagnosis took a
# screenshot: at the HTTP level a fully unstyled site is indistinguishable from a
# working one, and an agent building over MCP and WebDAV has no screenshot step.
# It would hand over an unstyled site reporting success.
#
# The tool already knew. It counted nothing and said nothing, and zero assets for
# a theme that declares colours and fonts is almost always a mistake - so the one
# place that can say so is the acknowledgement the caller is already reading.
# SM352: render the theme's config as CSS custom properties into the mirror.
#
# A DELIBERATE SECOND IMPLEMENTATION of the processor's generate_theme_css, and
# it is pinned by t/lint/61 rather than shared - the render path loads no
# Lazysite modules (ADR 0001), the same constraint that gives the security
# headers and the private-store path their pinned copies. The escaping in
# particular must not drift: a theme value reaching a stylesheet unescaped is a
# theme author writing CSS the engine did not sanction.
sub _write_theme_tokens {
    my ( $tdir, $dest ) = @_;
    my $tj = "$tdir/theme.json";
    return 0 unless -f $tj && -d $dest;

    my $raw = do {
        open my $fh, '<:utf8', $tj or return 0;
        local $/;
        <$fh>;
    };
    my $data = eval { JSON::PP->new->decode($raw) };
    return 0 unless ref $data eq 'HASH' && ref $data->{config} eq 'HASH';

    my @lines;
    for my $group ( sort keys %{ $data->{config} } ) {
        my $gv = $data->{config}{$group};
        next unless ref $gv eq 'HASH';
        next unless $group =~ /^[A-Za-z0-9_-]+$/;
        for my $key ( sort keys %$gv ) {
            next if ref $gv->{$key};
            next unless $key =~ /^[A-Za-z0-9_-]+$/;
            ( my $safe = $gv->{$key} ) =~ s/[;{}<>]//g;
            push @lines, "  --theme-$group-$key: $safe;";
        }
    }
    return 0 unless @lines;

    my $out = "/* generated from theme.json - do not edit (SM352) */\n"
        . ":root {\n" . join( "\n", @lines ) . "\n}\n";
    open my $of, '>:utf8', "$dest/theme-tokens.css" or return 0;
    print {$of} $out;
    close $of;
    return scalar @lines;
}

# SM315/SM322: the sentence a caller gets when a theme published no assets.
# Both the site-wide activate and the per-domain bind report it, in the same
# words bar the subject they are talking about: $lead opens it, $tail says what
# the consequence is. The middle - the reason, where the assets should have
# been, and any found outside it - is the mirror's own answer and is identical
# on both paths.
sub _mirror_warning {
    my ( $mirror, $lead, $tail ) = @_;
    return
        $lead
        . ( $mirror->{reason} // 'unknown' )
        . ( $mirror->{expected} ? ". Assets belong in $mirror->{expected}" : '' )
        . ( $mirror->{misplaced}
        ? ' (found outside it: ' . join( ', ', @{ $mirror->{misplaced} } ) . ')'
        : '' )
        . '. '
        . $tail;
}

# SM820: MIRROR EVERY THEME THE LAYOUT CARRIES, not only the activated one.
#
# A per-page `theme:` (SM120) resolves through `theme_assets` to
# /lazysite-assets/<layout>/<theme>/, and that mirror is written only when a
# theme is ACTIVATED, a layout is installed, or a package is applied. So a theme
# that is present, compatible and has simply never been the active one has no
# mirror, and a page pinning it links stylesheets that 404: measured on edge as a
# page with background rgba(0,0,0,0) in Times New Roman. Not degraded, unstyled.
#
# The asymmetry is what made it a defect rather than a limitation: a MISSPELT
# theme name already fell back safely - resolve_theme returns nothing and the
# processor uses the layout's default mirror - while a correct-but-unmirrored name
# failed silently to no styling. The safer outcome was going to the more obviously
# wrong input.
#
# WHY THIS RATHER THAN THE TWO OBVIOUS FIXES. Mirroring on REFERENCE puts a file
# write on the render path, and the render can be triggered by an anonymous
# visitor - a side effect that becomes a security question later. Resolving
# `theme_assets` to the theme SOURCE instead would make lazysite/layouts/
# web-reachable, and that tree is excluded from the canonical serve by SM795,
# where a symlink into lazysite/ served the session secret as an image. Mirroring
# every theme touches neither the render path nor that boundary: it is the same
# idempotent per-theme function, called for more themes, at the moments it is
# already called.
#
# NOT COMPLETE, and worth saying: a theme uploaded over WebDAV after the last
# activation still has no mirror until the next activation, install or apply.
# That is a smaller gap than the one this closes and it is the honest state.
sub _mirror_layout_themes {
    my ($layout) = @_;
    return { themes => 0, mirrored => 0 } unless defined $layout && length $layout;

    my $dir = "$LAZYSITE_DIR/layouts/$layout/themes";
    opendir my $dh, $dir
        or return { themes => 0, mirrored => 0, reason => 'no themes directory' };
    my @themes = sort grep { /^[A-Za-z0-9_-]+\z/ && -d "$dir/$_" } readdir $dh;
    closedir $dh;

    my %results;
    $results{$_} = _mirror_theme_assets( $layout, $_ ) for @themes;
    my $done = grep { ( $results{$_}{mirrored} // 0 ) > 0 } keys %results;

    return { themes => scalar @themes, mirrored => $done, results => \%results };
}

# SM830: ONE CACHE KEY FOR EVERYTHING IN A MIRROR, computed where the mirror is
# written and read where a page is rendered.
#
# The tokens link keys on its own file's hash (the processor's
# _asset_fingerprint). main.css and the rest are linked by LAYOUT templates,
# which had nothing but the engine version to key on - so an edited theme kept
# being served from every browser's cache until the next release. This is the
# theme's own version: the first 12 hex of a sha256 over every file in the
# mirror, by relative name and content, so it moves when and only when the
# bytes do - not on a re-activation that rewrites identical files. The render
# path reads it as [% theme_version %]; hashing the files there instead would
# put a font's worth of reading on every uncached render.
sub _write_mirror_fingerprint {
    my ($dir) = @_;
    my @files;
    File::Find::find( { no_chdir => 1, wanted => sub { push @files, $File::Find::name if -f $File::Find::name } },
        $dir );
    my $sha = Digest::SHA->new(256);
    for my $f ( sort @files ) {
        ( my $rel = $f ) =~ s{\A\Q$dir\E/}{};
        next if $rel eq '.fingerprint';
        $sha->add("$rel\0");
        $sha->addfile( $f, 'b' );
        $sha->add("\0");
    }
    my $hex = substr( $sha->hexdigest, 0, 12 );
    if ( open my $fh, '>', "$dir/.fingerprint" ) {
        print {$fh} "$hex\n";
        close $fh;
        return $hex;
    }
    log_event( 'WARN', $action, 'theme mirror fingerprint not written - its pages key on the engine version',
        dir => $dir, error => "$!" );
    return undef;
}

sub _mirror_theme_assets {
    my ( $layout, $theme ) = @_;
    return { mirrored => 0, reason => 'no layout or theme named' }
        unless length $layout && length $theme;

    my $tdir = "$LAZYSITE_DIR/layouts/$layout/themes/$theme";
    my $src  = "$tdir/assets";
    my $dest = "$DOCROOT/lazysite-assets/$layout/$theme";

    unless ( -d $src ) {
        # Is there something that LOOKS like a misplaced asset? A .css or .js
        # sitting directly in the theme directory beside theme.json is almost
        # certainly meant to be served, and naming it costs one directory read.
        my @misplaced;
        if ( opendir my $dh, $tdir ) {
            @misplaced = sort grep { /\.(?:css|js|woff2?|ttf|png|jpe?g|svg|webp)\z/i }
                readdir $dh;
            closedir $dh;
        }
        return {
            mirrored => 0,
            dest     => $dest,
            expected => $src,
            ( @misplaced ? ( misplaced => \@misplaced ) : () ),
            reason => (
                @misplaced
                ? 'the theme has files that look like assets, but they are not '
                    . "in assets/ - the engine mirrors $src and nothing else, so "
                    . 'the site will render unstyled'
                : 'the theme declares no assets/ directory'
            ),
        };
    }

    # SM756: the mirror is what every browser fetches main.css from. Build the
    # new one beside it and switch it in, so no request fetches half a theme.
    my $staging = _staging_for($dest);
    system( 'rm', '-rf', $staging ) if -e $staging;
    make_path( dirname($dest) ) unless -d dirname($dest);
    my $rc = system( 'cp', '-r', $src, $staging );
    if ( $rc != 0 ) {
        system( 'rm', '-rf', $staging );
        log_event( 'WARN', $action, 'theme asset mirror failed',
            layout => $layout, theme => $theme, rc => ( $rc >> 8 ) );
        return { mirrored => 0, dest => $dest, expected => $src,
            reason => 'the copy into the web asset mirror failed' };
    }
    # SM1335: what SM1303 refuses in an archive is refused in a source too. A
    # source write now re-mirrors on its own, so this copy runs far more often
    # than an activation did, and a link placed in a theme's assets/ by any
    # means (a shell, a restore) would be copied into the public mirror as a
    # link - to anything the web server can read. Nothing is switched in.
    if ( my $bad = _mirror_unsafe_entry($staging) ) {
        system( 'rm', '-rf', $staging );
        log_event( 'WARN', $action, 'theme asset mirror refused',
            layout => $layout, theme => $theme, entry => $bad );
        return { mirrored => 0, dest => $dest, expected => $src,
            reason => "the theme's assets/ holds $bad, which a served mirror may not carry "
                . '(a symbolic link, or a file type the web server would run); '
                . 'remove it from the source and the mirror follows' };
    }
    _write_theme_tokens( $tdir, $staging );
    _write_mirror_fingerprint($staging);
    my ( $sw_ok, $sw_err ) = _swap_in( $staging, $dest, undef );
    unless ($sw_ok) {
        system( 'rm', '-rf', $staging );
        log_event( 'WARN', $action, 'theme asset mirror switch failed',
            layout => $layout, theme => $theme, error => $sw_err );
        return { mirrored => 0, dest => $dest, expected => $src,
            reason => 'the web asset mirror could not be switched in' };
    }

    # Count what is actually THERE now, rather than what we believed we copied.
    # A count of intentions is the thing this filing exists to stop.
    my $n = 0;
    File::Find::find(
        { no_chdir => 1, wanted => sub { $n++ if -f $File::Find::name } },
        $dest ) if -d $dest;

    # SM352: the theme's CSS custom properties, written as a FILE beside the
    # assets they belong with.
    #
    # These were an inline <style> block on every page - the last one on the
    # site side, and the one that looked like it needed a nonce because its
    # content is per-theme rather than fixed. It does not: the values come from
    # theme.json, so they are the same on every page of every domain this
    # instance serves, and a file in the theme's own mirror is exactly the right
    # place for them.
    #
    # NO FLASH. A <link> in <head> blocks paint until it loads, which is what
    # makes this safe where moving a SCRIPT prelude out of head would not be -
    # scripts and stylesheets fail differently, and conflating them is what made
    # this look like the hard case. (SM756: written into the staged mirror
    # above, so it switches in with the assets it belongs with.)

    # SM734: and into every content root this instance serves, because a domain
    # with one serves /lazysite-assets/ from THERE and never sees the docroot
    # copy. Reported from the field: 200 on the docroot host, 404 on the
    # content-root host, for every theme.
    #
    # A failure here does NOT fail the activation. The docroot mirror is
    # already written and the primary host works; a content root that cannot be
    # written is a per-domain fault, and refusing the whole activation would
    # take a working site down for a broken sibling. It is reported instead, so
    # the acknowledgement the operator is already reading says which domain did
    # not get its assets.
    my ( @also, @failed );
    for my $cr ( _all_content_roots() ) {
        my $cdest = "$DOCROOT/$cr/lazysite-assets/$layout/$theme";
        eval {
            # SM756: the same build-beside-and-switch as the docroot mirror.
            my $cstage = _staging_for($cdest);
            system( 'rm', '-rf', $cstage ) if -e $cstage;
            make_path( dirname($cdest) ) unless -d dirname($cdest);
            my $crc = system( 'cp', '-r', $dest, $cstage );
            die "cp exited $crc\n" if $crc != 0;
            my ( $cok, $cerr ) = _swap_in( $cstage, $cdest, undef );
            unless ($cok) { system( 'rm', '-rf', $cstage ); die "$cerr\n" }
            push @also, $cr;
            1;
        } or push @failed, $cr;
    }

    return {
        mirrored => $n,
        dest     => $dest,
        expected => $src,
        ( @also   ? ( also_mirrored => \@also )   : () ),
        ( @failed ? ( mirror_failed => \@failed ) : () ),
    };
}

# SM1335: the first entry under $dir a served mirror may not carry - a symbolic
# link, or a file type the web server would run (SM1303's two archive checks) -
# relative to $dir, or undef. Links are listed and never followed.
sub _mirror_unsafe_entry {
    my ($dir) = @_;
    my @bad;
    File::Find::find( { no_chdir => 1, wanted => sub {
                my $p = $File::Find::name;
                return if $p eq $dir;
                push @bad, $p if -l $p || ( -f _ && $p =~ $Lazysite::Manager::Common::DANGEROUS_RE );
    } }, $dir );
    return undef unless @bad;
    ( my $rel = ( sort @bad )[0] ) =~ s{\A\Q$dir\E/}{};
    return $rel;
}

# SM1335 (ruling 81): A THEME'S MIRRORS FOLLOW ITS SOURCE.
#
# A theme has one source, lazysite/layouts/<L>/themes/<T>/, and one served copy
# per host that serves /lazysite-assets/ from its own root: the docroot's, and
# one under each content root (SM734). The copies were written at activation,
# apply, domain-add and creation, and at no other time - so an edit to a theme a
# page pins (SM120) and nobody activates never reached a visitor (the 04/11
# filing: a fix PUT to clarity's main.css, the pinned pages still on the old
# bytes), and a secondary domain kept the copy made the day its theme was
# created (the 05/11 filing: six photographs uploaded twice, neither upload
# reaching the copy harmony2050.org serves).
#
# So a write to a theme's source - whichever surface made it - re-mirrors THAT
# theme to every host's copy, through _mirror_theme_assets, the one function
# every other mirror is written by: the same build-beside-and-switch (SM756),
# tokens (SM352) and fingerprint (SM830), and the same refusal of a link
# (above). A theme whose source is gone takes its copies with it. And the pages
# rendered with it are dropped from the cache, so the next request renders them
# against the new copy - whether the theme is a host's own or a page's pin.
#
# A write to a layout's own files (layout.tt, layout.json, strings/) has no
# mirror to refresh; its pages are dropped the same way (T-38 §1: a pinned
# layout's pages kept their old render until each page was re-PUT).
#
# BOUNDED: one theme per theme written, however many files the write carried,
# never the whole site's themes. Which pages "use" a theme is read from the
# renders themselves: a render links its theme's copy by path
# (/lazysite-assets/<L>/<T>/), so the cache holds the answer the processor gave
# - the host's theme, a page's pin or a section's (SM812) alike - without
# re-deciding precedence here. A render on a layout that resolved no theme and
# has no default theme links no copy and is not found; it is also a render the
# theme write cannot have changed.
#
# Callable from any surface: the docroot is passed, and every package variable
# the mirror reads is set for the call. Returns { themes => [L/T...], layouts =>
# [L...], copies => n, pages_invalidated => n }, or undef when no rel names a
# layout's source.
sub follow_source_write {
    my ( $docroot, @rels ) = @_;
    my ( %themes, %layouts );
    for my $rel (@rels) {
        next unless defined $rel;
        ( my $r = $rel ) =~ s{^/+}{};
        my ( $l, $rest ) = $r =~ m{\Alazysite/layouts/([A-Za-z0-9_-]+)(?:/(.*))?\z} or next;
        $rest //= '';
        if ( $rest =~ m{\Athemes/([A-Za-z0-9_-]+)(?:/|\z)} ) { $themes{"$l/$1"} = 1 }
        elsif ( $rest ne 'themes' ) { $layouts{$l} = 1 }
    }
    return undef unless %themes || %layouts;

    local $DOCROOT      = length( $docroot // '' ) ? $docroot : $DOCROOT;
    local $LAZYSITE_DIR = _lz();
    no warnings 'once';
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;

    my ( $copies, $pages ) = ( 0, 0 );
    for my $lt ( sort keys %themes ) {
        my ( $l, $t ) = split m{/}, $lt;
        if ( -d "$LAZYSITE_DIR/layouts/$l/themes/$t" ) {
            my $m = _mirror_theme_assets( $l, $t );
            $copies += ( $m->{mirrored} ? 1 : 0 ) + scalar @{ $m->{also_mirrored} || [] };
            log_event( 'WARN', $action, 'theme source written, mirror not refreshed',
                layout => $l, theme => $t, reason => $m->{reason} // '' )
                if !$m->{mirrored} && -d "$LAZYSITE_DIR/layouts/$l/themes/$t/assets";
        }
        else {
            _remove_theme_mirrors( $l, $t );
        }
        # A layout written in the same call sweeps all its pages below.
        $pages += _invalidate_pages_using( $l, $t ) unless $layouts{$l};
    }
    for my $l ( sort keys %layouts ) {
        _remove_theme_mirrors( $l, undef ) unless -d "$LAZYSITE_DIR/layouts/$l";
        $pages += _invalidate_pages_using( $l, undef );
    }
    log_event( 'INFO', $action, 'theme source followed',
        themes => join( ',', sort keys %themes ), layouts => join( ',', sort keys %layouts ),
        copies => $copies,                        pages_invalidated => $pages );
    return { themes => [ sort keys %themes ], layouts => [ sort keys %layouts ],
        copies => $copies, pages_invalidated => $pages };
}

# Every host's copy of a theme (or, with no theme, of a layout's themes): the
# docroot's and one under each content root, as _mirror_theme_assets writes them.
sub _mirror_copy_dirs {
    my ( $layout, $theme ) = @_;
    my $tail = "lazysite-assets/$layout" . ( defined $theme ? "/$theme" : '' );
    return ( "$DOCROOT/$tail", map { "$DOCROOT/$_/$tail" } _all_content_roots() );
}

sub _remove_theme_mirrors {
    my ( $layout, $theme ) = @_;
    for my $d ( grep { -d } _mirror_copy_dirs( $layout, $theme ) ) {
        system( 'rm', '-rf', $d ) == 0
            or log_event( 'WARN', $action, 'stale theme mirror not removed', path => $d );
    }
    return;
}

# The cached renders that link a theme's copy (or, with no theme, any copy under
# the layout): the content tree's renders beside their sources, and every alias
# host's slot (SM110). Returns how many were removed.
sub _invalidate_pages_using {
    my ( $layout, $theme ) = @_;
    my $mark = defined $theme
        ? qr{/lazysite-assets/\Q$layout\E/\Q$theme\E[/"'?]}
        : qr{/lazysite-assets/\Q$layout\E/};
    my $n    = 0;
    my $drop = sub {
        my ($f) = @_;
        open my $fh, '<:raw', $f or return;
        my $body = do { local $/; <$fh> };
        close $fh;
        $n++ if defined $body && $body =~ $mark && unlink $f;
    };
    File::Find::find( {
            no_chdir => 1,
            preprocess => sub { grep { !( $_ eq 'lazysite' || $_ eq 'lazysite-assets' ) || !-d "$File::Find::dir/$_" } @_ },
            wanted => sub {
                my $f = $File::Find::name;
                return unless $f  =~ /\.html\z/ && -f $f;
                ( my $base = $f ) =~ s/\.html\z//;
                $drop->($f) if _cache_source_exists($base);
            },
        },
        $DOCROOT
    ) if -d $DOCROOT;
    my $hosts = _lz() . '/cache/hosts';
    File::Find::find( { no_chdir => 1, wanted => sub {
                $drop->($File::Find::name) if $File::Find::name =~ /\.html\z/ && -f $File::Find::name;
    } }, $hosts ) if -d $hosts;
    return $n;
}

# SM1339 (ruling 81): IS THIS PATH A SERVED COPY, AND WHOSE?
#
# A docroot-relative path under a host's /lazysite-assets/ (the docroot's, or
# one under a content root) answers:
#   level 'theme'  - inside <L>/<T>/ of a theme whose source is installed;
#   level 'layout' - <L>/ itself, or a file directly in it, for an installed L;
#   level 'root'   - the lazysite-assets folder itself.
# with the layout and theme, the content root it is under ('' for the docroot),
# the source path an edit belongs in, and the hosts that serve that root, each
# with whether the theme is the one active there. Anything else - a copy of a
# theme no longer installed, a remote layout's bundle, a path that is no
# host's - is undef: it is not a copy of any source, and removing it is cleanup.
#
# $ctx (optional) carries the content roots and domain rows across calls, so a
# listing reads the configuration once.
sub served_mirror {
    my ( $docroot, $rel, $ctx ) = @_;
    ( my $r = $rel // '' ) =~ s{^/+|/+$}{}g;
    return undef unless $r =~ m{(?:\A|/)lazysite-assets(?:/|\z)};
    local $DOCROOT      = length( $docroot // '' ) ? $docroot : $DOCROOT;
    local $LAZYSITE_DIR = _lz();
    $ctx ||= {};
    $ctx->{roots} ||= [ _all_content_roots() ];

    for my $root ( sort { length $b <=> length $a } ( '', @{ $ctx->{roots} } ) ) {
        my $pre = length $root ? "$root/lazysite-assets" : 'lazysite-assets';
        next unless $r eq $pre || index( $r, "$pre/" ) == 0;
        my $tail = substr( $r, length $pre );
        $tail =~ s{\A/}{};
        my ( $l, $t, $sub ) = split m{/}, $tail, 3;
        my %m = ( root => $root );
        if ( !length( $l // '' ) ) {
            %m = ( %m, level => 'root',
                source => 'lazysite/layouts/<layout>/themes/<theme>/assets/' );
        }
        elsif ( !-d "$LAZYSITE_DIR/layouts/$l" ) {
            return undef;
        }
        elsif ( !defined $t || !-d "$LAZYSITE_DIR/layouts/$l/themes/$t" ) {
            # <L>/ itself, or a file in it; a folder named for a theme that is
            # no longer installed is an orphan copy, and not a served one.
            return undef if defined $t && ( defined $sub || -d "$DOCROOT/$r" );
            %m = ( %m, level => 'layout', layout => $l,
                source => "lazysite/layouts/$l/themes/<theme>/assets/" );
        }
        else {
            my $src = "lazysite/layouts/$l/themes/$t";
            %m = ( %m, level => 'theme', layout => $l, theme => $t,
                source => !defined $sub ? "$src/assets/"
                : $sub eq 'theme-tokens.css' ? "$src/theme.json"
                : $sub eq '.fingerprint'     ? "$src/assets/"
                :                              "$src/assets/$sub" );
        }
        $m{hosts} = _hosts_serving( $root, $m{layout}, $m{theme}, $ctx );
        return \%m;
    }
    return undef;
}

# The hosts whose /lazysite-assets/ is served from $root, each with whether the
# theme is the one active there. A host serves from its effective content_root
# (its own, else the base's, else the docroot), as _host_content_root reads it.
sub _hosts_serving {
    my ( $root, $layout, $theme, $ctx ) = @_;
    no warnings 'once';
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
    $ctx->{rows} ||= eval { Lazysite::Manager::Domains::domains_list()->{domains} } || [];
    my @out;
    for my $d ( @{ $ctx->{rows} } ) {
        ( my $cr = $d->{content_root} // '' ) =~ s{^/+|/+$}{}g;
        next unless $cr eq $root;
        my $host = $d->{host} // '';
        if ( $d->{is_primary} ) {
            my $url = $d->{site_url} // '';
            $host = $url !~ /\$\{/ && $url =~ m{^https?://([^/:?#]+)}i ? lc $1 : '(default)';
        }
        push @out, {
            host => $host,
            ( $d->{is_primary} ? ( primary => JSON::PP::true ) : () ),
            ( defined $theme
                ? ( theme_active => ( ( $d->{layout} // '' ) eq $layout && ( $d->{theme} // '' ) eq $theme )
                    ? JSON::PP::true : JSON::PP::false )
                : () ),
        };
    }
    return \@out;
}

sub _validate_theme_dir {
    my ( $dir, $layout ) = @_;
    my $tj = "$dir/theme.json";
    return { valid => 0, errors => ['theme.json missing'] } unless -f $tj;
    open my $fh, '<:utf8', $tj
        or return { valid => 0, errors => ['theme.json unreadable'] };
    my $raw = do { local $/; <$fh> };
    close $fh;
    my $data = eval { decode_json($raw) };
    my @err;
    if ( ref $data ne 'HASH' ) {
        my $why = $@ ? do { ( my $e = $@ ) =~ s/\s+at \S+ line \d+.*//s; $e =~ s/\s+$//; $e }
            :   'top level is not a JSON object';
        push @err, "theme.json invalid: $why";
    }
    elsif ( ref $data->{layouts} ne 'ARRAY' || !@{ $data->{layouts} } ) {
        push @err, 'theme.json layouts[] missing or empty';
    }
    elsif ( !grep { $_ eq $layout } @{ $data->{layouts} } ) {
        push @err, "theme not declared for active layout '$layout'";
    }
    return { valid => ( @err ? 0 : 1 ), errors => \@err };
}

# Strip a trailing -backup-<ts> so a backup OF a backup groups under the original
# base name instead of chaining (foo-backup-T1-backup-T2-backup-T3...).
sub _backup_base {
    ( my $base = $_[0] ) =~ s/-backup-\d{8}T\d{6}Z\z//;
    return $base;
}

# Every snapshot of $base under $parent, oldest first: the timestamps sort
# lexically, so the last is the newest. The scan is written once - the "which is
# the latest" and "which are past retention" questions are the same readdir.
sub _backup_dirs {
    my ( $parent, $base ) = @_;
    opendir my $dh, $parent or return ();
    my @b = sort grep { /^\Q$base\E-backup-/ && -d "$parent/$_" } readdir $dh;
    closedir $dh;
    return @b;
}

sub _latest_backup_dir {
    my ( $parent, $base ) = @_;
    my @b = _backup_dirs( $parent, $base );
    return @b ? "$parent/$b[-1]" : undef;
}

# SM176: a per-theme "pristine" baseline - the artifact digest captured at
# install. Stored as a dotfile in the themes dir (skipped by the theme listing
# and by the backup scan) and OUTSIDE the theme dir, so it never perturbs the
# theme's own digest. A theme whose current digest still equals this baseline has
# no operator edits, so switching away from it must not spawn a backup.
sub _pristine_path { return "$_[0]/.pristine-$_[1]" }

sub _write_pristine {
    my ( $parent, $name, $digest ) = @_;
    return unless defined $digest && $digest =~ /\A[0-9a-f]{64}\z/;
    if ( open my $fh, '>', _pristine_path( $parent, $name ) ) {
        print {$fh} "$digest\n";
        close $fh;
    }
    return;
}

sub _read_pristine {
    my ( $parent, $name ) = @_;
    open my $fh, '<', _pristine_path( $parent, $name ) or return undef;
    my $d = <$fh>;
    close $fh;
    chomp $d if defined $d;
    return ( defined $d && $d =~ /\A[0-9a-f]{64}\z/ ) ? $d : undef;
}

# SM756 split this into the DECISION (is a snapshot wanted, and where) and the
# copy, because the atomic switch below keeps the old directory by RENAMING it
# to the snapshot name rather than copying first and overwriting after. Same
# rules, one place: no snapshot of a pristine artefact (SM176), none when the
# last snapshot already holds this content.
sub _snapshot_wanted {
    my ( $parent, $name ) = @_;
    my $src = "$parent/$name";
    return undef unless -d $src;
    my $base     = _backup_base($name);
    my $cur      = _artifact_digest($src);
    my $pristine = _read_pristine( $parent, $name );
    return undef if defined $pristine && $pristine eq $cur;
    if ( my $latest = _latest_backup_dir( $parent, $base ) ) {
        return undef if $latest ne $src && $cur eq _artifact_digest($latest);
    }
    my $dst = "$parent/$base-backup-" . strftime( '%Y%m%dT%H%M%SZ', gmtime );
    return undef if -e $dst;
    return $dst;
}

sub _snapshot_artifact {
    my ( $parent, $name ) = @_;
    my $dst = _snapshot_wanted( $parent, $name ) or return;
    system( 'cp', '-r', "$parent/$name", $dst );
}

# SM756: THE SWITCH. A new version of an artefact that is being served is built
# BESIDE it and switched in with rename(2), never written into it.
#
# The release manager's ruling: "nothing works on an active theme or layout,
# they load new and switch in. it should be atomic, and common on all
# surfaces." SM749 closed every file write into the active artefact; the two
# whole-artefact paths - a theme upload with update, a layout install with
# force - still `cp -r`'d over the directory being rendered, which is a
# sequence of file replacements and a request between two of them renders half
# of each. The mirror the browsers fetch from was written the same way, by
# activation itself.
#
# Two renames: the old directory steps aside, the staged one takes its name.
# A path lookup between them finds nothing for a microsecond and falls back;
# it never finds a mixture, which is the property that matters. A rename is
# atomic within one filesystem, and staging is always a sibling of its target.
# The old directory is kept under the snapshot name when a snapshot is wanted
# (an edited theme) and removed otherwise (a pristine one, SM176) - so the
# snapshot IS the previous directory, not a copy of it.
#
# Returns ( 1 ) or ( 0, $error ). On a failed second rename the old directory
# is put back, so a failure leaves the site as it was.
sub _swap_in {
    my ( $staging, $target, $keep_old_as ) = @_;
    my $aside = "$target.swap-out.$$";
    if ( -e $target ) {
        rename $target, $aside
            or return ( 0, "cannot move the current version aside: $!" );
    }
    unless ( rename $staging, $target ) {
        my $e = $!;
        rename $aside, $target if -e $aside;
        return ( 0, "cannot switch the new version in: $e" );
    }
    if ( -e $aside ) {
        if ( defined $keep_old_as ) {
            rename $aside, $keep_old_as
                or system( 'rm', '-rf', $aside );    # cannot keep it: do not leave it
        }
        else {
            system( 'rm', '-rf', $aside );
        }
    }
    return (1);
}

# The staging name for an artefact directory: a sibling, so the rename stays
# on one filesystem, and named so a listing reader can tell it is in flight.
sub _staging_for { return "$_[0].installing.$$" }

sub _prune_backups {
    my ( $parent, $name ) = @_;
    my $keep = _backup_retention();
    return if $keep <= 0;    # 0 (or negative) = keep all
    my @backups = _backup_dirs( $parent, _backup_base($name) );
    while ( @backups > $keep ) {
        my $old = shift @backups;
        system( 'rm', '-rf', "$parent/$old" );
    }
}

sub _backup_retention { return Lazysite::Util::backup_retention( _lz() ) } # SM753: the one reader

# The theme a layout should use when none is carried over: its declared
# default_theme if that declares the layout, else the first installed theme that
# declares it, else '' (the layout renders with no theme override).
sub _default_theme_for_layout {
    my ($layout) = @_;
    my $ldir     = "$LAZYSITE_DIR/layouts/$layout";
    my $dt       = _read_layout_json($layout)->{default_theme} // '';
    return $dt if length $dt && _theme_declares_layout( $layout, $dt );
    if ( opendir my $dh, "$ldir/themes" ) {
        for my $name ( sort readdir $dh ) {
            next if $name =~ /^\./ || $name =~ /-backup-\d/;
            next unless $name =~ /^[A-Za-z0-9_-]+$/;
            next unless -f "$ldir/themes/$name/theme.json";
            if ( _theme_declares_layout( $layout, $name ) ) { closedir $dh; return $name }
        }
        closedir $dh;
    }
    return '';
}

sub action_layout_activate {
    my ( $layout_name, $params ) = @_;
    $params ||= {};
    $layout_name =~ s/[^a-zA-Z0-9_-]//g;
    return { ok => 0, error => "Layout name required" } unless length $layout_name;

    my ( $old_layout, $cur_theme ) = _read_active_layout_and_theme();
    my $layout_dir = "$LAZYSITE_DIR/layouts/$layout_name";
    return { ok => 0, error => "Layout not found" } unless -d $layout_dir;

    my $theme = defined $params->{theme} ? $params->{theme} : $cur_theme;
    $theme = '' unless defined $theme;
    $theme =~ s/[^a-zA-Z0-9_-]//g;
    my $theme_specified = ( defined $params->{theme} && length $params->{theme} ) ? 1 : 0;

    my $lock_rel = "lazysite/layouts/$layout_name";
    my $lk       = acquire_lock( $lock_rel, $auth_user );
    unless ( $lk->{ok} ) {
        return { ok => 0, locked => 1, error => "Layout is locked by "
                . ( $lk->{locked_by} // 'another session' ) };
    }

    my $out = eval {
        my $v = _validate_layout_dir($layout_dir);
        return { ok => 0, error => "Layout invalid: " . join( '; ', @{ $v->{errors} } ) }
            unless $v->{valid};
        my $renders = $v->{renders} || {};

        # Compatible (layout, theme) pair. The live theme name is carried over by
        # default; if it isn't declared for the NEW layout, only refuse when the
        # caller explicitly named it - otherwise fall back to the new layout's own
        # default theme so the switch still succeeds (was: a hard error that made a
        # layout unselectable unless it happened to have a same-named theme).
        if ( length $theme && !_theme_declares_layout( $layout_name, $theme ) ) {
            if ($theme_specified) {
                return { ok => 0, incompatible => 1,
                    error => "Theme '$theme' is not declared for layout '$layout_name'"
                        . " - name a compatible theme to switch to" };
            }
            $theme           = _default_theme_for_layout($layout_name);
            $theme_specified = 1 if length $theme;
        }

        if ( defined $params->{base} && length $params->{base} ) {
            return { ok => 0, conflict => 1,
                error => "Layout changed since the supplied base manifest" }
                if _artifact_digest($layout_dir) ne $params->{base};
        }

        if ( length $old_layout && $old_layout ne $layout_name ) {
            _snapshot_artifact( "$LAZYSITE_DIR/layouts", $old_layout );
            _prune_backups( "$LAZYSITE_DIR/layouts", $old_layout );
        }
        my $res = _set_layout_pointer( $layout_name,
            ( $theme_specified && length $theme ) ? $theme : undef );
        if ( $res->{ok} ) {
            _mirror_theme_assets( $layout_name, ( length $theme ? $theme : $cur_theme ) );
            _mirror_layout_themes($layout_name);    # SM820
        }

        # SM337: say what was bound, not merely that something was.
        if ( $res->{ok} ) {
            $res->{renders} = $renders;
            unless ( $renders->{nav} ) {
                # A WARNING, not a refusal. Activating a showcase layout is a
                # legitimate choice; being unable to tell that you have is not.
                $res->{warning} =
                    "'$layout_name' does not render the site's navigation - "
                    . 'it has no [% nav %], so nav.conf will have no effect on '
                    . 'pages using it. Activated anyway; this is a note, not a '
                    . 'refusal.';
            }

            # SM1378: and whether this engine is the one the layout was
            # written for. Beside the nav note when there is one, so a caller
            # that already shows `warning` shows both.
            my ( $requires, $engine_note ) =
                layout_engine_requirement( $layout_dir, $LAZYSITE_DIR );
            $res->{requires} = { lazysite => $requires } if defined $requires;
            $res->{warning}  = join ' ', grep { defined } $res->{warning}, $engine_note
                if defined $engine_note;
        }
        return $res;
    };
    my $err = $@;
    release_lock( $lock_rel, $auth_user );
    die $err if $err;
    return $out;
}

sub _set_layout_pointer {
    my ( $layout, $theme ) = @_;
    my $conf_path = _lz() . "/lazysite.conf";
    return { ok => 0, error => "Cannot read conf" } unless -f $conf_path;
    open my $fh, '<:utf8', $conf_path or return { ok => 0, error => "Cannot read conf" };
    my $conf = do { local $/; <$fh> };
    close $fh;
    if ( $conf =~ /^layout\s*:/m ) { $conf =~ s/^layout\s*:.*$/layout: $layout/m }
    else                           { $conf .= "\nlayout: $layout\n" }
    if ( defined $theme ) {
        if ( $conf =~ /^theme\s*:/m ) { $conf =~ s/^theme\s*:.*$/theme: $theme/m }
        else                          { $conf .= "\ntheme: $theme\n" }
    }
    my ( $wok, $werr ) = _write_conf_content( $conf,
        "activate layout $layout" . ( defined $theme ? " with theme $theme" : '' ) );
    return { ok => 0, error => "Cannot write conf: $werr" } unless $wok;
    _invalidate_html_cache();
    return { ok => 1, layout => $layout, ( defined $theme ? ( theme => $theme ) : () ) };
}

# SM1378 (ruling 133, triage T-31): THE ENGINE A LAYOUT SAYS IT NEEDS.
#
# The catalogue writes `"requires": { "lazysite": "0.15.11" }` in every
# layout.json - the lowest release whose variables and filters the template
# uses - and nothing read it, so a layout installed on an older engine said
# ok:1 and then failed or degraded at render time (an unknown filter is a
# template error). This reads it, beside SM337's nav check and in its manner:
# a WARNING naming the consequence, never a refusal. An operator may install
# ahead of an upgrade they are about to make, and a tool that refuses that gets
# worked around.
#
# The running engine is the site's .install-state.json `version`, the same
# value the generator meta and action_version report. Where either side is
# absent (a dev tree with no install state, a layout that declares nothing)
# there is nothing to compare and nothing is said; a declaration that is not a
# version is named, since a layout that meant to say something and could not
# is the case a reader needs to hear about.
#
# $name is the layout as the site will call it (an install reads a release
# unpacked under a temporary name); it defaults to the directory's own.
# Returns ( $requires, $warning ): the declared version (or undef) and a
# sentence (or undef).
sub layout_engine_requirement {
    my ( $layout_dir, $lazysite_dir, $name ) = @_;
    my $meta = _read_json_file("$layout_dir/layout.json");
    return ( undef, undef ) unless ref $meta eq 'HASH' && ref $meta->{requires} eq 'HASH';
    my $want = $meta->{requires}{lazysite};
    return ( undef, undef ) unless defined $want && !ref $want && length $want;
    ( $name = $layout_dir ) =~ s{.*/}{} unless defined $name && length $name;
    return ( $want,
        "'$name' declares requires.lazysite '$want', which is not a version "
            . '(expected X.Y.Z), so the engine it needs cannot be checked.' )
        unless $want =~ /\A\d+(?:\.\d+){0,2}\z/;

    my $state = _read_json_file("$lazysite_dir/.install-state.json");
    my $have  = ref $state eq 'HASH' ? $state->{version} : undef;
    return ( $want, undef ) unless defined $have && $have =~ /\A\d+(?:\.\d+){0,2}/;

    my @w = split /\./, $want;
    my @h = ( $have =~ /\A(\d+)(?:\.(\d+))?(?:\.(\d+))?/ );
    for my $i ( 0 .. 2 ) {
        my ( $x, $y ) = ( $h[$i] // 0, $w[$i] // 0 );
        return ( $want, undef ) if $x > $y;
        last                    if $x < $y;
        return ( $want, undef ) if $i == 2;    # equal: the engine is new enough
    }
    return ( $want,
        "'$name' requires lazysite $want and this site runs $have - pages using "
            . 'it may fail or render without parts of the layout until the engine '
            . 'is upgraded. Done anyway; this is a note, not a refusal.' );
}

sub _validate_layout_dir {
    my ($dir) = @_;
    my $lt = "$dir/layout.tt";
    return { valid => 0, errors => ['layout.tt missing'] } unless -f $lt;
    # SM337: WHAT DOES THIS LAYOUT ACTUALLY RENDER?
    #
    # The source is already open here, so the answer costs a regex. It was not
    # being asked, and the consequence was that installing a layout, activating
    # it, saving a navigation and fetching the page all returned success while
    # the site's own menu was never rendered - 22 of 23 catalogue layouts carry
    # hard-coded links belonging to the theme gallery they were built for, and
    # one of them renders a fictional company name on whatever site activates it.
    #
    # Every signal said it worked, so the only way to find out was to install a
    # layout, bind it to a domain, render a page and look - a step an agent has
    # no reason to insert after four consecutive ok:1 responses.
    #
    # This does not refuse anything. A showcase layout is a legitimate thing to
    # activate and the caller may want exactly that. What changes is that the
    # acknowledgement stops being indistinguishable from binding a working site
    # layout.
    my $src = '';
    if ( open my $fh, '<:utf8', $lt ) {
        local $/;
        $src = <$fh> // '';
        close $fh;
    }

    # The documented contract is `[% nav %]` and `[% content %]`. Matched
    # loosely on the directive name so `[%nav%]`, `[% nav %]` and a filtered
    # `[% nav | ... %]` all count - a layout that renders the navigation
    # through a filter still renders the navigation.
    #
    # SM362 asks the adjacent question and the same read answers it: the engine
    # resolves page_meta_title and page_meta_desc for the layout to use, and
    # every catalogue layout overwrites them, so those two are reported here
    # too rather than needing a second survey.
    #
    # SM911 LD1: THE VARIABLE ANYWHERE IN THE TAG, not only as its first token.
    #
    # This required the name to open the directive, so it missed
    # `[% FOREACH item IN nav %]` - which is the ONLY way to render a multi-item
    # navigation - and it missed `head_title = page_meta_title || page_title`,
    # which is the fallback the layouts briefing's own <head> contract tells
    # authors to write, because page_meta_title alone is empty on a page that
    # sets no meta front matter. So the check punished exactly the two patterns
    # the documentation recommends, and on a live site it reported nav 0,
    # meta_title 0 and meta_desc 0 for a layout whose served page carried five
    # nav items from nav.conf, a resolved title and a resolved description.
    #
    # A false negative here is expensive in a particular way: it tells an author
    # their nav work is inert at the moment they have just done it correctly, so
    # they hunt a bug that is not there or add a literal `[% nav %]` beside the
    # loop to silence it.
    #
    # `[^%]*` keeps the match inside one directive, and `\b` keeps `navbar` and
    # `navigation` out. A TT comment directive is excluded: `[%# nav %]` mentions
    # the variable and renders nothing.
    my $tag_has = sub {
        my ($name) = @_;
        return $src =~ /\[%(?!\#)[^%]*\b\Q$name\E\b/ ? 1 : 0;
    };
    my %renders = (
        nav        => $tag_has->('nav'),
        content    => $tag_has->('content'),
        meta_title => $tag_has->('page_meta_title'),
        meta_desc  => $tag_has->('page_meta_desc'),
    );

    my $ok = eval {
        require Template::Parser;
        my $p = Template::Parser->new( {} );
        $p->parse($src) or die( $p->error . "\n" );
        1;
    };
    return { valid => 1, errors => [], renders => \%renders } if $ok;
    my $e = $@ || 'parse error';
    return { valid => 1, errors => [], renders => \%renders }
        if $e =~ /Can't locate Template/;
    chomp $e;
    return { valid => 0, errors => ["layout.tt does not compile: $e"],
        renders => \%renders };
}

sub _theme_declares_layout {
    my ( $layout, $theme ) = @_;
    my $tj = "$LAZYSITE_DIR/layouts/$layout/themes/$theme/theme.json";
    return 0 unless -f $tj;
    my $data = _read_json_file($tj);
    return 0 unless ref $data eq 'HASH' && ref $data->{layouts} eq 'ARRAY';
    return ( grep { $_ eq $layout } @{ $data->{layouts} } ) ? 1 : 0;
}

# SM861: a name the caller gave is used or refused - never edited.
#
# delete, rename and copy take a name as an IDENTITY: the thing to act on. All
# three ran s/[^a-zA-Z0-9_-]//g over it first, so `Lumen!` silently became
# `Lumen` and the verb acted on a different theme from the one named - on
# delete, a destructive one. Copy and rename additionally lower-cased the
# target, which made half the names the store permits unaddressable: mixed case
# is valid in theme_config_issues, the theme listing lists mixed-case
# directories, and WebDAV creates them, so these verbs were the outliers. A
# tester copying `lumen` to `lumen-1312E-backup-...` got a second lower-case
# theme that did not collide with the mixed-case one already there.
#
# DELIBERATELY NOT APPLIED TO theme-activate / layout-activate. Their strip is
# load-bearing: SM247 depends on a punctuation-only value - the control API
# defaults `path` to '/' - reducing to the empty string, so the deactivation
# guard can name it as a missing parameter with wording written after a live
# site was left unstyled. Refusing on the character would replace that message
# with a validation error and undo the fix.
sub _bad_theme_name {
    my ( $label, $name ) = @_;
    return undef if defined $name && $name =~ /^[A-Za-z0-9_-]+$/;
    return { ok => 0, kind => 'validation', field => $label,
        error => "$label '"
            . ( defined $name ? $name : '' )
            . "' must match [A-Za-z0-9_-]+" };
}

sub action_theme_delete {
    my ( $theme_name, $opts ) = @_;
    $opts ||= {};

    # SM1385: the theme by its path too, as theme-copy takes it (SM1339):
    # lazysite/layouts/<layout>/themes/<name>, the form the theme's own `path`
    # field gives. The bare name still means the active layout's theme (D013),
    # so a theme under any other layout was removable only file by file. A path
    # into a host's served copy (/lazysite-assets/...) is refused as every write
    # into one is, naming the source; any other path is not a theme's.
    my $layout;
    if ( defined $theme_name && $theme_name =~ m{/} ) {
        if ( $theme_name =~ m{\A/*lazysite/layouts/([^/]+)/themes/([^/]+?)/*\z} ) {
            ( $layout, $theme_name ) = ( $1, $2 );
            return { ok => 0, kind => 'validation', field => 'layout',
                error => "layout '$layout' must match [A-Za-z0-9_-]+" }
                unless $layout =~ /^[A-Za-z0-9_-]+$/;
        }
        else {
            ( my $p = $theme_name ) =~ s{^/+}{};
            if ( my ( $err, $why ) = Lazysite::Manager::Common::served_artifact_refusal(
                    $p, docroot => $DOCROOT ) )
            {
                return { ok => 0, kind => 'served-artifact-refused', error => $err,
                    audit_detail => $why };
            }
            return { ok => 0, kind => 'validation', field => 'path',
                error => "'$p' is not a theme: give its name, or its path "
                    . 'lazysite/layouts/<layout>/themes/<name>' };
        }
    }
    if ( my $bad = _bad_theme_name( 'name', $theme_name ) ) { return $bad }

    my ( $active_layout, $active_theme ) = _read_active_layout_and_theme();
    $layout = $active_layout unless defined $layout;
    return { ok => 0, error => "Cannot delete the active theme" }
        if $layout eq $active_layout && $theme_name eq $active_theme;
    return { ok => 0, error => "No active layout set" }
        unless length $layout;

    # SM177: a sub-domain is a first-class peer - if any configured domain uses
    # this theme (under its layout, where it lives), deleting it would
    # break that domain. Block and name them, just as the active-theme guard does
    # for the primary. domains_using resolves effective per-host values, so an
    # alias that inherits the active layout but pins this theme is caught.
    my @in_use = _domains_using( theme => $theme_name, layout => $layout );
    if (@in_use) {
        return { ok => 0,
            error => "Theme '$theme_name' is in use by "
                . join( ', ', @in_use )
                . ". Repoint or remove those domains first." };
    }

    # D013: by name, delete only from the active layout's themes dir; by path
    # (SM1385), from the layout the path names. A theme installed under several
    # layouts (theme.json's layouts[]) has a copy under each, removed one path
    # at a time.
    my $themes_dir = _lz() . "/layouts/$layout/themes";
    my $theme_dir  = "$themes_dir/$theme_name";
    return { ok => 0, error => "Theme not found" } unless -d $theme_dir;

    # SM262: an agent that can create a theme could not remove one, so every
    # experiment it ran was permanent and only the operator could clear it -
    # create-without-delete makes agents into litter generators. The grant is the
    # narrowest that solves that: delete what YOU created, and nothing else. A
    # theme with no created_by predates the field or arrived another way, and is
    # never removable this way, so an agent gains no authority over anything that
    # existed before it did.
    #
    # Applied only when the caller asks for it. The manager UI over a cookie
    # session is a human at the console and keeps the unrestricted delete; the
    # dispatcher sets this for token and MCP clients.
    # SM268 04-F6: provenance comes from a SIDE RECORD, not from theme.json.
    #
    # theme.json lives under lazysite/layouts/**, which the very capability this
    # rule restricts (manage_themes) makes writable through write_file,
    # upload_file and WebDAV - so the restriction was self-certified by data the
    # restricted party controls. An agent rewrote created_by to its own name and
    # deleted any non-active theme on the instance, operator-authored ones
    # included, and the audit line said it had deleted its own.
    #
    # themes-created.json sits in lazysite/auth/, which the blocklist denies on
    # every authoring surface, so the answer is now kept where the caller cannot
    # reach it. theme.json's created_by stays as a description; it is no longer
    # an authorisation. A theme with no side record is never removable this way,
    # which is the same safe reading as before.
    if ( $opts->{restrict_to_creator} ) {
        my $who = $opts->{user} // '';
        my $by  = _theme_creator( $layout, $theme_name );
        unless ( length $who && length $by && $by eq $who ) {
            return { ok => 0, kind => 'not-yours',
                error => "Theme '$theme_name' was not created by this account, so "
                    . 'it cannot be removed over this channel. You may delete '
                    . 'themes you created yourself; anything else is an operator '
                    . 'action from the manager.' };
        }
    }

    my $real = realpath($theme_dir);
    return { ok => 0, error => "Invalid theme path" }
        unless $real && index( $real, $themes_dir ) == 0;

    my $rc = system( "rm", "-rf", $theme_dir );
    if ( $rc != 0 ) {
        log_event( 'ERROR', 'theme-delete', 'rm failed',
            path => $theme_dir, rc => ( $rc >> 8 ) );
        return { ok => 0, error => "Delete failed" };
    }
    # The theme is gone; drop its provenance so a later theme reusing the name
    # does not inherit a creator it never had.
    _forget_theme_creator( $layout, $theme_name );
    # SM1335: its copies go with it - every host's, not only the docroot's, which
    # was the one this removed - and so do the renders that linked them.
    follow_source_write( $DOCROOT, "lazysite/layouts/$layout/themes/$theme_name" );

    return { ok => 1, deleted => $theme_name, layout => $layout,
        path => "lazysite/layouts/$layout/themes/$theme_name" };
}

# SM749: copy a theme, so "copy, edit, activate" is one verb on every surface.
#
# Before this the workflow the active-theme refusal names had no first step: a
# partner could create_theme (scaffolded from the LAYOUT DEFAULT's css, not from
# the theme they wanted to change) and then copy_file one file at a time, and a
# sysop had no button at all. A refusal that names a workflow nobody can
# perform in one move is SM750's defect with extra steps.
#
# Within the active layout, like rename. The copy is a plain directory copy
# plus the asset mirror if one exists; theme.json's name is rewritten so the
# copy does not claim to be its source; the creator registry records the
# copier, so delete_theme's "yours to remove" rule applies to the copy as to a
# theme made by create_theme. Not pristine (SM176): a copy exists to be edited.
sub action_theme_copy {
    my ( $from, $to, $opts ) = @_;
    $opts ||= {};
    # SM1339: the theme by its path too - lazysite/layouts/<layout>/themes/<name>,
    # the form the active-theme refusal and the theme's own `path` field give. A
    # caller that copied it from either was told the name was malformed. The
    # layout it names is the layout, and must agree with `layout` when both are
    # given.
    if ( defined $from && $from =~ m{\A/*lazysite/layouts/([^/]+)/themes/([^/]+?)/*\z} ) {
        my ( $pl, $pt ) = ( $1, $2 );
        return { ok => 0, kind => 'validation', field => 'layout',
            error => "the path names layout '$pl' and layout names '$opts->{layout}'; give one, or the same in both" }
            if defined $opts->{layout} && length $opts->{layout} && $opts->{layout} ne $pl;
        ( $from, $opts ) = ( $pt, { %$opts, layout => $pl } );
    }
    # SM861: validated, not rewritten - and `to` keeps the case it was given.
    # Lower-casing it meant the copy landed somewhere other than where the
    # caller asked, and that the existence check below tested the FOLDED name,
    # so a copy could miss a collision with a mixed-case theme already present.
    if ( my $bad = _bad_theme_name( 'from', $from ) ) { return $bad }
    if ( my $bad = _bad_theme_name( 'to',   $to ) )   { return $bad }
    return { ok => 0, kind => 'validation', error => 'The copy needs a different name' }
        if $from eq $to;

    my ( $active_layout, undef ) = _read_active_layout_and_theme();
    my $layout = $opts->{layout};
    $layout = $active_layout unless defined $layout && length $layout;
    return { ok => 0, kind => 'validation', error => 'No active layout set' }
        unless length $layout;
    return { ok => 0, kind => 'validation',
        error => "layout '$layout' must match [A-Za-z0-9_-]+" }
        unless $layout =~ /^[A-Za-z0-9_-]+$/;

    my $themes_dir = _lz() . "/layouts/$layout/themes";
    return { ok => 0, kind => 'not-found', error => "Theme '$from' not found" }
        unless -d "$themes_dir/$from";
    return { ok => 0, kind => 'exists', error => "Theme '$to' already exists" }
        if -d "$themes_dir/$to";

    my $rc = system( 'cp', '-r', "$themes_dir/$from", "$themes_dir/$to" );
    if ( $rc != 0 ) {
        log_event( 'ERROR', 'theme-copy', 'cp failed',
            from => $from, to => $to, rc => ( $rc >> 8 ) );
        return { ok => 0, error => 'Copy failed' };
    }

    # The copy is its own theme: name it, and say where it came from.
    my $json = "$themes_dir/$to/theme.json";
    if ( -f $json ) {
        my $data = eval {
            open my $fh, '<:utf8', $json or die $!;
            local $/;
            decode_json(<$fh>);
        };
        if ( ref $data eq 'HASH' ) {
            $data->{name}        = $to;
            $data->{copied_from} = $from;
            my $raw = JSON::PP->new->canonical->pretty->encode($data);
            open my $fh, '>:utf8', $json or return { ok => 0, error => 'Copy failed (theme.json)' };
            print {$fh} $raw;
            close $fh;
        }
    }

    # SM1336: the copy's mirror is written as every mirror is, from its own
    # source - tokens, fingerprint and every host's copy. This copied the
    # docroot's mirror of the theme it came from, so the copy had no copy on a
    # secondary domain at all, and none anywhere if its source had never been
    # mirrored.
    _mirror_theme_assets( $layout, $to );

    my $user = ( defined $auth_user && length $auth_user ) ? $auth_user : 'unknown';
    _record_theme_creator( $layout, $to, $user );

    log_event( 'INFO', 'theme-copy', 'theme copied',
        layout => $layout, from => $from, to => $to, user => $user );
    return {
        ok     => 1,
        layout => $layout,
        from   => $from,
        name   => $to,
        path   => "lazysite/layouts/$layout/themes/$to",
        next => "edit the copy, then activate it: activate_theme / theme-activate '$to'",
    };
}

sub action_theme_upload {
    my ( $zip_data, $filename ) = @_;

    # M-4: use Archive::Zip for safe extraction with per-entry path
    # validation, replacing system("unzip") which had to be trusted not
    # to zip-slip. Archive::Zip is an optional dep - install.sh warns if
    # missing, and this action returns a clear error instead of crashing.
    my $have_azip = eval { require Archive::Zip; Archive::Zip->import(qw(:ERROR_CODES)); 1 };
    unless ($have_azip) {
        return { ok => 0,
            error => "Archive::Zip not installed (apt-get install libarchive-zip-perl)" };
    }

    # SM1303: THE SITE'S UPLOAD LIMIT, as every other way bytes reach the site
    # applies it (file-upload, MCP upload_file). This action had none of its own.
    my $max = Lazysite::Manager::Common::upload_limits()->{max_bytes} // ( 10 * 1024 * 1024 );
    if ( length( $zip_data // '' ) > $max ) {
        return { ok => 0, kind => 'too-large',
            error => sprintf( 'The theme archive is %d bytes; this site takes at most %d (%.0f MB). '
                    . 'Raise manager_upload_max_mb to change it.',
                length($zip_data), $max, $max / ( 1024 * 1024 ) ) };
    }

    my $tmp_dir = "/tmp/lazysite-theme-$$";
    make_path($tmp_dir);

    my $zip_path = "$tmp_dir/upload.zip";
    open my $fh, '>:raw', $zip_path
        or do { _cleanup_tmp($tmp_dir); return { ok => 0, error => "Cannot write upload" } };
    print $fh $zip_data;
    close $fh;

    my $extract_dir = "$tmp_dir/extracted";
    make_path($extract_dir);

    my $extract_real = realpath($extract_dir);
    unless ( defined $extract_real ) {
        _cleanup_tmp($tmp_dir);
        return { ok => 0, error => "Cannot resolve extract dir" };
    }

    my $zip = Archive::Zip->new();
    unless ( $zip->read($zip_path) == Archive::Zip::AZ_OK() ) {
        _cleanup_tmp($tmp_dir);
        return { ok => 0, error => "Cannot read uploaded zip" };
    }

    # Validate every entry before extracting any.
    for my $member ( $zip->members ) {
        my $name = $member->fileName;
        if ( $name =~ m{\A/} ) {
            _cleanup_tmp($tmp_dir);
            return { ok => 0, error => "Zip entry has absolute path: $name" };
        }
        if ( $name =~ m{(?:^|/)\.\.(?:/|$)} ) {
            _cleanup_tmp($tmp_dir);
            return { ok => 0, error => "Zip slip detected in: $name" };
        }

        # SM1303: what WebDAV and upload_file refuse under a theme, refused here
        # too, so an archive is not the one way round them. A symbolic link
        # would be copied into the served asset mirror as a link - to anything
        # the web server can read, lazysite/auth/.secret among it - and a file
        # type the web server runs (the SEC-2026-07 list) would be served from
        # the mirror as a program. Every entry is checked before any is
        # extracted, so one refused entry refuses the whole archive.
        if ( $member->isSymbolicLink ) {
            _cleanup_tmp($tmp_dir);
            return { ok => 0, kind => 'blocked', error => "Zip entry is a symbolic link: $name" };
        }
        if ( !$member->isDirectory && $name =~ $Lazysite::Manager::Common::DANGEROUS_RE ) {
            _cleanup_tmp($tmp_dir);
            return { ok => 0, kind => 'blocked',
                error => "Zip entry is a file type the web server would run, which a theme may not carry: $name" };
        }
    }

    # Extract with tree layout under $extract_dir. extractTree returns
    # AZ_OK on full success.
    unless ( $zip->extractTree( '', "$extract_dir/" ) == Archive::Zip::AZ_OK() ) {
        _cleanup_tmp($tmp_dir);
        return { ok => 0, error => "Extraction failed" };
    }

    my $result = _install_theme_from_dir( $extract_dir, $action, $auth_user );
    _cleanup_tmp($tmp_dir);
    return $result;
}

sub _install_theme_from_dir {
    my ( $extract_dir, $action_label, $user, $update ) = @_;
    # TLO-4: _lz() stats the tree beside the docroot to decide where the engine
    # lives, and the per-layout loops below asked it once per layout per step.
    # The docroot does not migrate mid-call, so ask once.
    my $lz = _lz();

    return { ok => 0, error => "Upload must contain theme.json" }
        unless -f "$extract_dir/theme.json";

    open my $jf, '<:utf8', "$extract_dir/theme.json"
        or return { ok => 0, error => "Cannot read theme.json" };
    my $json = do { local $/; <$jf> };
    close $jf;
    my $meta = eval { decode_json($json) }
        or return { ok => 0, error => "Invalid theme.json" };

    my $theme_name = $meta->{name} // '';
    $theme_name =~ s/[^a-zA-Z0-9_-]//g;
    $theme_name = lc($theme_name);

    return { ok => 0, error => "Invalid theme name in theme.json" }
        unless $theme_name;

    # DP-C: strict reject when layouts[] is missing or empty.
    my $layouts = $meta->{layouts};
    unless ( ref $layouts eq 'ARRAY' && @$layouts ) {
        return { ok => 0,
            error => "Theme theme.json missing required 'layouts' field. Cannot install." };
    }

    my @clean_layouts;
    for my $l (@$layouts) {
        next unless defined $l && length $l;
        ( my $sane = $l ) =~ s/[^a-zA-Z0-9_-]//g;
        next unless length $sane;
        push @clean_layouts, $sane;
    }
    unless (@clean_layouts) {
        return { ok => 0,
            error => "Theme theme.json 'layouts' contains no usable layout names." };
    }

    # Verify every declared layout is installed. Reject the whole
    # upload if any are missing — the theme author explicitly said
    # "install under these" and we shouldn't silently skip.
    my @missing;
    for my $l (@clean_layouts) {
        push @missing, $l
            unless -f "$lz/layouts/$l/layout.tt";
    }
    if (@missing) {
        return { ok => 0,
            error => "Theme targets missing layout(s): " . join( ', ', @missing ) };
    }

    # Resolve the on-disk install name once, using the first layout
    # to detect collisions. The same $install_name is reused across
    # every layout so sysops can refer to the theme by a single
    # name in lazysite.conf's theme: key.
    my $install_name = $theme_name;
    my $first_dest   = "$lz/layouts/$clean_layouts[0]/themes/$theme_name";
    if ( -d $first_dest && !$update ) {
        my @t = localtime( time() );
        $install_name = sprintf( "%04d%02d%02d-%s",
            $t[5] + 1900, $t[4] + 1, $t[3], $theme_name );
    }
    elsif ( -d $first_dest ) {

        # AN UPDATE IS NOT A COLLISION, and treating it as one is what let a
        # layout upgrade report success while changing nothing a visitor sees.
        #
        # Measured on edge after lumen went to catalogue 1.1.0: the template was
        # the new one and /lazysite-assets/lumen/lumen/main.css was
        # byte-identical to a copy taken that morning, with none of the
        # .nav-toggle rules the release added. Below 900px the stale CSS hid the
        # nav with no rule to reveal the toggle.
        #
        # The mechanism was this branch. The new theme installed as
        # 20260817-lumen, the mirror ran for THAT, and the site went on serving
        # lumen - so `themes_installed` named a real theme truthfully and the
        # instance ran half of each one. _install_layout_from_dir has always
        # taken an update flag and written in place; only the theme half was
        # missing one, which is why the template updated and its stylesheet did
        # not.
        #
        # SM756: the update is built BESIDE the theme and switched in below -
        # never written into the directory being rendered. The snapshot of an
        # edited theme is the old directory itself, renamed at the switch, and a
        # pristine one (SM176) is simply removed; nothing is copied first and
        # overwritten after.
    }

    my @installed;
    for my $l (@clean_layouts) {
        my $dest    = "$lz/layouts/$l/themes/$install_name";
        my $staging = -d $dest ? _staging_for($dest) : $dest;
        system( 'rm', '-rf', $staging ) if $staging ne $dest && -e $staging;
        make_path($staging);
        my $rc = system( "cp", "-r", "$extract_dir/.", $staging );
        if ( $rc != 0 ) {
            system( 'rm', '-rf', $staging ) if $staging ne $dest;
            log_event( 'ERROR', $action_label, 'cp failed',
                path => $dest, rc => ( $rc >> 8 ) );
            return { ok => 0,
                error => "Install failed (cp theme files to $l)" };
        }
        if ( $staging ne $dest ) {
            my $keep = _snapshot_wanted( "$lz/layouts/$l/themes", $install_name );
            my ( $ok, $err ) = _swap_in( $staging, $dest, $keep );
            unless ($ok) {
                system( 'rm', '-rf', $staging );
                log_event( 'ERROR', $action_label, 'theme switch failed',
                    path => $dest, error => $err );
                return { ok => 0, error => "Update failed (switching the new theme in for $l)" };
            }
            _prune_backups( "$lz/layouts/$l/themes", $install_name );
        }

        # Nested asset path: /lazysite-assets/LAYOUT/THEME/ - built beside and
        # switched in the same way, because it is what the browser fetches.
        # SM1336: by _mirror_theme_assets, from the theme just installed, as
        # every other mirror is written. This copied assets/ alone into the
        # docroot, so an uploaded theme's mirror had no theme-tokens.css and no
        # fingerprint (its pages inlined their tokens and keyed on the engine
        # version) and no copy on any secondary domain.
        if ( -d "$extract_dir/assets" ) {
            local $LAZYSITE_DIR = $lz;
            _mirror_theme_assets( $l, $install_name );
        }

        # SM176: record the pristine baseline so switching away from this theme
        # later, if the operator never edited it, does not spawn a pointless backup.
        _write_pristine( "$lz/layouts/$l/themes",
            $install_name, _artifact_digest($dest) );

        push @installed, $l;
    }

    log_event( 'INFO', $action_label, 'theme installed',
        name    => $install_name,
        layouts => join( ',', @installed ),
        user    => $user );

    # SM1386: warned, never refused - a theme whose stylesheets are all outside
    # assets/ installs, and is served with no CSS.
    my $css_warning = _css_outside_assets_warning( $extract_dir, $install_name );
    log_event( 'WARN', $action_label, 'theme stylesheets outside assets/',
        name => $install_name, user => $user ) if defined $css_warning;

    return {
        ok           => 1,
        name         => $install_name,
        installed_as => $install_name,
        layouts      => \@installed,
        ( defined $css_warning ? ( warnings => [$css_warning] ) : () ),
    };
}

# SM1386: A THEME'S STYLESHEETS BELONG IN assets/. Only assets/ is mirrored to
# /lazysite-assets/<layout>/<theme>/, which is what a page links, so a zip with
# main.css at its root beside theme.json installed, previewed and activated
# with no CSS at all and nothing said why. Returns the warning, naming each
# stylesheet and where it belongs, when the theme has a .css file outside
# assets/ and none inside it; undef otherwise (a theme with CSS in assets/ may
# keep sources elsewhere, and a theme with no CSS is the layout's own styling).
sub _css_outside_assets_warning {
    my ( $dir, $name ) = @_;
    return undef unless defined $dir && -d $dir;
    my ( @outside, $inside );
    File::Find::find( { no_chdir => 1, wanted => sub {
                my $f = $File::Find::name;
                return unless -f $f && $f =~ /\.css\z/i;
                ( my $rel = substr( $f, length $dir ) ) =~ s{\A/+}{};
                if ( $rel =~ m{\Aassets/} ) { $inside = 1 }
                else                        { push @outside, $rel }
    } }, $dir );
    return undef if $inside || !@outside;
    @outside = sort @outside;
    my $n = @outside;
    return "theme '$name' has "
        . ( $n == 1 ? 'a stylesheet' : "$n stylesheets" )
        . ' outside assets/ and none inside it: '
        . join( ', ', map { "$_ (belongs at assets/$_)" } @outside )
        . ". Only assets/ is served (/lazysite-assets/<layout>/$name/), so the theme is "
        . 'installed and every page it styles has no CSS. Move '
        . ( $n == 1 ? 'it' : 'them' )
        . ' into assets/ in the theme (or the zip) and install it again.';
}

sub _cleanup_tmp {
    my ($dir) = @_;
    system( "rm", "-rf", $dir ) if $dir =~ m{^/tmp/lazysite-theme-\d+$};
}

# SM734: EVERY content root this instance serves, distinct, docroot excluded.
#
# A domain with a content_root serves /lazysite-assets/ from THAT root - the
# vhost points its document root there, so the request is a static file the
# engine never sees. Theme activation mirrored only into $DOCROOT, so such a
# domain never received its CSS: 200 on the docroot host, 404 on its own, for
# every theme. Reported from the field, and true on every release since the
# mirror existed - such a domain was never styled rather than having regressed.
#
# THE FIX IS n COPIES, and that was a decision rather than an oversight. The
# alternative - one copy in the docroot, reached by a front-end rule - asks
# something of the front end, which SM286 refuses as standing policy. A theme's
# assets are small and activation is rare, so the cost of copying is the cheap
# side of that trade.
#
# Reads the same conf lines as _host_content_root below, because a second parser
# would eventually disagree with it about what a content root is.
sub _all_content_roots {
    my %seen;
    if ( open my $fh, '<:raw', _lz() . "/lazysite.conf" ) {
        while ( my $l = <$fh> ) {
            next unless $l =~ /^(?:alias\.[^\s:]+\.)?content_root\s*:\s*(\S+)/;
            my $cr = $1;
            next unless length $cr;
            # A relative path under the docroot, one segment at a time. A
            # content_root is operator-written config, but it names a directory
            # this code is about to create, so it is checked rather than trusted.
            next if $cr =~ m{\A/} || $cr =~ m{(?:\A|/)\.\.(?:/|\z)} || $cr =~ /\0/;
            $seen{$cr} = 1;
        }
        close $fh;
    }
    my @roots = sort keys %seen;
    return @roots;
}

# The content root a host serves (its alias.<host>.content_root override, else
# the base content_root, else the docroot) - used to check whether a host cache
# entry still has a source page.
sub _host_content_root {
    my ($host) = @_;
    my ( $base, $override ) = ( '', undef );
    if ( open my $fh, '<:raw', _lz() . "/lazysite.conf" ) {
        while ( my $l = <$fh> ) {
            if    ( $l =~ /^content_root\s*:\s*(\S+)/ ) { $base = $1 }
            elsif ( length $host
                && $l =~ /^alias\.\Q$host\E\.content_root\s*:\s*(\S+)/ )
            {
                $override = $1;
            }
        }
        close $fh;
    }
    my $cr = defined $override ? $override : $base;
    return length $cr ? "$DOCROOT/$cr" : $DOCROOT;
}

# SM846: the name the primary site answers to, so a cached page from the
# primary can say which domain it serves - on a multi-domain instance a list
# that tags only the alias hosts leaves the untagged rows to be inferred.
# The configured site_url names it; the ${SERVER_NAME} placeholder names no
# host, and then the primary answers to whatever reaches it that is not an
# alias, which the request this listing arrived on is - unless it came in on
# an alias itself, when there is no name to give.
sub _primary_domain_name {
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
    my $r      = eval { Lazysite::Manager::Domains::domains_list() } || {};
    my @rows   = @{ $r->{domains} || [] };
    my ($prim) = grep { $_->{is_primary} } @rows;
    my $url    = $prim ? ( $prim->{site_url} // '' ) : '';
    return lc $1 if $url !~ /\$\{/ && $url =~ m{^https?://([^/:?#]+)}i;
    ( my $req = lc( $ENV{SERVER_NAME} || $ENV{HTTP_HOST} || '' ) ) =~ s/:\d+\z//;
    my %alias = map { lc( $_->{host} // '' ) => 1 } grep { !$_->{is_primary} } @rows;
    return $req if $req =~ /\A[a-z0-9.-]+\z/ && !$alias{$req};
    return 'default site';
}

sub action_cache_list {
    my @cached;
    my $primary = _primary_domain_name();
    # Primary host: the .html mirror sits beside its .md in the content tree.
    find(
        sub {
            return unless /\.html$/;
            my $rel = $File::Find::name;
            $rel                             =~ s{^\Q$DOCROOT\E/?}{/};
            return if $rel                   =~ m{^/lazysite/};
            ( my $base = $File::Find::name ) =~ s/\.html$//;
            push @cached, {
                path       => $rel,
                domain     => $primary,
                mtime      => ( stat $_ )[9],
                has_source => _cache_source_exists($base),
            };
        },
        $DOCROOT
    );

    # SM110: per-alias-host renders live in host-keyed slots under the cache dir
    # (lazysite/cache/hosts/<host>/<page>.html), NOT beside the .md, so the walk
    # above never sees them and the reserved-/lazysite/ skip excludes them. List
    # them too, tagged with their host, so a sub-domain's cached pages are visible
    # and clearable here (rather than a sysop resorting to a Files delete under
    # the reserved lazysite/ tree, which is correctly blocked).
    my $cache_base = $ENV{LAZYSITE_CACHE_DIR} || _lz() . "/cache";
    my $hosts_dir  = "$cache_base/hosts";
    if ( -d $hosts_dir ) {
        find(
            sub {
                return unless /\.html$/;
                ( my $rel = $File::Find::name ) =~ s{^\Q$hosts_dir\E/}{};
                my ( $host, $page ) = ( $rel =~ m{\A([^/]+)/(.+)\z} );
                return unless defined $host && defined $page;
                my $url = "/$page";    # keep .html, matching the primary entries
                ( my $base_rel = $page ) =~ s/\.html\z//;
                my $croot = _host_content_root($host);
                push @cached, {
                    path       => $url,
                    host       => $host,
                    domain     => $host,
                    mtime      => ( stat $_ )[9],
                    has_source => _cache_source_exists("$croot/$base_rel"),
                };
            },
            $hosts_dir
        );
    }

    return { ok => 1, cached => \@cached };
}

sub action_cache_invalidate {
    my ( $rel_path, $host ) = @_;

    # Per-host invalidation: clear only THIS host's copy of the page, so one
    # language/domain sub-site's cache can be dropped from the Cache page without
    # touching its siblings. (The Cache list tags each host entry with its host.)
    if ( defined $host && length $host && $rel_path ne '*' ) {
        ( my $rel = $rel_path ) =~ s{^/+}{};
        $rel =~ s/\.(?:md|html)\z//;
        my $n = Lazysite::Util::unlink_host_page( $DOCROOT, $host, "$rel.html" );
        log_event( 'INFO', $action, 'host cache invalidated',
            path => $rel_path, host => $host, user => $auth_user );
        return { ok => 1, path => $rel_path, host => $host, cleared => $n };
    }

    if ( $rel_path eq '*' ) {
        my $count = 0;
        find(
            sub {
                return unless /\.html$/;
                my $rel = $File::Find::name;
                $rel =~ s{^\Q$DOCROOT\E/?}{/};
                return if $rel =~ m{^/lazysite/};
                # SM133: a bare .html with NO .md sibling is legacy static
                # content (served by the migration fallback), not a render
                # cache - deleting it would destroy the page. Sweep only
                # true caches.
                ( my $base = $File::Find::name ) =~ s/\.html$//;
                return unless _cache_source_exists($base);
                unlink $_;
                $count++;
            },
            $DOCROOT
        );
        # SM110: clear-all also removes the whole per-alias-host cache tree
        # (wholesale - the hosts tree holds only generated renders, never
        # authored content, so the SM133 legacy-page caution doesn't apply).
        Lazysite::Util::clear_host_cache($DOCROOT);
        return { ok => 1, count => $count };
    }

    # SM367: a directory path is its index, and "/" is the commonest one there
    # is. Without this, "/" became "$DOCROOT/.html" - a file that has never
    # existed - so the unlink below found nothing, and the call returned ok:1
    # having done nothing at all.
    #
    # It cost the site agent two wrong diagnoses before it was spotted, both of
    # them plausible: once concluding a stale index.html was shadowing the
    # homepage, and once reading a 0.10.12 render on a 0.10.13 instance as a
    # failed upgrade. Neither was true. The homepage is the page most likely to
    # be checked and, because an engine upgrade does not invalidate rendered
    # pages, the one most likely to be stale - so this is the path where a
    # silent no-op does the most damage to somebody's reasoning.
    # ONLY a directory path. The first version of this appended /index
    # unconditionally and turned "/index" into "/index/index", breaking the
    # three spellings that were the documented workaround - which is the
    # ordinary way a fix for a silent no-op becomes a loud one.
    my $rel = $rel_path;
    $rel = "$rel/index" if $rel =~ m{/\z} || $rel eq '';
    $rel =~ s{//+}{/}g;

    my $full = "$DOCROOT$rel";
    $full =~ s/\.md$/.html/;
    $full .= '.html' unless $full =~ /\.html$/;

    my $real = realpath($full);

    # SEC-2026-07 (H3): confinement. A path that escapes the docroot is refused
    # whatever else is true of it.
    #
    # SM367: realpath returns undef when the PARENT is missing, and that used to
    # be the only way to get a refusal - so "/nope.md" answered ok:1 (its parent
    # is the docroot) while "/nope/deeper.md" answered ok:0. Two pages that do
    # not exist, two different answers, differing on something the caller never
    # asked about. Fall through to the existence test below rather than
    # reporting a confinement failure for a path that is simply not there.
    if ( defined $real
        && !( $real eq $DOCROOT || index( $real, "$DOCROOT/" ) == 0 ) )
    {
        return { ok => 0, error => 'Invalid path', kind => 'blocked' };
    }
    $real = $full unless defined $real;

    # SM133, ON THIS BRANCH TOO. A bare .html with no .md sibling is LEGACY
    # STATIC CONTENT served by the migration fallback - it is the page itself,
    # not a render of one. The '*' sweep has refused to touch those since SM133
    # and this branch never did, so `invalidate_cache` on a migrated site
    # DELETED THE PAGE and reported ok:1 with cleared:1 - a destructive act
    # described as a cache clear.
    #
    # Verified against the code before fixing: a .html with no source was
    # unlinked and the response said it had cleared one.
    ( my $src_base = $real ) =~ s/\.html\z//;
    my $has_source = _cache_source_exists($src_base);

    # SM367 follow-up, from the field: "no .md sibling" is NOT the same question
    # as "not a render", and the first version of this guard conflated them.
    #
    # 402.html and 404.html have no .md sibling and are engine RENDERS - their
    # sources live in lazysite/templates/system/ (SM201), not beside them. So
    # the guard refused to clear exactly the artefact SM355 was about: a cached
    # 404 in the served tree carrying a canonical a stranger chose. Safe, in
    # that nothing was destroyed, and it made the one page most likely to need
    # clearing the one page that could not be cleared.
    #
    # Two better answers, both cheap, taken in order so the refusal can say
    # WHICH case it thinks it has hit rather than only that it refused:
    #
    #   1. a system-page source in the engine tree - that is a render
    #   2. the engine's own generator marker in the file - that is a render
    #
    # Anything else with no source is legacy static content served by the
    # migration fallback, and deleting it deletes the page.
    my $is_render = 0;
    my ($base_name) = $real =~ m{([^/]+)\.html\z};
    if ( defined $base_name
        && -f "$LAZYSITE_DIR/templates/system/$base_name.md" )
    {
        $is_render = 'system';
    }
    elsif ( -f $real && open my $hf, '<:utf8', $real ) {
        local $/;
        my $head = substr( <$hf> // '', 0, 4096 );
        close $hf;
        $is_render = 'generated'
            if $head =~ /<meta\s+name="generator"\s+content="lazysite/i;
    }

    if ( -f $real && !$has_source && !$is_render ) {
        return {
            ok    => 0,
            kind  => 'not-a-cache',
            path  => $rel_path,
            error => 'That path is a page, not a cached render of one - it has '
                . 'no source file and carries no engine render marker, so '
                . 'deleting it would delete the page. Nothing was changed.',
        };
    }

    # SM367: `ok` now means something happened to the thing you named.
    #
    # It used to mean a syntax check passed. The site agent's table is the
    # argument: /nope.md and /definitely-not-a-page-zz both answered ok:true,
    # because the only test was whether the PARENT DIRECTORY existed. A caller
    # could not distinguish cleared, nothing-was-cached, and no-such-path - and
    # that is what made two field misdiagnoses possible, because the success
    # flag did not merely fail to help, it pointed away from itself.
    if ( !-f $real && !$has_source && !$is_render ) {
        return {
            ok    => 0,
            kind  => 'not-found',
            path  => $rel_path,
            error => "No such page: $rel_path",
        };
    }

    my $cleared = 0;
    if ( -f $real ) { unlink $real; $cleared = 1 }

    # SM110: drop the per-alias-host copies of this page's render too.
    my $hosts = Lazysite::Util::unlink_host_copies( $DOCROOT, $real );
    $cleared += $hosts if defined $hosts && $hosts =~ /^\d+$/;

    log_event( 'INFO', $action, 'cache invalidated',
        path => $rel_path, user => $auth_user );

    # SM367: SAY WHAT WAS CLEARED. ok:1 answered the question "did the call
    # succeed" and was read as "the cache is now gone", which are different
    # facts and were different facts. A caller can now tell a page that had no
    # cached render from one whose render was dropped - and "cleared: 0" is a
    # true and useful answer rather than a silent one.
    return { ok => 1, path => $rel_path, cleared => $cleared };
}

sub action_artifact_manifest {
    my ($p) = @_;
    my $a = _artifact_dir($p);
    return $a                                         unless $a->{ok};
    return { ok => 0, error => 'artifact not found' } unless -d $a->{dir};

    my $manifest = _compute_manifest( $a->{dir} );
    # digest is the optimistic-concurrency token: the client passes it back
    # as `base` to activate, which 409s if the artifact drifted since.
    return { ok => 1, layout => $a->{layout}, theme => $a->{theme},
        manifest => $manifest,
        digest   => sha256_hex( JSON::PP->new->canonical->encode($manifest) ) };
}

sub action_artifact_validate {
    my ($p) = @_;
    my $a = _artifact_dir($p);
    return $a unless $a->{ok};
    return { ok => 1, valid => 0, errors => ['artifact not found'] }
        unless -d $a->{dir};

    my @err;
    if ( length $a->{theme} ) {
        my $tj = "$a->{dir}/theme.json";
        if ( !-f $tj ) { push @err, 'theme.json missing' }
        else {
            open my $fh, '<:utf8', $tj or push @err, 'theme.json unreadable';
            if ( @err == 0 ) {
                my $raw = do { local $/; <$fh> };
                close $fh;
                my $data = eval { decode_json($raw) };
                if    ( ref $data ne 'HASH' ) { push @err, 'theme.json invalid' }
                elsif ( ref $data->{layouts} ne 'ARRAY' || !@{ $data->{layouts} } ) {
                    push @err, 'theme.json layouts[] missing or empty';
                }
            }
        }
    }
    else {
        my $v = _validate_layout_dir( $a->{dir} );
        return { ok => 1, valid => $v->{valid}, errors => $v->{errors} };
    }
    return { ok => 1, valid => ( @err ? 0 : 1 ), errors => \@err };
}

1;
