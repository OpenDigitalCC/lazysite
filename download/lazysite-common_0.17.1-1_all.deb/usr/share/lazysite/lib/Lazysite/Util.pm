package Lazysite::Util;

# Shared helpers for the modular lazysite scripts (auth, dav, manager-api, the
# users tool). The processor stays self-contained and does NOT use this module -
# see docs/feature-requests/archive/SM079-modular-refactor.md.
#
# Each script sets $Lazysite::Util::COMPONENT after `use`, so log lines are
# attributed to the right component.

use strict;
use Fcntl ();    # SM961: store_lock
use warnings;
use Lazysite::Paths ();
use POSIX           ();
use Socket          qw(inet_pton inet_ntop AF_INET AF_INET6);
use Exporter 'import';

our @EXPORT_OK = qw(store_lock log_event const_eq unlink_host_copies unlink_host_page clear_host_cache forward_line service_enabled account_page_enabled secure_write_perms write_private_atomic drop_to_tree_owner target_identity cannot_read store_fault path_owner_name web_door unreadable_note unreadable_clause backup_retention interpolate_env env_allowlist request_host request_address trusted_proxy_spec parse_trusted_proxies front_end_is_every_visitor proxy_identity unsafe_link_scheme nav_unsafe_entries conf_text_value sanitise_next);

our $COMPONENT = 'lazysite';

# SM215: make a just-written file owner/group/mode-safe so a helper run under sudo
# (as root) never leaves a file the web-server (www-data) CGI cannot access. The
# parent directory is provisioned <site-user>:<web-group> (and is setgid), so we
# INHERIT owner+group from it rather than hard-code www-data: as root, chown both
# (only root can); unprivileged, set the group only (best-effort - a non-root CLI
# is normally already the file's owner, and chown-to-another-user would just fail).
# Call on the temp file BEFORE rename (same directory), or on the final path. Mode
# is applied explicitly. Best-effort throughout: never dies on a chown/chmod fail.
# SM766 (SM760's lesson, made a rule): A STORE READER NEVER TURNS AN
# UNOPENABLE FILE INTO AN EMPTY ANSWER IN SILENCE. `open ... or return {}`
# on a file that EXISTS turned a permissions fault into "this account holds
# nothing" for the runtime and a dead process for Status; both were read as
# facts about the site. Every read-open in the auth and daemon stores now
# goes through this on failure: it WARNs with the file, the error and the
# unix user - unless the file simply is not there (ENOENT), which is the
# ordinary empty case and not a fault - and returns undef so the caller's
# `// <empty>` keeps its shape. t/lint/121 holds that no read-open in those
# modules returns in silence.
# SM753: THE ONE READER of `backup_retention`. Three parsers read this key
# with two defaults - the manager kept 10, the installer and the theme store
# kept 3, the docs said 3 - so a sysop who never set it kept ten manual
# backups, read that they kept three, and the theme store kept three. The
# release manager's ruling (2026-09-07): 3, one reader, settable on the Site
# config page. `0` means unlimited; anything that is not a whole number
# reads as the default and is said in the log, not died on.
our $BACKUP_RETENTION_DEFAULT = 3;
# P23 (WORK-PLAN-0154, ruled 2026-10-12): A LINK TARGET'S SCHEME, JUDGED AS THE
# RENDER JUDGES IT. A MARKED COPY of the decision in the processor's
# _url_safe_filter (lazysite-processor/include.pm, SM970 `| url_safe`), which
# loads nothing from this tree (ADR 0001); t/lint/223 runs both over the same
# texts and requires the same answer. Keep the two equal.
#
# Returns undef when the value may be a link - no scheme (a relative path,
# `/abs`, `?q`, `#frag`, `//host`) or http, https, mailto, tel - and otherwise
# the scheme that makes it unsafe, lowercased (`javascript`, `data`,
# `vbscript`, ...), or `undecodable` for a value still decoding after eight
# layers of character references and percent-encoding.
my %LINK_SAFE_SCHEME = map { $_ => 1 } qw(http https mailto tel);
my %LINK_SAFE_NAMED  = (
    colon  => ':', Tab => "\t", NewLine => "\n", plus   => '+',
    period => '.', amp => '&',  AMP     => '&',  percnt => '%',
);

sub _link_chr {
    my ($n) = @_;
    return ( $n > 0 && $n <= 0x10FFFF ) ? chr $n : "\x{FFFD}";
}

sub unsafe_link_scheme {
    my ($text) = @_;
    return undef unless defined $text;
    return 'reference' if ref $text;
    my $s = "$text";
    for ( 1 .. 8 ) {
        ( my $r = $s ) =~ s/\A[\x00-\x20]+//;
        $r =~ tr/\t\n\r//d;
        if ( $r =~ /\A([a-zA-Z][a-zA-Z0-9+.\-]*):/ ) {
            return lc $1 unless $LINK_SAFE_SCHEME{ lc $1 };
        }
        my $d = $s;
        $d =~ s/&#[xX]([0-9a-fA-F]{1,8});?/_link_chr(hex $1)/ge;
        $d =~ s/&#([0-9]{1,10});?/_link_chr($1)/ge;
        $d =~ s/&([a-zA-Z]+);/exists $LINK_SAFE_NAMED{$1} ? $LINK_SAFE_NAMED{$1} : "&$1;"/ge;
        $d =~ s/%([0-9a-fA-F]{2})/chr hex $1/ge;
        return undef if $d eq $s;
        $s = $d;
    }
    return 'undecodable';
}

# P23: the entries of a nav file (`Label | url`, a child indented) whose
# address unsafe_link_scheme refuses, in file order: [ { line, label, scheme } ].
# Read line by line as the processor's parse_nav reads it; a line with no label
# is skipped there, and here.
sub nav_unsafe_entries {
    my ($text) = @_;
    my @bad;
    my $n = 0;
    for my $line ( split /\n/, ( $text // '' ) ) {
        $n++;
        next if $line =~ /^\s*#/ || $line =~ /^\s*$/;
        ( my $l = $line ) =~ s/^\s+|\s+$//g;
        my ( $label, $url ) = split /\s*\|\s*/, $l, 2;
        $label //= '';
        $url   //= '';
        $label =~ s/^\s+|\s+$//g;
        $url   =~ s/^\s+|\s+$//g;
        next unless length $label;
        my $scheme = unsafe_link_scheme($url);
        push @bad, { line => $n, label => $label, scheme => $scheme } if defined $scheme;
    }
    return \@bad;
}

sub backup_retention {
    my ($lazysite_dir) = @_;
    my $conf = "$lazysite_dir/lazysite.conf";
    return $BACKUP_RETENTION_DEFAULT unless defined $lazysite_dir && -f $conf;
    open my $fh, '<:utf8', $conf or return $BACKUP_RETENTION_DEFAULT;
    my $val = $BACKUP_RETENTION_DEFAULT;
    while ( my $l = <$fh> ) {
        next unless $l =~ /^backup_retention\s*:\s*(.*?)\s*$/;
        my $v = $1;
        # SM782: an EMPTY value is the default, silently - it is how the
        # field ships and what clearing it through the API writes.
        if    ( !length $v )      { $val = $BACKUP_RETENTION_DEFAULT }
        elsif ( $v =~ /\A\d+\z/ ) { $val = $v + 0 }
        else { log_event( 'WARN', 'config', 'backup_retention is not a whole number; using the default', value => $v, default => $BACKUP_RETENTION_DEFAULT ) }
        last;
    }
    close $fh;
    return $val;
}

# SM1209: ONE VALUE OUT OF CONF TEXT, as the engine reads it. A value is confined
# to its own line: the separator is [ \t]*:[ \t]*, never \s*, which would run on
# over the newline and read a key whose line is present but empty (`app_scope:`,
# how config-set leaves a cleared key) as the whole next line. Like the engine
# (resolve_site_vars: ^(\w+)\h*:\h*(.+)$ /mg) a line with nothing after the colon is
# no occurrence at all, and the LAST occurrence of a repeated key wins. undef when
# the key has no occurrence; '' when the last one is blank (spaces only); the value
# is trimmed.
# The return target after a sign-in: a path on this site, or '/'. Moved here from
# lazysite-auth.pl (SM1299) so the Odoo sign-in page's return (ruling 37) is
# decided by the same check as /login's, not a second one. A path that starts
# with a single '/' and holds only word characters, '/', '.' and '-': no scheme,
# no host, no query, no backslash, and no '//' anywhere (as ruled for the Odoo
# page, and as /login now reads it too). Anything else is '/'.
sub sanitise_next {
    my ($next) = @_;
    return '/' unless defined $next && !ref $next && length $next;
    # H-1: reject protocol-relative URLs (//host) and backslash forms
    # before the permissive character-class check below - otherwise
    # //evil.com matches \A/[\w/.-]*\z.
    return '/' if $next =~ m{\A(?://|\\)};
    # SM1299: and a '//' anywhere - an empty segment is no path we serve
    return '/' if $next     =~ m{//};
    return '/' unless $next =~ m{\A/[\w/.-]*\z};
    return $next;
}

sub conf_text_value {
    my ( $text, $key ) = @_;
    return undef unless defined $text && defined $key;
    my $val;
    while ( $text =~ /^\Q$key\E[ \t]*:[ \t]*(.+)$/mg ) { $val = $1 }
    return undef unless defined $val;
    $val =~ s/\A\s+|\s+\z//g;
    return $val;
}

# n818 (SM1440): the unix user that owns a store, and what a refusal says about
# it. A command that cannot read a file under lazysite/auth/ is nearly always
# running as the wrong unix user (the login user, not the one the CGI runs as),
# and "fault on the host" sends the operator nowhere. The owner is the file's,
# or its directory's when the file cannot even be stat'ed from here.
# Undef when neither can be told.
sub path_owner_name {
    my ($path) = @_;
    return undef unless defined $path && length $path;
    for my $p ( $path, ( $path =~ m{\A(.*)/[^/]+\z}s ? $1 : () ) ) {
        my @st = stat $p or next;
        my ($name) = getpwuid( $st[4] );
        return $name // "uid $st[4]";
    }
    return undef;
}

# n825 (SM1447): THE USER TO RUN A COMMAND AS IS THE OWNER OF THE STORE FILES IT READS AND
# WRITES, not of the directory holding them. On a Hestia host lazysite/auth/ is
# ispadmin:www-data 2770 but acls.json and address-profiles.json are written by the CGI,
# so www-data owns them and ispadmin cannot read some; naming the directory's owner sent
# the operator to the one user that fails. One helper for every CLI refusal that names a
# user (acl, handlers, check, users): $dir is the store directory, @names the files in it
# the command touches. Returns ( $user, $differ ): $user is the owner of the first of them
# that exists (the directory's owner when none does; 'SITEUSER' when even that is unknown),
# and $differ is '' unless the files have different owners, then a sentence naming each.
# Never called from a web door: ruling 243 keeps unix names out of web refusals.
sub store_run_as {
    my ( $dir, @names ) = @_;
    my ( @order, %files );
    for my $n (@names) {
        my @st = stat( $n =~ m{\A/} ? $n : "$dir/$n" ) or next;
        my $u  = ( getpwuid $st[4] )[0] // "uid $st[4]";
        push @order,          $u unless $files{$u};
        push @{ $files{$u} }, $n;
    }
    unless (@order) {
        my $o = path_owner_name($dir);
        return ( $o // 'SITEUSER', '' );
    }
    return ( $order[0], '' ) if @order == 1;
    return ( $order[0],
        'The store files have different owners ('
            . join( '; ', map { "$_ owns " . join( ', ', @{ $files{$_} } ) } @order )
            . '), so no one user is the owner of them all: run it as the owner of the file it '
            . 'changes, or give the files one owner (`lazysite check` names the fix).' );
}

# Is this process answering a web request (the manager API, MCP, any CGI door)? A
# refusal shown through a web door names no unix user (ruling 243): it says "the web
# server's user" and "the owner of the file". The CLI tools name the users. This is the
# one switch; unreadable_note and unreadable_clause read it.
sub web_door {
    return ( defined $ENV{REQUEST_METHOD} || defined $ENV{GATEWAY_INTERFACE} ) ? 1 : 0;
}

# "could not be read ..." for a store's refusal text: who could not read it, and the owner.
# $err is the system's reason. The CLI names the user it ran as and the file's owner; a web
# door says the web server's user and the owner of the file.
sub unreadable_clause {
    my ( $path, $err ) = @_;
    return "could not be read by the web server's user ($err)" if web_door();
    my ($me) = getpwuid($>);
    my $owner = path_owner_name($path);
    return "could not be read as '" . ( $me // "uid $>" ) . "' ($err"
        . ( defined $owner ? "; the file is owned by '$owner'" : '' ) . ')';
}

# '' when this process opens $path (the fault, if any, is not about who ran it);
# otherwise a sentence naming the user it ran as, the user that owns the file,
# and the command to run as that user.
sub unreadable_note {
    my ($path) = @_;
    return '' unless defined $path && length $path;
    return '' if open my $fh, '<', $path;
    my $why = "$!";
    return '' if $!{ENOENT};
    ( my $short = $path ) =~ s{\A.*/(lazysite/)}{$1}s;
    return " The web server's user cannot read $short ($why). Run the command on the host as the owner of the file (`lazysite check` names the fix)."
        if web_door();
    my ($me) = getpwuid($>);
    $me //= "uid $>";
    my $owner = path_owner_name($path);
    return " This ran as unix user '$me', which cannot read $short ($why)."
        . ( !defined $owner ? ' Run it as the user the web server runs the site as, which owns the auth store.'
        : $owner eq $me ? ' That user owns it, so its permissions are the fault: `lazysite check` names the fix.'
        :   " It is owned by '$owner': run the command as '$owner' (sudo -u $owner ...)." );
}

sub cannot_read {
    my ( $what, $path ) = @_;
    return undef if $!{ENOENT};
    # SM768: read $! BEFORE getpwuid, which is free to reset it - the first
    # version logged `error=` blank, which is the one field the rule exists
    # to carry.
    my $err = "$!";
    my ($who) = getpwuid($>);
    log_event( 'WARN', 'store', "cannot read $what - it exists and this process cannot open it",
        file => $path, error => $err, unix_user => ( $who // $> ) );
    return undef;
}

# Ruling 206 (the 0.16.9 fault survey, items 9-21): A STORE THAT EXISTS AND
# CANNOT BE TOLD IS A FAULT, and every place that meets one says so in the same
# words. Logs one WARN naming the store, the fault and the remedy, and returns
# the cannot-tell refusal (503 through Manager::Common's %REFUSAL_STATUS):
#
#   store_fault( category => 'notify', store => 'lazysite/notify/ledger.jsonl',
#       fault => 'holds a line that is not a record (line 4)',
#       doing => 'send notifications', effect => 'Nothing was sent.' )
#
# `store` is docroot-relative (SM494: a host path is not a caller's to see).
# The caller decides what refusing means; this only says it. An ABSENT store is
# never passed here - absence is a site with nothing recorded yet.
sub store_fault {
    my (%a)    = @_;
    my $store  = $a{store} // 'a store';
    my $fault  = $a{fault} // 'cannot be read';
    my $effect = length( $a{effect} // '' ) ? " $a{effect}" : '';
    my $doing  = $a{doing} // 'answer this';
    log_event( 'WARN', $a{category} // 'store', "cannot tell - $store $fault.$effect",
        file => $store,
        repair => 'lazysite check --docroot <docroot> names it; repair it from the command line' );
    return {
        ok     => 0,
        kind   => 'cannot-tell',
        store  => $store,
        repair => 'lazysite check --docroot <docroot>',
        error => "Cannot $doing right now: $store $fault. This is a fault on the host, not a "
            . "decision about this request.$effect `lazysite check --docroot <docroot>` names the "
            . 'fault; repair it from the command line.',
    };
}

# SM1183: write a secret file so it is NEVER more permissive than its final mode,
# not for an instant. The old shape was `open '>'` (mode = 0666 & ~umask, and the
# umask is 0002 in the CGI and the dropped-privilege tools, so 0664), then print,
# then chmod 0660 - for OAuth's token store the chmod came AFTER the tokens were
# written, so the secret sat in a file any user the directory admitted could read.
# Here the temp is created with sysopen O_EXCL and the FINAL mode, under a umask
# that clears every bit the mode does not carry (a umask can only narrow, so the
# file is exactly $mode), written, closed and renamed over the target. A rename
# adopts the temp's mode, so an existing 0660 store becomes whatever $mode says
# on its next save. Returns (1, '') or (0, the reason); the temp never outlives
# a failure.
sub write_private_atomic {
    my ( $path, $content, $mode ) = @_;
    $mode = 0600 unless defined $mode;
    my $tmp = "$path.tmp.$$";
    my $fh;
    for my $try ( 1, 2 ) {
        my $old = umask( 0777 & ~$mode );
        my $ok = sysopen( $fh, $tmp, Fcntl::O_WRONLY() | Fcntl::O_CREAT() | Fcntl::O_EXCL(), $mode );
        my $err    = "$!";
        my $eexist = $!{EEXIST};
        umask $old;
        last if $ok;
        # A temp left by an earlier crash of this same pid number is ours to clear.
        if ( $try == 1 && $eexist ) { unlink $tmp; next }
        return ( 0, "Cannot write $tmp: $err" );
    }
    binmode $fh;
    unless ( print {$fh} $content ) { my $e = "$!"; close $fh; unlink $tmp; return ( 0, "Write failed: $e" ) }
    unless ( close $fh ) { my $e = "$!"; unlink $tmp; return ( 0, "Cannot finish $tmp: $e" ) }
    unless ( rename $tmp, $path ) { my $e = "$!"; unlink $tmp; return ( 0, "Cannot replace $path: $e" ) }
    return ( 1, '' );
}

sub secure_write_perms {
    my ( $path, $mode ) = @_;
    return unless defined $path && length $path;
    chmod $mode, $path if defined $mode;
    ( my $dir = $path ) =~ s{/[^/]+\z}{};
    $dir = '.' unless length $dir;
    my @ds = stat $dir or return;
    my ( $duid, $dgid ) = @ds[ 4, 5 ];
    if ( $> == 0 ) { chown $duid, $dgid, $path }    # root: match the provisioned dir
    else           { chown -1, $dgid, $path }       # non-root: group only, best-effort
    return;
}

# SM619: BECOME the owner of the site tree before writing into it.
#
# The rule this enforces is not new - lazysite-check.pl states it as SM139:
# "lazysite never writes into a site tree as root, because root-owned files
# there are exactly what stops the manager working afterwards". It was enforced
# in exactly one probe. A fleet sweep after the 0.11.0 upgrade found 31 sites
# with 16 identical failures each, every one traceable to a tree owned root:root
# - and one root-run command explains a whole tree, because lazysite/auth is
# setgid (02770): once ITS group is root, everything created beneath it
# afterwards inherits group root, including writes by callers that are
# themselves careful.
#
# secure_write_perms (SM215) is the per-FILE remedy and cannot reach this case:
# it inherits owner and group from the parent directory, so when the parent is
# the thing make_path() just created as root, it faithfully inherits root.
#
# WHOSE identity: the docroot's, read per call. One host serves many sites owned
# by different users, so this is never a constant - it is whatever owns the tree
# being written to, resolved fresh each time.
#
# Returns a hashref: { dropped => 0|1, user, group, why }. NEVER dies - the
# caller decides whether a refusal to drop is fatal, because that answer differs
# between a tool that writes (fatal) and one that only reads (harmless).
# The DECISION half, split out so it can be tested without being root: given a
# tree and an optional --as-user, who should this process become? Returns
# ( uid, gid ) or ( undef, why ). A test can point it at any real directory,
# including a genuinely root-owned one like '/', which is how the refusal path
# gets exercised at all - the alternative was a fake-root environment variable
# inside a privilege-dropping function, which is a worse thing to own.
sub target_identity {
    my ( $docroot, %opt ) = @_;
    my ( $uid, $gid );
    if ( defined $opt{as_user} && length $opt{as_user} ) {
        my @pw = getpwnam $opt{as_user}
            or return ( undef, "no such user '$opt{as_user}'" );
        ( $uid, $gid ) = @pw[ 2, 3 ];
        # An explicit --as-user names the OWNER; the tree still decides the
        # group, so a file lands in the web group the site is provisioned with
        # rather than the user's private group.
        my @ds = stat $docroot;
        $gid = $ds[5] if @ds && $ds[5] != 0;
    }
    else {
        my @ds = stat $docroot
            or return ( undef, "cannot stat '$docroot'" );
        ( $uid, $gid ) = @ds[ 4, 5 ];
        # A root-owned tree cannot say who it belongs to. Guessing here is how
        # the damage spread in the first place, so say so and let the caller
        # refuse - the repair (lazysite-check --fix, as root) is a different
        # tool with a different job.
        return ( undef,
            "the tree at '$docroot' is owned by root, so it cannot say "
                . 'which user to become - repair ownership first '
                . '(lazysite-check.pl --docroot ... --fix, as root), '
                . 'or name the owner with --as-user' )
            if $uid == 0;
    }

    return ( $uid, $gid );
}

sub drop_to_tree_owner {
    my ( $docroot, %opt ) = @_;
    return { dropped => 0, why => 'not running as root' } if $> != 0;

    my ( $uid, $gid ) = target_identity( $docroot, %opt );
    return { dropped => 0, why => $gid } unless defined $uid;

    # ORDER MATTERS AND IS NOT RECOVERABLE. The group must be set while still
    # root: once the UID is dropped the process can no longer change its GID, so
    # a UID-first version would strand the process in root's group with no way
    # back and no error to say so.
    $) = "$gid $gid";    ## no critic (Variables::RequireLocalizedPunctuationVars)
    $( = $gid;           ## no critic (Variables::RequireLocalizedPunctuationVars)
    $> = $uid;           ## no critic (Variables::RequireLocalizedPunctuationVars)
    $< = $uid;           ## no critic (Variables::RequireLocalizedPunctuationVars)

    # Perl does not die when one of those assignments fails, so VERIFY rather
    # than assume. Both real and effective are checked: dropping only the
    # effective ids would leave the privilege reachable again through $> = 0.
    if ( $> != $uid || $< != $uid || $) + 0 != $gid || $( + 0 != $gid ) {
        return {
            dropped => 0,
            why     => "could not drop to uid $uid gid $gid "
                . "(now euid=$>, uid=$<, egid=" . ( $) + 0 ) . ", gid=" . ( $( + 0 ) . ')'
        };
    }

    # 0002, so a new file is group-writable and a new directory group-writable
    # and traversable - what the CGI needs, and what the deploy sets by hand.
    umask 0002;

    return {
        dropped => 1,
        user    => scalar( ( getpwuid $uid )[0] ) // $uid,
        group   => scalar( ( getgrgid $gid )[0] ) // $gid,
    };
}

# Constant-time string compare for timing-safe credential/token checks.
sub const_eq {
    my ( $a, $b ) = @_;
    return 0 unless defined $a && defined $b;
    return 0 if length($a) != length($b);
    my $r = 0;
    $r |= ord( substr( $a, $_, 1 ) ) ^ ord( substr( $b, $_, 1 ) )
        for 0 .. length($a) - 1;
    return $r == 0;
}

# --- ${CGI_VAR} interpolation in a lazysite.conf value (SM926) ----------------
#
# `site_url` routinely holds `${REQUEST_SCHEME}://${SERVER_NAME}` - it is what
# install.pl and TestHelper write, so that one config works on any domain - and
# that value MEANS NOTHING until somebody expands it.
#
# THREE PIECES OF THE ENGINE READ THAT KEY AND ONLY TWO EXPANDED IT. The processor
# has an allowlist; tools/lazysite-users.pl hand-rolls two of the same variables
# with a comment explaining why it must; Lazysite::Notify had a seven-line reader
# that returned the raw line - so the first XMPP notification to arrive on a live
# site carried the URL `${REQUEST_SCHEME}://${SERVER_NAME}/manager/extensions`. The
# third hand-rolled copy is how that happened, and a fourth would be the same
# mistake with a different symptom, so this is the one home for it.
#
# THE PROCESSOR KEEPS ITS OWN COPY, deliberately: the render path is module-free
# (ADR 0001) and cannot require this. t/lint/202 pins the two allowlists
# identical, which is the same arrangement lint 198 makes for `_cannot_read`.
#
# HTTP_HOST IS EXCLUDED, and the reason it is excluded deserves reading before
# anyone relies on it - see the note in t/lint/202. It is request-supplied; so,
# on a default Apache (`UseCanonicalName Off`, which none of the shipped vhost
# examples override), is SERVER_NAME. Excluding one and permitting the other is
# not the guarantee the processor's comment believes it is. Recorded in SM926
# rather than changed here, because the fix is a vhost or a policy decision.
my %ENV_ALLOWLIST = map { $_ => 1 } qw(
    SERVER_NAME SERVER_PORT REQUEST_SCHEME HTTPS
    REQUEST_URI REDIRECT_URL
    DOCUMENT_ROOT SERVER_ADMIN
);

# Named, not returned straight from sort: `return sort ...` is undefined in scalar
# context, and a caller asking "how many variables may be interpolated?" is a
# reasonable thing to write. Same reasoning as _registration_groups in
# tools/lazysite-users.pl, and perlcritic refuses it at severity 5.
sub env_allowlist {
    my @names = sort keys %ENV_ALLOWLIST;
    return @names;
}

# SM926, RULED 2026-10-01: THE PRESENTED HOST IS THE HOST.
#
# One definition of "the host this request is for", shared by everything that
# needs one. There were two: lazysite-processor.pl's `_request_host` read
# HTTP_HOST to choose an alias host's config, and interpolation read whatever
# $ENV{SERVER_NAME} happened to hold - which under Apache's `UseCanonicalName`
# default of Off is the Host header, and under On is the configured ServerName.
# So a page and a notification could disagree about what host the site is on,
# conditional on a vhost setting none of the four shipped examples sets.
#
# The ruling settles it as a division of responsibility rather than a trust level:
# the engine uses the hostname it was given, and restricting what may be presented
# is the front end's job. A site that wants it fixed pins it - a literal
# `site_url` has no ${...} to expand and is left alone.
#
# VALIDATION IS NOT TRUST, it is hygiene: the host reaches filenames (the per-host
# page cache) and URLs, so only a DNS-shaped name of sane length is accepted and
# anything else reads as absent. That is the same validation the processor's copy
# has always done, and t/lint/203 pins the two identical.
sub request_host {
    my $host = lc( $ENV{HTTP_HOST} // q{} );
    $host =~ s/:\d+\z//;    # strip port
    $host =~ s/\.\z//;      # trailing dot (FQDN form)
    return q{} if length $host > 253;
    return q{}
        unless $host =~ /\A [a-z0-9] (?: [a-z0-9-]* [a-z0-9] )?
                         (?: \. [a-z0-9] (?: [a-z0-9-]* [a-z0-9] )? )* \z/x;
    return $host;
}

# SM929, RULED 2026-10-01: ONE DEFINITION OF THE REQUEST ADDRESS, AND ITS TRUST
# BASIS IS A NAMED LIST THAT DEFAULTS TO THE PRIVATE RANGES.
#
# Everything that asks "who is this request from" asked it differently. Forty-four
# reads across nine files: ten drove a DECISION (the login and form rate limits,
# the bad-URL auto-blocker, the DAV rate gate) and thirty-three went on the RECORD
# (`_ip` on a submission, the audit trail's actor column, the notification email,
# the daily visitor hash). Behind a front proxy every one of them saw the PROXY -
# one constant for every visitor a site will ever have, which is how SM929 was
# found: nine stored enquiries from six unrelated campaigns, all recording
# 10.2.30.177. A rate limit keyed on a constant is one bucket for the world, and
# the auto-blocker, whose threshold is ten bad URLs in an hour, blocks that
# constant - which is every visitor to the site.
#
# AND THE ONE READER THAT DID CONSULT THE FORWARDED HEADER TRUSTED IT BLINDLY.
# `client_ip` in the render path took the FIRST hop whenever the header was
# present. MEASURED ON A LIVE SITE 2026-10-01: an ordinary request rendered this
# caller's real public address, and the same request with
# `X-Forwarded-For: 203.0.113.7` rendered 203.0.113.7. A visitor chose what the
# engine believed, so unifying REMOVES an untrusted read as well as adding a
# trusted one.
#
# WHY THE RIGHTMOST HOP AND NOT THE FIRST. The filing asked for the first address,
# which is right for a proxy that REPLACES the header and wrong for one that
# APPENDS: a caller-supplied value then arrives AHEAD of the true one, which is
# exactly what that measurement shows. Walking from the right, every hop a trusted
# peer contributed is itself trusted, so the first address that is NOT trusted is
# the furthest one attributable to a peer we trust. A hop we cannot parse ENDS the
# walk rather than being skipped: skipping it would step further left, into the
# part of the chain the caller controls.
#
# THE TRUST BASIS IS THE PEER, WHICH NO CLIENT CAN SET. That is what makes this
# different in kind from the SM794 header-trust shape: REMOTE_ADDR comes from the
# server's own accept(), so there is no sentinel to forge and nothing for the trust
# source to clear. `auth_proxy_trusted` was considered and is NOT reused - it is a
# boolean about X-Remote-* AUTH headers with no hop check at all (SM794), so making
# it mean "and also believe this address" would overload one switch with two
# unrelated trust decisions.
sub _trusted_proxy_default {
    # A SUB, NOT A PACKAGE ARRAY: in the processor a file-scoped `our` below the
    # main body is EMPTY when a request is served (t/lint/39 names exactly this),
    # which would have left the render path trusting nothing and silently reading
    # the peer. A sub is initialised at call time and cannot be too early.
    return ( '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16' );
}

# The raw `trusted_proxies` line, or undef when the key is absent - which is NOT
# the same as empty. Four states, and they differ:
#   absent        -> undef -> the RFC1918 default above
#   empty         -> ''    -> trust nothing (clearing the field is a decision)
#   `none`        -> ''    -> trust nothing, said out loud
#   a list        -> that list, and only that
sub trusted_proxy_spec {
    my ($lazysite_dir) = @_;
    # Defined FIRST: form-handler.pl's $LAZYSITE_DIR is undef when the handler
    # library is missing, and interpolating it to build the path would warn.
    return undef unless defined $lazysite_dir && length $lazysite_dir;
    my $conf = "$lazysite_dir/lazysite.conf";
    return undef unless -f $conf;
    open my $fh, '<:utf8', $conf or return undef;
    my $spec;
    while ( my $l = <$fh> ) {
        next unless $l =~ /^trusted_proxies\s*:\s*(.*?)\s*$/;
        $spec = $1;
        last;
    }
    close $fh;
    return $spec;
}

# ($set, $rejected) - the parsed trust set, and every word that is not an address
# or range. PURE, and silent by design: the processor carries a pinned copy of this
# (ADR 0001) and a copy that logged would drift from one that could not. The
# REPORTING lives where an operator looks - tools/lazysite-check.pl names a rejected
# entry, because a trust list with a typo in it is a declaration the code ignores.
sub parse_trusted_proxies {
    my ($spec) = @_;
    $spec = '' unless defined $spec;
    $spec =~ s/\A\s+//;
    $spec =~ s/\s+\z//;
    my @words;
    # ABSENT AND EMPTY ARE THE SAME ANSWER, deliberately, and `none` is how an
    # operator says no. The Config page ships this field EMPTY and pressing Save
    # writes an empty value - SM782 names the same shape for backup_retention - so
    # reading empty as "trust nothing" would turn the feature off for any site
    # whose operator merely saved the page, silently, and put the proxy's address
    # back on every submission.
    if    ( !length $spec )       { @words = _trusted_proxy_default() }
    elsif ( lc($spec) eq 'none' ) { return ( [], [] ) }
    else                          { @words = split /[\s,]+/, $spec }
    my ( @set, @rejected );
    for my $w (@words) {
        my ( $addr, $bits ) = split m{/}, $w, 2;
        my $packed = _packed_address( $addr // '' );
        if ( !length $packed ) { push @rejected, $w; next }
        my $width = length($packed) * 8;
        $bits = $width if !defined $bits || !length $bits;
        # A zero-length prefix would match every peer, which makes the trust check
        # vacuous - the fault this whole change exists to remove. Refused, not
        # honoured: an operator who means that can name the ranges.
        if ( $bits !~ /\A[0-9]+\z/ || $bits + 0 > $width || $bits + 0 == 0 ) {
            push @rejected, $w;
            next;
        }
        push @set, [ $packed, $bits + 0 ];
    }
    return ( \@set, \@rejected );
}

# The address as bytes, or '' when it is not one. '' rather than undef so a caller
# tests `length` in any context - a bare `return` in list context is the trap
# feedback_bare_return_list_context names.
sub _packed_address {
    my ($text) = @_;
    return '' unless defined $text && length $text;
    return '' if $text =~ /[^0-9A-Fa-f:.]/;
    my $family = ( index( $text, ':' ) >= 0 ) ? AF_INET6 : AF_INET;
    my $packed = eval { inet_pton( $family, $text ) };
    return ( defined $packed && length $packed ) ? $packed : '';
}

# One address, one spelling - the same reasoning as lowercasing the request host.
sub _text_address {
    my ($packed) = @_;
    my $family   = length($packed) == 4 ? AF_INET : AF_INET6;
    my $text     = eval { inet_ntop( $family, $packed ) };
    return defined $text ? $text : '';
}

sub _address_in_set {
    my ( $packed, $set ) = @_;
    return 0 unless defined $packed && length $packed;
    for my $entry ( @{$set} ) {
        my ( $net, $bits ) = @{$entry};
        # Same family only: an IPv4 range never contains an IPv6 address, and
        # comparing their bytes would say otherwise.
        next unless length($net) == length($packed);
        my $whole = int( $bits / 8 );
        my $rest  = $bits % 8;
        next if $whole && substr( $packed, 0, $whole ) ne substr( $net, 0, $whole );
        if ($rest) {
            my $mask = 0xFF & ( 0xFF << ( 8 - $rest ) );
            next
                if ( ord( substr $packed, $whole, 1 ) & $mask )
                != ( ord( substr $net, $whole, 1 ) & $mask );
        }
        return 1;
    }
    return 0;
}

# SM1192 (test plan 0.15.10, F-1): EVERY VISITOR IS THE FRONT END. Behind a front
# proxy every request connects from the proxy's private or loopback address; unless
# the engine believes a forwarded address, an address rule applies to everyone at
# once. The decision is the engine's own: the peer is private, loopback or
# link-local AND request_address($spec) gives back the peer itself (no forwarded
# visitor is being believed). absent and empty mean the private-range default (only
# `none` trusts nothing), exactly as parse_trusted_proxies reads them. Returns
# ($peer, $cause, $set) or an empty list:
#   cause 'untrusted'  the peer is not in the effective trust set
#   cause 'no-forward' the peer IS trusted and no usable X-Forwarded-For arrives
# $set names the effective set for the sentence. Matching is parse_trusted_proxies
# and _address_in_set, the code the limiter uses, never a second parser.
sub front_end_is_every_visitor {
    my ($spec) = @_;
    my $peer   = $ENV{REMOTE_ADDR} // '';
    my $packed = _packed_address($peer);
    return () unless length $packed;
    my ($local) = parse_trusted_proxies(
        '10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 127.0.0.0/8 169.254.0.0/16 ::1 fc00::/7 fe80::/10');
    return () unless _address_in_set( $packed, $local );
    return () unless request_address($spec) eq $peer;
    my ($set) = parse_trusted_proxies($spec);
    my $s = defined $spec ? $spec : '';
    $s =~ s/\A\s+|\s+\z//g;
    my $named = lc($s) eq 'none' ? 'none' : length $s ? $s : 'the private-range default';
    return ( $peer, _address_in_set( $packed, $set ) ? 'no-forward' : 'untrusted', $named );
}

# THE one answer to "who is this request from". Give it the `trusted_proxies` spec
# (trusted_proxy_spec() reads it; the processor passes its own parsed value).
#
# With no forwarded header this returns exactly what every caller read before -
# REMOTE_ADDR, verbatim, not canonicalised - so a directly-served site is
# unaffected and that property is worth keeping rather than tidying.
sub request_address {
    my ($spec) = @_;
    my $peer   = $ENV{REMOTE_ADDR} // '';
    my ($set)  = parse_trusted_proxies($spec);
    return $peer unless @{$set};
    return $peer unless _address_in_set( _packed_address($peer), $set );
    my @chain = split /,/, ( $ENV{HTTP_X_FORWARDED_FOR} // '' );
    for my $hop ( reverse @chain ) {
        $hop =~ s/\A\s+//;
        $hop =~ s/\s+\z//;
        my $packed = _packed_address($hop);
        return $peer                  unless length $packed;
        return _text_address($packed) unless _address_in_set( $packed, $set );
    }
    return $peer;
}

# SM1129: THE ONE ANSWER TO "IS THIS REQUEST'S IDENTITY HEADER TRUSTWORTHY".
#
# `auth_proxy_trusted: true` used to be believed from ANY peer: a client that
# reached the CGI directly and sent X-Remote-User: admin was an operator
# (SM794 recorded the missing hop check and never built it; SM1128 P1-1 does).
# The flag now means "the identity headers come from a proxy", and WHICH proxy is
# `auth_proxy_trusted_from`: a comma/space list of addresses and CIDRs, matched
# against REMOTE_ADDR - the TCP peer, never X-Forwarded-For, which is the very
# thing a client sets. A SEPARATE setting from `trusted_proxies` (SM929): that one
# says whose X-Forwarded-For to believe about a visitor's address, this one whose
# identity headers to believe about a visitor's account, and the two sets need
# not be the same hosts.
#
# FAILS CLOSED. Flag on with the list absent, empty, `none`, or holding nothing
# parseable: nobody is trusted and the headers are stripped, as with the flag off
# (SM794 left the contract of the flag to the release manager and ruled nothing on
# an empty list; an unlisted proxy that is believed anyway is the defect). Unlike
# `trusted_proxies`, an empty value does NOT mean a default range.
#
# Every reader of the flag goes through here (t/lint/267): the processor's gate
# (its own pinned copy, ADR 0001), the manager API's gate, the auth wrapper, and
# the identity reader (Lazysite::Auth::Identity, SM1131), which reads the
# configured header names only when this says the proxy is trusted.
# Returns { flag, trusted, state, peer, from, rejected } where state
# is off | no-list | not-listed | listed.
sub proxy_identity {
    my ($lazysite_dir) = @_;
    my %r = (
        flag => 0, trusted => 0, state => 'off', from => '', rejected => [],
        peer => ( $ENV{REMOTE_ADDR} // '' ),
    );
    return \%r unless defined $lazysite_dir && length $lazysite_dir;
    my $conf = "$lazysite_dir/lazysite.conf";
    return \%r unless -f $conf;
    # An unreadable conf is a flag that reads off: closed. cannot_read says why.
    open my $fh, '<:utf8', $conf or do { cannot_read( 'the site conf', $conf ); return \%r };
    my ( $flag, $from ) = ( '', '' );
    while ( my $l = <$fh> ) {
        # Last one wins, as the processor's own conf reader has it.
        if    ( $l =~ /^auth_proxy_trusted\s*:\s*(.*?)\s*$/ )      { $flag = $1 }
        elsif ( $l =~ /^auth_proxy_trusted_from\s*:\s*(.*?)\s*$/ ) { $from = $1 }
    }
    close $fh;
    $r{from} = $from;
    $r{flag} = lc($flag) eq 'true' ? 1 : 0;
    return \%r unless $r{flag};
    my ( $set, $bad ) = ( [], [] );
    ( $set, $bad ) = parse_trusted_proxies($from) if length $from && lc($from) ne 'none';
    $r{rejected} = $bad;
    if    ( !@{$set} ) { $r{state} = 'no-list' }
    elsif ( _address_in_set( _packed_address( $r{peer} ), $set ) ) {
        $r{state}   = 'listed';
        $r{trusted} = 1;
    }
    else { $r{state} = 'not-listed' }
    return \%r;
}

# The value an allowlisted ${VAR} expands to. Only SERVER_NAME is special, and it
# is the whole of SM926's build: it resolves to the host PRESENTED, falling back to
# $ENV{SERVER_NAME} when there is no usable Host header - a CLI run, or a client
# that sent something that is not a hostname. Everything else is read from %ENV as
# before.
sub _env_value {
    my ($name) = @_;
    return $name eq 'SERVER_NAME'
        ? ( request_host() || $ENV{SERVER_NAME} )
        : $ENV{$name};
}

# Expand only allowlisted ${VAR}s. An allowlisted variable that is not SET
# expands to the empty string (the processor's behaviour, kept); one that is not
# allowlisted is left verbatim, so an unexpected placeholder stays visible rather
# than silently becoming ''.
sub interpolate_env {
    my ($val) = @_;
    return $val unless defined $val;
    $val =~ s{\$\{(\w+)\}}{
        $ENV_ALLOWLIST{$1} ? ( _env_value($1) // '' ) : "\${$1}"
    }ge;
    return $val;
}

# Did every ${VAR} in this value resolve to something? A cron- or CLI-driven
# caller has no CGI environment at all, so interpolate_env correctly returns
# `://` - and a caller building a LINK needs to know that rather than emit it.
# Notify uses this to fall back to a relative path.
sub env_interpolation_complete {
    my ($val) = @_;
    return 1 unless defined $val && $val =~ /\$\{/;
    while ( $val =~ /\$\{(\w+)\}/g ) {
        # SM926: through the SAME resolver interpolate_env uses, or this would
        # report `${SERVER_NAME}` as unresolvable on a request that has a Host
        # header and no SERVER_NAME - and Notify would then emit a relative path
        # on a site where the absolute one was perfectly available.
        return 0 unless $ENV_ALLOWLIST{$1} && length( _env_value($1) // '' );
    }
    return 1;
}

# Minimal JSON string escaper for the structured log format.
sub _json_str {
    my ($s) = @_;
    $s //= '';
    $s =~ s/\\/\\\\/g;
    $s =~ s/"/\\"/g;
    $s =~ s/\n/\\n/g;
    $s =~ s/\r/\\r/g;
    $s =~ s/\t/\\t/g;
    return $s;
}

# SM1152, SM1446: A PROCESS DETACHED FROM THE REQUEST - the registry rebuild a
# content write is owed, and a full backup that takes longer than any deadline in
# front of the manager. Double fork and setsid: no session, no terminal, no pipe
# the web server waits on (0-2 are /dev/null, 3-63 closed), and a parent that is
# init, so the request's own end - or its being killed - does not reach it.
#
# Returns 1 to the caller once the detached process exists (0 when it could not
# be forked) and undef IN the detached process, which must end with
# POSIX::_exit or an exec: it is a copy of the request and must not run its END
# blocks. $on_spawn, when given, runs in the intermediate process with the
# detached pid before the caller resumes - so what it records exists by then.
sub detach {
    my ($on_spawn) = @_;
    my $pid = fork();
    return 0 unless defined $pid;
    if ($pid) { waitpid( $pid, 0 ); return 1 }
    my $gc = fork();
    POSIX::_exit(1) unless defined $gc;
    if ($gc) {
        $on_spawn->($gc) if ref $on_spawn eq 'CODE';
        POSIX::_exit(0);
    }
    POSIX::setsid();
    if ( open my $null, '+<', '/dev/null' ) {
        POSIX::dup2( fileno($null), $_ ) for 0 .. 2;
    }
    POSIX::close($_) for 3 .. 63;
    return undef;
}

# Levelled logging to STDERR (text or json), honouring LAZYSITE_LOG_LEVEL and
# LAZYSITE_LOG_FORMAT. Component comes from $COMPONENT. Emitted diagnostics are
# ALSO forwarded to syslog - at WARN and above unless forward_diagnostics says
# otherwise, SM932 (see below). STDERR alone is not a sink this code can verify.
sub log_event {
    my ( $level, $context, $message, %extra ) = @_;
    my $min_level = $ENV{LAZYSITE_LOG_LEVEL} // 'INFO';
    my %rank      = ( DEBUG => 0, INFO => 1, WARN => 2, ERROR => 3 );
    return if ( $rank{$level} // 1 ) < ( $rank{$min_level} // 1 );
    my $ts     = POSIX::strftime( '%Y-%m-%d %H:%M:%S', localtime );
    my $format = $ENV{LAZYSITE_LOG_FORMAT} // 'text';
    no warnings 'uninitialized';    # helper subs in unit tests may pass undef
    my $line;
    if ( $format eq 'json' ) {
        my $pairs = join ',',
            map { '"' . _json_str($_) . '":"' . _json_str( $extra{$_} ) . '"' }
            keys %extra;
        $line = '{"ts":"' . $ts . '"'
            . ',"level":"' . _json_str($level) . '"'
            . ',"component":"' . _json_str($COMPONENT) . '"'
            . ',"context":"' . _json_str($context) . '"'
            . ',"message":"' . _json_str($message) . '"'
            . ( $pairs ? ",$pairs" : '' ) . '}';
    }
    else {
        my $extras = join ' ', map { "$_=" . ( $extra{$_} // '' ) } keys %extra;
        my $ctx    = $context // '';
        $line = "[$ts] [$level] [$COMPONENT] [$ctx] $message";
        $line .= " $extras" if $extras;
    }
    print STDERR "$line\n";
    my %prio = ( DEBUG => 'debug', INFO => 'info', WARN => 'warning', ERROR => 'err' );
    forward_line( 'diag', $prio{$level} // 'info', $line );
    return;
}

# --- External log forwarding (the 'Logging & forwarding' extension, log.pl) ----
#
# forward_audit / forward_diagnostics / syslog_facility in lazysite.conf control
# best-effort syslog copies of the two streams: audit-trail lines (the pipe
# format, at LOG_INFO) and log_event diagnostics (at their mapped priority).
# Config resolution rides the same path as log_level: an env override wins
# (LAZYSITE_FORWARD_AUDIT / LAZYSITE_FORWARD_DIAGNOSTICS /
# LAZYSITE_SYSLOG_FACILITY), else ONE cheap peek at lazysite.conf per process
# (located via $Lazysite::Audit::LAZYSITE_DIR, else DOCUMENT_ROOT); the result
# is cached, so a request pays at most one small-file read - and syslog is
# only opened when a stream is actually enabled. Sys::Syslog is core Perl.
#
# SM932, ruled 2026-09-30: DIAGNOSTICS FORWARDING IS ON BY DEFAULT, at WARN and
# above. Until this release log_event's only unconditional sink was
# `print STDERR`, and on a stack where a FastCGI child's STDERR does not reach
# the web server's error_log the engine had no reachable voice at all - an
# operator debugging a live site grepped error_log through four failing
# submissions and found nothing, while the same code from a terminal printed the
# cause at once. One unverifiable sink was the whole of it. A second sink does
# not make the first one work; it stops "nothing reached anybody" being the
# default outcome.
#
# The THRESHOLD is WARN rather than everything, and that is measured rather than
# preferred: cannot_read() logs at WARN, so WARN-and-above carries every repair
# the four-state work of 0.15.0 and 0.15.1 produced, while forwarding nothing
# new at INFO means no install's syslog volume changes on upgrade.
#
# forward_audit stays a boolean and stays OFF by default - it is a copy of an
# access record, not a diagnostic, and nobody has been unable to read it.
#
# Forwarding failure NEVER propagates: everything is eval-guarded, with a
# single WARN per process. Test seam (test-only): LAZYSITE_SYSLOG_DUMP=<file>
# appends "<priority> <line>" to that file instead of calling syslog, so tests
# can assert what would have been forwarded without a running syslogd.

my %FWD;                # cached forwarding config (per process)
my $fwd_warned;         # WARN once per process on forwarding TRANSPORT failure
my $fwd_conf_warned;    # WARN once per process on a bad/unreadable forwarding CONFIG
my $syslog_open;

sub _conf_bool {
    my $v = lc( $_[0] // '' );
    return $v =~ /^(?:1|on|yes|true|enabled)$/ ? 1 : 0;
}

# SM932: forward_diagnostics is a LEVEL, not a boolean, and absent means "WARN
# and above" rather than "off". Returns two values:
#   ( minimum rank to forward | undef to forward nothing, unrecognised value | undef )
#
#   absent              => 2   WARN and above - the default this release sets
#   off / 0 / no / false => undef, forward nothing
#   on / 1 / yes / true / all => 0, every level
#   a level name        => that rank (debug info warn|warning error|err)
#
# on/true meaning EVERY level is deliberate and is the backward-compatibility
# half of the change: an operator who switched forwarding on before this release
# asked for the whole stream and still gets exactly it, so no configured install
# changes behaviour. Only an install that never set the key moves, and it moves
# from nothing to WARN and above.
#
# An unrecognised value returns the default AND the offending value, so the
# caller can say so - a value the code silently ignores is the shape
# feedback_a_declaration_the_code_ignores exists to refuse.
sub _conf_diag_rank {
    my $v = lc( $_[0] // '' );
    $v =~ s/\A\s+//;
    $v =~ s/\s+\z//;
    return ( 2,     undef ) if $v eq '';
    return ( undef, undef ) if $v =~ /\A(?:0|off|no|false|disabled)\z/;
    return ( 0,     undef ) if $v =~ /\A(?:1|on|yes|true|enabled|all)\z/;
    my %rank = ( debug => 0, info => 1, warn => 2, warning => 2, error => 3, err => 3 );
    return ( $rank{$v}, undef ) if exists $rank{$v};
    return ( 2,         $v );
}

# The inverse of log_event's level -> syslog priority map, so forward_line can
# apply the diagnostics threshold to a line it only ever sees as a priority.
#
# An unknown priority ranks as err, not info: it is forwarded under every
# setting except "off". The point of this filing is diagnostics that went
# nowhere, so a line we cannot classify is one to pass on rather than drop.
my %SYSLOG_RANK = ( debug => 0, info => 1, warning => 2, err => 3 );

sub _syslog_rank { return $SYSLOG_RANK{ lc( $_[0] // '' ) } // 3 }

# SM932: reported only AFTER %FWD is fully built - never during. log_event calls
# forward_line calls _forward_conf, so warning mid-construction would forward
# against half-set values; by the time this runs $FWD{loaded} short-circuits the
# re-entry and every field has its value. Its own latch, separate from
# $fwd_warned, so a transport failure cannot suppress a config complaint.
sub _forward_conf_warn {
    my ( $message, $path, $detail ) = @_;
    return if $fwd_conf_warned++;
    log_event( 'WARN', 'forwarding', $message,
        file  => ( $path   // '' ),
        error => ( $detail // '' ) );
    return;
}

# Service killswitches (0.9.0): a network surface (MCP, OAuth, the control-API
# token path, token exchange) is OFF unless the operator explicitly enables it in
# lazysite.conf - the same posture WebDAV already has (webdav_enabled, default
# off). $docroot is DOCUMENT_ROOT (lazysite.conf is at $docroot/lazysite/). Absent
# / blank / false value => 0 (disabled). Cheap single-pass read; each surface
# calls this once at request entry.
sub service_enabled {
    my ( $docroot, $key ) = @_;
    return 0 unless defined $docroot && length $docroot && defined $key && length $key;
    open my $fh, '<', Lazysite::Paths::lazysite_dir($docroot) . "/lazysite.conf" or return 0;
    my $val = '';
    while ( my $l = <$fh> ) {
        if ( $l =~ /^\Q$key\E\s*:\s*(\S+)/ ) { $val = $1; last }
    }
    close $fh;
    return _conf_bool($val);
}

# SM1043 (SM1034, ruled Q2 "on by default"): is the member's account page on?
# It grants nothing, so it is ON unless lazysite.conf says `account_page:
# disabled` (or off/no/false/0). Asked by the processor, which serves /account,
# and by the manager API's me-* actions, so the page and its actions cannot
# disagree. Instance-wide: one account store serves every domain.
sub account_page_enabled {
    my ($lazysite_dir) = @_;
    return 1 unless defined $lazysite_dir && length $lazysite_dir;
    open my $fh, '<', "$lazysite_dir/lazysite.conf" or return 1;
    my $on = 1;
    while ( my $l = <$fh> ) {
        next unless $l =~ /^\s*account_page\s*:\s*(\S+)\s*$/;
        $on = ( $1 =~ /\A(?:disabled|off|no|false|0)\z/i ) ? 0 : 1;
        last;
    }
    close $fh;
    return $on;
}

sub _forward_conf {
    return \%FWD if $FWD{loaded};
    $FWD{loaded} = 1;
    my %want = (
        audit    => $ENV{LAZYSITE_FORWARD_AUDIT},
        diag     => $ENV{LAZYSITE_FORWARD_DIAGNOSTICS},
        facility => $ENV{LAZYSITE_SYSLOG_FACILITY},
    );
    my ( $conf_path, $conf_error );
    unless ( defined $want{audit} && defined $want{diag} && defined $want{facility} ) {
        my $dir =
            defined $Lazysite::Audit::LAZYSITE_DIR ? $Lazysite::Audit::LAZYSITE_DIR
            : defined $ENV{DOCUMENT_ROOT} ? Lazysite::Paths::lazysite_dir( $ENV{DOCUMENT_ROOT} )
            :                               undef;
        if ( defined $dir ) {
            $conf_path = "$dir/lazysite.conf";

            # SM932: this read decides whether the engine has a second sink, so
            # it may not fail in silence. It had no else branch at all, which is
            # the four-state defect SM917 swept out of the store readers - and
            # the one place it could not be fixed the same way, because
            # cannot_read() logs through log_event and log_event arrives here.
            # $! is captured immediately and reported at the end of the sub.
            if ( open my $fh, '<', $conf_path ) {    # not a store - site config
                while ( my $l = <$fh> ) {
                    $want{audit}    //= $1 if $l =~ /^forward_audit\s*:\s*(\S+)/;
                    $want{diag}     //= $1 if $l =~ /^forward_diagnostics\s*:\s*(\S+)/;
                    $want{facility} //= $1 if $l =~ /^syslog_facility\s*:\s*(\S+)/;
                }
                close $fh;
            }
            elsif ( !$!{ENOENT} ) {
                $conf_error = "$!";
            }
        }
    }
    $FWD{audit} = _conf_bool( $want{audit} );
    my ( $diag_rank, $diag_bad ) = _conf_diag_rank( $want{diag} );
    $FWD{diag} = $diag_rank;
    my $fac = lc( $want{facility} // 'daemon' );
    $fac = 'daemon' unless $fac =~ /^(?:daemon|local[0-7])$/;
    $FWD{facility} = $fac;

    # Both of these are reported through log_event, which re-enters this sub -
    # safe only because %FWD is complete and $FWD{loaded} is already 1. They
    # share one latch: an unreadable conf yields no value to be unrecognised, so
    # the two cannot both be true from the file, and one complaint is enough.
    _forward_conf_warn(
        'cannot read the log forwarding config - forwarding falls back to its defaults',
        $conf_path, $conf_error )
        if defined $conf_error;
    _forward_conf_warn(
        'unrecognised forward_diagnostics value - forwarding WARN and above instead',
        $conf_path, $diag_bad )
        if defined $diag_bad;
    return \%FWD;
}

sub _forward_warn {
    my ($err) = @_;
    $err = defined $err ? "$err" : '';
    $err =~ s/\s+$//;
    # Once per process; incremented BEFORE the nested log_event so its own
    # forward attempt cannot recurse back into a second warning.
    return if $fwd_warned++;
    log_event( 'WARN', 'forwarding', 'log forwarding failed', error => $err );
    return;
}

# SM932 (2): returns 1 when the line went to the sink, 0 when sending failed,
# and undef when the stream's setting does not forward it - so a probe can
# tell "not sent" from "sent and lost". Every other caller ignores it.
sub forward_line {
    my ( $stream, $priority, $line ) = @_;
    my $cfg = _forward_conf();

    # SM932: the audit stream stays a boolean; the diagnostics stream carries a
    # THRESHOLD, applied here rather than in log_event because four extensions
    # (audit, form-handler, form-smtp, payment-demo) carry their own log_event
    # copy and call straight into this sub. One gate, five callers.
    if ( $stream eq 'audit' ) {
        return unless $cfg->{audit};
    }
    else {
        return unless defined $cfg->{diag};
        return if _syslog_rank($priority) < $cfg->{diag};
    }
    if ( defined $ENV{LAZYSITE_SYSLOG_DUMP} && length $ENV{LAZYSITE_SYSLOG_DUMP} ) {
        my $ok = eval {
            open my $fh, '>>', $ENV{LAZYSITE_SYSLOG_DUMP} or die "$!\n";
            print {$fh} "$priority $line\n";
            close $fh;
            1;
        };
        _forward_warn("syslog dump: $@") unless $ok;
        return $ok ? 1 : 0;
    }
    my $ok = eval {
        require Sys::Syslog;
        unless ($syslog_open) {
            Sys::Syslog::openlog( 'lazysite', 'ndelay,pid', $cfg->{facility} );
            $syslog_open = 1;
        }
        Sys::Syslog::syslog( $priority, '%s', $line );
        1;
    };
    _forward_warn($@) unless $ok;
    return $ok ? 1 : 0;
}

# SM932 (2): the diagnostics forwarding setting as a reader can say it - for
# `lazysite check --sinks`, which must not re-read the config its own way.
# SM961: ONE LOCK FOR A STORE THAT IS BOTH APPENDED TO AND REWRITTEN.
#
# A submissions store is appended to by the file handler and rewritten whole
# (read, edit, write a copy, rename it over the original) by delete, confirm
# and approve. Locking the store file itself cannot serialise the two: the
# rename swaps the file, so an appender holding a lock on the old one writes
# into a file that is about to be thrown away - a submission lost with nothing
# logged. The lock is a SIDECAR that never moves: `.<name>.lock` beside the
# store. Returns the held handle (the lock is released when it goes out of
# scope, or on close) or undef with $! set. A reader-then-rewriter must take it
# BEFORE its read, so the rows it rewrites are all the rows there are.
sub store_lock {
    my ($path) = @_;
    my ( $dir, $base ) = $path =~ m{\A(.*)/([^/]+)\z} ? ( $1, $2 ) : ( '.', $path );
    open my $lk, '>>', "$dir/.$base.lock" or return undef;
    # T-115 (ruling 215): a lock beside a store in forms/ or auth/ takes the
    # store's mode, set rather than left to the umask (best effort).
    chmod 0660, "$dir/.$base.lock" if ( ( stat $lk )[2] & 07777 ) != 0660;
    flock( $lk, Fcntl::LOCK_EX() ) or return undef;
    return $lk;
}

sub forward_diagnostics_setting {
    my $cfg = _forward_conf();
    return { forwarding => ( defined $cfg->{diag} ? 1 : 0 ), facility => $cfg->{facility} };
}

# SM110 phase 2: the host-keyed page cache. An alias host's rendered pages
# live at lazysite/cache/hosts/<host>/<rel>.html (written by the processor,
# mirroring the page's docroot-relative path). Every surface that removes or
# overwrites a page's sibling .html cache must ALSO drop the per-host copies,
# or an alias host keeps serving the stale render after an edit.
#
# unlink_host_copies($docroot, $abs_html): given the SIBLING cache path
# ($docroot/<rel>.html), unlink <rel>.html under every host slot. Returns the
# number removed. Guards against traversal in the rel path (callers pass
# sysop/user-derived paths).
sub unlink_host_copies {
    my ( $docroot, $abs_html ) = @_;
    return 0 unless defined $docroot && length $docroot && defined $abs_html;
    my $hosts = Lazysite::Paths::lazysite_dir($docroot) . "/cache/hosts";
    return 0 unless -d $hosts;
    ( my $rel = $abs_html ) =~ s{^\Q$docroot\E/?}{};
    return 0 unless length $rel && $rel =~ /\.html\z/;
    return 0 if index( $rel, 'lazysite/' ) == 0;                # never a slot path itself
    return 0 if $rel =~ m{(?:^|/)\.\.(?:/|$)} || $rel =~ /\0/;  # no traversal
    my $n = 0;
    opendir my $dh, $hosts or return 0;
    for my $h ( readdir $dh ) {
        next if $h =~ /^\./;
        my $copy = "$hosts/$h/$rel";
        $n++ if -f $copy && unlink $copy;
    }
    closedir $dh;
    return $n;
}

# unlink_host_page($docroot, $host, $rel_html): remove ONE host's copy of a page
# (lazysite/cache/hosts/<host>/<rel>.html), so a per-host cache entry can be
# cleared surgically without touching the other language/domain siblings.
# Returns 1 if a file was removed. Host must be DNS-shaped; the rel path is
# traversal-guarded (callers pass operator/user-derived values).
sub unlink_host_page {
    my ( $docroot, $host, $rel ) = @_;
    return 0 unless defined $docroot && length $docroot;
    return 0 unless defined $host && $host =~ /\A[A-Za-z0-9.-]+\z/ && $host !~ /\.\./;
    ( my $r = ( $rel // '' ) ) =~ s{^/+}{};
    return 0 unless length $r && $r =~ /\.html\z/;
    return 0 if $r =~ m{(?:^|/)\.\.(?:/|$)} || $r =~ /\0/;
    my $copy = Lazysite::Paths::lazysite_dir($docroot) . "/cache/hosts/$host/$r";
    return ( -f $copy && unlink $copy ) ? 1 : 0;
}

# clear_host_cache($docroot): remove the whole hosts tree. Used where a sweep
# already drops every sibling cache (clear-all, theme/layout activation, nav
# change, backup restore) - wholesale removal is the simple, always-correct
# choice there; everything regenerates on the next request per host.
sub clear_host_cache {
    my ($docroot) = @_;
    return 0 unless defined $docroot && length $docroot;
    my $hosts = Lazysite::Paths::lazysite_dir($docroot) . "/cache/hosts";
    return 0 unless -d $hosts;
    require File::Path;
    File::Path::remove_tree( $hosts, { safe => 1 } );
    return 1;
}

1;
