package Lazysite::Paths;

# SM293 step 2: where the engine's own tree lives.
#
# WHY THIS EXISTS. `lazysite/` holds config, credentials, the audit log, session
# state, form submissions and pre-install snapshots - none of it content, and all
# of it inside the directory the web server serves. It is kept unreachable by a
# `deny /lazysite/` rule repeated in every shipped front-end template, which is
# the same arrangement SM248, SM268 H17 and SM283 each turned out to be: security
# living in configuration lazysite ships as a template, cannot test where it is
# installed, and on most deployments cannot even see.
#
# The concrete case, not a hypothetical: SM283's Hestia proxy answered static
# extensions off the docroot before Apache saw the request, so on any host whose
# list includes `gz` it would have served
# `lazysite/backups/preinstall-*.tar.gz` - a whole-site snapshot, including the
# account store, to anyone who knew the path.
#
# DISCOVERY, NOT ASSUMPTION - and this is the whole reason the change is safe.
# The engine ASKS where its tree is rather than computing one answer. A site
# migrates by MOVING THE DIRECTORY and nothing else: no config key, no flag day,
# no version gate. Both layouts work on the same code, so an upgrade cannot
# half-migrate a site into an unbootable state, and an operator who moves it back
# has undone the migration completely.
#
# This mirrors Lazysite::Private, deliberately. Two trees now sit beside the
# docroot on a migrated site:
#
#   <docroot>                    the served tree, and only content
#   <docroot>-lazysite           the engine's own tree (this module)
#   <docroot>-lazysite-private   protected content (Lazysite::Private)
#
# named for the docroot they belong to, so two sites under one parent directory
# can never share either. That naming was not free: a fixed name in the parent
# was the first shape of the private store, and it meant any two docroots with
# the same parent shared one store and each resolved the other's protected
# content.

use strict;
use warnings;
use File::Basename qw(dirname basename);
use Exporter 'import';

our @EXPORT_OK = qw(lazysite_dir external_lazysite_dir internal_lazysite_dir site_path
    stray_lazysite canonical_docroot processor_candidates find_processor dev_extension_dirs
    pool_conf_for docroot_of);

our $DIRNAME = 'lazysite';

# SM850: the in-docroot location, whether or not anything is there yet.
#
# For the few callers whose question is about THAT place rather than where the
# engine's tree is: a content walk that must not descend into an engine tree
# left in the served tree, a migration reporting what it would move. Everything
# that reads or writes engine state asks lazysite_dir instead - and t/lint/37
# holds that nothing else builds the path by hand.
sub internal_lazysite_dir {
    my ($docroot) = @_;
    return undef unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};
    return undef unless length $docroot;
    return "$docroot/$DIRNAME";
}

# The out-of-docroot location, whether or not anything is there yet.
sub external_lazysite_dir {
    my ($docroot) = @_;
    return undef unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};
    return undef unless length $docroot;
    return dirname($docroot) . '/' . basename($docroot) . "-$DIRNAME";
}

# Where this site's engine tree actually is.
#
# OUTSIDE WINS when both exist, and that direction is not a preference. A tree
# left inside the docroot is reachable by any front end that has not been told
# otherwise - the exposure being removed - so the engine must govern the copy
# that is safe and let stray_lazysite() report the one that is not. Preferring
# the inside copy would hide a half-finished migration behind working software,
# which is the worst of both.
sub lazysite_dir {
    my ($docroot) = @_;
    return undef unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};

    my $ext = external_lazysite_dir($docroot);
    return $ext if defined $ext && -d $ext;
    return "$docroot/$DIRNAME";
}

# SM1369 X4: THE DOCROOT AN ENGINE TREE BELONGS TO, for a caller that holds the
# tree only (the session verifier, which calls an identity provider's hooks).
# The inverse of lazysite_dir, proved by going forward again: the answer is
# the docroot whose lazysite_dir is this tree, or undef.
sub docroot_of {
    my ($lz) = @_;
    return undef unless defined $lz && length $lz;
    $lz =~ s{/+\z}{};
    my $base = basename($lz);
    my $docroot
        = $base eq $DIRNAME                ? dirname($lz)
        : $base =~ /\A(.+)-\Q$DIRNAME\E\z/ ? dirname($lz) . "/$1"
        :                                    undef;
    return undef unless defined $docroot && -d $docroot;
    my $back = lazysite_dir($docroot);
    return defined $back && $back eq $lz ? $docroot : undef;
}

# SM850: where a site-relative path the operator configured lives.
#
# lazysite.conf names files by a path relative to the site - `nav_file:
# lazysite/nav.conf`, `alias.<host>.nav_file: lazysite/nav-2.conf` - written
# when the engine tree could only be inside the docroot. A leading `lazysite/`
# means the ENGINE TREE, wherever it is; anything else is under the docroot.
# Joining the path to the docroot instead read and wrote `<docroot>/lazysite/`
# on a migrated site - a directory that is not there, so a nav save made a stray
# engine tree in the served tree and the live nav did not change.
#
# The processor carries a module-free copy of this rule (ADR 0001) in
# _nav_file_for; t/lint/37 drives both.
sub site_path {
    my ( $docroot, $rel ) = @_;
    return undef unless defined $docroot && length $docroot && defined $rel;
    $docroot =~ s{/+\z}{};
    ( my $r = $rel ) =~ s{\A/+}{};
    if ( $r =~ m{\A\Q$DIRNAME\E(?:/(.*))?\z}s ) {
        my $tail = $1;
        my $lz   = lazysite_dir($docroot);
        return defined $tail && length $tail ? "$lz/$tail" : $lz;
    }
    return "$docroot/$r";
}

# SM556: the docroot a DISPATCHER hands every manager module, resolved once.
#
# Every module confines a target by comparing realpath($target) against the
# $DOCROOT it was given, on the assumption that the given one is canonical.
# Under a symlinked DOCUMENT_ROOT that assumption held nowhere: three modules
# refused ("Invalid theme path", blocked, "Invalid submissions file") and two,
# which resolve both sides, succeeded. One site, one tree, two answers.
#
# Resolved ONLY when both spellings find the same engine tree - in practice an
# unmigrated site, whose tree sits inside the docroot. A migrated site's
# <docroot>-lazysite tree is named for one spelling and found only through it
# (beside the symlink, or beside the real directory); resolving would send the
# manager to a tree the front end does not serve, so the given spelling is
# kept. Given back unchanged when there is nothing to resolve.
sub canonical_docroot {
    my ($docroot) = @_;
    return $docroot unless defined $docroot && length $docroot;
    require Cwd;
    my $real = Cwd::realpath($docroot);
    return $docroot unless defined $real && length $real;
    ( my $given = $docroot ) =~ s{/+\z}{};
    return $real if $real eq $given;
    my $here  = Cwd::realpath( lazysite_dir($given) );
    my $there = Cwd::realpath( lazysite_dir($real) );
    return $docroot unless defined $here && defined $there && $here eq $there;
    return $real;
}

# Is this site half-migrated - an engine tree in BOTH places?
#
# Always a fault, and a quiet one: the engine reads the outside copy while the
# front end can still serve the inside one, so the site works perfectly and
# publishes its account store. Reported rather than repaired, because choosing
# which copy is current is a decision about an operator's live credentials.
sub stray_lazysite {
    my ($docroot) = @_;
    return 0 unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};
    my $ext = external_lazysite_dir($docroot);
    return ( defined $ext && -d $ext && -d "$docroot/$DIRNAME" ) ? 1 : 0;
}

# Move the engine tree OUT of the document root. Returns ( $ok, $error_or_note ).
#
# rename() is atomic within a filesystem and moves the whole tree in one step,
# which is what makes this safe to run on a live site: there is no window in
# which half the config, or half the account store, is in each place. Across
# filesystems it fails with EXDEV and this REFUSES rather than falling back to a
# copy - a half-copied auth store is the worst outcome available here, and the
# sysop can move it themselves and re-run the check.
#
# Idempotent: a site already migrated returns ok with a note, so "migrate
# everything" is safe to run repeatedly and safe to run on a mixed fleet.
sub migrate_out {
    my ($docroot) = @_;
    return ( 0, 'no docroot given' ) unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};

    my $inside = "$docroot/$DIRNAME";
    my $ext    = external_lazysite_dir($docroot)
        or return ( 0, 'cannot derive the external location' );

    return ( 0, 'this site has an engine tree in BOTH places - resolve that by '
            . 'hand before migrating; the engine is already reading the one '
            . 'outside, so the copy inside the document root is the one to '
            . 'check and remove' )
        if -d $ext && -d $inside;

    return ( 1, 'already migrated' ) if -d $ext;
    return ( 0, "no engine tree at $inside" ) unless -d $inside;

    return ( 0, 'something already exists at the destination' ) if -e $ext;

    unless ( rename $inside, $ext ) {
        my $err = "$!";
        return ( 0, 'cannot move the engine tree across filesystems - move it '
                . "by hand and re-run: $err" )
            if $err =~ /cross-device|Invalid cross/i;
        return ( 0, "cannot move the engine tree: $err" );
    }
    return ( 1, 'migrated' );
}

# And back, for a sysop who wants to undo it. Same contract reversed.
#
# Reversibility is not politeness. It is what lets a site be migrated on edge,
# watched, and put back without a release if anything about the deployment turns
# out to disagree.
sub migrate_back {
    my ($docroot) = @_;
    return ( 0, 'no docroot given' ) unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};

    my $inside = "$docroot/$DIRNAME";
    my $ext    = external_lazysite_dir($docroot)
        or return ( 0, 'cannot derive the external location' );

    return ( 0, 'this site has an engine tree in BOTH places - resolve that by '
            . 'hand first' )
        if -d $ext && -d $inside;

    return ( 1, 'already inside the document root' ) if -d $inside;
    return ( 0, "no engine tree at $ext" ) unless -d $ext;

    unless ( rename $ext, $inside ) {
        my $err = "$!";
        return ( 0, "cannot move the engine tree back: $err" );
    }
    return ( 1, 'moved back' );
}

# SM1066 (ruled 2026-10-12, "Fix, own branch"): WHERE THE CONTENT PROCESSOR IS,
# one lookup for every preview. Manager::Common::processor_path (the manager's
# previews, MCP preview_public_page and preview_domain) read LAZYSITE_PROCESSOR
# or else the docroot's ../cgi-bin; MCP preview_page looked beside
# lazysite-mcp.pl. The nginx examples and the Hestia templates set
# LAZYSITE_PROCESSOR only for the processor and the manager API, so on an
# install whose cgi-bin is not the docroot's ../cgi-bin the first two MCP
# previews shelled a processor that was not there while the third rendered.
#
# The candidates, in order; the first that is a readable file wins:
#
#   1. the directory LAZYSITE_PROCESSOR names. Only the DIRECTORY: in the
#      wrapped deployment the auth wrapper sets it to the ORIGINALLY requested
#      CGI - the manager API itself when a preview runs - so shelling it would
#      re-enter the manager ("Authentication required"), not render.
#   2. beside the running CGI ($script, else $0), through abs_path exactly as
#      MCP resolved itself, so a symlinked cgi-bin entry gives the same answer
#      as it did there.
#   3. the docroot's ../cgi-bin.
#
# Readable, not executable: every caller runs the processor through $^X, and
# the source tree, the dev server and the suite carry the CGIs at 0644. Where
# a rule above found the processor before, it still does, at the same path
# (t/unit/lib/90 holds that over the packaged layouts); only an install where a
# preview found nothing now finds one.
#
# Returns the path, or undef when no candidate is a processor.
sub processor_candidates {
    my ( $docroot, $script ) = @_;
    my @c;
    my $lp = $ENV{LAZYSITE_PROCESSOR};
    push @c, dirname($lp) . '/lazysite-processor.pl' if defined $lp && length $lp;
    $script //= $0;
    if ( defined $script && length $script ) {
        require Cwd;
        my $real = Cwd::abs_path($script);
        push @c, dirname($real) . '/lazysite-processor.pl' if defined $real && length $real;
    }
    push @c, "$docroot/../cgi-bin/lazysite-processor.pl" if defined $docroot && length $docroot;
    return @c;
}

# SM1222 (ruled 2026-10-20, "an extensions dir, yes, that allows multiple"): THE
# DEV SERVER'S EXTRA EXTENSION DIRECTORIES. tools/lazysite-server.pl --extensions
# DIR (repeatable) hands them to the CGIs it runs as LAZYSITE_EXTENSION_DIRS,
# colon separated, in the order given - and sets LAZYSITE_DEV_SERVER, which is
# what this honours. An installed engine is never started by that server, so for
# it both are unset and this returns (): the lookup beside the docroot is the only
# one, as before. A directory that is not a real directory (missing, or itself a
# symlink) is dropped here again, so a hand-set variable cannot widen the lookup
# past what the server accepts. Each is searched BEFORE the docroot's own
# extensions/: an explicit choice outranks the implicit default, and a development
# copy can stand in for a shipped one. A name in two directories: the first wins.
sub dev_extension_dirs {
    return () unless $ENV{LAZYSITE_DEV_SERVER};
    my $list = $ENV{LAZYSITE_EXTENSION_DIRS};
    return () unless defined $list && length $list;
    my @dirs;
    for my $d ( split /:/, $list ) {
        next unless length $d && $d =~ m{\A/} && -d $d && !-l $d;
        push @dirs, $d;
    }
    return @dirs;
}


sub find_processor {
    my ( $docroot, $script ) = @_;
    for my $c ( processor_candidates( $docroot, $script ) ) {
        return $c if -f $c && -r _;
    }
    return undef;
}

# SM1226 (ruled 2026-10-20: the warm-fork parent runs "only where a front end
# uses it"): THE HOST'S POOL CONF FOR THIS DOCROOT. Every front end that hands
# the Odoo endpoint to its warm-fork parent does it through the site's pool (the
# one-rule pool's front door; the split templates' location for the endpoint),
# and a pool is /etc/lazysite/pools/<instance>.conf, the conf lazysite@.service
# reads. A plain-CGI site has none. Matched on DOCROOT= (the instance name is
# only conventionally the domain), as `lazysite check` matches it
# (find_pool_conf); LAZYSITE_POOLS_DIR moves the directory, as there, so a test
# stands in for the host. Returns the conf's path, or undef.
sub pool_conf_for {
    my ($docroot) = @_;
    return undef unless defined $docroot && length $docroot;
    my $dir = $ENV{LAZYSITE_POOLS_DIR} || '/etc/lazysite/pools';
    opendir my $dh, $dir or return undef;
    my @confs = sort grep { /\.conf\z/ } readdir $dh;
    closedir $dh;
    require Cwd;
    my $want = Cwd::abs_path($docroot) // $docroot;
    for my $c (@confs) {
        open my $fh, '<', "$dir/$c" or next;
        my $root;
        while ( my $l = <$fh> ) {
            $root = $1 if $l =~ /^\s*DOCROOT\s*=\s*"?([^"\s]+)"?/;
        }
        close $fh;
        next unless defined $root;
        return "$dir/$c" if ( Cwd::abs_path($root) // $root ) eq $want;
    }
    return undef;
}

1;
