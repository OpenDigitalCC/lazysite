---
title: "lazysite - host dependencies"
subtitle: "The OS packages a host needs, beyond core Perl"
brand: plain
standard-margins: true
---

**Generated file - do not edit by hand.** Produced from
`dist/config/sbom-deps.json` by `tools/gen-host-deps.pl`; that JSON is the
authoritative machine-readable list. To check a live host instead of reading
this snapshot, run `lazysite-check.pl --dependencies`, which reports which of
these are present and prints the install line for whatever is missing.

## What you need

lazysite runs on core Perl plus a small set of packaged Perl modules. The core
modules ship with the `perl` package (Debian: `perl-modules-*`); only the
non-core packages below must be installed explicitly. Package names are Debian;
`sbom-deps.json` also carries the RHEL and Alpine equivalents.

On Debian or Ubuntu, install them all with:

```bash
sudo apt-get install \
    libarchive-zip-perl \
    libcryptx-perl \
    libdbd-sqlite3-perl \
    libdbi-perl \
    libfcgi-perl \
    libfcgi-procmanager-perl \
    libio-socket-ssl-perl \
    libnet-dns-perl \
    libnet-ssleay-perl \
    libnet-xmpp-perl \
    libodoo-oom-perl \
    libtemplate-perl \
    libtext-multimarkdown-perl \
    liburi-perl \
    libwww-perl \
    libyaml-pp-perl
```

## Packages

```datatable
columns: Package | Perl module(s) | Enables
widths: 5cm | 4.5cm | X
bold: 1
tone: medium
text: 3
---
libarchive-zip-perl | Archive::Zip | theme upload (manager), zip download (manager)
libcryptx-perl | Crypt::PK::ECC, Crypt::PK::Ed25519, Crypt::PK::RSA | passkeys (SM1352): an ECDSA P-256 passkey's signature; web push (SM1363): the VAPID signature; lazy-required only by those two (ruling 187); passkeys (SM1352): an Ed25519 passkey's signature; lazy-required only when one signs in or enrols; passkeys (SM1352): an RSA passkey's signature; lazy-required only when one signs in or enrols
libdbd-sqlite3-perl | DBD::SQLite | data extension: the SQLite storage engine (tier zero, one file at lazysite/db/data.sqlite)
libdbi-perl | DBI | data extension: the database interface every adapter is written against
libfcgi-perl | FCGI | FastCGI accept loop (SM142, optional; lazy-required - plain CGI needs nothing)
libfcgi-procmanager-perl | FCGI::ProcManager | FastCGI prefork pool (SM142, optional; lazy-required when LAZYSITE_FCGI_WORKERS>0)
libio-socket-ssl-perl | IO::Socket::SSL | SMTP form delivery over STARTTLS; domain-check TLS/cert probe (SM156, lazy-required)
libnet-dns-perl | Net::DNS | XMPP endpoint from the domain's SRV record (SM925 X2; notify-xmpp extension, optional; lazy-required only when enabled)
libnet-ssleay-perl | Net::SSLeay | domain-check certificate expiry read (SM156; also IO::Socket::SSL's own backend)
libnet-xmpp-perl | Net::XMPP | XMPP notification delivery (notify-xmpp extension, optional; lazy-required only when enabled)
libodoo-oom-perl | Odoo::Client, Odoo::Error, Odoo::Ops, Odoo::Ops::Blob, Odoo::Ops::Client::Daemon, Odoo::Ops::Config, Odoo::Ops::Context, Odoo::Ops::Daemon::Path, Odoo::Ops::File, Odoo::Ops::Journal, Odoo::Ops::Plan, Odoo::Ops::Registry, Odoo::Ops::Rows, Odoo::Ops::Runner, Odoo::Ops::Runs, Odoo::Ops::Version, Odoo::Transport::Session | Odoo extension (SM1162): reads a request file's type from its bytes and applies OOM's own check of a file value (a plain name, max_bytes) before it reaches an operation; lazy-required only when a binding maps a file, and absent before OOM 0.34; Odoo extension (SM1164): asks oomd's health verb for Status and the version check; lazy-required only when the extension runs; Odoo extension (SM1164): the client of oomd, the resident OOM, through which every operation call goes when odoo_daemon is on; lazy-required only when the extension runs, and absent before OOM 0.31; Odoo extension (SM1164): the installed OOM version, which the oomd service compares with the running daemon's; holds only $VERSION; Odoo extension (SM1171): reads back a custom change's returned value that OOM 0.32 kept in the journal as a blob, so it is capped as the value it is; lazy-required only when the extension runs, and absent before 0.32; Odoo extension (SM1171): reads the journal OOM kept of an apply, so the answer can say per change what became of it; lazy-required only when the extension runs; Odoo extension (SM1198): OOM's check of a request's list of rows, which loads only Odoo::Error, Odoo::JSON and Odoo::Ops, so a call through oomd needs no registry; lazy-required when a binding maps a rows parameter, and absent before OOM 0.36; Odoo extension (SM747 B): signs a person in to Odoo once with their password and carries their session, through OOM's session transport (OOM 0.03); lazy-required only when the extension runs; Odoo extension (SM747 C): asks Odoo who a signed-in session is, to refresh the identity cookie; lazy-required only when the extension runs; Odoo extension (SM747): OOM's error kinds and fault categories, mapped to lazysite's fault kinds; lazy-required only when the extension runs; Odoo extension (SM747): a write operation's sealed plan, kept in the extension's private store until applied; lazy-required only when the extension runs; Odoo extension (SM747): applies a confirmed plan through OOM's journal; lazy-required only when the extension runs; Odoo extension (SM747): one guarded connection per call, carrying the lazysite actor; lazy-required only when the extension runs; Odoo extension (SM747): records the approval OOM's runner requires before it applies a plan (a confirm, or a binding that applies immediately); lazy-required only when the extension runs, and absent from an OOM that predates the run registry; Odoo extension (SM747): the connection built in memory per call; lazy-required only when the extension runs; Odoo extension (SM747): the named operations a binding may name; lazy-required only when the extension runs; Odoo extension (SM747): the operations layer - presence and version check (>= 0.02); lazy-required only when the extension runs
libtemplate-perl | Template, Template::Filters, Template::Parser | SM071 layout.tt compile validation in the control API (ships with Template); Template Toolkit page rendering (processor core); n785 the page-parse guard's list of Template Toolkit's standard filters (ships with Template)
libtext-multimarkdown-perl | Text::MultiMarkdown | Markdown to HTML conversion (processor core)
liburi-perl | URI | URL parsing in SSRF guard and remote-fetch path resolution
libwww-perl | LWP::UserAgent | remote content fetch for :::include and url: variables, form webhook delivery
libyaml-pp-perl | YAML::PP | data extension: reading table field descriptors
```

## Runtime environment

perl
: Perl runtime. Required version 5.10+. On Debian: 'perl'. On Alpine: 'perl'. On RHEL: 'perl'. Includes core modules listed above.

git
: Host binary for the SM085 content history (conf key 'git_history: enabled'). Optional - only needed when the feature is enabled; invoked list-form (never through a shell), never a Perl module. Saves keep working without it (lazysite-check WARNs). Debian: 'git'.

Apache HTTP Server
: CGI host. Operator-provided. Any CGI/1.1-capable server works; Apache is the reference platform. The dev server (tools/lazysite-server.pl) is evaluation-only.

## Development-only: nginx

nginx is **not** a runtime or build dependency. It is used by two tests, both
of which skip cleanly when it is absent:

- `t/lint/34-front-end-configs-parse.t` runs `nginx -t` over every shipped
  nginx config, so one that will not start cannot ship. A front-end config that
  fails to parse takes a site down at the front door rather than degrading.
- `t/integration/42-hestia-proxy-gates-statics.t` starts nginx against the
  rendered Hestia proxy template and reproduces SM283's field measurement.

Install with `apt install nginx-light` (no service needs to run; the tests use
their own prefix, config and port). `openssl` is used to make a throwaway
certificate for the SSL template.

Worth stating plainly, because it is the lesson of SM283: the defect was in an
nginx config, on a repo whose entire coverage of nginx configs was text
matching, and the text matched. These two tests skipping is a real gap wherever
they skip - `t/lint/33` still pins the same files by text so that something
holds there, but it is the weaker check, not an equivalent one.

## Core modules

The remaining modules lazysite uses (`Digest::SHA`, `File::*`, `POSIX`, `Cwd`,
`Encode`, `JSON::PP`, `MIME::Base64`, `Socket`, `IO::Socket::INET`, and the
rest) are core Perl - present wherever Perl is. The full list, with per-module
purpose and licence, is in `dist/config/sbom-deps.json`.
