package main;

# lazysite-processor/registries.pm - the page scan and the generated registries.
#
# HOLDS   resolve_scan(): the `scan:` source a page names, with
#         _scan_parse_modifiers (filter=, sort=, and limit=/offset=, P9),
#         _scan_collect_files, _page_date, _page_url,
#         _scan_limit (the site's cap, P9), _front_matter_reserved (the
#         engine's front-matter keys, shared with the page's own stash),
#         _front_matter_private, _front_matter_custom and _page_tags (what a
#         scan and a registry object carry of a page's front matter, P12) and
#         _scan_page_unreadable (the log line
#         for a page a walk leaves out, SM976 Q15h); _listed_by_default,
#         _registry_lists, _llms_txt_on and _registry_organisation (SM1357, ruling
#         165: the sitemap and the summary list every public page, the summary
#         has a switch and carries the organisation entry); _public_page_set and
#         _in_public_page_set (ruling 174: the one page set both list),
#         _registry_scan_root (the root a host's registries are built from) and
#         _public_page_set_listing (that set as `lazysite check` reads it, n785);
#         _foreign_site_folder (ruling 171: another site's folder, undeclared) and
#         the scan's two askers of it, _scan_foreign_dir and _scan_under_foreign_dir
#         (ruling 176: site search leaves those folders out too);
#         scan_pages(), the walk
#         the registries are built from; update_registries() and its P-3 memo of whether any
#         registry template exists; _feed_dates; the registry serving path -
#         _serve_registry, _registry_cache_path, _registry_ct, _registry_stale
#         and _regenerate_registries_once (the one regenerator, SM389, under a
#         lock), and _schedule_registry_rebuild (SM1152: a stale registry is
#         rebuilt by a detached child, not inside the request that found it).
# OWNS    what a scan lists and in what order; where a registry is cached and
#         when it is regenerated; the content type it is served as.
# CALLS   parse_yaml_front_matter, _scan_hidden, _registry_hidden, _scan_scalar, _system_page_names,
#         _draft_requested,
#         peek_search_default, peek_conf_key, _language_set, resolve_site_vars,
#         confine_content_root, _content_rel, _private_twin, _path_under_content,
#         _declared_content_roots, _conf_value, _security_headers (its own
#         status line), _tt_dep, _cache_umask, read_file, log_event (the script
#         and its parts); Template->new; dirname, realpath, make_path and the
#         Fcntl LOCK_* constants (imported by the script's `use`, before its
#         parts load; the constants written as calls, so the part compiles alone).
# READS   $DOCROOT, $LAZYSITE_DIR, $REGISTRY_DIR, $REGISTRY_CACHE_DIR,
#         $REGISTRY_TTL, $REQUEST_CROOT, $TT_COMPILE_DIR, %ACCESS_REC,
#         $ENGINE_DOCS_DIR, $ENGINE_DOC_RENDER (the
#         script's, declared `our` there).
#
# A PART OF THE PROCESSOR, NOT A MODULE (SM944 S15). It is package main, required
# by absolute path from lazysite-processor.pl's BEGIN and never through @INC, and
# it loads nothing - ADR 0001 keeps the render path free of the Lazysite:: tree.
use strict;
use warnings;

our ( $DOCROOT, $LAZYSITE_DIR, $REGISTRY_DIR, $REGISTRY_CACHE_DIR, $REGISTRY_TTL, $REQUEST_CROOT, $TT_COMPILE_DIR, %ACCESS_REC,
    $ENGINE_DOCS_DIR, $ENGINE_DOC_RENDER );
our $REGISTRY_REBUILDING;    # SM1152: true in the detached rebuild itself

# --- Scan and registries ---
#
# The reserved front-matter keys, the scan: source, the registry regenerator and
# its serving path, scan_pages, and the TT helpers they share.

# SM459: the front-matter keys the ENGINE owns.
#
# Shared by the page scan and the page's own stash, deliberately. They used to
# disagree: a custom key was visible to a SCAN of the page and invisible to the
# page's own template, so an author wanting one fact in both places wrote it
# twice - once top-level for the index, once inside tt_page_var for their own
# layout - and the two copies drifted with nothing comparing them. That is the
# duplication the metadata exists to remove.
#
# One list, one place. Two copies of a reserved list is the same defect one
# level up, and this programme has met it twice already (SM435, SM457).
#
# SM522: a SUB, not a file-scoped hash. `our %FRONT_MATTER_RESERVED = ...`
# sat here, below the dispatch, and was still EMPTY when a CGI or FastCGI
# request was served - the SM293 shape with `our` in place of `my` - so a
# page's `auth:` and `layout:` reached the stash as page_auth / page_layout
# and the scan carried them as custom keys. A sub is initialised at call
# time and cannot be too early (t/lint/39).
sub _front_matter_reserved {
    return { map { $_ => 1 } qw(
            url title subtitle date tags excerpt searchable path
            layout theme auth register search meta_title meta_desc ) };
}

# P12 (WORK-PLAN-0154, ruled 2026-10-12 "Full front matter + general lists"):
# THE ENGINE-PRIVATE KEYS - what a REGISTRY never publishes, beyond the reserved
# keys above (which are computed fields, or the engine's) and anything named
# tt_* or _*. A registry is a static file served to anyone (sitemap.xml,
# llms.txt, a feed, a site's own JSON index), so the keys that say how the
# engine treats a page - who may read it, what it costs, which form it binds,
# how it is served - stay out of it, as does a page's own engine stash. The scan
# object, which is rendered for a reader the scan's gate has already admitted,
# is unchanged.
sub _front_matter_private {
    return { map { $_ => 1 } qw(
            auth_groups payment form query_params sections tt_page_var
            api raw content_type ttl redirect ) };
}

# A page's custom front matter as a scan or registry object carries it: every
# key not reserved and not tt_*/_*, a list as a list (P13), a scalar with its
# surrounding quotes and TT markers stripped (_scan_scalar). One definition, so
# the scan and the registries cannot disagree about what a page says (P12).
sub _front_matter_custom {
    my ( $meta, $reserved, $private ) = @_;
    my %custom;
    for my $k ( keys %$meta ) {
        next if $reserved->{$k} || $k =~ /^(?:tt_|_)/;
        next if $private && $private->{$k};
        my $v = $meta->{$k};
        if    ( ref $v eq 'ARRAY' ) { $custom{$k} = [ map { _scan_scalar($_) } @$v ] }
        elsif ( !ref $v )           { $custom{$k} = _scan_scalar($v) }
    }
    return \%custom;
}

# A page's tags as a list: a YAML list, a comma-separated string, or one value.
sub _page_tags {
    my ($meta) = @_;
    my $tags_raw = $meta->{tags} // '';
    return [@$tags_raw] if ref $tags_raw eq 'ARRAY';
    return [] unless length $tags_raw;
    return [ map { s/^\s+|\s+$//gr } split /,/, $tags_raw ];
}

# The scan modifiers, parsed off the front of the pattern (PR-6). Lifted out
# of resolve_scan verbatim; it still STRIPS what it parses, which is why it
# takes the pattern by reference - the remaining text is the glob.
sub _scan_parse_modifiers {
    my ($pattern_ref) = @_;

    # Parse filter modifiers: "filter=FIELD:VALUE" (may repeat)
    my @filters;
    while ( $$pattern_ref =~ s/\s+filter=(\w+):([^\s]+)// ) {
        push @filters, { field => $1, value => $2 };
    }

    # Parse sort modifier: "sort=FIELD DIRECTION"
    my $sort_field = 'filename';
    my $sort_dir   = 'asc';
    if ( $$pattern_ref =~ s/\s+sort=(\w+)(?:\s+(asc|desc))?//i ) {
        $sort_field = lc($1);
        $sort_dir   = lc($2) if defined $2;
        # date/title/filename are the built-ins; any other identifier sorts on the
        # matching (passed-through) custom front-matter key, e.g. sort=order.
        $sort_field = 'filename' unless $sort_field =~ /^\w+$/;
    }

    # P9 revise (ruled 2026-10-12, "Keep, add per-scan limit="): `limit=N` and
    # `offset=N` page the filtered, sorted list. Stripped whatever their value,
    # so a bad one can never reach the glob; a bad one is ignored and logged.
    my %page;
    for my $k (qw(limit offset)) {
        next unless $$pattern_ref =~ s/\s+$k=(\S*)//;
        my $v  = $1;
        my $ok = $k eq 'limit' ? qr/\A[1-9]\d{0,6}\z/ : qr/\A\d{1,7}\z/;
        if ( $v =~ $ok ) { $page{$k} = 0 + $v; next }
        log_event( 'WARN', $ENV{REDIRECT_URL} // '-',
            "scan: $k= is not a whole number - ignored", value => $v );
    }

    return ( \@filters, $sort_field, $sort_dir, \%page );
}

# The files a scan pattern reaches, capped and deduplicated (PR-6). Lifted out
# of resolve_scan verbatim: same roots, same walk, same private-wins dedupe,
# the cap the caller passes (P9: the site's scan_limit, 200 by default) in the
# same order, and the same _tt_dep calls on the way.
# SM1357 (ruling 165): THE SITEMAP AND THE AI-READABLE SUMMARY LIST EVERY PUBLIC
# PAGE. They used to list only the pages that said `register: [sitemap.xml]`, so a
# page an author never thought to register was invisible to search engines and
# to an AI client reading llms.txt, on every site, by default.
#
# A page with no `register:` key is now listed in both. A page that has one keeps
# what it says - its list is the author's choice of registries, and a page that
# names only a feed has said it is not for the sitemap. Left out whatever its
# register says, because it is not a page for a search engine or a reader:
#
#   search: false            the author has kept it out of search
#   api: / raw: true         an endpoint or a data file, not a page
#   redirect:                an address that sends the visitor elsewhere
#   starter_role: demonstration   the starter's showroom pages (SM486: four live
#                            sites advertised /lazysite-demo in their sitemap)
#
# and, as before and for every registry, a draft, a gated or protected page and
# anything under lazysite/ - which holds SM1354's page copies - never reach a
# registry at all (_registry_hidden, scan_pages).
sub _listed_by_default {
    my ( $meta, $url ) = @_;
    return 0 if exists $meta->{register};
    return 0 if defined $url && _registry_system_page($url);
    return _registry_listable($meta);
}

# The engine's own pages at a content root - sign-in, sign-out, the error pages -
# which a site may keep its own copy of (SM201). Not content, so not listed by
# default; a copy that registers itself keeps what it says. The names are the
# script's own %SYSTEM_PAGES, asked through _system_page_names - one list.
sub _registry_system_page {
    my ($url) = @_;
    my %sys = map { ( "/$_" => 1 ) } _system_page_names();
    return $sys{$url} ? 1 : 0;
}

sub _registry_listable {
    my ($meta) = @_;
    return 0 if ( $meta->{search}         // '' ) =~ /\A\s*["']?false["']?\s*\z/i;
    return 0 if ( $meta->{api}            // '' ) =~ /\A\s*true\s*\z/i;
    return 0 if ( $meta->{raw}            // '' ) =~ /\A\s*true\s*\z/i;
    return 0 if length( $meta->{redirect} // '' );
    return 0 if ( $meta->{starter_role}   // '' ) =~ /\A\s*demonstration\s*\z/i;
    return 1;
}

# Which pages a feed lists: its own registrants. The sitemap and the summary list
# the ONE public page set instead (_public_page_set, below).
sub _registry_lists {
    my ( $name, $page ) = @_;
    return ( grep { $_ eq $name } @{ $page->{register} || [] } ) ? 1 : 0;
}

# Ruling 174: THE SITEMAP AND THE SUMMARY ARE EQUIVALENT - built from one page
# set and listing exactly the same pages. Before, each read its own registrants,
# so a page registered for the sitemap alone was in the sitemap and missing from
# llms.txt, and the two drifted apart page by page. Both now call this one
# function. A page is in the set when it is listable (_registry_listable: not
# api/raw, search: false, a redirect or a demonstration page) and either nobody
# registered it (_listed_by_default) or it registered for EITHER of the two. A
# draft, a protected page (auth:, auth_groups:, a read rule) and a page copy
# never reach @pages at all (scan_pages, _registry_hidden), nor a folder that
# looks like another site's content (ruling 171, _foreign_site_folder).
sub _public_page_set_registry {
    my ($name) = @_;
    return ( $name eq 'sitemap.xml' || $name eq 'llms.txt' ) ? 1 : 0;
}

sub _in_public_page_set {
    my ($page) = @_;
    return 0 unless $page->{_listable};
    return 1 if $page->{_default};
    return ( grep { _public_page_set_registry($_) } @{ $page->{register} || [] } ) ? 1 : 0;
}

sub _public_page_set {
    my (@pages) = @_;
    return grep { _in_public_page_set($_) } @pages;
}

# The content root this request's host builds its registries from (SM110/SM151,
# update_registries): its own content_root, else the docroot - and undef for an
# alias without a root of its own, which shares the docroot's registries and
# builds none.
sub _registry_scan_root {
    my %sv = resolve_site_vars();
    if ( defined $sv{content_root} && length $sv{content_root} ) {
        my $c = confine_content_root( $DOCROOT, $sv{content_root} );
        return $c if defined $c;
    }
    return $sv{alias_host} ? undef : $DOCROOT;
}

# n804 (SM1424): one page of the set. A `description:` key is read by nothing; the
# check says so, so the entry carries whether the page wrote one.
sub _page_set_entry {
    my ($p) = @_;
    my %e = ( url => $p->{url}, title => $p->{meta_title}, description => $p->{meta_desc} );
    $e{ignored_description} = 1 if !ref $p->{description} && length( $p->{description} // '' );
    return \%e;
}

# n785 (SM1357): THIS HOST'S PUBLIC PAGE SET, as `lazysite check` reads it for its
# title and description checks - the pages the host's sitemap and llms.txt list,
# from the same scan and the same set, so the check counts per domain what each
# domain publishes (another domain's root, ruling 171's folders and everything
# else the set leaves out are not counted). { root, pages => [ { url, title,
# description } ] }, title and description as the registries publish them
# (meta_title else title, meta_desc else subtitle); root is undef, with no pages,
# for an alias that shares the docroot. n814 (SM1437): `unread` (path => error)
# is there only when the walk could not read something, so the check says its set
# is not whole.
sub _public_page_set_listing {
    my $root = _registry_scan_root();
    my %unread;
    my @pages = defined $root ? _public_page_set( scan_pages( $root, \%unread ) ) : ();
    my $set   = { root => $root, pages => [ map { _page_set_entry($_) } @pages ] };
    $set->{unread} = \%unread if %unread;
    return $set;
}

# Ruling 171: A FOLDER THAT LOOKS LIKE ANOTHER SITE'S CONTENT is left out of the
# walk the registries are built from, declared or not. A declared content root
# is already left out (§7). One that is NOT declared - a client's tree copied
# under sites/ before its domain was set up, or a site unpacked into a folder of
# the docroot with its own lazysite.conf - is served on the bare host like any
# other folder, but it is not this site's content: the bare host's sitemap and
# llms.txt listed it as its own pages. Looks like another site's content:
#
#   <docroot>/sites/<name>             the multi-site layout's place for a site
#   any folder holding lazysite.conf   (or lazysite/lazysite.conf) of its own
#
# lazysite check names each one as served on the bare host, with the remedy
# (report_foreign_site_folders: declare it as a domain's content_root, or move it
# out of the docroot) - the same two shapes, in the check's own walk.
sub _foreign_site_folder {
    my ($path) = @_;
    return 1 if $path =~ m{\A\Q$DOCROOT\E/sites/[^/]+\z};
    return 1 if -f "$path/lazysite.conf" || -f _lazysite_dir_for($path) . "/lazysite.conf";
    return 0;
}

# Ruling 176 (n776, within 171): THE SCAN'S WALK ASKS THE SAME QUESTION. Site
# search and every scan: listing walk the scan root and its private twin
# (_scan_collect_files); a folder of either is asked by its public spelling, so
# a protected page moved into the private store under a forgotten site folder
# is left out as its public copy would be. A folder outside both (the engine's
# docs) is never another site's.
sub _scan_foreign_dir {
    my ( $dir, $scan_root, $priv_root ) = @_;
    my $pub = $dir;
    if ( defined $priv_root && length $priv_root && index( $dir, "$priv_root/" ) == 0 ) {
        $pub = $scan_root . substr( $dir, length $priv_root );
    }
    return 0 unless index( $pub, "$scan_root/" ) == 0;
    # The site's own lazysite/ tree holds the site's own lazysite.conf, and the
    # engine's docs a scan reads may sit under it: it is this site's, never
    # another's (the walks leave it out before they ask, as scan_pages does).
    return 0 if defined $LAZYSITE_DIR && ( $pub eq $LAZYSITE_DIR || index( $pub, "$LAZYSITE_DIR/" ) == 0 );
    return _foreign_site_folder($pub);
}

# A file a one-level pattern matched: is any folder between the scan root and
# the file another site's? (The walk never descends into one; a pattern can
# name one outright.)
sub _scan_under_foreign_dir {
    my ( $file, $scan_root, $priv_root ) = @_;
    my $dir = dirname($file);
    my ($top) = grep { defined && length && ( $dir eq $_ || index( $dir, "$_/" ) == 0 ) } $scan_root, $priv_root;
    return 0 unless defined $top;
    while ( length $dir > length $top ) {
        return 1 if _scan_foreign_dir( $dir, $scan_root, $priv_root );
        $dir = dirname($dir);
    }
    return 0;
}

# Ruling 165: the summary is ON by default; `llms_txt: off` in lazysite.conf
# turns it off - it is then neither generated nor served (a 404, as on a site
# that never had one). A hand-written llms.txt in the content is the site's own
# and is served as content either way.
sub _llms_txt_on {
    my $v = peek_conf_key('llms_txt') // '';
    return $v =~ /\A["']?(?:off|false|no|0|disabled)["']?\z/i ? 0 : 1;
}

# The organisation entry for the summary: { name, type, url, address,
# telephone, email, hours => [lines] }, or undef when the site states no
# details beyond its name (_organisation_entry, the same rule as the home
# page's JSON-LD).
sub _registry_organisation {
    my ($sv) = @_;
    my @detail = qw(site_type site_address site_phone site_email site_hours);
    return undef unless grep { length( $sv->{$_} // '' ) } @detail;
    my %site = map { ( $_ => ( $sv->{$_} // '' ) ) } ( 'site_name', @detail );
    $site{site_url} = $sv->{site_url} // '';
    delete $site{site_hours} unless _unit_enabled('extensions/data.pl');
    my $lines;
    my ($org) = eval {
        _lazy_lib('Lazysite::Data::StructuredData');
        Lazysite::Data::StructuredData::organisation( $DOCROOT, \%site, lines => \$lines );
    };
    return undef unless $org;
    return {
        name      => $org->{name},
        type      => $org->{'@type'},
        url       => ( $org->{url}       // '' ),
        address   => ( $org->{address}   // '' ),
        telephone => ( $org->{telephone} // '' ),
        email     => ( $org->{email}     // '' ),
        hours     => ( $lines || [] ),
    };
}

# SM1284: does this request's scan read the engine's docs? An engine page's
# render does; a site page's only on a site that put them in (ruling 35).
sub _scan_sees_engine_docs {
    return 1 if $ENGINE_DOC_RENDER;
    return _engine_docs_public();
}

# SM1284 (ruling 35): `engine_docs_public: true` in lazysite.conf puts the
# engine's /docs pages into the site's search, sitemap, feeds and llms.txt -
# for a site that IS the product's documentation (lazysite.io). Off by default.
sub _engine_docs_public {
    return ( peek_conf_key('engine_docs_public') // '' ) =~ /\A(?:true|yes|on|1)\z/i ? 1 : 0;
}

sub _scan_collect_files {
    my ( $pattern, $scan_root, $excl, $limit ) = @_;

    # SM460: SEARCH THE PRIVATE STORE TOO.
    #
    # Gating MOVES content out of the docroot (SM286), so a scan rooted at the
    # docroot found nothing inside a protected section - and rendered a page
    # that listed nothing, successfully. Not an error, not a warning: an author
    # sees an empty list and reasonably concludes their content is missing or
    # their pattern is wrong. It removed scan-driven indexes - how blog
    # listings, feature indexes and library pages are built - from protected
    # areas entirely.
    #
    # SAFE BECAUSE THE FILTER ALREADY EXPECTED THIS. _scan_should_skip keys
    # each entry through _content_rel precisely "so a page resolved from the
    # private store is keyed and checked rather than skipping the branch and
    # being listed" - the ACL gate was written for private entries and never
    # received any. Finding them was the missing half, not the gating.
    #
    # PRIVATE WINS on a collision, the same rule Private::resolve documents: if
    # a stray public copy survives a move, listing the governed copy keeps the
    # ACL applying while stray_public() can still report the leak.
    my @roots     = ($scan_root);
    my $priv_root = _private_twin($scan_root);
    push @roots, $priv_root
        if defined $priv_root && $priv_root ne $scan_root && -d $priv_root;

    # SM1284 (ruling 35): AND THE ENGINE'S /docs PAGES, WHEN THEY ARE ASKED FOR.
    #
    # The manual lists itself - the features index is a scan of
    # /docs/features/ - so an engine page's own scans see the engine tree, or
    # the index would be empty on every site without a docs copy. A site page's
    # scan (the search index among them) sees it only when the site has said
    # `engine_docs_public: true`: the manual is the engine's, and a site's own
    # search and listings are about the site. FIRST, so a site's copy at the
    # same path replaces it below - the site page wins, as it does when served.
    my @fs_patterns;
    if ( _scan_sees_engine_docs() ) {
        if ( $pattern =~ m{\A/docs/(.+)\z}s ) {
            push @fs_patterns, "$ENGINE_DOCS_DIR/$1";
        }
        elsif ( $pattern =~ m{\A/\*\*/(.+)\z}s ) {
            push @fs_patterns, "$ENGINE_DOCS_DIR/**/$1";
        }
    }
    push @fs_patterns, map { $_ . $pattern } @roots;

    my @files;
    for my $fs_pattern (@fs_patterns) {
        if ( $fs_pattern =~ m{\*\*} ) {
            # Recursive glob: expand ** by walking directories
            # Split pattern into base dir and file glob parts
            my ( $base, $rest ) = $fs_pattern =~ m{^(.*?)/\*\*/(.*)$};
            if ( defined $base && defined $rest && -d $base ) {
                my $file_re = $rest;
                $file_re =~ s/\./\\./g;
                $file_re =~ s/\*/.*/g;
                $file_re = qr/\A${file_re}\z/;
                my @queue = ($base);
                while ( my $dir = shift @queue ) {
                    opendir( my $dh, $dir ) or next;
                    # SM311: the directory itself. A file ADDED or DELETED leaves no
                    # file to stat, but moves its directory's mtime - so the walked
                    # directories are what makes add and delete visible, and the
                    # matched files below are what makes an EDIT visible. Both are
                    # needed; neither is sufficient.
                    _tt_dep($dir);
                    for my $entry ( readdir($dh) ) {
                        next if $entry =~ /^\./;
                        my $path = "$dir/$entry";
                        if ( -d $path ) {
                            # SM1284: never into the lazysite/ management tree,
                            # as scan_pages already refuses. A site whose engine
                            # tree is inside the docroot listed its system pages
                            # in a `scan:/**/*.md` (the search index) at
                            # /lazysite/templates/... URLs, and would have listed
                            # the whole manual there. The engine's docs come in
                            # by their own pattern, at their own URLs.
                            next if $path eq $LAZYSITE_DIR;
                            # SM151: don't follow symlinked dirs - a symlink could
                            # cycle (hanging the walk) or escape the content root
                            # (leaking a sibling domain's pages into search).
                            next if -l $path;
                            # §7: never descend into ANOTHER domain's content root,
                            # so a bare-docroot search excludes client subtrees.
                            next if $excl->{$path} && $path ne $base;
                            # Ruling 176 (within 171): nor into a folder that looks
                            # like another site's content without being declared
                            # as one, as the sitemap's walk leaves it out - so a
                            # forgotten site folder is not found through search on
                            # the bare host either.
                            next if $path ne $base && _scan_foreign_dir( $path, $scan_root, $priv_root );
                            push @queue, $path;
                        }
                        elsif ( $entry =~ $file_re ) {
                            push @files, $path;
                        }
                    }
                    closedir($dh);
                }
            }
        }
        else {
            # Ruling 176: a one-level pattern is a folder named outright; its
            # files are left out when that folder, or one between it and the
            # scan root, looks like another site's content (the walk's rule).
            push @files, grep { !_scan_under_foreign_dir( $_, $scan_root, $priv_root ) } glob($fs_pattern);
            # SM311: same reasoning, one level - the directory the glob names.
            _tt_dep( dirname($fs_pattern) );
        }
    }

    # SM460: private wins when a path exists in both trees. Keyed on the
    # docroot-relative name so the two spellings of one page collapse to one
    # entry rather than listing it twice.
    {
        my %by_key;
        for my $f (@files) {
            my $key = _content_rel($f);
            $key = $f unless defined $key;
            # A later root (the private one) replaces an earlier public twin.
            $by_key{$key} = $f;
        }
        # SORTED, because the 200-file cap below takes a prefix and hash
        # order is randomised per process - an uncapped list would come out
        # right and a capped one would hold a different 200 pages each render.
        @files = sort values %by_key;
    }

    # P9: the cap is the caller's - resolve_scan applies the site's scan_limit
    # and counts what lies past it. Without one (no caller passes none today)
    # the list is whole.
    @files = @files[ 0 .. $limit - 1 ] if defined $limit && @files > $limit;

    return @files;
}

# P9 (WORK-PLAN-0154): HOW MANY PAGES A SCAN READS, the site's to set.
#
# A scan reads every page it lists, so it is capped; the cap was a literal 200
# that nothing documented, and a 1,745-post site rendered 200 with no sign of
# the rest. `scan_limit:` in lazysite.conf sets it; anything but a positive
# whole number is the default, said in the log.
sub _scan_limit {
    my $v = peek_conf_key('scan_limit');
    return 200 unless defined $v && length $v;
    return 0 + $v if $v =~ /\A[1-9]\d{0,6}\z/;
    log_event( 'WARN', $ENV{REDIRECT_URL} // '-',
        'scan_limit is not a positive whole number - using 200', value => $v );
    return 200;
}

# A page's date: the front matter's, else the file's mtime as YYYY-MM-DD
# (PR-5). resolve_scan and scan_pages carried identical copies of this.
sub _page_date {
    my ( $meta, $path ) = @_;
    my $date = $meta->{date} || '';
    unless ($date) {
        my @st = stat($path);
        if (@st) {
            my @t = localtime( $st[9] );
            $date = sprintf( "%04d-%02d-%02d", $t[5] + 1900, $t[4] + 1, $t[3] );
        }
    }
    return $date;
}

# A page's URL: the path with the scanned root, the .md suffix and a trailing
# /index stripped, in that order (PR-5). The other half of the same pair -
# resolve_scan feeds it a path already mapped back to its PUBLIC spelling
# (SM460/SM463), scan_pages feeds it the path it walked; the strip is the same.
sub _page_url {
    my ( $path, $root ) = @_;
    ( my $url = $path ) =~ s{^\Q$root\E}{};
    $url                =~ s/\.md$//;
    $url                =~ s{/index$}{/};
    return $url;
}

# SM976 Q15h ("Refuse + walker skips"): the log line for a page a walk leaves
# out because its front matter - or, Q15i, the body resolve_scan's excerpt
# reads - cannot be read. Docroot-relative, as a page is named everywhere else
# in the log.
sub _scan_page_unreadable {
    my ( $path, $why, $part, $verb ) = @_;
    $part //= 'front matter';
    $verb //= 'read';              # P25: 'opened', for a page the walk could not open
    ( my $rel = $path ) =~ s{^\Q$DOCROOT\E/*}{};
    $why =~ s/\s+at \S+ line \d+.*//s;
    $why =~ s/\Q$path\E/$rel/g;    # P25: read_file's message names the server path
    $why =~ s/\s+\z//;
    log_event( 'WARN', 'scan', "a page whose $part cannot be $verb is left out", page => $rel, error => $why );
    return;
}

sub resolve_scan {
    my ($pattern) = @_;

    my ( $filters, $sort_field, $sort_dir, $page ) = _scan_parse_modifiers( \$pattern );
    my @filters = @$filters;

    # Pattern must be root-relative starting with /
    return [] unless $pattern =~ m{^/};

    # SM151: box the scan to the requesting domain's content root (the domain's
    # '/'), so search on one domain never returns another's pages. Falls back to
    # the docroot for the primary host / when no content_root is in effect.
    my $scan_root = $REQUEST_CROOT // $DOCROOT;
    my $excl      = _declared_content_roots();    # §7: other domains' roots

    # Build filesystem glob pattern
    my $fs_pattern = $scan_root . $pattern;

    # Limit to .md files only
    return [] unless $fs_pattern =~ /\.md$/;

    # P9: every file the pattern matches, then the site's cap - a prefix in
    # file order, as before, so the same pages are listed on every render.
    my @all   = _scan_collect_files( $pattern, $scan_root, $excl );
    my $limit = _scan_limit();
    my @files = @all > $limit ? @all[ 0 .. $limit - 1 ] : @all;
    my $total = 0;    # P9: pages matched that this reader may see

    # Read site search default once if any filter references searchable
    my $search_default;

    # PO-1: two loop invariants, hoisted.
    #
    # EQUIVALENCE. Both were recomputed once per scanned file and neither can
    # change while the loop runs: _private_twin is a pure function of
    # $scan_root, the private root and $DOCROOT, and the loop body writes none
    # of them; _front_matter_reserved returns a fresh hash built from a literal
    # qw list, and the loop only ever READS $reserved{$k}. So each call returned
    # what the one before it returned, 200 times at the cap.
    my $priv_scan = _private_twin($scan_root);
    my %reserved  = %{ _front_matter_reserved() };

    my @pages;
    # @files is already sorted (the private-wins dedupe above sorts it) and the
    # only thing between here and there is the 200-file cap, which takes a
    # prefix - so a second sort would return the same list in the same order.
    for my $path (@files) {
        # Realpath check - confined to the scan root (the domain's content root,
        # or the docroot), so a symlinked file cannot escape the domain (SM151).
        my $real = realpath($path);
        # SM460: _path_under_content, not _path_under - it accepts the scan
        # root OR its private twin, each boundary-safe, which is the same
        # two-strict-checks shape SM458 used rather than one loosened test.
        # SM1284: or the engine's docs, which only the engine-docs pattern above
        # can have put in the list.
        next unless _path_under_content( $real, $scan_root ) || _engine_page_real($real);
        next unless -f $real;

        # SM311: recorded BEFORE the visibility filter, deliberately. A page that
        # becomes visible - a draft published, an ACL lifted - is an edit to a
        # file that already existed, so no directory mtime moves and the page
        # would never appear in a cached listing. Recording only what was SHOWN
        # would make the listing stale in exactly the case the author is watching
        # for. The path is already public knowledge to the render; this records
        # what was READ, not what was displayed.
        _tt_dep($real);

        # SM268 H13: never list what this requester may not read.
        next if _scan_hidden($real);
        $total++;

        # Read front matter. SM976 Q15h ("Refuse + walker skips"): a page whose
        # reading dies (bytes that are not UTF-8, put there by git or SSH) is
        # left out and logged - it renders nothing itself - so one such page
        # cannot fail every page whose scan reaches it.
        #
        # P25 (WORK-PLAN-0154): and a page it cannot OPEN (permissions), whose
        # read_file died outside this guard.
        my $raw = eval { read_file($path) };
        unless ( defined $raw ) {
            _scan_page_unreadable( $path, $@ || 'unknown', 'file', 'opened' );
            next;
        }
        my ($meta) = eval { parse_yaml_front_matter($raw) };
        if ( my $why = $@ ) {
            _scan_page_unreadable( $path, $why );
            next;
        }

        # Derive URL relative to the scan root, so a boxed domain's results
        # carry that domain's own '/'-relative paths (SM151).
        #
        # SM460/SM463: map a private-store path back to its PUBLIC spelling
        # first. This strip is a bare prefix, and the private root begins with
        # the scan root - so a page found in the private tree came out as
        # "-lazysite-private/intranet/a", which is both a broken link and a
        # disclosure of the store's naming. Widening the search without fixing
        # the derivation would have introduced that fault rather than found it;
        # SM286's own header warns that resolution and key derivation must
        # change together, and this is the derivation half.
        #
        # Boundary-safe (eq or "$root/"), so a sibling directory whose name
        # merely starts with the private root's is untouched.
        my $url_src = $path;
        if ( defined $priv_scan
            && length $priv_scan
            && ( $url_src eq $priv_scan
                || index( $url_src, "$priv_scan/" ) == 0 ) )
        {
            $url_src = $scan_root . substr( $url_src, length($priv_scan) );
        }
        # SM1284: an engine page is listed at the path it is served at.
        $url_src = "$scan_root/docs/$1" if $url_src =~ m{\A\Q$ENGINE_DOCS_DIR\E/(.+)\z}s;
        my $url = _page_url( $url_src, $scan_root );

        # Date from front matter or mtime
        my $date = _page_date( $meta, $path );

        # Parse tags from front matter (YAML list, comma-separated, or single value)
        my @tags = @{ _page_tags($meta) };

        # Extract raw body for search excerpt. SM976 Q15i (ruled 2026-10-09,
        # "Same rule"): the excerpt reads the BODY, which the front-matter guard
        # above never parsed - a page whose front matter is UTF-8 and whose body
        # is not died here, and every page whose scan reached it answered 500.
        # Left out and logged, as for its front matter.
        my $excerpt = '';
        eval {
            if ( $raw =~ /^---\n.*?\n---\n(.+)/s ) {
                $excerpt = $1;
                # Drop <style>/<script> blocks and HTML comments so their CSS/JS/markup
                # never leaks into the public search excerpt (a page often opens with an
                # inline <style> block).
                $excerpt =~ s{<style\b[^>]*>.*?</style>}{ }gis;
                $excerpt =~ s{<script\b[^>]*>.*?</script>}{ }gis;
                $excerpt =~ s{<!--.*?-->}{ }gs;
                $excerpt =~ s/^\s+|\s+$//g;
                $excerpt = substr( $excerpt, 0, 500 ) if length($excerpt) > 500;
            }
            1;
        } or do {
            _scan_page_unreadable( $path, $@, 'body' );
            next;
        };

        # Determine searchable status
        my $search_val = $meta->{search} // '';
        my $searchable;
        if ( $search_val =~ /^true$/i ) {
            $searchable = 1;
        }
        elsif ( $search_val =~ /^false$/i ) {
            $searchable = 0;
        }
        else {
            $search_default //= peek_search_default();
            $searchable = $search_default;
        }

        # Pass through custom (non-computed, non-control) front-matter keys so a
        # scanned/registry card is self-describing - [% p.accent %], [% p.kind %],
        # [% p.demo %], [% p.order %] - instead of smuggling data through tags.
        # Computed fields below take precedence; control/internal keys are excluded;
        # surrounding quotes and TT markers are stripped from scalar values.
        my %custom = %{ _front_matter_custom( $meta, \%reserved ) };

        push @pages, {
            %custom,
            url      => $url,
            title    => $meta->{title}    || '',
            subtitle => $meta->{subtitle} || '',

            # SM300: the description a registry should publish - the explicit
            # meta_desc when the author set one, the subtitle otherwise. Resolved
            # here so every registry template gets the same answer rather than
            # each re-deriving it.
            meta_desc  => ( $meta->{meta_desc}  // $meta->{subtitle} // '' ),
            meta_title => ( $meta->{meta_title} // $meta->{title}    // '' ),
            date       => $date,
            tags       => \@tags,
            excerpt    => $excerpt,
            searchable => $searchable,
            # Docroot-relative, never the absolute server path: this object is
            # published in the public /search-index JSON and exposed to templates
            # as [% p.path %]. Leaking /home/<user>/web/... was an info disclosure.
            path => ( $path =~ s{^\Q$DOCROOT\E}{}r ),
        };
    }

    # Apply filters
    for my $filter (@filters) {
        my $field = $filter->{field};
        my $val   = $filter->{value};

        @pages = grep {
            my $page = $_;
            my $pval = $page->{$field};

            if ( !defined $pval ) {
                0;    # field not present - exclude
            }
            elsif ( $val =~ /^>(.+)$/ ) {
                # Greater than
                ( $pval cmp $1 ) > 0;
            }
            elsif ( $val =~ /^<(.+)$/ ) {
                # Less than
                ( $pval cmp $1 ) < 0;
            }
            elsif ( ref $pval eq 'ARRAY' ) {
                # Array contains (for tags)
                grep { lc($_) eq lc($val) } @$pval;
            }
            elsif ( $val =~ /^(true|1)$/i ) {
                # Boolean true
                $pval ? 1 : 0;
            }
            elsif ( $val =~ /^(false|0)$/i ) {
                # Boolean false
                $pval ? 0 : 1;
            }
            else {
                # Exact match (case-insensitive)
                lc($pval) eq lc($val);
            }
        } @pages;
    }

    # Sort pages. date/title/filename are built-ins; any other field sorts on the
    # custom key (numeric-aware, so sort=order gives 2 before 10).
    my @sorted = sort {
        my ( $va, $vb );
        if ( $sort_field eq 'date' ) { ( $va, $vb ) = ( $a->{date}, $b->{date} ) }
        elsif ( $sort_field eq 'title' ) { ( $va, $vb ) = ( lc( $a->{title} ), lc( $b->{title} ) ) }
        elsif ( $sort_field eq 'filename' ) { ( $va, $vb ) = ( $a->{path}, $b->{path} ) }
        else {
            $va = ( defined $a->{$sort_field} && !ref $a->{$sort_field} ) ? $a->{$sort_field} : '';
            $vb = ( defined $b->{$sort_field} && !ref $b->{$sort_field} ) ? $b->{$sort_field} : '';
        }
        my $cmp = ( $va =~ /^-?\d+(?:\.\d+)?$/ && $vb =~ /^-?\d+(?:\.\d+)?$/ )
            ? ( $va <=> $vb ) : ( lc($va) cmp lc($vb) );
        $sort_dir eq 'desc' ? -$cmp : $cmp;
    } @pages;

    # P9: A CAPPED SCAN SAYS SO, and counts what it did not read. Past the cap
    # each file is held to the same two questions as a listed one - inside this
    # domain's content, and readable by this requester - so the total counts no
    # page the reader may not see and says nothing about one. `filter=` cannot
    # be asked of a page that was not read, so the total is taken before it.
    if ( @all > $limit ) {
        for my $path ( @all[ $limit .. $#all ] ) {
            my $real = realpath($path);
            next unless defined $real && ( _path_under_content( $real, $scan_root ) || _engine_page_real($real) ) && -f $real;
            next if _scan_hidden($real);
            $total++;
        }
        log_event( 'WARN', $ENV{REDIRECT_URL} // '-',
            "scan: is capped - reading the first $limit of $total pages in file order; "
                . 'raise scan_limit in lazysite.conf, or render <var>_total so the page can say so',
            pattern => $pattern );
    }

    # P9 revise: the directive's own page of the list - after filter= and the
    # sort, so offset=20 limit=10 is the third ten of what the reader would see.
    # limit= is capped by scan_limit, the site's ceiling; offset= reaches no
    # further than the pages the ceiling let the scan read, so paging a long
    # list means raising scan_limit to cover it. `_total` is unchanged.
    if ( defined $page->{offset} ) {
        splice( @sorted, 0, $page->{offset} > @sorted ? scalar @sorted : $page->{offset} );
    }
    if ( defined $page->{limit} ) {
        my $want = $page->{limit} < $limit ? $page->{limit} : $limit;
        $#sorted = $want - 1 if @sorted > $want;
    }

    return wantarray ? ( \@sorted, $total ) : \@sorted;
}

# A registry output is stale when it is missing, or older than $REGISTRY_TTL
# (PR-12). update_registries wrote the same test out twice - once as "does
# anything here need regenerating", once as the per-template skip, spelled as
# its negation. Same stat, same comparison, same order.
#
# The two further copies on the serve path (_serve_registry and the re-check
# under the lock in _regenerate_registries_once) are LEFT INLINE deliberately:
# t/unit/extensions/16 and t/unit/processor/46 lift those two subs out of this file
# by regex and run them standalone against stubs, so a call to a helper defined
# elsewhere in the file would be an undefined subroutine in their harnesses.
sub _registry_stale {
    my ($path) = @_;
    return 1 if !-f $path;
    return ( time() - ( stat($path) )[9] ) >= $REGISTRY_TTL ? 1 : 0;
}

{
    # P-3: cache "do we have any registry templates?" at process level.
    # Most sites don't use registries; this avoids an opendir on every
    # cache-miss render.
    my $_has_registries;    # undef = not yet probed

    sub update_registries {
        return if _draft_requested();    # SM1030: a draft render writes nothing
        # SM110/SM151: registries (sitemap, feeds, llms.txt) are generated per
        # content root. A host with its OWN content_root gets first-class
        # registries - scanned from and written INTO its subtree, with its own
        # per-host site_url - so each domain has a correct sitemap/feeds of just
        # its own pages. A host that is an alias WITHOUT a content root shares
        # the docroot (SM110 chrome-only alias); it is still skipped, or its
        # overlaid vars (site_name etc.) would bake into the docroot-shared
        # registries the primary serves. The primary host - with or without a
        # base content_root - generates as before.
        my $root = _registry_scan_root();
        return unless defined $root;

        if ( !defined $_has_registries ) {
            if ( -d $REGISTRY_DIR ) {
                opendir( my $dh, $REGISTRY_DIR );
                my @t = $dh ? grep { /\.tt$/ } readdir($dh) : ();
                closedir($dh) if $dh;
                $_has_registries = @t ? 1 : 0;
            }
            else {
                $_has_registries = 0;
            }
        }
        return unless $_has_registries;

        opendir( my $dh, $REGISTRY_DIR ) or return;
        my @templates = grep { /\.tt$/ } readdir($dh);
        closedir($dh);
        @templates = grep { $_ ne 'llms.txt.tt' } @templates unless _llms_txt_on(); # ruling 165

        return unless @templates;

        # Check if any registry needs updating. $stale_path is the first output
        # that does; $missing is set when one does not exist at all.
        my ( $stale_path, $missing );
        for my $tmpl (@templates) {
            ( my $output_name = $tmpl ) =~ s/\.tt$//;
            my $output_path = _registry_cache_path( $root, $output_name );
            if ( !-f $output_path ) {
                $stale_path //= $output_path;
                $missing = 1;
                last;
            }
            $stale_path //= $output_path if _registry_stale($output_path);
        }
        return unless defined $stale_path;

        # SM1152: STALE IS NOT MISSING. Every output exists, so there is
        # something to serve and nobody needs to wait for the scan: SM1069
        # measured it at 1.5-3 s on an 1,800-rule fixture, paid by the one
        # request that arrived after the TTL (SM666 names the class: work that
        # ran on the back of a visitor's request). It is handed to a detached
        # child. A registry that does not exist yet is still built here, in the
        # request that needs it - there is nothing to be stale WITH.
        return if !$missing && !$REGISTRY_REBUILDING && _schedule_registry_rebuild($stale_path);

        # Scan the source pages of THIS content root only (SM151), so a domain's
        # registries list just its own subtree with content-root-relative URLs.
        my @pages     = scan_pages($root);
        my %site_vars = resolve_site_vars();

        # P14 (ruled 2026-10-12, "Render from the canonical"): a registry lists
        # the pages of a content root, and an alias shares its canonical domain's
        # root - so the addresses in it (sitemap, llms.txt, the feeds) are the
        # canonical domain's, whichever host's request regenerated it. Before,
        # the file in the shared root named whichever host came last.
        $site_vars{site_url} = $site_vars{canonical_url}
            if length( $site_vars{canonical_url} // '' );

        # Compile-cache dirs + .ttc files are minted during new()/process():
        # group-writable creation whichever identity renders first (_cache_umask).
        # SM1035: make_path and Template->new (Template::Provider's mkdir) DIE
        # when the compile dir cannot be made, so the `or do { umask }` never
        # ran and the widened umask outlived the call. Both under eval, the
        # umask restored, then the same failure re-thrown.
        my $old_umask = _cache_umask();
        my $tt        = eval {
            make_path($TT_COMPILE_DIR) unless -d $TT_COMPILE_DIR;
            Template->new(
                ABSOLUTE    => 1,
                ENCODING    => 'utf8',
                EVAL_PERL   => 0,                                     # L-2
                FILTERS     => { url_safe => \&_url_safe_filter },    # SM970
                COMPILE_DIR => $TT_COMPILE_DIR,                       # P-4
                COMPILE_EXT => '.ttc',                                # P-4
            );
        };
        my $tt_died = $@;
        do { umask $old_umask; die $tt_died } if $tt_died;
        do { umask $old_umask; return } unless $tt;

        for my $tmpl (@templates) {
            ( my $output_name = $tmpl ) =~ s/\.tt$//;
            my $output_path = _registry_cache_path( $root, $output_name );
            my $tmpl_path   = "$REGISTRY_DIR/$tmpl";

            # Check this specific registry needs updating
            next unless _registry_stale($output_path);

            # Filter pages registered for this registry
            my $registry_name = $output_name;
            # Ruling 174: the sitemap and the summary from the one page set.
            my @registered =
                _public_page_set_registry($registry_name)
                ? _public_page_set(@pages)
                : grep { _registry_lists( $registry_name, $_ ) } @pages;

            # SM179 P3: for a language set, attach each page's hreflang alternates
            # so the sitemap can advertise its siblings (xhtml:link). Copy each
            # page hash before augmenting - @pages is shared across registries and
            # only the sitemap consumes `alternates`. A member whose counterpart is
            # absent carries exists=0 and the template omits it.
            if ( $registry_name eq 'sitemap.xml'
                && length( $site_vars{lang_group} // '' ) )
            {
                @registered = map {
                    +{
                        %$_,
                        alternates => [
                            _language_set(
                                ( $site_vars{alias_host} // '' ),
                                $site_vars{lang_group}, $_->{url}
                            )
                        ],
                    }
                } @registered;
            }

            # SM888 A1: A FEED DATE IS FORMATTED FOR THE FEED IT GOES INTO.
            #
            # `date: 2026-08-14` went into RSS's <pubDate> and Atom's <updated>
            # unchanged, and neither accepts it: pubDate wants RFC 822, updated
            # wants RFC 3339. A reader given a date it cannot parse shows the
            # item undated, or dates it "now" and re-sorts the feed on every
            # fetch. Not a crash, which is why every feed this project has
            # published has been wrong and looked fine.
            #
            # DONE HERE RATHER THAN IN THE TEMPLATE, and that is the whole
            # reach of the fix: the registry templates install under bucket
            # `seed`, so an upgrade never replaces them. A site installed a year
            # ago keeps the template it was given. Fixing starter/ alone would
            # fix new sites and leave every feed that has a subscriber wrong.
            #
            # The raw value stays available as `date_raw` for a site that has
            # written its own template around it.
            my $feed_updated = '';
            if ( $registry_name eq 'feed.rss' || $registry_name eq 'feed.atom' ) {
                my $rss = $registry_name eq 'feed.rss';

                # SM942 FO1: NEWEST FIRST, and the sort happens HERE for the same
                # reason the date formatting does - the registry templates install
                # under bucket `seed`, so an upgrade never replaces them and a
                # template-side sort would fix new sites while leaving every feed
                # that HAS a subscriber in filename order.
                #
                # SORTED BEFORE THE MAP, which is the whole trick. The map replaces
                # `date` with the RFC 822 / RFC 3339 string, and sorting THAT orders
                # by weekday name - wrong in a way that still looks sorted, which
                # would be worse than the fault being fixed because it would look
                # deliberate. An ISO date sorts chronologically as text, so the raw
                # value is the right key.
                #
                # AND ONLY AN ISO-LOOKING VALUE IS A SORT KEY. A `date:` the engine
                # cannot parse is passed through to the feed verbatim rather than
                # invented (t/integration/102), so prose like "last Tuesday" reaches
                # here - and as a bare string it sorts ABOVE every real date, which
                # would put the one page nobody dated properly at the top of every
                # reader. Caught by 102 when this sort was first written without the
                # guard. Unparseable sorts last, with no date of its own to argue
                # about.
                my $key = sub {
                    my $d = $_[0]->{date};
                    return '' unless defined $d;
                    return $d =~ /\A\d{4}-\d{2}-\d{2}/ ? $d : '';
                };
                @registered =
                    sort { $key->($b) cmp $key->($a) } @registered;

                @registered = map {
                    my ( $r822, $r3339 ) = _feed_dates( $_->{date} );
                    my $fmt = $rss ? $r822 : $r3339;
                    +{ %$_,
                        date_raw => $_->{date},
                        ( defined $fmt ? ( date => $fmt ) : () ),
                    };
                } @registered;

                # SM942 FO3 (ruled 2026-10-02): cap the item count. A site with a
                # few hundred dated pages otherwise emits all of them on every
                # poll. 50 is the conventional ceiling and costs no current site
                # anything: the pages the cap drops stay in the sitemap, the search
                # index and every link to them - only the FEED is bounded.
                # `feed_items: 0` asks for all of them.
                my $cap = _conf_value('feed_items');
                $cap = 50 unless defined $cap && $cap =~ /\A\d+\z/;
                splice @registered, $cap if $cap && @registered > $cap;

                # The channel's own timestamp, for a template that carries
                # <lastBuildDate> or <updated>. The feed is sorted, so the newest
                # item IS the first one. Kept in a local rather than written into
                # %site_vars, which is shared with sitemap.xml and llms.txt and has
                # no business gaining a feed-only key.
                $feed_updated = @registered ? ( $registered[0]{date} // '' ) : '';
            }

            my $vars = {
                %site_vars,
                pages => [ map { my %p = %$_; delete @p{qw(_listable _default)}; \%p } @registered ],
                feed_updated => $feed_updated,    # SM942: '' for every non-feed registry
            };
            # SM1357: the summary's organisation entry, from the site's own details.
            if ( $registry_name eq 'llms.txt' ) {
                my $org = _registry_organisation( \%site_vars );
                $vars->{organisation} = $org if $org;
            }

            my $output = '';
            $tt->process( $tmpl_path, $vars, \$output ) or do {
                log_event( "ERROR", "-", "registry template error", tmpl => $tmpl, error => $tt->error() );
                next;
            };

            make_path( dirname($output_path) ) unless -d dirname($output_path);

            # SM1152: written beside and renamed into place. The rebuild now
            # runs while requests are reading the file it replaces (it used to
            # run inside the one request that wanted the new one), and a reader
            # must never be served half a sitemap.
            my $tmp_path = "$output_path.tmp$$";
            open( my $fh, '>:utf8', $tmp_path ) or do {
                log_event( "WARN", "-", "cannot write registry", path => $output_path, error => $! );
                next;
            };
            print $fh $output;
            close $fh;
            rename( $tmp_path, $output_path ) or do {
                log_event( "WARN", "-", "cannot write registry", path => $output_path, error => $! );
                unlink $tmp_path;
            };
        }
        umask $old_umask;
    }
}    # close P-3 _has_registries memo block

# SM888 A1: one front-matter date, the two spellings the feed specifications
# require. Returns ( RFC 822, RFC 3339 ), or the empty list when the value is
# not a date this can read.
#
# THE MONTH AND DAY NAMES ARE OURS, not strftime's. %a and %b are LOCALE
# DEPENDENT, and a host with a non-English locale would publish "jeu., 14 août"
# into a feed whose specification names the English abbreviations - a fault
# that appears on some hosts and not others, which is the worst kind to chase.
#
# AN UNPARSEABLE DATE IS PASSED THROUGH, not replaced. Substituting "now" would
# make the feed re-sort itself on every fetch and tell the sysop nothing; the
# page's front matter is where it is wrong and where it should be fixed.
# THE TABLES LIVE INSIDE THE SUB, and that is not a style choice. Written as
# file-scope `my @DOW = (...)` in an enclosing block, they are EMPTY here: this
# is a CGI whose execution reaches the request handler thousands of lines
# above, so a runtime assignment down here never runs before the sub is called.
# The first cut published "<pubDate>, 14  2026 00:00:00 +0000</pubDate>" - a
# date with no day and no month, which is worse than the raw value it replaced.
# Twelve strings on a path that runs when a feed regenerates cost nothing.
{

    sub _feed_dates {
        my ($raw) = @_;
        my @DOW   = qw(Sun Mon Tue Wed Thu Fri Sat);
        my @MON   = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
        return () unless defined $raw && length $raw;
        my ( $y, $m, $d, $H, $M, $S ) = $raw =~ m{
            \A \s* (\d{4}) - (\d{2}) - (\d{2})
            (?: [T ] (\d{2}) : (\d{2}) (?: : (\d{2}) )? )?
        }x or return ();
        $H //= 0;
        $M //= 0;
        $S //= 0;
        return () if $m < 1 || $m > 12 || $d < 1 || $d > 31;

        require Time::Local;
        my $epoch = eval {
            Time::Local->can('timegm_modern')
                ? Time::Local::timegm_modern( $S, $M, $H, $d, $m - 1, $y )
                : Time::Local::timegm( $S, $M, $H, $d, $m - 1, $y - 1900 );
        };
        return () unless defined $epoch;

        my @g = gmtime($epoch);
        return (
            sprintf(
                '%s, %02d %s %04d %02d:%02d:%02d +0000',
                $DOW[ $g[6] ], $g[3], $MON[ $g[4] ], $g[5] + 1900,
                $g[2],         $g[1], $g[0]
            ),
            sprintf(
                '%04d-%02d-%02dT%02d:%02d:%02dZ',
                $g[5] + 1900, $g[4] + 1, $g[3], $g[2], $g[1], $g[0]
            ),
        );
    }
}

# SM293 step 3: where a generated registry is cached, per content root.
#
# Keyed on the content root's path RELATIVE to the docroot, so a multi-domain
# instance keeps each domain's sitemap separate. That separation is the whole of
# SM248: one shared file at the docroot root meant a secondary domain was served
# the primary's sitemap, because the front end resolved the file before the
# engine was asked which domain had been requested.
sub _registry_cache_path {
    my ( $root, $name ) = @_;
    my $key = $root;
    $key = '' unless defined $key;
    $key =~ s{\A\Q$DOCROOT\E/?}{};
    $key =~ s{[^A-Za-z0-9._-]+}{_}g;
    $key = '_root' unless length $key;
    return "$REGISTRY_CACHE_DIR/$key/$name";
}

# The content types the generated registries are served as. Named explicitly:
# guessing from the extension would serve feed.atom as application/octet-stream,
# and get llms.txt right only by accident.
#
# A SUB, not a file-scoped `my` hash. This file runs its main body near the TOP,
# so a `my %REGISTRY_CT = (...)` declared down here is still EMPTY when the
# request is served - every registry name looked unknown and every fetch 404'd.
# SM285 shipped exactly this bug with `my @PROBE_EXT`, where it made a security
# probe pass by testing nothing; the comment there says so, and I wrote this one
# the same way anyway. The sub is initialised at call time and cannot be early.
sub _registry_ct {
    my ($name) = @_;
    my %ct = (
        'sitemap.xml' => 'application/xml; charset=utf-8',
        'llms.txt'    => 'text/plain; charset=utf-8',
        'feed.rss'    => 'application/rss+xml; charset=utf-8',
        'feed.atom'   => 'application/atom+xml; charset=utf-8',
    );
    return $ct{$name} if $ct{$name};

    # A registry is any template an operator drops in - `search-index` is the
    # documented example - so the four shipped names cannot be the whole list.
    # The first version of this served only those four, which quietly removed
    # the ability to define your own: the custom template still rendered, and
    # the result was no longer written anywhere nor reachable.
    return 'application/xml; charset=utf-8'      if $name =~ /\.xml\z/;
    return 'application/json; charset=utf-8'     if $name =~ /\.json\z/;
    return 'application/rss+xml; charset=utf-8'  if $name =~ /\.rss\z/;
    return 'application/atom+xml; charset=utf-8' if $name =~ /\.atom\z/;
    return 'text/plain; charset=utf-8';
}

# Serve a generated registry, if this URI names one. Returns 1 when handled.
#
# Generated on request and cached for $REGISTRY_TTL, which the operator chose
# knowing a registry may be a little stale: a sitemap that lags a few hours is
# not a defect, and it buys a high-demand file that never sits in the document
# root at all.
sub _serve_registry {
    my ($uri) = @_;
    return 0 unless defined $uri;
    ( my $name = $uri ) =~ s{\A.*/}{};
    my $ct = _registry_ct($name);
    return 0 unless length $name && $ct;

    # Only if this site actually ships that registry's template - otherwise a
    # request for /sitemap.xml on a site with no registries should 404 as it
    # always did, not answer with an empty document.
    return 0 unless -f "$REGISTRY_DIR/$name.tt";
    return 0 if $name eq 'llms.txt' && !_llms_txt_on();    # ruling 165: off is a 404

    my %sv   = resolve_site_vars();
    my $root = $DOCROOT;
    if ( defined $sv{content_root} && length $sv{content_root} ) {
        my $c = confine_content_root( $DOCROOT, $sv{content_root} );
        $root = $c if defined $c;
    }

    # A sysop who wrote their OWN sitemap.xml as content keeps it. In
    # production the front end serves that file and the engine never sees the
    # request, but the guarantee must not depend on which route the request
    # took - the dev server and any ACL-store site come through here.
    return 0 if -f "$root/$name";

    my $path = _registry_cache_path( $root, $name );

    # SM1152: a registry that exists is served as it is, stale or not, and a
    # stale one is rebuilt by a detached child; only one that does not exist is
    # built inside this request, because there is nothing else to send. If no
    # child can be started it is rebuilt here, as it always was.
    if ( !-f $path ) {
        _regenerate_registries_once( $path, $uri );
    }
    elsif ( ( time() - ( stat($path) )[9] ) >= $REGISTRY_TTL ) {
        _schedule_registry_rebuild($path)
            or _regenerate_registries_once( $path, $uri );
    }

    open my $fh, '<:utf8', $path or return 0;
    my $body = do { local $/; <$fh> };
    close $fh;

    # SM389: and it is a served request, so it goes in the access log. Registry
    # hits were the one served path that recorded nothing at all - a crawler
    # fetching sitemap.xml every few hours was invisible, which is exactly the
    # traffic a sysop would want to see. Its own channel rather than 'page':
    # a sitemap fetch is not a page view and must not inflate one.
    $ACCESS_REC{s}  = 200;
    $ACCESS_REC{ch} = 'registry';

    # An explicit Status line, like every other served path here. CGI defaults
    # to 200 without one, so omitting it works and then reads as a missing
    # status to anything asserting on the response.
    print "Status: 200 OK\r\n";
    print "Content-Type: $ct\r\n";
    print "$_\r\n" for _security_headers();    # SM381
    print "Cache-Control: public, max-age=$REGISTRY_TTL\r\n\r\n";
    print $body;
    return 1;
}

# SM1152: THE REBUILD OF A STALE REGISTRY HAPPENS AFTER THE REQUEST THAT FOUND
# IT, in a detached child. $path is any one output of the content root: the lock
# sits beside it, one per root, and the child rebuilds every stale output of
# that root (update_registries decides which).
#
# The lock is taken HERE, without waiting, and handed to the child by fork: the
# open file description is shared, so the lock lives until the child exits and
# is held by nobody once it has. Another request arriving meanwhile finds the
# lock taken and starts nothing - "a rebuild is in hand" is true for it as well,
# so it returns 1 without forking. That is how two concurrent stale requests
# start one rebuild.
#
# Double fork, so the request never waits for the child and a long-lived worker
# (FastCGI, the pool) collects no zombie; the grandchild leaves the session,
# points descriptors 0-2 at /dev/null (the web server holds the response open
# until every holder of its pipe has let go) and closes the others but the lock.
# It leaves with _exit: the request's own END blocks and buffered output are the
# parent's to run, not a copy's. Descriptors are dup2'd rather than the Perl
# handles reopened, because under FastCGI STDOUT is a tied handle.
#
# Returns 1 when a rebuild is running or has been started, 0 when none could be
# (no lock file, no fork) - the caller then rebuilds inline, as before.
sub _schedule_registry_rebuild {
    my ($path) = @_;
    my $dir = dirname($path);
    make_path($dir) unless -d $dir;

    open my $lh, '>>', "$dir/.rebuild.lock" or return 0;
    unless ( flock $lh, LOCK_EX() | LOCK_NB() ) {
        close $lh;
        return 1;    # one is already running
    }

    my $pid = fork();
    if ( !defined $pid ) { close $lh; return 0 }
    if ($pid) {
        waitpid( $pid, 0 );
        close $lh;    # ours only; the grandchild's copy keeps the lock
        return 1;
    }

    # The child: start the grandchild and go.
    my $gc = fork();
    POSIX::_exit(0) if !defined $gc || $gc;

    POSIX::setsid();
    if ( open my $null, '+<', '/dev/null' ) {
        POSIX::dup2( fileno($null), $_ ) for 0 .. 2;
    }
    my $keep = fileno($lh);
    POSIX::close($_) for grep { $_ != $keep } 3 .. 63;

    local $REGISTRY_REBUILDING = 1;
    eval { update_registries() };
    log_event( 'WARN', '-', 'background registry rebuild failed', error => $@ ) if $@;
    POSIX::_exit(0);
}

# SM389: one regenerator, not N.
#
# TTL expiry is a stampede. The cached file goes stale at an INSTANT, and every
# request arriving after that instant saw the same old mtime and ran
# update_registries() - a full site scan each - concurrently. The cost scales
# with traffic precisely when traffic is what made it stale, and a site big
# enough for the scan to be slow is a site with enough requests to pile up.
#
# A non-blocking lock picks ONE. The losers do not wait and do not regenerate:
# they serve the stale file, which is the entire premise of a TTL cache and is
# what the sysop accepted by setting a TTL at all. A few more seconds of
# staleness on a sitemap is not a defect; N concurrent site scans is.
#
# The one case a loser cannot serve through is no file at all - a cold start, or
# the first request after a cache clear. There it waits for the winner, because
# there is nothing to be stale WITH.
sub _regenerate_registries_once {
    my ( $path, $uri ) = @_;

    my $regen = sub {
        eval { update_registries() };
        log_event( 'WARN', $uri, 'registry generation failed', error => $@ ) if $@;
    };

    # No lock file, no lock - fall back to the old behaviour rather than
    # declining to serve. A herd is a cost; not answering is a fault.
    open my $lh, '>>', "$path.lock" or return $regen->();

    if ( flock $lh, LOCK_EX() | LOCK_NB() ) {

        # Re-check UNDER the lock. A winner may have finished between the stat
        # that sent us here and the lock we just took, and regenerating again on
        # its fresh output is the same herd in slow motion.
        $regen->()
            if !-f $path || ( time() - ( stat($path) )[9] ) >= $REGISTRY_TTL;
        flock $lh, LOCK_UN();
        close $lh;
        return;
    }

    # Somebody else is regenerating.
    if ( -f $path ) { close $lh; return }    # serve it stale

    # Nothing to serve. Wait for the winner rather than joining it - a blocking
    # lock here is one process waiting, where the alternative is N scans.
    flock $lh, LOCK_EX();
    flock $lh, LOCK_UN();
    close $lh;
    return;
}

sub scan_pages {
    # SM151: scan a specific content root (default: the docroot). URLs are
    # derived relative to $root so a per-domain registry carries the domain's
    # own '/'-relative links.
    # n814 (SM1437): $unread, when given, is a hash ref that collects what the walk
    # could not read - a directory it could not open, a page it left out - as
    # path => error, so `lazysite check` can say its page set is not whole.
    my ( $root, $unread ) = @_;
    $root //= $DOCROOT;
    my $excl     = _declared_content_roots();    # §7: other domains' roots
    my $reserved = _front_matter_reserved();     # P12, hoisted as in resolve_scan
    my $private  = _front_matter_private();

    my @pages;

    # n825 (SM1447): A STORE THAT WILL NOT LOAD HIDES EVERY PAGE, AND THE WALK SAYS SO.
    # _registry_hidden counts a failed acls.json load as governing everything (fail
    # closed), so a run that cannot read the store lists no page at all - and the check
    # printed "0 public page(s), each with a title..." about a site with 12 undescribed
    # ones. Naming the store in $unread makes the check say its set is not whole.
    if ($unread) {
        my $acls = "$LAZYSITE_DIR/auth/acls.json";
        if ( -f $acls && ref( _acl_map('lazysite/auth/acls.json') ) ne 'HASH' ) {
            $unread->{$acls} = open( my $fh, '<:raw', $acls ) ? 'does not decode as a JSON object' : "$!";
        }
    }

    # Find all .md and .url files recursively under the root
    my @queue = ($root);
    # SM1284 (ruling 35): and the engine's /docs pages, on a site that put them
    # in. Otherwise a site's sitemap, feeds and llms.txt are its own content.
    my $engine;
    if ( _engine_docs_public() ) {
        if ( -d $ENGINE_DOCS_DIR ) { $engine = $ENGINE_DOCS_DIR }
        elsif ( $unread && $!{EACCES} ) { $unread->{$ENGINE_DOCS_DIR} = "$!" }
    }
    push @queue, $engine if defined $engine;
    while ( my $dir = shift @queue ) {
        opendir( my $dh, $dir ) or do {
            $unread->{$dir} = "$!" if $unread;
            next;
        };
        for my $entry ( sort readdir($dh) ) {
            next if $entry =~ /^\./;
            next if $entry =~ /\.brief$/;    # SM073: briefs never index
            my $path = "$dir/$entry";
            # Never index the lazysite/ management tree (auth, templates,
            # cache); relevant when $root is the bare docroot.
            next if $path eq $LAZYSITE_DIR;
            if ( -d $path ) {
                # SM151: do not follow symlinked directories - a symlink can
                # form a cycle (which would hang the walk) or escape the
                # content root (which would leak a sibling domain's pages into
                # this domain's registries). Page serving is realpath-confined
                # (P1); the scanner simply refuses to traverse symlinked dirs.
                next if -l $path;
                # §7: never descend into ANOTHER domain's content root - a
                # bare-docroot host's sitemap must not enumerate client subtrees.
                next if $excl->{$path} && $path ne $root;
                # Ruling 171: nor into a folder that looks like another site's
                # content without being declared as one (_foreign_site_folder).
                next if $path ne $root && _foreign_site_folder($path);
                push @queue, $path;
            }
            elsif ( $entry =~ /\.(md|url)$/ ) {
                my $raw;
                if ( $entry =~ /\.md$/ ) {
                    # P25: a page it cannot open is left out and named.
                    $raw = eval { read_file($path) };
                    unless ( defined $raw ) {
                        $unread->{$path} = ( $@ || 'unknown' ) =~ s/\s+at \S+ line \d+.*//sr =~ s/\s+\z//r if $unread;
                        _scan_page_unreadable( $path, $@ || 'unknown', 'file', 'opened' );
                        next;
                    }
                }
                else {
                    # For .url files read the cached .html front matter isn't
                    # available - read from remote is too expensive, skip register
                    # unless a local .md sidecar exists
                    next;
                }

                # SM976 Q15h: a page whose reading dies registers nothing, logged.
                my ($meta) = eval { parse_yaml_front_matter($raw) };
                if ( my $why = $@ ) {
                    $unread->{$path} = $why =~ s/\s+at \S+ line \d+.*//sr =~ s/\s+\z//r if $unread;
                    _scan_page_unreadable( $path, $why );
                    next;
                }
                # SM1357: a page with no register: key is listed in the sitemap
                # and the summary by default; see _listed_by_default.
                my $default = _listed_by_default( $meta, _page_url( $path, $root ) );
                next unless $meta->{register} || $default;

                # SM181 + SM268 H13: a registry (sitemap.xml, llms.txt, the
                # feeds) is a STATIC artefact written to disk and served to
                # anyone, so the question is not "may this requester read it"
                # but "is it public at all". Draft and gated are two answers to
                # that one question and both live in _registry_hidden.
                next if _registry_hidden($path);

                # Get date from front matter or file mtime
                my $date = _page_date( $meta, $path );

                # Derive URL from path, relative to the scanned root (SM151).
                # SM1284: an engine page at the path it is served at - and not
                # at all when the site has its own page there, which wins.
                my $url_src = $path;
                if ( defined $engine && $path =~ m{\A\Q$engine\E/(.+)\.md\z}s ) {
                    next if -f _content_abs("$root/docs/$1.md");
                    $url_src = "$root/docs/$1.md";
                }
                my $url = _page_url( $url_src, $root );

                # P12: the page's other front matter, as a scan object carries
                # it, less the engine-private keys; and its tags, as a list.
                push @pages, {
                    %{ _front_matter_custom( $meta, $reserved, $private ) },
                    url      => $url,
                    title    => $meta->{title}    || '',
                    subtitle => $meta->{subtitle} || '',
                    date     => $date,
                    tags     => _page_tags($meta),
                    register => ( ref $meta->{register} eq 'ARRAY' ? $meta->{register} : [] ),
                    _listable => _registry_listable($meta),
                    _default  => $default,

                    # SM300: the description a registry publishes - the explicit
                    # meta_desc when the author set one, the subtitle otherwise.
                    # Resolved once here so every registry template gets the same
                    # answer instead of each re-deriving the fallback.
                    meta_desc =>
                        ( $meta->{meta_desc} // $meta->{subtitle} // '' ),
                    meta_title =>
                        ( $meta->{meta_title} // $meta->{title} // '' ),
                };
            }
        }
        closedir($dh);
    }

    return @pages;
}

1;
