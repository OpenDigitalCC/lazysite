package main;

# lazysite-processor/front-door.pm - the processor's front door (SM294).
#
# HOLDS   _front_door(): under LAZYSITE_FRONT_DOOR, a pool worker routes each
#         request itself - a page, a content static or a denial is answered in
#         this process, another surface or a wrapped request is relayed to a
#         child; _front_route($req), the module-free copy of
#         Lazysite::FrontDoor::route (t/lint/42 drives both); _front_relay and
#         its helpers _front_cgibin, _read_request_body, _front_body_cap
#         (SM389: the body is bounded before it is read) and _front_fail; and
#         @POOL_PRELOAD with _pool_preload (SM1169), the engine modules the
#         pool's parent loads before it forks its workers; SM1181 S3:
#         _front_session (a wrapped page's identity decided in the worker, as a
#         value), _front_bad_url (the SM128 guard, for every request it does not
#         hand to the auth wrapper) and _front_wrapper_action (the ?action=
#         requests that stay the wrapper's); SM1181 S4: the manager API relayed
#         without the wrapper, its child writing the contract from the value;
#         SM1226: _front_warm, the Odoo endpoint handed to its warm-fork parent,
#         and _odoo_endpoint_request / _front_odoo, the same for the split
#         templates' pool, which runs no front door.
# OWNS    which requests a pool worker answers itself and which it relays; which
#         modules the pool's parent loads for its workers; who a request the
#         front door would have wrapped is, in the pool.
# CALLS   _lazysite_dir_for, _conf_value, _security_headers, log_event, _lazy_lib,
#         _proxy_identity, _request_address, _trusted_proxy_spec, _timing_to
#         (lazysite-processor.pl and its parts); IO::Select and POSIX, required
#         inside _front_relay at call time, as before; Lazysite::Auth::Session and
#         Lazysite::BadUrl through _lazy_lib (SM1181 S3; preloaded by the pool's
#         parent); Lazysite::Auth::Identity's clear_identity_env and
#         write_identity_env, and Lazysite::Timing::handover, in the relay's
#         child (S4); Lazysite::WarmFork::Wire (socket_for, request) through
#         _lazy_lib, preloaded by the pool's parent (SM1226).
# READS   $DOCROOT, $LAZYSITE_DIR, $FRONT_CGIBIN, $RELAY_TIMEOUT, $TIMING; SETS
#         $REQUEST_IDENT and %ACCESS_REC (the script's, declared `our` there).
#         Whether the front door is on ($FRONT_DOOR) is the script's own decision,
#         read where it calls _front_door.
#
# A PART OF THE PROCESSOR, NOT A MODULE (SM944 S9). It is package main, required
# by absolute path from lazysite-processor.pl's BEGIN and never through @INC, and
# it loads nothing when it is compiled - ADR 0001 keeps the CGI render path free
# of the Lazysite:: tree. The front door runs only when LAZYSITE_FRONT_DOOR is
# set (the one-rule pool), where the two modules it asks are already resident.
use strict;
use warnings;

our ( $DOCROOT, $LAZYSITE_DIR, $FRONT_CGIBIN, $RELAY_TIMEOUT, $REQUEST_IDENT, $TIMING, %ACCESS_REC );

# --- Preload before fork (SM1169, SM1082 C1) ---

# THE ENGINE MODULES A POOLED REQUEST LOADS ON FIRST USE, named once. Each is
# loaded by _lazy_lib at the point a request needs it (ADR 0001 keeps the CGI
# render path free of them), so under the pool every worker paid for each on its
# own first request - and again for every respawn, which is every
# LAZYSITE_FCGI_MAX_REQUESTS requests. The pool PARENT loads them once, before
# FCGI::ProcManager forks, and a worker inherits them copy-on-write.
#
# THE LIST IS THE LAZY LOADS, NOT A GUESS: t/lint/269 holds it to the modules the
# processor and its parts name through _lazy_lib or `require Lazysite::...`, so a
# module added to the request path and left off this list fails there. The `use`
# closure of each comes with it, and t/lint/269 reads every file-scope variable of
# that whole set (the SM973 class: a variable a worker keeps from one visitor to
# the next).
#
# Only the pool's branch calls _pool_preload. A plain CGI request is a fresh
# process and loads what it needs, as before.
our @POOL_PRELOAD = qw(
    Lazysite::Auth::Identity
    Lazysite::Auth::AddressProfiles
    Lazysite::Auth::AddressAudit
    Lazysite::Auth::AddressScope
    Lazysite::I18n
    Lazysite::Fetch
    Lazysite::Data::Tables
    Lazysite::Data::Schedule
    Lazysite::Data::StructuredData
    Lazysite::Extensions
    Lazysite::Extensions::Hooks
    Lazysite::Auth::Session
    Lazysite::BadUrl
    Lazysite::Maintenance
    Lazysite::WarmFork::Wire
);

# Load the modules, then compile one trivial template and one trivial page of
# Markdown so Template's parser and Text::MultiMarkdown's rules are in the parent
# too: they compile on first use, not on `use`, and are most of what a worker's
# first page costs. Nothing is written (no compile directory, no cache) and
# nothing a request owns is touched: no request has been read yet, so there is no
# person in the process to carry.
#
# A module that will not load (an optional dependency absent, say) is logged and
# skipped: the worker then loads it, or fails to, exactly as it did before.
sub _pool_preload {
    my @failed;
    for my $m (@POOL_PRELOAD) {
        eval { _lazy_lib($m); 1 } or push @failed, $m;
    }
    log_event( 'INFO', 'pool', 'preload skipped a module that did not load', modules => join( ',', @failed ) )
        if @failed;
    eval {
        my $tt  = Template->new( {} );
        my $out = '';
        $tt->process( \'[% FOREACH i IN [1] %][% i | html %][% END %][% IF x %]y[% END %]', {}, \$out );
        Text::MultiMarkdown->new->markdown("*a*\n\n| h |\n|---|\n| c |\n");
        1;
    };
    return scalar(@POOL_PRELOAD) - scalar(@failed);
}

# --- The front door (SM294) ---

# SM293 step 5 put every routing decision the vhost templates used to make into
# Lazysite::FrontDoor::route(), and shipped lazysite-front.pl to execute it - so a
# front end can be ONE rule. That script dispatches with exec(), which is exactly
# right for a one-shot CGI and fatal here: exec REPLACES the process, so a worker
# that dispatched that way would cease to exist and the next request would find
# nothing listening. The failure is invisible to a single request, which answers
# perfectly on the way out.
#
# So the worker consults the same table and splits by what it can BE:
#
#   - the hot path (a page, a content static, a denial) is what this process
#     already is, so it is answered in-process at no cost - and that is the
#     overwhelming majority of requests, which is the whole point of the pool;
#   - the cold path (another surface, or anything needing the auth wrapper) is
#     RELAYED to a child, costing a process on exactly the requests that cost one
#     today. Never worse than the CGI front door, much better than it on the rest.
#
# Off unless LAZYSITE_FRONT_DOOR is set, so an existing pool is byte-identical.
#
# Module-free (ADR 0001), mirroring Lazysite::FrontDoor::route; t/lint/42 drives
# BOTH and compares answers, because the two must not drift into a front end and
# an engine that disagree about who owns a URL - which is SM248, SM268 H17 and
# SM283, all three.
sub _front_route {
    my ($req)   = @_;
    my $docroot = $req->{docroot} // '';
    my $uri     = $req->{uri}     // '/';
    my $cookie  = $req->{cookie}  // '';
    $docroot =~ s{/+\z}{};
    $uri     =~ s/\?.*\z//s;

    return { surface => 'denied', why => 'engine-owned path' }
        if $uri =~ m{\A/lazysite(?:/|\z)} || $uri =~ /[.]brief\z/;

    if ( $uri =~ m{\A/cgi-bin/(lazysite-[a-z-]+[.]pl)\z} ) {
        my $script = $1;
        my $wrap
            = ( $script =~ /\A lazysite-(?:processor|manager-api)[.]pl \z/x )
            ? 1
            : 0;
        return { surface => 'cgi', target => $script, wrapped => $wrap,
            why => 'named cgi surface' };
    }

    # SM1182: the two extensions install.pl links into cgi-bin under their own names
    #    (no lazysite- prefix). Every native form posts to /cgi-bin/form-handler.pl;
    #    under the one rule it matched nothing above and fell to the processor as a
    #    page miss, so a form was never delivered. By NAME, never a wider pattern:
    #    only what the installer ships there is reachable. Both run direct, outside
    #    the auth wrapper, as they do installed (SM402: the handler reads no identity).
    if ( $uri =~ m{\A/cgi-bin/(form-handler|payment-demo)[.]pl\z} ) {
        return { surface => 'cgi', target => "$1.pl", wrapped => 0,
            why => 'linked extension cgi' };
    }

    return { surface => 'cgi', target => 'lazysite-dav.pl', wrapped => 0,
        why => 'dav prefix' }
        if $uri =~ m{\A/dav(?:/|\z)};

    my $lz       = _lazysite_dir_for($docroot);
    my $has_acls = ( -f "$lz/auth/acls.json" ) ? 1 : 0;
    ( my $rel = $uri ) =~ s{\A/+}{};

    if ( $has_acls && length $rel && -f "$docroot/$rel" ) {
        return { surface => 'processor', wrapped => 1,
            why => 'existing static, acl store present' };
    }

    if ( $uri =~ m{\A/([^.]+)\z} ) {
        my $stem = $1;
        if ( !-f "$docroot/$stem.md" ) {
            my $legacy
                = ( -f "$docroot/$stem.html" )  ? "$stem.html"
                : ( -f "$docroot/$stem.shtml" ) ? "$stem.shtml"
                :                                 undef;
            if ( defined $legacy ) {
                return { surface => 'processor', wrapped => 1,
                    why => 'legacy static page, acl store present' }
                    if $has_acls;
                return { surface => 'static', target => $legacy,
                    why => 'legacy static page' };
            }
        }
    }

    if ( $uri eq '/' && !-f "$docroot/index.md" && -f "$docroot/index.html" ) {
        return { surface => 'processor', wrapped => 1,
            why => 'legacy index, acl store present' }
            if $has_acls;
        return { surface => 'static', target => 'index.html',
            why => 'legacy index' };
    }

    if ( $cookie =~ /lazysite_auth=/ && !( length $rel && -f "$docroot/$rel" ) )
    {
        return { surface => 'processor', wrapped => 1,
            why => 'session cookie present' };
    }

    return { surface => 'static', target => $rel, why => 'existing static' }
        if length $rel && -f "$docroot/$rel";

    return { surface => 'processor', wrapped => 0, why => 'page miss' };
}

# Where the surfaces live. Same resolution as lazysite-front.pl, so the CGI and
# the pool front doors cannot disagree about it.
sub _front_cgibin {
    return $FRONT_CGIBIN if length $FRONT_CGIBIN;
    my $parent = $DOCROOT;
    $parent =~ s{/[^/]*\z}{};
    return "$parent/cgi-bin";
}

# SM389: read the request body, bounded. Returns ( $body, $too_big ).
#
# Its own sub rather than inline in the relay so it can be DRIVEN by a test with
# a real filehandle. The behaviour being claimed here is "a hostile body does not
# size this worker", and that is not a claim a source-text match can settle.
sub _read_request_body {
    my ($cap) = @_;
    my $body  = '';
    my $len   = ( $ENV{CONTENT_LENGTH} || 0 ) + 0;

    if ( $len > 0 ) {

        # Refuse before allocating, as the manager's upload path already does.
        # Reading it in order to find out how big it is would BE the defect.
        return ( '', 1 ) if $len > $cap;
        my $got = 0;
        while ( $got < $len ) {
            my $n = read STDIN, $body, $len - $got, $got;
            last if !defined $n || $n == 0;
            $got += $n;
        }
        return ( $body, 0 );
    }

    return ( '', 0 )
        unless ( $ENV{REQUEST_METHOD} // 'GET' ) =~ /\A(?:POST|PUT|PATCH)\z/;

    # No declared length - chunked transfer encoding, which the CLIENT chooses.
    # Read in bounded chunks and stop one byte past the cap: that is enough to
    # know it is over, and finding out HOW far over would mean reading it all,
    # which is the thing being prevented.
    my $got = 0;
    while ( $got <= $cap ) {
        my $n = read STDIN, $body, 65_536, $got;
        last if !defined $n || $n == 0;
        $got += $n;
    }
    return ( '',    1 ) if $got > $cap;
    return ( $body, 0 );
}

# SM389: how much request body the relay will hold in memory.
#
# THIS IS A MEMORY BACKSTOP, NOT A POLICY GATE. Policy lives downstream - the
# manager's manager_upload_max_mb, the form handler's upload_max_kb, WebDAV's
# own limit - and each refuses with an error that names the setting the sysop
# can change. The relay must never be the thing that quietly refuses a body
# those layers would have accepted.
#
# So it follows the upload limit UP. A sysop who raises
# manager_upload_max_mb is entitled to have uploads work; a fixed ceiling
# underneath it would present as "uploads broke after a config change" with
# nothing pointing at this function. front_max_body_mb overrides both, for the
# sysop who wants the backstop somewhere else entirely.
sub _front_body_cap {
    my $mb = 64;                                                # generous default ceiling
    my $up = ( _conf_value('manager_upload_max_mb') || 0 ) + 0;
    $mb = $up if $up > $mb;
    my $own = ( _conf_value('front_max_body_mb') || 0 ) + 0;
    $mb = $own if $own > 0;
    return $mb * 1024 * 1024;
}

# The access record's status is the numeric code (the record writes it as a
# number); the whole status line, "503 Service Unavailable", made a non-numeric
# warning in the worker's log for every answer given here (n795, the restack).
sub _front_fail {
    my ( $status, $text ) = @_;
    $ACCESS_REC{s}  = ( $status =~ /\A(\d{3})\b/ )[0] // 500;
    $ACCESS_REC{ch} = 'front';
    print "Status: $status\r\n";
    print "$_\r\n" for _security_headers();    # SM381
    print "Content-Type: text/plain; charset=utf-8\r\n\r\n";
    print "$text\n";
    return 1;
}

# How long a relayed surface may take before the worker gives up on it. A worker
# blocked forever on a wedged child serves NOTHING else - one hung request would
# take the site down, which is the failure mode the dev server already taught
# this project once (L-DEVBIND). Generous, because a large DAV upload is a
# legitimate slow request; finite, because the pool must survive a bad one.

# Run another surface as a child and pass its response through.
#
# The child gets real file descriptors 0 and 1 (a pipe each), NOT this worker's
# tied FCGI handles - those are Perl-level objects that do not survive exec, so
# the hand-off has to happen at the descriptor level or the child's output goes
# to the listen socket.
sub _front_relay {
    my ($decision) = @_;
    require IO::Select;
    require POSIX;

    my $cgibin = _front_cgibin();
    my $target
        = ( $decision->{surface} eq 'cgi' )
        ? "$cgibin/$decision->{target}"
        : "$cgibin/lazysite-processor.pl";

    return _front_fail( '500 Internal Server Error',
        "lazysite: surface not found: $decision->{target}" )
        unless -f $target;

    # The auth wrapper's contract is UNCHANGED: it validates the session cookie,
    # sets the trust headers, and execs whatever LAZYSITE_PROCESSOR names. Only
    # the choice of which requests get wrapped moved; how wrapping works did not,
    # so the trust design and the t/lint/38 gate are untouched. Folding the
    # wrapper in-process means replacing those headers with an identity value,
    # which is an auth-spine change and has its own filing.
    #
    # SM1181 S4: that filing's manager API arrives here unwrapped, carrying the
    # worker's value as `identity`; the child below writes the same contract from it.
    my $program = $target;
    if ( $decision->{wrapped} ) {
        my $wrapper = "$cgibin/lazysite-auth.pl";
        return _front_fail( '500 Internal Server Error',
            'lazysite: auth wrapper not found' )
            unless -f $wrapper;
        $ENV{LAZYSITE_PROCESSOR} = $target;
        $program = $wrapper;
    }

    # Read the request body before forking: it comes off this worker's tied FCGI
    # STDIN, which the child cannot inherit.
    #
    # SM389: BOUNDED, both ways. A declared CONTENT_LENGTH was trusted whatever
    # it said, and a request with no CONTENT_LENGTH at all - chunked transfer
    # encoding, which a client chooses, not the sysop - was slurped whole
    # under `local $/`. Either one sizes this worker to the body, and the worker
    # PERSISTS: the memory does not come back when the request ends.
    my ( $body, $too_big ) = _read_request_body( _front_body_cap() );
    return _front_fail( '413 Payload Too Large', 'lazysite: request body too large' )
        if $too_big;

    # SM1226: the Odoo endpoint is answered by its warm-fork parent when one is
    # listening; when none is (no lazysited, the extension just enabled, a restart
    # in progress), the CGI runs below exactly as before.
    # SM1369 X5 (H-5): a warm endpoint is one an enabled extension declares
    # (hooks.endpoints, warm: 1), read from the hook index, not known by name.
    if ( !$decision->{wrapped} && _warm_endpoint( $decision->{target} ) ) {
        my $done = _front_warm( $body, $decision->{target} );
        return $done if defined $done;
    }

    pipe my $from_kid, my $kid_out or
        return _front_fail( '500 Internal Server Error', 'lazysite: pipe' );
    pipe my $kid_in, my $to_kid or
        return _front_fail( '500 Internal Server Error', 'lazysite: pipe' );

    # FCGI::ProcManager installs a SIGCHLD reaper for ITS children; if it reaps
    # ours first, waitpid below never sees an exit status and we would block.
    local $SIG{CHLD} = 'DEFAULT';
    local $SIG{PIPE} = 'IGNORE';    # a child that dies mid-body must not kill us

    my $kid = fork();
    return _front_fail( '500 Internal Server Error', 'lazysite: fork' )
        unless defined $kid;

    if ( $kid == 0 ) {
        close $from_kid;
        close $to_kid;
        POSIX::dup2( fileno($kid_in),  0 );
        POSIX::dup2( fileno($kid_out), 1 );
        close $kid_in;
        close $kid_out;
        # SM1181 S4: THE MANAGER API WITHOUT THE WRAPPER. The worker decided who this
        # request is (_front_session, request_session once); here, in the child and
        # never in the worker, the identity variables the parameters carried are
        # cleared - the sentinel, the sid, the passwordless flag and the six trust
        # headers - and the wrapper's contract is written from the value by the one
        # writer the wrapper itself calls. The API's own gate and checks then run as
        # they did behind the wrapper. SM1144: the worker's time so far is handed
        # across the exec as the wrapper handed its own.
        if ( ref $decision->{identity} eq 'HASH' ) {
            Lazysite::Auth::Identity::clear_identity_env( $decision->{identity} );
            Lazysite::Auth::Identity::write_identity_env( $decision->{identity} );
            Lazysite::Timing::handover() if $TIMING;
        }
        # _exit, not exit: this child is a fork of a FastCGI worker and must not
        # run its parent's END blocks or flush its parent's buffers on the way
        # out. The parent sees empty output and answers 500.
        exec {$^X} $^X, $program or POSIX::_exit(127);
    }

    close $kid_out;
    close $kid_in;

    my $rsel = IO::Select->new($from_kid);
    my $wsel = IO::Select->new();
    if   ( length $body ) { $wsel->add($to_kid) }
    else                  { close $to_kid }

    my $sent     = 0;
    my $written  = 0;
    my $deadline = time + $RELAY_TIMEOUT;
    my $timedout = 0;

    while ( $rsel->count || $wsel->count ) {
        my $left = $deadline - time;
        if ( $left <= 0 ) { $timedout = 1; last }
        my ( $r, $w ) = IO::Select->select( $rsel, $wsel, undef, $left );
        for my $h ( @{ $w || [] } ) {
            my $n = syswrite $h, $body, length($body) - $written, $written;
            if ( !defined $n ) { $wsel->remove($h); close $h; next }
            $written += $n;
            if ( $written >= length $body ) { $wsel->remove($h); close $h }
        }
        for my $h ( @{ $r || [] } ) {
            my $buf = '';
            my $n   = sysread $h, $buf, 65_536;
            if ( !defined $n || $n == 0 ) { $rsel->remove($h); close $h; next }
            print $buf;
            $sent += $n;
        }
    }

    if ($timedout) {
        kill 'TERM', $kid;
        select undef, undef, undef, 0.2;    ## no critic (ProhibitSleepViaSelect)
        kill 'KILL', $kid;
    }
    waitpid $kid, 0;
    my $rc = $?;

    if ($timedout) {
        log_event( 'ERROR', $ENV{REDIRECT_URL} // '-', 'relay timed out',
            surface => $decision->{target} // $decision->{surface},
            seconds => $RELAY_TIMEOUT );
        # Headers are already gone if anything was sent; truncating is all that
        # is left, and it is what any CGI host does. Say so in the log either way.
        return _front_fail( '504 Gateway Timeout', 'lazysite: surface timed out' )
            unless $sent;
        $ACCESS_REC{s} = 504;
        return 1;
    }

    unless ($sent) {
        log_event( 'ERROR', $ENV{REDIRECT_URL} // '-', 'relay produced nothing',
            surface => $decision->{target} // $decision->{surface}, rc => $rc );
        return _front_fail( '500 Internal Server Error',
            'lazysite: surface produced no response' );
    }

    # The child emitted its own CGI status line; record what we can for the
    # access log without re-parsing its headers.
    $ACCESS_REC{s}  = 200 unless defined $ACCESS_REC{s};
    $ACCESS_REC{ch} = 'front';
    return 1;
}

# --- The Odoo endpoint, warm-forked (SM1226, SM1082 C3) ---

# THE ODOO ENDPOINT WITHOUT A PROGRAM START. Relayed, it was a fork of this worker
# and an exec of lazysite-odoo.pl - a perl and the endpoint's modules compiled on
# every call (SM1164 D5 measured it). Its warm-fork parent (Lazysite::WarmFork,
# a lazysited service) has compiled them once and forks a fresh child per request,
# so nothing of one visitor reaches the next; this worker hands it the request -
# the same parameters and body the CGI would have been given - over the site's
# socket and passes the answer through.
#
# Returns 1 when answered, undef when nothing reached the parent (no socket, a
# refused connection): the caller then runs the CGI. Once the parent has taken
# the request it is never re-run, whatever happens - a write may have been made -
# so a failure after that point is answered here, as the relay answers one.
sub _front_warm {
    my ( $body, $target ) = @_;
    _lazy_lib('Lazysite::WarmFork::Wire');
    my ($sock) = Lazysite::WarmFork::Wire::socket_for( $LAZYSITE_DIR, $target );
    return undef unless defined $sock && -S $sock;
    my $r = Lazysite::WarmFork::Wire::request( $sock, {%ENV}, $body, timeout => $RELAY_TIMEOUT );
    return undef unless $r->{connected};
    my $out = $r->{out} // '';
    if ( $r->{timed_out} ) {
        log_event( 'ERROR', $ENV{REDIRECT_URL} // '-', 'warm-fork relay timed out',
            surface => $target, seconds => $RELAY_TIMEOUT );
        return _front_fail( '504 Gateway Timeout', 'lazysite: surface timed out' ) unless length $out;
    }
    unless ( length $out ) {
        log_event( 'ERROR', $ENV{REDIRECT_URL} // '-', 'warm-fork relay produced nothing',
            surface => $target, why => $r->{why} // '' );
        return _front_fail( '500 Internal Server Error', 'lazysite: surface produced no response' );
    }
    print $out;
    my ($st) = $out =~ /\AStatus:\s*(\d{3})/;
    $ACCESS_REC{s}  = $st // 200 unless defined $ACCESS_REC{s};
    $ACCESS_REC{ch} = 'front';
    return 1;
}

# SM1226 (ruled 2026-10-20, option a): THE SPLIT TEMPLATES' ODOO ENDPOINT. The
# split FastCGI templates (nginx and Apache vhost-fcgi, Hestia's fcgi templates)
# send /cgi-bin/lazysite-odoo.pl to the pool, whose worker runs no front door
# there. The worker hands it to the warm-fork parent as the front door does, or
# runs the CGI when no parent is listening (_front_relay). Matched by the path
# alone: REDIRECT_URL is the web server's (nginx sets it to the path), else the
# request's REQUEST_URI less its query (Apache's proxy handler). A client cannot
# reach this with another path, and every other request renders as before.
sub _odoo_endpoint_request {
    my $uri = $ENV{REDIRECT_URL} // $ENV{REQUEST_URI} // '';
    $uri =~ s/\?.*\z//s;
    return $uri eq '/cgi-bin/lazysite-odoo.pl' ? 1 : 0;
}

# As the front door treats it: the bad-URL guard (SM1181 R5), then the relay,
# warm-forked when it can be.
sub _front_odoo {
    my $uri = '/cgi-bin/lazysite-odoo.pl';
    return 1 if _front_bad_url($uri);
    return _front_relay( { surface => 'cgi', target => 'lazysite-odoo.pl', wrapped => 0,
            why => 'odoo endpoint (split template)' } );
}

# --- Identity in the worker (SM1181 S3, SM1082 C2) ---

# THE AUTH WRAPPER'S OWN REQUESTS. lazysite-auth.pl answers a request whose query
# names one of its actions itself - sign in, sign out, a claim, a token exchange or
# rotation, a forgotten password, an unsubscribe - before it would run the page.
# Matched exactly as it matches (the same unanchored `action=` in the query, the
# same method for each), so a wrapped request that names one is still relayed to
# it, and S3 moves only what the wrapper would have exec'd: the page.
sub _front_wrapper_action {
    my $q = $ENV{QUERY_STRING} // '';
    return 0 unless $q =~ /action=([a-z][a-z-]*)/;
    my $act  = $1;
    my $post = ( $ENV{REQUEST_METHOD} // 'GET' ) eq 'POST';
    return 1 if $act eq 'logout' || $act eq 'unsubscribe';
    return 1 if $post && $act =~ /\A(?:login|claim|exchange|rotate|forgot)\z/;
    return 0;
}

# SM128 / SM1181 S3 (ruling R5, threat T13): THE BAD-URL GUARD, ON EVERY REQUEST.
#
# The blocker ran only where the auth wrapper ran, and the pool's front door sent
# the wrapper only the requests it wrapped, so an anonymous probe at a pooled site
# was never counted and a blocked address was refused only when it carried a
# cookie. Now the front door runs Lazysite::BadUrl::guard - the wrapper's own
# decision, the same keys, the same visitor address (SM929), the same audit row -
# for every request except one it hands to the wrapper, which runs the guard
# itself (so no probe counts twice). Answers 403 as the wrapper does; a worker
# must not exit.
sub _front_bad_url {
    my ($uri) = @_;
    _lazy_lib('Lazysite::BadUrl');
    my @lines;
    if ( open my $fh, '<:utf8', "$LAZYSITE_DIR/lazysite.conf" ) {
        @lines = <$fh>;
        close $fh;
    }
    return 0
        unless Lazysite::BadUrl::guard( docroot => $DOCROOT, path => $uri,
        ip => _request_address( _trusted_proxy_spec() ), conf_lines => \@lines );
    return _front_fail( '403 Forbidden', '403 Forbidden' );
}

# SM1181 S3: WHO A WRAPPED PAGE REQUEST IS, DECIDED IN THE WORKER.
#
# Under the one-rule pool a signed-in page, a /manager/ page and an ACL-protected
# static were relayed: fork, exec the auth wrapper, which verified the cookie,
# wrote the identity headers and exec'd the processor - two programs per request
# for a page this worker could render itself. The wrapper's decision is
# Lazysite::Auth::Session::request_session (S1), and the processor reads a held
# value in place of the headers (S2), so the worker asks the one function ONCE,
# with this request's Cookie header and the render path's proxy answer, and holds
# what it returns in $REQUEST_IDENT for main(). No fork, no exec, no header
# written: in the pool the value is the only trusted identity (R3), and
# apply_trust_gate strips every identity header a client sent while it is held
# (R4).
#
# A failure holds an ANONYMOUS value (no user, no groups) with the reason, so a
# wrapped request is decided here either way and nothing below falls back to the
# request's own headers. Every check the wrapper's verification made comes with
# the function: the signature, the expiry, a removed, disabled or revoked account,
# a store that cannot be read, the fresh groups and those the address is refused
# for, the Odoo site sign-in's record and its odoo_identity_ttl (never stale-ok:
# that is the Odoo endpoint's own question, T8). The line logged is the wrapper's,
# from the same function (T11), under the site's log_level as the wrapper reads
# it (SM1099). $REQUEST_IDENT is cleared at both ends of the request (T1, T7).
sub _front_session {
    my ($uri) = @_;
    _lazy_lib('Lazysite::Auth::Session');
    my $lvl = _conf_value('log_level');
    $ENV{LAZYSITE_LOG_LEVEL} = $lvl if defined $lvl && length $lvl && !$ENV{LAZYSITE_LOG_LEVEL};

    my $cookie = $ENV{HTTP_COOKIE} // '';

    # SM1181 S5: `pool`, as the front door is only ever a worker - the sentinel is
    # never consulted here, so a listed proxy's user wins over a cookie (R3, SM1130).
    _timing_to('identity');    # SM1144: the wrapper's time was the page's `identity`
    my ( $ident, $why, %detail ) = Lazysite::Auth::Session::request_session(
        lazysite_dir => $LAZYSITE_DIR, proxy => _proxy_identity(), cookie => $cookie, pool => 1 );
    _timing_to('config');

    my @line = Lazysite::Auth::Session::session_log_line( $ident, $why, \%detail,
        cookie_sent => length $cookie ? 1 : 0 );
    log_event( $line[0], $uri, @line[ 1 .. $#line ] ) if @line;

    # SM1381: renew - where a session refused only as stale is renewed (the verdict's)
    $REQUEST_IDENT = $ident || {
        user => '', groups => [], name   => '', email => '', sid => '', no_password => 0,
        provider => '', stale => 0, source => 'anonymous', why => $why // '',
        renew => $detail{renew} // '' };
    # SM297: a fault value names the store it could not read
    $REQUEST_IDENT->{store} = $detail{store} // '' unless $ident;
    return;
}

# SM297 (ruling 206, ruling 217): the fault value request_session returned - a
# session cookie whose store cannot be read - is refused with a 503, as the auth
# wrapper refuses it on the CGI path, and never rendered as anonymous. The log line
# _front_session wrote names the store and the repair. Rulings 216, 217: the answer
# is the engine's one refusal for a store it cannot tell (_serve_store_fault, in
# gates.pm). Returns 1 when answered.
sub _front_session_fault {
    return 0 unless ref $REQUEST_IDENT eq 'HASH' && ( $REQUEST_IDENT->{why} // '' ) eq 'cannot-tell';
    my $store = $REQUEST_IDENT->{store};
    undef $REQUEST_IDENT;
    $ACCESS_REC{ch} = 'front';
    return _serve_store_fault( $ENV{REDIRECT_URL} // $ENV{REQUEST_URI} // '/', $store, '', logged => 1 );
}

# Consult the front door. Returns true when the request has been answered here,
# false to fall through to main() - which is the hot path and must stay cheap.
sub _front_door {
    my $uri      = $ENV{REDIRECT_URL} // $ENV{REQUEST_URI} // '/';
    my $decision = _front_route(
        { docroot => $DOCROOT,
            uri    => $uri,
            method => ( $ENV{REQUEST_METHOD} // 'GET' ),
            cookie => ( $ENV{HTTP_COOKIE}    // '' ),
        }
    );

    # SM1181 S3: a page the front door would have wrapped is rendered HERE, its
    # identity decided by _front_session; the manager API, /cgi-bin/ surfaces and
    # the wrapper's own ?action= requests are relayed as before (S4 is the API).
    # R8: the split vhost-fcgi templates never send a signed-in request to the pool
    # (their carve-out runs the wrapper under fcgiwrap) and have no front door, so
    # this reaches only the one-rule pool.
    my $in_worker = $decision->{wrapped}
        && $decision->{surface} eq 'processor'
        && !_front_wrapper_action();
    # SM1181 S4: the manager API is decided here the same way, then relayed to the
    # API directly - one program, not two. It cannot run in the worker: it is a
    # top-level script that answers by `exit` in dozens of places (C3 gives it
    # warm-fork). Its own gate, CSRF and capability checks run in it unchanged.
    my $api_direct = $decision->{wrapped}
        && $decision->{surface} eq 'cgi'
        && ( $decision->{target} // '' ) eq 'lazysite-manager-api.pl'
        && !_front_wrapper_action();
    my $to_wrapper = !$in_worker && !$api_direct
        && ( $decision->{wrapped} || ( $decision->{target} // '' ) eq 'lazysite-auth.pl' );
    return 1 if !$to_wrapper && _front_bad_url($uri);    # R5

    # 404 rather than 403, matching lazysite-front.pl: a 403 confirms the path
    # exists, and these are paths whose existence is not the visitor's business.
    # (Reached only under the front door. The processor's own guard on the same
    # paths answers 403 and is left alone here - noted in the SM294 filing.)
    if ( $decision->{surface} eq 'denied' ) {
        $ACCESS_REC{s}  = 404;
        $ACCESS_REC{ch} = 'front';
        print "Status: 404 Not Found\r\n";
        print "Content-Type: text/html; charset=utf-8\r\n";
        print "$_\r\n" for _security_headers( html => '<p>Not found</p>' );    # SM352
        print "\r\n";
        print "<p>Not found</p>\n";
        return 1;
    }

    # What this process already is: render it here. 'static' included, because
    # the processor serves content statics itself (_serve_content_static) - the
    # front door does not reimplement byte ranges, conditional GETs or content
    # types, three things that are easy to get subtly wrong.
    return 0
        if !$decision->{wrapped}
        && ( $decision->{surface} eq 'processor'
        || $decision->{surface} eq 'static' );

    if ($in_worker) {
        _front_session($uri);
        return 1 if _front_session_fault();
        return 0;
    }

    if ($api_direct) {
        _front_session($uri);
        return 1 if _front_session_fault();
        _lazy_lib('Lazysite::Auth::Identity');
        return _front_relay( { %$decision, wrapped => 0, identity => $REQUEST_IDENT } );
    }

    return _front_relay($decision);
}

1;
