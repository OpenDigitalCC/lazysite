---
title: AI connector - tools reference
subtitle: What a grant reaches, and every tool the MCP connector exposes.
auth: required
search: false
---

## Who this is for

An AI agent working on this site, and whoever builds or debugs a client for it.
This is the one page that says what a grant reaches - its capabilities and the
paths denied to it - and lists every tool the MCP connector exposes. How a client
reaches the site and authenticates - the
[endpoints](/docs/ai-connector-setup#endpoints), the two
[connection modes](/docs/ai-connector-setup#connectionmodes) and
[authentication](/docs/ai-connector-setup#authentication) - is in
[Connect an AI assistant](/docs/ai-connector-setup), with the steps for adding the
connector to Claude.ai, ChatGPT or Claude Code; what to do once connected is in
the briefings, starting with
[AI briefing - publishing](/docs/ai-briefing-publishing).

::: widebox
The connector is **supervised, not autonomous**: an AI drafts and edits through
these tools, but it is bound by the partner's capabilities and per-file ACLs, the
deny-list (it can never read or write delivery secrets), and - for write actions -
the AI client's own per-call approval. A read is not audited unless it is refused
or fails; writes are recorded as material events.
:::

## Capabilities

A partner's grant (visible in `whoami.capabilities`) gates the tools:

- `manage_content` - read/write content pages and use the file tools (most tools).
  Defaults to the `webdav` grant; set off for a theme-only partner.
- `manage_themes` - activate themes.
- `manage_layouts` - activate layouts.
- `manage_domains` - manage the domains this instance serves, and move whole
  sites between them (the `site_backup` / `site_apply` tools; the `domain-*`
  control-API actions). A token reaches only the domains its scope names, and
  a token with no scope reaches none: the operator gives it one by naming its
  group in a domain's `allowed_groups`. Such a token may still create a domain
  with the control API's `domain-add` by naming one of its own groups as the
  new domain's `allowed_groups`: the content root must lie outside every
  existing domain, and may be an existing folder unless an access rule
  protects it; afterwards the token reaches that domain through the group and
  no other. A group the account is not in is refused. The same
  holds for every tool that
  names a `host` - `domain_set`, `preview_domain`, `read_nav`, `set_nav`, the
  `host` form of `activate_theme` and `activate_layout` - and `list_domains`
  shows only the domains the grant reaches. A domain added or repointed must
  have its content inside the scope. Grants add: a grant with a scope reaches
  the primary site only when the primary's own row, `(default)`, names its group
  too (`dav_scopes` then holds `/`, the primary); otherwise it does not reach the
  primary, nor change anything the whole instance reads:
  `activate_theme` and `activate_layout` without a `host`, `install_layout`,
  `delete_layout`, the handler and schedule tools, `create_theme` with
  `activate`, and on the control API the site configuration, extensions,
  connectors and instance backups are refused to it; it changes its own
  domains through the `host` forms. A grant with no scope keeps them, and so
  does one granted the primary's row: it reaches the primary, whose settings
  they are. A theme or layout a site
  serves is that site's: a confined grant writes one only when no site serves
  it or only its own domains do (copy it, edit the copy, bind the copy with
  `host`). A form is reached through the pages that bind it (`form: NAME`),
  and a form no page binds is the primary's; a brief is its page's, or its
  row's table's; `form_list` and `list_briefs` show only those the grant
  reaches. A safety export is its table's domain's, and one written before
  exports recorded a domain is the primary's. A page a confined grant writes,
  moves, copies, uploads, restores or applies may not newly bind a form it does
  not reach; editing a page that already binds one, and removing a binding,
  still work.
- `webdav` - the WebDAV transport / file-API mechanism flag.
- `manage_config` - site configuration (control API, not exposed as MCP tools).
- `manage_connectors` - where site data may be sent: define connectors, set their
  secrets, read the call record (control API only in this release; see
  /docs/connectors). Calling a connector as a logged-in user needs no
  capability - the connector's own `callers` groups decide.
- `analytics` - read the visitor-log analysis. Off by default; an explicit grant,
  since it exposes (aggregated, IP-anonymised, path-free) log data. Visitor analysis
  is available both as the MCP `analyse_visitors` tool AND as the control-API
  `analyse_visitors` action (`?action=analyse_visitors&window=N`), so an API-channel
  client gets it too.
- `audit` - read the audit trail (the in-page Audit view plus the control-API
  `audit` action). A separate capability from `analytics`; off by default.

Per-file ACLs (owner + read/write lists, with `@groups`) bind a token client
exactly as over WebDAV - a tool call is refused if the partner lacks access to the
target, regardless of capability.

Capabilities are read from your account on every request (the token does not
encode them), so a grant is effective immediately - you do not need a new token.
A grant taken away is refused on your next request in the same way, and what
confines you (your domain scope) still applies when your grant widens.
`whoami.grant` says this in the response. A client that fetched the tool list
when it connected keeps showing that list: list the tools again, or reconnect
the connector, to see a tool you have just been granted. No new pairing key is
needed.

An operator gives an agent account a ROLE - a group that bundles the
capabilities for one job. The shipped agent roles are `content-agent` (pages,
navigation and forms, a form's own configuration included), `data-agent` (data
tables, their rows and authoring briefs), `forms-reader` (form submissions,
read only) and `analytics-agent` (visitor analytics), each over MCP; an account
may hold several. `whoami.roles` names the roles you hold and, under `beyond`,
any capability you hold that none of them grants.

`manage_forms` reads and writes a form's own configuration,
`lazysite/forms/<name>.conf`, through `read_file` and `write_file` as well as
WebDAV: its targets name existing handlers only (`- handler: <id>`). A grant
holding `manage_forms` without `manage_content` is offered the two tools for
that path alone - their listing says so, and `whoami.tools_by_reach` names the
reach under `path_only_reach`.
`smtp.conf`, `handlers.conf` and `schedule.conf` are not forms and stay closed.

## Scope and denied paths

Your capabilities and path scope come from the brief (and `whoami`). The content
tree, assets, the layout/theme files under `lazysite/layouts/`, `lazysite/nav.conf`,
and a form's dispatch config `lazysite/forms/<name>.conf` (the last two with
`manage_nav` and `manage_forms` respectively) are writable within scope. These paths are **denied** and the
server rejects writes to them:

`/cgi-bin/`
: Executable scripts (processor, auth CGI, manager API, extensions). Never writable.

`/lazysite/lazysite.conf`
: Site configuration. Config keys are set through the control API with an
  allowlist, not by overwriting this file.

`/lazysite/auth/`
: User and group credential store.

`/lazysite/forms/smtp.conf`, `/lazysite/forms/handlers.conf`, `/lazysite/forms/schedule.conf`, `/lazysite/forms/submissions/`
: SMTP credentials, handler definitions, the schedule, and the submitted
  entries. Handlers and the schedule are created through the handler actions
  (`save_handler`, `save_schedule` over MCP; `handler-save`, `schedule-save`
  over the control API), where the handler's destination decides the
  capability - never by writing the file. A form's own dispatch config,
  `lazysite/forms/<name>.conf`, **is** writable with `manage_forms` (it only
  names handlers, and a target that names anything else is refused with
  422) - see [Wiring a form](/docs/ai-briefing-publishing#wiringaform).

`/lazysite/manager/`
: Manager UI internals.

`/lazysite/cache/` and `/lazysite/logs/`
: Generated cache and log files.

`/lazysite/templates/`
: Registry templates that generate `llms.txt`, `sitemap.xml`, and feeds.

### What is walled off from the connector

The connector deliberately cannot reach operator-only surfaces. Attempts return a
machine-readable `kind`:

- `lazysite/forms/*.conf` and other config - `blocked-config` (use the handler
  tools below - `save_handler`, `bind_form`, `save_schedule` - rather than the
  files; SMTP credentials are operator-only).
- `lazysite/auth/*`, `.pl` scripts, the manager - `blocked`.
- User administration, secrets, credential minting - not exposed at all.

## Tools

37 tools. **Reads** are not audited (a refused or failed read is, and a tool
that crashes writes one failure row naming the tool - its error stays in the
error log); **writes** are recorded in the audit log as material events and may trigger the AI client's per-call approval. All file tools
need `manage_content` unless noted.

### Identity

whoami
: Partner identity (`user`), `capabilities`, `account`, active layout/theme, the
  full `tools` manifest, and the `auth` block (method + expiry). No capability
  required. Call it first. `capabilities` holds exactly the capability keys, as
  booleans - `ui` among them is manager access. `account` holds what the account
  is rather than what it may do: `groups`, `email`, `display_name`, provenance
  (`created_by`, `created_at`, `managed_by`), token and MFA state, scopes, and
  `interactive_login` (whether it may sign in to the manager at all). The control
  API's `whoami` carries the same two blocks from the same builder (SM821).
  `grant` says where the capabilities come from (your account, at each request)
  and `roles` lists the roles held and any capability `beyond` them; both
  surfaces carry these too.

describe_capabilities
: The full capability map: every capability and what it unlocks (MCP tools,
  control-API actions, WebDAV paths), task recipes for common jobs, the
  engine-owned paths you must not write, and - under `holds` - what THIS account
  currently has. No capability required. The task recipes are the sanctioned
  sequences: follow them (e.g. `switch-layout`, `restore-from-history`) rather
  than improvising an order.

### Reading and inspecting (reads - not audited)

list_files `{ path }`
: Files and folders under a directory (default `/`) with size, mtime, ext
  and generated. Brief presence left the listing with SM245 - ask `list_briefs`.

read_file `{ path }`
: A text file's contents. Refuses binary (`kind: binary`) and files over 512 KB
  (`kind: too-large`).

read_page `{ path }`
: A page as structured data - parsed front matter, Markdown body, has_brief,
  public_url. A page that is not valid UTF-8 is refused (`kind:
  page-encoding-refused`) with the first invalid byte's offset and how to fix it;
  read_file, preview_page, preview_public_page, validate_page, view_version,
  read_brief and create_form answer the same.

list_pages
: Every page with title, registries (sitemap/llms/feed) and public URL. Walks at
  most 1,000 pages: `truncated` says whether it stopped there, with `page_cap`.

page_status `{ path }`
: Whether the source exists + last-modified, whether the render is pending (cache
  dropped after an edit, re-renders next visit), and the public URL. A page whose
  front matter says `camera: self` also reports `camera` and `camera_note`
  ("camera allowed on this page", https only), and a page that asks for any
  browser feature (`geolocation: self`, `camera: self`) reports `permissions`,
  the features it allows, and `permissions_note`. Confirm an
  edit will reach visitors without a web fetch.

search_files `{ query, path }`
: Case-insensitive content grep across text files, returning path + line snippets.
  Excludes the lazysite/ infra; file- and match-capped.

preview_page `{ path, content }`
: Render a page server-side, fresh (no cache), and return its HTML + status -
  in-channel verification of layout / nav / form output. Public view; a protected
  page shows the auth gate. With `content`, renders that DRAFT at `path` instead
  of the saved page - against the layout, theme, navigation and access rules of
  the site that owns the path - and writes nothing: no file, no cache, no content
  history. The answer carries `draft: true`. A draft is refused for anything a
  save of it at that path would be refused for (`page-encoding-refused`,
  `form-bind-refused`, `template-parse-refused`, `raw-content-refused`, the
  path's write rules) and over 512 KiB (`kind: too-large`); `path` is required.

validate_page `{ path | content }`
: Pre-publish checks: unterminated front matter, missing title, invalid form-field
  rules, and a **public-data warning** (Wi-Fi passwords, postcodes/addresses, phone
  numbers).

audit_site
: Whole-site audit: broken internal links, orphan pages, missing titles, stale
  generated HTML, duplicate content blocks. Walks at most 1,000 pages: `truncated`
  says whether it stopped there, with `page_cap`.

analyse_visitors `{ window }`
: Sanitised visitor-log analysis for trend reporting (needs the `analytics`
  capability). Returns per-day totals, a people/AI-assistant/bot/noise breakdown,
  top pages, referrers, status codes, and a capped recent event stream over the
  last `window` days (1-365, default 30). Never the raw log, any filesystem path,
  or a visitor IP. Read `/docs/ai-briefing-stats` for how to interpret it and what
  may/may not be reported.

get_permissions `{ path }`
: The ACL for a path (owner + read/write grants) - call before `set_permissions`.
  For a page, asked by its path or its stem (`/about` for `about.md`), it answers
  the rule that governs the page, and `key` names the key that holds it (`keys`
  lists both when the page and its stem each hold part of it).

list_handlers
: The delivery handlers - the named functions a form or the schedule calls - with
  each one's type, settings, whether it is on, the capability that governs it
  (`cap`) and what uses it (`used_by`); plus every form's handler list (`forms`)
  and the fields each type takes (`types`). Opens for `manage_forms`,
  `manage_data` or `manage_connectors`.

save_handler `{ id, type, name, ... }` / delete_handler `{ id }`
: Create, replace or delete a handler. **The destination decides**: a `table`
  handler needs `manage_data`, a `connector` handler `manage_connectors`, `smtp`
  and `file` need `manage_forms`; a refusal names the capability that would
  work. A handler still used by a form or schedule entry is not deleted - the
  answer names them. There is no webhook type: outbound HTTP is a connector.

read_notify_outbox `{ rule?, id? }`
: The notification outbox: events notify rules queued and not yet sent
  (queued, or retrying with the last error), messages held back by a rule's
  per-recipient cap, and those given up (failed, with the reason), plus
  `waiting` when the daemon's `notify-outbox` job is not taking them. With
  `id`, one event and who it resolves to, with what was decided for each. It
  shows recipients, so it needs `manage_notifications`; a grant confined to
  some domains sees only their rules.

retry_notify_outbox `{ rule?, id? }`
: Retry now: make the events a notify rule has waiting (in backoff for minutes
  after a transport failure), or one event by `id`, due at once - to test a mail
  fix without posting fresh events. It only ends the wait: the outbox job still
  sends them on its next run, so the per-recipient cap and a held message still
  apply, an event already sent is not sent again, and one given up stays given
  up. Needs `manage_notifications`.

list_schedule / save_schedule `{ id, handler, every, payload }` / delete_schedule `{ id }`
: What the timer calls: a handler, every so many seconds (300 or more), with
  fixed fields. Same capability rule as the handler it calls.

read_nav
: The site navigation as a structured list (items + children) plus the raw
  nav.conf. Read before set_nav. Needs no capability beyond MCP access - the
  nav is public - and reads only the domains your grant reaches; omit `host`
  for the primary site. A nav.conf that is not valid UTF-8 is refused (`kind:
  page-encoding-refused`), naming the file, the first invalid byte's offset and
  how to fix it.

list_themes
: The themes installed across all layouts, with which is active. Needs
  `manage_themes`. A snapshot kept when a layout or theme was switched or
  deleted (`<name>-backup-<stamp>`) is not a layout or a theme: it is listed
  under `backups` (`artifact`, `layout`, `name`, `path`) and never under `themes`.

list_layout_catalogue
: The layouts available in the configured layouts repo (name, version, default
  theme, themes), annotated with what is already installed - discover what
  `install_layout` can pull without downloading anything. Needs `manage_layouts`.

### Version history (needs the site's Content history extension)

When the operator has enabled the **Content history** extension, every save
(manager, WebDAV, or this connector) is recorded as a version, and these tools
let you inspect and undo content changes. If `list_versions` returns
`enabled: false`, versions are not being recorded - ask the operator to enable
the extension; do not try to build your own history. All three need
`manage_content`.

list_versions `{ path, limit }`
: A file's recorded versions, newest first: version id, author, date, message.
  Not audited (a read).

view_version `{ path, version }`
: One version's full content plus a unified diff against the current file.
  Not audited (a read).

restore_version `{ path, version }`
: Restore the file to that version. The historic content is written back
  through the normal save path (page cache refreshed) and the restore itself
  becomes the newest recorded version - nothing is lost by restoring. Audited.
  A version that is not valid UTF-8 is refused (`kind: page-encoding-refused`,
  with the offset) and the file is left as it is.

### Copy, change, publish a page (SM1354)

Prepare a change to a live page on a private copy, look at it, then put it over the
page in one move. Content history is the way back.

copy_page `{ path }`
: Take a copy of a page. It is written at `lazysite/copies/pages/<page path>` (the
  answer names it as `copy`). Change it with `write_file` or `replace_text` at that
  path; see it with `preview_page` at that path. Only those who may change the page
  read or write its copy; it has no public address and is in no navigation, search,
  sitemap, cache or content history. One open copy per page: a second is refused as
  `copy-open`, naming the first. Needs `manage_content`.

publish_copy `{ path, via }`
: Put the page's open copy over the page as one recorded version naming you, this
  connector as where the change came from, `via` when given (a lower-case word, such
  as `wizard`) and who prepared the copy. Refused as `stale-copy`, nothing written,
  when the page changed after the copy was taken; the answer carries both versions
  (`taken_from`, `current`). The answer's `undo.version` is the version before the
  publish: `restore_version` with it puts the page back. Needs `publish_copies`
  (off by default; no shipped role holds it, the site grants it) and
  `manage_content`. Without `publish_copies`, ask a person to publish the copy in
  the manager.

discard_copy `{ path }`
: Throw the page's open copy away. The page and its content history are untouched.
  Needs `manage_content`.

A copy cannot be moved, deleted, uploaded over or made by `copy_file`: each is
refused naming the tool to use. A save to the copies folder with no open copy is
refused as `no-copy`.

### Data rows: switches, history and wizards (SM1355; needs the data extension)

All need `manage_data`. Every row write through `save_data_row`,
`delete_data_row` and these tools is recorded as one change, and the answer
names it as `change`. See [Data tables](/docs/data-tables) for the descriptor and
wizard formats.

switch_row `{ table, key, available }`
: Turn one row on or off by the table's declared `availability` field. Immediate,
  one recorded change; `unchanged` when the row was already in that state. Refused
  as `no_availability` on a table that declares none.

list_row_changes `{ table, key, limit }`
: The recorded changes, newest first: id, when, who, from where, what, the row
  before and after, and `undoable`. The answer names the table's
  `row_history_days` (default 90); older changes are removed on the next write.
  Not audited (a read).

undo_row_change `{ table, change }`
: Put the row back as it was before that change; itself a recorded change.
  Refused as `stale-change` when the row changed since, `already-undone`, and
  `expired-change` past the table's history period.

list_wizards `{}`
: The site's wizards, each with its table and number of steps.

run_wizard `{ wizard, key, answers, save }`
: One step at a time: the next `question`, or `complete` with the row. Ask the
  person each question; a required one cannot be skipped (`kind: required`).
  `save: true` writes the row (with `key`, an update of that row).

save_wizard `{ wizard, definition }`
: Store a wizard's YAML, checked against its table first.

refresh_data_table `{ table }`
: Refresh a table whose descriptor names a `source:` connector now (SM1364): the
  schedule entry's call, made as you, so the connector's callers decide. A failed
  refresh changes nothing and says why; the answer's `source` says how old the
  rows are. The mapped columns are read-only on every tool - see
  [Data tables](/docs/data-tables).

Remote sync of the history (push/pull to a git host) is **operator-only** by
design - it is configured and driven from the manager UI (Remote sync extension)
and is not exposed over the connector or the control API.

### Writing and editing (writes - audited)

write_file `{ path, content }`
: Create or overwrite a text file. Returns `created` (1 new / 0 overwrite) and runs
  `validate_page` on the content, returning any `warnings`/`issues`. Audited as
  `create` or `edit`.

create_page `{ slug, title, subtitle, body, register }`
: Create a new page from front-matter fields + body; errors if it already exists.

delete_page `{ slug }`
: Delete a page - its brief store entry goes with it - and report
  `still_referenced_in` (nav, other pages) for cleanup; generated indexes
  refresh automatically.

rename_page `{ old, new, update_links }`
: Rename / move a page (carries its brief store entry + ACL); with `update_links`, rewrites
  internal links to the old path across pages (nav.conf is not rewritten) - at most
  1,000 pages, and `truncated` with `page_cap` says when it stopped there.

replace_text `{ path, old, new }`
: Replace exact text without rewriting the whole file - safer for a small change.
  Errors if `old` is absent (no silent clobber); reports the replacement count.

copy_file `{ from, to }`
: Copy a text file to a new path (templating). Refuses a destination that already exists; use write_file to replace a file. Destination starts with a fresh ACL.

move_file `{ from, to }`
: Rename / move a file; carries its brief store entry and re-keys its ACL.

delete_file `{ path }`
: Delete a file. Audited as `delete`.

set_permissions `{ path, read, write, draft }`
: Set the per-file ACL - owner plus comma-separated read/write lists (users or
  `@groups`), and the draft flag. **A partial update: omitted fields keep their
  current value.** Setting a read list on a draft section leaves it draft -
  still a 404 - so the API equivalent of the Publish button is
  `{"draft": false}` alongside your grants. A field agent replicated the UI
  flow, granted access, and the section kept 404ing; least surprise says the
  trap gets named where the tool is learned.

remove_permissions `{ path }`
: Remove the rule on a path (a file, a folder prefix ending in `/`, or `/` for the
  site-wide rule) - owner, lists, draft flag and address profiles together. Only the
  rule's owner (or an operator) may. Removing a draft or read rule publishes what it
  held back. Audited as `acl-remove`. Use `set_permissions` to change a rule.

bind_form `{ form, handler }` or `{ form, handlers: [...] }`
: Wire a form to delivery by naming existing handlers from `list_handlers`.
  Needs `manage_forms` only - and nothing but handler ids: to deliver
  somewhere new, create the handler first.

set_nav `{ items }`
: Replace the site navigation - `items` is an ordered list of `{ label, url }`
  (a `children` list becomes a sub-menu; an item with no url is a section header).
  Writes nav.conf and rebuilds the cache. Needs `manage_nav`.

### Site operations

activate_theme `{ theme }`
: Activate a theme for the current layout (clears the HTML cache).
  Needs `manage_themes`.

activate_layout `{ layout, theme }`
: Activate a layout, optionally naming a compatible theme. Needs `manage_layouts`.

install_layout `{ layout, theme, all, update, activate }`
: Install a layout and its theme(s) from the configured repo and activate it
  (default). Needs `manage_layouts`. **To switch the site to a different
  layout, this one call is the whole switch** - it installs AND activates.
  Only delete the old layout afterwards, if at all. Use
  `list_layout_catalogue` first to see names.

delete_layout `{ layout }`
: Delete an installed layout and its themes. **The ACTIVE layout is always
  refused** - when switching, install/activate the replacement first, then
  delete the old one. Never delete first: the right order is
  `list_layout_catalogue` -> `install_layout` -> (optionally) `delete_layout`.
  A recovery snapshot is kept. Needs `manage_layouts`.

submit_feedback `{ summary, good, bad, rating, context }`
: Report what worked and what got in the way while building through the
  connector - this is how the operators improve the tools. Use it freely; your
  identity and context are recorded automatically. No capability required.

invalidate_cache `{ path }`
: Drop a page's cached HTML so it re-renders (`"*"` for all). A normal write
  already clears its own page; use this for pages that embed another.

### Site migration (move a whole site between domains or instances)

A **site package** is a portable snapshot of ONE domain's site: its content, its
navigation, the theme and layout it uses, and its presentation settings. It
deliberately excludes extensions, instance settings and any secrets, so it is safe
to hand to another instance. Use it to turn an agency demo into a client's live
site, or to copy a site to another domain. Both tools need `manage_domains` and
access to the domain.

site_backup `{ host }`
: Package the named configured domain's site into
  `lazysite-site-<host>-<stamp>.tar.gz` in the backups area (fetch it with the
  backup download if you need to move it to another instance). Returns the
  package `name`.

site_apply `{ name, host, clean }`
: Apply a package (already in this instance's backups area) onto a target: copies
  its content into the target domain's content root, installs the bundled
  theme/layout if the target lacks it, places the nav, and sets the domain's
  presentation. Omit `host` to apply to the default site; `clean: true` clears
  the target content first. **Apply overwrites the target - take a backup first
  if you want a rollback point.** The target domain must already be registered
  (`domain-add` on the control API) unless you are applying to the default site.

The end-to-end recipe (`migrate-site`) is in `describe_capabilities` under
`tasks`: **site_backup on the source -> (download + site-backup-upload if a
different instance) -> site_apply on the target -> verify.**

## Error model

A failed tool result is `{ ok: 0, error, kind }`. The `kind` lets an agent tell
causes apart: `blocked`, `blocked-config`, `not-found`, `permission`, `binary`,
`too-large`, `invalid-path`. A 401 carries `error.data.reason` -
`sign-in-incomplete` (no credential reached the server - re-authorise the
connector) vs `credential-invalid` (expired/revoked - reconnect).

**Over the control API** (`/cgi-bin/lazysite-manager-api.pl`) the same refusal
also answers with an HTTP status taken from its `kind` (SM670): `forbidden`,
`permission`, `blocked`, `disabled` 403; `not-found` 404 (an unknown action too);
`exists`, `in-use`, `confirm` 409; `too-large` 413; `rate` 429; a failure on the
server 500; `partial` - part of the write happened - 207; `cannot-tell` 503; `unauthenticated` (no sign-in at all) 401, with no
`WWW-Authenticate` header because the session is a cookie and not an HTTP scheme;
`not-set-up` (the site has no manager account yet) 503; anything else, and a refusal with no kind, 400. The body keeps `ok: false` either
way, so a client may key on either. MCP tool results are JSON-RPC and stay 200.

**`cannot-tell` is not a refusal of your account.** It means an auth store the
engine needs to answer "what may this account do" exists and the web server
cannot read it - a file permission fault on the host. Your credential verified;
nothing was decided about your grants, so do not ask for one. The body names the
store (`store`, a docroot-relative path such as
`lazysite/auth/groups-settings.json`) and the repair (`repair`: `lazysite check
--docroot <docroot> --fix`, run by the operator). Every call answers this until
the store is readable, `whoami` included, rather than reporting an empty grant.
Over MCP the same answer is JSON-RPC error `-32003` with HTTP 503 and `kind`,
`store` and `repair` in `error.data`.

**When the account store itself cannot be read**, the engine cannot check your
credential at all, so it has not verified you: you get `cannot-tell` 503 with
no `store` and no `repair`, and a message saying it is not a verdict on your
credential. Do not reissue the credential; the operator's log names the cause.

## A reliable edit loop

1. `whoami` - confirm identity, capabilities, and that tools are loaded.
2. `list_files` / `list_pages` / `read_page` - orient; read before you edit.
3. `validate_page` (with `content`) - catch front-matter / form / public-data
   issues before writing.
4. `preview_page` with `content` - see the draft rendered in the site's own layout
   and theme before anything is saved.
5. `write_file` or `replace_text` - make one change at a time.
6. `preview_page` - confirm the render in-channel (not a web fetch). `page_status`
   confirms it will reach visitors.
7. `audit_site` after a set of changes - catch broken links / orphans / duplicates.

Pages are Markdown files served at their path (`about.md` → `/about`); a page that
registers in a feed lists it in front matter (`register: [sitemap, llms]`).
