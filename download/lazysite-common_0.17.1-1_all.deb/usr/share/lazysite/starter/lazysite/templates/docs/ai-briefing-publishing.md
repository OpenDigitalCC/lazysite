---
title: AI briefing - publishing
subtitle: Guide for an automated partner publishing to a lazysite site over WebDAV and the control API.
register:
  - sitemap.xml
---

## Who this is for

This briefs an automated publishing partner - an AI agent that holds write
access to the docroot over WebDAV. It covers the onboarding brief, the path
mapping, the WebDAV operations, the control API actions, briefs, ownership and
cache behaviour. How you connect and authenticate, the endpoints and what your
grant reaches are in the
[AI connector - tools reference](/docs/ai-connector-tools) (see
[below](#connectingauthenticatingandwhatyourgrantreaches)).

For content rules (front matter, Markdown, URLs) see
[AI briefing - content authoring](/docs/ai-briefing-authoring). For layouts and
themes see [AI briefing - layouts](/docs/ai-briefing-layouts). For configuration
see [AI briefing - configuration](/docs/ai-briefing-configuration). For analysing
visitor traffic (with the `analytics` permission) see
[AI briefing - visitor analytics](/docs/ai-briefing-stats). For keys,
variables, and file locations see [Reference](/docs/reference).

## How onboarding works

You are given one document out of band: an **onboarding brief**. Everything
else is discoverable from it. The brief carries a machine-readable block
(under a `## Machine-readable` heading) - parse your identity, scope, and
endpoints from that block, not from prose. A partner-agnostic copy is published
at `/.well-known/ai-partner`.

The brief *describes* the grant; the token *is* the grant; the server
*enforces* it. Treat the scope in the brief as advisory about what to attempt;
the server is authoritative and rejects anything outside it. If an in-scope
write returns `403`, the grant - not the documentation - is right.

## First: confirm you can reach the site

Before authenticating, do one cheap unauthenticated request - `GET
https://SITE/.well-known/ai-partner` (it also returns your machine-readable
bootstrap). This proves your environment can egress to the host.

- JSON came back: you are connected - proceed.
- The request was blocked **before reaching the site** - no network, or a proxy
  `403` whose body names an allowlist (`host_not_allowed`, "add this host to your
  egress settings"): **stop and report that immediately.** The block is on your
  side; the host must be added to your network egress allowlist. Do not retry
  blindly, and do not conclude the site is down - you have not reached it yet.
  Note that a pairing key denied at your proxy is **not** consumed (it never
  reached the origin), so it is still live - say so in your report.
- A response that reached the origin but is not the expected JSON (a wrong-host
  page, DNS failure, timeout) is a wrong address, not an egress block.

Report which of these you got before going further, so a human can act on the
right thing.

## Connecting, authenticating and what your grant reaches

Connecting and authenticating have one home,
[Connect an AI assistant](/docs/ai-connector-setup), and what your grant reaches
has one, the [AI connector - tools reference](/docs/ai-connector-tools). Both
hold for WebDAV and the control API as much as for MCP. Read them before your
first authenticated request:

- [Endpoints](/docs/ai-connector-setup#endpoints) - WebDAV, exchange and
  rotate, the control API, MCP.
- [Connection modes](/docs/ai-connector-setup#connectionmodes) - API mode or
  MCP mode, and which to use by client.
- [Authentication](/docs/ai-connector-setup#authentication) - exchanging the
  pairing key, presenting the token as Basic auth, rotating it, recovering
  from a `401`, and checking your access and your grant.
- [Capabilities](/docs/ai-connector-tools#capabilities) and
  [Scope and denied paths](/docs/ai-connector-tools#scopeanddeniedpaths) -
  what your grant reaches and the paths no grant writes.

## Control API actions

Issue these to the control-API endpoint (`/cgi-bin/lazysite-manager-api.pl`)
with your access token as HTTP Basic auth, the same as WebDAV. Each is a
`?action=<name>` query; parameters are passed in the query string unless noted
as a JSON body, and a token client's POSTs need no CSRF token.

**Before planning a sequence of calls, read `describe_capabilities`.** It is the
authoritative list of what *this* account can call on *this* channel, and it is
narrower than the list below: some actions are served only to the manager UI over
a cookie session, so a token or MCP client cannot reach them at all. Planning
against the full action list and discovering the subset by being refused is a
trial-and-error loop that one lookup replaces.

### Reading a page as Markdown

Append `.md` to any page URL and you get the page's **Markdown source** rather
than its rendered HTML, served as `text/markdown`. This is what the links in
`llms.txt` point at, so following that registry gives you the prose without
having to parse a rendering.

The same access rules apply, because it is the same request path: a page behind
`auth: required` answers a `.md` request the way it answers any other - with a
redirect to the sign-in, not with its source. There is no separate permission to
grant or revoke.

**The front matter is not the file's.** Three keys travel - `title`, `subtitle`
and `description` - and they are the three the rendering already publishes, so
the Markdown discloses nothing the HTML did not. Everything else is withheld,
including `auth`, `auth_groups`, `query_params`, `tt_page_var`, `form` and
`api`: a page's configuration is not its content. Do not read a `.md` response
to discover how a page is configured - use `read_page`, which answers that
question and is gated for it.

Only a single `.md` is a source request. `page.md.md` is a probe, not a link,
and gets the rendering.

### Refreshing the generated registries

`?action=regenerate-registries` clears `sitemap.xml`, `llms.txt`, `robots.txt`
and the feeds so they rebuild from current content. Use it after deleting or
renaming a page **when you want to verify the result**: the delete takes effect
immediately but a registry is rebuilt lazily, so reading the sitemap straight
afterwards can still show the old URL and look like the delete failed.

::: widebox
**Do not delete a generated registry file to force a refresh.** It is not a
cache invalidation - it is an outage that ordinary traffic will not necessarily
clear. A registry is rebuilt during page *processing*, when its output is
missing or stale. Requesting `sitemap.xml` does not run the processor, and a
request for a cached page is not a render - so on a settled site with a warm
cache and no editing, nothing notices the file is gone and it can stay 404
indefinitely. This has happened on a live site: `sitemap.xml` was down for about
a minute and `llms.txt` for longer.
:::

Some list-shaped responses are worth knowing before you read one: **a list
response names its contents**, so `list_versions` returns `versions`,
`list_domains` returns `domains`, `form-list` returns `forms`. If you read the
wrong key you get an empty result, which looks exactly like a working call that
found nothing - so check the key before concluding a feature is broken.

`whoami` (GET)
: No parameters. Returns your partner identity, capabilities, groups, effective
  scope, and the extensions/layouts/themes the site offers - confirm your grant
  from the server rather than the brief alone.

`theme-activate` / `layout-activate` (POST)
: `path=<name>` - the theme or layout to make active (an empty `path`
  deactivates). Sets `theme:`/`layout:` in `lazysite.conf` and clears the
  affected cache in one step. Needs `manage_themes` / `manage_layouts`.

`cache-invalidate` (POST)
: `path=<dir-or-page>` - clear generated HTML under that path (use `/` for the
  whole site). Deletes only generated cache (`<page>.html` with a `.md`/`.url`
  source), never your author `.html` partials.

`acl-set` (POST)
: `path=<file>` in the query, plus a JSON body `{ "read": [...], "write": [...] }`
  (only the CLI, as `local`, may also pass `"owner"`). The first `acl-set` on a
  file you can write records you as owner. Needs `webdav`. See *Own your pages*.
  To give many files the same rule, send `"paths": [...]` in the body instead
  of `path` (SM1052): every path is checked first and none is written if any is
  refused; the trail records one row per path.

`accounts-import-stage` (POST)
: Prepare accounts for the operator to create (SM1053): a JSON body
  `{ "accounts": [ { "username": "...", "email": "...", "groups": [...] } ] }`, or
  `{ "csv": "username,email,groups\n..." }` with groups separated by `;`. Never a
  password - a row carrying one refuses the file. Nothing is created: the
  operator reviews a dry run on the manager's Account import page and applies
  it, and each person sets their own password from a claim link, which the
  operator may choose to have mailed to the address the row carries. Groups
  that do not exist are left out. A row for an account that already exists
  proposes changes to its address and groups (a row's `groups` is the set it
  should have; a row without `groups` changes none): the operator ticks the ones
  to make. A new account too joins only groups that exist and are neither an
  operator nor a registration group. Never a password, or an operator's own
  account. Needs `manage_users`. Over MCP the same staging is
  `stage_accounts`; the review stays in the manager.

`accounts-import-remove` (POST)
: `{ "id": "..." }` removes a staged import (SM1053): the account that staged
  it, or the operator. Accounts an applied import created stay. Needs
  `manage_users`.

`acl-get` (GET) / `acl-remove` (POST)
: `path=<file>`. `acl-get` returns the entry; `acl-remove` clears it
  (owner-only; a holder of `manage_users` is no exception - only the CLI as
  `local` and a member of the operator group are). Needs `webdav`.
  `acl-remove` refuses a call with no path or an empty one: the site-wide rule is
  removed with `path=/`.

A file that arrives in a folder whose rule holds content back (a read list, or
`draft`) lands in the private store however it arrives - `save`, `move`, `copy`,
`file-upload`, MCP `move_file` / `copy_file` / `upload_file`, WebDAV `PUT` /
`MOVE` / `COPY` - and stays there if its own rule changes (SM981). Taking a post
down by moving it into a draft folder is safe. A folder found in both trees is
repaired by `lazysite acl reapply --apply`, which keeps the private copy of
anything both hold and moves the public one aside to `lazysite/displaced/`.

`config-set` (POST)
: `key=<name>` and `value=<…>` (query string or JSON body). Sets one
  allowlisted site-config key in `lazysite.conf` - currently `site_name`,
  `site_url`, `search_default`. Privilege-relevant keys (manager groups,
  extensions, auth) and ones with their own action (layout/theme - use
  `layout-activate`/`theme-activate`) are refused. Needs `manage_config`.

## Path mapping

The WebDAV root maps one to one onto the docroot. You address the source `.md`
file, not the published URL. The `page_source` value (see
[Reference](/docs/reference)) is exactly the WebDAV path for a page.

```
Published URL        Source file (WebDAV path under /dav/)
/                    /index.md
/about               /about.md
/docs/install        /docs/install.md
/docs/               /docs/index.md
```

Published URLs are extensionless on the read side; on the write side you always
address the `.md` (or `.url`) file.

## WebDAV operations

`PROPFIND`
: Inspect a collection or check a resource exists before writing.

`GET`
: Read the current source file before editing.

`PUT`
: Create or overwrite a source file.

`MKCOL`
: Create a collection. WebDAV does not create intermediate collections -
  create parents first, top down.

`DELETE`, `MOVE`, `COPY`
: Remove, rename, or duplicate resources within scope.

## If `/dav` does not respond

Read the status before concluding the path is wrong - each one is a specific
gate, not a missing endpoint:

`404` on every method (including `OPTIONS`)
: WebDAV is **disabled site-wide** - not a wrong path. The endpoint returns
  404 by design until the operator enables it (manager Config → *WebDAV
  publishing*, or `webdav_enabled: yes` in `lazysite.conf`). Ask the operator
  to enable it; the path is correct.

`403 "WebDAV not enabled for this account"`
: The site is on, but your account lacks WebDAV. Ask the operator to enable
  WebDAV on your Users-page card.

`403 "HTTPS required"`
: WebDAV refuses Basic auth over plaintext - use `https://`.

`401`
: Normal when unauthenticated - retry with your token as HTTP Basic auth
  (username = your partner id, password = the `lzs_` token).

## Document your intent: briefs

Every file you author should carry a **brief** - the record of *why* the
file exists and *what* each edit changed, so the next agent (or the
operator) understands intent before touching it. A brief is **not a
sidecar file**: it lives out of band in an engine-owned store, keyed by
the content path it describes. Briefs are private at every layer - never
served, never in `sitemap.xml` or `llms.txt` - and readable only through
the tools below and the operator's manager.

**A brief may describe any content object, not only a page.** The key is a
content path, so a folder, an asset, a layout, a theme, the nav, or the site
root can each carry one. This already works and was simply never written
down, so agents recorded intent for pages and had nowhere to put it for
everything else. A data ROW cannot carry one yet - it has no path - which is
recorded as SM657.

How to work with briefs:

- **Over MCP**: `read_brief { path }` and `append_brief { path, entry }`.
- **Over the control API**: `brief-read` and `brief-append` (an explicit
  `path` is always required). `briefs-list` shows every entry - with an
  `orphan` flag for briefs whose content path no longer answers - and
  `brief-delete` clears one, so you can clean up anything you orphan.
- **Never write a `<file>.brief` file.** On a site where the briefs
  extension is enabled, that write is **refused on every channel**, and the
  refusal names the replacement. On a site not yet migrated a sidecar
  still writes, but the store is the standard: the operator imports
  existing sidecars from the Extensions page's *Migrate sidecars*, and
  the engine carries store entries through renames and deletes for you.

A brief is **append-only**: the store stamps every entry with the date
and your identity, so the history builds itself. Your *first* append for
a file should capture the spec:

- **Purpose** - the page's goal and who it is for.
- **Sections, in order** - what is on the page and why each part is there.
- **Tone & style** - voice and language conventions (e.g. British English,
  no em-dashes, warm but honest).
- **Images & sources** - which images are used, and which source document
  the content came from.
- **Constraints** - anything that must hold: "genuine quotes only, never
  invent", photo-permission rules, a required credit, or a dependency
  (e.g. "the enquiry form needs `forms/enquire.conf`").
- **To change this page…** - concrete examples of edits an owner might
  ask for, so they know what they can change.

Later appends are log lines - what changed and why, one entry per
substantive edit.

A brief can describe **any path the site holds** - a folder (`/docs`), an
asset (`/favicon.ico`), a theme stylesheet, even the site root - not only
Markdown pages. Brief-first authoring is welcome: appending to a path
that does not exist yet records intent for the file you are about to
create.

**The brief is a two-way spec, not just a record.** Backfill one for
every page you maintain, based on what the page currently is. The owner
reads and appends through the manager's Brief affordance; when an
appended entry asks for a change, refactor the page to match it and
append what you did. The brief is the source of intent; the page is its
current rendering.

## Own your pages: ACLs

On a shared scope where several authors write, you can **own** a file so others
cannot overwrite it. Ownership and permissions are *not* files in the content
tree - they live in a central store and are set through the control API:

```
POST .../lazysite-manager-api.pl?action=acl-set&path=/content/about.md
{ "write": ["your-partner-id"], "read": ["your-partner-id"] }
```

- The first `acl-set` on a file you can write records **you** as its `owner`.
- `write` - an allowlist; if present, only the owner and these users may
  `PUT`/`DELETE`/`MOVE` the file. Omit to leave writes open (scope still
  applies).
- `read` - an allowlist for `GET` over WebDAV. Omit to leave reads open. (This
  governs WebDAV/manager access only - the public still sees the rendered
  page.)

`acl-get` returns the current entry; `acl-remove` clears it (owner only - so no
one can take over a file you own). Without an entry, access is just your
account's scope, exactly as before. Usernames only for now (no groups).

## Cache behaviour

The processor serves a cached `.html` only when it is newer than its `.md`
source, and regenerates when the cache is missing or stale.

Content edits self-invalidate
: A `PUT` updates the source's mtime, so the page regenerates on its next
  request. No separate cache action for ordinary content.

Protected pages are never cached
: Pages with `auth:` or `payment:` render per request.

Structural changes need a cache clear
: Editing `nav.conf`, activating a theme/layout, or changing a config key does
  not retro-invalidate pages whose cache is already warm. For content scope,
  re-PUT the affected pages (a content PUT self-invalidates). For
  theme/layout/config, clear the cache via the control API (`cache-invalidate`)
  or ask the operator.

## Themes and layouts have their own gates

Theme files need `manage_themes` and layout structure `manage_layouts`, and the
**active** layout and theme are read-only on every surface, so a re-skin is
staged beside them, previewed, then activated - or handed off to the operator.
The steps are in [AI briefing - layouts and themes](/docs/ai-briefing-layouts):
[Staging a layout over WebDAV](/docs/ai-briefing-layouts#stagingalayoutoverwebdav)
and
[The active theme is read-only](/docs/ai-briefing-layouts#theactivethemeisread-only.whereathemelives.).

## Verify your publish

A `2xx` is not proof the page is right. After publishing, confirm:

- **Fetch the page** and expect `200`.
- **No leaked Template Toolkit** - the body must contain no literal `[%` … `%]`.
- **The nav reflects `nav.conf`** on every affected page (re-PUT any still
  showing the old nav).
- For a **form** page, `GET` the form's action URL and expect anything but
  `404`; the receiver is a server CGI (`/cgi-bin/form-handler.pl`) the operator
  installs - if it `404`s, report it rather than trying to fix it.

## When a write fails, read the status

Three different things can stop a write, and they call for three different
responses. Do not probe to tell them apart - the status says which.

`403`
: The path is denied to your grant. Stop asking; this will not succeed on retry
  and it is not a fault. If you believe it should be in scope, report it.

`507`
: The server cannot currently store it - a directory is not writable by the
  server. This is an operator's problem, not yours and not your request's.
  Report it with the response body and do not retry in a loop.

`500`
: Something unexpected broke. Worth reporting.

A `507` in particular is not a permission decision. Reading it as one, and
telling the operator that writes to a path are denied by policy, sends them
looking in the wrong place.

All five write verbs answer this way - `PUT`, `DELETE`, `MKCOL`, `MOVE` and
`COPY` - so the same reading works whatever you were doing. The body names
**which** directory, which matters for `MOVE`: it writes two of them, and a
`MOVE` can fail because the *source* directory is unwritable while the
destination is fine. Pass the body along verbatim; it says `source` or
`destination` and the operator needs that to know where to look.

`MKCOL` has one more distinction worth reading. A `409` means the parent
collection does not exist - that one **is** yours to fix, by creating the
parent first. A `507` from the same request means the parent exists and the
server cannot write into it.

## Do not design a browser-origin integration

The control API is not callable from a page. It sends no CORS headers and
refuses a preflight explicitly, because it serves callers that hold
operator-issued credentials and a browser cannot hold one safely.

If you are designing something where a page talks to the site, the answer is a
form POST for anything the visitor sends, a static file for the page itself, and
a credentialled component - you, over MCP or this API - for the privileged work.
See [API and raw mode](/docs/api) for the reasoning and the alternatives.

## Submissions announce themselves - do not poll

When a form is submitted, the site raises a notification of its own accord: into
the manager's notification bell, and - where the operator has configured the
`notify-xmpp` extension - as a chat message to them. It names the form and the time
and carries none of the submitted content.

So there is no need to build a polling loop to discover that a questionnaire has
been completed, and no need to ask the operator for a webhook. If a workflow
needs to react when material arrives, the notification is the trigger that
already exists; ask the operator to point it wherever the reacting component
listens.

To read what was submitted, use `read_form_submissions` (MCP) or
`form-submissions` (control API), both under the least-privilege
`read_submissions` capability. See [Forms](/docs/forms).

## Tasks

### Connecting

1. Parse the machine-readable block from the onboarding brief.
2. `POST` the pairing key to the exchange endpoint; store the token + expiry
   (see [Authentication](/docs/ai-connector-setup#authentication)).
3. `PROPFIND /dav/` to confirm, and `whoami` to read your real grant.
4. Fetch the briefings and [Reference](/docs/reference) for the content,
   layout, and configuration rules.

### Publishing a single page

1. `PROPFIND` or `GET` the target to check current state.
2. Prepare the `.md` with valid front matter (see
   [authoring](/docs/ai-briefing-authoring)).
3. `MKCOL` any missing parent collections, top down.
4. `PUT` to its docroot-relative path under `/dav/`. The page regenerates on
   next request.

### Publishing a whole site

1. `PROPFIND` the tree to learn what exists.
2. `MKCOL` collections parent-first; `PUT` each file (diff against the
   `PROPFIND` and skip unchanged).
3. Verify with `PROPFIND`/`GET` on a sample, per the checklist above.

### Editing navigation

1. `GET` `/dav/lazysite/nav.conf`, edit, `PUT` it back.
2. Re-PUT affected pages (or clear the cache) so the new nav appears on warm
   pages.

### Wiring a form

A `::: form` block named e.g. `enquire` needs a dispatch config to receive
submissions. With `manage_config` you deploy this yourself - no operator step
for file storage:

1. `PUT` `/dav/lazysite/forms/<name>.conf` (matching the form's name), listing
   the handlers it dispatches to:

   ```yaml
   targets:
     - handler: local-storage
   ```

2. `local-storage` ships by default and writes submissions to
   `lazysite/forms/submissions/` - nothing else to set up. A handler that
   does not exist yet is made through the handler actions, not this file:
   an email or file handler with `manage_forms`, a data-table handler with
   `manage_data`, a connector handler with `manage_connectors` (see
   [Forms](/docs/forms)). The SMTP credentials (`smtp.conf`) stay the
   operator's.
3. Submit a test entry and confirm it lands.

You may write only the per-form `<name>.conf`, and only with targets that
name existing handlers; `smtp.conf`, `handlers.conf`, `schedule.conf` and the
`submissions/` store are denied over WebDAV.

### Rotating your token

1. Before `expires_at`, `POST` to rotate with your current token as Basic auth.
2. Replace your stored token + expiry with the response.

## Offline fallback - drop-in bundle

When you cannot reach `/dav/` - no egress, no token, or a locked-down runner -
emit the file set you *would* have published as a single **JSON bundle** the
operator applies. Same content, no network.

```json
{
  "lazysite_bundle": 1,
  "post": ["clear-cache"],
  "files": [
    { "path": "about.md", "content": "---\ntitle: About\n---\nAbout us.\n" },
    { "path": "lazysite/layouts/mysite/layout.tt", "content": "…[% content %]…" }
  ]
}
```

- `path` is **docroot-relative** - the same path you would use under `/dav/`.
- `content` is the full file body (JSON-escaped - no delimiters to collide with).
- Include **only in-scope files** - never the [denied paths](/docs/ai-connector-tools#scopeanddeniedpaths).
- `post` lists post-extract actions; use `"clear-cache"` when the bundle changes
  a theme, layout, `nav.conf`, or config file (content pages self-invalidate).

The operator applies it (auditing first - a manifest, not an auto-run script):

```bash
perl tools/lazysite-bundle-apply.pl --docroot DOCROOT bundle.json          # dry run
perl tools/lazysite-bundle-apply.pl --docroot DOCROOT --apply bundle.json  # write
```

The tool validates every path against the deny list, confines writes to the
docroot, reports create-vs-overwrite per file, and prints the post-extract
commands. The file set is identical to a live publish - only the transport
differs.
