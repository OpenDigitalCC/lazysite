---
title: AI briefing - layouts and themes
subtitle: Guide for AI assistants helping users author or modify a lazysite layout or theme.
register:
  - sitemap.xml
---

## Who this is for

This briefs an AI assistant working on the visual layer of a
lazysite site - the layout template (`layout.tt`) and its
themes. For content, see
[AI briefing - authoring](/docs/ai-briefing-authoring). For
configuration, see
[AI briefing - configuration](/docs/ai-briefing-configuration). For the
content/layout/theme separation this all rests on, see
[AI briefing - building sites](/docs/ai-briefing-building-sites). What a layout
and a theme are, where they live on disk, how the engine resolves them and how a
person installs and switches them is in [Layouts and themes](/docs/layouts); this
page is what an agent needs to change them.

[% IF design_guide %]**This site's design guide:** <a href="[% design_guide | url_safe %]">[% design_guide %]</a> -
how this site's own design is put together. Read it before you change its look.[% END %]

## Terminology (D013)

A **layout** is the `layout.tt` that wraps every page, under
`lazysite/layouts/NAME/`; a **theme** is the colours, fonts, spacing and assets
on top of it, nested at `lazysite/layouts/LAYOUT/themes/THEME/`. The definitions
and an on-disk tree are in [Layouts and themes](/docs/layouts#layoutsandthemes).

**Manager UI**: has its own internal template at
`lazysite/manager/layout.tt`. Outside the layout+theme system.
Do not modify unless explicitly asked.

## Front-matter variables arrive ALREADY ESCAPED - never add `| html`

**`page_title`, `page_subtitle`, `page_meta_title`, `page_meta_desc` and
`page_author` are HTML-escaped before your template sees them.** Applying
`| html` escapes them a second time.

This is deliberate and it is a security decision, not a convenience one
(SEC-2026-07 H5): author-controllable front matter is escaped at the single
point it enters the stash, so **every** layout emits it safely - including
third-party layouts nobody here can edit, and including a layout that forgets to
filter. Escaping at the point of construction is the half that fails safe; the
engine knows where a value came from and a template does not.

The cost of that choice is this rule, and the rule was never written down. So:

<!-- lint-48: counter-example follows. The second line shows the WRONG form, so
     the check that keeps every other example correct skips between these
     markers. -->

```
<meta name="description" content="[% page_meta_desc %]">          correct
<meta name="description" content="[% page_meta_desc | html %]">   double-escaped
```

<!-- lint-48: end counter-example -->

An apostrophe in the second form reaches search engines as `&amp;#39;`, which
renders as the literal text `&#39;`. "a client's brief", "what's included",
"we're hiring" - apostrophes are ordinary in English copy, and a meta
description is exactly where marketing copy goes. It is read by search engines,
social cards and AI clients, and by almost nobody during review, so a site can
serve it mangled for months.

`| html` on these five is always wrong. On any value you construct yourself in
the template, it is right.

## The `<head>` contract

**A layout must render `<title>` from `page_meta_title` and its description from
`page_meta_desc`.** Both are always set, so there is no fallback to write.

An author sets `meta_title` or `meta_desc` in a page's front matter to control
what search engines and social cards show, separately from the heading on the
page. The engine resolves them before your layout runs:

```
page_meta_title  =  meta_title  //  title
page_meta_desc   =  meta_desc   //  subtitle
```

So a page that sets neither behaves exactly as it always has, and a page that
sets either gets what it asked for. You do not need to write the `//` yourself,
and you should not: the resolution order is the engine's to own, and a layout
that reimplements it will drift from the registries, which use the same
resolved values for `sitemap.xml`, `llms.txt` and the feeds.

### Why getting this wrong is silent

The engine injects a description tag **only when the rendered HTML has none**.
That is deliberate - a layout that writes its own `<head>` is trusted to mean
it, and the engine will not fight it. The consequence is that a layout doing
this:

<!-- lint-48: counter-example follows. This block shows what NOT to write; the
     check that keeps the other examples correct skips between these markers. -->

```
<title>[% page_title %]</title>
<meta name="description" content="[% page_subtitle | html %]">
```

<!-- lint-48: end counter-example -->

wins, quietly. The page's `meta_desc` is discarded with no warning, and
`meta_title` is never consulted at all. The site's own `llms.txt` will then
advertise the page with one description while the page serves another, and
nothing reports the disagreement.

This is not hypothetical. It is how every layout in the catalogue was written,
because the example in this briefing showed it that way, and it is why
`meta_title` had no observable effect on any real site for a full release after
it was implemented (SM300, SM308). The example below is now correct; if you are
reading an older layout as a model, check its `<head>` before copying it.

### Deprecated in `<head>`

`page_title` and `page_subtitle` remain correct **in the body** - they are the
heading and standfirst, and that is what they are for. In `<head>` they are the
wrong variables. A layout using them there is not broken today, since the two
resolve identically on a page that sets no meta front matter; it simply ignores
the author whenever they ask for something different.

## TT variables in layout.tt

Always available:

- `content` - rendered HTML page body
- `page_title`, `page_subtitle` - front-matter values
- `page_meta_title`, `page_meta_desc` - **what belongs in `<title>` and
  `<meta name="description">`**. Use these, not `page_title` and
  `page_subtitle`, for the two `<head>` tags. See "The `<head>` contract"
  below - getting this wrong is silent.
- `site_name` - from `lazysite.conf`
- `nav` - array parsed from `nav.conf`
- `request_uri` - current URL path (no query string)
- `page_url` - the page's full address with no query, already escaped: use it
  for `og:url` and the canonical link, as `[% page_url %]`
- `page_url_raw` - the same address, raw, for JSON-LD alone: `[% page_url_raw | json %]`.
  Never in markup (the `_raw` rule above).

Variables an extension gives a layout, present only while that extension is
on and empty otherwise, so a layout may render them on any site:

- `signin_banner` - on a site whose sign-in is an identity provider's (an
  extension that signs people in, such as Odoo's site sign-in), that provider's
  "Signed in as <name>" with a sign-out, in place of the account sign-in and
  sign-out links; empty on any other site. Render it where the account links go:
  `[% IF signin_banner %][% signin_banner %][% ELSE %]...[% END %]`
- `login_options` - the other ways in that /login offers, one per such provider:
  each has `id`, `label` (text: escape it), `path` (a path on this site, which may
  carry a query) and `sep` (`?` or `&`, what joins a `next=` to the path)

- `odoo_signin_banner` (the Odoo extension) - "Signed in as <name>" with a
  sign-out, on a site whose Odoo sign-in is the site sign-in; `odoo_display_name`,
  the name the site gives Odoo (text: escape it)
- `app_offline_kit` (the `app-offline` extension) - the offline kit's script tag,
  for a site installed as an app whose Odoo sign-in is the site sign-in (on any other
  site the kit keeps nothing). Render it once, and carry the kit's slots:
  `data-ls-app-banner` (shown offline), `data-ls-app-show-out` and
  `data-ls-app-show-in` (signed out, signed in) and `data-ls-app-status` (the
  install state and a waiting update). See /docs/app, "The offline kit". No
  layout ships a script: the kit, like the Odoo helper, is the engine's.

D013 additions:

- `layout_name` - resolved layout name (string)
- `theme_name` - resolved theme name when a compatible theme is
  active (string; unset otherwise)
- `theme` - hash, the parsed `theme.json`. Access config values
  as `[% theme.config.colours.primary %]` etc. Empty hash when
  no theme is active.
- `theme_assets` - URL prefix `/lazysite-assets/LAYOUT/THEME`
  (nested for local themes), or `/lazysite-assets/CACHE_KEY` for
  remote layouts (flat), or unset when no theme
- `theme_css` - a **ready-made element**, emitted for you: normally a
  `<link rel="stylesheet" ...>` to the theme's generated
  `theme-tokens.css`, carrying its own fingerprint so the tokens
  invalidate independently of `main.css`. On a site whose theme mirror
  predates that file it falls back to an inline
  `<style>:root { ... }</style>` block of the same custom properties.
  Empty string when no theme. **Do not wrap it** in a `<style>` tag of
  your own - print it as it is, in `<head>`.
- `theme_version` - the cache key for the files under `theme_assets`:
  a fingerprint of the theme's mirrored files, so
  `[% theme_assets %]/main.css?v=[% theme_version %]` is a new URL when
  the theme changes and the same URL when it does not. The engine
  version where the mirror has no fingerprint yet. Always set.

Auth variables:

- `authenticated` - truthy if the request has a valid session
- `auth_user`, `auth_name`, `auth_groups` - user identity
- `manager` - "enabled"/"disabled" from conf
- `manager_path` - manager UI URL path

## theme.json schema (D013)

Required fields:

- `name` - matches directory name
- `version` - semver
- `description` - free text
- `author` - free text
- `layouts` - array of layout names this theme is compatible
  with. **The manager rejects an upload without this.** The
  processor ignores a theme if the active layout isn't in this
  array (what then renders:
  [How the processor resolves a theme](/docs/layouts#howtheprocessorresolvesatheme)).
- `config` - object grouping design tokens. Common groups:
  `colours`, `fonts`, `spacing`, `icons`. Group names and keys
  are author-chosen; values must be strings.

Optional:

- `files` - list of files shipped. Used for remote-layout auto-
  fetch; not consulted for local themes.

Example:

    {
      "name": "mytheme",
      "version": "1.0.0",
      "description": "Example brand theme",
      "author": "Example Ltd",
      "layouts": ["default"],
      "config": {
        "colours": {
          "primary": "#332b82",
          "text": "#2a2a2a"
        },
        "fonts": {
          "body": "Open Sans"
        }
      },
      "files": ["theme.json", "main.css"]
    }

## Auto-generated CSS variables

The processor walks `theme.config` and emits a `<style>` block
with CSS custom properties at `:root`, exposed as
`[% theme_css %]`:

    <style>
    :root {
      --theme-colours-primary: #332b82;
      --theme-colours-text: #2a2a2a;
      --theme-fonts-body: Open Sans;
    }
    </style>

Naming: `--theme-GROUP-KEY`.

Use in the theme's CSS:

    body {
      color: var(--theme-colours-text);
      font-family: var(--theme-fonts-body);
    }

This is the recommended pattern: layout.tt emits `theme_css`;
the theme's own `main.css` references the variables. A theme
fork that only tweaks colours edits `theme.json` and doesn't
need to duplicate CSS structure.

## Minimum layout.tt

    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>[% page_meta_title %][% IF site_name %] - [% site_name %][% END %]</title>
      [% IF page_meta_desc %]<meta name="description" content="[% page_meta_desc %]">[% END %]
      [% theme_css %]
      [% IF theme_assets %]
      <link rel="stylesheet" href="[% theme_assets %]/main.css?v=[% theme_version %]">
      [% END %]
    </head>
    <body>
      [% IF nav.size %]
      <nav>
        [% FOREACH item IN nav %]
        <a href="[% item.url | url_safe %]">[% item.label %]</a>
        [% END %]
      </nav>
      [% END %]
      <main>
        <h1>[% page_title %]</h1>
        [% IF page_subtitle %]<p>[% page_subtitle %]</p>[% END %]
        [% content %]
      </main>
    </body>
    </html>

A value that is a whole `href`, `src` or `action` - a nav entry's URL, a
`query.*` or db value, an attribute a page passes to a component - is written
through `| url_safe` (SM970), as `item.url` is above. It passes a path or an
http, https, mailto or tel URL unchanged and turns any other scheme, such as
`javascript:`, into `#`. The filter is available to layouts, components and
pages alike; lint 213 holds every shipped layout and page to it.

## Components: a layout's reusable pieces (GS9)

A component is a Template Toolkit file at `components/<name>.tt` inside the
layout directory. Once it exists, any Markdown page on the site can use it
with a fenced block, and the author never writes HTML:

    ::: hero eyebrow="Workshop"
    # The barn, restored

    ::: actions
    [Book a visit](/visit)
    :::
    :::

The component receives three variables:

- `attrs` - the `key="value"` pairs on the opening line (`attrs.eyebrow`).
- `content` - the inner Markdown, already rendered to HTML. Print it as-is;
  adding `| html` would double-escape it.
- `slots` - each nested `::: <name>` block whose name is NOT itself a
  component, rendered to HTML (`slots.actions`). A nested block that IS a
  component renders inside `content` instead, so components nest.

A worked `components/hero.tt`:

    <section class="hero">
    [% IF attrs.eyebrow %]<span class="eyebrow">[% attrs.eyebrow | html %]</span>[% END %]
    [% content %]
    [% IF slots.actions %]<div class="cta">[% slots.actions %]</div>[% END %]
    </section>

`attrs` values are raw author text, so escape them; `content` and `slots`
are rendered HTML, so do not. Style `.hero`, `.eyebrow` and `.cta` in the
theme's CSS against the theme tokens (`var(--theme-colours-accent)` and
friends - the variable names mirror YOUR theme.json's own group and key
spellings, `--theme-<group>-<key>`, so check the generated theme-tokens.css
rather than guessing), so the same component restyles with every theme.

Built-in components ship under `lazysite/templates/components/` and work on
every layout (`::: qr` is one). A layout component of the same name wins.

A `:::` block whose name matches no component becomes a plain
`<div class="name">` - that is the fenced-div fallback, and it is silent on
purpose. An OPENING fence with no closing `:::` is different: it is left in
the page as literal text, the build logs a `WARN` naming the component and
the body line, and `validate_page` reports `component-fence-unmatched` at
the line. Close every fence you open; count them when you nest.

The same hero panel has been hand-built twice on two sites because nobody
told either author this existed. If your layout has a visual pattern a page
will want more than once, ship it as a component and name it in the
layout's README.

### `sections:` - a page composed entirely from components

For a page that is all structure and no prose, the front matter can carry a
`sections:` list. The engine parses it (a sequence of single-key maps, with
nested maps, lists and `{inline: maps}`) into a `sections` variable for the
LAYOUT. The layout decides what to do with it; the engine draws nothing.
No shipped layout reads `sections` yet, so a layout that wants this adds
the loop itself:

    [% FOREACH s IN sections %]
    [% type = s.keys.first %]
    [% INCLUDE "components/${type}.tt" data = s.$type %]
    [% END %]
    <main>[% content %]</main>

and a page then reads:

    ---
    title: Home
    sections:
      - hero:
          heading: The barn, restored
          actions:
            - { label: Book a visit, href: /visit, style: primary }
      - features:
          items:
            - { title: Workshops, body: Hands-on, small groups. }
            - { title: Stays, body: Two rooms above the forge. }
    ---
    Any Markdown body still renders below, in [% content %].

Under `sections:` a component gets its values as `data` (`data.heading`,
`data.actions`), whereas under a `:::` fence it gets `attrs`/`content`/
`slots`. A component meant for both reads whichever is set.

## Activating layout + theme

A site has ONE active layout + theme, set by the `layout:` and `theme:` keys in
`lazysite.conf` ([how they resolve](/docs/layouts#howtheprocessorresolvesalayout)).
**Activate the theme globally and keep pages layout-agnostic** - do not put
`layout:` in page front matter as the way to apply a design. Every page then inherits the active
layout, so the whole site re-themes in one step. A per-page `layout:` is only
for previewing a staged candidate (below) or a deliberate one-off page - and
you remove preview overrides once you activate.

Agents set these **themselves** through the control API (`layout-activate` /
`theme-activate`), which also clears the cache - it is a self-serve action with
`manage_layouts` / `manage_themes`, not an operator hand-off.

## A reveal animation must start from a VISIBLE state

A scroll-reveal pattern usually looks like this:

```css
.rv    { opacity: 0; transform: translateY(22px); }
.rv.in { opacity: 1; transform: none; }
```

with a script adding `.in` as sections enter the viewport. **Content is invisible
by default and visible only once JavaScript has run** - so a visitor with
JavaScript blocked, most crawlers, and anything extracting text see an empty
page. The site looks complete to its author and is empty to a meaningful fraction
of what reads it.

**A rule inside `prefers-reduced-motion` is NOT a safety net:**

```css
@media (prefers-reduced-motion: reduce) { .rv { opacity: 1; } }
```

That applies only to visitors who asked for reduced motion. It reads like the
animation has already been made safe, and it has not. A careful reader took it
that way, removed the page script while moving chrome into the layout, and left
every section of a live site permanently invisible. The hero sat outside the
pattern, so four successive visual checks looked fine.

Either start visible and animate from there, or give a `<noscript>` fallback that
restores visibility. `create_theme` warns when a theme's CSS hides content by
default, and `audit_site` reports it on an installed theme.

## The active theme is read-only. Where a theme lives.

Two facts to have BEFORE you plan a theme change, rather than after your first
`403`:

**A theme lives at `lazysite/layouts/<layout>/themes/<theme>/`.** Not
`lazysite/themes/` - a theme always belongs to a layout, so it is stored under
that layout. Looking in the wrong place is a `403`, not a `404`, because the
whole `lazysite/` tree is denied to writes by default.

**The theme a site is currently using cannot be edited in place - on any
surface.** WebDAV, the control API, MCP and the manager all refuse a write into
the active theme (or the active layout) - the primary site's, and the theme and
layout any other domain on the instance serves as its own - deliberately: a live theme being
rewritten mid-request would serve a half-updated site to whoever was reading at
that moment. A theme apply is atomic; a stream of file writes into the theme
being rendered is not. It is design, not obstruction, and the refusal is the
same wherever you meet it - there is no other surface to try.

So a theme change is always **copy, edit, activate**:

1. **Copy** the live theme: `copy_theme` (MCP: `{theme, new_name}`),
   `POST action=theme-copy&path=<theme>` with `{"new_name": "..."}` on the
   control API, or **Copy** on the manager's Themes page. The theme is named by
   its directory name or by its path, `lazysite/layouts/<layout>/themes/<theme>`,
   as the refusal gives it. The copy carries the
   source's files and asset mirror and is yours to delete: `delete_theme`
   (MCP) or `theme-delete` (control API) takes the theme by name under the
   active layout, or by its path under any layout.
2. **Edit** the copy, under `lazysite/layouts/<layout>/themes/<new_name>/`, with
   `write_file` / `replace_text` / `PUT` as usual - a non-active theme accepts
   writes with `manage_themes`.
3. **Activate** the copy: `activate_theme` / `theme-activate` (with `host` for
   another domain's theme). The pointer moves
   once, the mirror is rebuilt once, the cache clears once.

The old theme stays where it is until you remove it, which is also your rollback.

## Staging a layout over WebDAV

If you publish over WebDAV you do NOT edit the live look in place - you
stage a new layout beside the active one, preview it, and **activate it
yourself** over the control API.

1. **A grant takes effect at once.** Editing layout structure (including
   `layout.tt`) needs `manage_layouts`; theme files need `manage_themes`
   (separate capabilities), and an operator's grant applies from your next
   request, with no new token (see
   [Capabilities](/docs/ai-connector-tools#capabilities)). If a layout write
   still `403`s right after a grant, you are almost certainly writing the
   **active** layout (next point), which is denied regardless of capability. (Ruled that out and a fresh grant still
   seems not to apply? Call `whoami`: its `capabilities` are the grant as it
   stands now. A tool missing from your client's list means the list was
   fetched before the grant - list the tools again.)
2. **Stage a NEW layout dir - never the active one.** A `PUT` into the
   active layout returns `403`: the live layout is immutable in place, by
   design (a deliberate guard, not a grant failure). A path under a new
   layout returns `409` until you create its collections, then it is
   writable - so `MKCOL` `lazysite/layouts/<new>` and
   `…/themes/<theme>` first, then `PUT` the files.
3. **Preview by per-page override.** Set `layout: <new>` in a single page's
   front matter to render that page through the staged layout before any
   global switch - this is the preview mechanism. The theme's SOURCE css is
   web-served at `/lazysite/layouts/<new>/themes/<theme>/main.css`, so
   reference that for preview; the canonical mirror
   `/lazysite-assets/<new>/<theme>/main.css` is `404` until activation.
4. **Activate it yourself.** `POST` `action=layout-activate&layout=<new>` then
   `action=theme-activate&theme=<theme>` to the control API (needs
   `manage_layouts` / `manage_themes`); each sets the pointer in
   `lazysite.conf` AND clears the cache atomically - no operator step. Then
   **remove the per-page `layout:` preview overrides**: they are a preview
   tool, not the deploy mechanism, and left in place they quietly defeat the
   next site-wide theme switch. Once active, the canonical `/lazysite-assets/`
   mirror serves the theme CSS.

## Theme assets and the activation mirror

`main.css` and other theme assets must live under the theme's **`assets/`**
directory: `lazysite/layouts/<layout>/themes/<theme>/assets/main.css`. On
activation the server builds a flattened mirror served at
`/lazysite-assets/<layout>/<theme>/main.css`, and `layout.tt` links that mirror.

- A `main.css` at the theme ROOT (not under `assets/`) is **not** mirrored, so
  the page links a `404`. Put assets under `assets/`.
- **The mirror is rebuilt on every activation** (`theme-activate` /
  `layout-activate`), so after activating, `GET`
  `/lazysite-assets/<layout>/<theme>/main.css` returns `200` - a
  copied-then-activated layout is drop-in, with no CSS-path edits needed. If it
  ever `404`s **on a single-site instance**, re-activate to rebuild it. On an
  instance serving more than one domain, do NOT re-activate - see
  [Multi-domain instances](#multi-domaininstances) below, where re-activating
  changes a different site.
- **The mirror also follows its source.** A write to a theme's source - WebDAV,
  `write_file`, `upload_file`, `move_file`, `delete_file`, the manager - rebuilds
  that theme's mirror for every domain that has one (the docroot's and one under
  each content root), with its `theme-tokens.css` and fingerprint, and drops the
  cached pages that use it, a page pinning it by `theme:` included. A write to a
  layout's own files (`layout.tt`, `layout.json`) drops the pages that use the
  layout. So an inactive theme's edit reaches the pages that pin it, and no
  activation is needed for it.
- **The mirror itself is not writable.** A write into any
  `/lazysite-assets/<layout>/<theme>/` (a domain's own included) is refused,
  naming the source path to write instead: the mirror is replaced whole at the
  next source write, and reaches no other domain. `list_files` marks each mirror
  `served_copy`, with its `source` and the hosts that serve it (`served_by`, each
  with `theme_active`).
- Before activation, the theme SOURCE css is web-served at
  `/lazysite/layouts/<layout>/themes/<theme>/main.css` - use that for preview;
  switch links to the `/lazysite-assets/` mirror once active.

`theme.json` must be **strict JSON, ASCII, and quote-free in values** - a
non-ASCII character (e.g. an em-dash in `description`) or embedded quotes in a
`config` value fails validation. The check runs **at activation** (and is
cached), so after fixing `theme.json` you must **re-activate**, not just
re-PUT it; a rejection now names the failing reason.

Author `.html` files in the content tree (include partials with no matching
`.md`/`.url` source) are **content, not cache** - the activation cache-clear
leaves them alone. Generated cache (`<page>.html` beside `<page>.md`) is what
gets cleared.

## Multi-domain instances

Everything above describes one site. An instance can serve **several first-class
domains**, each with its own content root, and each carrying its own layout,
theme, nav and presentation settings. If you have been given a task about "a
domain" rather than "the site", read this section first - the instructions above
are not wrong, but they operate instance-wide and will change a site you were not
asked to touch.

A domain's own layout and theme are set with `domain_set` (MCP) or `domain-set`
(control API) against that host. `list_domains` / `domains-list` shows what is
registered, each with its `content_root`, `layout` and `theme` - **call it first**
on any task that mentions a domain, so you know whether this instance serves one
site or several.

`preview_domain` renders a domain exactly as an anonymous visitor would see it,
under its own Host, and works before DNS or TLS point at it - so you can check
what you configured instead of guessing.

### Do not use `theme-activate` to fix a secondary domain

`theme-activate` and `layout-activate` are **instance-wide**. They rewrite the
`theme:` and `layout:` keys in `lazysite/lazysite.conf`, which is the *primary*
site's presentation. Re-activating to repair a secondary domain's stylesheet
switches the primary site's theme - on a real instance that moved a live site
from its own theme to a client's.

They also only see the active layout: `theme-activate` looks for the theme under
`lazysite/layouts/<active-layout>/themes/`, so a theme belonging to a secondary
domain's *different* layout is simply not found, and the activation refuses. The
remedy fails in both directions.

### The right way to publish a secondary domain's assets

Binding the layout and theme publishes the theme's assets to
`/lazysite-assets/<layout>/<theme>/` as part of the binding, under **that
domain's** layout. Bind it and the mirror is there.

Two equivalent ways to bind, and the second is usually what you want:

- `domain_set` with `key: theme` (or `layout`) - explicit, one key at a time.
- `activate_theme` / `activate_layout` **with a `host`** - the same tools you
  would reach for anyway, scoped to that one domain. Without a `host` they are
  instance-wide and change every site on the instance, so on a multi-domain
  instance always pass one.

`site_apply` (applying a site package to a target `host`) also mirrors on apply,
and is the right tool when you are moving a whole site rather than changing its
presentation.

### If a domain renders unstyled

The usual cause is a missing mirror, and the symptom is misleading: the layout
*is* applied and renders its header, nav and footer correctly, but with no CSS
the chrome is invisible, so it reads as "no layout".

1. `GET /lazysite-assets/<layout>/<theme>/main.css` for that domain's pair. A
   `404` confirms it.
2. Check the source is where it belongs:
   `lazysite/layouts/<layout>/themes/<theme>/assets/main.css`.
3. Re-bind with `domain-set` to publish it. Do not re-activate.

### Cache

How long browsers keep `/lazysite-assets/` files depends on WHICH front end
serves the site, and a layout author cannot assume - so here is how to tell,
and what to do in each case:

- On the **stock front end** (no ACL store; the header says nothing, or
  `X-Lazysite-Front` is absent), assets carry a ten-year cache. A layout
  linking `main.css?v=1` must **bump `v` on every CSS change** or browsers
  keep serving the old file - including yours while you are checking your work.
- On the **lazysite proxy template** (`X-Lazysite-Front: hestia-proxy/acl` or
  a one-rule front end), the engine serves assets itself. By default they
  revalidate on every use - your changes appear immediately and `?v=` bumping
  is unnecessary (though harmless). If the operator has set the site's
  **Asset cache lifetime** (`asset_max_age`), changes can take up to that many
  seconds to reach returning visitors, and `?v=` bumping makes them immediate
  again.

## Opening hours and structured data (SM1356, SM1357)

**Opening hours are a schedule table, and a layout renders its blocks.** A page
(or `lazysite.conf`, for every page) binds `hours: schedule:<table>`, and the
layout gets `hours.label` ("Open now until 17:00", "Opens at 12:00"),
`hours.week` (seven days, each with its `periods`), `hours.today` and
`hours.next_exception` - the whole shape, with an example, is in
[Data tables - Schedules](/docs/data-tables#schedules). Values are escaped like
any `db:` value: no `| html`. Do not compute "open now" in the layout's own
script or from `now` in a template: the engine caches the page only until the
next change of state, so the engine's label is right and a hand-rolled one is
the cached one.

**A layout writes no JSON-LD.** The engine puts one
`<script type="application/ld+json">` before `</head>` on the pages a table's
`structured_data:` mapping names, and the organisation entry on the home page,
from the site's own details. A layout that also hard-codes schema.org markup
publishes a second, disagreeing description of the same thing. Keep `</head>` in
the layout; that is where it goes.

## A layout cannot open the camera, the microphone or the visitor's location

Every response sends a `Permissions-Policy` header that denies these browser
features: `accelerometer`, `browsing-topics`, `camera`, `display-capture`,
`geolocation`, `gyroscope`, `magnetometer`, `microphone`, `midi`, `payment`,
`usb`, `xr-spatial-tracking`. A layout or theme script that calls
`getUserMedia`, `navigator.geolocation` or a sensor API fails on every page,
and the visitor is never asked - the browser refuses at the policy first. There
is no layout or theme setting that changes this, and nothing to ask of the
front end: the engine sends the header.

What relaxes it is the PAGE. A page whose front matter says `<feature>: self`
(`camera: self`, `geolocation: self`) sends `<feature>=(self)` for that page
alone, over https only. So a component that needs one of these features is
used on a page that asks for it, and the layout keeps working without it
everywhere else - check before calling the API, and degrade quietly when it is
refused. See the front matter keys in
[AI briefing - content authoring](/docs/ai-briefing-authoring). Two features
cannot be asked for by any page: `payment` (its key is the paid-page key) and
`browsing-topics` (lazysite installs no trackers). `autoplay`, `fullscreen` and
`picture-in-picture` are not denied and need nothing.

## What NOT to do

- Do not modify `lazysite/manager/layout.tt` - that's the
  manager UI's internal chrome.
- Do not place themes at the pre-D013 path
  `lazysite/themes/NAME/` - the processor doesn't look there
  any more.
- Do not write `view.tt` - that file name is gone; it's
  `layout.tt` now.
- Do not omit `layouts[]` from `theme.json` - the manager
  rejects the upload and the processor can't activate it.
- Do not emit CSS expressions in `theme.config` values; `;{}<>`
  are stripped to prevent declaration escape.

## Related

- [Layouts and themes](/docs/layouts) - the model, and installing and switching by hand
- [Integrations](/docs/integrations) - bring an external design into a site
- [Layouts reference](/docs/features/configuration/layouts)
- [Themes reference](/docs/features/configuration/themes)
- [theme.json reference](/docs/features/configuration/theme-json)
- [Remote layouts](/docs/features/configuration/remote-layouts)
