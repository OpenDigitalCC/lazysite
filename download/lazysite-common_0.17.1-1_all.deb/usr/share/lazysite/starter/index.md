---
provenance: lazysite-starter
starter_role: content
title: Welcome
subtitle: A new lazysite site
register:
  - sitemap.xml
  - llms.txt
---

This site is built with [lazysite](https://lazysite.io).

## Manager

[Open the lazysite Manager](/manager) to manage content, themes, extensions, and users via the web interface.

Sign in as `manager` - no password required when accessing from localhost.

## Try it

- [Feature demonstrator](/lazysite-demo) - see features working locally

## Discover

- [Authoring guide](/docs/authoring) - writing pages, front matter, Markdown
- [All features](/docs/features) - complete feature reference
- [API and raw mode](/docs/api) - JSON endpoints, query strings, content types

## Configure

- [Configuration](/docs/configuration) - views, navigation, lazysite.conf
- [Reference](/docs/reference) - front matter keys, variables, file locations

## Install

- [Installation](/docs/install) - requirements, server setup, getting started

## Develop

- [Development](/docs/development) - dev server, troubleshooting, build tools

## Project

- [lazysite.io](https://lazysite.io) - project website
- [GitHub](https://github.com/OpenDigitalCC/lazysite) - source
