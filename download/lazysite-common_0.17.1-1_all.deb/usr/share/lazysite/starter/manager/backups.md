---
title: Backups
auth: manager
search: false
---

<div id="status" class="mg-status"></div>

<div class="mg-note mg-note-warn" id="unfinished" hidden>
<p><b>Unfinished backups.</b> These were started and did not finish, so they hold
no backup and are not offered as one. If no backup is being taken now, delete them.</p>
<div class="mg-list" id="unfinished-list"></div>
</div>

<div class="mg-note mg-note-info">
Backups are whole-site snapshots for disaster recovery &mdash; the full-system
kind includes configuration and secrets. Day-to-day <b>content versioning</b>
(per-file history, diff and restore) lives in the <b>Content history</b> extension.
</div>

<div class="mg-card">
<div class="mg-card-header"><span class="mg-card-title">Content backups</span>
<button class="mg-btn mg-btn-sm" onclick="loadBackups()">Refresh</button></div>
<div class="mg-card-body">
<p class="mg-muted">
Snapshots of the site <b>content</b> (everything except the <code>lazysite/</code>
infrastructure), stored under <code>lazysite/backups/</code> and never served. A
<b>pre-install</b> snapshot is taken automatically the first time lazysite is
installed over an existing site. <b>Restore</b> writes a snapshot's files back over
the site (files created since are left in place), takes a <b>prerestore</b> safety
snapshot first, and clears the affected page caches.
</p>
<div style="margin-bottom:12px;">
<button class="mg-btn mg-btn-primary" onclick="createBackup(this)">Create content backup</button>
<span class="mg-row-meta" id="content-outcome" role="status"></span>
</div>
<div class="mg-list" id="content-list">
<div class="mg-row"><span class="mg-file-name">Loading&hellip;</span></div>
</div>
</div>
</div>

<div class="mg-card">
<div class="mg-card-header"><span class="mg-card-title">Site packages</span>
<button class="mg-btn mg-btn-sm" onclick="loadBackups()">Refresh</button></div>
<div class="mg-card-body">
<p class="mg-muted">
A <b>site package</b> is one domain's site &mdash; its content, nav, the referenced
theme/layout and presentation settings &mdash; and <b>nothing else</b>: no extensions,
no instance settings, <b>no secrets</b>. That is what makes it safe to hand to a
client's own instance (an agency demo &rarr; client hand-off). Create one from
<b>Domains &rarr; Export site</b>; the package appears here to download, apply or
delete. To move between instances, download it, then <b>Upload</b> it on the target
and <b>Apply</b> it to a domain there.
</p>
<div style="margin-bottom:12px;">
<button class="mg-btn mg-btn-primary" onclick="exportPrimarySite(this)">Export this site</button>
<label class="mg-btn mg-btn-primary" style="cursor:pointer;">
&#11014; Upload a package
<input type="file" accept=".tar.gz,application/gzip" style="display:none;" onchange="uploadPackage(this)">
</label>
</div>
<div class="mg-list" id="package-list">
<div class="mg-row"><span class="mg-file-name">Loading&hellip;</span></div>
</div>
</div>
</div>

<div class="mg-card">
<div class="mg-card-header"><span class="mg-card-title">Full-system backups</span></div>
<div class="mg-card-body">
<p class="mg-muted">
A <b>complete</b> snapshot &mdash; content <i>plus</i> configuration, accounts and
secrets, themes and layouts &mdash; for disaster recovery and for <b>migrating a
site to another domain</b> (build on a temporary domain, then move content, config
and accounts to the final one). Because it carries the auth secrets and its restore
overwrites accounts and config, <b>restore is a system-user operation from the
shell</b>, not a button here:
</p>
<pre class="mg-code" style="white-space:pre-wrap;">lazysite backups --docroot &lt;path&gt; --cgibin &lt;cgi-bin&gt; --restore-full &lt;file&gt; --domain &lt;new-domain&gt;</pre>
<p class="mg-muted">That one command also lays the engine's entry points and the group and modes, and ends with the health check.</p>
<p class="mg-muted">Download one to keep off-site. Anyone who can download a full
backup effectively holds the site's secrets &mdash; treat it accordingly.</p>
<div style="margin-bottom:12px;">
<button class="mg-btn mg-btn-primary" onclick="createFullBackup(this)">Create full-system backup</button>
<span class="mg-row-meta" id="full-outcome" role="status"></span>
</div>
<div class="mg-list" id="full-list">
<div class="mg-row"><span class="mg-file-name">Loading&hellip;</span></div>
</div>
</div>
</div>

<script>
var API = '/cgi-bin/lazysite-manager-api.pl';
var BACKUP_POLL_MS = 5000, BACKUP_POLL_CAP_MS = 3 * 3600 * 1000;    // SM1446: a full backup in progress

function showStatus(msg, isError) {
  var el = document.getElementById('status');
  if (isError) {
    if (typeof mgShowWarning === 'function') mgShowWarning(msg, true);
    if (el) { el.textContent = ''; el.className = 'mg-status'; }
    return;
  }
  if (typeof mgClearWarning === 'function') mgClearWarning();
  if (!el) return;
  if (!msg) { el.textContent = ''; el.className = 'mg-status'; return; }
  el.className = 'mg-status mg-status-success';
  el.textContent = msg;
  setTimeout(function() { showStatus(''); }, 3000);
}

function escHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function fmtSize(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

function fmtDate(epoch) {
  if (!epoch) return '';
  return new Date(epoch * 1000).toISOString().replace('T', ' ').replace(/:\d\d\..*/, '') + ' UTC';
}

function loadBackups() {
  fetch(API + '?action=backup-list', { credentials: 'same-origin' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (!d.ok) { showStatus(d.error, true); return; }
      // SM1446 (ruling 248): a backup being taken now is shown at the top of
      // its list, marked in progress, with nothing to act on yet.
      var all = (d.in_progress || []).map(function(b) { b.running = true; return b; })
        .concat(d.backups || []);
      // Three distinct kinds: content snapshots (in-app restore), site packages
      // (SM183: apply to a domain), and full-system backups (CLI restore only).
      renderBackups(all.filter(function(b) { return b.scope === 'content'; }), 'content-list', true);
      renderPackages(all.filter(function(b) { return b.scope === 'site'; }));
      renderBackups(all.filter(function(b) { return b.scope === 'full'; }), 'full-list', false);
      renderUnfinished(d.unfinished || []);
    })
    .catch(function(e) { showStatus('Failed to load backups: ' + e.message, true); });
}

// SM1446: a backup that was started and did not finish is not a backup. The
// server lists it apart; it is shown apart, with its time and a delete.
function renderUnfinished(list) {
  var box = document.getElementById('unfinished');
  var el = document.getElementById('unfinished-list');
  if (!box || !el) return;
  box.hidden = !list.length;
  var html = '';
  for (var i = 0; i < list.length; i++) {
    var b = list[i];
    html += '<div class="mg-row">';
    html += '<span class="mg-file-name"><span class="mg-mono">' + escHtml(b.name) + '</span> '
          + '<span class="mg-tag mg-tag-off">unfinished</span> '
          + '<span class="mg-row-meta">' + fmtDate(b.mtime) + '</span></span>';
    html += '<span class="mg-row-actions"><button class="mg-btn mg-btn-sm mg-btn-danger" data-impact="destroy" '
          + 'onclick="deleteUnfinished(\'' + escHtml(b.name) + '\', this)">Delete</button></span>';
    html += '</div>';
  }
  el.innerHTML = html;
}

function deleteUnfinished(name, btn) {
  var site = /^(?:lazysite-)?site-/.test(name);
  var msg = 'Delete the unfinished backup "' + name + '"?\n\nIt holds no backup. '
          + 'Delete it only if no backup is being taken now.';
  var go = function(ok) {
    if (!ok) return;
    if (btn) btn.disabled = true;
    fetch(API + '?action=' + (site ? 'site-backup-delete' : 'backup-delete'), {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name })
    }).then(function(r) { return r.json(); }).then(function(d) {
      if (btn) btn.disabled = false;
      if (!d.ok) { showStatus(d.error || 'Delete failed', true); return; }
      showStatus('Deleted ' + name + '.');
      loadBackups();
    }).catch(function(e) { if (btn) btn.disabled = false; showStatus('Delete error: ' + e.message, true); });
  };
  if (typeof mgConfirm === 'function') { mgConfirm(msg, { danger: true, ok: 'Delete' }).then(go); }
  else { go(window.confirm(msg)); }
}

// restorable = content (in-app restore button); full backups download only.
function renderBackups(list, elId, restorable) {
  var el = document.getElementById(elId);
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div class="mg-row"><span class="mg-file-name mg-empty">No backups yet</span></div>';
    return;
  }
  var html = '';
  for (var i = 0; i < list.length; i++) {
    var b = list[i];
    var badge = b.kind === 'preinstall' ? 'mg-tag mg-tag-on' : 'mg-tag mg-tag-off';
    // TWO children, which is what .mg-row is: everything that describes the
    // row, then everything that acts on it. Five loose children were placed
    // into a two-column grid one after another, so the badge, Download and
    // Restore each landed on a row of their own, staggered - reported as a
    // button out of alignment, and it was every button in the list.
    if (b.running) {
      html += '<div class="mg-row"><span class="mg-file-name"><span class="mg-mono">' + escHtml(b.name) + '</span> '
            + '<span class="mg-tag mg-tag-on">in progress</span> '
            + '<span class="mg-row-meta">started ' + fmtDate(b.mtime) + '</span></span></div>';
      continue;
    }
    html += '<div class="mg-row">';
    html += '<span class="mg-file-name"><span class="mg-mono">' + escHtml(b.name) + '</span> '
          + '<span class="mg-tag ' + badge + '">' + escHtml(b.kind) + '</span> '
          + '<span class="mg-row-meta">' + fmtSize(b.size) + ' &middot; ' + fmtDate(b.mtime) + '</span></span>';
    html += '<span class="mg-row-actions">';
    html += '<a class="mg-btn mg-btn-sm" href="' + API + '?action=backup-download&name=' + encodeURIComponent(b.name) + '">&#11015; Download</a>';
    if (restorable) {
      html += '<button class="mg-btn mg-btn-sm mg-btn-danger" onclick="restoreBackup(\'' + escHtml(b.name) + '\', this)">Restore</button>';
    } else {
      html += '<span class="mg-row-meta">restore via CLI</span>';
    }
    html += '</span>';
    html += '</div>';
  }
  el.innerHTML = html;
}

// SM266 (3): undo the apply that just happened, by name, from where the
// operator is standing. Routes through the SAME restore the Backups list uses -
// no second restore path - so it inherits the pre-restore snapshot, the cache
// clear and the audit entry. The undo is therefore itself undoable.
function offerUndo(snapshot, host) {
  var bar = document.getElementById('undo-bar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'undo-bar';
    bar.className = 'mg-undo-bar';
    var app = document.getElementById('app') || document.body;
    app.insertBefore(bar, app.firstChild);
  }
  bar.innerHTML = 'Applied to ' + escHtml(host || 'the primary site') + '. '
    + 'Not what you meant? <button class="mg-btn mg-btn-sm" '
    + 'onclick="undoApply(\'' + escHtml(snapshot) + '\', this)">Undo &mdash; restore '
    + '<code>' + escHtml(snapshot) + '</code></button> '
    + '<button class="mg-btn mg-btn-sm" onclick="this.parentNode.remove()">Close</button>';
}

// SM874: the undo asks ONCE, and asks the real question.
//
// It used to confirm, then call restoreBackup, which confirmed again - three
// clicks for one decision, and the site agent's first two 1315S-03 attempts
// read as "undo does nothing" because they had answered only part of the chain.
// Worse, the two dialogs now say different things: an undo REPLACES the target
// and the generic restore overlays it. Two confirmations that contradict each
// other are worse than one that is accurate, so this defers to restoreBackup's
// - which is written for the mode it is passed.
function undoApply(snapshot, btn) {
  restoreBackup(snapshot, btn, true);
  var bar = document.getElementById('undo-bar');
  if (bar) bar.remove();
}

// `replace` is the undo path: the target folder is cleared before the snapshot
// is written back, so files the apply ADDED are removed too. Without it a
// restore is an overlay and an apply cannot be undone - which is what the
// pre-apply snapshot exists for.
function restoreBackup(name, btn, replace) {
  var msg = replace
    ? 'Undo the apply, restoring "' + name + '"?\n\n'
      + 'The target folder is cleared and the snapshot written back, so files '
      + 'the package ADDED are removed as well as changes to existing ones. A '
      + 'prerestore safety snapshot is taken first, so this is reversible too.'
    : 'Restore "' + name + '"?\n\nIts files are written back over the site, '
      + 'replacing anything of the same name. Files that are not in the '
      + 'snapshot are left alone. A prerestore safety snapshot is taken first.';
  var go = function(ok) {
    if (!ok) return;
    if (btn) btn.disabled = true;
    showStatus('Restoring ' + name + '...');
    fetch(API + '?action=backup-restore&name=' + encodeURIComponent(name)
              + (replace ? '&replace=1' : ''),
          { method: 'POST', credentials: 'same-origin' })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (btn) btn.disabled = false;
        if (!d.ok) { showStatus(d.error, true); return; }
        showStatus('Restored ' + d.restored + ' (safety snapshot: ' + d.safety
                 + ', ' + d.cache_cleared + ' cached page(s) cleared).');
        loadBackups();
      })
      .catch(function(e) { if (btn) btn.disabled = false; showStatus('Error: ' + e.message, true); });
  };
  // SM874: the button carries the verb for the mode it is in - "Undo the apply"
  // removes files, "Restore" does not, and an operator reading only the button
  // should still be told which one they are about to do.
  var verb = replace ? 'Undo the apply' : 'Restore';
  if (typeof mgConfirm === 'function') { mgConfirm(msg, { danger: true, ok: verb }).then(go); }
  else { go(window.confirm(msg)); }
}

function createBackup(btn) { _create(btn, '', 'Backup created: ', 'content-outcome'); }

function createFullBackup(btn) {
  var msg = 'Create a full-system backup?\n\nIt includes configuration, accounts '
          + 'and secrets. Keep the downloaded file secure.';
  var go = function(ok) { if (ok) _create(btn, '&scope=full', 'Full-system backup created: ', 'full-outcome'); };
  if (typeof mgConfirm === 'function') { mgConfirm(msg, { ok: 'Create' }).then(go); }
  else { go(window.confirm(msg)); }
}

// SM1446: THE BUTTON RETURNS TO REST WITH THE OUTCOME BESIDE IT, and the list is
// read again whatever happened. The outcome was only a toast, gone in seconds,
// and an answer that was not JSON - the error page of a server that stopped
// waiting - was dropped, so the page fell silent and showed nothing new.
function _create(btn, extra, okMsg, outId) {
  var out = document.getElementById(outId);
  var say = function(t) { if (out) out.textContent = t; };
  if (btn) btn.disabled = true;
  say('Creating backup…');
  showStatus('Creating backup...');
  fetch(API + '?action=backup-create' + extra, { method: 'POST', credentials: 'same-origin' })
    .then(function(r) {
      return r.text().then(function(t) {
        try { return JSON.parse(t); } catch (e) {
          return { ok: 0, error: 'No answer from the backup (HTTP ' + r.status + '): the server '
            + 'stopped waiting for it. It may still finish; the list shows it when it has, '
            + 'or as unfinished.' };
        }
      });
    })
    .then(function(d) {
      if (btn) btn.disabled = false;
      if (d.ok && d.in_progress) {
        // SM1446 (ruling 248): a full backup runs on after the request; the
        // page follows it in the list until it is done, failed or unfinished.
        say('Full-system backup started: ' + d.name + ' (in progress)');
        loadBackups();
        pollBackup(d.name, okMsg, outId, Date.now());
        return;
      }
      var t = d.ok ? okMsg + d.name : (d.error || 'Backup failed');
      say(t);
      showStatus(t, !d.ok);
      loadBackups();
    })
    .catch(function(e) {
      if (btn) btn.disabled = false;
      say('Error: ' + e.message);
      showStatus('Error: ' + e.message, true);
      loadBackups();
    });
}

// SM1446 (ruling 248): follow a backup that runs on after its request. Read the
// list every BACKUP_POLL_MS until the name is listed as a backup (done), as
// unfinished, or nowhere (failed: the worker removed its claim), or until
// BACKUP_POLL_CAP_MS has passed; then say so beside the button.
function pollBackup(name, okMsg, outId, began) {
  var out = document.getElementById(outId);
  var say = function(t) { if (out) out.textContent = t; };
  var again = function() { setTimeout(function() { pollBackup(name, okMsg, outId, began); }, BACKUP_POLL_MS); };
  var end = function(t, bad) { say(t); showStatus(t, bad); loadBackups(); };
  if (Date.now() - began >= BACKUP_POLL_CAP_MS) {
    end('Still being taken: ' + name + '. The list shows it when it has finished.', false);
    return;
  }
  fetch(API + '?action=backup-list', { credentials: 'same-origin' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (!d.ok) { again(); return; }
      var find = function(l) { return (l || []).filter(function(b) { return b.name === name; })[0]; };
      var done = find(d.backups);
      if (done) { end(okMsg + name + ' (' + fmtSize(done.size) + ')', false); return; }
      if (find(d.unfinished)) { end('The backup did not finish: ' + name + ' is listed as unfinished.', true); return; }
      if (!find(d.in_progress)) {
        end('The backup failed: ' + name + ' is no longer listed. The audit trail\'s backup-create entry says why.', true);
        return;
      }
      say('Full-system backup in progress: ' + name);
      again();
    })
    .catch(function() { again(); });
}

// --- SM183: site packages (create is on the Domains page; here: list, upload,
// apply, delete). The global CSRF wrapper (manager layout M-1) adds the token to
// every POST, so these follow the same fetch pattern as the content backups. ---

// The source host is encoded in the package name: lazysite-site-<host>-<UTCstamp>.
function pkgHost(name) {
  var m = /^lazysite-site-(.+)-\d{8}T\d{6}Z\.tar\.gz$/.exec(name || '');
  return m ? m[1] : '';
}

function renderPackages(list) {
  var el = document.getElementById('package-list');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div class="mg-row"><span class="mg-file-name mg-empty">No site packages yet &mdash; create one from Domains &rarr; Export site.</span></div>';
    return;
  }
  var html = '';
  for (var i = 0; i < list.length; i++) {
    var b = list[i];
    var host = pkgHost(b.name);
    var uploaded = host === 'uploaded';
    var id = 'pkg-' + i;
    // Same two children as the backup rows above. `flex-wrap` on the row did
    // nothing: .mg-row is a grid, and the expand card it was there to keep on
    // its own line spans both columns instead.
    html += '<div class="mg-row">';
    html += '<span class="mg-file-name"><span class="mg-mono">' + escHtml(b.name) + '</span> '
          + '<span class="mg-tag ' + (uploaded ? 'mg-tag mg-tag-off' : 'mg-tag mg-tag-on') + '">' + (uploaded ? 'uploaded' : escHtml(host || 'site')) + '</span> '
          + '<span class="mg-row-meta">' + fmtSize(b.size) + ' &middot; ' + fmtDate(b.mtime) + '</span></span>';
    html += '<span class="mg-row-actions">';
    html += '<a class="mg-btn mg-btn-sm" href="' + API + '?action=backup-download&name=' + encodeURIComponent(b.name) + '">&#11015; Download</a>';
    html += '<button class="mg-btn mg-btn-sm" onclick="showApply(\'' + escHtml(b.name) + '\', \'' + id + '\')">Apply&hellip;</button>';
    html += '<button class="mg-btn mg-btn-sm mg-btn-danger" onclick="deletePackage(\'' + escHtml(b.name) + '\', this)">Delete</button>';
    html += '</span>';
    html += '<div class="mg-expand mg-row-wide" id="' + id + '" hidden></div>';
    html += '</div>';
  }
  el.innerHTML = html;
}

// SM185: export the DEFAULT/primary site as a self-contained package, without
// needing the domains feature. Gated server-side on manage_content.
function exportPrimarySite(btn) {
  if (btn) btn.disabled = true;
  showStatus('Packaging this site…');
  fetch(API + '?action=site-export-primary', { method: 'POST', credentials: 'same-origin' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (btn) btn.disabled = false;
      if (!d.ok) { showStatus(d.error || 'Export failed', true); return; }
      showStatus('Exported this site → ' + d.name + '. Download or apply it below.');
      loadBackups();
    })
    .catch(function(e) { if (btn) btn.disabled = false; showStatus('Export error: ' + e.message, true); });
}

function uploadPackage(input) {
  if (!input.files || !input.files.length) return;
  var file = input.files[0];
  var fd = new FormData();
  fd.append('file', file, file.name);
  showStatus('Uploading ' + file.name + '…');
  // No explicit Content-Type: the browser sets the multipart boundary; the CSRF
  // wrapper still adds X-CSRF-Token.
  fetch(API + '?action=site-backup-upload', { method: 'POST', credentials: 'same-origin', body: fd })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      input.value = '';
      if (!d.ok) { showStatus(d.error || 'Upload failed', true); return; }
      showStatus('Uploaded ' + d.name + '. Apply it to a domain below.');
      loadBackups();
    })
    .catch(function(e) { input.value = ''; showStatus('Upload error: ' + e.message, true); });
}

function showApply(name, panelId) {
  var panel = document.getElementById(panelId);
  if (!panel) return;
  // The `hidden` ATTRIBUTE, not an inline display. Same state, expressed
  // where the stylesheet can see it - .mg-expand[hidden] - and one less
  // inline style for a rule in the sheet to lose to.
  if (!panel.hidden) { panel.hidden = true; return; }
  panel.hidden = false;
  panel.innerHTML = '<span class="mg-muted">Loading&hellip;</span>';
  panel._pkg = name;
  Promise.all([
    fetch(API + '?action=site-backup-inspect&name=' + encodeURIComponent(name), { credentials: 'same-origin' }).then(function(r) { return r.json(); }),
    fetch(API + '?action=domains-list', { credentials: 'same-origin' }).then(function(r) { return r.json(); })
  ]).then(function(res) {
    var info = res[0], dl = res[1];
    if (!info.ok) { panel.innerHTML = '<span class="mg-warn">' + escHtml(info.error || 'Cannot read package') + '</span>'; return; }
    var m = info.manifest || {};
    var doms = (dl.ok && dl.domains) ? dl.domains : [];
    var opts = '<option value="">(default) &mdash; primary site</option>';
    for (var i = 0; i < doms.length; i++) {
      if (!doms[i].content_root) continue;   // only domains with their own content root
      opts += '<option value="' + escHtml(doms[i].host) + '">' + escHtml(doms[i].host) + '</option>';
    }
    var selId = panelId + '-target', clnId = panelId + '-clean';
    var html = '';
    html += '<div style="font-size:0.85rem;margin-bottom:8px;"><b>Package</b>: source '
          + escHtml(m.source_host || '(default)') + ' &middot; ' + (info.content_files || 0)
          + ' file(s) &middot; theme ' + escHtml(m.theme || '(none)') + ' &middot; layout '
          + escHtml(m.layout || '(none)') + ' &middot; nav '
          + (info.has_nav ? 'override' : escHtml(m.nav || 'base-inherited')) + '.</div>';
    // SM266: changing the target re-runs the dry run and the readiness check
    // against THAT target. Both are per-target answers, so neither can be
    // computed once when the panel opens.
    html += '<div style="margin-bottom:6px;"><label>Apply to: <select id="' + selId
          + '" onchange="refreshApplyPreview(\'' + panelId + '\')">' + opts + '</select></label></div>';
    html += '<div style="margin-bottom:6px;"><label><input type="checkbox" id="' + clnId + '"> Remove existing content under the target first (clean)</label></div>';
    // SM266 (1) dry run, (2) target readiness, (4) presentation-key override.
    html += '<div id="' + panelId + '-preview" class="mg-apply-preview"></div>';
    html += '<div class="mg-muted" style="font-size:0.8rem;margin-bottom:8px;">Apply overwrites the target domain\'s content and rewrites its presentation (site_url / site_name / theme / layout / nav) to the package\'s. A safety snapshot is taken first and the change is recorded in content history. DNS/TLS for the target stay the operator\'s job.</div>';
    html += '<button class="mg-btn mg-btn-primary mg-btn-sm" onclick="doApply(\'' + escHtml(name) + '\', \'' + selId + '\', \'' + clnId + '\', this)">Apply package</button> ';
    html += '<button class="mg-btn mg-btn-sm" onclick="document.getElementById(\'' + panelId + '\').hidden = true;">Cancel</button>';
    panel.innerHTML = html;
    refreshApplyPreview(panelId);
  }).catch(function(e) { panel.innerHTML = '<span class="mg-warn">Error: ' + escHtml(e.message) + '</span>'; });
}

// SM266 (carved out of SM183): the difference between "I have read the
// manifest" and "I know what this will change".
//
// SM183 made apply SAFE - a snapshot on every surface, a named rollback point,
// a digest on the artefact. None of that lets a human see what an apply will do
// BEFORE agreeing to it, which is the question an operator actually has in
// front of a confirm button. Three answers, all for the selected target:
//
//   the dry run       how many files land, and how many of them overwrite
//   readiness         whether DNS/vhost/TLS are pointed at the target yet
//   the key override  which presentation keys change, with the option to keep
//
// All three are per-target. Re-run on every target change; blank for the
// primary site, where "which domain" is not a question.
function refreshApplyPreview(panelId) {
  var box = document.getElementById(panelId + '-preview');
  var sel = document.getElementById(panelId + '-target');
  var panel = document.getElementById(panelId);
  if (!box || !sel || !panel) return;
  var host = sel.value;
  var name = panel._pkg;
  if (!host) {
    box.innerHTML = '<div class="mg-muted" style="font-size:0.8rem;margin-bottom:8px;">'
      + 'Applying to the primary site. Select a domain to see what would change there.</div>';
    return;
  }
  box.innerHTML = '<span class="mg-muted">Checking the target&hellip;</span>';
  Promise.all([
    fetch(API + '?action=site-backup-inspect&name=' + encodeURIComponent(name)
          + '&host=' + encodeURIComponent(host), { credentials: 'same-origin' })
      .then(function(r) { return r.json(); }),
    fetch(API + '?action=domain-check&host=' + encodeURIComponent(host),
          { credentials: 'same-origin' }).then(function(r) { return r.json(); })
      .catch(function() { return { ok: false }; })
  ]).then(function(res) {
    var info = res[0], chk = res[1];
    if (!info.ok) {
      box.innerHTML = '<div class="mg-warn">' + escHtml(info.error || 'Cannot compare against that target') + '</div>';
      return;
    }
    var c = info.compare || {}, m = info.manifest || {}, h = '';

    // 1. The dry run. Overwrites are the number that matters, so it leads and
    // is emphasised when non-zero - "12 files, 9 of them overwriting what is
    // there" is a different decision from "12 new files".
    h += '<div class="mg-apply-block"><b>What this would do to ' + escHtml(host) + '</b><ul>';
    h += '<li>' + (c.added || 0) + ' new file' + ((c.added === 1) ? '' : 's') + '</li>';
    h += '<li>' + (c.overwritten
          ? '<b>' + c.overwritten + ' existing file' + ((c.overwritten === 1) ? '' : 's') + ' overwritten</b>'
          : 'nothing overwritten') + '</li>';
    if (m.layout) {
      h += '<li>layout <code>' + escHtml(m.layout) + '</code> &mdash; '
        + (c.layout_present ? 'already installed, left as it is' : 'would be installed') + '</li>';
    }
    if (m.theme) {
      h += '<li>theme <code>' + escHtml(m.theme) + '</code> &mdash; '
        + (c.theme_present ? 'already installed, left as it is' : 'would be installed') + '</li>';
    }
    h += '</ul></div>';

    // 2. Readiness. A target whose DNS or TLS is not pointed yet is a warning
    // BEFORE the apply rather than a discovery after it. Not a blocker: staging
    // content ahead of a DNS cutover is a legitimate thing to do deliberately.
    // SM876: READ THE CHECK THE ENGINE ACTUALLY RETURNS.
    //
    // This read `chk.dns.ok`, `chk.tls.ok` and `chk.vhost.ok`, and was wrong
    // three times over. `domain-check` returns
    //
    //     { ok, host, all_pass, checks: [ { id, label, pass, detail }, ... ] }
    //
    // so `checks` is an ARRAY and not a map; the ids are `dns`, `host`, `ssl`
    // and `terminates` - there is no `tls` and no `vhost`; and the field is
    // `pass`, not `ok`. `undefined === false` is false, so no problem could
    // ever be pushed and the warning branch was UNREACHABLE. Not "the warning
    // did not fire for this host" - it had never fired for any host, and the
    // green tick was unconditional.
    //
    // Found walking tier-B B6 (2026-09-13): a domain the engine's own
    // domain-check reported as `dns pass=0 ... terminates pass=0` was shown as
    // "is resolving and served", in green, with a tick. A missing readiness
    // line leaves an operator to check; a false green tells them not to bother.
    //
    // THREE STATES, NOT TWO. `pass` is 1, 0, or NULL - and null is deliberate:
    // behind a proxy or NAT the server cannot know its own public IP, so
    // "Points to this server" is INDETERMINATE rather than failed (see
    // Domains.pm). Treating null as a failure would warn on every proxied site;
    // treating it as a pass would assert reachability nobody established. So it
    // is its own answer, and the tick is claimed only when the engine says
    // all_pass.
    //
    // The problem text is the engine's own label and detail rather than three
    // strings invented here - one place says what a failing check means, and it
    // is the place that ran it.
    if (chk && chk.ok) {
      var probs = [], unknown = [], list = chk.checks || [];
      for (var ci = 0; ci < list.length; ci++) {
        var c = list[ci]; if (!c) continue;
        if (c.pass === null || c.pass === undefined) { unknown.push(c.label); continue; }
        if (Number(c.pass)) continue;
        probs.push(c.label + ' — ' + c.detail);
      }
      if (probs.length) {
        h += '<div class="mg-note mg-note-warn">&#9888; ' + escHtml(host) + ': '
           + escHtml(probs.join('; '))
           + '. The apply will still work &mdash; the content simply is not reachable yet.</div>';
      } else if (chk.all_pass) {
        h += '<div class="mg-apply-ok">&#10003; ' + escHtml(host) + ' is resolving and served.</div>';
      } else {
        h += '<div class="mg-note mg-note-info">' + escHtml(host)
           + ': nothing is failing, but this could not be confirmed &mdash; '
           + escHtml(unknown.join('; ')) + '. Behind a proxy that is normal.</div>';
      }
    }

    // 3. The presentation keys, with the option to keep the target's own. Ticked
    // means "keep mine"; unticked (the default) is the existing behaviour, so
    // an operator who ignores this control gets exactly what they got before.
    var pres = [['theme', m.theme], ['layout', m.layout], ['nav', m.nav]];
    var rows = '';
    for (var i = 0; i < pres.length; i++) {
      if (!pres[i][1]) continue;
      rows += '<label class="mg-apply-keep"><input type="checkbox" class="' + panelId + '-keep" '
        + 'value="' + escHtml(pres[i][0]) + '"> keep this site\'s <b>' + escHtml(pres[i][0])
        + '</b> (the package would set it to <code>' + escHtml(pres[i][1]) + '</code>)</label>';
    }
    if (rows) {
      h += '<div class="mg-apply-block"><b>Presentation</b><div class="mg-muted" '
        + 'style="font-size:0.8rem">Tick anything you want left alone. Untouched, the '
        + 'package\'s values are applied, as before.</div>' + rows + '</div>';
    }
    box.innerHTML = h;
  }).catch(function(e) {
    box.innerHTML = '<div class="mg-warn">Error: ' + escHtml(e.message) + '</div>';
  });
}

function doApply(name, selId, clnId, btn) {
  var sel = document.getElementById(selId), cln = document.getElementById(clnId);
  var host = sel ? sel.value : '';
  var clean = cln ? cln.checked : false;
  // SM266 (4): the presentation keys the operator ticked to keep.
  var panelId = selId.replace(/-target$/, '');
  var keep = [];
  var boxes = document.querySelectorAll('.' + panelId + '-keep');
  for (var i = 0; i < boxes.length; i++) if (boxes[i].checked) keep.push(boxes[i].value);
  var where = host ? ('"' + host + '"') : 'the primary site';
  var msg = 'Apply "' + name + '" to ' + where + '?'
          + (clean ? '\n\nCLEAN is on: existing content under the target is removed first.' : '')
          + (keep.length ? '\n\nKeeping this site\'s own ' + keep.join(', ') + '.' : '')
          + '\n\nA safety snapshot is taken and the change is recorded in content history.';
  var go = function(ok) {
    if (!ok) return;
    if (btn) btn.disabled = true;
    showStatus('Applying ' + name + '…');
    fetch(API + '?action=site-backup-apply', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name, host: host, clean: clean, keep_presentation: keep })
    }).then(function(r) { return r.json(); }).then(function(d) {
      if (btn) btn.disabled = false;
      if (!d.ok) { showStatus(d.error || 'Apply failed', true); return; }
      showStatus('Applied ' + name + (host ? ' to ' + host : ' to the primary site') + '.');
      // SM266 (3): the undo. The snapshot name comes back in the result and used
      // to appear only in the audit trail, so undoing meant finding the right
      // row on the Backups list and knowing it was the one. Offered here, at the
      // moment the operator can still tell whether the apply was what they meant.
      // Safe to offer because restoring is itself snapshotted.
      if (d.safety) offerUndo(d.safety, host);
      loadBackups();
    }).catch(function(e) { if (btn) btn.disabled = false; showStatus('Apply error: ' + e.message, true); });
  };
  if (typeof mgConfirm === 'function') { mgConfirm(msg, { danger: clean, ok: 'Apply' }).then(go); }
  else { go(window.confirm(msg)); }
}

function deletePackage(name, btn) {
  var msg = 'Delete the site package "' + name + '"?\n\nThis removes the portable copy only; live sites are unaffected.';
  var go = function(ok) {
    if (!ok) return;
    if (btn) btn.disabled = true;
    fetch(API + '?action=site-backup-delete', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name })
    }).then(function(r) { return r.json(); }).then(function(d) {
      if (btn) btn.disabled = false;
      if (!d.ok) { showStatus(d.error || 'Delete failed', true); return; }
      showStatus('Deleted ' + name + '.');
      loadBackups();
    }).catch(function(e) { if (btn) btn.disabled = false; showStatus('Delete error: ' + e.message, true); });
  };
  if (typeof mgConfirm === 'function') { mgConfirm(msg, { danger: true, ok: 'Delete' }).then(go); }
  else { go(window.confirm(msg)); }
}

loadBackups();
</script>
