#!/usr/bin/perl
# install.pl - lazysite installer (D021c)
#
# Upgrade-safe installer driven by release-manifest.json. Reads
# release-manifest.json at the tarball root, tracks installed
# state in {DOCROOT}/lazysite/.install-state.json, and makes
# upgrade decisions per file based on the classification bucket:
#
#
#   code: always overwritten on upgrade
#   anything else (seed and friends): overwritten only if the
#         on-disk SHA matches the state file - i.e. the operator
#         has not edited it. Only `code` is tested by name.
#
# Runtime directories come from the manifest's runtime_paths
# array. Some install steps are not manifest-expressible and stay
# imperative (cgi-bin symlinks for extension endpoints, auth
# users/groups seed, nav.conf seed, lazysite.conf conditional
# write, SGID on lazysite/).
#
# Restore via --restore extracts a backup tarball produced on a
# prior upgrade.
#
# Core-only Perl; no CPAN deps. Shells out to `tar` for backup
# creation and extraction.

use strict;
use warnings;
use File::Copy     ();
use File::Path     qw(make_path remove_tree);
use File::Find     ();
use File::Basename qw(basename dirname);
use File::Temp     qw(tempdir);
use Digest::SHA    ();
use JSON::PP       ();
use POSIX          qw(strftime);
use Getopt::Long   ();
use Cwd            qw(abs_path);
use Fcntl          qw(O_WRONLY O_APPEND O_CREAT O_EXCL);

my $STAGE_DIR = abs_path( dirname($0) );

# The channel ladder: a build's channel declares its maturity, a site's
# update_channel is the MINIMUM maturity it accepts. edge = every release
# (early testing), beta = bedded-in candidates, stable = certified customer
# rollout. Keep in sync with tools/build-manifest.pl and the CLI validators
# (the installer does not load the lib). Initialised here, ahead of the
# top-level option blocks (--channel-check runs before the sub definitions'
# region is reached at runtime).
# 'certified' (2026-08-20, ADR 0010): above stable - a stable build whose
# compliance records have been WALKED (signed declaration, restore rehearsal,
# pentest posture). The conformity gates that used to block a stable cut
# attach there instead, so stable ships supported software and certification
# is a deliberate act rather than a blocked cut.
our %CHANNEL_RANK = ( edge => 0, beta => 1, stable => 2, certified => 3, all => 0 );

# SM356: `all` is spelled out rather than reached through a `// 0` fallback. It
# meant the same thing before - and it meant it by ACCIDENT, because an
# unrecognised value fell to the same 0. A rung that is only ever reached by
# failing to recognise something cannot be told apart from a typo.
our $CHANNEL_DEFAULT = 'stable';

# SM1369 X7: the extensions this payload does not carry (absent_extensions).
our %ABSENT_EXT;

# SM1361 (rulings 201, 202): THE SHARED READ-ONLY ENGINE. A volume-hosted site
# runs in a container whose image IS this payload; the site holds only its own
# state. With --engine shared (the container's entrypoint passes it, and the
# install state remembers it) the plan lays no engine entry - nothing under
# {CGIBIN}, nothing in {DOCROOT}/../lib, tools or extensions - and the steps
# that run an installed tool run it from {ENGINE}, which is this payload. A
# host never passes it: on Hestia and the deb hosts each site keeps its own
# engine (ruling 201), which is why this is said rather than worked out from
# where the payload sits - a deb host's payload is read-only too.
our $SHARED_ENGINE = 0;

# ---------- arg parse ----------

my %opt = (
    docroot      => '',
    cgibin       => '',
    domain       => '',
    theme        => '',
    help         => 0,
    restore      => 0,
    backup       => '',
    list_backups => 0,
    dry_run      => 0,
    invoked_as   => '',
    engine       => '',
);

sub usage {
    my ($rc) = @_;
    print <<'USAGE';
Usage: install.pl --docroot PATH --cgibin PATH [options]

Install, upgrade or reinstall lazysite in-place, from the shipped
manifest. WHICH OF THE THREE IS YOURS TO SAY (--mode): this script
no longer decides from the state of the disk, because one command
that picks for itself tells the operator afterwards which one
happened. An operator-edited page is preserved on every mode;
project-owned code is overwritten.

Most operators do not run this directly - the `lazysite` command
does, and it is the one way documented:
  lazysite provision --docroot DIR --cgibin DIR
  lazysite upgrade   --docroot DIR
  lazysite reinstall --docroot DIR

Required (for install/upgrade/reinstall):
  --docroot PATH      Path to web document root
  --cgibin  PATH      Path to cgi-bin directory
  --mode    provision|upgrade|reinstall
                      What you are doing, and it is checked against
                      the site rather than assumed:
                        provision - a site that does not exist yet;
                                    refused if one is already there
                        upgrade   - move an installed site to this
                                    version; refused if nothing is
                                    installed. Already current is a
                                    no-op, not a failure.
                        reinstall - re-lay THIS version's files over a
                                    site that already has it, keeping
                                    content; refused if the versions
                                    differ

Optional:
  --domain  NAME      Domain name for lazysite.conf site_url
                      (used only when seeding a new lazysite.conf)
  --dry-run           Compute the plan without executing any
                      filesystem changes. Useful before upgrade.
  --force             Upgrade even if the site's update channel would skip this
                      release (e.g. a 'stable' site taking an 'edge' build). The
                      override is recorded in the audit log.
  --force-security    --force, for a security release only (SM1307): refused
                      unless this payload's manifest declares
                      "security_critical": true. With --channel-check, a site
                      whose channel refuses the build answers 0 (forced).
                      Recorded in the audit log as upgrade-forced.
  --channel edge|beta|stable|certified
                      Set the site's update channel (update_channel in
                      lazysite.conf) and exit - no install. The ladder is
                      edge < beta < stable < certified: a site accepts builds
                      at its own maturity or above (beta takes beta and up;
                      stable takes stable and up; edge takes everything). An
                      unrecognised value is treated as 'stable' and reported.
                      Loop over your docroots to set a whole fleet.
  --policy auto|manual
                      Set the site's update policy (update_policy in
                      lazysite.conf) and exit - no install. 'auto' lets
                      `lazysite upgrade --all` (cron-driven fleet upgrades)
                      touch this site; 'manual' (the default) leaves it to
                      the sysop.
  --site-url URL      Set the site's address (site_url in lazysite.conf) and
                      exit - no install. An absolute http(s) URL with no
                      ${...} placeholder: the address a link sent from the
                      command line (a claim link, a notice) is built on. The
                      Hestia deploy sets it on a new site.
  --restore-full FILE Restore a full-system backup (manager "full" backup) into
                      --docroot, optionally rewriting the site domain with
                      --domain NAME. The temp -> final domain migration path.
                      One command: it also lays the engine's cgi-bin entry
                      points from this release (so it needs --cgibin),
                      applies the group and modes as provision does
                      (--serving-group), and ends with the health check.
  --invoked-as CMD    How the operator reached the lazysite CLI - `lazysite`
                      when it is on PATH, `perl /path/tools/lazysite-cli.pl`
                      from an unpacked tarball. The CLI sets this; a refusal
                      spells the command it recommends with it, so the hint
                      is one the host can run. Default: lazysite.
  --help              Show this help

Maintenance modes:
  --list-backups      List available backups at
                      {docroot}/lazysite/backups/
  --restore           Restore the most recent backup
  --restore --backup PATH
                      Restore a specific backup tarball
  --verify            Is the code INSTALLED at --docroot/--cgibin actually this
                      payload's version? Reports the gap and exits non-zero if
                      it is not. Needs --docroot and --cgibin; changes nothing.
  --channel-check     Would this upgrade be SKIPPED by the site's update
                      channel? Exit 3 if yes, 0 otherwise - so a deploy can
                      bail BEFORE touching the site. Needs --docroot; reads
                      lazysite.conf and the manifest only.
  --starter           Install lazysite's own starter pages too - the demo pages,
                      the sample contact and members pages and the starter's
                      welcome page. A new site gets none of them without it
                      (SM1285): it has the system pages, the /docs manual (the
                      engine's, on every site) and a minimal home page until it
                      writes its own. On an upgrade, lays the starter pages a
                      site that declined them has not got. The choice is
                      remembered in the install state.
  --list-starter      List the site's starter pages, each as unmodified (the
                      install state's checksum, or the shipped one, still
                      matches) or edited. Needs --docroot; changes nothing.
  --remove-starter    Remove the UNMODIFIED starter pages, with their cached
                      renders; an edited one is never removed. With --dry-run,
                      says what would go and removes nothing. Needs --docroot.
  --no-starter        Accepted, and the default for a new site. On an upgrade,
                      records that the site declines the starter pages it has
                      not got; it never removes one it has.
  --health-check-by-caller
                      Do not run the health check at the end: the caller runs it. The
                      Hestia deploy passes this and runs the check as root after its
                      permission pass, where the web server group's private store
                      is readable. The report says the check was not run.
  --engine shared|copy
                      SM1361 (ruling 201): `shared` lays only the site - its
                      content, settings, templates and the manager's pages and
                      assets - and runs the engine from THIS payload, read-only:
                      nothing under --cgibin or beside the docroot (lib, tools,
                      extensions) is written. For a container whose image is
                      the payload; its entrypoint passes it. `copy`, the default,
                      lays the site's own engine copy, as every host does. The
                      choice is remembered in the install state.
  --serving-group G   The group the web server runs as. The install ends by
                      running the health check, which compares the tree against
                      this group; it defaults to www-data where that group
                      exists. Name it on a host serving under another group.
                      --restore-full takes it too.

Exit status:
  0  installed, and the site passed its own health check
  1  the install itself failed
  2  a mistake in the invocation
  3  --channel-check only: this upgrade would be skipped by the site's channel
  4  installed, and the site is NOT serviceable - the health check named a
     failure. The files are in place; `lazysite check --docroot D --fix`
     repairs what it may.

Example:
  install.pl --docroot /var/www/html --cgibin /usr/lib/cgi-bin
  install.pl --docroot /var/www/html --cgibin /usr/lib/cgi-bin --domain example.com
  install.pl --docroot /var/www/html --cgibin /usr/lib/cgi-bin --dry-run

Upgrade notes:
  Seed files you have edited (pages, docs, forms config) are
  preserved across upgrades. Code files are always refreshed.
  Pre-upgrade backups accumulate under
  {docroot}/lazysite/backups/ per backup_retention
  (lazysite.conf; default 3).
USAGE
    exit( $rc // 0 );
}

# A mistake in the INVOCATION. Named after the program, and exit 2 - the code
# every other lazysite tool uses for "you typed it wrong", where a die would
# have exited 255 and told the sysop perl had aborted.
sub _usage_error {
    my ($msg) = @_;
    print {*STDERR} "install.pl: $msg\n";
    exit 2;
}

# No args = help (matches install.sh behaviour)
usage(0) unless @ARGV;

Getopt::Long::Configure( 'no_ignore_case', 'bundling_override' );
Getopt::Long::GetOptions(
    'docroot=s'      => \$opt{docroot},
    'cgibin=s'       => \$opt{cgibin},
    'domain=s'       => \$opt{domain},
    'theme=s'        => \$opt{theme},
    'help'           => \$opt{help},
    'restore'        => \$opt{restore},
    'backup=s'       => \$opt{backup},
    'list-backups'   => \$opt{list_backups},
    'dry-run'        => \$opt{dry_run},
    'verify'         => \$opt{verify},
    'channel-check'  => \$opt{channel_check},
    'channel=s'      => \$opt{channel},
    'policy=s'       => \$opt{policy},
    'site-url=s'     => \$opt{site_url},
    'restore-full=s' => \$opt{restore_full},
    'force'          => \$opt{force},
    # SM1307: the Hestia fleet updater's --force-security reaches a site here.
    'force-security' => \$opt{force_security},
    'mode=s'         => \$opt{mode},
    'invoked-as=s'   => \$opt{invoked_as},
    # SM933 PR1: the group the web server runs as, for the post-install health
    # check. The check's own default is www-data when that group exists, which
    # is right on the platform this ships for and wrong on a host serving under
    # another group - and since the check's verdict now decides the exit status,
    # a wrong guess would turn a healthy install into a failed one. Naming it is
    # the only way the installer can be told.
    'serving-group=s' => \$opt{serving_group},
    # SM1361 (ruling 201): the container's read-only engine. See $SHARED_ENGINE.
    'engine=s' => \$opt{engine},
    # SM939 E2 / R15: no starter content. See $NO_STARTER.
    'no-starter' => \$opt{no_starter},
    # SM1285 (ruling 33): the starter pages are opt-in.
    'starter' => \$opt{starter},
    # SM1286 (ruling 34): list them, or remove the unmodified ones.
    'list-starter'   => \$opt{list_starter},
    'remove-starter' => \$opt{remove_starter},
    # SM1220: the caller runs the health check itself (the Hestia deploy, as root).
    'health-check-by-caller' => \$opt{health_check_by_caller},
) or do {
    print {*STDERR} "install.pl: unknown option (run --help for the option list)\n";
    exit 2;
};

usage(0) if $opt{help};

# SM1307: --force-security IS ONLY AS STRONG AS THE RELEASE'S OWN DECLARATION.
# It is --force - past the site's update_channel - for a payload whose manifest
# says "security_critical": true (build-manifest.pl --security-critical, which
# release.sh --security-critical passes), and refused for any other before a
# site is read, as the CLI's `upgrade --all --force-security` is. The Hestia
# updater's --force-security arrives here through the per-site deploy.
if ( $opt{force_security} ) {
    my $m = load_manifest("$STAGE_DIR/release-manifest.json");
    _usage_error( '--force-security refused: payload ' . ( $m->{version} // 'unknown' )
            . ' (channel: ' . ( $m->{channel} || 'edge' ) . ') does not declare '
            . '"security_critical": true in its release manifest. The override is only as '
            . "strong as the release's own declaration; for a routine out-of-channel "
            . 'upgrade use --force.' )
        unless $m->{security_critical};
    $opt{force} = 1;
}

if ( $opt{theme} ) {
    warn "WARNING: --theme is no longer supported. install.pl "
        . "does not fetch remote themes. Upload themes via the "
        . "manager UI at /manager/themes.\n";
}

# --- mode dispatch ---

if ( $opt{list_backups} ) {
    _usage_error('--list-backups requires --docroot') unless $opt{docroot};
    exit cmd_list_backups( $opt{docroot} );
}

if ( $opt{restore} ) {
    _usage_error('--restore requires --docroot') unless $opt{docroot};
    exit cmd_restore( \%opt );
}

if ( $opt{list_starter} || $opt{remove_starter} ) {
    _usage_error('--list-starter and --remove-starter each require --docroot') unless $opt{docroot};
    _usage_error('--list-starter and --remove-starter are one or the other')
        if $opt{list_starter} && $opt{remove_starter};
    exit cmd_starter_pages( \%opt );
}

# --channel-check: would this upgrade be SKIPPED by the site's update channel?
# Exit 3 if yes (so the deploy can bail BEFORE touching the site), 0 otherwise.
# Reads only lazysite.conf + the manifest - no file changes, no ownership needed.
if ( $opt{channel_check} ) {
    _usage_error('--channel-check requires --docroot') unless $opt{docroot};
    my $manifest = load_manifest("$STAGE_DIR/release-manifest.json");
    my $state    = load_state( state_path( $opt{docroot} ) );
    # Only an upgrade (existing install at a different version) is gated.
    if ( $state && ( $state->{version} // '' ) ne ( $manifest->{version} // '' ) ) {
        my ( $site, $problem ) = read_update_channel( $opt{docroot} );
        my $rel = $manifest->{channel} || 'edge';
        warn "channel-check: $problem\n" if defined $problem;
        if ( channel_refuses( $site, $rel ) ) {
            # SM1307: forced past the channel, and saying so - the caller
            # reports which sites a security release reached this way.
            if ( $opt{force_security} ) {
                warn "channel-check: the site's channel refuses this '$rel' build; "
                    . "--force-security overrides it (the release declares security_critical)\n";
                exit 0;
            }
            exit 3;
        }
    }
    exit 0;
}

# --channel edge|beta|stable|certified: set the site's update_channel in lazysite.conf. A
# standalone maintenance op (no install) - pins a deployment to a channel, or
# moves it back, without hand-editing the conf. To set a whole fleet, loop it over
# your docroots (lazysite has no central site registry - the host knows the sites):
#   for d in /home/*/web/*/public_html; do install.pl --channel stable --docroot "$d"; done
if ( defined $opt{channel} ) {
    _usage_error('--channel requires --docroot') unless $opt{docroot};
    exit cmd_set_channel( $opt{docroot}, $opt{channel} );
}

# --policy auto|manual: set the site's update_policy in lazysite.conf (SM139). The
# same standalone maintenance-op shape as --channel. 'auto' opts the site in to
# cron-driven fleet upgrades (`lazysite upgrade --all`); 'manual' (the default
# when the key is absent) means only a deliberate per-site upgrade touches it.
if ( defined $opt{policy} ) {
    _usage_error('--policy requires --docroot') unless $opt{docroot};
    exit cmd_set_policy( $opt{docroot}, $opt{policy} );
}

# --site-url URL: set the site's site_url in lazysite.conf (n807). The same standalone
# maintenance-op shape as --channel and --policy. A new site's conf holds the
# ${REQUEST_SCHEME}://${SERVER_NAME} template, which only a web request can expand,
# so a link built on the command line (a claim link) had no address; the Hestia
# deploy sets it to the domain it was given.
if ( defined $opt{site_url} ) {
    _usage_error('--site-url requires --docroot') unless $opt{docroot};
    exit cmd_set_site_url( $opt{docroot}, $opt{site_url} );
}

# --restore-full: restore a full-system backup (from the manager's "full" backup)
# into a docroot, optionally rewriting the site domain - the temp-domain ->
# final-domain migration path. A system-user operation: the tarball carries the
# auth secrets, so this deliberately lives in the installer, not the manager UI.
if ( defined $opt{restore_full} ) {
    _usage_error('--restore-full requires --docroot') unless $opt{docroot};
    exit cmd_restore_full( \%opt );
}

# --verify: is the INSTALLED code actually this version? (the deploy-gap detector)
if ( $opt{verify} ) {
    _usage_error('--verify requires --docroot and --cgibin')
        unless $opt{docroot} && $opt{cgibin};
    $opt{docroot} = abs_path( $opt{docroot} ) // $opt{docroot};
    $opt{cgibin}  = abs_path( $opt{cgibin} )  // $opt{cgibin};
    exit cmd_verify( \%opt );
}

# Install / upgrade path.
_usage_error('--docroot is required') unless $opt{docroot};
_usage_error('--cgibin is required')  unless $opt{cgibin};

# Absolute paths to avoid surprises when cwd is not the install root.
$opt{docroot} = abs_path( $opt{docroot} ) // $opt{docroot};
$opt{cgibin}  = abs_path( $opt{cgibin} )  // $opt{cgibin};

exit cmd_install( \%opt );

# =========================================================
# ---------- install / upgrade command ----------
# =========================================================

# The site's update channel preference, read from lazysite.conf.
#
# SM356: THE DEFAULT FAILED OPEN, IN THREE DIFFERENT WAYS.
#
# This returned 'all' - accept every build, edge included - when the conf could
# not be read, when there was no update_channel line, and when the value was not
# recognised. The third is the dangerous one: `update_channel: stabel` did not
# fail, did not warn, and did not mean stable. It meant the MOST permissive
# setting available, silently, which is the opposite of what the operator typed.
#
# The reported symptom was that an edge rollout touched sites it was not for.
# The gate was working; the default was wrong.
#
# Now: a recognised value is honoured, and everything else falls to `stable` -
# the most restrictive rung, which is the safe direction for a control whose
# failure mode is installing a pre-release build on a customer site. An
# unrecognised value is ALSO reported, in the second return value, because a
# typo silently corrected to something safe is still a setting that does not do
# what it says.
#
# Returns ( channel, problem ) - problem is undef when the value was explicit
# and recognised.
sub read_update_channel {
    my ($docroot) = @_;
    my $conf = _conf_path($docroot);
    open my $fh, '<', $conf
        or return ( $CHANNEL_DEFAULT, "cannot read $conf" );
    while ( my $l = <$fh> ) {
        next unless $l =~ /^\s*update_channel\s*:\s*(\S+)/;
        close $fh;
        my $c = lc $1;
        return ( $c, undef ) if exists $CHANNEL_RANK{$c};
        return ( $CHANNEL_DEFAULT,
            "update_channel is '$c', which is not one of "
                . join( '/', sort keys %CHANNEL_RANK )
                . " - treating this site as '$CHANNEL_DEFAULT'" );
    }
    close $fh;
    return ( $CHANNEL_DEFAULT, undef );    # absent is a policy, not a fault
}

# Would the site's channel refuse this release? 'all' (and 'edge') accept
# everything; otherwise the release must sit at the site's rung or above.
sub channel_refuses {
    my ( $site_channel, $release_channel ) = @_;

    # SM356: an unrecognised rung FAILS CLOSED on both sides. These were `// 0`,
    # which is `edge`, which accepts everything - so any value neither side
    # recognised resolved to "install it". A comparison whose unknown case is
    # the permissive one is not a gate.
    my $need = $CHANNEL_RANK{ lc( $site_channel // '' ) };
    $need = $CHANNEL_RANK{$CHANNEL_DEFAULT} unless defined $need;

    # An unrecognised RELEASE channel is treated as the least mature, so a site
    # asking for stable does not accept a build whose maturity nobody can read.
    my $got = $CHANNEL_RANK{ lc( $release_channel // 'edge' ) };
    $got = 0 unless defined $got;

    return $got < $need ? 1 : 0;
}

# Shared appender for the installer's audit events. Same file and pipe format
# as Lazysite::Audit (the installer must not load the lib - keep the two in
# sync). Robust like the lib writer: creation is umask-proof (sysopen 0664 +
# chmod, so the web-server group - inherited via the setgid logs dir - can
# append later; the field defect was a 0644 install-created file silently
# locking every CGI audit write out forever), an owned file that lost its
# group-write bit is healed before appending, and a failed write warns to
# STDERR instead of vanishing. Never dies - auditing must not break a deploy.
sub audit_append {
    my ( $docroot, $act, $target, $detail ) = @_;
    my $logdir = lazysite_dir_for($docroot) . "/logs";
    unless ( -d $logdir || mkdir $logdir ) {
        warn "audit write failed ($act): cannot create $logdir: $!\n";
        return;
    }
    for ( $target, $detail ) { $_ = defined $_ ? "$_" : ''; s/[|\r\n]+/ /g }
    my $ts   = POSIX::strftime( '%Y-%m-%dT%H:%M:%SZ', gmtime );
    my $file = "$logdir/audit.log";
    my @s    = stat $file;
    chmod 0664, $file if @s && !( $s[2] & 0020 ) && $s[4] == $>;
    my $fh;
    unless ( sysopen $fh, $file, O_WRONLY | O_APPEND | O_CREAT, 0664 ) {
        warn "audit write failed ($act): cannot append to $file: $!\n";
        return;
    }
    chmod 0664, $file unless @s;    # umask-proof the create
    my $line = "$ts | system | $act | $target |  | ok | install";
    $line .= " | $detail" if length $detail;
    print {$fh} "$line\n" or warn "audit write failed ($act): $!\n";
    close $fh;
    return;
}

# Replace one "key: value" line in the site's lazysite.conf (append when the key
# is absent). Atomic via temp + rename. Shared by --channel and --policy.
# Where a site keeps its lazysite.conf. Asked through lazysite_dir_for, never
# assembled by hand, because SM293 moved the engine tree on migrated sites.
sub _conf_path {
    my ($docroot) = @_;
    return lazysite_dir_for($docroot) . '/lazysite.conf';
}

# Every pre-upgrade backup in a site's backup directory, oldest first.
sub _backup_files {
    my ($dir) = @_;
    my @files = sort glob("$dir/lazysite-backup-*.tar.gz");
    return @files;
}

# How the install state records a file's digest.
sub _sha256_tag {
    my ($path) = @_;
    return 'sha256:' . sha256_of($path);
}

# THE conf-key writer for this file. Returns ( ok, reason ): 1 and undef on
# success, 0 and a sentence on failure, so a caller that wants to warn has the
# words and a caller that wants silence can drop them.
#
# The installer is core-Perl by design (ADR 0001) and cannot reach
# Lazysite::Manager::Common's writer, so it carries its own - one of them.
sub _write_conf_key {
    my ( $conf, $key, $value ) = @_;
    return ( 0, "No lazysite.conf at $conf - is this a lazysite docroot?" )
        unless -f $conf;
    open my $in, '<', $conf or return ( 0, "Cannot read $conf: $!" );
    my @lines = <$in>;
    close $in;

    my $found = 0;
    for my $l (@lines) {
        if ( $l =~ /^\s*\Q$key\E\s*:/ ) {
            $l     = "$key: $value\n";
            $found = 1;
            last;
        }
    }
    push @lines, "$key: $value\n" unless $found;
    return _replace_conf( $conf, \@lines );
}

# Write @$lines over $conf, atomically. Returns ( ok, reason ) like the writer
# above, which is its first caller; convert_retired_conf_keys is the second.
sub _replace_conf {
    my ( $conf, $lines ) = @_;

    # Preserve the original's mode and group across the atomic replace. The
    # temp file is born with the INVOKING user's umask and primary group, so
    # without this a site-user CLI run (e.g. a root-driven channel sweep via
    # sudo -u) silently replaced a siteuser:www-data 0664 conf with a
    # siteuser:siteuser 0644 one - and the manager (running as the web-server
    # user on a no-suexec host) could no longer save settings. chmod is always
    # ours to do (we own the temp); the chgrp is best-effort (only root or a
    # member of the target group may set it - lazysite check --fix repairs
    # anything left).
    my @orig_stat = stat $conf;
    my $tmp       = "$conf.tmp.$$";
    open my $out, '>', $tmp or return ( 0, "Cannot write $tmp: $!" );
    print {$out} @$lines;
    close $out;
    if (@orig_stat) {
        chmod $orig_stat[2] & 07777, $tmp;
        # SM215: as root (a sudo-driven update), preserve the file's OWNER too -
        # not just the group - so an upgrade never leaves a root-owned conf the web
        # user cannot rewrite. Non-root: group only (owner chown would just fail).
        chown( ( $> == 0 ? $orig_stat[4] : -1 ), $orig_stat[5], $tmp );
    }
    unless ( rename $tmp, $conf ) {
        my $why = "Cannot replace $conf: $!";
        unlink $tmp;
        return ( 0, $why );
    }
    return ( 1, undef );
}

# The maintenance-op face of the writer: takes a DOCROOT, warns the reason, and
# answers in exit-status terms (0 = ok) because --channel and --policy return
# what it gives them straight out of the process.
sub set_conf_line {
    my ( $docroot, $key, $value ) = @_;
    my ( $ok, $why ) = _write_conf_key( _conf_path($docroot), $key, $value );
    return 0 if $ok;
    warn "$why\n";
    return 1;
}

# --channel: set update_channel in the site's lazysite.conf (replace the line if
# present, else append). Standalone maintenance op.
sub cmd_set_channel {
    my ( $docroot, $value ) = @_;
    $value = lc $value;
    unless ( exists $CHANNEL_RANK{$value} ) {
        warn "--channel must be 'edge', 'beta', 'stable' or 'certified' (got '$value')\n";
        return 2;
    }
    my $rc = set_conf_line( $docroot, 'update_channel', $value );
    return $rc if $rc;

    audit_channel_set( $docroot, $value );
    info("Update channel set to '$value' for $docroot");
    return 0;
}

# --policy: set update_policy in the site's lazysite.conf (SM139). 'auto' opts the
# site in to fleet-wide `lazysite upgrade --all`; 'manual' (the absent-key default)
# leaves upgrades to the operator. Standalone maintenance op, same shape as
# --channel.
sub cmd_set_policy {
    my ( $docroot, $value ) = @_;
    $value = lc $value;
    unless ( $value eq 'auto' || $value eq 'manual' ) {
        warn "--policy must be 'auto' or 'manual' (got '$value')\n";
        return 2;
    }
    my $rc = set_conf_line( $docroot, 'update_policy', $value );
    return $rc if $rc;

    audit_policy_set( $docroot, $value );
    info("Update policy set to '$value' for $docroot");
    return 0;
}

# --site-url: set site_url in the site's lazysite.conf. Only an absolute http(s) URL
# with no placeholder and no path is taken: the value is the origin a link is built on.
sub cmd_set_site_url {
    my ( $docroot, $value ) = @_;
    $value =~ s{/+\z}{};
    unless ( $value =~ m{\Ahttps?://[A-Za-z0-9.-]+(?::[0-9]+)?\z} ) {
        warn "--site-url must be an absolute http(s) address with no path, such as https://example.com (got '$value')\n";
        return 2;
    }
    my $rc = set_conf_line( $docroot, 'site_url', $value );
    return $rc if $rc;

    audit_append( $docroot, 'site-url-set', "site_url: $value" );
    info("Site address set to '$value' for $docroot");
    return 0;
}

# Record a policy change (origin = install).
sub audit_policy_set {
    my ( $docroot, $value ) = @_;
    audit_append( $docroot, 'policy-set', "update_policy: $value" );
    return;
}

# Record a channel change (origin = install).
sub audit_channel_set {
    my ( $docroot, $value ) = @_;
    audit_append( $docroot, 'channel-set', "update_channel: $value" );
    return;
}

# --restore-full: restore a full-system backup onto a docroot, optionally
# rewriting the site domain (the temp -> final domain migration path), and leave
# a site that serves (SM1439, ruling 239): the engine's entry points laid from
# the release this runs, the tree's group and modes applied, the render caches
# cleared, and the health check run. A system-user operation.
#
# THE ENGINE IS LAID BY THE CODE PROVISION USES. The tarball carries the docroot
# only, so cgi-bin/lazysite-processor.pl and its siblings (and the lib, tools and
# extensions beside the docroot) are not in it. The plan is the install plan,
# narrowed to the engine's entries (is_engine_entry), run by execute_plan; the
# extension endpoint links, the runtime paths and the group and modes are the
# same subs an install calls. It runs BEFORE anything is extracted, so a restore
# that cannot lay the engine refuses (ruling 206) with the docroot untouched.
sub cmd_restore_full {
    my ($o)     = @_;
    my $tarball = $o->{restore_full};
    my $domain  = $o->{domain};
    my $cli     = length( $o->{invoked_as} // '' ) ? $o->{invoked_as} : 'lazysite';

    my $docroot = $o->{docroot};
    my $retry   = "$cli backups --docroot $docroot --cgibin CGIBIN --restore-full FILE"
        . ( ( defined $domain && length $domain ) ? " --domain $domain" : '' );
    unless ( length( $o->{cgibin} // '' ) ) {
        print {*STDERR} "install.pl: --restore-full needs --cgibin.\n"
            . "  The restore lays the engine's entry points (lazysite-processor.pl and the rest)\n"
            . "  there, as provision does, so that the restored site serves. Nothing was changed.\n"
            . "  Run:  $retry\n";
        return 2;
    }

    $tarball = abs_path($tarball) // $tarball;
    die "Backup '$tarball' not found\n" unless -f $tarball;

    # SM1446: a backup that did not finish is refused before anything is laid: an
    # empty claim, or an archive cut off mid-write, would restore part of a site.
    unless ( -s $tarball && system( 'gzip', '-tq', $tarball ) == 0 ) {
        print {*STDERR} "install.pl: refusing to restore: '$tarball' is not a finished backup\n"
            . "  (it is empty, or its archive stops part way). Nothing was changed.\n"
            . "  Restore a finished full backup; the manager's Backups page lists only those.\n";
        return 1;
    }

    # A symlink for lazysite/ or for the two directories the mode and ownership steps
    # name inside it is refused before anything is made, laid or extracted (ruling 206):
    # the setgid chmod and the root ownership repair would follow it out of the site.
    if ( my $bad = linked_site_dir($tarball) ) {
        print {*STDERR} "install.pl: refusing to restore: the backup holds '$bad' as a symlink.\n"
            . "  The restore sets modes and, as root, ownership on that directory, and a link would\n"
            . "  carry them to wherever it points. Nothing was changed.\n"
            . "  A real lazysite/ tree is a directory: take the backup again from the site, or\n"
            . "  repair the archive, then run the restore again.\n";
        return 1;
    }
    make_path($docroot) unless -d $docroot;
    $docroot = abs_path($docroot) // $docroot;
    make_path( $o->{cgibin} ) unless -d $o->{cgibin};
    $o->{docroot} = $docroot;
    $o->{cgibin}  = abs_path( $o->{cgibin} ) // $o->{cgibin};
    $retry =~ s/CGIBIN/$o->{cgibin}/;

    info("Restoring full-system backup into $docroot");
    info("  from: $tarball");

    # ---- the engine, from this release ----
    my $manifest = eval { load_manifest("$STAGE_DIR/release-manifest.json") };
    my $why      = $@;
    my $refusal  = select_engine( $o, undef );
    my %subs     = placeholders( $docroot, $o->{cgibin} );
    if ( !$manifest || defined $refusal ) {
        $why =~ s/\s+\z//;
        print {*STDERR} 'install.pl: cannot lay the engine\'s entry points: '
            . ( $manifest ? $refusal : "this payload has no usable release manifest ($why)\n" )
            . "  Nothing was extracted. Run the restore from an unpacked release tarball:\n"
            . "    $retry\n";
        return 1;
    }
    %ABSENT_EXT = absent_extensions($manifest);
    load_install_dirs( $manifest, \%subs );
    my $engine = { %$manifest, files => [ grep { is_engine_entry($_) } @{ $manifest->{files} } ] };
    my $plan = compute_plan( $engine, undef, \%subs );
    my $engine_files;
    my $laid = eval {
        ($engine_files) = execute_plan($plan);
        link_extension_endpoints( $o->{cgibin}, \%subs );
        1;
    };
    unless ($laid) {
        my $err = $@;
        $err =~ s/\s+\z//;
        print {*STDERR} "install.pl: cannot lay the engine's entry points under $o->{cgibin}: $err\n"
            . "  Nothing was extracted. Make that directory writable by this user, then run:\n"
            . "    $retry\n";
        return 1;
    }
    info('  engine:    laid the entry points from this release');

    # SM268 H16: was missing --no-same-permissions, so as ROOT this restored
    # setuid bits straight out of the tarball. safe_tar_extract also vets the
    # member names for traversal before writing anything.
    my $rc = safe_tar_extract( $tarball, $docroot );
    die "tar extraction failed (rc=$rc)\n" if $rc != 0;

    my $conf = _conf_path($docroot);
    die "Restored tree has no lazysite/lazysite.conf - not a full backup?\n"
        unless -f $conf;

    if ( defined $domain && length $domain ) {
        my ($set_ok) = _write_conf_key( $conf, 'domain', $domain );
        warn "Could not set domain in $conf\n" unless $set_ok;
        info("Set site domain to: $domain");
    }

    # Drop generated HTML caches so pages re-render (new domain, fresh mtimes).
    my $cache = lazysite_dir_for($docroot) . "/cache";
    File::Path::remove_tree($cache) if -d $cache;

    # The tar carries no modes (--no-same-permissions) and leaves out the caches
    # and backups, so the tree gets what an install gives it: the runtime paths,
    # then the group-write bits, store modes and setgid.
    create_runtime_paths( $manifest->{runtime_paths} || [], \%subs, 'fresh' );
    apply_site_modes( $docroot, $manifest, \%subs, 'fresh' );

    # The install state must say what is on disk (ruling 206). The backup's state
    # records the backup's version and the hashes of ITS engine files, so a later
    # upgrade would read the engine laid above as edited. The engine entries and the
    # version are the plan just executed, written by write_state as an install writes
    # them; the backup's entries for seed and content files stay, so an edited seed is
    # still never clobbered.
    my $state_path = state_path($docroot);
    my $old        = load_state($state_path) || {};
    $main::NO_STARTER = 1 if ( $old->{starter} // '' ) eq 'none';
    %main::DIRS_LEFT  = ref $old->{dirs_left} eq 'HASH' ? %{ $old->{dirs_left} } : ();
    my @once = ref $old->{once} eq 'ARRAY' ? @{ $old->{once} } : ();
    my %files = ( %{ ref $old->{files} eq 'HASH' ? $old->{files} : {} }, %{ $engine_files || {} } );
    write_state( $state_path, $manifest->{version}, \%files, \@once );

    audit_full_restore( $docroot, $tarball, $domain );
    info('Full restore complete.');
    return run_health_check($o);
}

# The directories --restore-full's mode and ownership steps walk into by name (SM1439):
# lazysite/ itself, and the auth and forms stores inside it. Their members, read from the
# archive's own listing before anything is extracted. Returns the first one the archive
# holds as a symlink or hard link, else undef.
sub linked_site_dir {
    my ($tarball) = @_;
    my %named = map { $_ => 1 } qw(lazysite lazysite/auth lazysite/forms);
    open my $fh, '-|', 'tar', 'tvzf', $tarball or die "Cannot list $tarball\n";
    my $bad;
    while ( my $line = <$fh> ) {
        chomp $line;
        next unless $line =~ /\A[lh]/;
        my ($name) = $line =~ m{ \A \S+ \s+ \S+ \s+ \d+ \s+ \S+ \s+ \S+ \s+ (.*?) (?: [ ] (?: -> | link [ ] to ) [ ] .* )? \z }x;
        next unless defined $name;
        $name =~ s{\A(?:\./|/)+}{};
        $name =~ s{/+\z}{};
        if ( $named{$name} ) { $bad = $name; last }
    }
    close $fh;
    return $bad;
}

# Record a full-system restore (origin = install).
sub audit_full_restore {
    my ( $docroot, $tarball, $domain ) = @_;
    ( my $base = $tarball ) =~ s{.*/}{};
    my $target = "full restore from $base"
        . ( ( defined $domain && length $domain ) ? " -> domain $domain" : '' );
    audit_append( $docroot, 'full-restore', $target );
    return;
}

# What the channel gate needs to decide: the site's rung, the release's rung,
# and whether the first refuses the second. Reports an unrecognised conf value
# on the way past (SM356), which is why it is one call and not three.
sub channel_verdict {
    my ( $docroot, $manifest ) = @_;
    my ( $site,    $problem )  = read_update_channel($docroot);
    my $rel = $manifest->{channel} || 'edge';
    info("NOTE: $problem") if defined $problem;
    return ( $site, $rel, channel_refuses( $site, $rel ) );
}

# The channel gate's two outcomes, which wrote the same sentence: an upgrade the
# site's channel refused ('upgrade-skipped') and one --force pushed through
# anyway ('upgrade-forced', which adds the override clause).
sub audit_channel_outcome {
    my ( $docroot, $act, $from, $to, $rel_channel, $site_channel, $extra ) = @_;
    audit_append( $docroot, $act,
        "$from -> $to (release channel: $rel_channel; site channel: "
            . ( $site_channel // 'stable' )
            . ( $extra        // '' ) . ")" );
    return;
}

sub audit_install_event {
    my ( $docroot, $mode, $from, $to, $detail ) = @_;
    my $act = $mode eq 'fresh' ? 'installed'
        : $mode eq 'upgrade' ? 'upgraded'
        :                      'reinstalled';
    my $target = ( $mode eq 'upgrade' && defined $from ) ? "$from -> $to" : $to;
    audit_append( $docroot, $act, $target, $detail );
    return;
}

# SM939 E2 / R15: SKIP LAZYSITE'S OWN STARTER CONTENT.
#
# A fresh install puts the demo pages and ~70 docs pages on the owner's domain,
# publicly served and in the sitemap. Right for a site that IS lazysite's
# documentation, someone else's content on anybody else's - and removing it
# afterwards is seventy-odd deletes to undo something the install did on
# purpose. The ruling keeps today's default and adds this opt-out.
#
# WHAT counts as starter content is declared once, in classification.json's
# `starter_content`, and arrives here as a `starter` flag on manifest entries.
#
# THE CHOICE IS REMEMBERED. docs/ is bucket `code`, so on an upgrade every docs
# file not yet tracked in the state would be planned as a fresh install - the
# opt-out would last exactly until the first upgrade. So the state records
# `starter: none` and every later run honours it, with or without the flag.
#
# ONLY UNTRACKED FILES ARE SKIPPED. A site that already has the docs keeps them
# and keeps getting their updates; this flag cannot delete content.
#
# Declared here, above every sub that reads them, and WITHOUT a file-scope
# assignment: top-level code below `exit cmd_install(...)` never runs, so an
# initialiser there would be a promise the program does not keep.
our ( $NO_STARTER, $STARTER_SKIPPED, %STARTER_SKIPPED_URL );

# SM933 A5 / R16: THE MODE THE INSTALLER ACTUALLY LEFT on each directory it
# created, as opposed to the mode the model declares (`dirs`).
#
# `check --fix` declines to set any bit but group-write on a declared directory
# (SM274), because it cannot tell drift from a sysop's deliberate choice - and
# so a fresh install could not reach a clean report from its own output (R3).
# This record is what tells the two apart: a directory whose mode is STILL
# exactly what the installer left is the installer's own output, untouched since,
# and --fix may bring it to the declared mode. A directory whose mode has moved
# since was changed by somebody, and stays theirs.
#
# How the installer can leave a mode other than the one it declares: a chmod by
# an account that is not in the directory's group drops setgid silently (Linux
# clears S_ISGID for a caller outside the group), which is exactly the case
# where A2's regroup could not be applied.
#
# Recorded ONLY on creation and carried forward from the previous state, so a
# directory that pre-dates the installer is never claimed as its output.
our %DIRS_LEFT;

sub cmd_install {
    my ($o) = @_;

    my $manifest = load_manifest("$STAGE_DIR/release-manifest.json");
    info("Installer: lazysite $manifest->{version}");

    my $state_path = state_path( $o->{docroot} );
    my $state      = load_state($state_path);

    if ( defined( my $why = select_engine( $o, $state ) ) ) {
        print {*STDERR} $why;
        return 2;
    }

    # SM939 E2: the flag, or a choice an earlier run recorded.
    # SM933 A5: carried forward - a directory created by an earlier run is still
    # that run's output.
    %DIRS_LEFT = ( ref $state eq 'HASH' && ref $state->{dirs_left} eq 'HASH' )
        ? %{ $state->{dirs_left} }
        : ();


    # SM892 U2: THE OPERATOR SAYS WHICH, AND THIS CHECKS THEM.
    #
    # This block used to CHOOSE the mode from the state on disk: no state meant
    # fresh, same version meant reinstall, anything else meant upgrade. So one
    # command did three jobs and the operator found out afterwards which one
    # had happened - the V3 walk ran the documented command on a running site
    # and was told "A fresh install has NO accounts".
    #
    # Ruled 2026-09-15: "One place for install, and another for upgrade,
    # because they should be purposefully chosen." The classifier is still
    # here, and it is still the same three conditions - what changed is that it
    # now answers "is that what this is?" instead of "what shall I call this?",
    # and a mismatch is a refusal that names the right command.
    my ( $mode, $refusal, $noop ) = declared_mode( $o, $state, $manifest );
    if ( defined $refusal ) {
        print {*STDERR} $refusal;
        return 2;
    }
    if ( defined $noop ) {
        info($noop);
        return 0;
    }

    info("Mode: $mode");

    # SM939 E2: the flag, or a choice an earlier run recorded.
    # SM1285 (ruling 33): and a NEW site declines them unless --starter asks.
    # A site with no recorded choice was installed when they came by default,
    # so it keeps the behaviour it was installed with; --starter on a site that
    # declined them lays them, and drops the recorded `none`.
    $NO_STARTER = $o->{starter} ? 0
        : ( $mode eq 'fresh'
            || $o->{no_starter}
            || ( ref $state eq 'HASH' && ( $state->{starter} // '' ) eq 'none' ) ) ? 1
        : 0;
    info("  docroot: $o->{docroot}");
    info("  cgibin:  $o->{cgibin}");
    if ( $mode ne 'fresh' ) {
        info("  from:    $state->{version}");
        info("  to:      $manifest->{version}");
    }

   # Upgrade channel policy: a site's update_channel is the minimum maturity it
   # accepts on the edge < beta < stable < certified ladder - a 'stable' site refuses beta
   # and edge UPGRADES, a 'beta' site refuses edge ones. This is how a
   # not-yet-bedded-in build is kept off customer sites. Fresh installs and
   # reinstalls are the sysop's explicit choice and are never gated. The
   # skip is a clean no-op (exit 3, not an error) and is recorded in the
   # site's audit log.
    if ( $mode eq 'upgrade' && !$o->{force} ) {
        # SM356: a value nobody recognised used to become the most permissive
        # setting in silence. It now becomes the most restrictive one and SAYS
        # SO (channel_verdict reports it) - a typo corrected to something safe
        # is still a setting that does not do what the sysop wrote.
        my ( $site_channel, $release_channel, $refuses )
            = channel_verdict( $o->{docroot}, $manifest );
        if ($refuses) {
            info( "Upgrade SKIPPED: this site is on the '$site_channel' update channel and "
                    . "$manifest->{version} is an '$release_channel' build. No changes made. "
                    . "Use --force to install it anyway." );
            audit_channel_outcome( $o->{docroot}, 'upgrade-skipped',
                $state->{version}, $manifest->{version}, $release_channel,
                $site_channel );
            return 3;
        }
    }
    elsif ( $mode eq 'upgrade' && $o->{force} ) {
        # --force: install regardless of the site's update channel (a deliberate
        # operator override for an out-of-channel build). Recorded in the audit log;
        # the normal upgrade event is still logged when the install completes.
        my ( $site, $rel, $refuses ) = channel_verdict( $o->{docroot}, $manifest );
        if ($refuses) {
            my $how = $o->{force_security}
                ? '--force-security, the release declares security_critical'
                : '--force';
            info( "$how: installing '$rel' build $manifest->{version} over the "
                    . "site's '$site' channel policy (sysop override)." );
            audit_channel_outcome( $o->{docroot}, 'upgrade-forced',
                $state->{version}, $manifest->{version}, $rel, $site,
                ( $o->{force_security} ? '; --force-security override (security_critical release)' : '; --force override' ) );
        }
    }

    my %subs = placeholders( $o->{docroot}, $o->{cgibin} );

    # ---- extensions this payload does not carry (SM1369 X7) ----
    %ABSENT_EXT = absent_extensions($manifest);
    if ( defined( my $why = refuse_absent_extensions( $o->{docroot} ) ) ) {
        print {*STDERR} $why;
        return 2;
    }
    info( '  not in this payload, left out: ' . join( ', ', sort keys %ABSENT_EXT ) )
        if %ABSENT_EXT;

    # ---- plan ----
    my $plan = compute_plan( $manifest, $state, \%subs );
    if ( $o->{dry_run} ) {
        print_plan( $plan, $manifest, \%subs );
        info("--dry-run: no changes made.");
        return 0;
    }

    # ---- directory model ----
    # Must precede anything that creates a directory. Empty (older payload)
    # leaves install_file on its historical bare-make_path behaviour.
    load_install_dirs( $manifest, \%subs );

    # ---- runtime paths ----
    # SM246: BEFORE the backup, not after. lazysite/backups is a runtime path
    # the CGI writes (Manager::Backups saves snapshots through the manager), and
    # the backup step below used to create it first with a bare make_path - so
    # on an upgrade run as root it landed at the umask default, root-owned and
    # not group-writable, and the manager's own backup action then failed with a
    # permission error on a directory the installer had made. Creating the
    # declared paths first means the model's mode is the one that takes effect.
    # create_backup archives an explicit file list from the install state, so
    # this ordering cannot change what a backup contains.
    create_runtime_paths( $manifest->{runtime_paths} || [], \%subs, $mode );

    # ---- backup (upgrade or reinstall only) ----
    my $backup_path;
    if ( $mode ne 'fresh' ) {
        my $backup_dir = lazysite_dir_for( $o->{docroot} ) . "/backups";
        # Normally already created above from the model. Retained for a payload
        # whose manifest predates the declaration, which must install as before.
        make_path($backup_dir) unless -d $backup_dir;
        $backup_path = create_backup(
            $state, $backup_dir, $state_path, $manifest->{version},
        );
        info("Backup: $backup_path");
    }

    # ---- execute plan ----
    my ( $state_files, $plan_stats, $warnings ) = execute_plan($plan);

    # ---- imperative post-steps ----
    post_install_steps( $o, $manifest, \%subs, $state_files, $mode, $plan_stats );

    # ---- integrity check ----
    # The code we just installed must match the manifest, so the version we are
    # about to stamp truthfully reflects the RUNNING code (a partial deploy would
    # otherwise report the new version with stale code).
    my @verr = verify_code_files( $manifest, \%subs );
    if (@verr) {
        push @$warnings, "INTEGRITY: " . scalar(@verr)
            . " code file(s) do NOT match the manifest after install - the"
            . " reported version may not reflect the running code: "
            . join( '; ', @verr );
        info( "WARNING: post-install verification found "
                . scalar(@verr) . " code-file mismatch(es) - run --verify" );
    }

    # ---- the handler contract (SM842) ----
    #
    # Once, on an upgrade or reinstall: bring the site's old delivery shapes -
    # inline form targets, webhook and db handlers, connector schedules - to the
    # one shape the new engine reads. It runs AFTER the integrity check, so the
    # code converting the site is the code that was just verified, and it runs
    # the INSTALLED tool as a separate process, because this installer must not
    # load the lib (SM767: it runs from a tarball that may not carry one). What
    # it changed is printed; what it could not convert is a warning in the
    # summary, because a form that no longer delivers must not hide behind a
    # finished upgrade.
    if ( $mode ne 'fresh' ) {
        my ( $ok, $why ) = run_handler_conversion( $o->{docroot}, \%subs );
        push @$warnings, 'HANDLERS: the SM842 conversion did not finish cleanly ('
            . $why . ') - see the lines above, and run lazysite-handlers.pl convert '
            . '--docroot ' . $o->{docroot} . ' as the site user once they are resolved'
            unless $ok;

        # N13-30: and the lazysite.conf keys the engine stopped reading.
        my ( $changed, $warn, $err ) = convert_retired_conf_keys( _conf_path( $o->{docroot} ) );
        info("  conf:      $_") for @$changed;
        push @$warnings, @$warn;
        push @$warnings, "CONF: could not convert the retired lazysite.conf keys ($err)" if $err;
    }

    # ---- invalidate rendered HTML (SM413) ----
    #
    # On an UPGRADE only: a fresh install has nothing rendered yet, and running
    # it there would report a number that means nothing. The pages re-render on
    # next request, so the cost is one render per page actually visited rather
    # than a rebuild of the whole site at upgrade time.
    if ( $mode eq 'upgrade' ) {
        my $dropped = invalidate_rendered_html( $o->{docroot} );
        info( "Invalidated $dropped rendered page(s) - they re-render on next"
                . " request, so the new build is what visitors get" )
            if $dropped;
    }

    # ---- one-time steps (SM798) ----
    #
    # A step the site gets ONCE, recorded by name in the install state, so an
    # operator's later choice is never undone by the next upgrade. The name is
    # the marker rather than a version comparison: a site reinstalled at the
    # version that introduced a step must not be re-stepped.
    #
    # login-rate-limit-on: the login rate limiter became an extension, and the
    # registry lists what is ON - so without this, a fresh site would start
    # with no rate limiting and every upgraded site would lose it (ruled
    # 2026-09-11: on by default). Listed on a fresh install and on the first
    # upgrade that knows about it; switched off afterwards, it stays off.
    my @once = ( $state && ref $state->{once} eq 'ARRAY' ) ? @{ $state->{once} } : ();

    # extensions-rename (SM1142): before the step below, which writes into the
    # list this converts.
    unless ( grep { $_ eq 'extensions-rename' } @once ) {
        my ( $changed, $warn ) = extensions_rename( $o->{docroot}, $o->{cgibin}, \%subs );
        _drop_old_dir_orphans( $plan_stats, $warnings, \%subs );
        info("  extensions: $_") for @$changed;
        $plan_stats->{extensions_rename} = $changed;
        push @$warnings, @$warn;
        push @once,      'extensions-rename' unless @$warn;
    }

    unless ( grep { $_ eq 'login-rate-limit-on' } @once ) {
        my ( $added, $err ) = enable_extension_in_conf( _conf_path( $o->{docroot} ),
            'extensions/login-rate-limit.pl' );
        if ( defined $err ) {
            push @$warnings, "RATE LIMIT: could not switch the login rate limit extension on ($err) - "
                . 'switch it on in the manager\'s extensions list, or this site has no login rate limiting';
        }
        else {
            info('  conf:      switched on the login rate limit extension (SM798)') if $added;
            push @once, 'login-rate-limit-on';
        }
    }

    # address-profiles-converted (SM1345): each address list becomes an address
    # profile of the same name (convert_address_profiles_store, above), and the
    # site's template calls take the new method names (rewrite_template_calls).
    # On every mode: a new site has nothing to convert and records the step; a
    # site whose old store will not convert is told, and tried again at the next
    # upgrade.
    unless ( grep { $_ eq 'address-profiles-converted' } @once ) {
        my ( $changed, $warn, $done ) = convert_address_profiles_store( $o->{docroot} );
        my ( $tchanged, $twarn ) = rewrite_template_calls( $o->{docroot} );
        info("  auth:      $_") for @$changed;
        info("  template:  $_") for @$tchanged;
        push @$warnings, @$warn, @$twarn;
        push @once, 'address-profiles-converted' if $done && !@$twarn;
    }

    # ---- the extension hook index (SM1369 X1) ----
    #
    # On every install, after the steps above have settled which extensions are
    # on: the new release's descriptors may declare hooks, or stop declaring
    # them, so the index is rebuilt from them. The INSTALLED code does it, as a
    # separate process, for the reason the handler conversion gives. A site whose
    # extensions declare no hooks gets no index and nothing is printed.
    #
    # X2 (ruling 166): a FRESH install builds it too, the same call. The index
    # carries the capabilities and actions the installed extensions declare, so
    # a new site without one could not grant them until its first upgrade or
    # toggle.
    {
        my ( $ok, $why ) = run_hook_index_build( $o->{docroot}, \%subs );
        push @$warnings, 'HOOKS: the extension hook index was not '
            . ( $mode eq 'fresh' ? 'built' : 'rebuilt' ) . ' (' . $why . ') - '
            . ( $mode eq 'fresh' ? ''      : 'the previous one stands; ' )
            . 'enable or save an extension in the manager to rebuild it'
            unless $ok;
    }

    # ---- the declared capabilities' top-up (SM1369 X2, ruling 167) ----
    #
    # On an upgrade or reinstall, after the index above: a capability an
    # extension carved out of a core one (ruling 71's manage_odoo, from
    # manage_connectors) is topped up for every group holding the one it came
    # from, where the group has not decided it - a 0 an operator wrote stays.
    # The users tool does it on next use as well (SM645's trigger); this is so
    # a site nobody touches after the upgrade keeps every group's reach. The
    # INSTALLED tool runs it, as the site user. One line names the groups it
    # topped up; nothing is printed when none.
    if ( $mode ne 'fresh' ) {
        my ( $ok, $why ) = run_capability_top_up( $o->{docroot}, \%subs );
        push @$warnings, 'GROUPS: the declared capabilities were not topped up (' . $why . ') - '
            . 'they are topped up the next time the site\'s accounts are touched, or run '
            . 'lazysite-users.pl --docroot ' . $o->{docroot} . ' capability-top-up as the site user'
            unless $ok;
    }

    # ---- write new state ----
    write_state( $state_path, $manifest->{version}, $state_files, \@once );

    # ---- audit the deploy (SM117) ----
    # A fresh install records the channel it was seeded with (post_install_steps
    # writes update_channel into a seeded lazysite.conf) in the install event's
    # detail field, matching the standalone --channel audit's wording - so a
    # provision-time channel choice is on the trail, not just later switches.
    audit_install_event(
        $o->{docroot}, $mode,
        ( defined $state ? $state->{version} : undef ),
        $manifest->{version},
        $mode eq 'fresh'
        ? 'update_channel: ' . ( read_update_channel( $o->{docroot} ) )[0]
        : undef
    );

    # ---- retention ----
    if ( $mode ne 'fresh' ) {
        my $retention = read_retention( $o->{docroot} );
        apply_retention( lazysite_dir_for( $o->{docroot} ) . "/backups", $retention );
    }

    # ---- summary ----
    print_summary( $mode, $manifest, $plan_stats, $backup_path, $warnings );
    print_dep_check();
    print_next_steps( $o->{docroot} );

    # ---- health ----
    return run_health_check($o);
}

# SM842: run the installed handler tool's conversion as the site's owner.
# Returns ( ok, why ). A payload without the tool (an older one) has nothing
# to convert. As root the child becomes the docroot's owner first, because the
# tool refuses to write a site tree as root (SM139) and root-owned handler
# files are what stops the manager saving them afterwards.
sub run_handler_conversion {
    my ( $docroot, $subs ) = @_;
    my $tool = resolve_placeholders( '{ENGINE}/tools/lazysite-handlers.pl', $subs );
    return ( 1, 'no handler tool in this payload' ) unless -f $tool;
    info('Handlers: converting to the handler contract (SM842)');
    my $pid = fork;
    return ( 0, "cannot fork: $!" ) unless defined $pid;
    if ( !$pid ) {
        if ( $> == 0 ) {
            my @st = stat $docroot;
            if ( @st && $st[4] != 0 ) {
                POSIX::setgid( $st[5] );
                POSIX::setuid( $st[4] );
            }
        }
        exec( $^X, $tool, 'convert', '--docroot', $docroot ) or POSIX::_exit(127);
    }
    waitpid $pid, 0;
    my $rc = $? >> 8;
    return ( 1, '' ) if $rc == 0;
    return ( 0, $rc == 1 ? 'something was left unconverted' : "the tool exited $rc" );
}

# SM1369 X1: rebuild the extension hook index with the installed lib, as the
# site's owner when run as root (as run_handler_conversion). Its lines (an
# extension indexed or refused) are passed through. Returns ( $ok, $why ).
sub run_hook_index_build {
    my ( $docroot, $subs ) = @_;
    my $lib = resolve_placeholders( '{ENGINE}/lib', $subs );
    return ( 1, 'no lib in this payload' ) unless -f "$lib/Lazysite/Extensions/Hooks.pm";
    my $pid = fork;
    return ( 0, "cannot fork: $!" ) unless defined $pid;
    if ( !$pid ) {
        if ( $> == 0 ) {
            my @st = stat $docroot;
            if ( @st && $st[4] != 0 ) {
                POSIX::setgid( $st[5] );
                POSIX::setuid( $st[4] );
            }
        }
        exec( $^X, "-I$lib", '-MLazysite::Manager::Extensions', '-e',
            'exit Lazysite::Manager::Extensions::rebuild_hook_index_main(@ARGV)', $docroot )
            or POSIX::_exit(127);
    }
    waitpid $pid, 0;
    my $rc = $? >> 8;
    return ( 1, '' ) if $rc == 0;
    return ( 0, $rc == 1 ? 'the index could not be written' : "the build exited $rc" );
}

# SM1369 X2 (ruling 167): run the installed users tool's capability-top-up as
# the site's owner (as run_handler_conversion). Its one line, when it topped a
# group up, is printed as the step's. A payload without the tool has nothing to
# top up. Returns ( $ok, $why ).
sub run_capability_top_up {
    my ( $docroot, $subs ) = @_;
    my $tool = resolve_placeholders( '{ENGINE}/tools/lazysite-users.pl', $subs );
    return ( 1, 'no users tool in this payload' ) unless -f $tool;
    my $pid = open my $fh, '-|';
    return ( 0, "cannot fork: $!" ) unless defined $pid;
    if ( !$pid ) {
        if ( $> == 0 ) {
            my @st = stat $docroot;
            if ( @st && $st[4] != 0 ) {
                POSIX::setgid( $st[5] );
                POSIX::setuid( $st[4] );
            }
        }
        open( STDERR, '>&', \*STDOUT ) or POSIX::_exit(127);
        exec( $^X, $tool, '--docroot', $docroot, 'capability-top-up' ) or POSIX::_exit(127);
    }
    my @lines = <$fh>;
    close $fh;
    my $rc = $? >> 8;
    chomp @lines;
    if ( $rc == 0 ) {
        info("  groups:    $_") for grep { /\Atopped up: / } @lines;
        return ( 1, '' );
    }
    info("  groups:    $_") for @lines;
    return ( 0, "the users tool exited $rc" );
}

# old-address-name: begin (SM1343, the upgrade converts the store by its old name)
# SM1345 (0.16.5, rulings 56-57): ADDRESS LISTS BECOME ADDRESS PROFILES, ONCE.
#
# Until 0.16.5 lazysite/auth/address-lists.json held named address lists, each an
# allow list or a deny list for life. The engine now reads address-profiles.json:
# the same names and entries with no kind, because every rule that names one says
# whether it allows or denies it (`addresses` / `addresses_deny`, and the manager's,
# sign-in's and a session binding's `_deny` keys). Every place a rule names a list
# already names it in the slot its kind meant (the saves refused the other one,
# SM1189), so converting the STORE is the whole conversion: no rule is rewritten
# and every use keeps its effect - an allow list's uses are Allow uses, a deny
# list's Deny uses.
#
# Text in, text out (the installer loads no Lazysite module, SM767): the old file
# is decoded with JSON::PP, each record loses its `kind`, the profiles are written
# beside it with the old file's mode and owner, and only then is the old file
# renamed to address-lists.json.converted, a record of what it held. Idempotent: no
# old file, nothing to do. It never overwrites a profile store that is already
# there (the site has both: told, and left for the operator to compare). An old
# file that does not decode is left where it is, so the engine keeps refusing every
# rule that names a profile (it reads an unconverted site as a fault, the SM1024
# rule) rather than meeting an empty store whose deny rules would block nobody; the
# summary says so and the next upgrade tries again.
#
# Returns ( \@changed, \@warnings, $done ): $done is true when the store is
# converted or there was nothing to convert, so the once-step is recorded.
sub convert_address_profiles_store {
    my ($docroot) = @_;
    my $auth      = lazysite_dir_for($docroot) . '/auth';
    my $old       = "$auth/address-lists.json";
    my $new       = "$auth/address-profiles.json";
    return ( [], [], 1 ) unless -e $old;
    if ( -e $new ) {
        return ( [], [ "ADDRESS PROFILES: both $old and $new exist. The profiles are what the "
                    . 'engine reads; the lists were left as they are. Compare the two, then delete '
                    . 'address-lists.json (SM1345)' ], 1 );
    }
    my $raw = do { local $/; open my $fh, '<:raw', $old or return ( [], [ "ADDRESS PROFILES: cannot read $old ($!) - "
                    . 'every rule that names an address profile refuses until it is converted; run the upgrade '
                    . 'again as the site user or root (SM1345)' ], 0 ); <$fh> };
    my $lists = eval { JSON::PP::decode_json( $raw // '' ) };
    unless ( ref $lists eq 'HASH' ) {
        return ( [], [ "ADDRESS PROFILES: $old does not decode as a JSON object, so it was not converted - "
                    . 'every rule that names an address profile refuses until it is repaired and the upgrade '
                    . 'is run again (SM1345)' ], 0 );
    }
    my ( %profiles, %kind );
    for my $name ( sort keys %$lists ) {
        my $rec = $lists->{$name};
        unless ( ref $rec eq 'HASH' ) { $profiles{$name} = $rec; next } # the engine skips it, as before
        my %p = %$rec;
        $kind{$name}     = delete $p{kind} // '';
        $profiles{$name} = \%p;
    }
    my @st  = stat $old;
    my $tmp = "$new.tmp.$$";
    open my $out, '>:raw', $tmp
        or return ( [], ["ADDRESS PROFILES: cannot write $tmp ($!) - the lists were not converted (SM1345)"], 0 );
    print {$out} JSON::PP->new->canonical->pretty->encode( \%profiles );
    close $out;
    if (@st) {
        chmod $st[2] & 07777, $tmp;
        chown( ( $> == 0 ? $st[4] : -1 ), $st[5], $tmp );
    }
    unless ( rename $tmp, $new ) {
        my $why = $!;
        unlink $tmp;
        return ( [], ["ADDRESS PROFILES: cannot write $new ($why) - the lists were not converted (SM1345)"], 0 );
    }
    rename $old, "$old.converted";
    my @names = sort keys %profiles;
    my @changed = ( 'converted ' . scalar(@names) . ' address list(s) to address profiles of the same names'
            . ( @names ? ': ' . join( ', ', map { length( $kind{$_} // '' ) ? "$_ (was $kind{$_})" : $_ } @names ) : '' )
            . '; every rule keeps its effect (SM1345)' );
    return ( \@changed, [], 1 );
}
# SM1345 (ruling 105): THE TEMPLATE TEST IS RENAMED WITH THE PROFILES. A site's
# `visitor.in_list(...)` and `visitor.in_any(...)` become `visitor.in_profile(...)`
# and `visitor.in_any_profile(...)`, in every file Template Toolkit reads for it:
# the pages (TT runs in a page body), the layouts, themes and templates under the
# lazysite directory, and the private store. The engine knows only the new names
# (no alias), so a call left behind is an unknown method and false; `lazysite
# check` names any that is. Each file changed is reported. Written as the conf is:
# the original's mode and owner kept, temp and rename. The runtime stores
# (backups, cache, logs, auth, forms) are not walked: they hold no template.
#
# Returns ( \@changed, \@warnings ): @changed is one line per file rewritten. The
# pattern is written in the sub: a file-scoped `my` is still empty when the install
# runs (the main body calls this before the line that would set it).

sub rewrite_template_calls {
    my ($docroot) = @_;
    ( my $d = $docroot ) =~ s{/+\z}{};
    my $lz   = lazysite_dir_for($d);
    my $priv = dirname($d) . '/' . basename($d) . '-lazysite-private';
    my %skip = map { ( "$lz/$_" => 1 ) } qw(backups cache logs auth forms sessions tmp);
    my ( %seen, @files, %unread );

    # SM1380: A DIRECTORY THE WALK CANNOT READ IS SAID ONCE, IN THE SUMMARY. File::Find
    # warns "Can't opendir(DIR): Permission denied" and carries on, so an upgrade run as
    # a user that cannot read part of the private store (<private>/sites on the 0.16.5
    # edge deploy) printed raw Perl warnings and left that directory's old calls
    # unrenamed with nothing in the summary. The walk's warnings are collected, as
    # lazysite-check.pl's find_noting does (Q16g), and become one ADDRESS PROFILES
    # warning; the step is then not recorded, so the next upgrade tries again.
    local $SIG{__WARN__} = sub {
        my ($m) = @_;
        if ( $m =~ /\ACan't opendir\((.*?)\): ([^\n]*)/
            || $m =~ /\ACan't stat (.*?): ([^\n]*)/
            || $m =~ /\ACan't cd to (.*?): ([^\n]*)/ )
        {
            $unread{$1} //= $2;
            return;
        }
        print STDERR $m;
    };
    for my $root ( grep { -d $_ } $d, $lz, $priv ) {
        File::Find::find(
            { no_chdir => 1,
                wanted => sub {
                    my $p = $File::Find::name;
                    if ( -d $p ) {
                        $File::Find::prune = 1 if $skip{$p} || basename($p) eq '.git';
                        return;
                    }
                    return if -l $p || !-f _ || -s _ > 4_000_000;
                    return unless $p =~ /\.(?:md|tt|html?|tmpl)\z/;
                    push @files, $p unless $seen{$p}++;
                },
            },
            $root
        );
    }
    my ( @changed, @warn );
    for my $f ( sort @files ) {
        open my $in, '<:raw', $f or next;
        my $t = do { local $/; <$in> };
        close $in;
        my $n = ( $t =~ s/\bvisitor\.in_list\b/visitor.in_profile/g )
            + ( $t =~ s/\bvisitor\.in_any\b(?!_)/visitor.in_any_profile/g );
        next unless $n;
        my @st  = stat $f;
        my $tmp = "$f.tmp.$$";
        if ( open my $out, '>:raw', $tmp ) {
            print {$out} $t;
            close $out;
            chmod $st[2] & 07777, $tmp;
            chown( ( $> == 0 ? $st[4] : -1 ), $st[5], $tmp );
            if ( rename $tmp, $f ) {
                ( my $rel = $f ) =~ s{\A\Q$d\E/}{};
                push @changed, "renamed $n address test call(s) in $rel to visitor.in_profile / "
                    . 'visitor.in_any_profile (SM1345)';
                next;
            }
            unlink $tmp;
        }
        push @warn, "ADDRESS PROFILES: could not rewrite the address test calls in $f ($!) - "
            . 'rename visitor.in_list to visitor.in_profile and visitor.in_any to visitor.in_any_profile '
            . 'by hand; until then they are false (SM1345)';
    }
    if (%unread) {
        my @dirs = sort keys %unread;
        my @show = map { "$_ ($unread{$_})" } @dirs;
        my $more = @show > 8 ? ' (and ' . ( @show - 8 ) . ' more)' : '';
        splice @show, 8 if @show > 8;
        my $who = getpwuid($>) // "uid $>";
        # n825 (SM1447): say what is known. The walk could not look in these directories,
        # so it does not know whether any visitor.in_list / visitor.in_any call is below
        # them; it names who owns them, which is who can look.
        my %own;
        for my $dir (@dirs) {
            my @st = stat $dir or next;
            $own{ ( getpwuid $st[4] )[0] // "uid $st[4]" } = 1;
        }
        my @owners = sort keys %own;
        my $that = @owners == 1 ? "that owner ($owners[0])" : @owners ? 'an owner of them (' . join( ', ', @owners ) . ')' : 'the user that owns the site';
        push @warn, 'ADDRESS PROFILES: could not read ' . scalar(@dirs)
            . ' director' . ( @dirs == 1 ? 'y' : 'ies' ) . " as $who: " . join( ', ', @show ) . $more
            . ' - so it could not check ' . ( @dirs == 1 ? 'that directory' : 'those directories' )
            . ' for visitor.in_list or visitor.in_any calls'
            . ( @owners ? ', which ' . ( @dirs == 1 ? 'is' : 'are' ) . ' owned by ' . join( ', ', map { "'$_'" } @owners ) : '' )
            . "; run the upgrade again as root or as $that, then `lazysite check` to confirm none is left (SM1345, SM1380)";
    }
    return ( \@changed, \@warn );
}
# old-address-name: end

# N13-30: the settings 0.13.13 stopped reading, converted rather than kept alive
# by an alias (pre-stable: one way to say a thing). Returns ( \@changed,
# \@warnings, $error ).
#
#   manager_upload_blocked_paths -> manager_blocked_paths, its name since
#       SM019c. Where both are set the old line is dropped: the new key already
#       won, so the site's behaviour does not change.
#   db_render_raw -> deleted. db: values are always escaped now (SM786). A site
#       that had it ON renders differently from here, which is a warning in the
#       summary rather than a line in the log.
#
# Text in, text out: the installer loads no Lazysite module (SM767). A line
# that is a comment is left alone, so the shipped example's own prose is not
# rewritten.
sub convert_retired_conf_keys {
    my ($conf) = @_;
    return ( [], [], undef ) unless -f $conf;
    open my $in, '<', $conf or return ( [], [], "cannot read $conf: $!" );
    my @lines = <$in>;
    close $in;

    my $has_new = grep { /^\s*manager_blocked_paths\s*:/ } @lines;
    my ( @out, @changed, @warn );
    for my $l (@lines) {
        if ( $l =~ /^(\s*)manager_upload_blocked_paths(\s*:.*)\z/s ) {
            if ($has_new) {
                push @changed, 'dropped manager_upload_blocked_paths (manager_blocked_paths is set, and already won)';
                next;
            }
            push @out,     "$1manager_blocked_paths$2";
            push @changed, 'renamed manager_upload_blocked_paths to manager_blocked_paths';
            $has_new = 1;
            next;
        }
        if ( $l =~ /^\s*db_render_raw\s*:\s*(\S*)/ ) {
            push @changed, 'removed db_render_raw';
            push @warn,
                'DB_RENDER_RAW: this site had turned off the escaping of db: values, and that switch '
                . 'is gone - a db: value that carried HTML now shows it as text. Escape where the '
                . 'template renders instead (SM786)'
                if $1 =~ /\A(?:enabled|true|yes|on|1)\z/i;
            next;
        }
        push @out, $l;
    }
    return ( [], [], undef ) unless @changed;
    my ( $ok, $why ) = _replace_conf( $conf, \@out );
    return $ok ? ( \@changed, \@warn, undef ) : ( [], [], $why );
}

# SM798: list an extension in the site's registry, as the manager's enable does.
# Returns ( $added, $error ): 1 when it was added, 0 when it was already there,
# and an error when the conf could not be written. A missing conf is left alone
# and reported as an error, so the step is not recorded as done.
#
# The registry is the `extensions:` block, read by
# Lazysite::Manager::Extensions::_enabled_map; SM1142's extensions-rename has
# converted a site's old list before this runs. Text in, text out: the installer
# loads no Lazysite module (SM767). Commented lines are not a block, so the
# shipped example's own `# extensions:` prose is untouched.
# The `extensions:` list in lazysite.conf's lines: ( $head, $last, @entries ),
# the index of its header and of its last entry (undef when there is no list)
# and the entries in order. One reader for both installer steps that read the
# list (enable_extension_in_conf, conf_lists_extension).
sub _extensions_block {
    my ($lines) = @_;
    my ( $head, $last, @entries );
    for my $i ( 0 .. $#$lines ) {
        if ( !defined $head ) {
            $head = $last = $i if $lines->[$i] =~ /^extensions\s*:\s*$/;
            next;
        }
        if ( $lines->[$i] =~ /^\s+-\s+(.+?)\s*$/ ) {
            push @entries, $1;
            $last = $i;
            next;
        }
        last if $lines->[$i] =~ /^\S/;
    }
    return ( $head, $last, @entries );
}

# SM1361: --engine, or what the install state remembers, or `shared` when this
# payload carries the shared-engine marker the image writes at its root (the
# same name Lazysite::Extensions::$SHARED_MARK reads; this installer loads no
# module, and t/lint/392 holds the two names equal), else `copy`. Sets
# $SHARED_ENGINE; returns a refusal, or undef.
sub select_engine {
    my ( $o, $state ) = @_;
    my $want = $o->{engine} // '';
    if ( !length $want ) {
        my $mark = "$STAGE_DIR/SHARED-ENGINE";
        $want
            = ( ref $state eq 'HASH' && ( $state->{engine} // '' ) eq 'shared' ) ? 'shared'
            : ( -f $mark && !-l $mark ) ? 'shared'
            :                             'copy';
    }
    return "install.pl: --engine '$want' is not one of shared, copy\n"
        unless $want eq 'shared' || $want eq 'copy';
    $SHARED_ENGINE = $want eq 'shared' ? 1 : 0;
    return undef;
}

# Is this manifest entry the engine's own code, which a shared-engine site runs
# from the payload instead of holding a copy? The CGIs and their parts, and
# everything beside the docroot: lib, tools, extensions.
sub is_engine_entry {
    my ($entry) = @_;
    my $to = $entry->{install_to} // return 0;
    return ( $to =~ m{\A\{CGIBIN\}/} || $to =~ m{\A\{DOCROOT\}/\.\./(?:lib|tools|extensions)/} ) ? 1 : 0;
}

# Is $script (`extensions/<file>.pl`) on in this lazysite.conf?
sub conf_lists_extension {
    my ( $conf, $script ) = @_;
    open my $in, '<', $conf or return 0;
    my @lines = <$in>;
    close $in;
    my ( undef, undef, @entries ) = _extensions_block( \@lines );
    return ( grep { $_ eq $script } @entries ) ? 1 : 0;
}

# SM1369 X7 (rulings 188, 202): THE EXTENSIONS THIS PAYLOAD DOES NOT CARRY.
# The manifest marks each extension's files (`extension: <id>`): its
# descriptor, its payload and its endpoints. The common deb's manifest lists
# Odoo's files, and lazysite-odoo carries them, so on a host without that
# package the descriptor is not beside this installer. Such an extension is
# left out WHOLE - none of its entries is laid, and the plan treats the
# site's old copies as files that left the manifest (an unedited copy is
# removed, an edited one kept with its orphan warning). A site that has the
# extension ON is refused before anything changes (refuse_absent_extensions).
# %ABSENT_EXT is declared at the top, beside the channel ladder.

sub absent_extensions {
    my ($manifest) = @_;
    my %absent;
    for my $e ( @{ $manifest->{files} || [] } ) {
        my $id = $e->{extension};
        next             unless defined $id && $id =~ /\A[a-z][a-z0-9-]*\z/;
        $absent{$id} = 1 unless -f "$STAGE_DIR/extensions/$id.pl";
    }
    return %absent;
}

# The refusal, or undef. Before the plan, the backup and any write: an upgrade
# that went ahead would remove the extension's code from a site that uses it
# (R-7), which is the one outcome this must never reach in silence.
sub refuse_absent_extensions {
    my ($docroot) = @_;
    my $conf      = _conf_path($docroot);
    my @on = grep { conf_lists_extension( $conf, "extensions/$_.pl" ) } sort keys %ABSENT_EXT;
    return undef unless @on;
    return "lazysite: this site has the "
        . join( ', ', map { "'$_'" } @on )
        . " extension on, and this payload does not carry it.\n"
        . "  Nothing was changed. Install "
        . join( ', ', map { "lazysite-$_" } @on )
        . " (the package that ships it) and run this again,\n"
        . "  or switch the extension off in the manager first.\n";
}

sub enable_extension_in_conf {
    my ( $conf, $script ) = @_;
    return ( 0, "no lazysite.conf at $conf" ) unless -f $conf;
    open my $in, '<', $conf or return ( 0, "cannot read $conf: $!" );
    my @lines = <$in>;
    close $in;

    my ( $head, $last, @entries ) = _extensions_block( \@lines );
    return ( 0, undef ) if grep { $_ eq $script } @entries;
    if ( defined $head ) {
        splice @lines, $last + 1, 0, "  - $script\n";
    }
    else {
        $lines[-1] .= "\n" if @lines && $lines[-1] !~ /\n\z/;
        push @lines, "extensions:\n", "  - $script\n";
    }
    my ( $ok, $why ) = _replace_conf( $conf, \@lines );
    return $ok ? ( 1, undef ) : ( 0, $why );
}

# old-name: begin (SM1142, the migration names what it migrates)
# SM1142 S1: EXTENSIONS-RENAME, THE UPGRADE THAT MOVES A SITE TO THE ONE NAME.
#
# Ruled 2026-10-17 (R3): "fixup on upgrade, then its done" - nothing reads the
# old directory or the old conf spelling after this, so everything that held
# them is converted here, once, and the result is in the upgrade summary:
#
#   - every entry left in the old directory beside the docroot moves to
#     extensions/. By the time this runs the plan has installed the payload
#     there and removed the old copies it had installed unedited, so what is
#     left is a copy the site edited or a file the site added. A name the
#     payload already holds keeps the payload's copy, as an edited code file
#     always has on upgrade, and the site's version is kept beside it as
#     <name>.from-plugins (not a .pl, so the registry never lists it);
#   - a cgi-bin symlink into the old directory is pointed at the moved file
#     (the two the installer makes are re-made by post_install_steps already;
#     this catches one made by hand from the docs);
#   - lazysite.conf: the old list header becomes `extensions:` and each
#     `- <old>/<file>` entry `- extensions/<file>`, so every extension that was
#     on stays on - login rate limiting among them, which reads as off, and
#     silently, if this is missed. A conf that carried both headers (SM915's
#     damaged shape, which the readers merged) gets the union in one list;
#   - a start page stored as the old Extensions page names the new one;
#   - the old directory is removed when it is empty. Where its parent is not
#     ours to write (Hestia's root-owned domain root), the root-run deploy
#     removes it after this, and the summary says so.
#
# Idempotent: a second run finds nothing to move and nothing to rewrite.
# Returns ( \@changed, \@warnings ). Text in, text out (SM767).
#
# A sub, not a file-scope variable: cmd_install runs before the top level of
# this file reaches any assignment below it.
sub _old_ext_dir { return 'plugins' }

sub extensions_rename {
    my ( $docroot, $cgibin, $subs ) = @_;
    my $od = _old_ext_dir();
    my ( @changed, @warn );
    my $old = resolve_placeholders( "{DOCROOT}/../$od",        $subs );
    my $new = resolve_placeholders( '{DOCROOT}/../extensions', $subs );
    # The step moves every entry of $old: it must be the old directory and
    # nothing wider, whatever the placeholders resolved to.
    return ( [], ["EXTENSIONS: refusing to convert - the directories resolved to $old and $new"] )
        unless $old =~ m{/\Q$od\E\z} && $new =~ m{/extensions\z};

    if ( -d $old && !-l $old ) {
        if ( !-d $new && !make_path($new) ) {
            push @warn, "EXTENSIONS: could not create $new ($!) - the files in $old were "
                . 'not moved, and nothing reads them now. Create it (on Hestia, as root) and '
                . 'run the upgrade again';
        }
        elsif ( opendir my $dh, $old ) {
            for my $e ( sort grep { $_ ne '.' && $_ ne '..' } readdir $dh ) {
                my $src = "$old/$e";
                my $dst = ( -e "$new/$e" || -l "$new/$e" ) ? "$new/$e.from-plugins" : "$new/$e";
                if ( -e $dst || -l $dst ) {
                    push @warn, "EXTENSIONS: $src was left in place - $dst already exists. "
                        . 'Compare the two and remove the one you do not want';
                    next;
                }
                if ( rename $src, $dst ) {
                    push @changed, $dst =~ /\.from-plugins\z/
                        ? "kept the site's copy of $e as extensions/$e.from-plugins (the release's copy is extensions/$e)"
                        : "moved $e to extensions/";
                }
                else {
                    push @warn, "EXTENSIONS: could not move $src to $dst ($!) - nothing reads it there";
                }
            }
            closedir $dh;
        }
        if ( -d $old ) {
            if ( rmdir $old ) {
                push @changed, "removed the empty $od/ directory";
            }
            elsif ( opendir my $left, $old ) {
                my $n = grep { $_ ne '.' && $_ ne '..' } readdir $left;
                closedir $left;
                push @changed, "the empty $old is not ours to remove (its parent is not writable) - "
                    . 'the root-run deploy removes it'
                    unless $n;
            }
        }
    }

    # The cgi-bin links into the old directory.
    if ( length( $cgibin // '' ) && opendir my $ch, $cgibin ) {
        for my $e ( sort grep { -l "$cgibin/$_" } readdir $ch ) {
            my $link   = "$cgibin/$e";
            my $target = readlink $link;
            next unless defined $target;
            my $abs    = $target =~ m{\A/} ? $target : "$cgibin/$target";
            my ($file) = $abs =~ m{/\Q$od\E/([^/]+)\z} or next;
            my $to     = "$new/$file";
            next unless -f $to;
            unlink $link;
            if ( symlink $to, $link ) {
                push @changed, "re-pointed $link at extensions/$file";
            }
            else {
                push @warn, "EXTENSIONS: could not re-point $link at $to ($!)";
            }
        }
        closedir $ch;
    }

    # lazysite.conf.
    my $conf = _conf_path($docroot);
    if ( -f $conf && open my $in, '<', $conf ) {
        my @lines = <$in>;
        close $in;
        my ( @out, @entries, %seen, $at, $in_list, $was_old );
        for my $l (@lines) {
            if ( $l =~ /^(extensions|\Q$od\E)\s*:\s*$/ ) {
                $was_old = 1 if $1 eq $od;
                $at //= scalar @out;
                $in_list = 1;
                next;
            }
            if ($in_list) {
                if ( $l =~ /^\s+-\s+(.+?)\s*$/ ) {
                    ( my $entry = $1 ) =~ s{\A\Q$od\E/}{extensions/};
                    $was_old = 1 if $entry ne $1;
                    push @entries, $entry unless $seen{$entry}++;
                    next;
                }
                # As the readers do: an indented line stays in the list (and is
                # kept), anything else - a blank line included - ends it.
                if ( $l =~ /^[ \t]/ ) { push @out, $l; next }
                $in_list = 0;
            }
            push @out, $l;
        }
        if ($was_old) {
            splice @out, $at, 0, "extensions:\n", map { "  - $_\n" } @entries;
            $out[ $at - 1 ] .= "\n" if $at && $out[ $at - 1 ] !~ /\n\z/;
            my ( $ok, $why ) = _replace_conf( $conf, \@out );
            if ($ok) { push @changed, 'lazysite.conf lists the enabled extensions under extensions:, as extensions/<file>' }
            else { push @warn, "EXTENSIONS: could not rewrite $conf ($why) - every extension reads as off until it is" }
        }
    }

    # A start page naming the old Extensions page.
    my $settings = lazysite_dir_for($docroot) . '/auth/user-settings.json';
    if ( -f $settings && open my $sin, '<', $settings ) {
        my $text = do { local $/; <$sin> };
        close $sin;
        my $n = $text =~ s/("start_page"\s*:\s*"manager:)\Q$od\E(")/$1extensions$2/g;
        if ($n) {
            my ( $ok, $why ) = _replace_conf( $settings, [$text] );
            if ($ok) { push @changed, "$n start page(s) now name /manager/extensions" }
            else { push @warn, "EXTENSIONS: could not rewrite $settings ($why) - $n account(s) land on the account sheet until their start page is set again" }
        }
    }
    return ( \@changed, \@warn );
}

# The plan's orphan lines for the old directory: the step above moved them.
sub _drop_old_dir_orphans {
    my ( $stats, $warnings, $subs ) = @_;
    my $od     = _old_ext_dir();
    my $old    = resolve_placeholders( "{DOCROOT}/../$od", $subs );
    my $is_old = sub { index( $_[0], "$old/" ) == 0 };
    @{ $stats->{orphaned} } = grep { !$is_old->($_) } @{ $stats->{orphaned} };
    @$warnings = grep { !( /\Aorphan \(edited post-install, left in place\): (.+)\z/ && $is_old->($1) ) } @$warnings;
    return;
}
# old-name: end

# =========================================================
# ---------- plan computation ----------
# =========================================================

# Verify every code-bucket file is present at its install_to destination with the
# manifest's sha256 - i.e. the running code really IS this manifest's version.
# Returns a list of human-readable mismatches (empty = all good). Only code files
# (content/config are sysop-editable and legitimately differ).
sub verify_code_files {
    my ( $manifest, $subs ) = @_;
    my @bad;
    for my $entry ( @{ $manifest->{files} } ) {
        next unless defined $entry->{install_to};
        next unless ( $entry->{bucket} // '' ) eq 'code';
        next if $SHARED_ENGINE              && is_engine_entry($entry);
        next if defined $entry->{extension} && $ABSENT_EXT{ $entry->{extension} };
        my $dest = resolve_placeholders( $entry->{install_to}, $subs );
        if ( !-f $dest ) { push @bad, "$dest (missing)"; next }
        my $disk = sha256_of($dest);
        push @bad, "$dest (disk=$disk manifest=$entry->{sha256})"
            if $disk ne ( $entry->{sha256} // '' );
    }
    return @bad;
}

# --verify: check the installed code against the shipped manifest. Exit 0 if the
# running code matches this version, 1 (with the mismatches) if it does not - so
# a deploy that left a stale .pl behind is caught instead of silently reporting
# the new version.
sub cmd_verify {
    my ($o) = @_;
    my $manifest = load_manifest("$STAGE_DIR/release-manifest.json");
    if ( defined( my $why = select_engine( $o, load_state( state_path( $o->{docroot} ) ) ) ) ) {
        print {*STDERR} $why;
        return 2;
    }
    my %subs = placeholders( $o->{docroot}, $o->{cgibin} );
    %ABSENT_EXT = absent_extensions($manifest);
    my @bad = verify_code_files( $manifest, \%subs );
    if (@bad) {
        print STDERR "VERIFY FAILED for $manifest->{version}: "
            . scalar(@bad) . " code file(s) do not match the manifest -\n";
        print STDERR "  $_\n" for @bad;
        print STDERR "The installed code is NOT $manifest->{version} "
            . "(incomplete deploy). Re-run the install.\n";
        return 1;
    }
    print "VERIFY OK: installed code matches the manifest for $manifest->{version}.\n";
    return 0;
}

sub compute_plan {
    my ( $manifest, $state, $subs ) = @_;

    my $stored_files = $state ? ( $state->{files} || {} ) : {};

    my @plan;
    my %manifest_installs;

    for my $entry ( @{ $manifest->{files} } ) {
        next unless defined $entry->{install_to};    # null = tarball-only

        # SM1369 X7: an extension this payload does not carry is left out whole.
        next if defined $entry->{extension} && $ABSENT_EXT{ $entry->{extension} };
        # SM1361: a shared-engine site runs the engine from this payload.
        next if $SHARED_ENGINE && is_engine_entry($entry);

        my $dest   = resolve_placeholders( $entry->{install_to}, $subs );
        my $source = "$STAGE_DIR/$entry->{path}";
        $manifest_installs{$dest} = 1;

        # SM939 E2: starter content the site has opted out of, and has not got.
        if ( $NO_STARTER && $entry->{starter} && !exists $stored_files->{$dest} && !-e $dest ) {
            $STARTER_SKIPPED = ( $STARTER_SKIPPED // 0 ) + 1;
            # SM1285: and the URL it would have served, so the seeded nav does
            # not link to it.
            $STARTER_SKIPPED_URL{"/$1"} = 1 if $entry->{path} =~ m{\Astarter/([^/]+)\.md\z};
            next;
        }

        if ( !exists $stored_files->{$dest} ) {
            # Not tracked in prior state. If the destination already EXISTS on disk
            # and this is a sysop-editable (non-code) file, treat it as
            # pre-existing sysop content and PRESERVE it - never clobber a
            # homepage/page created or edited outside the installer's state tracking
            # (e.g. seeded by a different install path, authored via the manager /
            # WebDAV, or written before this file became manifest-tracked). Only
            # write when the destination is absent, or it is a code file (which must
            # match the shipped version). Preserve records the shipped sha as the
            # baseline, so it stays edited-vs-shipped and preserved on later upgrades.
            if ( -e $dest && ( $entry->{bucket} // '' ) ne 'code' ) {
                push @plan, {
                    action => 'preserve',
                    dest   => $dest,
                    bucket => $entry->{bucket},
                    sha256 => $entry->{sha256},
                    path   => $entry->{path},
                };
                next;
            }
            push @plan, {
                action => 'install',
                source => $source,
                dest   => $dest,
                bucket => $entry->{bucket},
                sha256 => $entry->{sha256},
                path   => $entry->{path},
            };
            next;
        }

        my $stored  = $stored_files->{$dest} // '';
        my $on_disk = -f $dest ? _sha256_tag($dest) : '';

        if ( $on_disk eq $stored ) {
            # unedited
            push @plan, {
                action => 'overwrite',
                source => $source,
                dest   => $dest,
                bucket => $entry->{bucket},
                sha256 => $entry->{sha256},
                path   => $entry->{path},
            };
        }
        else {
            # user-edited
            if ( ( $entry->{bucket} // '' ) eq 'code' ) {
                push @plan, {
                    action     => 'overwrite',
                    source     => $source,
                    dest       => $dest,
                    bucket     => 'code',
                    sha256     => $entry->{sha256},
                    was_edited => 1,
                    path       => $entry->{path},
                };
            }
            else {
                push @plan, {
                    action => 'preserve',
                    dest   => $dest,
                    bucket => $entry->{bucket},
                    sha256 => $entry->{sha256},
                    path   => $entry->{path},
                };
            }
        }
    }

    # Files in the stored state but not in the new manifest.
    if ( keys %$stored_files ) {
        for my $dest ( sort keys %$stored_files ) {
            next if $manifest_installs{$dest};

            if ( !-e $dest ) {
                push @plan, { action => 'already_gone', dest => $dest };
                next;
            }

            my $stored  = $stored_files->{$dest};
            my $on_disk = _sha256_tag($dest);
            if ( $on_disk eq $stored ) {
                push @plan, { action => 'remove', dest => $dest };
            }
            else {
                push @plan, { action => 'orphan_warn', dest => $dest };
            }
        }
    }

    return \@plan;
}

sub print_plan {
    my ( $plan, $manifest, $subs ) = @_;
    my %by_action;
    push @{ $by_action{ $_->{action} } }, $_ for @$plan;
    print "\n--- Plan ---\n";
    for my $action (qw(install overwrite preserve remove orphan_warn already_gone)) {
        my $items = $by_action{$action} or next;
        my $count = scalar @$items;
        print "  $action: $count\n";
        if ( $action eq 'preserve' || $action eq 'orphan_warn' ) {
            print "    - $_->{dest}\n" for @$items;
        }
    }
    print "\nRuntime paths:\n";
    for my $rp ( @{ $manifest->{runtime_paths} || [] } ) {
        my $resolved = resolve_placeholders( $rp->{path}, $subs );
        # P10 (WORK-PLAN-0154): three entries in classification.json carry
        # `why` and no `purpose`, and each printed an uninitialised-value
        # warning into every dry run (`lazysite provision` among them).
        my $why = $rp->{purpose} // $rp->{why} // '';
        print "  " . ( $rp->{mode} // '-' ) . " $resolved  ($why)\n";
    }
    print "\n";
}

# =========================================================
# ---------- plan execution ----------
# =========================================================

# SM413: invalidate rendered HTML, in one place, used by every path that
# changes the code under a site.
#
# THE ASYMMETRY THIS REMOVES: the rollback path already did this - "content at
# the pre-upgrade version may reference state that no longer matches" - and the
# UPGRADE path did not. So the installer already knew the rule and applied it
# in one direction only, which is the direction taken far less often.
#
# The field measured the cost: a homepage served a render produced under
# 0.10.13 through FOUR subsequent deployments, and was only corrected when an
# operator invalidated by hand. Because a cached page is regenerated when its
# SOURCE changes, and an upgrade changes no source, a page nobody edits keeps
# its pre-upgrade render for ever - including any head-contract or security
# header the new build introduced. The homepage is the page least likely to be
# edited and the first one an operator checks after an upgrade, so the failure
# presents as "the upgrade did not take".
#
# Only the rendered .html is dropped, never the whole cache directory: the
# per-host mirrors and other cache state have their own lifecycles, and this
# is a re-render trigger rather than a reset.
sub invalidate_rendered_html {
    my ($docroot) = @_;
    my $cache = lazysite_dir_for($docroot) . "/cache";
    return 0 unless -d $cache;
    my $n = 0;
    File::Find::find(
        { no_chdir => 1,
            wanted => sub {
                return unless -f $_ && /\.html$/;
                if   ( unlink $_ ) { $n++ }
                else               { warn "  warn: could not unlink $_: $!\n" }
            },
        },
        $cache,
    );
    return $n;
}

sub execute_plan {
    my ($plan) = @_;

    my %state_files;
    my %stats = (
        installed => 0,
        overwrote => 0,
        preserved => [],
        removed   => 0,
        orphaned  => [],
    );
    my @warnings;

    for my $step (@$plan) {
        my $a = $step->{action};

        if ( $a eq 'install' || $a eq 'overwrite' ) {
            my $ok = eval { install_file( $step->{source}, $step->{dest} ); 1 };
            if ( !$ok ) {
                my $err = $@; $err =~ s/\s+$//;
                # Code files (the app) are critical - fail. Content/seed files
                # are not: a page the owner (or a webdav partner) wrote may not
                # be writable by the installer - warn, leave it, carry on.
                die "$err\n" if ( $step->{bucket} // '' ) eq 'code';
                push @warnings, "skipped (not writable, left as-is): $step->{dest}";
                # Record the SHIPPED sha as the baseline so a future upgrade
                # treats it as edited-vs-shipped and keeps preserving it.
                $state_files{ $step->{dest} } =
                    defined $step->{sha256} ? "sha256:$step->{sha256}" : '';
                next;
            }
            $state_files{ $step->{dest} } = _sha256_tag( $step->{dest} );
            $a eq 'install' ? $stats{installed}++ : $stats{overwrote}++;
        }
        elsif ( $a eq 'preserve' ) {
            # Record the SHIPPED sha as the baseline (not the on-disk/user
            # version), so an edited file stays "edited vs shipped" and keeps
            # being preserved on future upgrades instead of being clobbered.
            $state_files{ $step->{dest} } =
                defined $step->{sha256} ? "sha256:$step->{sha256}" : _sha256_tag( $step->{dest} );
            push @{ $stats{preserved} }, $step->{dest};
        }
        elsif ( $a eq 'remove' ) {
            remove_page_file( $opt{docroot}, $step->{dest} );
            $stats{removed}++;
        }
        elsif ( $a eq 'already_gone' ) {
            # No-op, not in new state.
        }
        elsif ( $a eq 'orphan_warn' ) {
            push @{ $stats{orphaned} }, $step->{dest};
            push @warnings, "orphan (edited post-install, left in place): $step->{dest}";
        }
    }

    return ( \%state_files, \%stats, \@warnings );
}

# SM246: the declared mode for each directory the installer may create, resolved
# from the manifest once per run. Empty means the payload predates install_dirs,
# in which case install_file behaves exactly as it always did - an older tarball
# must install unchanged.
our %INSTALL_DIR_MODE;

# The runtime paths the model declares `on_upgrade: repair` (the engine owns the mode),
# resolved once per run, whoever applies them: form-events and git are `applied_by:
# check` only, so create_runtime_paths skips them, and align_store_modes sets their
# mode when they exist.
our %RUNTIME_REPAIR_MODE;

# The resolved docroot for this run, so make_declared_path can tell "a directory
# the installer owns" from "a directory above the site" (SM268 03-F8) - the two
# need opposite advice.
our $INSTALL_DOCROOT = '';

# SM933 A2 / R13: EVERY PATH THE INSTALLER CREATES TAKES THE DOCROOT'S GROUP.
#
# Measured (SM933 PR0): install.pl set no group on anything it wrote. install_file
# copied then chmod'ed; make_declared_path created with a declared mode; neither
# called secure_write_perms. So the group of all 202 created paths was whatever
# the kernel handed out - the docroot's group under a setgid docroot, the
# installing process's primary group otherwise. And one path was wrong EVEN under
# a setgid docroot: the private store is created BESIDE the docroot, so the
# docroot's setgid bit never reaches it and it took the site root's group
# (<user>:<user> on Hestia) - a store the CGI could not write, in both runs.
#
# The ruling (R13, 2026-10-03) is one rule: the DOCROOT's group, for everything
# the installer creates, siblings outside the docroot included. Not the
# immediate parent, which is what secure_write_perms inherits from and is the
# wrong source for exactly the path that was broken.
#
# ON CREATION ONLY. Each call site passes a path it has just made - a directory
# its mkdir succeeded on, a file that did not exist before the copy. An existing
# path is never regrouped: on an upgrade the group may be a sysop's deliberate
# choice, and "align everything" is the 0.6.5 outage's shape.
#
# BEST EFFORT, AND COUNTED. As non-root, chgrp succeeds only into a group the
# installer is a member of. A failure is not fatal - the health check at the end
# of the install names any path the CGI cannot reach - but it is counted, so the
# install says how many paths it could not give the site's group rather than
# leaving the reader to infer it from a list of check failures.
our $GROUP_ADOPT_FAILED = 0;


sub _adopt_site_group {
    my ($path) = @_;
    return unless length $INSTALL_DOCROOT && defined $path && length $path;
    return if -l $path;    # SM268 H5: never act through a link
    my $gid = ( stat $INSTALL_DOCROOT )[5];
    return unless defined $gid;
    my $cur = ( lstat $path )[5];
    return if !defined $cur || $cur == $gid;
    chown( -1, $gid, $path ) or $GROUP_ADOPT_FAILED++;
    return;
}

sub load_install_dirs {
    my ( $manifest, $subs ) = @_;
    %INSTALL_DIR_MODE    = ();
    %RUNTIME_REPAIR_MODE = ();
    $INSTALL_DOCROOT     = $subs->{DOCROOT} // '';
    for my $d ( @{ $manifest->{install_dirs} || [] } ) {
        $INSTALL_DIR_MODE{ resolve_placeholders( $d->{path}, $subs ) } = oct( $d->{mode} );
    }
    for my $r ( @{ $manifest->{runtime_paths} || [] } ) {
        next unless ( $r->{on_upgrade} // '' ) eq 'repair';
        $RUNTIME_REPAIR_MODE{ resolve_placeholders( $r->{path}, $subs ) } = oct( $r->{mode} );
    }
    return scalar keys %INSTALL_DIR_MODE;
}

# Create a missing directory chain, giving EVERY level the mode the model
# declares for it.
#
# This is deliverable 1's fault. `make_path($dir)` with no mode uses
# 0777 & ~umask, which under a root umask of 022 is 0755 - no group write - and
# nothing corrected the docroot directories that are not in runtime_paths. The
# installer already solves this problem three times for FILES and never once for
# directories.
#
# Two properties worth being explicit about, because this is the class of change
# that caused the 0.6.5 outage:
#
#   * the mode is applied ONLY on creation. An existing directory is never
#     chmod'ed here, so an operator who tightened one keeps their choice and a
#     site whose ownership does not match the assumption cannot be broken by
#     this path.
#   * mkdir's mode argument is masked by the umask, so the mode is applied by an
#     explicit chmod afterwards - the same umask-proofing the file path uses.
#
# A single make_path with one mode would give every intermediate level the mode
# of the deepest one, which is wrong the moment two levels differ (creating
# lazysite/auth would make lazysite/ 2770). Hence the level-by-level walk.
sub make_declared_path {
    my ($dir) = @_;

    # SM268 H5: `-d` follows a link, so a symlinked intermediate directory was
    # accepted as "already there" and everything below it was written outside
    # the docroot - 39 files, in the reviewer's reproduction. Walk the existing
    # levels and refuse any that is a link before trusting the tree.
    {
        my $d = $dir;
        while ( length $d ) {
            _refuse_symlink( $d, 'create a directory' ) if -e $d || -l $d;
            my $parent = dirname($d);
            last if $parent eq $d;
            $d = $parent;
        }
    }

    return 1 if -d $dir;

    # No model (older payload): historical behaviour, unchanged.
    return make_path($dir) ? 1 : 0 unless %INSTALL_DIR_MODE;

    my @missing;
    my $d = $dir;
    while ( length $d && !-d $d ) {
        push @missing, $d;
        my $parent = dirname($d);
        last if $parent eq $d;
        $d = $parent;
    }

    for my $path ( reverse @missing ) {
        my $mode = $INSTALL_DIR_MODE{$path};
        # Refusing is the point. A directory created with no declared mode is
        # how this incident happened: it lands at the umask default, no consumer
        # claims it, and nothing reports it until a deploy exposes it. Shipping
        # a file into a new directory must therefore be a decision someone made
        # rather than a side effect nobody saw.
        # SM268 03-F8: say which of the two cases this is, because they need
        # opposite responses and the old message only described one of them.
        #
        # A path INSIDE the site is the installer's own: the model must gain an
        # entry. A path ABOVE the site is the sysop's - the installer will
        # not guess a mode for a directory it does not own, and telling them to
        # edit classification.json for their own parent directory sends them
        # somewhere that cannot help. That was the reported complaint: the entry
        # was already there.
        unless ( defined $mode ) {
            my $inside = length($INSTALL_DOCROOT)
                && ( $path eq $INSTALL_DOCROOT
                || index( $path, "$INSTALL_DOCROOT/" ) == 0 );
            die "No declared mode for directory $path\n"
                . "  Every directory the installer creates must be declared in\n"
                . "  dist/config/classification.json (install_dirs), with the mode\n"
                . "  and the reason for it. Add an entry and rebuild the manifest.\n"
                if $inside;
            die "Cannot create $path: it is above the site and the installer does\n"
                . "  not own it, so there is no mode it can safely choose. Create it\n"
                . "  yourself with the ownership and mode your platform expects:\n"
                . "      mkdir -p $path\n"
                . "  then re-run this install. (Editing classification.json will not\n"
                . "  help here - it describes the site's own directories.)\n";
        }
        # SM268 H5: mkdir FAILS if the name already exists - including as a
        # symlink - so a successful mkdir proves we created a real directory
        # and the chmod below cannot land on someone else's file. Without the
        # check, a pre-placed symlink-to-file took the runtime mode: an
        # adversarial review put 2775 on an arbitrary file outside the docroot.
        mkdir $path or die "Cannot create directory $path: $!\n";
        _refuse_symlink( $path, 'set the mode' );
        _adopt_site_group($path);    # SM933 A2: before the chmod, so setgid sticks
        chmod $mode, $path;          # mkdir's mode is masked by the umask; this is not

        # SM933 A5: what is actually there, which is not always what was asked.
        $DIRS_LEFT{$path} = sprintf '%04o', ( lstat $path )[2] & 07777;
    }
    return 1;
}

# SM268 H5: refuse a path that IS a symlink.
#
# The installer runs as ROOT by the documented deploy path, and SM246 guarantees
# the docroot and lazysite/ are group-writable by design. So any account that can
# create a name in the docroot - the CGI, the site user, a compromised extension -
# could pre-place a symlink and have the next upgrade write through it, chmod
# through it, or chown through it, as root. An adversarial review landed five:
# a write through a symlinked destination, a chmod through a symlinked .pl, a
# runtime directory chmod through a symlinked dir, `chmod 2775` applied to an
# arbitrary FILE outside the docroot, and 39 files written outside via a
# symlinked intermediate directory.
#
# lstat, not stat: `-d`/`-e` follow the link and answer about the target, which
# is exactly the confusion being exploited. `lazysite-check.pl` already uses this
# idiom in two walks.
# SM268 H6/H16: extract an archive with the member names checked FIRST.
#
# Both restore paths shelled out to tar and trusted the archive. Two problems:
#
#   * a member named `../..` or an absolute path escapes the destination, even
#     when -C names a staging directory. The reviewer wrote a file outside the
#     docroot this way.
#   * --restore-full omitted --no-same-permissions, so as ROOT it restored
#     setuid bits straight out of the tarball.
#
# tar has no "reject traversal" switch, so the member list is read and vetted
# before anything is written. Refusing beats sanitising: an archive containing a
# traversal member is not a backup this installer produced, and continuing with
# the "safe" remainder would restore a half-tree from a hostile file.
sub safe_tar_extract {
    my ( $tarball, $dest, @extra ) = @_;

    my @members = qx(tar tzf \Q$tarball\E 2>/dev/null);
    die "Cannot list $tarball\n" if $? != 0;
    chomp @members;

    for my $m (@members) {
        # `..` in any position escapes the destination even with -C, and no tar
        # switch rejects it - hence the pre-flight.
        #
        # A LEADING SLASH is not a finding here: create_backup deliberately
        # writes absolute member names (--absolute-names) and the restore relies
        # on tar stripping the leading `/` to land them under a staging dir,
        # which is tar's default whenever -P/--absolute-names is absent - and
        # the extract below deliberately does not pass it.
        # Rejecting absolute members would refuse every backup this installer
        # has ever produced.
        die "Refusing to restore: archive member escapes the destination: $m\n"
            if $m =~ m{(?:\A|/)\.\.(?:/|\z)};
    }

    # --no-same-owner: never restore uid/gid from the archive.
    # --no-same-permissions: never restore setuid/setgid or over-permissive
    #   modes; extracted files take the process umask instead.
    #
    # Stripping the leading `/` is tar's DEFAULT (it only keeps absolute names
    # under --absolute-names/-P, which is not passed here), so no flag is needed
    # for it - and `--no-absolute-names` is not accepted by every tar in the
    # supported range, so naming it would break the restore it protects.
    return system( 'tar', '-xzf', $tarball, '-C', $dest,
        '--no-same-owner', '--no-same-permissions', @extra );
}

sub _is_symlink {
    my ($path) = @_;
    return ( lstat($path) && -l _ ) ? 1 : 0;
}

# Die on a symlinked path, naming it. Loud rather than skipped: a symlink where
# the installer expects a real file is either an attack or a broken tree, and
# both want a sysop to look.
sub _refuse_symlink {
    my ( $path, $what ) = @_;
    return unless _is_symlink($path);
    die "Refusing to $what through a symlink: $path\n"
        . "  The installer runs as root and never follows a link. Remove it (or\n"
        . "  replace it with the real file) and re-run.\n";
}

sub install_file {
    my ( $src, $dest ) = @_;
    my $dir = dirname($dest);
    _refuse_symlink( $dest, 'write' );
    if ( !-d $dir && !eval { make_declared_path($dir); 1 } ) {
        my $err = $@;
        # An undeclared directory is a packaging fault, not a permissions one -
        # pass it through rather than burying it under the Hestia hint, which
        # would send the reader to re-apply a web template that cannot fix it.
        die $err if $err =~ /^No declared mode/;
        # Most often: a site-root sibling (extensions/, tools/, lib/) on a Hestia
        # domain, whose root is mode 0551 - the template hook (lazysite-app.sh)
        # must pre-create those as root. Give an actionable message rather than
        # a bare "mkdir ... Permission denied".
        die "Cannot create directory $dir: $err"
            . "  If this is a Hestia install, the domain root is not user-writable;\n"
            . "  re-apply the lazysite-app web template (it pre-creates extensions/,\n"
            . "  tools/ and lib/ as root), then re-run the install.\n";
    }
    my $new = !-e $dest;    # SM933 A2: regroup only what this copy CREATES
    File::Copy::copy( $src, $dest )
        or die "Failed to copy $src -> $dest: $!\n";
    _adopt_site_group($dest) if $new;
    chmod mode_for($dest), $dest;
}

sub mode_for {
    my ($path) = @_;
    return 0755 if $path =~ /\.(pl|sh)$/;

    # SM1361: the rules below name the engine tree as `/lazysite/`, its place
    # inside the docroot. A site whose tree is BESIDE the docroot (SM293's
    # <docroot>-lazysite) is laid there from the start in the shared container,
    # and its account store and SMTP secret landed 0644 - world-readable - with
    # the health check calling the site not serviceable. The tree is asked for,
    # as every other writer asks (lazysite_dir_for), and its path is matched as
    # the `/lazysite/` one is.
    if ( length $INSTALL_DOCROOT ) {
        my $lz = lazysite_dir_for($INSTALL_DOCROOT);
        if ( length $lz && index( $path, "$lz/" ) == 0 ) {
            ( my $rel = substr( $path, length $lz ) ) =~ s{\A/}{};
            $path = "/lazysite/$rel";
        }
    }
    return 0640 if $path =~ m{/lazysite/auth/};

    # SM907 AT5: A CREDENTIAL TEMPLATE STARTS WHERE THE SAVE WOULD LEAVE IT.
    #
    # smtp.conf.example is the file an operator copies to smtp.conf and then
    # fills in with an SMTP password. It shipped 0644, so the copy was
    # world-readable and the credential was readable by every local user on the
    # host - which is the second failure the 27 September field check reported.
    # A save through the manager chmods 0660, because the extension declares a
    # `password` field; the template it was copied from did not start there.
    #
    # The example holds no secret itself, so this is not about the shipped file:
    # it is about what `cp smtp.conf.example smtp.conf` produces.
    #
    # SM933 PR1, found by wiring the post-install check in: THE INSTALLER MAKES
    # THAT COPY ITSELF. A fresh install lays down a live `lazysite/forms/smtp.conf`
    # byte-identical to the example, and this rule was anchored on `.example$`, so
    # the live file - the one that gets the password - landed 0644 while the
    # template it came from was 0640. The shipped check calls that a FAILURE
    # ("a secret must not be" world-accessible), which means a fresh install
    # failed its own health check on its own output. Matching the live name too
    # is the whole fix: 0640 satisfies both of the check's conditions (no world
    # bits, readable by the CGI's group), and a manager save still widens it to
    # 0660 when a password is entered.
    return 0640 if $path =~ m{/lazysite/forms/smtp\.conf(?:\.example)?$};
    return 0640 if $path =~ m{/lazysite/forms/.*\.example$};
    # T-115: and the live form configs the installer seeds from them
    # (forms/<name>.conf): the form store holds submissions and handler targets,
    # and nothing in it is anyone's but the site's. Group-readable for the CGI.
    return 0640 if $path =~ m{/lazysite/forms/[^/]+\.conf$};

    return 0644;
}

# =========================================================
# ---------- imperative post-install steps ----------
# =========================================================

# T-115 (ruling 215): THE MODES THE CHECK HOLDS, SET BY THE INSTALL ITSELF.
#
# `lazysite check` (check 5c) fails a world bit on the user store, the group
# list, the ACLs, the auth and forms examples and the two directories. Earlier
# installs laid some of those wrong themselves (the beside layout, T-115), and
# an operator's edit keeps a file's mode through the plan - so without this an
# upgrade would leave a site the check calls not serviceable over a mode
# lazysite set. Every mode, every layout: modes only, never content, an edited
# file included; never through a link; a file this run cannot chmod (another
# account's) is left for `lazysite repair` and the check names it. Drift after
# the install stays the check's to name and repair's to fix.
#
# And every directory the model declares (install_dirs, the table written into the
# install state as `dirs`, which the check's "declared directories carry their
# declared mode" line walks; and the runtime paths marked on_upgrade: repair, which
# the check holds as its group-writable set): the 0.16.1 container recipe left
# lazysite/stats/form-events at 2755, the check FAILs it as not group-writable, and
# the upgrade-on-start left it so. Only directories below the docroot or the
# lazysite tree, never a link; the mode only, never an owner or group.
sub align_store_modes {
    my ( $docroot, $install_mode ) = @_;
    my $lz = lazysite_dir_for($docroot);
    return 0 unless length $lz && -d $lz;
    my @want;
    push @want, map { [ "$lz/auth/$_", 0660 ] } qw(users groups acls.json);
    for my $dir (qw(auth forms)) {
        my $d = "$lz/$dir";
        next if -l $d || !-d $d;
        push @want, [ $d, 02770 ];
        opendir my $dh, $d or next;
        push @want, map { [ "$d/$_", 0640 ] } sort grep { /\.example\z/ } readdir $dh;
        closedir $dh;
    }
    # Only on an upgrade: a provision or a reinstall must not claim a directory that was
    # there before the install, or undo a mode a sysop set since (SM933 R16, t/tools/96).
    my %declared = ( $install_mode // '' ) eq 'upgrade' ? ( %INSTALL_DIR_MODE, %RUNTIME_REPAIR_MODE ) : ();
    for my $p ( sort keys %declared ) {
        next unless index( $p, "$docroot/" ) == 0 || index( $p, "$lz/" ) == 0;
        next if -l $p                             || !-d $p;
        push @want, [ $p, $declared{$p} ];
    }
    my $n = 0;
    for my $w (@want) {
        my ( $p, $mode ) = @$w;
        next if -l $p || !-e $p;
        next if ( ( lstat $p )[2] & 07777 ) == $mode;
        $n++ if chmod $mode, $p;
    }
    info("  modes:     set the declared mode on $n path(s)") if $n;
    return $n;
}

# The extensions whose script is linked into cgi-bin as an endpoint.
sub endpoint_links { return qw(form-handler payment-demo) }

# The cgi-bin endpoints that are links to an extension's script. Run by every
# install and by --restore-full (SM1439), so a restored site has the same ones.
sub link_extension_endpoints {
    my ( $cgibin, $subs ) = @_;
    my $extension_dir = resolve_placeholders( '{DOCROOT}/../extensions', $subs );

    # --- cgi-bin symlinks for extension endpoints ---
    #
    # form-handler and payment-demo need /cgi-bin/<name>.pl presence
    # so Apache routes POSTs at them. Symlink from extensions; fall
    # back to install if symlink unsupported (some shared hosts).
    # These paths are NOT tracked in .install-state.json - they are
    # links to files that ARE tracked.
    # SM1361: on a shared-engine site the cgi-bin is the payload's, which the
    # image links once at build time (installers/docker/Dockerfile, the same
    # list: t/tools/210).
    for my $extension ( $SHARED_ENGINE ? () : endpoint_links() ) {
        my $src = "$extension_dir/$extension.pl";
        my $dst = "$cgibin/$extension.pl";
        next unless -f $src;
        if ( -e $dst || -l $dst ) {
            # Already present from earlier install; refresh.
            unlink $dst;
        }
        if ( symlink( $src, $dst ) ) {
            info("  linked:    $dst -> $src");
        }
        else {
            File::Copy::copy( $src, $dst )
                or die "Could not install $dst: $!\n";
            chmod 0755, $dst;
            info("  installed: $dst (symlink unsupported)");
        }
    }

    return;
}

sub post_install_steps {
    my ( $o, $manifest, $subs, $state_files, $mode, $stats ) = @_;

    my $docroot = $o->{docroot};
    my $cgibin  = $o->{cgibin};
    link_extension_endpoints( $cgibin, $subs );

    # --- manager CSS: now manifest-tracked ---
    #
    # The manager CSS/assets are shipped straight to the web-served
    # manager/assets/ by the manifest (classification rule
    # ^starter/lazysite/manager/assets/), code bucket, so an upgrade always
    # refreshes them. The old approach copied them here from
    # lazysite/manager/assets/ on every run; that copy could go stale (a
    # pre-SM109 manager.css lingered on upgrade), so it was removed. Clean up
    # the now-orphaned source copy if a previous install left one.
    {
        my $orphan = lazysite_dir_for($docroot) . "/manager/assets/manager.css";
        unlink $orphan if -f $orphan;

        # SM698: and the SERVED sheet from before the styles were named. An
        # upgrade installs manager-classic.css beside it and stops referencing
        # manager.css, so the old file would sit in the web root unreferenced -
        # which is the same stale-stylesheet state SM109 removed the copy hack
        # to prevent. Nothing links to it after this release; remove it rather
        # than leave a sheet that looks live and is not.
        my $served_orphan = "$docroot/manager/assets/manager.css";
        unlink $served_orphan if -f $served_orphan;
        my $od = lazysite_dir_for($docroot) . "/manager/assets";
        rmdir $od if -d $od;    # only succeeds if empty
    }

    # --- auth users/groups: NOT seeded. SM865. ---
    #
    # This copied auth/users and auth/groups from their .example files on a
    # fresh install, and users.example shipped exactly one entry - `manager:` -
    # with groups.example placing it in `members` AND `lazysite-admins`. So
    # every new site came with a passwordless account in an admin group.
    #
    # The trailing colon means no password, and lazysite-auth.pl refuses a
    # no-password login unless REMOTE_ADDR is 127.0.0.1 or ::1, so it was never
    # reachable from outside. It is still the shared role account SM659
    # deliberately removed from setup-sysop - "role accounts are how people end
    # up sharing a password, and the audit trail then says `manager` did
    # everything". The installer's half of that argument was winning on every
    # fresh install, which is the disagreement this removes.
    #
    # NOTHING REPLACES IT, and that is the point. SM659 settled that a site with
    # no accounts is a coherent state rather than a half-built one - "deploying
    # with no accounts is fine" - because deployment and first user are separate
    # steps. `setup-sysop --user NAME` is the one route, and print_next_steps
    # now names it so the absence is stated rather than discovered.
    #
    # An UPGRADE was already untouched here (the block was fresh-only and
    # guarded on !-f), and an existing `manager` account is left exactly where
    # it is: an operator may be signing in with it, and an installer that
    # deletes a login nobody asked it to delete is worse than the account.
    # lazysite-check is the place to name it - see SM865.

    # --- nav.conf: seed from .example on fresh install ---
    if ( $mode eq 'fresh' ) {
        my $src = "$STAGE_DIR/starter/nav.conf.example";
        my $dst = lazysite_dir_for($docroot) . "/nav.conf";
        if ( -f $src && !-f $dst ) {
            File::Copy::copy( $src, $dst )
                or die "Could not seed nav.conf: $!\n";
            # SM1285: a site without the starter pages gets no menu entry for
            # one - the example links the demo, contact and members pages.
            if (%STARTER_SKIPPED_URL) {
                my @keep = grep {
                    !( /\|\s*(\S+)\s*$/ && $STARTER_SKIPPED_URL{$1} )
                } do { open my $in, '<', $dst or die "Could not read nav.conf: $!\n"; <$in> };
                write_text( $dst, join '', @keep );
            }
            # 0664, not 0644: the manager's nav editor saves this through the
            # www-data CGI ("Cannot write nav: Permission denied" in the field).
            chmod 0664, $dst;
            info("  seeded:    lazysite/nav.conf (from nav.conf.example)");
        }
    }

    # --- lazysite.conf: write on fresh install ---
    #
    # If --domain, write a minimal conf with templated site_name /
    # site_url. Otherwise, install the .example as the live conf.
    if ( $mode eq 'fresh' ) {
        my $conf = _conf_path($docroot);
        if ( !-f $conf ) {
            if ( length $o->{domain} ) {
                write_text(
                    $conf,
                    "# lazysite.conf - site configuration\n"
                        . "# See https://lazysite.io/docs for reference\n\n"
                        . "site_name: $o->{domain}\n"
                        . "site_url: \${REQUEST_SCHEME}://$o->{domain}\n"
                        # New sites default to the stable update channel (edge upgrades
                        # are skipped). Change to 'all' for a test / cutting-edge site.
                        . "update_channel: stable\n"
                        # SM139: fleet upgrades (`lazysite upgrade --all`) leave a
                        # 'manual' site alone; set 'auto' to opt in to cron-driven
                        # upgrades. 'manual' matches the absent-key default.
                        . "update_policy: manual\n"
                );
                info("  wrote:     lazysite/lazysite.conf (from --domain)");
            }
            else {
                my $src = "$STAGE_DIR/starter/lazysite.conf.example";
                if ( -f $src ) {
                    File::Copy::copy( $src, $conf )
                        or die "Could not seed lazysite.conf: $!\n";
                    info("  seeded:    lazysite/lazysite.conf (from example)");
                }
            }
            # 0664, not 0644: the manager (config-set, extension enable, channel
            # changes) runs as the web-server user and must be able to write the
            # conf. Group-writability only helps with the right group ownership -
            # see align_ownership below for the root-run case.
            chmod 0664, $conf if -f $conf;
        }
    }

    apply_site_modes( $docroot, $manifest, $subs, $mode );
}

# The group-write bits, the stores' modes, the lazysite/ setgid bit and the root-run
# ownership alignment: what leaves a site's tree usable by the web server's group.
# Run by every install (post_install_steps) and by --restore-full, which extracts
# a tree whose modes the tar did not carry (SM1439).
sub apply_site_modes {
    my ( $docroot, $manifest, $subs, $mode ) = @_;

    # --- CGI-writable file set: umask-proof the group-write bit ---
    #
    # Every file the www-data CGI must WRITE IN PLACE (the manager saves
    # nav.conf / lazysite.conf / the auth store / ACLs; every surface appends
    # audit.log) has to carry group-write whatever umask this installer ran
    # under - a 0644 file here silently locks the CGI out (the field defects:
    # nav-save "Permission denied", and audit entries lost without trace).
    # This list mirrors check 4b in tools/lazysite-check.pl - keep the two in
    # step (t/tools/03-install-pl.t cross-checks them). Runs on every mode and
    # only ADDS the group-write bit to files that exist; anything else about
    # an operator's modes is left alone.
    # SM246 (deliverable 4): the list is DECLARED in the model
    # (classification.json's runtime_files), not repeated here. It was
    # hand-maintained in two places - a new file needing group write was only
    # fixed if someone remembered both - and each row now carries the reason.
    # Falls back to the historical list when the manifest predates the field, so
    # an older payload installs exactly as before.
    my @gw = map { $_->{path} } @{ $manifest->{runtime_files} || [] };
    @gw = map { "{DOCROOT}/$_" } qw(
        lazysite/nav.conf lazysite/lazysite.conf
        lazysite/auth/users lazysite/auth/groups lazysite/auth/acls.json
        lazysite/logs/audit.log lazysite/logs/audit-reads.log
    ) unless @gw;
    # T-115: resolved through the placeholders, as every other declared path is.
    # It joined the spec to "$docroot/" after stripping a `{DOCROOT}/` the model's
    # rows do not carry (they are `{LAZYSITE}/...`), so the path was never a file
    # and the step skipped every row; and the fallback's `lazysite/` named the
    # tree inside the docroot only, missing a site whose tree sits beside it.
    for my $spec (@gw) {
        ( my $s = $spec ) =~ s{\A\{DOCROOT\}/lazysite/}{{LAZYSITE}/};
        my $p = resolve_placeholders( $s, $subs );
        next if -l $p || !-f $p;
        my $m = ( stat _ )[2] & 07777;
        chmod( $m | 0020, $p ) unless $m & 0020;
    }

    # --- T-115 (ruling 215): the account and form stores' declared modes ---
    align_store_modes( $docroot, $mode );

    # --- SGID on the lazysite/ subtree (not whole docroot) ---
    my $laz = lazysite_dir_for($docroot);
    if ( -d $laz ) {
        my $mode_now = ( stat $laz )[2] & 07777;
        my $want     = $mode_now | 02020;          # g+ws
        if ( $mode_now != $want ) {
            chmod $want, $laz;
        }
    }

    # --- Robustness: ownership alignment when installing as root ---
    # A sudo install writes root-owned files; deploy wrappers (Hestia) fix that
    # with a blanket chown afterwards, but a direct `sudo install.sh` has no such
    # pass - leaving lazysite.conf and the runtime dirs unwritable by the web
    # server ("Cannot write lazysite.conf: Permission denied" the moment the
    # manager saves a setting). Align what we manage to the DOCROOT's own
    # owner/group, so the installer is correct on its own regardless of the
    # calling wrapper.
    align_ownership($docroot);
    return;
}

# Repair ROOT-OWNED files under the lazysite tree (root runs only): a sudo
# install writes as root, and without a wrapper chown pass those files are
# unreadable/unwritable by the web-server CGI. Scope is deliberately narrow -
# ONLY files currently owned by root are touched (the CGI legitimately owns its
# runtime files as www-data, and the sysop owns content; both are left
# alone - a broader "align everything" pass in 0.6.5 stripped www-data's access
# on a site whose docroot group was not www-data, 500ing the auth wrapper).
# Owner becomes the docroot's owner; group becomes the WEB-SERVER group
# (www-data when it exists, matching lazysite-check), so group-rw modes keep
# working for the CGI.
sub align_ownership {
    my ($docroot) = @_;
    return unless $> == 0;    # only meaningful (and permitted) as root
    my $uid = ( stat $docroot )[4];
    return unless defined $uid;
    return if $uid == 0;      # a root-owned docroot gives us no better target
    my $gid = ( getgrnam 'www-data' )[2];
    $gid = ( stat $docroot )[5] unless defined $gid;

    my @paths = ( _conf_path($docroot) );
    my @stack = ( lazysite_dir_for($docroot) );
    while ( my $dir = pop @stack ) {
        next unless -d $dir;
        push @paths, $dir;
        opendir my $dh, $dir or next;
        for my $e ( readdir $dh ) {
            next if $e eq '.' || $e eq '..';
            my $p = "$dir/$e";
            # SM268 H5: a symlink is SKIPPED outright, never queued for chown.
            # It used to fall into @paths, where stat read the TARGET's uid for
            # the "only root-owned" guard and chown followed the link - so a
            # planted link handed its target to the site user, as root. Perl has
            # no lchown, so skipping is the only correct answer.
            if    ( -l $p ) { next }
            elsif ( -d $p ) { push @stack, $p }
            else            { push @paths, $p }
        }
        closedir $dh;
    }
    my $n = 0;
    for my $p (@paths) {
        next unless -e $p;
        my $cu = ( stat _ )[4];
        next unless defined $cu && $cu == 0;    # ONLY repair root-owned paths
        chown( $uid, $gid, $p ) and $n++;
    }
    info("  ownership: repaired $n root-owned path(s) under lazysite/")
        if $n;
    return;
}

# =========================================================
# ---------- runtime paths ----------
# =========================================================

sub create_runtime_paths {
    my ( $rps, $subs, $install_mode ) = @_;
    # SM246: the defensive default is the CONSERVATIVE value. This read
    # `||= 'fresh'`, and 'fresh' is the one that re-chmods existing directories -
    # so a caller that forgot the argument got the destructive behaviour. The one
    # real caller always passes it, so this was never live; a default that only
    # bites when someone makes a mistake should not be the dangerous one.
    $install_mode ||= 'upgrade';
    for my $rp (@$rps) {
        # SM246: one model, three consumers - install applies, check verifies,
        # check --fix repairs. `applied_by` says which consumers own a path, so
        # the table can describe paths that are VERIFIED without being created
        # or chmod'ed here (lazysite/git is made by the content-history extension at
        # adoption; lazysite/forms and the form-events log by the CGI). Absent
        # means install, so an entry that predates the field behaves as before.
        my $by = $rp->{applied_by};
        next if ref $by eq 'ARRAY' && !grep { $_ eq 'install' } @$by;
        # SM1361: beside the docroot is the image's on a shared-engine site;
        # its extensions directory, where there is one, is the site's own
        # read-only volume of local extensions, never the installer's to make
        # or chmod.
        next if $SHARED_ENGINE && $rp->{path} =~ m{\A\{DOCROOT\}/\.\./};
        my $path = resolve_placeholders( $rp->{path}, $subs );
        my $mode = oct( $rp->{mode} );
        # SM268 H5: never chmod a runtime path that is a symlink. `-d` follows
        # the link, so a planted link took the runtime mode onto its target -
        # the reviewer put 2775 on a file outside the docroot this way.
        _refuse_symlink( $path, 'set the mode' );
        if ( -d $path ) {
            # On a FRESH install the directory may already exist because the
            # file-install pass created it (e.g. to hold the seeded
            # auth/*.example), in which case it carries a default mode, not the
            # declared one - so apply the runtime mode (these dirs must be
            # group-writable + setgid for the www-data CGI to write them). On an
            # UPGRADE, leave an existing directory alone: the sysop may have
            # tightened it deliberately.
            # SM246 (deliverable 3): the fresh-versus-upgrade policy is now
            # DECLARED per path rather than implied by one branch.
            #
            #   repair - the engine owns this absolutely and re-applies the mode
            #            on every run. These are the directories the CGI MUST be
            #            able to write; a sysop who "tightens" lazysite/cache
            #            breaks their own site, silently, and the failure looks
            #            like a rendering fault rather than a permission one.
            #   leave  - set on creation, never touched again. ../extensions is
            #            EXECUTED, not written, so 0755 is right and hardening it
            #            further is a legitimate sysop choice.
            #
            # Absent means leave, so an entry predating the field keeps the old
            # upgrade behaviour. Note this only ever widens a mode toward what the
            # model declares - it is not the "align everything" ownership pass
            # that caused the 0.6.5 outage, which was chown and is untouched.
            my $on_upgrade = $rp->{on_upgrade} // 'leave';
            chmod $mode, $path
                if $install_mode eq 'fresh' || $on_upgrade eq 'repair';
            next;
        }
        # SM246: create the PARENTS through the directory model, then this
        # directory with its own runtime mode.
        #
        # `make_path($path, {mode => $mode})` applied one mode to every level it
        # created and then chmod'ed only the leaf, so an intermediate kept
        # whatever mkdir left it with: creating lazysite/auth (2770) made
        # lazysite/ 2770, and creating lazysite/manager/locks (2775) made
        # lazysite/manager/ 0775 with no setgid. Both were then invisible,
        # because nothing verified an intermediate.
        #
        # Linux mkdir(2) does not take S_ISGID from its mode argument, which is
        # why every level needs an explicit chmod rather than a mode passed to
        # mkdir - the same reason install_file's directory walk exists.
        make_declared_path( dirname($path) );
        mkdir $path unless -d $path;
        # SM933 A2: this is the branch that creates the private store, beside
        # the docroot where its setgid bit cannot reach - the one path that was
        # wrong under every docroot mode in the measurement.
        _adopt_site_group($path);
        chmod $mode, $path;
    }
}

# =========================================================
# ---------- backup / restore ----------
# =========================================================

sub create_backup {
    my ( $state, $backup_dir, $state_path, $new_version ) = @_;

    my $ts   = strftime( '%Y%m%d-%H%M%S', gmtime );
    my $name = "lazysite-backup-$ts-pre-$new_version.tar.gz";
    my $out  = "$backup_dir/$name";

    # Collect the set of files to back up: everything in the current
    # .install-state.json plus .install-state.json itself. Missing
    # files are skipped with a warning (stale state).
    my @paths;
    for my $path ( sort keys %{ $state->{files} || {} } ) {
        if ( -f $path ) {
            push @paths, $path;
        }
        else {
            warn "  backup: missing $path (recorded in state but not on disk; skipped)\n";
        }
    }
    push @paths, $state_path if -f $state_path;

    unless (@paths) {
        die "Backup: no files to archive. Aborting upgrade to avoid unrecoverable state.\n";
    }

    # Build a file list for tar --files-from. Paths are absolute;
    # tar strips leading / by default. Restore re-adds it.
    # SM268 H7: the list is piped to tar, not written to a file.
    #
    # It used to be `$backup_dir/.backup-list-$$` - a predictable name in a
    # directory SM246 guarantees is group-writable. Anyone in the site group
    # could pre-place that name as a symlink and, since this runs as root during
    # an upgrade, have the open() write the file list through it. Racing the pid
    # is easy: pids are small and the window is the whole backup.
    #
    # Feeding tar on stdin removes the file, and with it the race, the predicable
    # name and the cleanup. There is nothing left to plant.
    my @cmd = (
        'tar',
        '--absolute-names',
        '-czf', $out,
        # --verbatim-files-from is POSITIONAL and affects only the --files-from
        # that follows it, so the order here is load-bearing: after, tar warns
        # "has no effect" and exits non-zero, which aborts the upgrade.
        '--verbatim-files-from',
        '--files-from', '-',
    );
    my $rc;
    local $SIG{PIPE} = 'IGNORE';    # SM959: a child that exits early must not kill us
    if ( open my $tar, '|-', @cmd ) {
        print {$tar} "$_\n" for @paths;
        close $tar;
        $rc = $?;
    }
    else {
        die "Backup: could not run tar: $!\n";
    }

    if ( $rc != 0 ) {
        unlink $out if -f $out;
        die "Backup: tar failed (rc=$rc). Aborting upgrade. Your system is unchanged.\n";
    }

    # SM268 03-F10: the installer's own backups never got a sidecar.
    #
    # SM183 said "every site package and backup now gets a .sha256 sidecar" and
    # the installer's did not - it cannot load Lazysite::Manager::Backups, so the
    # writer simply was not there. That also made apply_retention's
    # `unlink "$backups[$i].sha256"` dead code: it retired a file nothing had
    # ever written. Same format, same sha256sum -c compatibility, written the
    # same atomic way.
    write_backup_sha256($out);

    return $out;
}

# The .sha256 sidecar for an installer-written artefact. Deliberately a small
# local copy rather than a shared one: install.pl runs from the release tarball
# with no @INC into the site's lib, which is the whole reason this was missing.
# Failure is not fatal - the artefact is valid without it - but it must not be
# reported as written when it was not.
sub write_backup_sha256 {
    my ($path) = @_;
    return '' unless -f $path;
    my $sha = eval { sha256_of($path) };
    return '' unless defined $sha && length $sha;
    my $base = basename($path);
    my $side = "$path.sha256";
    if ( -l $side ) {
        warn "  warn: $side is a symlink; not writing a digest sidecar\n";
        return '';
    }
    my $tmp = "$side.tmp.$$";
    unless ( sysopen my $fh, $tmp, O_WRONLY | O_CREAT | O_EXCL, oct '640' ) {
        warn "  warn: could not write $tmp: $!\n";
        return '';
    }
    else {
        print {$fh} "$sha  $base\n";
        close $fh;
    }
    unless ( rename $tmp, $side ) {
        warn "  warn: could not install $side: $!\n";
        unlink $tmp;
        return '';
    }
    return $sha;
}

# Remove one installed file, and for a page its cached renders: the .html beside
# it and the per-alias-host copies (SM110 - standalone installer, so inline
# rather than the Lazysite::Util helper). Shared by an upgrade's `remove` step
# and --remove-starter (SM1286), which must leave nothing of a page behind.
sub remove_page_file {
    my ( $docroot, $dest ) = @_;
    unlink $dest
        or warn "  warn: could not unlink $dest: $!\n";
    # SM1369 X7: a module the release moved out of a lib (Odoo's, into its payload
    # lib) leaves the directories it emptied; they go too, up to the lib itself.
    # rmdir removes only an empty directory, so anything a site put there stays.
    if ( $dest =~ m{\A(.*/lib)/.+\.pm\z} ) {
        my ( $top, $dir ) = ( $1, dirname($dest) );
        while ( length $dir > length $top && rmdir $dir ) { $dir = dirname($dir) }
    }
    return unless $dest =~ /\.md$/;
    ( my $cached = $dest ) =~ s/\.md$/.html/;
    unlink $cached if -f $cached;
    ( my $rel = $cached ) =~ s{^\Q$docroot\E/?}{};
    my $hosts = lazysite_dir_for($docroot) . "/cache/hosts";
    if ( length $rel && $rel !~ m{\.\.} && opendir( my $hd, $hosts ) ) {
        for my $h ( readdir $hd ) {
            next                    if $h =~ /^\./;
            unlink "$hosts/$h/$rel" if -f "$hosts/$h/$rel";
        }
        closedir $hd;
    }
    return;
}

# SM1286 (ruling 34): THE STARTER PAGES A SITE HAS, AND WHICH IT NEVER EDITED.
#
# A new site gets no starter pages (SM1285), and the upgrade that made that the
# default keeps the ones a site already has. This is how an owner clears them
# out without unpicking them by hand: list them, or remove the unmodified ones.
#
# STARTER is the manifest's own flag (classification.json's starter_content),
# so this names exactly the pages --starter lays - never forgot, logout or the
# search pages, which a site needs.
#
# UNMODIFIED is provenance, as ADR 0004 defines it: the page still carries
# `provenance: lazysite-starter`, and its bytes still match the checksum the
# install state recorded for it, or the one this release ships. Anything else
# is edited and stays. A page the state never tracked and that differs from
# the shipped one is the operator's, whatever its path.
#
# Run as the site user (the CLI refuses root): it deletes in the site tree, and
# nothing it does needs more.
sub cmd_starter_pages {
    my ($o)      = @_;
    my $docroot  = $o->{docroot};
    my $manifest = load_manifest("$STAGE_DIR/release-manifest.json");
    my $state    = load_state( state_path($docroot) );
    my $recorded = ( ref $state eq 'HASH' && ref $state->{files} eq 'HASH' ) ? $state->{files} : {};
    my %subs = placeholders( $docroot, '' );

    my ( @unmodified, @edited );
    for my $entry ( @{ $manifest->{files} } ) {
        next unless $entry->{starter} && defined $entry->{install_to};
        my $dest = resolve_placeholders( $entry->{install_to}, \%subs );
        next unless -f $dest;
        my $sha     = _sha256_tag($dest);
        my $ours    = _has_starter_provenance($dest);
        my $matches = ( defined $recorded->{$dest} && $recorded->{$dest} eq $sha )
            || ( defined $entry->{sha256} && $sha eq "sha256:$entry->{sha256}" );
        push @{ ( $ours && $matches ) ? \@unmodified : \@edited }, $dest;
    }
    my $rel = sub { ( my $r = $_[0] ) =~ s{^\Q$docroot\E/?}{}; $r };

    if ( $o->{list_starter} || $o->{dry_run} ) {
        my $verb = $o->{remove_starter} ? 'would remove' : 'unmodified  ';
        print "$verb  " . $rel->($_) . "\n"                               for @unmodified;
        print 'edited        ' . $rel->($_) . "  (kept: never removed)\n" for @edited;
        print "No starter pages on this site.\n" unless @unmodified || @edited;
        if ( $o->{remove_starter} ) {
            print "--dry-run: nothing removed.\n";
        }
        elsif (@unmodified) {
            print "Remove the unmodified ones with --remove-starter (--dry-run first to see them).\n";
        }
        return 0;
    }

    remove_page_file( $docroot, $_ )                for @unmodified;
    print 'removed  ' . $rel->($_) . "\n"           for @unmodified;
    print 'kept     ' . $rel->($_) . "  (edited)\n" for @edited;
    print "No unmodified starter pages to remove.\n" unless @unmodified;
    audit_append( $docroot, 'starter-removed', scalar(@unmodified) . ' page(s)',
        join( ' ', map { $rel->($_) } @unmodified ) )
        if @unmodified;

    # The seeded menu may still link a page that has gone; the menu is the
    # operator's, so it is named rather than edited.
    my %gone = map { ( '/' . ( $rel->($_) =~ s/\.md\z//r ) ) => 1 } @unmodified;
    if ( %gone && open my $nav, '<', lazysite_dir_for($docroot) . '/nav.conf' ) {
        my @linked = grep { /\|\s*(\S+)\s*$/ && $gone{$1} } <$nav>;
        close $nav;
        chomp @linked;
        print "nav.conf still links a removed page - edit the menu: $_\n" for map { s/^\s+//r } @linked;
    }
    return 0;
}

# Does the page's front matter carry `provenance: lazysite-starter`?
sub _has_starter_provenance {
    my ($path) = @_;
    open my $fh, '<', $path or return 0;
    my $first = <$fh> // '';
    my $ours  = 0;
    if ( $first =~ /\A---\s*\z/ ) {
        while ( my $l = <$fh> ) {
            last if $l =~ /\A---\s*\z/;
            $ours = 1 if $l =~ /^provenance\s*:\s*lazysite-starter\s*$/;
        }
    }
    close $fh;
    return $ours;
}

sub cmd_list_backups {
    my ($docroot) = @_;
    my $dir = lazysite_dir_for($docroot) . "/backups";
    unless ( -d $dir ) {
        print "No backups directory at $dir.\n";
        return 0;
    }
    my @files = _backup_files($dir);
    unless (@files) {
        print "No backups found at $dir.\n";
        return 0;
    }
    printf "%-60s  %12s  %s\n", 'Backup', 'Size', 'Modified';
    for my $f (@files) {
        my @st    = stat $f;
        my $size  = $st[7];
        my $mtime = strftime( '%Y-%m-%d %H:%M:%S UTC', gmtime $st[9] );
        printf "%-60s  %12d  %s\n", basename($f), $size, $mtime;
    }
    return 0;
}

sub cmd_restore {
    my ($o) = @_;

    my $backup_path;
    if ( length $o->{backup} ) {
        $backup_path = abs_path( $o->{backup} ) // $o->{backup};
        die "Backup '$backup_path' not found\n" unless -f $backup_path;
    }
    else {
        my $dir   = lazysite_dir_for( $o->{docroot} ) . "/backups";
        my @files = _backup_files($dir);
        die "No backups found at $dir\n" unless @files;
        $backup_path = $files[-1];    # most recent (lexicographic == chronological)
    }

    info("Restoring from: $backup_path");

    # Extract into a temp dir. Do NOT pass --absolute-names at
    # extract: tar must strip leading / and land files under $tmp
    # so we can explicitly copy them to their real destinations.
    # Otherwise tar would write to the absolute paths directly and
    # bypass our state-driven restore logic (and the security
    # benefit of staging in a temp dir first).
    my $tmp = tempdir( 'lazysite-restore-XXXXXX', TMPDIR => 1, CLEANUP => 1 );
    my $rc  = safe_tar_extract( $backup_path, $tmp );
    die "tar extraction failed (rc=$rc)\n" if $rc != 0;

    # The tar stripped the leading "/" from paths, so the content
    # lives at $tmp/<abs-path-without-leading-slash>.
    my $state_rel = state_path( $o->{docroot} );
    $state_rel =~ s{^/+}{};
    my $state_copy = "$tmp/$state_rel";
    die "Backup is missing .install-state.json at $state_copy\n"
        unless -f $state_copy;

    my $backup_state = load_state($state_copy);
    my $files        = $backup_state->{files} || {};

    my $restored = 0;
    for my $dest ( sort keys %$files ) {
        ( my $rel = $dest ) =~ s{^/+}{};
        my $src = "$tmp/$rel";
        unless ( -f $src ) {
            warn "  skip (missing in backup): $dest\n";
            next;
        }
        make_path( dirname($dest) );
        if ( -e $dest ) {
            unlink $dest
                or warn "  warn: could not remove existing $dest: $!\n";
        }
        File::Copy::copy( $src, $dest )
            or die "Could not restore $dest: $!\n";
        chmod mode_for($dest), $dest;
        $restored++;
    }

    # Rewrite .install-state.json from the backup.
    my $state_path = state_path( $o->{docroot} );
    make_path( dirname($state_path) );
    File::Copy::copy( $state_copy, $state_path )
        or die "Could not write $state_path: $!\n";
    chmod 0644, $state_path;

    # Invalidate rendered .html cache: content at the pre-upgrade
    # version may reference state that no longer matches.
    my $dropped = invalidate_rendered_html( $o->{docroot} );
    info("  cleared:   lazysite/cache/ ($dropped rendered page(s) invalidated)")
        if $dropped;

    info("");
    info("Restore complete.");
    info("  Version:  $backup_state->{version}");
    info("  Files:    $restored restored");
    info("  Runtime:  untouched (auth, logs, locks, etc.)");
    info("");

    return 0;
}

# =========================================================
# ---------- retention ----------
# =========================================================

sub read_retention {
    my ($docroot) = @_;
    # SM767: THE INSTALLER LOADS NO LIB. SM753 made this `require
    # Lazysite::Util` and the 0.13.5 deploy died here on the edge host:
    # install.pl runs from the unpacked tarball with no lib in @INC, and the
    # suite never noticed because `prove -l` lends every child PERL5LIB=lib -
    # the harness supplying what production does not (SM473's shape).
    # This MIRRORS Lazysite::Util::backup_retention - same default, same
    # grammar - and t/lint/122 holds the two together and holds that this
    # file never loads the lib.
    my $default = 3;
    my $conf    = lazysite_dir_for($docroot) . '/lazysite.conf';
    return $default unless -f $conf;
    open my $fh, '<', $conf or return $default;
    my $val = $default;
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    while (<$fh>) {
        next unless /^backup_retention\s*:\s*(.*?)\s*$/;
        my $v = $1;
        # SM782: empty is the default, silently (the engine's reader agrees)
        if    ( !length $v )    { $val = $default }
        elsif ( $v =~ /^\d+$/ ) { $val = $v + 0 }
        else { warn "lazysite.conf: backup_retention '$v' is not a whole number; using $default\n" }
        last;
    }
    close $fh;
    return $val;
}

sub apply_retention {
    my ( $dir, $retention ) = @_;
    return if $retention == 0;
    my @backups = _backup_files($dir);
    # Sort by mtime ascending (oldest first) in case lexical and
    # chronological diverge (shouldn't, but defensive).
    @backups = sort { ( stat $a )[9] <=> ( stat $b )[9] } @backups;
    my $excess = @backups - $retention;
    return if $excess <= 0;
    for my $i ( 0 .. $excess - 1 ) {
        unlink $backups[$i]
            or warn "  warn: could not remove $backups[$i]: $!\n";
        # SM183: retire the integrity sidecar with the artefact it describes.
        unlink "$backups[$i].sha256" if -f "$backups[$i].sha256";
        info( "  retired:   " . basename( $backups[$i] ) );
    }
}

# =========================================================
# ---------- the declared mode (SM892) ----------
# =========================================================

# What the operator SAID they were doing, checked against what is on disk.
#
# Returns one of three things, and the third is why this is not a boolean:
#
#   ( $mode, undef, undef )     the declaration holds; get on with it
#   ( undef, $refusal, undef )  the declaration is WRONG about this site - the
#                               message names the verb they wanted, exit 2
#   ( undef, undef, $noop )     the declaration is right and there is nothing
#                               to do - say so and exit 0
#
# The no-op case is `upgrade` on a site already at the payload's version. It is
# not an operator error and must not be reported as one: see the comment where
# it is returned.
#
# THE THREE MODES ARE UNCHANGED and so are the conditions that tell them apart.
# What changed is who decides: `--mode` is now required, and this compares it
# with the state rather than deriving it. The same three facts, asked the other
# way round.
#
# EVERY REFUSAL NAMES THE COMMAND THEY WANTED AND THE STATE IT FOUND. An
# operator who chose wrongly has exactly one question - "then what should I
# have run?" - and "already installed" without the version is a fact they have
# to go and look up before they can act on it.
#
# The verbs, not the flags, are what the messages name: `--mode` is how the
# CLI talks to this script, and `lazysite upgrade` is what a person types.
sub declared_mode {
    my ( $o, $state, $manifest ) = @_;

    my $want = $o->{mode};
    my $have = defined $state ? ( $state->{version} // '?' ) : undef;
    my $to   = $manifest->{version} // '?';

    # SM899: the CLI says how it was reached. On a tarball host there is no
    # `lazysite` on PATH, and a hint that names one sends the operator to
    # "command not found".
    my $cli = length( $o->{invoked_as} // '' ) ? $o->{invoked_as} : 'lazysite';

    unless ( defined $want && length $want ) {
        # NOT a default. A default here is the guessing this removed, and the
        # caller is always either the lazysite CLI or a script this repo ships,
        # so an absent mode is a caller that was not updated.
        return ( undef, "install.pl: --mode is required and must be one of "
                . "provision, upgrade, reinstall.\n"
                . "  install.pl no longer decides which of those you meant "
                . "(SM892). Run one of:\n"
                . "    $cli provision --docroot DIR --cgibin DIR   # a site that does not exist yet\n"
                . "    lazysite upgrade   --docroot DIR                # move an installed site forward\n"
                . "    $cli reinstall --docroot DIR                # re-lay this version, keeping content\n" );
    }

    unless ( $want =~ /\A(?:provision|upgrade|reinstall)\z/ ) {
        return ( undef, "install.pl: --mode '$want' is not one of provision, "
                . "upgrade, reinstall.\n" );
    }

    if ( $want eq 'provision' ) {
        return ( 'fresh', undef ) unless defined $state;
        return ( undef, "lazysite: this site is ALREADY INSTALLED, at $have.\n"
                . "  provision is for a site that does not exist yet, so nothing was changed.\n"
                . "  To move it to $to:        $cli upgrade --docroot $o->{docroot}\n"
                . "  To re-lay $have as it ships:  $cli reinstall --docroot $o->{docroot}\n" );
    }

    if ( $want eq 'upgrade' ) {
        unless ( defined $state ) {
            return ( undef, "lazysite: NOTHING IS INSTALLED at $o->{docroot}.\n"
                    . "  upgrade moves an installed site forward, so nothing was changed.\n"
                    . "  To install it:  $cli provision --docroot $o->{docroot} --cgibin DIR\n" );
        }
        if ( $have eq $to ) {
            # ALREADY CURRENT IS A NO-OP, NOT A REFUSAL, and the distinction is
            # load-bearing rather than pedantic.
            #
            # A refusal is for a declaration that is WRONG about the site. This
            # one is not: the site is installed, the operator asked to move it
            # forward, and there is simply nothing newer. `apt upgrade` with
            # nothing to upgrade exits 0, and so does this.
            #
            # It also has to. `lazysite upgrade --all` crosses a fleet where
            # some sites are already current - on the 0.14.2 rollout, most of
            # them by the end - and every one of those used to resolve to the
            # inferred `reinstall` and exit 0. Refusing here would turn a
            # 29-site rollout's ordinary no-ops into 29 reported failures.
            #
            # The release manager's point stands and is answered by SAYING so:
            # "upgrade of the same version is confusing" - so it names the verb
            # that does re-lay the files, for an operator who meant that.
            return ( undef, undef,
                "lazysite: this site is already at $to - nothing to upgrade.\n"
                    . "  To re-lay $to as it ships, keeping content:  "
                    . "$cli reinstall --docroot $o->{docroot}\n" );
        }
        return ( 'upgrade', undef );
    }

    # reinstall
    unless ( defined $state ) {
        return ( undef, "lazysite: NOTHING IS INSTALLED at $o->{docroot}.\n"
                . "  reinstall re-lays the version a site already has, so nothing was changed.\n"
                . "  To install it:  $cli provision --docroot $o->{docroot} --cgibin DIR\n" );
    }
    if ( $have ne $to ) {
        return ( undef, "lazysite: this site is at $have and the payload is $to.\n"
                . "  reinstall re-lays the SAME version; changing version is an upgrade.\n"
                . "  To move it to $to:  $cli upgrade --docroot $o->{docroot}\n" );
    }
    return ( 'reinstall', undef );
}

# =========================================================
# ---------- state i/o ----------
# =========================================================

sub state_path {
    my ($docroot) = @_;
    return lazysite_dir_for($docroot) . "/.install-state.json";
}

sub load_state {
    my ($path) = @_;
    return undef unless -f $path;
    open my $fh, '<:raw', $path
        or die "Cannot read state $path: $!\n";
    my $text = do { local $/; <$fh> };
    close $fh;
    my $parsed = eval { JSON::PP::decode_json($text) }
        or die "Cannot parse state $path: $@\n";
    return $parsed;
}

sub write_state {
    my ( $path, $version, $files, $once ) = @_;

    # SM268 03-F7: record the RESOLVED install_dirs modes alongside the files.
    #
    # SM246's design is "one table, three consumers - install applies, check
    # verifies, check --fix repairs". That was true of runtime_paths and false
    # of install_dirs: lazysite-check.pl carried its own hand-written list of
    # eleven lazysite/* directories and knew nothing of the twenty-eight the
    # model declares. So every site already carrying the reported fault - the
    # docroot's content directories stripped of group write - stayed broken, and
    # the audit tool called the site healthy.
    #
    # The model lives in the release tarball, which an installed site does not
    # keep, so check cannot read it directly. Writing the resolved paths into
    # the install state is what gives check something to verify against, without
    # it having to guess at placeholders or find a manifest.
    my %dirs = map { $_ => sprintf '%04o', $INSTALL_DIR_MODE{$_} }
        keys %INSTALL_DIR_MODE;
    # SM933 A5: only for directories the model still declares and that still
    # exist - a record for a path nothing governs would be a claim with nothing
    # behind it.
    my %left = map { $_ => $DIRS_LEFT{$_} }
        grep { exists $dirs{$_} && -d $_ && !-l $_ } keys %DIRS_LEFT;

    my $data = {
        schema_version => '1',
        version        => $version,
        installed_at   => strftime( '%Y-%m-%dT%H:%M:%SZ', gmtime ),
        files          => $files,
        ( %dirs           ? ( dirs      => \%dirs )     : () ),
        ( %left           ? ( dirs_left => \%left )     : () ),    # SM933 A5
        ( $once && @$once ? ( once => [ sort @$once ] ) : () ),   # SM798: steps done once
        ( $NO_STARTER     ? ( starter => 'none' )       : () ),    # SM939 E2: remembered
        ( $SHARED_ENGINE  ? ( engine  => 'shared' )     : () ),    # SM1361: remembered
    };
    make_path( dirname($path) );
    my $json = JSON::PP->new->utf8(1)->pretty(1)->indent_length(2)
        ->canonical(1)->encode($data);
    open my $fh, '>:raw', $path
        or die "Cannot write state $path: $!\n";
    print $fh $json;
    close $fh;
    chmod 0644, $path;
}

# A release tarball always carries release-manifest.json - it is generated at
# build time and shipped. A SOURCE CHECKOUT does not: the file is gitignored,
# so it exists only on a machine that has built a release.
#
# That distinction was invisible for a long time, because the developer's
# working copy always had one lying around from the last build. The suite
# passed there and failed on a clean checkout of the very tag it was testing -
# fifteen test files invoke install.pl, and the strict SBOM gate needs the same
# file, so a released tag could neither run its own tests nor its own
# compliance control for anyone who cloned it (2026-08-14 review, D3 F3.1 and
# D6 F6.6).
#
# The manifest is DERIVABLE from the tree, so absence is recoverable rather
# than fatal: if the builder and the classification map are both present, build
# one. It goes to a temp path and not into the checkout, so a clean tree stays
# clean and the fallback cannot be mistaken for a real release artefact.
sub _generate_manifest_to_tmp {
    my ($expected) = @_;
    my $root       = dirname($expected);
    my $builder    = "$root/tools/build-manifest.pl";
    return undef unless -f $builder && -f "$root/dist/config/classification.json";

    my $tmp = "/tmp/lazysite-manifest-$$.json";
    my $rc  = system( $^X, $builder, '--staged', $root, '--out', $tmp );
    return ( $rc == 0 && -s $tmp ) ? $tmp : undef;
}

sub load_manifest {
    my ($path) = @_;
    my $tmp;
    if ( !-f $path ) {
        $tmp = _generate_manifest_to_tmp($path);
        die "release-manifest.json not found at $path\n" unless $tmp;
        print "install: no release-manifest.json; generated one from the "
            . "source tree (this is a checkout, not a release tarball)\n";
        $path = $tmp;
    }
    open my $fh, '<:raw', $path
        or die "Cannot read $path: $!\n";
    my $text = do { local $/; <$fh> };
    close $fh;
    # SM304: a manifest that is PRESENT but unparseable is treated exactly as an
    # absent one, because the recovery is identical and already written above.
    #
    # A power cut during the 0.10.10 gate left this file as 66,505 bytes of nulls
    # - written, not fsynced. It is gitignored, so `git status` reported the tree
    # clean and nothing pointed at it. Both readers of this file died, with
    # different messages, and NEITHER considered regenerating a file it knows how
    # to regenerate. That is the same gap written twice, which is the whole
    # argument of SM304.
    my $parsed = eval { JSON::PP::decode_json($text) };
    if ( !$parsed && !$tmp ) {
        my $why = $@ || 'unparseable';
        $tmp = _generate_manifest_to_tmp($path);
        if ($tmp) {
            print "install: $path could not be parsed ($why); regenerated one "
                . "from the source tree\n";
            open my $rfh, '<:raw', $tmp or die "Cannot read $tmp: $!\n";
            $text = do { local $/; <$rfh> };
            close $rfh;
            $parsed = eval { JSON::PP::decode_json($text) };
        }
    }
    die "Cannot parse $path: $@\n" unless $parsed;
    unlink $tmp if $tmp;
    return $parsed;
}

# =========================================================
# ---------- helpers ----------
# =========================================================

# SM293: where this site keeps its engine tree.
#
# Module-free, and that is not laziness: install.pl is the bootstrap that
# INSTALLS the payload containing lib/, so it cannot depend on it. Mirrors
# Lazysite::Paths::lazysite_dir and the processor's copy; t/lint/37 drives all
# three and compares their answers.
#
# This one matters more than the others. Every write into the engine tree flows
# through the {LAZYSITE} placeholder below, so an installer that computed
# "<docroot>/lazysite" would RE-CREATE the tree inside the docroot on the next
# upgrade of a migrated site - putting it in both places, which is the one state
# that is broken and invisible at the same time.
sub lazysite_dir_for {
    my ($d) = @_;
    return '' unless defined $d && length $d;
    $d =~ s{/+\z}{};
    return '' unless length $d;
    my $leaf = $d;
    $leaf =~ s{\A.*/}{};         # basename
    my $parent = $d;
    $parent =~ s{/[^/]*\z}{};    # dirname
    my $ext = "$parent/$leaf-lazysite";
    return -d $ext ? $ext : "$d/lazysite";
}

sub placeholders {
    my ( $docroot, $cgibin ) = @_;
    return (
        DOCROOT  => $docroot,
        CGIBIN   => $cgibin,
        LAZYSITE => lazysite_dir_for($docroot),

        # SM1361: where the engine's tools and lib are for the steps that run
        # them - this payload on a shared-engine site, the site's own copy
        # beside the docroot everywhere else.
        ENGINE => ( $SHARED_ENGINE ? $STAGE_DIR : _site_root_for($docroot) ),

        # SM321: the private store, so it can be DECLARED like every other
        # runtime directory instead of being created by whichever code path
        # happens to reach it first.
        #
        # It was the only runtime directory not in runtime_paths, and that single
        # omission produced a chain of defects: install never created it, so
        # `check` needed bespoke repair code (SM313), so the operator needed a
        # special command with hand-assembled paths, so a sweep and a CGI protect
        # raced to create it with different ownership (SM323) and whichever won
        # decided whether partner surfaces could protect content at all.
        #
        # DUPLICATED FROM Lazysite::Private::private_root ON PURPOSE. This
        # installer is core-Perl-only by design - it must run before, and
        # independently of, the engine it installs, so it cannot load the module
        # that owns this path. t/lint/51 asserts the two constructions agree,
        # which is the same treatment ADR 0008's frozen fields get in t/lint/45:
        # where a fact must exist twice, the second copy is pinned to the first.
        PRIVATE_STORE => _private_store_for($docroot),
    );
}

# The directory the site's own engine copy sits in: the docroot's parent.
sub _site_root_for {
    my ($docroot) = @_;
    return '' unless defined $docroot && length $docroot;
    ( my $d = $docroot ) =~ s{/+\z}{};
    return length $d ? dirname($d) : '';
}

# Mirrors Lazysite::Private::private_root exactly - a SIBLING of the docroot,
# not a child. Getting that wrong is what made the docroot repair miss it.
sub _private_store_for {
    my ($docroot) = @_;
    return '' unless defined $docroot && length $docroot;
    ( my $d = $docroot ) =~ s{/+\z}{};
    return '' unless length $d;
    return dirname($d) . '/' . basename($d) . '-lazysite-private';
}

sub resolve_placeholders {
    my ( $template, $subs ) = @_;
    my $out = $template;
    for my $k ( keys %$subs ) {
        $out =~ s/\{\Q$k\E\}/$subs->{$k}/g;
    }
    # Collapse any "/../" sequences where the docroot placeholder
    # introduced them (e.g. {DOCROOT}/../extensions), by normalising
    # through a simple textual pass. Do NOT use abs_path here - the
    # directory may not exist yet.
    #
    # SM268 03-F8: a TRAILING `..` counts too. This pattern needed a slash on
    # both sides, so `{DOCROOT}/../lib` collapsed to /base/lib and matched,
    # while `{DOCROOT}/..` stayed as `/base/site/..` - a string
    # make_declared_path never looks up, because the parent walk asks for
    # `/base`. The declaration for the site's parent directory was therefore
    # dead, and provisioning a site whose parent does not yet exist failed with
    # "No declared mode for directory ..." telling the operator to add an entry
    # to classification.json that was already there.
    #
    # Loop: collapsing one segment can expose another (a/b/../../c).
    1 while $out =~ s{/[^/]+/\.\./}{/}g;
    1 while $out =~ s{/[^/]+/\.\.\z}{};
    $out =~ s{/\z}{} if length($out) > 1;
    # Collapsing back past the root leaves nothing; that is the root itself, and
    # an empty string would be a lookup key no declaration can ever carry.
    $out = '/' if $out eq '';
    return $out;
}

sub sha256_of {
    my ($path) = @_;
    my $sha = Digest::SHA->new('sha256');
    $sha->addfile( $path, 'b' );
    return $sha->hexdigest;
}

sub write_text {
    my ( $path, $text ) = @_;
    make_path( dirname($path) );
    open my $fh, '>:raw', $path or die "Cannot write $path: $!\n";
    print $fh $text;
    close $fh;
}

sub info {
    my ($msg) = @_;
    print STDERR "$msg\n";
}

# =========================================================
# ---------- summary + dep check + next steps ----------
# =========================================================

sub print_summary {
    my ( $mode, $manifest, $stats, $backup_path, $warnings ) = @_;
    print STDERR "\n=== Install summary ($mode) ===\n";
    print STDERR "  Version:    $manifest->{version}\n";
    print STDERR "  Installed:  $stats->{installed}\n";
    print STDERR "  Overwrote:  $stats->{overwrote}\n";
    my $pcount = scalar @{ $stats->{preserved} };
    print STDERR "  Preserved:  $pcount";
    print STDERR " (operator-edited)" if $pcount;
    print STDERR "\n";
    if ($pcount) {
        print STDERR "    - $_\n" for @{ $stats->{preserved} };
    }
    print STDERR "  Removed:    $stats->{removed}\n";
    # SM939 E2: say it, so an empty site reads as a choice and not a failure.
    print STDERR "  Starter:    not installed (" . ( $STARTER_SKIPPED // 0 ) . " file(s) skipped; "
        . "--starter installs them; the choice is remembered for upgrades)\n"
        if $NO_STARTER && $STARTER_SKIPPED;
    my $ocount = scalar @{ $stats->{orphaned} };
    if ($ocount) {
        print STDERR "  Orphans:    $ocount (edited post-install, left in place):\n";
        print STDERR "    - $_\n" for @{ $stats->{orphaned} };
    }
    print STDERR "  Backup:     $backup_path\n" if $backup_path;
    # SM1142: what the move to extensions/ did, on the upgrade that did it.
    if ( @{ $stats->{extensions_rename} || [] } ) {
        print STDERR "  Extensions: converted to extensions/ (SM1142):\n";
        print STDERR "    - $_\n" for @{ $stats->{extensions_rename} };
    }

    # SM933 A2: the paths this run could not give the docroot's group. Said in the
    # summary rather than left for the reader to infer from check failures,
    # because the cause is one fact - the installer is not a member of that
    # group - and the check would report it as N separate paths.
    if ($GROUP_ADOPT_FAILED) {
        my $g = getgrgid( ( stat $INSTALL_DOCROOT )[5] // -1 ) // 'the docroot group';
        print STDERR "  Group:      $GROUP_ADOPT_FAILED created path(s) could not be given "
            . "group '$g'\n"
            . "              (this user is not a member of it, so running the install again as\n"
            . "              the site owner fails the same way. As root, either:\n"
            . "                on a Hestia host:  $STAGE_DIR/installers/hestia/lazysite-hestia-deploy.sh USER DOMAIN\n"
            . "                anywhere:          perl $STAGE_DIR/tools/lazysite-cli.pl repair --docroot $INSTALL_DOCROOT)\n";
    }
    if (@$warnings) {
        print STDERR "\nWarnings:\n";
        print STDERR "  $_\n" for @$warnings;
    }
    print STDERR "\n";
}

sub print_dep_check {
    my @missing;
    for my $check (
        [ 'Archive::Zip', 'libarchive-zip-perl',
            'theme upload (manager UI)' ],
        [ 'Template::Plugin::JSON::Escape', 'libtemplate-plugin-json-escape-perl',
            'search index (search-index.md)' ],
    ) {
        my ( $mod, $pkg, $feature ) = @$check;
        my $rc = system("perl -M$mod -e 1 2>/dev/null");
        push @missing, [ $mod, $pkg, $feature ] if $rc != 0;
    }
    return unless @missing;
    print STDERR "Missing optional Perl modules:\n";
    for my $m (@missing) {
        print STDERR "  $m->[0]    # $m->[2]\n";
    }
    print STDERR "\nOn Debian/Ubuntu:\n";
    my $pkgs = join ' ', map { $_->[1] } @missing;
    print STDERR "  sudo apt-get install $pkgs\n\n";
}

# SM933 PR1: AN INSTALL EITHER SAYS IT IS HEALTHY OR NAMES ITS OWN FAULT.
#
# The reported incident: provision printed `Installed: 265`, `Overwrote: 0` and
# four Next steps, and every request to the site answered 500. The engine
# compiled; the fault was ownership and modes that provision itself had just
# written. `lazysite-check.pl` could see all of it, and it was the one thing
# nobody had run - separately, from memory, after the install said it was done.
#
# So the installer ends by running the instrument it already ships with. The
# wiring is the whole change; the diagnosis already existed.
#
# EXIT 4, NOT 1. The files DID install - treating that as a failed command would
# be as wrong in the other direction, and SM899's rule is that a refusal is not a
# failed command. 4 says "installed, and the site is not serviceable", which is a
# different thing an operator or a wrapper script can act on separately from a
# copy that broke (1) or a usage error (2).
#
# NOT 3: `--channel-check` already returns 3 for "this upgrade would be skipped
# by the site's update channel". Two meanings on one code in one tool is how a
# deploy script comes to treat an unhealthy site as a routine skip.
sub run_health_check {
    my ($o) = @_;
    my $tool = "$STAGE_DIR/tools/lazysite-check.pl";

    # SM1220: the caller said it runs the check. Said in words, so that "not run"
    # and "healthy" do not read alike.
    if ( $o->{health_check_by_caller} ) {
        print STDERR "Health check: not run here (--health-check-by-caller); the caller runs it.\n\n";
        return 0;
    }

    # An older payload, or a partial tree, may not carry the tool. Absence is
    # reported rather than passed over: "no health check was run" and "the site
    # is healthy" must never read the same way.
    unless ( -f $tool ) {
        print STDERR "Health check: SKIPPED - $tool is not in this payload.\n"
            . "  Run `lazysite check --docroot $o->{docroot}` once it is available.\n\n";
        return 0;
    }

    my @cmd = ( $^X, $tool, '--docroot', $o->{docroot} );
    push @cmd, '--cgibin', $o->{cgibin} if length( $o->{cgibin} // '' );
    push @cmd, '--group', $o->{serving_group}
        if length( $o->{serving_group} // '' );

    print STDERR "=== Health check ===\n";
    my $rc = system(@cmd);

    if ( $rc == -1 ) {
        print STDERR "\nHealth check: COULD NOT RUN ($!).\n"
            . "  Run `lazysite check --docroot $o->{docroot}` by hand.\n\n";
        return 0;
    }

    my $status = $rc >> 8;
    if ( $status == 0 ) {
        print STDERR "\nThe site passed its own health check.\n\n";
        return 0;
    }

    print STDERR <<"TEXT";

THE INSTALL COMPLETED AND THE SITE IS NOT SERVICEABLE YET.
The files are in place - the report above names what is wrong with them. Most of
it is ownership or modes, and the check repairs what it may:

  lazysite check --docroot $o->{docroot} --fix

Anything it names as needing root is printed as the exact command to run.
TEXT
    return 4;
}

sub print_next_steps {
    my ($docroot) = @_;
    my $LAZYSITE_SHOWN = lazysite_dir_for($docroot);
    print STDERR <<"TEXT";
Next steps:
  1. Create the first account. A fresh install has NO accounts - that is
     deliberate, not a missing step, and there is no default login:

       sudo -u <site user> perl $docroot/../tools/lazysite-users.pl \\
            --docroot $docroot setup-sysop --user <name>

     It prints a single-use link for that person to set their own password,
     so no password is chosen for them or sent to them. Run it again with
     another name for each further sysop.
  2. Install a layout + theme via the manager UI at /manager/themes.
     A fresh install has no default layout - the processor falls
     back to a built-in template until a layout is installed and
     a compatible theme is activated via /manager/config. Set
     'layout:' and 'theme:' in lazysite.conf to point at them.
  3. Edit $LAZYSITE_SHOWN/lazysite.conf to configure your site.
  4. Replace $docroot/index.md with your content.
  5. After any control-panel action that rebuilds this domain's web server
     configuration, re-run the health check:

       lazysite check --docroot $docroot

     A rebuild can reset directory modes under the document root, and the
     engine needs group write on the paths it was given. The check names any
     path it finds in that state, and --fix repairs the ones it may.

TEXT
}

__END__

=head1 NAME

install.pl - install or upgrade lazysite in place

=head1 SYNOPSIS

  install.pl --docroot PATH --cgibin PATH [--domain NAME] [--dry-run]

=head1 DESCRIPTION

Installs or upgrades lazysite in place from the shipped release manifest. On the
first run it creates a fresh installation; on later runs it upgrades, overwriting
project-owned code while preserving operator-edited content (pages, custom docs)
per the manifest's C<code>/C<seed> classification. Per-file SHAs are recorded in
F<lazysite/.install-state.json> so an edited seed file is never clobbered and an
unwritable file is skipped non-fatally.

=head1 OPTIONS

=over 4

=item B<--docroot> PATH

Path to the web document root (required).

=item B<--cgibin> PATH

Path to the C<cgi-bin> directory (required).

=item B<--domain> NAME

Domain name for the C<site_url> in a newly-seeded F<lazysite.conf> (used only
when seeding a fresh config).

=item B<--dry-run>

Compute and print the plan without making any filesystem change. Run this before
an upgrade to see what would be written.

=item B<--force>

Upgrade even when the site's C<update_channel> would skip this release (for
example a C<stable> site taking an C<edge> build). A deliberate operator override,
recorded in the site's audit log as C<upgrade-forced>.

=item B<--force-security>

C<--force>, for a security release only (SM1307): refused, before any site is
read, unless this payload's C<release-manifest.json> declares
C<"security_critical": true>. With B<--channel-check>, a site whose channel
refuses the build answers 0 and says it was forced. The Hestia fleet updater's
C<--force-security> passes it through the per-site deploy. Recorded as
C<upgrade-forced>, naming the override.

=item B<--channel> C<edge>|C<beta>|C<stable>|C<certified>

Set the site's update channel (the C<update_channel:> key in C<lazysite.conf>) and
exit - a standalone maintenance operation, no install. The ladder is
C<edge> E<lt> C<beta> E<lt> C<stable> E<lt> C<certified>, and a site accepts
builds at its own rung or above. Use it to pin a deployment to C<stable>
(customer rollout) or move it back to C<edge>, without hand-editing
the conf. An unrecognised value in the conf is treated as C<stable> - the most
restrictive rung - and reported (SM356). Recorded in the audit log as C<channel-set>. lazysite has no central
registry of sites, so to set a whole fleet, loop this over your docroots:

    for d in /home/*/web/*/public_html; do
        install.pl --channel stable --docroot "$d"
    done

=item B<--verify>

Is the code B<installed> at C<--docroot>/C<--cgibin> actually this payload's
version? The deploy-gap detector: it compares what is on disk against the
release manifest and reports the difference, exiting non-zero when they
disagree. Needs both C<--docroot> and C<--cgibin>; changes nothing.

=item B<--health-check-by-caller>

Do not run the health check at the end of the install; the caller runs it. The
Hestia deploy passes this and runs the check as root once its permission pass is
done, because the check run as the site user cannot read the web server group's
private store. The report says the check was not run.

=item B<--channel-check>

Would an upgrade of this site be skipped by its C<update_channel>? Exits 3 if
it would, 0 otherwise, so a deploy can bail before touching the site. Needs
C<--docroot>; reads C<lazysite.conf> and the release manifest only - no file
changes and no ownership requirement.

=item B<--policy> C<auto>|C<manual>

Set the site's update policy (the C<update_policy:> key in C<lazysite.conf>) and
exit - a standalone maintenance operation, no install. C<auto> opts the site in
to fleet-wide C<lazysite upgrade --all> runs (e.g. cron-driven); C<manual> (the
default when the key is absent) means only a deliberate per-site upgrade - or
C<upgrade --all --force>/C<--force-security> - touches it. Recorded in the audit
log as C<policy-set>.

=item B<--site-url> I<URL>

Set the site's address (the C<site_url:> key in C<lazysite.conf>) and exit - a
standalone maintenance operation, no install. The value is an absolute C<http> or
C<https> origin with no path and no C<${...}> placeholder, such as
C<https://example.com>. A new site's conf holds the
C<${REQUEST_SCHEME}://${SERVER_NAME}> template, which only a web request can
expand; the address set here is the one a link made on the command line (a claim
link) is built on. Recorded in the audit log as C<site-url-set>.

=item B<--restore-full> I<FILE>

Restore a full-system backup (created by the manager's "full" backup) into
C<--docroot>, and clear the render caches. Pass C<--domain> I<NAME> to rewrite the
site's C<domain:> - the temp-domain to final-domain migration path (build a site on
a temporary domain, then migrate it, content + config + accounts intact, to the
final domain). A deliberate system-user operation: a full backup carries the auth
secrets, so restore is not exposed in the manager UI. Recorded as C<full-restore>.

This one command is the whole procedure: a full backup carries the docroot only, so
it also lays the engine's entry points (the C<cgi-bin> scripts, and the lib, tools
and extensions beside the docroot) from the release it runs, by the code C<--mode
provision> uses, gives the tree the group and modes an install gives it, and ends
with the health check (exit 4 when the site is not serviceable yet, as an install
does). It needs C<--cgibin>, as provision does, and takes C<--serving-group> for
the group the web server runs as. When the entry points cannot be laid it refuses
before extracting anything, and says what to run.

    install.pl --restore-full full-20260704T101500Z.tar.gz \
        --docroot /home/site/public_html --cgibin /home/site/cgi-bin \
        --domain www.example.com --serving-group www-data

=item B<--help>

Print the usage summary.

=back

=head1 SEE ALSO

L<lazysite-check.pl(1)>, L<lazysite-users.pl(1)>. See also
F<installers/hestia/INSTALL-RUNBOOK.md> and F<docs/IMPLEMENTOR.md>.

=cut
