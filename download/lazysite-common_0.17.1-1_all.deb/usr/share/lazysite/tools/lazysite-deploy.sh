#!/usr/bin/env bash
#
# Watch the lazysite dist directory and deploy each new version bump to the
# Hestia host as it appears. Detects the latest lazysite-X.Y.Z.tar.gz, and
# on any strictly-higher version, scp/extract/run the Hestia updater.
#
# Usage: lazysite-deploy.sh [--baseline X.Y.Z] [--help]
#
#   --baseline X.Y.Z  treat X.Y.Z as the last version already deployed, instead
#                     of taking the baseline from whatever is in dist at start.
#
# WHY --baseline EXISTS. The watcher's baseline is normally the highest version
# already in dist when it starts, which is right while it keeps running: it
# deploys each bump as it appears. But a release that lands while the watcher is
# DOWN is in dist by the time it comes back, so it becomes the baseline and is
# never deployed - the release is silently absorbed. The workaround was to
# rename the tarball so the watcher could not see it, then rename it back.
#
#   lazysite-deploy.sh --baseline 0.10.31   # 0.10.32 in dist WILL be deployed
#
# Give the version you have actually deployed. Anything strictly higher then
# deploys as usual, including something already sitting in dist.
#
set -euo pipefail

# No defaults that name anyone's infrastructure: this ships in the repository,
# and a hostname baked into a released artefact is a detail about the operator
# rather than about lazysite. Both are required.
HOST=${LAZYSITE_HOST:-}
DIST=${LAZYSITE_DIST:-}
POLL=${LAZYSITE_POLL:-4}

# True if $1 exists and sits on a fuse (sshfs) filesystem that is responding.
# Fails when the sshfs mount is absent or its transport has dropped.
mount_ok() {
    local dir=$1 fstype
    fstype=$(findmnt -no FSTYPE --target "$dir" 2>/dev/null) || return 1
    case $fstype in fuse.sshfs|fuse*) ;; *) return 1 ;; esac
    ls "$dir" >/dev/null 2>&1
}

# True if $1 is a strictly higher version than $2 (sort -V semantics).
version_gt() {
    [ "$1" != "$2" ] &&
    [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -n1)" = "$1" ]
}

# Print the highest lazysite-X.Y.Z.tar.gz version present in $1 (empty if none).
# Ignores the -nginx_*.deb artifacts and any non-plain-numeric versions.
latest_version() {
    local dist=$1 f v best=
    for f in "$dist"/lazysite-[0-9]*.tar.gz; do
        [ -e "$f" ] || continue
        v=${f##*/lazysite-}; v=${v%.tar.gz}
        case $v in *[!0-9.]*) continue ;; esac
        if [ -z "$best" ] || version_gt "$v" "$best"; then
            best=$v
        fi
    done
    [ -n "$best" ] && printf '%s\n' "$best"
}

# True if the tarball for version $1 in dir $2 is non-empty and a complete gzip.
# Guards against racing a build that is still writing the file.
tarball_ready() {
    local f="$2/lazysite-$1.tar.gz"
    [ -s "$f" ] && gzip -t "$f" 2>/dev/null
}

# Print yes, no or unreadable: whether the release-manifest.json of version $1,
# inside tarball $2, declares "security_critical": true. The tarball is the
# stage the updater runs from once unpacked, so this is the manifest the
# updater's own --force-security check reads, and the test is the same: the
# key's truth, as JSON::PP decodes it.
security_critical() {
    local ver=$1 tarball=$2 rc=0
    tar -xzOf "$tarball" "lazysite-$ver/release-manifest.json" 2>/dev/null |
        perl -MJSON::PP -e 'local $/; my $m = eval { JSON::PP->new->decode(<STDIN>) }; exit 2 unless ref $m eq "HASH"; exit( $m->{security_critical} ? 0 : 1 )' ||
        rc=$?
    case $rc in
        0) printf 'yes\n' ;;
        1) printf 'no\n' ;;
        *) printf 'unreadable\n' ;;
    esac
}

# The flags the updater must be given for a given target version.
#
# SM345 - WHAT CHANGED, AND WHY: this passed `--rebuild` on EVERY deploy.
# `--rebuild` implies `--templates`, so every edge cut refreshed the SHARED
# Hestia web template and rebuilt every domain's vhost - including sites sitting
# on beta and stable, which the release was never meant to reach. That is a
# template change applied to sites running older code, arriving at whatever
# moment their vhost next rebuilds. A channel ladder that gates the code and not
# the template is only half a ladder.
#
# So the default is now a PLAIN deploy. The updater itself is channel-scoped
# (SM345): it works out which sites accept this build and touches only those -
# no repair, no probe, no rebuild on anything else.
#
# --rebuild / --templates are PROMOTION-TIME flags now, passed deliberately:
#   * when the release actually changes the web template, or
#   * when promoting to the channel the affected sites are on.
# Pass them with LAZYSITE_DEPLOY_FLAGS, e.g.
#   LAZYSITE_DEPLOY_FLAGS='--rebuild' ./lazysite-deploy.sh
# The SM270 ordering they exist for still holds inside the updater: refresh,
# rebuild, THEN deploy, so the deploy's permission sweep repairs what Hestia's
# rebuild resets. That ordering is why they must not be run as a separate step.
#
# --reapply-acls re-issues every stored access rule so its content actually
# MOVES out of the document root. From 0.10.8 protecting content moves it, but
# only on the act of protecting - so any section protected on an earlier version
# still has its files in the served tree, with the rule honoured for pages and
# the files public. It changes no rule, and it must run AFTER the upgrade.
# It is per-site and the updater applies it only to sites that actually
# upgraded, so it cannot reach an out-of-scope site.
#
# Version-gated because this watcher deploys whatever appears in dist: passing a
# flag to a release that predates it fails the whole run on an unknown option.
#
# SM1315 (ruling 45): --force-security when the release declares itself
# security-critical. 0.16.2 did, and the updater scoped it by each site's
# update_channel, so it reached the edge sites only and the rest were pushed by
# hand. The declaration is read from the release's own manifest (see
# security_critical above); a missing or false key, or a manifest that cannot be
# read, adds nothing. No version gate is needed: a manifest carries the key only
# from 0.16.2 (SM1305), whose updater takes the flag (SM1307). It changes which
# SITES the updater puts in scope, never which VERSIONS this watcher deploys: a
# version that is not strictly higher is still not deployed.
updater_flags() {
    local ver=$1 tarball=${2:-} flags="${LAZYSITE_DEPLOY_FLAGS:-}" sc
    # An `if`, not `a && b`: this script runs under `set -e` unattended, and a
    # bare AND-list whose left side fails is exactly the construct whose -e
    # behaviour people disagree about. Not worth being clever in a deploy loop.
    if version_gt "$ver" '0.10.8'; then
        flags="$flags --reapply-acls"
    fi
    if [ -n "$tarball" ]; then
        sc=$(security_critical "$ver" "$tarball")
        case $sc in
            yes)
                case " $flags " in
                    *' --force-security '*) ;;
                    *) flags="$flags --force-security" ;;
                esac
                ;;
            unreadable)
                printf 'lazysite-deploy: %s: no readable release-manifest.json in %s; deploying without --force-security\n' \
                    "$ver" "$tarball" >&2
                ;;
        esac
    fi
    printf '%s\n' "$flags"
}

# scp + extract + run the Hestia updater for version $1. Streams remote stdout.
#
# RETURNS the updater's own exit status, which SM344 made meaningful:
#   0  rollout succeeded, in-scope fleet clean
#   2  rollout SUCCEEDED and the fleet has findings a human must look at -
#      including a site that installed and is NOT serviceable (Q16f: the
#      updater reported that as a channel skip, and this printed "deployed")
#   *  the rollout failed
deploy() {
    local ver=$1 src="$DIST/lazysite-$1.tar.gz" flags rc=0
    flags=$(updater_flags "$ver" "$src")
    printf '\n=== Deploying %s -> %s (%s) ===\n' "$ver" "$HOST" "${flags:-plain deploy}"
    scp "$src" "$HOST:/tmp" || return 1
    ssh "$HOST" "cd /tmp; tar -xzf lazysite-$ver.tar.gz" || return 1

    # `|| rc=$?` RATHER THAN `set +e` / `set -e` AROUND IT.
    #
    # set -e is a SHELL option, not a function-local one. This used to do
    # `set +e; ssh ...; rc=$?; set -e; return "$rc"` - and that final `set -e`
    # takes effect immediately, so the function returned a non-zero status with
    # -e freshly re-enabled. The caller's own `set +e` had already been undone
    # from underneath it, so the failing command was the CALL to this function
    # and the whole watcher exited.
    #
    # It exited with the updater's own status, which made it invisible: status 2
    # is SM344's "rollout succeeded, fleet has findings" - a SUCCESSFUL deploy.
    # So the watcher deployed, printed the success text, and died, every time
    # the fleet had findings. From outside that is "it deployed once and
    # stopped", and the next release then sat in dist with nothing watching it.
    # 0.10.14 was missed exactly this way, after 0.10.13's deploy returned 2.
    #
    # `|| rc=$?` never trips -e in the first place, so no option needs saving
    # or restoring and there is nothing to leave in the wrong state.
    #
    # No STAGE argument (SM1316): the updater's stage defaults to the release it
    # runs from, which is /tmp/lazysite-$ver - giving it again said it twice.
    ssh "$HOST" "cd /tmp; sudo bash /tmp/lazysite-$ver/installers/hestia/lazysite-hestia-update-all.sh $flags" || rc=$?
    return "$rc"
}

# Watch $DIST and deploy every new version bump as it appears.
watch_and_deploy() {
    local given=${1:-} current next rc tick=0 mount_lost=0
    # Required to DEPLOY, not to ask for help - so this sits here rather than at
    # the top of the file, where it would make --help fail for anyone who has
    # not configured the watcher yet.
    if [ -z "$HOST" ] || [ -z "$DIST" ]; then
        printf 'Set LAZYSITE_HOST and LAZYSITE_DIST.\n' >&2
        printf '  LAZYSITE_HOST  the Hestia host to deploy to\n' >&2
        printf '  LAZYSITE_DIST  the dist/ directory to watch\n' >&2
        exit 2
    fi
    if ! mount_ok "$DIST"; then
        printf 'Error: %s is not on a mounted sshfs filesystem\n' "$DIST" >&2
        exit 1
    fi
    if [ -n "$given" ]; then
        # An EXPLICIT baseline. Say where it came from, because the difference
        # matters: a detected baseline means "deploy the next bump", a given one
        # means "deploy anything above this, including what is already here".
        current=$given
        printf 'Watching %s (baseline: %s, given)\n' "$DIST" "$current" >&2
        next=$(latest_version "$DIST" || true)
        if [ -n "$next" ] && version_gt "$next" "$current"; then
            printf '%s is already in dist and is newer - it will deploy now\n' \
                "$next" >&2
        fi
    else
        current=$(latest_version "$DIST" || true)
        printf 'Watching %s (baseline: %s, detected)\n' "$DIST" "${current:-none}" >&2
    fi
    while true; do
        # A LOST MOUNT IS A PAUSE, NOT AN END. This used to exit, so a transient
        # sshfs drop - which a long deploy is very good at producing, since the
        # transport sits idle while the remote updater runs for minutes - ended
        # the watcher. From the outside that looks like "it deployed once and
        # stopped", because that is exactly what it did.
        #
        # Waiting instead cannot cause a deploy that would not otherwise have
        # happened: the version comparison below is unchanged, and a version
        # already deployed is not deployed again.
        if ! mount_ok "$DIST"; then
            if [ "$mount_lost" -eq 0 ]; then
                printf '\nsshfs mount at %s is not responding - waiting for it\n' \
                    "$DIST" >&2
                mount_lost=1
            fi
            sleep "$POLL"
            continue
        fi
        if [ "$mount_lost" -eq 1 ]; then
            printf 'sshfs mount at %s is back; resuming\n' "$DIST" >&2
            mount_lost=0
        fi
        next=$(latest_version "$DIST" || true)
        if [ -n "$next" ] && { [ -z "$current" ] || version_gt "$next" "$current"; } &&
           tarball_ready "$next" "$DIST"; then
            # Same reasoning as inside deploy(): no option juggling, so
            # nothing can leave -e in a state the other side did not expect.
            rc=0
            deploy "$next" || rc=$?
            case $rc in
                0)
                    printf '\nVersion %s deployed\n\n' "$next" >&2
                    ;;
                2)
                    # SM344: the rollout WORKED. The findings are conditions the
                    # fleet was already in - out-of-scope sites on older lines,
                    # sites needing a repair nobody has run. Re-deploying does
                    # not change them and neither does cutting another version,
                    # so do NOT tell the operator to bump. Saying "failed" here
                    # is what made a working release look broken, and it teaches
                    # the reader to ignore the word when it is true.
                    printf '\nVersion %s deployed - FLEET HAS FINDINGS (see above).\n' "$next" >&2
                    printf 'The deploy succeeded. The findings need a human, not a retry\n' >&2
                    printf 'and not a version bump.\n\n' >&2
                    ;;
                *)
                    printf '\nDeploy of %s FAILED (status %s); skipping (bump again to retry)\n\n' \
                        "$next" "$rc" >&2
                    ;;
            esac
            current=$next
            continue
        fi
        case $((tick % 2)) in 0) printf -- '-\r' >&2 ;; *) printf '|\r' >&2 ;; esac
        tick=$((tick + 1))
        sleep "$POLL"
    done
}

# Printed from the header comment itself, delimited by markers rather than line
# numbers, so editing anything above it cannot silently truncate the help.
usage() {
    sed -n '/^# Usage:/,/^set -euo pipefail$/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'
}

# Validated to the SAME shape latest_version accepts, so a baseline can always
# be compared with what is in dist. A typo would otherwise sort unpredictably
# against real versions and either deploy nothing or deploy everything. Checked
# where the value is READ, not after the loop, so an explicitly empty
# --baseline '' is an error rather than a silent fall back to detection.
check_baseline() {
    case ${1-} in
        ''|*[!0-9.]*|.*|*.)
            printf 'lazysite-deploy: --baseline must be a plain version like 0.10.31 (got: %s)\n' \
                "${1-}" >&2
            exit 2
            ;;
    esac
}

# Parsing lives in a FUNCTION, not inline in the dispatch block, so a test can
# drive the real parser instead of a copy of it that can drift from it.
parse_args() {
    BASELINE=
    while [ $# -gt 0 ]; do
        case $1 in
            --baseline)
                [ $# -ge 2 ] || { printf 'lazysite-deploy: --baseline needs a version, e.g. --baseline 0.10.31\n' >&2; exit 2; }
                check_baseline "$2"
                BASELINE=$2
                shift 2
                ;;
            --baseline=*)
                check_baseline "${1#*=}"
                BASELINE=${1#*=}
                shift
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                printf 'lazysite-deploy: unknown option %s\n' "$1" >&2
                usage >&2
                exit 2
                ;;
        esac
    done
}

if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    parse_args "$@"
    watch_and_deploy "$BASELINE"
fi
