#!/usr/bin/perl
# lazysite-check - install health / permissions doctor.
#
# Verifies that a lazysite docroot is set up so the (no-suexec, www-data) CGI
# can read its config and write the things it must write (cache, logs, locks,
# secrets), that secrets are not world-exposed, and that the manager is
# bootstrapped. Reports OK / WARN / FAIL per check with a remediation hint;
# exits non-zero if anything FAILs. With --fix it applies the safe fixes
# (chmod always; chown only when run as root) and then RE-RUNS every check, so
# the printed report reflects the post-fix state (SM139 increment 5 - the old
# pre-fix snapshot misled operators in the field).
#
# Effective-access checks are evaluated as the CGI identity via ownership+mode
# arithmetic, never via -r/-w/-x: run as root those answer for root, which
# bypasses DAC and silently passes files the www-data CGI cannot touch.
#
#   perl tools/lazysite-check.pl --docroot /path/to/public_html [--fix]
#   options: --cgibin PATH  --owner USER  --group GROUP  --fix  --help
#
# Core-Perl only.
use strict;
use warnings;
use Cwd        qw(abs_path);
use File::Find ();
use POSIX      ();
use JSON::PP   ();             # core; every call site is fully qualified

my %opt = ( docroot => undef, cgibin => undef, owner => undef,
    group        => undef, fix => 0, check_dav => undef, check_acl => undef,
    dependencies => 0 );

# SM285 probe state. Declared HERE, at the top, because this file's main body
# exits before its sub definitions are reached - so a `my` down beside the subs
# never executes. That is not a style point: the first version of the probe put
# its extension list down there, the list was empty when the probe ran, and it
# reported a leaking front end healthy. perlcritic flags the same hazard as
# unreachable code. Anything the probe needs at runtime is declared up here.
my $PROBE_DIR;    # absolute path of the probe directory
my $PROBE_KEY;    # the ACL key we added, so an interrupt can withdraw it

while (@ARGV) {
    my $a = shift @ARGV;
    if    ( $a eq '--docroot' )       { $opt{docroot}       = shift @ARGV }
    elsif ( $a eq '--cgibin' )        { $opt{cgibin}        = shift @ARGV }
    elsif ( $a eq '--owner' )         { $opt{owner}         = shift @ARGV }
    elsif ( $a eq '--group' )         { $opt{group}         = shift @ARGV }
    elsif ( $a eq '--fix' )           { $opt{fix}           = 1 }
    elsif ( $a eq '--check-dav' )     { $opt{check_dav}     = shift @ARGV }
    elsif ( $a eq '--check-acl' )     { $opt{check_acl}     = shift @ARGV }
    elsif ( $a eq '--dependencies' )  { $opt{dependencies}  = 1 }
    elsif ( $a eq '--sinks' )         { $opt{sinks}         = 1 }
    elsif ( $a eq '--handover-mode' ) { $opt{handover_mode} = shift @ARGV }
    elsif ( $a eq '--help' )          { usage(); exit 0 }
    else { print STDERR "lazysite-check.pl: unknown option '$a'\n"; exit 2 }
}

# SM126 D: host-dependency query. A standalone check of the OS-level Perl
# modules lazysite needs (from dist/config/sbom-deps.json) - no docroot needed,
# so it runs before the docroot validation below. A sysop (or an onboarding
# agent) can ask "what must I install here" and get the missing-package line.
run_dependency_check() if $opt{dependencies};    # exits

# Introspection for the regression tests (the chown-handover logic is only
# reachable as root): print what handover_mode() computes for an octal mode.
if ( defined $opt{handover_mode} ) {
    printf "%04o\n", handover_mode( oct( $opt{handover_mode} ) );
    exit 0;
}

sub usage {
    print <<'USAGE';
lazysite-check - install health / permissions doctor

Usage: perl tools/lazysite-check.pl --docroot PATH [options]

  --docroot PATH   the site's public_html (required)
  --cgibin PATH    the cgi-bin dir (default: <docroot>/../cgi-bin)
  --owner USER     expected owner (default: the owner of the docroot)
  --group GROUP    expected group (default: the group of the docroot)
  --fix            apply the safe fixes (chmod always; chown only as root),
                   then re-run the checks - the report shows the post-fix state.
                   On the docroot's own content directories it restores GROUP
                   WRITE and nothing else: without it the CGI cannot save, and
                   every other bit is your choice, not the model's (SM274). A
                   mode that differs any other way is reported, never changed.
  --check-dav URL  probe URL/dav/ unauthenticated; expect 401 (route wired), not
                   404 (route missing - the web server / proxy does not forward /dav/)
  --check-acl URL  ask whether PROTECTED CONTENT is reachable: briefly gate a
                   probe folder, fetch it anonymously from URL under several
                   file extensions, and FAIL if any bytes come back. Several
                   extensions on purpose - SM283 leaked .png/.pdf/.txt and
                   gated .dat, so a one-extension probe reports OK on a leaking
                   site. Writes a temporary entry to the ACL store and removes
                   it, including after an interrupt.
  --sinks          send one marked diagnostic line through the engine's syslog
                   forwarding and report whether the system log received it
                   (SM932). Writes one line to the host's log, so it is asked
                   for, never run by default. The web server's error log (the
                   CGI's STDERR) is not probed: this command's STDERR is the
                   terminal, not the web server's.
  --dependencies   report the OS Perl packages lazysite needs (present vs missing)
                   and the install line for whatever is absent; no docroot needed
  --help           this help

Exit status is non-zero if any check FAILs.
USAGE
}

# SM126 D: report required non-core Perl modules vs what is present on this host,
# reading the authoritative list from dist/config/sbom-deps.json. Informational
# (always exits 0); the doc docs/reference/host-dependencies.md is generated from
# the same source by tools/gen-host-deps.pl.
sub run_dependency_check {
    my $self = abs_path($0);
    ( my $tools = $self )  =~ s{/[^/]*$}{};
    ( my $root  = $tools ) =~ s{/[^/]*$}{};
    my $deps_path = "$root/dist/config/sbom-deps.json";
    unless ( -f $deps_path ) {
        print STDERR "lazysite-check.pl: dependency metadata not found at $deps_path\n"
            . "  (run this from a lazysite source tree or release tarball)\n";
        exit 2;
    }
    open my $fh, '<', $deps_path
        or do { print STDERR "lazysite-check.pl: cannot read $deps_path: $!\n"; exit 2 };
    my $json = do { local $/; <$fh> };
    close $fh;
    my $data    = JSON::PP->new->decode($json);
    my $modules = $data->{modules} || {};

    print "lazysite host dependencies (from dist/config/sbom-deps.json)\n\n";
    print "Non-core Perl modules:\n";
    my ( $present, $total, %missing_pkg );
    for my $mod ( sort keys %{$modules} ) {
        my $m = $modules->{$mod};
        next if $m->{core};
        $total++;
        ( my $file = $mod ) =~ s{::}{/}g;
        # Probe a module named in the trusted local SBOM file; block-form require
        # of a path string, no injection surface.
        my $ok = eval { require "$file.pm"; 1 }; ## no critic (Modules::RequireBarewordIncludes)
        if ($ok) {
            $present++;
            printf "  %-8s %-22s %s\n", 'OK', $mod, ( $m->{debian_pkg} // '' );
        }
        else {
            my $pkg = $m->{debian_pkg} // '';
            $missing_pkg{$pkg} = 1 if length $pkg;
            printf "  %-8s %-22s %-26s (%s)\n", 'MISSING', $mod, $pkg,
                ( $m->{used_by} // '' );
        }
    }

    if ( my $env = $data->{environment} ) {
        print "\nRuntime environment (operator-provided):\n";
        printf "  %-20s %s\n", $_->{name} // '', $_->{description} // '' for @{$env};
    }

    print "\n$present of $total non-core modules present.\n";
    if (%missing_pkg) {
        print "Missing - on Debian/Ubuntu install with:\n\n";
        print "  sudo apt-get install " . join( ' ', sort keys %missing_pkg ) . "\n";
    }
    else {
        print "All required non-core modules are installed.\n";
    }
    exit 0;
}

my $DOC = $opt{docroot};
unless ( defined $DOC && -d $DOC ) {
    print STDERR "lazysite-check.pl: --docroot must be an existing directory\n";
    exit 2;
}
$DOC = abs_path($DOC);
# SM293: ASK where the engine tree is. A site that has moved it beside its
# docroot is still a lazysite site, and computing "$DOC/lazysite" here rejected
# it outright at the guard below - the health tool refusing to look at exactly
# the sites that had taken the safer layout.
BEGIN {
    # SM366: locate the Lazysite module tree relative to this script
    # (run-in-place, tarball and Hestia installs), falling back to the system
    # @INC (package installs). The same bootstrap lazysite-users.pl has always
    # carried; without it this tool cannot start anywhere the modules are not
    # already on @INC, which is every install that is not a package.
    require Cwd;
    require File::Basename;
    my $bin = File::Basename::dirname( Cwd::abs_path(__FILE__) );
    for my $cand ( "$bin/lib", "$bin/../lib", "$bin/../../lib" ) {
        if ( -d "$cand/Lazysite" ) { unshift @INC, $cand; last }
    }
}

require Lazysite::Paths;
my $LZ = Lazysite::Paths::lazysite_dir($DOC);

# SM293: the permission model is written in docroot-relative paths
# ("lazysite/auth"), because that is the layout it grew up in. On a MIGRATED
# site those paths are not under the docroot at all, and a bare "$DOC/$rel"
# simply does not exist - so every check below would `next unless -e` its way
# past the entire engine tree and report a clean bill of health while verifying
# nothing. The auth store's 02770 is the most important mode on the site.
sub model_path {
    my ($rel) = @_;
    return "$LZ/$1" if $rel =~ m{\Alazysite/(.*)\z};
    return $LZ      if $rel eq 'lazysite';
    return "$DOC/$rel";
}
my $CGI = defined $opt{cgibin} ? abs_path( $opt{cgibin} ) : abs_path("$DOC/../cgi-bin");

unless ( -d $LZ ) {
    print STDERR "lazysite-check.pl: no engine tree for $DOC - looked inside it "
        . "and beside it. Is this a lazysite docroot?\n";
    exit 2;
}

# --- expected owner / group (default: derived from the docroot itself) -------
my @ds      = stat $DOC;
my $exp_uid = defined $opt{owner} ? ( ( getpwnam $opt{owner} )[2] // -1 ) : $ds[4];
# Expected GROUP defaults to the CGI's group (www-data), NOT the docroot's group:
# the no-suexec CGI runs as www-data and must keep group access to the tree.
# Falling back to the docroot group only if there is no www-data group.
my $exp_gid = defined $opt{group} ? ( ( getgrnam $opt{group} )[2] // -1 )
    :   ( ( getgrnam 'www-data' )[2] // $ds[5] );
my $exp_user = ( getpwuid $exp_uid )[0] // $exp_uid;
my $exp_grp  = ( getgrgid $exp_gid )[0] // $exp_gid;
# The CGI (www-data) legitimately OWNS the files it creates at runtime - locks,
# cache entries, generated html, audit.log - so www-data ownership is valid, not a
# fault. Only a TRULY foreign owner (root, another user) breaks CGI access.
my $cgi_uid = ( getpwnam 'www-data' )[2];

# --- result collection -------------------------------------------------------
my ( @results, @chmod_fixes, $chown_needed, $tt_cache_bad, @stale_registries );
my ( $git_fix_root, $git_shared_fix );
my $store_create_needed;    # SM313: the private store to create under --fix
my $store_repair_needed;    # SM323: an existing store whose owner/mode locks the CGI out
sub report {    # (level, message, [hint])
    my ( $level, $msg, $hint ) = @_;

    # SM584: the level is a closed vocabulary. A typo used to pass straight
    # through: the icon printed empty, perl warned about an undefined value,
    # and - the part that mattered - the summary counts `eq 'OK'`, so a
    # mis-spelled level was counted as neither ok, warning nor failure and
    # vanished from both the tally and the exit code. A check whose answer
    # nobody sees is worse than a check that is not there.
    die "report: unknown level '$level' for: $msg\n"
        unless $level =~ /\A(?:OK|WARN|FAIL)\z/;
    push @results, { level => $level, msg => $msg, hint => $hint };
}

# Q16g: A WALK THAT CANNOT READ A DIRECTORY SAYS SO, AS A FINDING.
#
# File::Find warns "Can't opendir(DIR): Permission denied" and carries on, so a
# check run as a user that cannot read part of the site - the private store at
# <docroot>-lazysite-private/sites, on the 0.15.4 rollout - printed that raw
# Perl warning and then reported its result as if the walk were complete. Every
# walk in this tool goes through here: the warnings are collected, not printed,
# and the directories each check left unread become one WARN naming them, the
# check that could not cover them, and how to run the check so it can. Kept per
# check across its roots (a check walks the docroot and the private store in
# turn) and reported with the results, after any --fix pass: run_checks empties
# the checks' entries with the results, and the --fix pass's own walks are kept
# across its passes.
my %unread_by;    # check => { directory => error }

sub find_noting {    # ( $what, \%find_options, @roots )
    my ( $what, $opts, @roots ) = @_;
    local $SIG{__WARN__} = sub {
        my ($m) = @_;
        if ( $m =~ /\ACan't opendir\((.*?)\): ([^\n]*)/
            || $m =~ /\ACan't stat (.*?): ([^\n]*)/
            || $m =~ /\ACan't cd to (.*?): ([^\n]*)/ )
        {
            $unread_by{$what}{$1} //= $2;
            return;
        }
        print STDERR $m;
    };
    File::Find::find( $opts, @roots );
    return;
}

sub report_unread_walks {
    report_unread( $_, $unread_by{$_} ) for sort keys %unread_by;
    return;
}

# n825 (SM1447): AN OK LINE SAYS WHAT WAS LOOKED AT. A walk that could not read part
# of the tree reports that part in its own WARN (report_unread, with the user to run as),
# and says no ok about the whole: an ok beside a warning that the same check missed
# directories read as a clean result. Always true, so a caller that returns it still returns.
sub report_ok_read {    # ( $what, @report_args )
    my ( $what, @args ) = @_;
    report( 'OK', @args ) unless keys %{ $unread_by{$what} || {} };
    return 1;
}

sub report_unread {    # ( $what, \%dir_to_error )
    my ( $what, $u ) = @_;
    my @dirs = sort keys %$u;
    my $who  = getpwuid($>) // "uid $>";
    my @show = map { "$_ ($u->{$_})" } @dirs;
    my $more = @show > 8 ? ' (and ' . ( @show - 8 ) . ' more)' : '';
    splice @show, 8 if @show > 8;
    report( 'WARN',
        "$what could not read " . scalar(@dirs) . " director" . ( @dirs == 1 ? 'y' : 'ies' )
            . " as $who: " . join( ', ', @show ) . $more
            . ' - nothing below '
            . ( @dirs == 1 ? 'it' : 'them' )
            . ' was looked at, so this result covers the rest of the site only',
        _run_as_remedy(@dirs) );
    return;
}
sub owner_name { ( getpwuid( ( stat $_[0] )[4] ) )[0] // ( stat $_[0] )[4] }
sub group_name { ( getgrgid( ( stat $_[0] )[5] ) )[0] // ( stat $_[0] )[5] }
sub mode_of    { ( stat $_[0] )[2] & 07777 }

# SM907 AT4: WHAT GOES WRONG, per file. One sentence covered the whole list -
# "the manager cannot save it" - and it is wrong about the audit log, which no
# manager saves: every surface APPENDS to it, and what an operator loses is the
# record, silently. An operator who reads the true consequence knows whether they
# have a cosmetic fault or a missing audit trail.
my %UNWRITABLE_MEANS = (
    'lazysite/logs/audit.log' =>
        'every surface appends here, so events are being LOST as they happen '
        . 'and the Audit page shows a short list that looks healthy',
    'lazysite/logs/audit-reads.log' =>
        'MCP and the control API append the AI read audit here (SM1325), so those '
        . 'rows are being LOST and the Audit page\'s AI reads view looks quiet',
    'lazysite/auth/groups-settings.json' =>
        'the manager cannot save a capability change, and a group whose record '
        . 'cannot be written cannot be given to a person',
    'lazysite/auth/.consume.lock' =>
        'every account change and single-use link (a reset, an invitation) is refused, '
        . 'since none may run unlocked',
    'lazysite/auth/users'     => 'no account can be created, changed or removed',
    'lazysite/auth/groups'    => 'no membership change can be saved',
    'lazysite/auth/acls.json' =>
        'no access rule can be saved, so a page cannot be protected or opened',
    'lazysite/nav.conf'      => 'the navigation cannot be saved',
    'lazysite/lazysite.conf' => 'no site setting can be saved',
);

sub _unwritable_consequence {
    my ($rel) = @_;
    return $UNWRITABLE_MEANS{$rel} // 'the manager cannot save it';
}


# Effective access for the CGI identity, from ownership + mode arithmetic.
# $bit is the "other" permission bit: 4 read, 2 write, 1 execute/traverse.
# Never -r/-w/-x here: run as root those answer for root, which bypasses DAC
# and passes files/dirs the www-data CGI cannot actually use (field-hit
# 2026-07-09: the manager layout, readable by root, unusable by the CGI).
sub cgi_can {    # ( $bit, @stat )
    my ( $bit, @s ) = @_;
    my $mode = $s[2] & 07777;
    return 1 if defined $cgi_uid && $s[4] == $cgi_uid && $mode & ( $bit << 6 );
    return 1 if $s[5] == $exp_gid && $mode & ( $bit << 3 );
    return ( $mode & $bit ) ? 1 : 0;
}

# The access bits a path under lazysite/git must gain, or 0 when the CGI can
# already use it (probe 7c-i and its --fix share this). The FLAG condition is
# CGI access arithmetic (cgi_can); the FIX bits also top up the owner so a
# stripped dir serves both identities (matching git's own shared-repo modes:
# dirs 2775-shaped, mutable files 0664-shaped). Dirs need group rwx + setgid
# (git creates object files inside them); loose objects/packs need group READ
# only (git deliberately keeps them read-only - mutable state is replaced via
# rename, so directory writability is the real requirement); other files get
# read+write (COMMIT_EDITMSG and FETCH_HEAD are rewritten IN PLACE, and an
# unwritable COMMIT_EDITMSG is fatal to a commit).
sub git_want_bits {    # ( $gd, $path, $is_dir, @stat )
    my ( $gd, $p, $is_dir, @s ) = @_;
    if ($is_dir) {
        return 0 if cgi_can( 4, @s ) && cgi_can( 2, @s ) && cgi_can( 1, @s );
        return 02770;
    }
    if ( index( $p, "$gd/objects/" ) == 0 ) {
        return cgi_can( 4, @s ) ? 0 : 0040;
    }
    return 0 if cgi_can( 4, @s ) && cgi_can( 2, @s );
    return 0660;
}

my $conf = "$LZ/lazysite.conf";

# All checks are collected here so --fix can run them AGAIN after applying
# fixes: the printed report must reflect the post-fix tree, not the pre-fix
# snapshot (SM139 increment 5).
sub run_checks {
    @results = ();
    delete $unread_by{$_} for grep { $_ ne '--fix' } keys %unread_by;    # Q16g
    @chmod_fixes      = ();
    @stale_registries = ();
    $chown_needed     = 0;
    $tt_cache_bad     = 0;
    $git_fix_root     = '';
    $git_shared_fix   = '';

    # --- 1. ownership: nothing under lazysite/ should be foreign-owned -----------
    {
        my ( @bad, $total );
        find_noting( 'the ownership check under lazysite/',
            { no_chdir => 1, wanted => sub {
                    my @s = lstat $File::Find::name or return;
                    return if -l _;
                   # ispadmin owns the code/content; www-data owns the files it creates at
                   # runtime (locks/cache/generated/audit) - both are fine. Flag only a
                   # truly foreign owner the CGI cannot access.
                    if ( $s[4] != $exp_uid && ( !defined $cgi_uid || $s[4] != $cgi_uid ) ) {
                        $total++;
                        push @bad, $File::Find::name if @bad < 8;
                    }
            } }, $LZ );
        if ($total) {
            my $sample = join( ', ', map { s{^\Q$DOC/\E}{}r } @bad );
            $sample .= ", …" if $total > @bad;
            report( 'FAIL',
                "$total path(s) under lazysite/ owned by neither $exp_user nor www-data "
                    . "(a foreign owner the CGI cannot access): $sample",
                "chown -R $exp_user:$exp_grp '$LZ'" );
            $chown_needed = 1;
        }
        else {
            report_ok_read( 'the ownership check under lazysite/', "lazysite/ tree owned by $exp_user (or the www-data CGI)" );
        }
    }

    # --- 2. the dirs the CGI must write: group-writable + setgid -----------------
    # (so www-data can create cache/.html, logs, locks, .secret, rate DBs, and new
    #  files inherit the group)
    my %want_dir = (
        'lazysite/backups'           => 02775,    # SM246 manager-written snapshots
        'lazysite/cache'             => 02775,
        'lazysite/logs'              => 02775,
        'lazysite/stats'             => 02775,    # SM213 durable per-day stats store
        'lazysite/stats/form-events' => 02775,    # SM216-2 form-outcome log (PII-free)
        'lazysite/manager/locks'     => 02775,
        'lazysite/layouts'           => 02775,
        'lazysite-assets'            => 02775,
        'lazysite/auth'              => 02770,
        'lazysite/forms'             => 02770,
        'lazysite/git'               => 02770,
    );
    for my $rel ( sort keys %want_dir ) {
        my $path = model_path($rel);
        next unless -e $path;                     # not every dir exists on every install
        unless ( -d $path ) { report( 'WARN', "$rel exists but is not a directory" ); next }
        my $mode = mode_of($path);
        my $want = $want_dir{$rel};
        my $gw   = ( $mode & 0070 ) >= 0070 ? 1 : ( $mode & 0020 ? 1 : 0 );
        my $sgid = $mode & 02000;
        if ( !( $mode & 0020 ) || !$sgid ) {
            my $g = group_name($path);
            report( 'FAIL',
                sprintf( "%s is %04o (group=%s) - the CGI cannot write here%s%s",
                    $rel, $mode, $g,
                    ( $mode & 0020 ? '' : '; not group-writable' ),
                    ( $sgid        ? '' : '; no setgid (new files miss the group)' ) ),
                sprintf( "chmod %04o '%s'", $want, $path ) );
            push @chmod_fixes, [ $want, $path ];
        }
        else {
            report( 'OK', sprintf( "%s writable + setgid (%04o)", $rel, $mode ) );
        }
    }

    # --- 2b. the rest of the declared model (SM268 03-F7) -----------------------
    #
    # SM246 states the design as "one table, three consumers - install applies,
    # check verifies, check --fix repairs". That was true of runtime_paths and
    # false of install_dirs: the eleven entries above are hand-written and the
    # model declares twenty-eight. So a site carrying the reported fault - the
    # docroot's content directories stripped of group write, which is the 0.6.5
    # incident SM246 exists for - stayed broken while this tool called it
    # healthy. The fix was prospective only: make_declared_path applies a mode
    # ON CREATION and never corrects an existing directory.
    #
    # Reported, not repaired, and deliberately so. These are content directories
    # on a live site; a sysop who tightened one on purpose should not have it
    # widened by a tool they ran to ask a question. --fix stays on the CGI
    # writability set above, where the mode is a functional requirement rather
    # than a default. The suggested command is printed so the repair is one
    # paste away.
    {
        my %declared;
        my $st = _read_json("$LZ/.install-state.json");
        %declared = %{ $st->{dirs} }
            if ref $st eq 'HASH' && ref $st->{dirs} eq 'HASH';
        # SM933 A5 / R16: the mode the installer actually LEFT on each directory
        # it created. See the branch that reads it below.
        my %left = ( ref $st eq 'HASH' && ref $st->{dirs_left} eq 'HASH' )
            ? %{ $st->{dirs_left} }
            : ();

        my $checked = 0;
        my $wrong   = 0;
        # SM270: the DOCROOT ITSELF is checked, and it is a FAIL rather than a
        # warning.
        #
        # SM268 03-F7 excluded it along with the parent and the cgi-bin, on the
        # reasoning that those are pre-existing and the platform's business.
        # That was right about the parent and the cgi-bin and WRONG about the
        # docroot: its mode is a functional requirement, not a preference - the
        # CGI writes every authoring surface through it. A live 0.10.5 upgrade
        # then proved the point. Hestia's v-rebuild-web-domain reset public_html
        # to 2751 (setgid, no group write), the sysop followed the release
        # notes' instruction to re-render vhosts, and this tool reported the site
        # healthy while the manager could not save a file.
        #
        # Queued for --fix, unlike the content directories below: this one is
        # "the site does not work", not "someone may have tightened it on
        # purpose".
        if ( my $want_doc = $declared{$DOC} ) {
            my $w = oct $want_doc;
            my $m = mode_of($DOC);
            # Two severities, because they are two different problems. NOT
            # GROUP-WRITABLE is "the site does not work" - it is the reported
            # incident, and the CGI cannot save anything. Group-writable but no
            # SETGID works today and breaks the group on newly created files,
            # which is the slower-burning SM215 class. Reporting both as FAIL
            # would fire on every hand-made dev docroot and teach the reader to
            # skip the line that matters.
            if    ( !-d $DOC ) { }
            elsif ( !( $m & 0020 ) ) {
                report( 'FAIL',
                    sprintf( 'the docroot is %04o and is NOT group-writable - the CGI '
                            . 'cannot save anything. A Hestia vhost rebuild resets this '
                            . '(SM270); re-run after any rebuild', $m ),
                    sprintf( "chmod %04o '%s'", $w, $DOC ) );
                push @chmod_fixes, [ $w, $DOC ];
            }
            elsif ( !( $m & 02000 ) ) {
                report( 'WARN',
                    sprintf( 'the docroot is %04o - writable, but without setgid new '
                            . 'files will not inherit the web-server group', $m ),
                    sprintf( "chmod %04o '%s'", $w, $DOC ) );
            }
            else {
                report( 'OK', sprintf( 'docroot is group-writable + setgid (%04o)', $m ) );
            }
        }

        for my $path ( sort keys %declared ) {
            # Only the site's OWN directories BELOW the docroot. The parent and
            # the cgi-bin stay out: those really are the platform's, and a
            # finding that fires on every install is one its reader learns to
            # skip past. The docroot itself is handled above.
            next unless index( $path, "$DOC/" ) == 0;
            ( my $rel = $path ) =~ s{\A\Q$DOC\E/}{};
            next if $rel =~ m{\A\.\.(?:/|\z)};
            next if exists $want_dir{$rel};    # already covered, with --fix
            next unless -d $path;
            $checked++;
            my $want = oct $declared{$path};
            my $mode = mode_of($path);
            next if $mode == $want;
            $wrong++;
            # SM933 A5 / R16: THE INSTALLER'S OWN OUTPUT, UNTOUCHED SINCE.
            #
            # The reasoning below holds --fix to group-write because the state
            # could not tell drift from a deliberate choice. For a directory the
            # installer created it now can: if the mode is STILL exactly what the
            # installer left, nobody has chosen anything here - it is the
            # installer's own result, and R3 says --fix repairs the installed
            # set. So the whole declared mode is restored, setgid included. A
            # mode that has moved since the install falls through to the rule
            # below and stays the sysop's.
            if ( defined $left{$path} && $mode == oct $left{$path} ) {
                report( ( $mode & 0020 ) ? 'WARN' : 'FAIL',
                    sprintf( '%s is %04o, as the installer left it; the model declares '
                            . '%04o - --fix sets the declared mode (nothing has changed '
                            . 'it since the install, so it is not a choice anybody made)',
                        $rel, $mode, $want ),
                    sprintf( "chmod %04o '%s'", $want, $path ) );
                push @chmod_fixes, [ $want, $path ];
                next;
            }
            # SM274: two questions, not one - "is this mode different from the
            # model" and "can the CGI still write here".
            #
            # SM246's design says "install applies, check verifies, --fix
            # repairs", and the repair third was held because these are content
            # directories on a live site: a sysop who tightened one on
            # purpose must not have it widened by a tool they ran to ask a
            # question. That reasoning is right about the WHOLE mode and wrong
            # about one bit of it.
            #
            # The install state records the DECLARED mode, not the mode the
            # installer actually left, so it cannot distinguish "drifted" from
            # "deliberate" by history - which is what ruled out comparing
            # against a baseline. But it does not need to. Group-write on a
            # declared directory is FUNCTIONAL: without it the CGI cannot write
            # there, which is the site not working. Every other bit is
            # preference, and nobody tightens a docroot subdirectory to break
            # their own site on purpose.
            #
            # So --fix ADDS the group-write bit and nothing else, leaving an
            # sysop's own choices about world and owner bits exactly as they
            # made them. A mode that differs in any other way is still reported
            # and still not touched.
            if ( !( $mode & 0020 ) ) {
                report( 'FAIL',
                    sprintf( '%s is %04o and is NOT group-writable - the CGI cannot '
                            . 'write here (the model declares %04o)', $rel, $mode, $want ),
                    sprintf( "chmod g+w '%s'", $path ) );
                push @chmod_fixes, [ 0020, $path, 'add' ];
                $wrong++;
                next;
            }
            report( 'WARN',
                sprintf( '%s is %04o, the model declares %04o - reported only; '
                        . '--fix restores group write, never other bits',
                    $rel, $mode, $want ),
                sprintf( "chmod %04o '%s'", $want, $path ) );
        }
        if ( !$checked ) {
            report( 'OK',
                'no declared directory modes recorded (payload predates the model)' );
        }
        elsif ( !$wrong ) {
            report( 'OK', "$checked declared directories carry their declared mode" );
        }
    }

    # --- 3. group must be the CGI's group on the writable dirs -------------------
    for my $rel ( sort keys %want_dir ) {
        my $path = model_path($rel);
        next unless -d $path;
        my $gid = ( stat $path )[5];
        if ( $gid != $exp_gid ) {
            report( 'FAIL',
                "$rel group is " . group_name($path) . ", expected $exp_grp "
                    . "(the group the CGI runs as) - the CGI cannot access it",
                "chown -R $exp_user:$exp_grp '$LZ'" );
            $chown_needed = 1;
        }
    }

    # --- 3a. traversal: the CGI must be able to cross into these dirs ------------
    # Every check below presupposes the CGI can TRAVERSE the path components
    # above the file (execute bit on each dir). A root-run -x cannot see a
    # missing group-execute (root bypasses DAC), so evaluate ownership+mode.
    for my $rel (qw(lazysite lazysite/manager lazysite/auth)) {
        my $path = model_path($rel);
        next unless -d $path;
        my @s = stat $path;
        if ( !cgi_can( 1, @s ) ) {
            report( 'FAIL',
                sprintf( "%s/ (%04o, %s:%s) is not traversable by the CGI (%s) - "
                        . "everything beneath it is unreachable from the web",
                    $rel, $s[2] & 07777, owner_name($path), group_name($path), $exp_grp ),
                sprintf( "chown %s:%s '%s' && chmod g+x '%s'", $exp_user, $exp_grp, $path, $path ) );
            push @chmod_fixes, [ 0010, $path, 'add' ];
            $chown_needed = 1 if $s[5] != $exp_gid;
        }
        else {
            report( 'OK', "$rel/ traversable by the CGI" );
        }
    }

    # --- 3b. TT compile cache: every dir must be writable by the CGI -------------
    # Template Toolkit 2.x treats a failed .ttc compile-cache write as a FATAL
    # render error, silently downgrading every page (manager included) to the
    # built-in fallback layout. Root-era or post-chown dirs under cache/tt are the
    # classic cause (0755 without group-write). The tree is a pure cache: the safe
    # fix is to remove it wholesale and let the CGI regrow it.
    if ( -d "$LZ/cache/tt" ) {
        find_noting( 'the template-cache check (lazysite/cache/tt)',
            { no_chdir => 1, wanted => sub {
                    return unless -d $File::Find::name;
                    my @s = stat _;
                    $tt_cache_bad++ unless cgi_can( 2, @s );
            } }, "$LZ/cache/tt" );
        if ($tt_cache_bad) {
            report( 'FAIL',
                "lazysite/cache/tt has $tt_cache_bad dir(s) the CGI ($exp_grp) cannot "
                    . "write - on Template Toolkit 2.x this silently downgrades every page "
                    . "to the built-in fallback layout",
                "rm -rf '$LZ/cache/tt'  (a pure cache - it regenerates)" );
        }
        else {
            report_ok_read( 'the template-cache check (lazysite/cache/tt)', "lazysite/cache/tt writable by the CGI" );
        }
    }

    # --- 4. secrets: not world-accessible AND readable by the CGI ----------------
    # (the common live-500: .secret is 0600 owned by a non-www-data user, so a
    #  cookie/secret verification by the www-data CGI dies before headers)
    # SM141: sessions.jsonl + revoked.json carry visitor IP/UA + revocation
    # state - 0660, CGI-readable, never world-accessible, like the secrets.
    # SM906: groups-settings.json JOINS THE LIST, and its absence cost a day.
    #
    # It carries every group's CAPABILITIES. Unreadable to the CGI, caps_for
    # resolves to nothing - and nothing is indistinguishable from "this account
    # holds no capabilities". On a new install that presented as four separate
    # faults at once: the capability grid all dots, the group labels falling back
    # to their technical names, the backend cap-/ch- groups offered as though
    # assignable, and `account-create` refusing with "Creator 'x' lacks
    # create_sub_users permission" about an account that held it.
    #
    # The sibling file with the same shape and the same consequence -
    # user-settings.json - has been on this list since SM141. This one was simply
    # never added, so the check an operator runs to find exactly this fault was
    # silent about the one store that decides what anybody may do.
    for my $rel ( qw(
        lazysite/auth/.secret lazysite/forms/.secret lazysite/manager/.csrf-secret
        lazysite/auth/oauth.json lazysite/auth/user-settings.json
        lazysite/auth/groups-settings.json
        lazysite/auth/sessions.jsonl lazysite/auth/revoked.json
        lazysite/notify-xmpp.conf lazysite/forms/smtp.conf
        ) ) {
        my $path = model_path($rel);
        next unless -f $path;
        my @s    = stat $path;
        my $mode = $s[2] & 07777;
        if ( $mode & 0007 ) {
            report( 'FAIL',
                sprintf( "%s is world-accessible (%04o) - a secret must not be", $rel, $mode ),
                sprintf( "chmod 0660 '%s'", $path ) );
            push @chmod_fixes, [ 0660, $path ];
        }
        elsif ( !cgi_can( 4, @s ) ) {
            report( 'FAIL',
                sprintf( "%s (%04o, %s:%s) is not readable by the CGI (%s) - "
                        . "cookie/secret verification dies before headers (a 500)",
                    $rel, $mode, owner_name($path), group_name($path), $exp_grp ),
                sprintf( "chown %s:%s '%s' && chmod 0660 '%s'", $exp_user, $exp_grp, $path, $path ) );
            push @chmod_fixes, [ 0660, $path ];
            $chown_needed = 1;
        }
        else {
            report( 'OK', "$rel readable by the CGI, not world-accessible" );
        }
    }

    # --- 4b. config/auth files the CGI overwrites in place must be group-writable -
    # (the manager saves nav.conf / lazysite.conf / the user store + ACLs through the
    #  www-data CGI; if they are not group-writable by www-data, the save fails)
    for my $rel ( qw(
        lazysite/nav.conf lazysite/lazysite.conf
        lazysite/auth/users lazysite/auth/groups lazysite/auth/acls.json
        lazysite/auth/groups-settings.json
        lazysite/auth/.consume.lock
        lazysite/logs/audit.log
        lazysite/logs/audit-reads.log
        ) ) {
        my $path = model_path($rel);
        next unless -f $path;
        my @s    = stat $path;
        my $mode = $s[2] & 07777;
        my $cgi_writable =
            ( defined $cgi_uid && $s[4] == $cgi_uid && ( $mode & 0200 ) ) # www-data owner, owner-write
            || ( $s[5] == $exp_gid && ( $mode & 0020 ) );    # www-data group, group-write
        unless ($cgi_writable) {
            report( 'FAIL',
                sprintf( "%s (%04o, %s:%s) is not writable by the CGI (%s) - %s",
                    $rel, $mode, owner_name($path), group_name($path), $exp_grp,
                    _unwritable_consequence($rel) ),
                sprintf( "chown %s:%s '%s' && chmod g+w '%s'", $exp_user, $exp_grp, $path, $path ) );
            push @chmod_fixes, [ 0020, $path, 'add' ];    # add group-write, keep the rest
            $chown_needed = 1;
        }
        else {
            report( 'OK', "$rel writable by the CGI" );
        }
    }

    # --- 5. the user store must not be world-writable ----------------------------
    for my $rel (qw(lazysite/auth/users lazysite/auth/groups)) {
        my $path = model_path($rel);
        next unless -f $path;
        my $mode = mode_of($path);
        if ( $mode & 0002 ) {
            report( 'FAIL', sprintf( "%s is world-writable (%04o)", $rel, $mode ),
                sprintf( "chmod 0660 '%s'", $path ) );
            push @chmod_fixes, [ 0660, $path ];
        }
    }

    # --- 5b. the group store must be readable by the CGI (ruling 206) -----------
    # One the sign-in CGI cannot open is cannot-tell, never "no groups": every
    # sign-in and every session is refused until it reads.
    {
        my $rel  = 'lazysite/auth/groups';
        my $path = model_path($rel);
        my @s    = stat $path;
        if ( @s && -f _ && !cgi_can( 4, @s ) ) {
            report( 'FAIL',
                sprintf( "%s (%04o, %s:%s) is not readable by the CGI (%s) - every sign-in "
                        . 'and every session is refused (cannot tell which groups an account '
                        . 'is in)',
                    $rel, $s[2] & 07777, owner_name($path), group_name($path), $exp_grp ),
                sprintf( "chown %s:%s '%s' && chmod 0660 '%s'", $exp_user, $exp_grp, $path, $path ) );
            push @chmod_fixes, [ 0660, $path ];
            $chown_needed = 1;
        }
    }

    # --- 5c. T-115: nothing in the account store or the form store is world-readable
    # The secrets (check 4) were the only files tested for world bits, so a user
    # store, group list or ACL file left 0644 - which install.pl did to an
    # unedited seed on a site whose engine tree sits beside the docroot (its
    # modes named the tree as `/lazysite/` only) - passed every check. Each is
    # named here, on both layouts (model_path), and --fix (and `lazysite
    # repair`) sets the declared mode: 0660 for a store the CGI rewrites, 0640
    # for a shipped example, 2770 for the two directories.
    {
        my @files = map { [ $_, 0660 ] } qw(lazysite/auth/users lazysite/auth/groups lazysite/auth/acls.json);
        for my $dir (qw(lazysite/auth lazysite/forms)) {
            my $d = model_path($dir);
            next unless -d $d && !-l $d;
            if ( opendir my $dh, $d ) {
                push @files, map { [ "$dir/$_", 0640 ] } sort grep { /\.example\z/ && -f "$d/$_" && !-l "$d/$_" } readdir $dh;
                closedir $dh;
            }
            my $mode = mode_of($d);
            if ( $mode & 0007 ) {
                report( 'FAIL',
                    sprintf( "%s/ has world access (%04o) - it holds accounts or form submissions", $dir, $mode ),
                    sprintf( "chmod 2770 '%s'", $d ) );
                push @chmod_fixes, [ 02770, $d ];
            }
        }
        my $bad = 0;
        for my $f (@files) {
            my ( $rel, $want ) = @$f;
            my $path = model_path($rel);
            next if -l $path || !-f $path;
            my $mode = mode_of($path);
            next unless $mode & 0007;
            $bad++;
            report( 'FAIL',
                sprintf( "%s is world-readable (%04o) - nothing in the account or form store may be", $rel, $mode ),
                sprintf( "chmod %04o '%s'", $want, $path ) );
            push @chmod_fixes, [ $want, $path ];
        }
        report( 'OK', 'nothing in lazysite/auth/ or lazysite/forms/ is world-readable' ) unless $bad;
    }

    # --- 6. config present + readable BY THE CGI; cgi-bin scripts executable -----
    # (-r/-x here would answer for the invoking user - run as root they pass on
    #  files the www-data CGI cannot read or exec; use the arithmetic instead)
    my @cs = stat $conf;
    if ( !@cs || !-f _ ) {
        report( 'FAIL', "lazysite.conf missing at $conf" );
    }
    elsif ( !cgi_can( 4, @cs ) ) {
        report( 'FAIL',
            sprintf( "lazysite.conf (%04o, %s:%s) is not readable by the CGI (%s) - "
                    . "the site cannot load its configuration",
                $cs[2] & 07777, owner_name($conf), group_name($conf), $exp_grp ),
            sprintf( "chown %s:%s '%s' && chmod 0664 '%s'", $exp_user, $exp_grp, $conf, $conf ) );
        push @chmod_fixes, [ 0044, $conf, 'add' ];
        $chown_needed = 1 if $cs[5] != $exp_gid;
    }
    else {
        report( 'OK', "lazysite.conf present and readable by the CGI" );
    }

    if ( -d $CGI ) {
        for my $s (qw(lazysite-processor.pl lazysite-auth.pl lazysite-manager-api.pl)) {
            my $p  = "$CGI/$s";
            my @ss = stat $p;
            if ( !@ss || !-f _ ) { report( 'FAIL', "cgi-bin/$s missing", "re-run the deploy" ) }
            elsif ( !cgi_can( 1, @ss ) ) {
                report( 'FAIL',
                    sprintf( "cgi-bin/%s (%04o, %s:%s) is not executable by the CGI (%s)",
                        $s, $ss[2] & 07777, owner_name($p), group_name($p), $exp_grp ),
                    sprintf( "chmod 0755 '%s'", $p ) );
                push @chmod_fixes, [ 0755, $p ];
            }
            else { report( 'OK', "cgi-bin/$s present and executable" ) }
        }
    }
    else {
        report( 'WARN', "cgi-bin not found at $CGI (pass --cgibin to check it)" );
    }

    # --- 6b. SM279: a stale group dav_scope is a confinement that is not one ----
    #
    # SM165 moved confinement to the domain-owned model in 0.7.26. The group
    # `dav_scope` field kept being accepted and stored for every release after,
    # and enforced nowhere - so a sysop who set one between 0.7.26 and 0.10.6
    # has an account they believe is confined and which is not.
    #
    # FAIL, not WARN, and deliberately so: every other finding in this tool is
    # about a permission being wrong. This one is about a permission the sysop
    # thinks exists. There is no repair to apply - the fix is to confine the group
    # through its domain - so it is reported and never touched by --fix.
    #
    # SM1023: the store is read ONCE, here, with its state, and section 7 reports
    # a store this run cannot read or decode; this section says nothing about it.
    my ( $GS, $GS_STATE, $GS_ERR ) = _read_json_state("$LZ/auth/groups-settings.json");
    {
        my %scoped;
        my $gs = $GS || {};
        for my $g ( sort keys %$gs ) {
            next unless ref $gs->{$g} eq 'HASH';
            my $s = $gs->{$g}{dav_scope};
            $scoped{$g} = $s if defined $s && length $s;
        }
        for my $g ( sort keys %scoped ) {
            report( 'FAIL',
                "group '$g' carries a retired dav_scope ($scoped{$g}) - it has "
                    . "confined NOBODY since 0.7.26; any member you believe is "
                    . "restricted to that folder is not",
                "confine the group by naming it in the allowed_groups of the "
                    . "domain it may manage, then clear the stale value: "
                    . "perl tools/lazysite-users.pl --docroot '$DOC' group-set "
                    . "'$g' dav_scope ''" );
        }
    }

    # --- 6c. SM335: a retired anonymise_ip is a choice the sysop no longer has
    #
    # The manager Stats page used to count visitors itself, and honoured
    # `anonymise_ip: false` by keying them on the raw address. Both readers now
    # share one tally, and that tally always anonymises - a /24 truncation then
    # a hash, before anything is stored - which is what the export has always
    # done.
    #
    # So the line is inert. WARN rather than FAIL, and the distinction matters:
    # SM279's retired dav_scope is a confinement somebody believes exists and
    # does not, which is a permission being wrong. This is the opposite
    # direction - an operator who asked for LESS anonymisation is now getting
    # more - so nothing is exposed and nobody is less safe. They are simply not
    # getting what they asked for, and should be told rather than left to infer
    # it from a control that has disappeared.
    {
        my $anon = conf_value( $conf, 'anonymise_ip' );
        if ( defined $anon && length $anon ) {
            report( 'WARN',
                "lazysite.conf carries a retired anonymise_ip ($anon) - visitor "
                    . "addresses are now always truncated to their /24 and hashed "
                    . "before anything is stored, so this line has no effect",
                "remove the anonymise_ip line from "
                    . "'$LZ/lazysite.conf'; if you were relying on "
                    . "un-anonymised addresses, that capability is gone "
                    . "deliberately and no setting restores it" );
        }
    }

    # SM929: A TRUST LIST WITH A TYPO IN IT IS A DECLARATION THE CODE IGNORES.
    #
    # `trusted_proxies` decides whether the engine may believe X-Forwarded-For
    # about who the visitor is. The parser skips any word that is not an address
    # or range, because the alternative - dying inside a CGI on a config line -
    # would take the site down. That makes this the only place a typo can be
    # SEEN, and the consequence of not seeing it is quiet: every address the site
    # records goes back to being the proxy's, which is what SM929 was raised
    # about in the first place.
    {
        my $spec = conf_value( $conf, 'trusted_proxies' );
        if ( defined $spec && length $spec ) {
            require Lazysite::Util;
            my ( $set, $bad ) = Lazysite::Util::parse_trusted_proxies($spec);
            if ( @{$bad} ) {
                report( 'WARN',
                    'lazysite.conf trusted_proxies has '
                        . scalar( @{$bad} )
                        . ' entry/entries that are not an address or range, and they are '
                        . 'ignored: ' . join( ', ', @{$bad} ),
                    'correct or remove them in ' . "'$LZ/lazysite.conf'"
                        . ' - an address (192.0.2.1), a CIDR range (10.0.0.0/8), or the '
                        . 'word none. A range of /0 is refused because it would trust '
                        . 'every caller, which is the same as having no check at all' );
            }
            _report_forwarded_trust( $set, 0 );
            if ( !@{$set} && lc($spec) ne 'none' ) {
                report( 'WARN',
                    'lazysite.conf trusted_proxies is set but resolves to NO trusted '
                        . 'address, so forwarded headers are ignored and every address '
                        . 'this site records is the connecting one',
                    'name the reverse proxy in front of this site, or set it to none '
                        . 'to say so deliberately' );
            }
            elsif ( @{$set} && !@{$bad} ) {
                report( 'OK',
                    'trusted_proxies names '
                        . scalar( @{$set} )
                        . ' trusted address/range(s) for the visitor address' );
            }
        }
        else {
            # Absent or empty is the private-range default (parse_trusted_proxies), not
            # "trust nothing": only `none` is.
            require Lazysite::Util;
            my ($dset) = Lazysite::Util::parse_trusted_proxies('');
            _report_forwarded_trust( $dset, 1 );
        }
    }

    # SM1129: `auth_proxy_trusted: true` HANDS THE IDENTITY TO WHOEVER SITS IN FRONT.
    #
    # With the flag on, X-Remote-User and its siblings name the visitor, and the
    # only thing between a client and "I am an operator" is that the request came
    # from the proxy: auth_proxy_trusted_from, a list of addresses/CIDRs matched
    # against the TCP peer. So the flag is always worth a line, and the list is
    # named in it. No list believes nobody - the site's header sign-in is DOWN, and
    # that is the same fault as a typo in the list, so both say so.
    {
        require Lazysite::Util;
        my $pid = Lazysite::Util::proxy_identity($LZ);
        if ( $pid->{flag} ) {
            my $from = length $pid->{from} ? $pid->{from} : 'not set';
            if ( $pid->{state} eq 'no-list' ) {
                report( 'WARN',
                    'lazysite.conf auth_proxy_trusted is on and auth_proxy_trusted_from lists '
                        . "no usable address ($from), so NO request is believed to carry "
                        . 'an identity header: proxy sign-in is refused for everyone',
                    "set auth_proxy_trusted_from in '$LZ/lazysite.conf' to the address(es) "
                        . 'of the proxy that sets the identity headers (192.0.2.1, 10.0.0.0/8), '
                        . 'or turn auth_proxy_trusted off if no proxy signs visitors in' );
            }
            else {
                report( 'WARN',
                    'lazysite.conf auth_proxy_trusted is on: the identity headers are '
                        . "believed from auth_proxy_trusted_from = $from and from nowhere else",
                    'keep that list to the proxy itself and keep the proxy on a private network; '
                        . 'a listed address that a visitor can reach directly can name itself '
                        . 'any account' );
            }
            if ( @{ $pid->{rejected} } ) {
                report( 'WARN',
                    'lazysite.conf auth_proxy_trusted_from has '
                        . scalar( @{ $pid->{rejected} } )
                        . ' entry/entries that are not an address or range, and they are '
                        . 'ignored: ' . join( ', ', @{ $pid->{rejected} } ),
                    "correct or remove them in '$LZ/lazysite.conf' - an address (192.0.2.1) "
                        . 'or a CIDR range (10.0.0.0/8); a /0 range is refused' );
            }
        }
    }

    # SM1024 (ruled 2026-10-12, "Close all three"): the two session stores the
    # sign-in gate reads. One that exists and does not decode (an empty file
    # included) refuses every sign-in and every session until it is repaired,
    # so it is a FAIL naming the file. Unreadable is the permission sweep's.
    for my $name (qw(user-settings.json revoked.json)) {
        my $sf = "$LZ/auth/$name";
        my ( undef, $state ) = _read_json_state($sf);
        $state = 'undecodable' if $state eq 'ok' && -z $sf;
        next unless $state eq 'undecodable';
        report( 'FAIL',
            "$name does not decode as a JSON object ($sf) - every sign-in and every session "
                . 'is refused (cannot tell) until it is repaired (SM1024)',
            "repair the JSON in '$sf', or restore it from a backup" );
    }

    # --- 7. manager bootstrap (ties to setup-sysop) ------------------------------
    #
    # SM872: THE REMEDIES HERE NAMED `setup-manager`, WHICH SM659 DELETED WITH NO
    # ALIAS - so every one of them handed the operator a command that exits 2.
    # SM865 made it bite: the installer no longer seeds a `manager` account, so a
    # fresh install now legitimately trips the first branch below and the very
    # first thing a new operator is told to run does not exist. `setup-sysop`
    # covers the first three (it seeds the group's capabilities, joins the
    # account and writes `manager: enabled`); the fourth is an account that
    # exists without a password, which is what a claim link is for.
    my $SYSOP = "perl tools/lazysite-users.pl --docroot '$DOC' setup-sysop --user <name>";
    my $mgr_enabled = ( conf_value( $conf, 'manager' ) // '' ) =~ /enabled/i;
    {
        # SM138: manager groups are those whose SETTINGS entry grants manager access
        # (ui / manage_users / the manager flag); the conf manager_groups key is
        # retired (a lingering line is inert and migrated away on first use).
        #
        # SM1023: ABSENT, UNREADABLE AND UNDECODABLE ARE THREE ANSWERS. This read
        # was `|| {}`, so a store the check's own user could not open read as "no
        # group grants manager access" and raised the unconfigured-manager alarm:
        # seen on sites.lazysite.io, run as an account outside the site group just
        # after an upgrade, while the same check as root said "bootstrapped". The
        # engine does not read an unreadable store as unsecured (SM906), and the
        # check must not invent that answer either. Only an absent store is the
        # unconfigured manager. An undecodable one is a FAIL: since SM1024 (ruled
        # 2026-10-12) every reader treats it as an unreadable store - pages render
        # as a secured site and the manager refuses every signed-in request with
        # cannot-tell until the file is repaired.
        my $gs     = $GS || {};
        my @groups = sort grep {
            my $c = $gs->{$_};
            ref $c eq 'HASH' && ( $c->{ui} || $c->{manage_users} || $c->{manager} );
        } keys %{$gs};
        my $gs_file = "$LZ/auth/groups-settings.json";
        my ( $conf_state, $conf_err ) = _open_state($conf);
        if ( $GS_STATE eq 'unreadable' ) {
            report( 'WARN',
                "cannot read groups-settings.json as " . _running_as() . " ($GS_ERR) - "
                    . 'which groups grant manager access is unknown, so the manager '
                    . 'state is not reported; if the web server cannot read it either, a password '
                    . 'sign-in is refused to every account, the operator\'s included (SM1352, ruling 206)',
                _run_as_remedy($gs_file) );
        }
        elsif ( $GS_STATE eq 'undecodable' ) {
            report( 'FAIL',
                "groups-settings.json does not decode as a JSON object ($gs_file) - "
                    . 'no group\'s capabilities can be read from it; pages render as a '
                    . 'secured site and the manager refuses every signed-in request '
                    . '(cannot tell) until it is repaired (SM1024), and a password sign-in is refused '
                    . 'to every account, the operator\'s included (SM1352, ruling 206)',
                "repair the JSON in '$gs_file', or restore it from a backup" );
        }
        elsif ( !@groups ) {
            report( 'WARN',
                "no group grants manager access - the manager is unconfigured "
                    . "(every authenticated user would be a manager)",
                $SYSOP );
        }
        elsif ( !$mgr_enabled && $conf_state eq 'unreadable' ) {
            # SM1023: the conf key is unknown, not absent.
            report( 'WARN',
                'cannot read lazysite.conf as ' . _running_as() . " ($conf_err)"
                    . " - whether 'manager: enabled' is set is unknown",
                _run_as_remedy($conf) );
        }
        elsif ( !$mgr_enabled ) {
            # Not setup-sysop: the group is already there and only the conf key
            # is missing, so name the one-line edit rather than an account step.
            report( 'WARN', "a manager group exists but 'manager: enabled' is not set",
                "add `manager: enabled` to $LZ/lazysite.conf" );
        }
        else {
            # is there a manager user with a password, in a manager group?
            my %is_mgr_group = map { $_ => 1 } @groups;
            my %members;
            # SM1023: a membership or account file this run cannot open makes
            # "no user in a manager group" unknown, not true. Absent stays an
            # answer.
            my @unread = grep { ( _open_state("$LZ/auth/$_") )[0] eq 'unreadable' } qw(groups users);
            if ( open my $gf, '<', "$LZ/auth/groups" ) {
                while ( my $l = <$gf> ) {
                    next unless $l =~ /^([^:#]+):\s*(.*)$/;
                    next unless $is_mgr_group{$1};
                    $members{$_} = 1 for split /[,\s]+/, ( $2 // '' );
                }
                close $gf;
            }
            my ( $have_mgr, $have_pw ) = ( 0, 0 );
            if ( open my $uf, '<', "$LZ/auth/users" ) {
                while ( my $l = <$uf> ) {
                    next if $l =~ /^\s*#/;
                    next unless $l =~ /^([^:]+):(.*)$/;
                    next unless $members{$1};
                    $have_mgr = 1;
                    $have_pw  = 1 if length( $2 // '' );
                }
                close $uf;
            }
            if (@unread) {
                report( 'WARN',
                    'cannot read ' . join( ' and ', map { "auth/$_" } @unread ) . ' as ' . _running_as()
                        . " - whether a manager group (@groups) has a member with a password is "
                        . 'unknown',
                    _run_as_remedy("$LZ/auth") );
            }
            elsif ( !$have_mgr ) { report( 'WARN', "no user in a manager group (@groups)",
                    $SYSOP ) }
            elsif ( !$have_pw ) { report( 'WARN', "manager user has no password (localhost-only)",
                    "perl tools/lazysite-users.pl --docroot '$DOC' "
                        . 'claim-create <username>   # mints a 24h self-service link' ) }
            else { report( 'OK', "manager bootstrapped (group + user + password)" ) }

            # SM471: A CAPABILITY ADDED AFTER THIS SITE WAS CREATED.
            #
            # The manager group is seeded with the capabilities that existed
            # that day. SM471 found that no later release backfilled it, and
            # reported the gap here rather than repair it.
            #
            # SM645 REPAIRS IT, and this check reports what that repair will do.
            # _ensure_manager_group_caps (tools/lazysite-users.pl) tops a manager
            # group up with every capability it has NO decision on - absent,
            # never an explicit 0, which SM496 made the record of a decline - so
            # granting cannot undo anybody's decision. It runs on the next use of
            # the users tool: the manager's Users, Groups and Config pages, or a
            # command such as `permissions`. Not at upgrade and not on sign-in:
            # SM685 took it off the credential path, ruled 2026-09-09, and the
            # release manager kept that on 2026-10-23 (SM1272) rather than add a
            # top-up at upgrade. So a deploy's check runs before it, and an
            # upgraded site shows the gap until the manager is next used.
            #
            # SM1272: TWO WORDINGS. A gap the top-up fills is reported as what
            # will happen - granted on the next use - because "decide" asks for
            # a decision the code has already taken (ruled 2026-08-27). Anything
            # else keeps the SM496 remedy, the Groups page banner first: that
            # is a real decision. Today every reported gap is on a manager group
            # and every capability below is one the top-up fills, so the second
            # wording is kept for the day either stops being true.
            #
            # api and mcp are excluded: SM127 keeps manager groups off the
            # remote channels deliberately, so their absence is the design.
            # THE CAPABILITY LIST IS A DELIBERATE LOCAL COPY. This file is
            # core-Perl by design and cannot load Lazysite::Auth::Settings, so
            # it carries the list the way the processor carries its ACL copy -
            # and t/lint/81 pins the pair, which is what makes the copy safe
            # rather than a second opinion.
            my @CAPS = qw(
                ui webdav
                manage_content write_content manage_nav manage_forms
                manage_themes manage_layouts manage_domains manage_config
                manage_services
                manage_users analytics audit notifications feedback
                read_submissions delete_submissions approve_accounts
                create_sub_users delegate_sub_user_creation
                manage_data write_data manage_briefs run_jobs manage_connectors
                manage_notifications
                housekeeping purge audit_switch maintenance_access
                publish_copies);
            # SM1354: the capabilities no seed or top-up gives (Settings's
            # @OFF_BY_DEFAULT, copied for the reason above). Absent on a manager
            # group is their designed state, not a gap, so they are not reported.
            my %OFF_BY_DEFAULT = map { $_ => 1 } qw(publish_copies);
            # SM1369 X2 (H-7): and the capabilities this site's extensions
            # declare, read from the extension index as the engine reads them -
            # never from a literal here, and never by running an extension.
            push @CAPS, declared_capabilities();

            my $gsettings = $gs;    # SM1023: read once, and readable to reach here

            # SM496: ABSENT and DECLINED are different answers now. An
            # explicit 0 is a recorded human decision (the Groups page banner
            # or a group-set off wrote it) and stays silent as a warning -
            # re-warning about a decision is how warnings get ignored. Only a
            # capability the store has never seen a decision on warns, and
            # the remedy is the UI first: capability upkeep is app support,
            # and app support must not need a shell on the box.
            # SM1272: the top-up's own rule (_ensure_manager_group_caps): a
            # manager group, any capability but the two remote channels.
            my $topup_fills = sub {
                my ( $have, $c ) = @_;
                return $have->{manager} && $c ne 'api' && $c ne 'mcp';
            };
            my ( @missing, @filled, @declined );
            for my $g (@groups) {
                my $have = $gsettings->{$g} or next;
                next unless $have->{manager};
                for my $c (@CAPS) {
                    next if $OFF_BY_DEFAULT{$c} && !exists $have->{$c};
                    if ( !exists $have->{$c} ) {
                        if   ( $topup_fills->( $have, $c ) ) { push @filled,  "$g/$c" }
                        else                                 { push @missing, "$g/$c" }
                    }
                    elsif ( !$have->{$c} ) { push @declined, "$g/$c" }
                }
            }
            if (@filled) {
                my ($fg) = $filled[0] =~ m{\A([^/]+)/};
                report( 'WARN',
                    'manager group(s) do not hold capabilities this release has yet: '
                        . join( ', ', @filled )
                        . ' - added after the group was seeded. A manager group is '
                        . 'granted them on the next use of the manager or the users '
                        . 'tool (opening the Users, Groups or Config page, or a '
                        . 'lazysite-users.pl command such as group-reach); nothing to '
                        . 'decide, and a capability declined on purpose stays declined',
                    # SM1273: repair runs the top-up, so it is the simplest route.
                    'or now: ' . cli_spelling() . ' repair --domain DOMAIN (it runs the '
                        . 'top-up), or from a shell as the site user: perl '
                        . "tools/lazysite-users.pl --docroot '$DOC' group-reach $fg" );
            }
            if (@missing) {
                report( 'WARN',
                    'manager group(s) have not decided on capabilities this '
                        . 'release has: '
                        . join( ', ', @missing )
                        . ' - added after the group was seeded. Decide in the '
                        . 'manager UI: Groups -> the group -> the "new '
                        . 'capabilities" banner (grant or dismiss)',
                    do {
                        my ($fg) = $missing[0] =~ m{\A([^/]+)/};
                        my ($fc) = $missing[0] =~ m{/(.+)\z};
                        'or from a shell, exactly: perl tools/lazysite-users.pl '
                            . "--docroot '$DOC' group-set $fg $fc on|off";
                    } );
            }
            if ( !@missing && !@filled ) {
                report( 'OK',
                    'manager group(s) carry a decision on every capability '
                        . 'this release has'
                        . ( @declined
                        ? ' (' . scalar(@declined) . ' declined by decision)'
                        : '' )
                );
            }
        }
    }

    # --- 7b. manager layout: present + usable by the CGI (field-hit 2026-07-09) --
    # lazysite/manager/layout.tt readable by root but not by the CGI makes the
    # manager render in the built-in fallback layout, stuck at "Loading..." -
    # and a root-run -r check cannot see it. Evaluate as the CGI identity.
    if ($mgr_enabled) {
        my $path = "$LZ/manager/layout.tt";
        if ( !-f $path ) {
            report( 'FAIL',
                "lazysite/manager/layout.tt missing - the manager renders in the "
                    . "built-in fallback layout, stuck at Loading...",
                "re-run the deploy (install.pl restores manager/layout.tt)" );
        }
        else {
            my @s = stat $path;
            if ( !cgi_can( 4, @s ) ) {
                report( 'FAIL',
                    sprintf( "lazysite/manager/layout.tt (%04o, %s:%s) is not readable by "
                            . "the CGI (%s) - the manager renders in the built-in fallback "
                            . "layout, stuck at Loading...",
                        $s[2] & 07777, owner_name($path), group_name($path), $exp_grp ),
                    sprintf( "chown %s:%s '%s' && chmod 0664 '%s'", $exp_user, $exp_grp, $path, $path ) );
                push @chmod_fixes, [ 0664, $path ];
                $chown_needed = 1 if $s[5] != $exp_gid;
            }
            else {
                report( 'OK', "lazysite/manager/layout.tt present and readable by the CGI" );
            }
        }
    }

    # --- 7c. content history (SM085) ----------------------------------------------
    # When git_history is enabled: the git binary must exist (WARN - saves keep
    # working, history silently stops), the repo dir must not be world-accessible,
    # and info/exclude MUST carry the lazysite/auth exclusion - a history that can
    # be pushed to a remote must never contain the credential store (SECURITY).
    if ( ( conf_value( $conf, 'git_history' ) // '' ) =~ /enabled/i ) {
        my $have_git = 0;
        for my $bd ( split /:/, ( $ENV{PATH} // '' ) ) {
            next unless length $bd;
            if ( -f "$bd/git" && -x _ ) { $have_git = 1; last }
        }
        if ( !$have_git ) {
            report( 'WARN',
                "git_history is enabled but git is not installed - saves keep working "
                    . "but no content history is recorded",
                "apt-get install git (or the distro equivalent)" );
        }
        my $gd = "$LZ/git";
        if ( !-d $gd ) {
            report( 'WARN',
                "git_history is enabled but lazysite/git is not initialised",
                "tick the Content history extension on the Extensions page "
                    . "(or the git-init control-API action)" );
        }
        else {
            my $mode = mode_of($gd);
            if ( $mode & 0007 ) {
                report( 'FAIL',
                    sprintf( "lazysite/git is world-accessible (%04o) - the content "
                            . "history must not be", $mode ),
                    sprintf( "chmod 02770 '%s'", $gd ) );
                push @chmod_fixes, [ 02770, $gd ];
            }
            my $excl = '';
            if ( open my $xf, '<', "$gd/info/exclude" ) {
                local $/;
                $excl = <$xf> // '';
                close $xf;
            }
            if ( $excl !~ m{^/?lazysite/auth/?\s*$}m ) {
                report( 'FAIL',
                    "lazysite/git/info/exclude does not exclude lazysite/auth - the "
                        . "credential store could be committed and PUSHED to a remote",
                    "add a '/lazysite/auth/' line to '$gd/info/exclude' (and "
                        . "'git rm -r --cached lazysite/auth' if it was ever committed)" );
            }
            else {
                report( 'OK', "content history: lazysite/auth is excluded from the repo" );
            }
            # git-sync.conf holds the remote access token; when it exists it
            # must be excluded too (the sync extension self-heals this before
            # every sync, but a missing line is still a pushable-secret risk).
            if ( -f "$LZ/git-sync.conf"
                && $excl !~ m{^/?lazysite/git-sync\.conf\s*$}m ) {
                report( 'FAIL',
                    "lazysite/git/info/exclude does not exclude lazysite/git-sync.conf - "
                        . "the remote access token could be committed and PUSHED to a remote",
                    "add a '/lazysite/git-sync.conf' line to '$gd/info/exclude' (and "
                        . "'git rm --cached lazysite/git-sync.conf' if it was ever committed)" );
            }

            # 7c-i. repo internals (field defect 2026-07-11, dito.tech): a
            # pre-0.7.7 doctor chown left 0755 object dirs the CGI cannot
            # write, so every commit failed while the saves succeeded - new
            # file versions were silently not recorded. Ownership+mode
            # arithmetic (cgi_can) as everywhere: root's -w would pass what
            # the CGI cannot use.
            my ( $git_bad, @git_sample ) = (0);
            find_noting( 'the lazysite/git access check',
                { no_chdir => 1, wanted => sub {
                        my $p = $File::Find::name;
                        my @s = lstat $p or return;
                        return if -l _;
                        my $bits = git_want_bits( $gd, $p, ( -d _ ? 1 : 0 ), @s );
                        return unless $bits;
                        $git_bad++;
                        push @git_sample, $p if @git_sample < 5;
                        $chown_needed = 1 if $s[5] != $exp_gid;
                } }, $gd );
            if ($git_bad) {
                my $sample = join( ', ', map { s{^\Q$DOC/\E}{}r } @git_sample );
                $sample .= ', …' if $git_bad > @git_sample;
                report( 'FAIL',
                    "$git_bad path(s) under lazysite/git the CGI ($exp_grp) cannot use - "
                        . "commits fail while saves succeed, so new file versions are "
                        . "SILENTLY NOT RECORDED ($sample)",
                    "re-run with --fix (restores group access; a foreign group also needs "
                        . "the chown above)" );
                $git_fix_root = $gd;
            }
            else {
                report_ok_read( 'the lazysite/git access check', "content history: the repo is usable by the CGI" );
            }

            # 7c-ii. core.sharedRepository=group makes git itself keep every
            # path it creates group-accessible regardless of the process umask
            # - set at init since 0.7.8; repos initialised earlier predate it
            # and regress on the next umask-0022 write unless set.
            if ($have_git) {
                my $val = '';
                if ( open my $ph, '-|', 'git', "--git-dir=$gd", 'config', '--get',
                    'core.sharedRepository' ) {
                    local $/; $val = <$ph> // ''; close $ph;
                }
                $val =~ s/\s+//g;
                if ( $val =~ /\A(?:1|2|group|true|all|world|everybody|0[0-7]{2,3})\z/i ) {
                    report( 'OK',
                        "content history: core.sharedRepository keeps the repo group-accessible" );
                }
                else {
                    report( 'WARN',
                        "content history: core.sharedRepository is not set - git creates new "
                            . "object dirs with the process umask, which can silently break "
                            . "version recording after an ownership change",
                        "git --git-dir='$gd' config core.sharedRepository group  (--fix does this)" );
                    $git_shared_fix = $gd;
                }
            }

            # 7c-iii. recording-health breadcrumb: the engine touches
            # COMMIT_FAILED when a version could not be recorded (the save
            # itself succeeds by design) and removes it on the next successful
            # commit. WARN, not FAIL: --fix repairs the cause above; only a
            # subsequent save can prove recording works again.
            if ( -e "$gd/COMMIT_FAILED" ) {
                report( 'WARN',
                    "content history: the last version-recording attempt FAILED "
                        . "(lazysite/git/COMMIT_FAILED present) - changes since then are "
                        . "missing from the history",
                    "fix the findings above (--fix), then save any page - a successful "
                        . "save clears this flag" );
            }
        }
    }

    # --- 8. WebDAV route health (SM121, opt-in) ----------------------------------
    # A wired /dav/ challenges with 401 even unauthenticated; a missing route 404s.
    # 404-vs-401 is the fastest way to tell "web server / proxy doesn't forward /dav/"
    # (provisioning) from an auth/scope problem.
    if ( defined $opt{check_dav} ) {
        my $u = $opt{check_dav};
        $u =~ s{/+$}{};
        if ( $u !~ m{^https?://\S+$} ) {
            report( 'WARN', "--check-dav needs an http(s):// URL; skipping the WebDAV probe" );
        }
        else {
            my $code = '';
           # list-form open: no shell, so the URL can't inject. -k tolerates a fresh cert.
            if ( open my $ph, '-|', 'curl', '-sS', '-k', '-o', '/dev/null',
                '-w', '%{http_code}', '--max-time', '8', "$u/dav/" ) {
                local $/; $code = <$ph> // ''; close $ph;
            }
            $code =~ s/\D//g;
            if ( $code eq '401' ) { report( 'OK', "WebDAV /dav/ is routed (401 challenge at $u/dav/)" ) }
            elsif ( $code eq '404' ) {
                report( 'FAIL',
                    "WebDAV /dav/ returns 404 at $u/dav/ - the web server / proxy is not forwarding "
                        . "/dav/ to lazysite-dav.pl (route missing, not an auth problem)",
                    "wire /dav/ -> cgi-bin/lazysite-dav.pl in the vhost (and the nginx proxy if used), then reload" );
            }
            elsif ( $code eq '' ) { report( 'WARN', "WebDAV /dav/ probe got no response (curl missing or host unreachable)" ) }
            else { report( 'WARN', "WebDAV /dav/ returned $code at $u/dav/ (expected 401)" ) }
        }
    }

    # --- 8b. does the front end actually respect the ACL? (SM285) ---------------
    run_acl_probe( $opt{check_acl} ) if defined $opt{check_acl};

    # --- 8b2. does the engine see static requests at all? (SM377 follow-up) -----
    report_engine_sees_statics( $opt{check_acl} ) if defined $opt{check_acl};

    # --- 8c. who an @group ACL entry now admits (SM288) -------------------------
    report_unscoped_data_tables();
    report_rows_without_a_policy();
    report_unsafe_nav_urls();
    report_csp_allow_lists();
    report_permissions_ceiling();       # SM1294
    report_group_acl_reach();
    report_address_rules();             # SM1141
    report_address_slots_against_old_kinds();
    report_old_address_template_calls();
    report_widened_rules();             # SM1313
    report_rules_without_an_owner();    # SM1401

    # --- 8d. is any protected content ALSO sitting in the docroot? (SM286) ------
    report_stray_public();

    # --- 8d2. a symbolic link planted in the served asset mirror (SM1304) -------
    report_asset_links();

    # --- 8g. can this site's private store actually be written? (SM296) --------
    report_private_store_usable();

    # --- 8g1. is every enabled extension listed under the one name? (SM1142) ----
    report_extensions_list();
    report_refused_site_extensions();    # SM1361, ruling 210

# --- 8g1b. the extension index: built, and what the enabled extensions declare (SM1369 X2) ---
    report_hook_index();

    # --- 8g2. is the login rate limiter actually counting? (SM798) --------------
    report_login_rate_limit();

    # --- 8g2b. can every store the engine refuses on be told? (SM1417, ruling 206) ---
    report_store_faults();

    # --- 8g3. what each enabled extension checks of itself (SM1369 X6, H-6) ----
    # (the Odoo extension's: its scheduled keys' expiry SM1161, the OOM it loads
    # SM1244, oomd SM1164 D4, the Odoo sign-in SM1160, old read caps SM1173)
    report_extension_checks();

    # --- 8e. where is this site's engine tree, and is there only one? (SM293) ---
    report_engine_tree();

    # --- 8f. registries left behind from before they were served (SM293) --------
    report_stale_registries();
    report_unfinished_backups();    # SM1446

    # --- 8h. templates written for 0.12's raw db values (SM844) ------------------
    report_double_escaped_db_templates();
    report_uncompilable_form_patterns();
    report_unconverted_delivery();
    report_schedule_floor();            # SM1391
    report_time_zone();                 # SM1356
    report_cryptx();                    # SM1352, SM1363 (ruling 187)
    report_page_titles();               # SM1357
    report_structured_data();           # SM1357
    report_foreign_site_folders();      # SM1357, ruling 171
    report_content_roots();             # ruling 206
    report_auth_numbers();              # ruling 206
    report_retired_conf_keys();
    report_retired_notify_keys();       # SM1412
    report_app_settings();              # SM1155
    report_maintenance();               # SM1118
    report_shared_manager_account();    # N141D (SM864)
    report_preview_marker_account();    # SM1390

    # --- 8h. is front-door mode on for this site? (SM294 / SM309) --------------
    report_front_door_mode();
    report_pool_status(); # SM1144: R5 reads the fleet's pool status from the deploy report
    report_pool_engine();    # ruling 203: the pool runs the site's own engine

    # --- 8i2. is this site's persistent runtime armed? (SM893) ----------------
    report_daemon_runtime();

    # --- 8i. is the ACTIVE theme's stylesheet actually being served? (SM315) ----
    report_theme_assets_mirrored();

    # --- 9. content provenance (is this content lazysite's or the operator's?) ---
    # lazysite stamps its shipped seed pages with `provenance: lazysite-starter` in the
    # front matter. This reports which .md content is ours (unmodified vs customised)
    # versus sysop-authored - the "is this likely ours?" test behind the upgrade-
    # safety work. Informational (always OK); never a FAIL.
    {
        require Digest::SHA;
        my %state;
        my $st = _read_json("$LZ/.install-state.json");
        %state = %{ $st->{files} }
            if ref $st eq 'HASH' && ref $st->{files} eq 'HASH';
        my $sha_file = sub {
            my ($p) = @_;
            open my $fh, '<:raw', $p or return '';
            my $d = Digest::SHA->new(256);
            $d->addfile($fh);
            close $fh;
            return 'sha256:' . $d->hexdigest;
        };

        my ( @sysop, @customised );
        my $unmodified = 0;
        find_noting( 'the content-provenance count',
            { no_chdir => 1,
                wanted => sub {
                    my $p = $File::Find::name;
                    return unless $p =~ /\.md\z/ && -f $p;
                    # Skip lazysite internals + code-managed trees (always ours).
                    for my $skip (qw(lazysite manager docs .well-known)) {
                        return if index( $p, "$DOC/$skip/" ) == 0;
                    }
                    open my $fh, '<', $p or return;
                    my $first = <$fh> // '';
                    my $head  = '';
                    if ( $first =~ /\A---\s*\R?\z/ ) {    # front matter opens
                        while ( my $l = <$fh> ) { last if $l =~ /\A---\s*\R?\z/; $head .= $l }
                    }
                    close $fh;
                    ( my $rel = $p ) =~ s/\A\Q$DOC\E\/?//;
                    if ( $head !~ /^provenance\s*:\s*lazysite-starter\s*$/m ) {
                        push @sysop, $rel;
                        return;
                    }
                    # Ours: unmodified vs customised, via the recorded install-state sha.
                    my $rec = $state{$p};
                    if ( defined $rec && $rec eq $sha_file->($p) ) { $unmodified++ }
                    else { push @customised, $rel }
                },
            },
            $DOC,
        );

        report_ok_read( 'the content-provenance count', sprintf(
                'content provenance: %d lazysite page(s) [%d unmodified, %d customised], %d operator-authored',
                $unmodified + scalar @customised, $unmodified, scalar @customised, scalar @sysop ) );
        my $cap = sub { my @l = @_; @l > 10 ? ( @l[ 0 .. 9 ], '...' ) : @l };
        report_ok_read( 'the content-provenance count', '  customised (edited from a lazysite page): ' . join( ', ', $cap->(@customised) ) )
            if @customised;
        report_ok_read( 'the content-provenance count', '  operator-authored (not ours, never touched by upgrades): ' . join( ', ', $cap->(@sysop) ) )
            if @sysop;
    }

    # --- 10. system pages resolve (SM201) ----------------------------------------
    # login/claim/402/403/404 are served with a fallback: a content-root or
    # docroot-root copy overrides, else the protected engine default under
    # lazysite/templates/system/. Verify each route resolves - so /login and /claim
    # never 404 even after an agent deletes a root copy - and that the protected
    # defaults (which make the fallback self-healing) are present.
    {
        my ( @dead, @root_only );
        # SM1048: forgot and logout, the rest of the sign-in flow.
        for my $name (qw(login claim forgot logout maintenance 402 403 404)) {
            my $has_default = -f "$LZ/templates/system/$name.md";
            my $has_root    = -f "$DOC/$name.md";
            push @dead,      $name if !$has_default && !$has_root;
            push @root_only, $name if !$has_default && $has_root;
        }
        if (@dead) {
            report( 'FAIL',
                'system page(s) with neither an engine default nor a root copy - these '
                    . 'routes will 404: ' . join( ', ', @dead ),
                'reinstall/upgrade to restore lazysite/templates/system/ (SM201)' );
        }
        if (@root_only) {
            report( 'WARN',
                'system page(s) served only from a root copy - the protected default is '
                    . 'missing (an agent-proof fallback): ' . join( ', ', @root_only ),
                'run an upgrade to install lazysite/templates/system/ (SM201)' );
        }
        report( 'OK', 'system pages (login/claim/forgot/logout/40x) all resolve via the fallback chain (SM201)' )
            if !@dead && !@root_only;
    }

    # --- 10b. a site page in front of the engine's /docs manual (SM1284) -------
    report_shadowed_engine_docs();

    # --- 11. OAuth/remote discovery coherence (SM190 / SM200 lever 4) -------------
    # The .well-known discovery docs advertise every endpoint from site_url. If a
    # remote service is enabled but site_url is unset or not https, the docs hand a
    # connecting agent a broken/wrong endpoint (the token exchange then fails with a
    # confusing sign-in-incomplete - the outsourcify onboarding incident). Catch it
    # here at deploy time, before onboarding, without an HTTP round-trip.
    {
        my @remote =
            grep { ( conf_value( $conf, $_ ) // '' ) =~ /^(?:enabled|true|yes|on|1)$/i }
            qw(oauth_enabled token_exchange_enabled control_api_enabled webdav_enabled mcp_enabled);
        if (@remote) {
            my $site_url = conf_value( $conf, 'site_url' ) // '';

            # The recommended house value is the dynamic
            # ${REQUEST_SCHEME}://${SERVER_NAME}, which the processor expands
            # per-request; behind TLS (every deployed vhost terminates it) the
            # scheme resolves to https, so the advertised endpoints are https.
            # Treat that form as acceptable instead of warning "not https" on
            # every site - that literal-prefix test was 0.9.13 field noise.
            my $dynamic_scheme = $site_url =~ m{^\$\{REQUEST_SCHEME\}://};

            if ( !length $site_url ) {
                report( 'FAIL',
                    'a remote service is enabled (' . join( ', ', @remote )
                        . ') but site_url is UNSET - the .well-known discovery docs will '
                        . 'advertise endpoints with no host, so an agent connect fails',
                    'set site_url: https://<this-host> in lazysite.conf' );
            }
            elsif ( $site_url !~ m{^https://} && !$dynamic_scheme ) {
                report( 'WARN',
                    "site_url is '$site_url' (not https://) while a remote service is "
                        . 'enabled - OAuth connectors require https advertised endpoints',
                    'set site_url to the https:// URL of this host' );
            }
            elsif ( $site_url =~ m{/$} ) {
                report( 'WARN',
                    "site_url '$site_url' has a trailing slash - advertised endpoints get a "
                        . 'double slash; trim it',
                    'remove the trailing / from site_url' );
            }
            else {
                report( 'OK', "OAuth/remote discovery: site_url ($site_url) is coherent for the "
                        . 'enabled service(s)' );
            }
        }
    }
    return;
}

# --- apply fixes; returns how many were applied -------------------------------
# A queued fix [ $mode, $path ] sets $mode exactly; [ $bits, $path, 'add' ] ORs
# $bits into the file's mode AT APPLY TIME, so two fixes on the same path
# compose (e.g. group-write from check 4b + group/other-read from check 6)
# instead of the later chmod clobbering the earlier one.

# The mode a CGI-owned path must carry BEFORE the root chown pass hands it to
# the site user: the owner bits are replicated onto the group, so the access
# the CGI had AS OWNER survives the handover AS GROUP (0600 secret -> 0660,
# 0755 tt-cache dir -> 0775). Field defect 2026-07-11: the chown pass turned
# the CGI's own 0600 .secret files into site-user-owned 0600 - breaking them
# in the very run that printed "fixed:" - because run 1 had verified them via
# OWNERSHIP, which the chown then took away. Pure function; unit-tested.
sub handover_mode {
    my ($mode) = @_;
    $mode &= 07777;
    return $mode | ( ( $mode & 0700 ) >> 3 );
}

# SM1195: A FIX IS "FIXED" WHEN THE PATH NOW CARRIES THE MODE, NOT WHEN chmod
# RETURNED TRUE.
#
# Field report (edge, 2026-10-19, run as ispadmin): --fix printed "fixed: chmod
# 2770 .../lazysite/git (was 0770)" three times in one run and then reported the
# same path as a FAIL with no setgid. Linux clears S_ISGID on chmod when the
# caller is not root and not a member of the file's group (ispadmin is not in
# www-data); chmod still returns success. The tool believed the return value,
# so the report said "fixed" for a change that had not happened, and the loop
# applied it again every pass. Every chmod/chown the fix path makes now goes
# through here and is checked by stat; a change that did not take is reported
# as such, with the reason when it can tell and the command for someone who can.
my %attempted;    # "path\0mode" -> 1: a change is tried once per run
my $not_taken = 0;

# The caller's groups. LAZYSITE_CHECK_GROUPS (a space-separated gid list) stands
# in for them in the regression test, which has no second user to be "outside"
# a group with.
sub in_group {
    my ($gid) = @_;
    my @g = split ' ', ( $ENV{LAZYSITE_CHECK_GROUPS} // $) );
    return scalar grep { $_ == $gid } @g;
}

# ( $mode, $path ) -> ( 1 ) when the path now carries $mode, else
# ( 0, $why, $now ) with the reason in words.
sub set_mode {
    my ( $mode, $path ) = @_;
    my $ok  = chmod $mode, $path;
    my $err = "$!";
    my @s   = stat $path;
    my $now = @s ? ( $s[2] & 07777 ) : undef;
    return (1) if $ok && defined $now && $now == $mode;
    return ( 0, "refused: $err",     $now )  unless $ok;
    return ( 0, 'the path vanished', undef ) unless defined $now;
    if ( ( $mode & 02000 ) && !( $now & 02000 ) ) {
        my $who = ( getpwuid $> )[0]    // $>;
        my $grp = ( getgrgid $s[5] )[0] // $s[5];
        return ( 0, "the setgid bit was dropped because $who is not in group $grp "
                . "(the system clears it for a non-root caller outside the file's group)", $now )
            if $> != 0 && !in_group( $s[5] );
        return ( 0, 'the setgid bit was dropped by the system', $now );
    }
    return ( 0, 'the system left a different mode', $now );
}

# Report a chmod that did not take, once, with the root command.
sub report_not_taken {
    my ( $mode, $path, $cur, $now, $why ) = @_;
    printf "not fixed: chmod %04o %s (was %04o, now %s) - %s\n"
        . "  as root: sudo chmod %04o '%s'\n",
        $mode, $path, $cur, ( defined $now ? sprintf( '%04o', $now ) : 'gone' ),
        $why,  $mode, $path;
    $not_taken++;
}

# ( $uid, $gid, $path ) -> true only when the owner/group are now as asked.
sub set_owner {
    my ( $uid, $gid, $path ) = @_;
    my $ok = chown $uid, $gid, $path;
    my @s  = lstat $path or return 0;
    return $ok && $s[4] == $uid && $s[5] == $gid ? 1 : 0;
}

# n818 (SM1440, O-5): would --fix change anything? The hint "re-run with --fix" is
# shown only when the run queued a repair that --fix applies; a run whose only
# findings are things a human decides has nothing for --fix to do.
sub fix_available {
    return 1 if @stale_registries || $tt_cache_bad || $git_fix_root || $git_shared_fix
        || $store_create_needed || $store_repair_needed || $chown_needed;
    for my $f (@chmod_fixes) {
        my ( $mode, $path, $how ) = @{$f};
        my @s   = stat $path or next;
        my $cur = $s[2] & 07777;
        $mode |= $cur if ( $how // '' ) eq 'add';
        return 1      if $mode != $cur;
    }
    return 0;
}

sub apply_fixes {
    my $fixed = 0;

    # SM627: move a stale generated registry out of the document root. Named
    # with the time it was moved, so two repairs on different days do not
    # overwrite each other's copy - the second would otherwise destroy the only
    # remaining copy of an operator's own file, which is the exact outcome
    # moving instead of deleting exists to prevent.
    if (@stale_registries) {
        require File::Path;
        require File::Copy;
        my $bak = "$LZ/backups/stale-registries";
        File::Path::make_path($bak) unless -d $bak;
        my $when = do {
            my @t = gmtime;
            sprintf '%04d%02d%02dT%02d%02d%02dZ',
                $t[5] + 1900, $t[4] + 1, $t[3], $t[2], $t[1], $t[0];
        };
        for my $src (@stale_registries) {
            my $name = $src =~ m{([^/]+)\z} ? $1 : $src;
            my $dst  = "$bak/$name.$when";

            # The stamp has one-second resolution, so two repairs inside the
            # same second land on the same name and move() would OVERWRITE -
            # destroying the copy this whole mechanism exists to keep. Caught by
            # t/unit/tools/73, which repaired twice in a row. Never overwrite:
            # find a free name, and give up rather than clobber.
            if ( -e $dst ) {
                my $n = 1;
                $n++ while $n < 1000 && -e "$dst.$n";
                if ( -e "$dst.$n" ) {
                    warn "not moving $name: $dst and 1000 variants all exist\n";
                    next;
                }
                $dst = "$dst.$n";
            }

            if ( File::Copy::move( $src, $dst ) ) {
                my $short = $dst =~ m{([^/]+)\z} ? $1 : $dst;
                print "fixed: moved $name out of the document root -> "
                    . "lazysite/backups/stale-registries/$short "
                    . "(the engine now serves a current one)\n";
                $fixed++;
            }
            else {
                warn "could not move $src aside: $!\n";
            }
        }
    }

    if ($tt_cache_bad) {
        require File::Path;
        my $err;
        File::Path::remove_tree( "$LZ/cache/tt", { error => \$err } );
        if ( $err && @{$err} ) { warn "could not remove $LZ/cache/tt\n" }
        else {
            print "fixed: rm -rf $LZ/cache/tt (compile cache regenerates)\n";
            $fixed++;
        }
    }
    if ($git_fix_root) {
        # One walk, one summary line - a repo can hold hundreds of object
        # dirs; per-path "fixed:" lines would drown the report.
        my $gd = $git_fix_root;
        my $n  = 0;
        my @git_failed;
        find_noting( '--fix',
            { no_chdir => 1, wanted => sub {
                    my $p = $File::Find::name;
                    my @s = lstat $p or return;
                    return if -l _;
                    my $bits = git_want_bits( $gd, $p, ( -d _ ? 1 : 0 ), @s );
                    return unless $bits;
                    my $want = ( $s[2] & 07777 ) | $bits;
                    return if $attempted{"$p\0$want"}++;
                    my ($took) = set_mode( $want, $p );
                    if   ($took) { $n++ }
                    else         { push @git_failed, $p }
            } }, $gd );
        if ($n) {
            print "fixed: restored group access on $n path(s) under lazysite/git "
                . "(version recording works again on the next save)\n";
            $fixed++;
        }
        if (@git_failed) {
            my $first = $git_failed[0];
            printf "not fixed: %d path(s) under lazysite/git did not take the group access "
                . "(first: %s) - a non-root caller outside the group cannot keep the setgid "
                . "bit\n  as root: sudo chmod -R g+rwXs '%s'\n",
                scalar @git_failed, $first, $gd;
            $not_taken += @git_failed;
        }
    }
    if ($git_shared_fix) {
        my $set = system( 'git', "--git-dir=$git_shared_fix", 'config',
            'core.sharedRepository', 'group' ) == 0;
        my $val = '';
        if ( $set && open my $ph, '-|', 'git', "--git-dir=$git_shared_fix", 'config',
            '--get', 'core.sharedRepository' ) {
            local $/; $val = <$ph> // ''; close $ph;
        }
        $val =~ s/\s+//g;
        if ( $set && $val eq 'group' ) {
            print "fixed: git config core.sharedRepository group "
                . "(git keeps future repo paths group-accessible, umask-independent)\n";
            $fixed++;
        }
        else {
            print "not fixed: git config core.sharedRepository group on $git_shared_fix "
                . "did not take\n  as the repo's owner: git --git-dir='$git_shared_fix' "
                . "config core.sharedRepository group\n";
            $not_taken++;
        }
    }
    for my $f (@chmod_fixes) {
        my ( $mode, $path, $how ) = @{$f};
        my @s   = stat $path or next;      # vanished (e.g. under the tt purge)
        my $cur = $s[2] & 07777;
        $mode |= $cur if ( $how // '' ) eq 'add';
        next          if $mode == $cur;    # already in the target state - no re-print
            # SM933 PR6: name the mode that was there. A repair that prints only the
            # new value destroys the evidence of the fault it just corrected - the
            # operator who runs --fix is often the one who has to explain afterwards
            # what was wrong, and "chmod 2775" alone does not say whether anything
            # was. The prior mode is already in hand from the stat above.
        next if $attempted{"$path\0$mode"}++;    # SM1195: once per run, not once per pass
        my ( $took, $why, $now ) = set_mode( $mode, $path );
        if ($took) {
            printf "fixed: chmod %04o %s (was %04o)\n", $mode, $path, $cur;
            $fixed++;
        }
        else { report_not_taken( $mode, $path, $cur, $now, $why ) }
    }
    # SM313: create the private store, so protecting content can actually move it.
    if ($store_create_needed) {
        my $s = $store_create_needed;
        if ( -d $s ) {
            # A previous iteration made it; nothing to do. --fix loops until
            # stable, so this branch is reached on the second pass.
        }
        elsif ( $> == 0 ) {
            require File::Path;
            my $err;
            File::Path::make_path( $s, { error => \$err } );
            if ( -d $s ) {
                # Owned by the site user, setgid so content moved in keeps the
                # group. The engine then writes into a directory it owns, and
                # never needs write permission on the parent.
                my $own = set_owner( $exp_uid, $exp_gid, $s );
                my ($took) = set_mode( 02770, $s );
                if ( $own && $took ) {
                    printf "fixed: created the private store %s (%s:%s, mode 2770)\n",
                        $s, $exp_user, $exp_grp;
                    $fixed++;
                }
                else {
                    printf "not fixed: the private store %s was created but is not "
                        . "%s:%s mode 2770\n  as root: sudo chown %s:%s '%s' && sudo chmod 2770 '%s'\n",
                        $s, $exp_user, $exp_grp, $exp_user, $exp_grp, $s, $s;
                    $not_taken++;
                }
            }
            else { warn "could not create the private store $s\n" }
        }
        else {
            # Not root, and by construction the parent is not writable by us -
            # so print the exact commands rather than failing silently.
            print "skip: creating the private store needs root - run:\n"
                . "  mkdir -p '$s'\n"
                . "  chown $exp_user:$exp_grp '$s'\n"
                . "  chmod 2770 '$s'\n";
        }
    }
    # SM323: repair a store that exists but the CGI cannot write into.
    if ($store_repair_needed) {
        my $s = $store_repair_needed;
        if ( $> == 0 ) {
            # Same shape --fix creates: owned by the site user, group the CGI
            # identity, setgid so content moved in keeps the group.
            my $bad = 0;
            set_owner( $exp_uid, $exp_gid, $s ) or $bad++;
            ( set_mode( 02770, $s ) )[0]        or $bad++;
            # The contents too - a store populated by a sweep running as the site
            # user holds files the CGI cannot rewrite either, and un-protecting
            # has to move them back OUT.
            my $n = 0;
            find_noting( '--fix',
                { no_chdir => 1, wanted => sub {
                        my $p  = $File::Find::name;
                        my @st = lstat $p or return;
                        return if -l _;
                        set_owner( $exp_uid, $exp_gid, $p )            or $bad++;
                        ( set_mode( ( -d _ ? 02770 : 0660 ), $p ) )[0] or $bad++;
                        $n++;
                } }, $s );
            if ($bad) {
                printf "not fixed: private store %s: %d change(s) did not take\n"
                    . "  as root: sudo chown -R %s:%s '%s' && sudo chmod 2770 '%s'\n",
                    $s, $bad, $exp_user, $exp_grp, $s, $s;
                $not_taken += $bad;
            }
            else {
                printf "fixed: private store %s now %s:%s mode 2770 (%d path(s))\n",
                    $s, $exp_user, $exp_grp, $n;
                $fixed++;
            }
        }
        else {
            print "skip: repairing the private store needs root - run:\n"
                . "  chown -R $exp_user:$exp_grp '$s'\n"
                . "  chmod 2770 '$s'\n";
        }
    }
    if ($chown_needed) {
        if ( $> == 0 ) {
            my $chown_bad = 0;
            # Recursive chown to the expected owner:group. Handing a path the
            # CGI currently OWNS to the site user must not strip the CGI's
            # access - replicate the owner bits onto the group first (see
            # handover_mode above).
            find_noting( '--fix', { no_chdir => 1, wanted => sub {
                        my $p = $File::Find::name;
                        my @s = lstat $p or return;
                        return if -l _;
                        if ( defined $cgi_uid && $s[4] == $cgi_uid ) {
                            my $want = handover_mode( $s[2] );
                            ( set_mode( $want, $p ) )[0] or $chown_bad++
                                if $want != ( $s[2] & 07777 );
                        }
                        set_owner( $exp_uid, $exp_gid, $p ) or $chown_bad++;
            } }, $LZ );
            if ($chown_bad) {
                print "not fixed: chown -R $exp_user:$exp_grp $LZ - $chown_bad change(s) "
                    . "did not take\n  as root: sudo chown -R $exp_user:$exp_grp '$LZ'\n";
                $not_taken += $chown_bad;
            }
            else {
                print "fixed: chown -R $exp_user:$exp_grp $LZ\n";
                $fixed++;
            }
        }
        else {
            print "skip: ownership fix needs root - run:\n"
                . "  chown -R $exp_user:$exp_grp '$LZ'\n";
        }
    }
    return $fixed;
}

run_checks();

# When --fix is on, apply-and-recollect UNTIL STABLE (bounded): one pass can
# CREATE new fixable findings - the field case 2026-07-11 was the root chown
# pass handing CGI-owned files to the site user, after which the 0600 secrets
# needed a 0660 chmod that only the NEXT collection could queue; the old
# single apply pass reported that new damage but never repaired it ("--fix
# said fixed, the site still 500s"). Each iteration re-collects, so the
# report below always describes the tree as it now IS (SM139 increment 5).
my $fixes_applied = 0;
if ( $opt{fix} ) {
    for my $pass ( 1 .. 3 ) {
        my $n = apply_fixes();
        $fixes_applied += $n;
        run_checks();
        last unless $n;
    }
}

report_unread_walks();    # Q16g: after any --fix pass, with the results it describes
report_diagnostic_sinks() if $opt{sinks};    # SM932 (2), after any --fix re-run

# --- report ------------------------------------------------------------------
my %icon = ( OK => '  ok  ', WARN => ' warn ', FAIL => ' FAIL ' );
my ( $fails, $warns ) = ( 0, 0 );
print "\nlazysite-check  docroot=$DOC  expect-owner=$exp_user:$exp_grp\n";
print "(--fix applied $fixes_applied change(s)"
    . ( $not_taken ? ", $not_taken not taken - see the \"not fixed\" lines above" : '' )
    . "; this report reflects the post-fix state)\n"
    if $fixes_applied || $not_taken;

# n814 (SM1437): --fix that changed nothing says so, in one line.
print "--fix: nothing to change\n" if $opt{fix} && !$fixes_applied && !$not_taken;
print "\n";
for my $r (@results) {
    $fails++ if $r->{level} eq 'FAIL';
    $warns++ if $r->{level} eq 'WARN';
    printf "[%s] %s\n", $icon{ $r->{level} }, $r->{msg};
    printf "         -> %s\n", $r->{hint} if $r->{hint} && $r->{level} ne 'OK';
}
my $fix_available = fix_available();
printf "\n%d ok, %d warning(s), %d failure(s)%s\n",
    scalar( grep { $_->{level} eq 'OK' } @results ), $warns, $fails,
    ( !$opt{fix} && $fix_available ? "  (re-run with --fix to apply the chmod/chown fixes)" : "" );
exit( $fails ? 1 : 0 );

# --- helpers -----------------------------------------------------------------

# SM1194 (test plan 0.15.10, F-6): a trust set is only half of it. The engine
# believes the chain from the RIGHT, which is safe only when the front end
# APPENDS the real peer; a front end that passes the client's own header through
# (lazysite's nginx templates before SM929, first shipped in v0.15.2) makes
# "X-Forwarded-For: 192.0.2.55" the visitor's address, and every address-keyed
# control takes their word. The DEFAULT (key absent or empty) trusts the private
# ranges, which hold an ordinary front end's address, so it is exposed too; only
# `none` is not. This runs as the site user and cannot read the nginx config, so
# it cannot tell; it says what to probe instead.
sub _report_forwarded_trust {
    my ( $set, $default ) = @_;
    return unless @{$set};
    report( 'WARN',
        "trusted_proxies is only safe when the front end appends the client's address "
            . "to X-Forwarded-For (lazysite's templates since 0.15.2/SM929); probe it: "
            . 'a request with X-Forwarded-For: 192.0.2.55 must not be seen as 192.0.2.55'
            . ( $default ? ' (the private-range default)' : '' ),
        'if it is seen as 192.0.2.55, rebuild the site\'s vhost from the current '
            . 'template (the Hestia updater\'s --rebuild, or '
            . 'v-rebuild-web-domain USER DOMAIN followed by `' . cli_spelling()
            . ' repair --domain DOMAIN`, which puts back the permissions a rebuild '
            . 'resets - SM270); set trusted_proxies: none until it is rebuilt '
            . '(do not remove the line - removing it restores the default trust)' );
    return;
}

# SM1236: the CLI as this host runs it, for a hint. LAZYSITE_CLI is set by the
# CLI and the Hestia updater; otherwise `lazysite` when it is on PATH, otherwise
# the CLI beside this tool by path (the tarball puts no `lazysite` on PATH).
sub cli_spelling {
    return $ENV{LAZYSITE_CLI} if length( $ENV{LAZYSITE_CLI} // '' );
    for my $d ( split /:/, $ENV{PATH} // '' ) {
        return 'lazysite' if length $d && -x join( '/', $d, 'lazysite' );
    }
    require Cwd;
    require File::Basename;
    my $cli = File::Basename::dirname( Cwd::abs_path($0) // $0 ) . '/lazysite-cli.pl';
    return -f $cli ? "perl $cli" : 'lazysite';
}

sub conf_value {
    my ( $file, $key ) = @_;
    open my $fh, '<', $file or return undef;
    my $val;
    while ( my $l = <$fh> ) { if ( $l =~ /^\Q$key\E\s*:\s*(.+)/ ) { $val = $1; last } }
    close $fh;
    return undef unless defined $val;
    $val =~ s/^\s+|\s+$//g;
    return $val;
}

# SM1141 (slice D of SM1134): ADDRESS RULES THAT MEAN NOTHING, OR EVERYTHING.
#
# A rule that names an address profile decides from the visitor's address, and that
# address is the front end's unless trusted_proxies says the front end is one to
# believe (SM929): behind an untrusted proxy every visitor is the proxy, so a
# profile allowed admits all of them or none and a profile denied blocks all or
# none. Three things are worth saying, each of them quiet at run time:
#   - rules in use and no front end trusted: `none`, or a list that resolves to
#     nothing. Every address is the connecting peer.
#   - rules in use on an install that has a front end in front of the engine
#     (a pool conf for this docroot, or Hestia's /home/USER/web/DOMAIN layout)
#     and trusted_proxies unset. The default trusts only 10/8, 172.16/12 and
#     192.168/16; a front end connecting from loopback or a public address is not
#     covered. A line naming the front end settles it. The check cannot see the
#     connecting address, so it names the evidence it went on.
#   - a rule that names a profile the store does not hold (allowing it then admits
#     nobody, SM1138), and a store this run cannot read or decode, or an
#     address-lists.json the upgrade left unconverted (SM1345), while rules name
#     profiles (the engine denies everything they name).
# Where the rules are is Lazysite::Auth::AddressRefs, the reader the delete guard
# in the users tool uses, so the two cannot disagree about what "in use" means.
sub report_address_rules {
    my $d = $opt{docroot};
    require Lazysite::Auth::AddressRefs;
    my $refs  = Lazysite::Auth::AddressRefs::rules($d);
    my @rules = @{ $refs->{rules} };
    if ( @{ $refs->{faults} } ) {
        report( 'WARN',
            'address rules could not be looked for everywhere: ' . join( '; ', @{ $refs->{faults} } )
                . ' - a rule that names an address profile may be in what was not read',
            _run_as_remedy() );
    }
    return unless @rules;    # nothing uses an address rule: nothing to say

    my $LZ    = Lazysite::Paths::lazysite_dir($d);
    my $where = Lazysite::Auth::AddressRefs::describe(@rules);
    my $conf  = "$LZ/lazysite.conf";
    my $spec  = conf_value( $conf, 'trusted_proxies' );
    require Lazysite::Util;
    my ($set) = Lazysite::Util::parse_trusted_proxies($spec);
    my $unset = !defined $spec || !length $spec;

    if ( !@{$set} ) {
        report( 'WARN',
            'address rules are in use (' . $where . ') and trusted_proxies trusts no front end '
                . ( $unset ? '' : "($spec) " )
                . '- every visitor appears to come from the address that connects, which behind a proxy '
                . 'is the proxy, so these rules admit or refuse everyone alike',
            "set trusted_proxies in '$conf' to the front end's address or range (192.0.2.1, 10.0.0.0/8); "
                . 'none is right only where visitors connect to this server directly' );
    }
    elsif ($unset) {
        my $ev = _front_end_evidence($d);
        if ( defined $ev ) {
            report( 'WARN',
                'address rules are in use (' . $where . ') behind a front end (' . $ev . ') and trusted_proxies is not set, '
                    . 'so only the private ranges 10.0.0.0/8, 172.16.0.0/12 and 192.168.0.0/16 are believed: '
                    . 'a front end that connects from loopback or a public address is not covered, and '
                    . 'every visitor then appears to be that front end',
                "name the front end in trusted_proxies in '$conf' (127.0.0.1 for a proxy on this host)" );
        }
    }
    else {
        report( 'OK', 'address rules are in use (' . $where . ') and trusted_proxies names the front end(s)' );
    }

    my @names = do { my %s; grep { !$s{$_}++ } map { $_->{name} } @rules };
    my $store = Lazysite::Paths::lazysite_dir($d) . '/auth/address-profiles.json';
    my ( $profiles, $state, $err ) = _read_json_state($store);
    my $old = Lazysite::Paths::lazysite_dir($d) . '/auth/address-lists.json';
    if ( $state eq 'absent' && -e $old ) {
        report( 'WARN',
            "address-lists.json from a release before 0.16.5 ($old) was not converted to address profiles while rules name "
                . join( ', ', @names ) . ' - every address is refused by every rule that names one '
                . 'until they are',
            'run the upgrade again: it converts the lists to profiles of the same names (SM1345)' );
    }
    elsif ( $state eq 'unreadable' ) {
        report( 'WARN',
            'cannot read address-profiles.json as ' . _running_as() . " ($err) while rules name "
                . join( ', ', @names ) . ' - whether those profiles exist is unknown',
            _run_as_remedy() );
    }
    elsif ( $state eq 'undecodable' ) {
        report( 'WARN',
            "address-profiles.json does not decode as a JSON object ($store) while rules name "
                . join( ', ', @names ) . ' - every address is refused by every rule that names a profile, '
                . 'allowed or denied, until it is repaired',
            "repair the JSON in '$store', or restore it from a backup" );
    }
    else {
        my %have    = map  { $_ => 1 } keys %{ $profiles || {} };
        my @missing = grep { !$have{ $_->{name} } } @rules;
        if (@missing) {
            my %u;
            my @n = grep { !$u{$_}++ } sort map { $_->{name} } @missing;
            report( 'WARN',
                'address rules name ' . ( @n == 1 ? 'a profile' : 'profiles' ) . ' the store does not hold: '
                    . join( ', ', @n ) . ' (' . Lazysite::Auth::AddressRefs::describe(@missing)
                    . ') - a rule allowing a missing profile admits nobody, one denying it blocks nobody',
                'create the profile (Access -> Address profiles, or lazysite-users address-profile-set), or '
                    . 'correct the name in the rule' );
        }
        elsif ( @{ $refs->{faults} } ) {
            # n818 (SM1440): an ok only about what was read.
            report( 'WARN',
                'could not check that every address profile a rule names is in the store: '
                    . join( '; ', @{ $refs->{faults} } ),
                _run_as_remedy() );
        }
        else {
            report( 'OK', 'every address profile a rule names is in the store' );
        }

    }
    return;
}

# old-address-name: begin (SM1343, the check reads the old store and the old method names)
# SM1345 (ruling 106): A RULE WHOSE SLOT IS NOT ITS OLD LIST'S KIND. Until 0.16.5 a
# list was an allow list or a deny list, and a rule naming one in the other slot -
# possible only by a hand edit, since every save refused it (SM1189) - refused every
# visitor. The upgrade keeps the old store as address-lists.json.converted and
# rewrites no rule, so such a rule now applies in the slot it is in. This names
# each one, by rule and slot and the kind the list had, for the operator to keep
# or move. Nothing when the converted file is absent (a site that never had lists).
sub report_address_slots_against_old_kinds {
    my $d   = $opt{docroot};
    my $old = Lazysite::Paths::lazysite_dir($d) . '/auth/address-lists.json.converted';
    my ( $lists, $state, $err ) = _read_json_state($old);
    return if $state eq 'absent';
    if ( $state ne 'ok' ) {
        report( 'WARN', "cannot read $old ($state" . ( $err ? ": $err" : '' ) . ') - the rules cannot be '
                . 'compared with the kinds the address lists had before 0.16.5',
            _run_as_remedy() );
        return;
    }
    require Lazysite::Auth::AddressRefs;
    my $refs = Lazysite::Auth::AddressRefs::rules($d);
    my ( %u, @say );
    for my $r ( @{ $refs->{rules} } ) {
        next unless $r->{slot} eq 'allow' || $r->{slot} eq 'deny';
        my $rec  = $lists->{ $r->{name} };
        my $kind = ref $rec eq 'HASH' ? ( $rec->{kind} // '' ) : '';
        next if !length $kind || $kind eq $r->{slot};
        my $one = "$r->{name} (" . ( $kind eq "allow" ? "an allow" : "a deny" ) . " list before 0.16.5) is " . ( $r->{slot} eq 'allow' ? 'allowed' : 'denied' )
            . ' by ' . Lazysite::Auth::AddressRefs::describe($r);
        push @say, $one unless $u{$one}++;
    }
    if ( !@say && @{ $refs->{faults} } ) {
        # n818 (SM1440): the rules were not all read, so nothing is said to be fine.
        report( 'WARN',
            'could not check whether every rule names its address profile in the slot its old list\'s kind meant: '
                . join( '; ', @{ $refs->{faults} } ),
            _run_as_remedy() );
        return;
    }
    unless (@say) {
        report( 'OK', 'every rule names its address profile in the slot its old list\'s kind meant' );
        return;
    }
    report( 'WARN',
        'address rules use a profile the other way from its old list\'s kind: ' . join( '; ', @say )
            . ' - before 0.16.5 such a rule refused every visitor; it now allows or denies as its slot says',
        'keep each if that is what the rule means, or move the name to the other key (addresses / '
            . 'addresses_deny, or the _deny key); address-lists.json.converted is the record of the old kinds' );
    return;
}

# SM1345 (ruling 105): A TEMPLATE CALL TO THE OLD TEST NAMES. The upgrade rewrote
# visitor.in_list / visitor.in_any to visitor.in_profile / visitor.in_any_profile in
# the site's pages, layouts, themes and templates; the engine knows only the new
# names, so one written back by hand (or copied from an old snippet) is false
# whatever the address. Each is named by file and line.
sub report_old_address_template_calls {
    my $d = $opt{docroot};
    ( my $docroot = $d ) =~ s{/+\z}{};
    my $lz = Lazysite::Paths::lazysite_dir($docroot);
    require Lazysite::Private;
    my $priv = Lazysite::Private::private_root($docroot);
    my %skip = map { ( "$lz/$_" => 1 ) } qw(backups cache logs auth forms sessions tmp);
    my ( %seen, @hits );
    for my $root ( grep { defined && -d $_ } $docroot, $lz, $priv ) {
        find_noting(
            'the old address test calls',
            { no_chdir => 1,
                wanted => sub {
                    my $p = $File::Find::name;
                    if ( -d $p ) {
                        $File::Find::prune = 1 if $skip{$p} || $p =~ m{/\.git\z};
                        return;
                    }
                    return if -l $p || !-f _ || $seen{$p}++;
                    return unless $p =~ /\.(?:md|tt|html?|tmpl)\z/;
                    open my $fh, '<', $p or return;
                    while ( my $l = <$fh> ) {
                        next unless $l   =~ /\bvisitor\.(?:in_list\b|in_any\b(?!_))/;
                        ( my $rel = $p ) =~ s{\A\Q$docroot\E/}{};
                        push @hits, "$rel line $.";
                    }
                    close $fh;
                },
            },
            $root
        );
    }
    return unless @hits;
    splice @hits, 10, @hits - 10, '(and ' . ( @hits - 10 ) . ' more)' if @hits > 10;
    report( 'WARN',
        'templates call the address tests by their names from before 0.16.5: ' . join( ', ', @hits )
            . ' - visitor.in_list and visitor.in_any are unknown now, so each call is false',
        'write visitor.in_profile and visitor.in_any_profile instead (the upgrade rewrites them; SM1345)' );
    return;
}
# old-address-name: end

# Evidence that a front end sits between visitors and this engine, or undef. Two
# kinds the check can see without a request: a pool conf for this docroot (the
# engine runs behind a pool a front end proxies to), and Hestia's own layout.
sub _front_end_evidence {
    my ($d)  = @_;
    my $want = abs_path($d)                // $d;
    my $pools = $ENV{LAZYSITE_CHECK_POOLS} // '/etc/lazysite/pools'; # the tests stand in a dir
    if ( opendir my $dh, $pools ) {
        my @confs = sort grep { /\.conf\z/ } readdir $dh;
        closedir $dh;
        for my $c (@confs) {
            open my $fh, '<', "$pools/$c" or next;
            while ( my $l = <$fh> ) {
                next unless $l =~ /^\s*DOCROOT\s*=\s*"?([^"\s]+)"?/;
                return "pool $c" if ( abs_path($1) // $1 ) eq $want;
            }
            close $fh;
        }
    }
    return 'Hestia layout' if $want =~ m{\A/home/[^/]+/web/[^/]+/public_html(?:/|\z)};
    return undef;
}

# SM288 WIDENS ACCESS ON UPGRADE, so the operator gets to see it coming.
#
# An @group ACL entry used to match a cookie user and a WebDAV partner, and
# silently never matched the same account over MCP or the control API. From
# SM288 it matches everywhere - which is the intended behaviour and is still a
# change of effective permissions on a live site. Nobody should discover that
# from a changelog line.
#
# Informational, never a WARN: an @group entry is a normal thing to have and
# nagging about it would teach the reader to skip this section. It reports the
# entries and who resolves into them, so "who gains" is answerable before the
# upgrade rather than after.
# SM593: on an instance serving several unrelated domains, a table that names
# no `domain:` is reachable by ANY manage_data holder - including a partner
# scoped to a neighbouring domain, who is not supposed to know it exists.
#
# A WARNING RATHER THAN A FAILURE, and only where several domains are
# configured. On a single-site instance the instance-wide namespace is the only
# namespace there is and the key would be noise; the exposure needs a second
# party before it is an exposure. This is also the migration list: an instance
# upgrading into the release keeps every table working, and this names the ones
# still to scope.
# SM932 (2): DID THE DIAGNOSTICS REACH A SECOND SINK?
#
# syslog forwarding is on by default at WARN and above, so a failure has two
# places to land - and each can fail quietly, syslog the quieter, because a
# transport failure is reported once per process. This sends one marked line
# through the engine's own forward_line (the path every log_event takes) and
# looks for it: in the dump file when LAZYSITE_SYSLOG_DUMP redirects the engine,
# otherwise in the journal, then /var/log/syslog or /var/log/messages.
# LAZYSITE_CHECK_SINK_READ=journal forces the journal read (the tests use it
# with a stand-in journalctl, so nothing reaches the host's log).
sub report_diagnostic_sinks {
    local $ENV{DOCUMENT_ROOT} = $DOC;
    require Lazysite::Util;
    my $set = Lazysite::Util::forward_diagnostics_setting();
    if ( !$set->{forwarding} ) {
        report( 'WARN', 'diagnostic sinks: syslog forwarding is off - the engine\'s '
                . 'diagnostics reach only the web server\'s error log',
            'forward_diagnostics: off in lazysite.conf; remove it for the default (WARN and above)' );
        return;
    }
    my $nonce = join '', map { sprintf '%02x', int rand 256 } 1 .. 8;
    my $line = "lazysite check: diagnostic sink probe $nonce (sent by lazysite check --sinks)";
    # err, so any configured threshold forwards it.
    my $sent = Lazysite::Util::forward_line( 'diag', 'err', $line );
    if ( !$sent ) {
        report( 'FAIL', 'diagnostic sinks: the probe line could not be sent to syslog',
            'the engine logged why once on STDERR ("log forwarding failed"); check '
                . 'that /dev/log exists and that Sys::Syslog is installed' );
        return;
    }
    my ( $found, $where, $why ) = _sink_read_back($nonce);
    if ($found) { report( 'OK', "diagnostic sinks: syslog received the probe ($where)" ) }
    elsif ( defined $where ) {
        report( 'FAIL', "diagnostic sinks: sent to syslog, but $where did not receive it within 3s",
            "facility $set->{facility}; a log daemon filtering that facility, or one not "
                . 'running, drops it - the engine cannot see that from its side' );
    }
    else {
        report( 'WARN', 'diagnostic sinks: sent to syslog; cannot confirm it arrived - ' . $why,
            'run as an account that can read the system log (journalctl), or look for '
                . "'sink probe $nonce' in it yourself" );
    }
    return;
}

# Returns (found, where, why-unreadable): the first READABLE source is polled for
# up to three seconds; where is undef when no source could be read at all.
sub _sink_read_back {
    my ($nonce) = @_;
    require Time::HiRes;
    my $dump        = $ENV{LAZYSITE_SYSLOG_DUMP};
    my $force       = ( $ENV{LAZYSITE_CHECK_SINK_READ} // '' ) eq 'journal';
    my $file_reader = sub {
        my ($path) = @_;
        return sub {
            open my $fh, '<', $path or return ( 0, "$path: $!" );
            local $/;
            my $t = <$fh> // '';
            close $fh;
            return ( 1, $t );
        };
    };
    my @sources;
    if ( !$force && defined $dump && length $dump ) {
        push @sources, [ 'the syslog dump file', $file_reader->($dump) ];
    }
    else {
        push @sources, [ 'the system journal', sub {
                my $out = `journalctl -q --no-pager -t lazysite --since=-10min -o cat 2>&1`;
                return ( 0, 'journalctl is not available' ) if $? == -1;
                ( my $first = $out ) =~ s/\n.*//s;
                return ( 0, "journalctl: $first" )
                    if $? || $out =~ /No\ journal\ files|insufficient\ permissions|not\ seeing\ messages/xi;
                return ( 1, $out );
        } ];
        unless ($force) {
            push @sources, [ $_, $file_reader->($_) ] for grep { -e } qw(/var/log/syslog /var/log/messages);
        }
    }

    my ( $where, $read, @why );
    for my $src (@sources) {
        my ( $ok, $text ) = $src->[1]->();
        if ($ok) { ( $where, $read ) = @$src; return ( 1, $where ) if index( $text, $nonce ) >= 0; last }
        push @why, $text;
    }
    return ( 0, undef, join( '; ', @why ) || 'no system log could be read' ) unless $read;
    for ( 1 .. 6 ) {
        Time::HiRes::sleep(0.5);
        my ( $ok, $text ) = $read->();
        return ( 1, $where ) if $ok && index( $text, $nonce ) >= 0;
    }
    return ( 0, $where );
}

sub report_unscoped_data_tables {
    my $d   = $opt{docroot};
    my $dir = Lazysite::Paths::lazysite_dir($d) . "/db/tables";
    return unless -d $dir;

    # Several domains configured? `alias_hosts` is the list SM151 keys the
    # multi-domain instance on, read here the same way every other conf value
    # in this tool is read.
    my $aliases = conf_value( $conf, 'alias_hosts' ) // '';
    my @hosts   = grep { length } map { s/^\s+|\s+$//gr } split /,/, $aliases;
    return unless @hosts;    # one domain: nothing to be confined from

    # IS ANYBODY ACTUALLY CONFINED? Several domains is not several PARTIES.
    # SM165 confines an account by naming its group in a domain's
    # allowed_groups, and resolve_user_scopes derives every scope from exactly
    # that - so with no domain declaring allowed_groups, no caller holds a
    # scope, none is confined, and an unscoped table is reachable by the
    # sysop alone. Warning there is a finding about nothing, repeated on
    # every deploy of an instance whose domains are all one person's - and a
    # finding that is always present and never actionable is how a real one
    # gets scrolled past.
    my $confined = 0;
    if ( open my $ch, '<', $conf ) {
        while ( my $l = <$ch> ) {
            next unless $l =~ /^alias\..+\.allowed_groups\s*:\s*\S/;
            $confined = 1;
            last;
        }
        close $ch;
    }

    opendir( my $dh, $dir ) or return;
    my @files = sort grep { /\.ya?ml\z/ } readdir $dh;
    closedir $dh;
    return unless @files;

    my ( @unscoped, @scoped );
    for my $f (@files) {
        ( my $name = $f ) =~ s/\.ya?ml\z//;
        my $txt = '';
        if ( open my $fh, '<', "$dir/$f" ) { local $/; $txt = <$fh>; close $fh }
        # Read as TEXT, not through the YAML parser: this tool runs on installs
        # where the data extension's modules may not be present, and a check that
        # cannot run where the problem lives is not a check.
        if   ( $txt =~ /^domain:\s*\S/m ) { push @scoped,   $name }
        else                              { push @unscoped, $name }
    }
    return unless @unscoped;

    unless ($confined) {
        report( 'OK',
            sprintf(
                '%d data table%s %s no domain, and no domain confines a group'
                    . ' - so nothing but the operator reaches them',
                scalar @unscoped,
                ( @unscoped == 1 ? ''      : 's' ),
                ( @unscoped == 1 ? 'names' : 'name' ) ) );
        return;
    }

    report( 'WARN',
        sprintf( '%d data table%s %s no domain on a %d-domain instance: %s',
            scalar @unscoped,
            ( @unscoped == 1 ? ''      : 's' ),
            ( @unscoped == 1 ? 'names' : 'name' ),
            scalar @hosts + 1, join( ', ', @unscoped ) ),
        'Any manage_data holder on this instance reads them, including a '
            . 'partner scoped to another domain - and a table name is itself a '
            . "disclosure. Add `domain: <host>` to each descriptor in "
            . "lazysite/db/tables/. See /docs/data-tables."
    );
    report( 'OK',
        sprintf( '%d data table%s scoped to a domain',
            scalar @scoped, ( @scoped == 1 ? ' is' : 's are' ) )
    ) if @scoped;
    return;
}

# P16 (WORK-PLAN-0154, ruled 2026-10-12 "Add allow-lists"): an entry in a
# csp_script_src, csp_connect_src, csp_img_src or csp_frame_src list - the
# site's or a domain's (alias.<host>.csp_*_src) - that is not an https origin is
# left out of every page's policy and logged on each render. This names each,
# with the line it is on, so it can be corrected once. Read as text, like the
# rest of this tool; the rule is Lazysite::SecurityHeaders::csp_origin_ok.
sub report_csp_allow_lists {
    require Lazysite::SecurityHeaders;
    open my $ch, '<', $conf or return;
    my ( @bad, $lists );
    my $n = 0;
    while ( my $l = <$ch> ) {
        $n++;
        next unless $l =~ / ^ ( (?: alias\. \S+? \. )? csp_ (?: script|connect|img|frame ) _src ) \s* : \s* (.*?) \s* $ /x;
        my ( $key, $raw ) = ( $1, $2 );
        $lists++;
        my ( undef, $refused ) = Lazysite::SecurityHeaders::csp_allow_lists($raw);
        push @bad, map { "lazysite.conf:$n $key '$_'" } @$refused;
    }
    close $ch;
    return unless $lists;
    if (@bad) {
        report( 'WARN',
            sprintf( '%d CSP allow-list entr%s not an https origin, left out of the policy: %s',
                scalar @bad, ( @bad == 1 ? 'y is' : 'ies are' ), join( ', ', @bad ) ),
            'An entry is https://host or https://host:port, a leading *. for subdomains - no '
                . "bare *, no path, no 'unsafe-*' or other keyword. See /docs/configuration." );
        return;
    }
    report( 'OK', 'every CSP allow-list entry is an https origin' );
    return;
}

# SM1294 (ruling 29): the site's ceiling on the browser features a page may ask
# for. An entry that is no such feature - a typo, or payment or browsing-topics,
# which can never be listed (rulings 15 and 16) - lets no page ask for anything
# by it; the engine leaves it out, which narrows and never widens. This names
# each, with its line, so the list says what the operator meant. Silent when the
# site sets no ceiling. alias.<host>.permissions_policy_allow is not read: the
# ceiling is per site, and a domain cannot override it.
sub report_permissions_ceiling {
    require Lazysite::SecurityHeaders;
    no warnings 'once';    ## no critic (ProhibitNoWarnings)
    open my $ch, '<', $conf or return;
    my ( @bad, $raw, $at );
    my $n = 0;
    while ( my $l = <$ch> ) {
        $n++;
        next unless $l =~ /^permissions_policy_allow[ \t]*:[ \t]*(.*?)\s*$/;
        ( $raw, $at ) = ( $1, $n );
    }
    close $ch;
    my ( $ceil, $refused ) = Lazysite::SecurityHeaders::permissions_ceiling($raw);
    return unless $ceil;
    if (@$refused) {
        report( 'WARN',
            sprintf( 'lazysite.conf:%d permissions_policy_allow lists %s that no page can ask for: %s',
                $at, ( @$refused == 1 ? 'an entry' : scalar(@$refused) . ' entries' ), join( ', ', @$refused ) ),
            'payment and browsing-topics stay denied on every site and cannot be listed; the others are '
                . join( ', ', @Lazysite::SecurityHeaders::PAGE_FEATURES ) . ', or none. See /docs/configuration.' );
        return;
    }
    report( 'OK', 'pages may ask only for the browser features permissions_policy_allow lists: '
            . ( @$ceil ? join( ', ', @$ceil ) : 'none' ) );
    return;
}

# P23 (WORK-PLAN-0154, ruled 2026-10-12): A NAV ADDRESS THAT CAN RUN SCRIPT.
# A save refuses one now and the render shows it as `#`; a nav file written
# before that, or by hand, still holds it, so this names each entry. Every
# navigation file the instance renders: lazysite/nav.conf, a `nav_file:` and
# each `alias.<host>.nav_file:` in lazysite.conf (read as text, like the rest
# of this tool). The rule is Lazysite::Util::unsafe_link_scheme, the marked
# copy of the render's `| url_safe`.
sub report_unsafe_nav_urls {
    my $d = $opt{docroot};
    require Lazysite::Util;
    my %navs = ( 'lazysite/nav.conf' => 1 );
    if ( open my $ch, '<', $conf ) {
        while ( my $l = <$ch> ) {
            next unless $l =~ /^(?:alias\.\S+\.)?nav_file\s*:\s*(.+?)\s*$/;
            ( my $v = $1 ) =~ s{^/+}{};
            $navs{$v} = 1 if length $v;
        }
        close $ch;
    }
    my ( @bad, $read );
    for my $rel ( sort keys %navs ) {
        my $path = Lazysite::Paths::site_path( $d, $rel );
        next unless -f $path;
        open my $fh, '<:encoding(UTF-8)', $path or next;
        my $text = do { local $/; <$fh> };
        close $fh;
        $read++;
        push @bad, map { "$rel:$_->{line} '$_->{label}' ($_->{scheme}:)" }
            @{ Lazysite::Util::nav_unsafe_entries($text) };
    }
    return unless $read;
    if (@bad) {
        report( 'WARN',
            sprintf( '%d nav entr%s link to an unsafe scheme, rendered as #: %s',
                scalar @bad, ( @bad == 1 ? 'y' : 'ies' ), join( ', ', @bad ) ),
            'A nav address is a path (/about), an http or https address, mailto: or '
                . 'tel:. Correct the entry with set_nav (or the Navigation editor), which '
                . 'refuses an unsafe one. See /docs/configuration.' );
        return;
    }
    report( 'OK', 'every nav entry links to a path or a web address' );
    return;
}

# SM857 (the filing's fifth open question, answered where a sysop reads it):
# CONFINEMENT PROTECTS NOTHING THAT ALREADY EXISTS.
#
# A row written before `row_policy: true` carries no policy, and no policy means
# SHARED - which is right for compatibility and is the opposite of what the flag
# was turned on for. The filing's own words: "correct, and invisible: someone
# will assume otherwise". So the number is reported, per table.
#
# THE DESCRIPTOR IS READ AS TEXT, like every other descriptor check in this tool,
# because it runs on installs where the data extension's modules are absent. The
# COUNT needs the store, so DBI is a soft dependency: present, the number is
# reported; absent or unreadable, THAT is reported, because "0 rows carry no
# policy" and "I could not look" are different answers and only one of them is
# reassuring.
sub report_rows_without_a_policy {
    my $d   = $opt{docroot};
    my $dir = Lazysite::Paths::lazysite_dir($d) . "/db/tables";
    return unless -d $dir;
    opendir( my $dh, $dir ) or return;
    my @files = sort grep { /\.ya?ml\z/ } readdir $dh;
    closedir $dh;

    my @declared;
    for my $f (@files) {
        my $txt = '';
        if ( open my $fh, '<', "$dir/$f" ) { local $/; $txt = <$fh>; close $fh }
        next unless $txt  =~ /^row_policy:\s*(?:true|yes|on|1)\s*$/mi;
        ( my $name = $f ) =~ s/\.ya?ml\z//;
        push @declared, $name;
    }
    return unless @declared;

    my $store = Lazysite::Paths::lazysite_dir($d) . '/db/data.sqlite';
    if ( !-f $store ) {
        report( 'OK',
            sprintf( '%d table%s declare%s row_policy and the store holds nothing yet',
                scalar @declared, ( @declared == 1 ? '' : 's' ), ( @declared == 1 ? 's' : '' ) ) );
        return;
    }

    my $dbh = eval {
        require DBI;
        DBI->connect( "dbi:SQLite:dbname=$store", '', '',
            { RaiseError => 1, PrintError => 0, ReadOnly => 1 } );
    };
    if ( !$dbh ) {
        report( 'WARN',
            sprintf( '%d table%s declare row_policy and the rows could not be counted',
                scalar @declared, ( @declared == 1 ? '' : 's' ) ),
            'The store could not be opened to count them (' . ( $@ || 'no DBI' ) . '). '
                . 'Rows written before the flag carry NO policy, and no policy means shared - '
                . 'so the number matters. See /docs/data-tables.' );
        return;
    }

    my ( @open_rows, @clean );
    for my $t (@declared) {
        # The table name comes from a FILENAME the engine already constrains to
        # [a-z][a-z0-9_]*; re-asserted here because this interpolates it.
        next unless $t =~ /\A[a-z][a-z0-9_]*\z/;
        my $n = eval {
            my $r = $dbh->selectrow_arrayref(
                "SELECT COUNT(*) FROM \"$t\" WHERE row_policy IS NULL OR row_policy = ''");
            $r ? $r->[0] : undef;
        };
        if ( !defined $n ) { push @open_rows, "$t (could not be counted)"; next }
        if ($n)            { push @open_rows, "$t: $n";                    next }
        push @clean, $t;
    }

    report( 'OK', sprintf( '%d row-policy table%s: every row carries a policy',
            scalar @clean, ( @clean == 1 ? '' : 's' ) ) )
        if @clean;
    report( 'WARN',
        'rows carrying no policy: ' . join( ', ', @open_rows ),
        'A row with no policy is SHARED, so confinement does not protect it - every '
            . 'writer the table admits may amend it. These rows predate the flag. Set '
            . 'their row_policy with an operator write, or leave them shared knowingly.' )
        if @open_rows;
    return;
}

# SM1313 (ruling 61): A STORED RULE WIDER THAN THE RULE ENCLOSING IT IS NAMED.
#
# Before 0.16.3 anyone who could write a path inside a protected area could
# write a rule there admitting people the area's rule does not (SM1309), and the
# longest match then let them in. 0.16.3 refuses such a write unless the
# operator or the enclosing rule's owner makes it, and keeps every rule already
# stored. This finds the stored ones of the kind it now refuses: a rule wider
# than its enclosing rule whose owner is neither that rule's owner nor an
# operator, so a carve-out the operator or the area's owner made is not named.
# The judgement is Acl::widening_refusal's, asked one mode at a time with the
# rule's owner as the writer - never a second copy of it.
#
# A WARN, and nothing is changed: whether a carve-out is right is the
# operator's to decide, so `lazysite repair` leaves it as a decision for a human.
sub report_widened_rules {
    my $d = $opt{docroot};
    my ( $map, $state ) = _read_json_state( _acls_file($d) );
    return unless $state eq 'ok' && ref $map eq 'HASH' && keys %$map;
    return if _probe_load_engine($d);    # the engine is not loadable here: nothing to ask
    my $n = 0;
    for my $key ( sort keys %$map ) {
        my $rec = $map->{$key};
        next unless ref $rec eq 'HASH';
        my $owner = $rec->{owner};
        next if defined $owner && length $owner
            && eval { Lazysite::Auth::Acl::account_is_operator($owner) };
        for my $mode (qw(read write)) {
            next unless ref $rec->{$mode} eq 'ARRAY' && @{ $rec->{$mode} };
            my %one = ( $mode => $rec->{$mode}, ( defined $owner ? ( owner => $owner ) : () ) );
            my $r = Lazysite::Auth::Acl::widening_refusal( $map, $key, \%one, undef, $owner );
            next unless $r;
            my $enc = ( $r->{enclosing} =~ m{\A(?:/|\.|)\z} ) ? 'the site-wide rule' : "the rule on '$r->{enclosing}'";
            report( 'WARN',
                "the rule on '$key' lets " . join( ', ', @{ $r->{admits} } ) . " $mode it, which "
                    . "$enc does not - a rule inside another that widens it, of the "
                    . 'kind 0.16.3 refuses unless the operator or the enclosing rule\'s owner writes it',
                "review it: keep it if it is meant (it stays in force), or remove it with "
                    . cli_spelling() . " acl remove '$key' --actor local --docroot $d" );
            last if ++$n >= 50;
        }
        last if $n >= 50;
    }
    return;
}

# SM1401 (triage T-91): A RULE WHOSE OWNER IS NO ACCOUNT IS NAMED. Removing an
# account (`lazysite-users.pl remove`, the manager's account delete) leaves its
# rules with the login as owner. The rule stays in force as written, and only
# the operator can change it: a rule's writer must be its owner or an operator,
# and a token is never an operator (Acl::_is_operator answers 0 under token
# auth), so an agent that could set rules cannot clear this one. The remove
# command names them at the time; this names the ones already there. `local`,
# the host operator, is an owner every site has. A WARN; nothing is changed,
# with or without --fix, because whether the rule should stay is a decision.
sub report_rules_without_an_owner {
    my $d = $opt{docroot};
    my ( $map, $state ) = _read_json_state( _acls_file($d) );
    return unless $state eq 'ok' && ref $map eq 'HASH' && keys %$map; # the other states: report_group_acl_reach
    open my $uf, '<', "$LZ/auth/users" or return; # no store, or unreadable: the auth checks name it
    my %account = ( local => 1 );
    while ( my $l = <$uf> ) {
        next if $l =~ /^\s*(?:#|$)/;
        my ($name) = split /:/, $l, 2;
        next unless defined $name;
        $name =~ s/^\s+|\s+$//g;
        $account{$name} = 1 if length $name;
    }
    close $uf;
    my $n = 0;
    for my $key ( sort keys %$map ) {
        my $rec = $map->{$key};
        next unless ref $rec eq 'HASH';
        my $owner = $rec->{owner};
        next unless defined $owner && length $owner && !$account{$owner};
        report( 'WARN',
            "the rule on '$key' is owned by '$owner', which is no account (removed, or never one) - the "
                . 'rule stays in force as written, and only the operator can change it',
            "remove it from the manager's Permissions (Files page) as the operator, or re-own it: "
                . cli_spelling() . " acl set '$key' --owner ACCOUNT --actor local --docroot $d. A token cannot: "
                . 'only the operator changes a rule it does not own' );
        last if ++$n >= 50;
    }
    return;
}

sub report_group_acl_reach {
    my $d = $opt{docroot};
    # SM551: through the engine-tree resolver, never "$d/lazysite/..." by hand -
    # on a migrated site (SM293) that path does not exist and this section
    # reported nothing while rules were in force.
    my $f = _acls_file($d);

    # SM1023: the open decides (SM770: no -f guard in front of it), and the
    # three answers differ. Absent: no rules, nothing to say. Unreadable by this
    # run: which paths are protected is unknown. Undecodable: the renderer fails
    # closed on it (SM268 H12) and refuses every page it checks against the ACL.
    my ( $map, $state, $err ) = _read_json_state($f);
    return if $state eq 'absent';
    if ( $state eq 'unreadable' ) {
        report( 'WARN',
            'cannot read acls.json as ' . _running_as() . " ($err) - which paths are "
                . 'protected, and to whom, is unknown',
            _run_as_remedy($f) );
        return;
    }
    if ( $state eq 'undecodable' ) {
        report( 'FAIL',
            "acls.json does not decode as a JSON object ($f) - the renderer refuses "
                . 'every page it checks against the ACL until it is repaired, and every '
                . 'rule change and file copy is refused so the damaged file is not replaced',
            "repair the JSON in '$f', or restore it from a backup" );
        return;
    }

    # Every @group named by any entry, in any mode.
    return unless keys %$map;

    # SM287: is anything site-wide? Informational, deliberately NOT a warning,
    # and reported BEFORE the @group section because it is a different question
    # and a site can have one without the other.
    #
    # Enumerating top-level folders is a legitimate choice and nagging about it
    # would teach the reader to skip this section. But it fails OPEN as content
    # grows - a file added at the docroot root next month is public, with
    # nothing else in this tool to say so - and a sysop who believes the
    # site is closed should be able to see which of the two shapes they have.
    my $has_root = grep { exists $map->{$_} } ( '/', '', '.', './' );
    report( 'OK',
        $has_root
        ? 'a site-wide ACL rule is in force - every path is governed unless a '
            . 'more specific entry says otherwise'
        : 'access is granted per path; there is no site-wide rule, so anything '
            . 'added outside the listed paths is public (use "/" if the whole '
            . 'site should be private)' );

    my %wanted;
    for my $path ( keys %$map ) {
        my $e = $map->{$path};
        next unless ref $e eq 'HASH';
        for my $mode (qw(read write)) {
            my $list = $e->{$mode};
            next unless ref $list eq 'ARRAY';
            for my $entry (@$list) {
                next unless defined $entry && $entry =~ /\A\@(.+)\z/;
                push @{ $wanted{ lc $1 } }, "$path ($mode)";
            }
        }
    }
    return unless %wanted;

    # DELIBERATELY NOT RESOLVING MEMBERSHIP HERE.
    #
    # The honest options were: duplicate the closure logic (a fourth answer to
    # "which groups is this account in", which is the defect SM288 exists to
    # remove, so no), report DIRECT membership only (which omits anyone in a
    # nested group and would tell a sysop that somebody does not gain access
    # when they do), or name the entries and point at the tool that knows. This
    # file is core-Perl by design and cannot load Lazysite::Auth::Settings.
    #
    # Under-reporting who gains access is worse than not reporting it.
    for my $g ( sort keys %wanted ) {
        report( 'OK',
            "\@$g is granted by " . join( ', ', sort @{ $wanted{$g} } ) );
    }
    report( 'OK',
        'SM288: these @group entries now apply on EVERY channel, including MCP '
            . 'and the control API, where they were silently inert before. '
            . 'For who is in each group, including via nested groups: '
            . 'lazysite-users.pl --docroot <docroot> groups' );
    return;
}

# ---------------------------------------------------------------------------
# SM285: the ACL self-probe.
#
# Everything else in this tool inspects the site from the inside. This asks the
# only question that matters from the outside, and it is the question nothing
# could answer before: WHEN THE ENGINE REFUSES A FILE, DOES THE VISITOR ACTUALLY
# GET REFUSED? Front-end configuration decides that, lazysite ships templates it
# cannot test where they are installed, and on most deployments we have no
# access to look. SM248, SM268 H17 and SM283 were all that gap; SM283 was live
# across a fleet for weeks and was found by a person fetching a URL by hand.
#
# WHY SEVERAL EXTENSIONS, which is the whole design. SM283 leaked .png, .pdf,
# .txt and .bin and gated .dat - because .dat was the one extension absent from
# the front end's static list. A probe using one extension would have picked
# .dat and reported OK. Deciding by extension cannot be made safe, so neither
# can testing one.
#
# A SUB, not a file-scoped `my` list. The first version was
# `my @PROBE_EXT = qw(...)` down here, and this file executes its main body near
# the top - so the list was still EMPTY when the probe ran. The loop iterated
# zero times, `@gated == @PROBE_EXT` compared 0 with 0, and the probe reported
# "the front end respects the ACL" against a port with nothing listening on it.
# A security check that passes by testing nothing is the exact defect this whole
# programme is about, and it survived until a test drove a real leaking front
# end at it.
sub _probe_exts { return qw(png pdf txt css gz dat) }

# ---------------------------------------------------------------------------
# SM293: which layout this site has, and a FAIL if it has both.
#
# `lazysite/` holds config, credentials, the audit log, session state, form
# submissions and pre-install snapshots. Inside the docroot it is kept
# unreachable by a `deny /lazysite/` repeated in every shipped front-end
# template - the same arrangement SM248, SM268 H17 and SM283 each turned out to
# be. SM283's proxy answered static extensions off the docroot, so on any host
# whose list includes `gz` it would have served
# `lazysite/backups/preinstall-*.tar.gz`: the whole site, including the account
# store, to anyone who knew the path.
#
# A site migrates by MOVING the directory beside its docroot. Both layouts work,
# so this reports rather than nags - EXCEPT for the half-migrated state, which is
# a genuine fault and an invisible one: the engine reads the outside copy while
# the front end can still serve the inside one, so the site behaves perfectly and
# publishes its credentials.
# SM293 step 3: registries left over from before they were engine-served.
#
# They used to be written into the content root and served from disk. Now they
# are generated on request and cached outside it - but a file left at the old
# path is still resolved by the front end BEFORE the engine is consulted, so it
# keeps being served and nothing ever regenerates it. A sitemap frozen on the day
# of the upgrade, quietly, is the failure mode.
#
# WARN, not FAIL: a stale sitemap is an SEO problem, not a disclosure. And the
# sysop may have authored their own on purpose, which the engine deliberately
# yields to - so this names the files and explains, rather than deleting them.
# SM844: A TEMPLATE WRITTEN CORRECTLY FOR 0.12 IS WRONG ON 0.13, AND NOTHING SAID.
#
# 0.12 printed a db: value raw, so `| html` was the right advice. 0.13 escapes
# every db: value at the sink (SM786), so the same `| html` escapes a second time
# and shows `&amp;lt;` - only for rows that contain & < > " ', so it can sit
# unnoticed until somebody adds "Smith & Jones". The render log names the table
# and column once a visitor hits it; this names the FILE before anyone does.
#
# A page is listed when its front matter binds a table with db: AND it uses
# `| html` inside [% %]. That catches the page-body case. A layout that applies
# `| html` to a db: variable cannot be tied to a binding from here, and the
# message says so rather than implying the list is complete.
# SM921: a form field whose `pattern` a browser cannot compile validates NOTHING -
# the specification's answer to an uncompilable pattern is to ignore the attribute
# in full, so the field accepts anything and nothing says so. The engine's own
# shipped `tel` default was in that state until 0.15.2, which means the sites that
# already have one are the population this looks for.
#
# WARN, not refuse, and NOT at render time. Ruled 2026-09-30: validate_page refuses
# a new bad pattern while the author is writing it, this finds the ones already
# published, and the render path is unchanged - a render-time refusal would show an
# error where a form used to be, on upgrade, on exactly these sites.
#
# THE JUDGEMENT IS NOT RESTATED HERE. Lazysite::Validate::html_pattern_problem is
# the one definition of which shapes the `v` flag refuses, and t/lint/204 holds both
# callers to it; a second copy would be two answers to one question, drifting. If
# the module cannot be loaded this says SO rather than reporting a clean sweep it
# never made.
sub report_uncompilable_form_patterns {
    my $d = $opt{docroot};
    unless ( eval { require Lazysite::Validate; 1 } ) {
        report( 'WARN', 'cannot check form patterns: Lazysite::Validate did not load',
            'this check needs the engine module tree; the pattern rules in page '
                . 'content were NOT examined' );
        return;
    }

    my @roots = ($d);
    if ( eval { require Lazysite::Private; 1 } ) {
        my $store = Lazysite::Private::private_root($d);
        push @roots, $store if $store && -d $store;
    }

    my @hits;
    for my $root (@roots) {
        find_noting( 'the form-pattern check',
            { no_chdir => 1, wanted => sub {
                    my $p = $File::Find::name;
                    if ( -d $p ) {
                        $File::Find::prune = 1 if $p eq Lazysite::Paths::internal_lazysite_dir($d);
                        return;
                    }
                    return unless $p =~ /\.md\z/;
                    open my $fh, '<', $p or return;
                    my $text = do { local $/; <$fh> };
                    close $fh;
                    return unless $text =~ /:::\s*form\b/;
                    for my $block ( $text =~ /:::\s*form\b(.*?):::/gs ) {
                        for my $line ( split /\n/, $block ) {
                            next unless $line =~ /\|/;
                            my ( $name, undef, $rules ) = split /\s*\|\s*/, $line, 3;
                            next unless defined $rules;
                            my $pat;
                            if ( $rules =~ /\bpattern:"((?:[^"\\]|\\.)*)"/ ) { $pat = $1 }
                            elsif ( $rules =~ /\bpattern:(\S.*?)\s*\z/ )     { $pat = $1 }
                            next unless defined $pat;
                            next unless Lazysite::Validate::html_pattern_problem($pat);
                            ( my $rel = $p ) =~ s{\A\Q$root\E/}{};
                            push @hits, "$rel ($name)";
                        }
                    }
            } }, $root );
    }

    if (@hits) {
        my @show = sort @hits;
        my $more = @show > 8 ? ' (and ' . ( @show - 8 ) . ' more)' : '';
        splice @show, 8 if @show > 8;
        report( 'WARN',
            scalar(@hits) . ' form field(s) carry a pattern no browser can compile: '
                . join( ', ', @show ) . $more
                . ' - an uncompilable pattern is ignored in full, so those fields '
                . 'validate nothing at all',
            'escape the reserved characters inside the character class - ( ) { } [ ] '
                . '/ | and a hyphen at either end all need a backslash under the `v` '
                . 'flag browsers compile with; `lazysite-validate.pl <page.md>` names '
                . 'the field and the character' );
    }
    else {
        report_ok_read( 'the form-pattern check', 'every form pattern in page content can be compiled' );
    }
    return;
}

sub report_double_escaped_db_templates {
    my $d     = $opt{docroot};
    my @roots = ($d);
    if ( eval { require Lazysite::Private; 1 } ) {
        my $store = Lazysite::Private::private_root($d);
        push @roots, $store if $store && -d $store;
    }
    my @hits;
    for my $root (@roots) {
        find_noting( 'the db: template check',
            { no_chdir => 1, wanted => sub {
                    my $p = $File::Find::name;
                    if ( -d $p ) {
                        $File::Find::prune = 1 if $p eq Lazysite::Paths::internal_lazysite_dir($d);
                        return;
                    }
                    return unless $p =~ /\.md\z/;
                    open my $fh, '<', $p or return;
                    my $text = do { local $/; <$fh> };
                    close $fh;
                    my ($fm) = $text =~ /\A---\s*\n(.*?)\n---\s*\n/s or return;
                    return unless $fm   =~ /\bdb:\s*[a-z]/i;
                    return unless $text =~ /\[%[^%]*\|\s*html\b[^%]*%\]/;
                    push @hits, $p =~ s{\A\Q$root\E/}{}r;
            } }, $root );
    }
    if (@hits) {
        my @show = sort @hits;
        my $more = @show > 8 ? ' (and ' . ( @show - 8 ) . ' more)' : '';
        splice @show, 8 if @show > 8;
        report( 'WARN',
            scalar(@hits) . ' page(s) bind a data table with db: and also use | html: '
                . join( ', ', @show ) . $more
                . ' - db: values are escaped for you from 0.13.0, so | html escapes them a '
                . 'second time and shows &amp;lt; for any value containing & < > or quotes',
            'remove | html from the db: values in those templates; a layout that applies '
                . '| html to a db: variable is not covered by this check' );
    }
    else {
        report_ok_read( 'the db: template check', 'no page binds a data table and also applies | html to it' );
    }
    return;
}

# SM842: delivery shapes the handler contract no longer reads - an inline form
# target, a webhook, api or db handler, a connector that schedules itself. The
# upgrade converts them (install.pl runs lazysite-handlers.pl convert); this
# says so when one survived, because each is a form or a timer that has quietly
# stopped delivering. A text scan, not the converter, because this tool is
# core-Perl by design; the converter is what repairs.
sub report_unconverted_delivery {
    my $forms = "$LZ/forms";
    my @found;
    if ( opendir my $dh, $forms ) {
        for my $f ( sort grep { /\.conf\z/ } readdir $dh ) {
            next if $f =~ /\A(?:smtp|schedule)\.conf\z/;
            open my $cf, '<', "$forms/$f" or next;
            my $text = do { local $/; <$cf> };
            close $cf;
            if ( $f eq 'handlers.conf' ) {
                push @found, "handler '$1' is a '$2' handler"
                    while $text =~ /^[ \t]*-[ \t]+id:[ \t]*(\S+)(?:(?!^[ \t]*-[ \t]+id:).)*?^[ \t]+type:[ \t]*(webhook|api|db)[ \t]*$/gmsx;
                next;
            }
            push @found, "form '" . ( $f =~ s/\.conf\z//r ) . "' has an inline target"
                if $text =~ /^[ \t]*-[ \t]+type:/m;
        }
        closedir $dh;
    }
    if ( open my $cj, '<', "$LZ/connectors/connectors.json" ) {
        my $text = do { local $/; <$cj> };
        close $cj;
        push @found, 'a connector carries its own schedule (schedule_every)' if $text =~ /"schedule_every"/;
    }
    if (@found) {
        report( 'WARN',
            scalar(@found) . ' delivery setting(s) the engine no longer reads: ' . join( '; ', @found )
                . ' - each is a form or a timer that delivers nothing until converted',
            "run: lazysite-handlers.pl convert --docroot $opt{docroot} (as the site user); it says what it "
                . 'changed and anything it could not' );
    }
    else {
        report( 'OK', 'every form and schedule names a handler the engine reads' );
    }
    return;
}

# SM1390 (ruling 147): an account named by the preview cookie's marker. Since
# SM1390 the session verifier refuses a payload beginning with that marker, so
# such an account signs in and is refused on every request; the creating doors
# refuse the name now, and this names one that already existed. The marker is
# the verifier's own constant, never a literal here.
sub report_preview_marker_account {
    my $users = "$LZ/auth/users";
    open my $fh, '<', $users or return; # no store, or unreadable: reported by the auth checks
    require Lazysite::Auth::Session;
    my $marker = Lazysite::Auth::Session::PREVIEW_MARKER();
    my $found  = 0;
    while ( my $l = <$fh> ) {
        next if $l =~ /^\s*(?:#|$)/;
        my ($name) = split /:/, $l, 2;
        next unless defined $name;
        $name =~ s/^\s+|\s+$//g;
        $found = 1 if $name eq $marker;
    }
    close $fh;
    if ($found) {
        report( 'WARN',
            "this site has an account named '$marker', the preview cookie's marker: its sessions are "
                . 'refused as previews, so it cannot sign in',
            "rename it (users rename $marker NEW-NAME); the users tool refuses the name from now on" );
    }
    else {
        report( 'OK', "no account is named by the preview cookie's marker ('$marker')" );
    }
    return;
}

# SM1391 (ruling 148): a schedule entry whose interval is under the floor. The
# save path refuses one (Lazysite::Handlers, "at least 300"), so it exists only
# when it was written into lazysite/forms/schedule.conf by hand - and the
# scheduler never runs it. The daemon records the refusal once (Daemon::Jobs);
# this names it from the file, so an operator without the run record is told.
# A text scan of the records format, as the scans above: id, then every, inside
# one `- id:` record. The floor is the one Lazysite::Handlers declares.
sub report_schedule_floor {
    my $floor = 300;
    my @found;
    if ( open my $fh, '<', "$LZ/forms/schedule.conf" ) {
        my $text = do { local $/; <$fh> };
        close $fh;
        while ( $text =~ /^[ \t]*-[ \t]+id:[ \t]*(\S+)((?:(?!^[ \t]*-[ \t]+id:).)*)/gmsx ) {
            my ( $id, $body ) = ( $1, $2 );
            next if $body =~ /^[ \t]+enabled:[ \t]*(?:false|no|off|0)[ \t]*$/mi;
            my ($every) = $body =~ /^[ \t]+every:[ \t]*(.*?)[ \t]*$/m;
            next unless defined $every;
            push @found, "'$id' (every: $every)" unless $every =~ /\A\d+\z/ && $every >= $floor;
        }
    }
    if (@found) {
        report( 'WARN',
            scalar(@found) . " schedule entr" . ( @found == 1 ? 'y' : 'ies' )
                . " under the $floor-second floor, which the scheduler never runs: " . join( '; ', @found ),
            "set every: to $floor or more on the Handlers page or with schedule-save, "
                . 'which refuses less; the daemon records the refusal once in lazysite/daemon/schedule-runs.json' );
    }
    else {
        report( 'OK', "every schedule entry is at or above the $floor-second floor" );
    }
    return;
}

# SM1118 (ruled 2026-10-20, #338): A SITE IN MAINTENANCE IS A SITE NOBODY BUT ITS
# OPERATORS CAN USE, and it stays that way until somebody switches it off - so the
# check says so every time it runs, naming where it is on (the instance, or which
# domains) and when it is expected back. A value the engine would read as off is
# named as well: `maintenance: yes please` leaves the site open while the file
# says otherwise. This file is core-Perl by design and loads no engine module, so
# it carries the switch's values as Lazysite::Maintenance::on_value reads them.
sub report_maintenance {
    open my $fh, '<', $conf or return;
    my $text = do { local $/; <$fh> };
    close $fh;
    my $is_on = sub { defined $_[0] && $_[0] =~ /\A\s*(?:on|enabled|true|yes|1)\s*\z/i };
    my $is_off = sub { !defined $_[0] || $_[0] =~ /\A\s*(?:off|disabled|false|no|0)?\s*\z/i };
    my ( $base, $until, $page );
    while ( $text =~ /^maintenance\h*:\h*(.*?)\h*$/mg )       { $base  = $1 }
    while ( $text =~ /^maintenance_until\h*:\h*(.*?)\h*$/mg ) { $until = $1 }
    while ( $text =~ /^maintenance_page\h*:\h*(.*?)\h*$/mg )  { $page  = $1 }
    my %dom;
    while ( $text =~ /^alias\.(\S+)\.maintenance\h*:\h*(.*?)\h*$/mg ) { $dom{ lc $1 } = $2 }
    my @odd = ( ( defined $base && !$is_on->($base) && !$is_off->($base) ? ('maintenance') : () ),
        map { "alias.$_.maintenance" } grep { !$is_on->( $dom{$_} ) && !$is_off->( $dom{$_} ) } sort keys %dom );
    report( 'WARN',
        'lazysite.conf has a maintenance value the engine reads as OFF: ' . join( ', ', @odd ),
        "write on or off in '$conf'; anything else leaves the site open" )
        if @odd;
    my @on = ( $is_on->($base) ? ('the whole instance') : () );
    push @on, map { "domain $_" } grep { $is_on->( $dom{$_} ) } sort keys %dom if !$is_on->($base);
    return unless @on;
    my $back = ( defined $until && length $until ) ? " (expected back $until UTC)" : '';
    report( 'WARN',
        'the site is IN MAINTENANCE for ' . join( ', ', @on ) . "$back: visitors are sent to the maintenance page and only accounts holding access during maintenance get through",
        'switch it off on the Config page (or the domain\'s sheet) when the work is done' );
    my $p = ( defined $page && length $page ) ? $page : '/maintenance';
    if ( $p =~ m{\A/} ) {
        ( my $n = $p ) =~ s{\A/+|/+\z}{}g;
        report( 'WARN', "the maintenance page ($p) does not resolve to a page of this site, so visitors would be sent to a 404",
            'write it as a page, or leave maintenance_page unset to use the one the site ships' )
            unless length $n && ( -f "$DOC/$n.md" || ( $n eq 'maintenance' && -f "$LZ/templates/system/maintenance.md" ) );
    }
    return;
}

# SM1155: a site that sets app_name installs as an app, and the engine turns the
# app OFF on a value it cannot honour rather than guessing (a scope of `portal`
# repaired to `/portal/` would install the wrong section). So an operator who
# typed one sees no manifest and no reason - this names the value. An icon the
# settings name but the site does not serve is left out of the manifest; a
# browser drops the install prompt for an icon that 404s, so it is said here.
# Silent when app_name is not set.
sub report_app_settings {
    my $name = conf_value( $conf, 'app_name' );
    return unless defined $name && length $name;
    my $scope = conf_value( $conf, 'app_scope' )     // '/';
    my $start = conf_value( $conf, 'app_start_url' ) // $scope;
    my @bad;
    push @bad, "app_scope ($scope) must start and end with / and name a directory"
        unless $scope =~ m{\A/(?:[A-Za-z0-9._~-]+/)*\z} && $scope !~ m{(?:\A|/)\.\.?/};
    ( my $sp = $start ) =~ s/\?.*\z//;
    push @bad, "app_start_url ($start) must be a path inside app_scope ($scope)"
        unless $sp =~ m{\A/[A-Za-z0-9._~/%-]*\z} && $sp !~ m{\.\.} && ( index( $sp, $scope ) == 0 || "$sp/" eq $scope );
    for my $k (qw(app_theme_colour app_background_colour)) {
        my $v = conf_value( $conf, $k );
        push @bad, "$k ($v) must be #rgb or #rrggbb" if defined $v && length $v && $v !~ /\A#(?:[0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})\z/;
    }
    my $root = $DOC;
    my $cr   = conf_value( $conf, 'content_root' );
    $root = "$DOC/$cr" if defined $cr && length $cr && $cr =~ m{\A[A-Za-z0-9._/-]+\z} && $cr !~ m{\.\.} && -d "$DOC/$cr";
    my @missing;
    my $icons = 0;
    for my $k (qw(64 192 512 maskable)) {
        my $p = conf_value( $conf, "app_icon_$k" );
        next unless defined $p && length $p;
        $icons++;
        if ( $p !~ m{\A/[A-Za-z0-9._~/-]+\.(?:png|webp|svg|jpe?g)\z}i || $p =~ m{\.\.} ) {
            push @bad, "app_icon_$k ($p) must be a site path to a png, webp, svg or jpg";
        }
        elsif ( !-f "$root$p" && !-f "$DOC$p" ) {
            push @missing, "app_icon_$k ($p)";
        }
    }
    if (@bad) {
        report( 'WARN', 'lazysite.conf app_name is set but the app is OFF: ' . join( '; ', @bad ),
            "correct it in '$LZ/lazysite.conf'; the engine does not guess a scope" );
    }
    if (@missing) {
        report( 'WARN', 'the app manifest leaves out ' . scalar(@missing) . ' icon(s) the site does not serve: ' . join( ', ', @missing ),
            'put the file at that path, or correct the setting' );
    }
    unless ($icons) {
        report( 'WARN', 'the app names no icons (app_icon_192, app_icon_512), so the manifest has none and a browser may not offer to install it',
            'add app_icon_192 and app_icon_512 (png files the site serves); app_icon_maskable and app_icon_64 are optional' );
    }
    report( 'OK', "app '$name' is declared at $scope with a valid scope, start page and icons" ) unless @bad || @missing || !$icons;
    return;
}

# SM1356: THE SITE'S TIME ZONE, which every schedule and dated row is read in. A
# name the host cannot find is read as UTC, so a site in Europe/London would say
# "open now" an hour early all summer and nothing on the page would show why.
# Silent when the key is absent (UTC is then what the site asked for).
sub report_time_zone {
    my $raw = conf_value( "$LZ/lazysite.conf", 'time_zone' );
    return unless defined $raw && length $raw;
    my $dir = $ENV{TZDIR} && -d $ENV{TZDIR} ? $ENV{TZDIR} : '/usr/share/zoneinfo';
    if ( $raw eq 'UTC'
        || ( $raw =~ m{\A[A-Za-z][A-Za-z0-9_+-]*(?:/[A-Za-z0-9_+-]+){0,2}\z} && -f "$dir/$raw" ) )
    {
        report( 'OK', "time_zone is $raw; schedules and dated rows are read in it" );
    }
    else {
        report( 'WARN', "time_zone '$raw' is not a zone this host knows, so schedules and dated rows are read in UTC",
            "name a zone from $dir such as Europe/London (the tzdata package provides them)" );
    }
    return;
}

# SM1352, SM1363 (ruling 187): CRYPTX, WHICH PASSKEYS AND WEB PUSH NEED. The deb
# recommends it rather than depends on it, so a host may lack it; the two features
# then say so where they are used, and this says so once for the site. A WARN only
# when the site is using one of them - an account holds a passkey, or notify.conf
# routes a notice by webpush - because an unused optional library is not a fault.
sub report_cryptx {
    require Lazysite::Crypto;
    my $missing = Lazysite::Crypto::cryptx_missing();
    if ( !defined $missing ) {
        report( 'OK', 'CryptX is installed: passkeys and web push can be used' );
        return;
    }
    my @using;
    if ( open my $fh, '<:raw', "$LZ/auth/user-settings.json" ) {
        my $raw = do { local $/; <$fh> };
        close $fh;
        my $all = eval { JSON::PP::decode_json( $raw // '{}' ) };
        push @using, 'an account holds a passkey'
            if ref $all eq 'HASH'
            && grep { ref $_ eq 'HASH' && ref $_->{passkeys} eq 'ARRAY' && @{ $_->{passkeys} } } values %$all;
    }
    if ( open my $fh, '<', "$LZ/notify.conf" ) {
        while ( my $l = <$fh> ) {
            next unless $l =~ /^\s*route\.[\w.-]+\s*:.*\bwebpush\b/i;
            push @using, 'notify.conf routes a notice by webpush';
            last;
        }
        close $fh;
    }
    if (@using) {
        report( 'WARN', 'CryptX (libcryptx-perl) is not installed, so passkeys and web push do not work, and '
                . join( '; ', @using ),
            'install libcryptx-perl (apt install libcryptx-perl); nothing else needs it' );
        return;
    }
    report( 'OK', 'CryptX (libcryptx-perl) is not installed: passkeys and web push are unavailable until it is' );
    return;
}

# SM1357: EVERY PUBLIC PAGE HAS A TITLE AND A DESCRIPTION, and no two pages of
# one domain share a title. The sitemap and the AI-readable summary list every
# public page, and a search engine shows a page by its title and description: a
# page with neither is listed as its address.
#
# n785: PER DOMAIN, FROM THE PAGE SET THE SITEMAP LISTS. This walked the whole
# docroot, so `index.md` and `sites/b/index.md` - the home pages of two domains -
# were one shared title. Each domain's set now comes from the processor itself
# (`--page-set`, _public_page_set_listing: ruling 174's one set, from the scan
# its sitemap and llms.txt are built from), so another domain's root, ruling
# 171's folders and every page the sitemap leaves out are not counted, and each
# warning names its domain. The primary first, then each alias with a content
# root of its own; an alias without one shares the primary's pages. On a site with
# one domain the warnings name none (ruling 199). Title and
# description as the registries publish them: meta_title else title, meta_desc
# else subtitle.
sub report_page_titles {
    my $d      = $opt{docroot};
    my $bin    = File::Basename::dirname( Cwd::abs_path(__FILE__) );
    my ($proc) = grep { defined && -f && -r }
        ( defined $opt{cgibin} ? "$CGI/lazysite-processor.pl" : () ),
        Lazysite::Paths::find_processor($d),
        "$bin/../lazysite-processor.pl";    # the engine tree this tool runs from
    unless ( defined $proc ) {
        report( 'WARN', 'the page title check did not run: no lazysite-processor.pl was found',
            'pass --cgibin with the cgi-bin directory that holds it' );
        return;
    }
    my $site_url  = conf_value( $conf, 'site_url' ) // '';
    my ($primary) = $site_url =~ m{\A\w+://([^/:]+)};
    my @hosts     = ( [ undef, $primary // 'the primary domain' ],
        map { [ $_, $_ ] } grep { length } map { lc s/^\s+|\s+$//gr } split /,/, conf_value( $conf, 'alias_hosts' ) // '' );

    my ( $n, $bad ) = ( 0, 0 );
    my ( @read, %seen, %unread );
    for my $h (@hosts) {
        my ( $host, $label ) = @{$h};
        my $set = _page_set_of( $proc, $d, $host );
        unless ( ref $set eq 'HASH' ) {
            report( 'WARN', "$label: the page title check did not run: $proc --page-set gave no page set",
                'run it by hand with DOCUMENT_ROOT set to see why' );
            $bad = 1;
            next;
        }
        next unless defined $set->{root} && !$seen{ $set->{root} }++;
        %unread = ( %unread, %{ $set->{unread} } ) if ref $set->{unread} eq 'HASH';
        my ( @untitled, @undescribed, @ignored, %by_title );
        for my $p ( @{ $set->{pages} || [] } ) {
            $n++;
            my $title = $p->{title} // '';
            push @untitled,    $p->{url} unless length $title;
            push @undescribed, $p->{url} unless length( $p->{description} // '' );
            push @ignored, $p->{url} if $p->{ignored_description} && !length( $p->{description} // '' );
            push @{ $by_title{ lc $title } }, $p->{url} if length $title;
        }
        push @read, [ $label, \@untitled, \@undescribed, \%by_title, \@ignored ];
    }
    # Ruling 199: a site with one domain is not told which domain it is.
    for my $r (@read) {
        $r->[0] = '' if @read == 1;
        $bad    = 1  if _report_page_titles_of( @{$r} );
    }
    # n814 (SM1437), ruling 206: A PAGE SET THAT COULD NOT BE READ WHOLE IS NOT "OK".
    # Run as a user who cannot open a directory, the walk left it out and this said
    # "0 public page(s), each with a title..." about a site with 17 undescribed pages.
    if (%unread) {
        my @paths = sort keys %unread;
        my @show  = map { "$_ ($unread{$_})" } @paths;
        my $more  = @show > 8 ? ' (and ' . ( @show - 8 ) . ' more)' : '';
        splice @show, 8 if @show > 8;
        report( 'WARN',
            'the page title check could not read ' . scalar(@paths) . ' path(s) as ' . _running_as() . ': '
                . join( ', ', @show ) . $more
                . ' - the pages there were not looked at, so the public page count and every finding here cover the rest of the site only',
            _run_as_remedy(@paths) );
        $bad = 1;
    }
    report( 'OK', "$n public page(s), each with a title and a description of its own" ) unless $bad;
    return;
}

# One domain's page set, from the processor as a command (never a request).
sub _page_set_of {
    my ( $proc, $d, $host ) = @_;
    local %ENV = %ENV;
    delete @ENV{qw(GATEWAY_INTERFACE REQUEST_METHOD REQUEST_URI REDIRECT_URL QUERY_STRING HTTP_HOST)};
    $ENV{DOCUMENT_ROOT} = $d;
    $ENV{HTTP_HOST}     = $host if defined $host;
    open my $err, '>&', \*STDERR    or return undef;
    open STDERR,  '>',  '/dev/null' or return undef;
    my $ok = open my $ph, '-|', $^X, $proc, '--page-set';
    open STDERR, '>&', $err or return undef;
    return undef unless $ok;
    my $out = do { local $/; <$ph> };
    close $ph or return undef;
    return eval { JSON::PP->new->utf8->decode( $out // '' ) };
}

# The three findings for one domain; true when there was any.
sub _report_page_titles_of {
    my ( $label, $untitled, $undescribed, $by_title, $ignored ) = @_;
    $ignored //= [];
    my $on   = length $label ? "$label: " : '';
    my $list = sub {
        my @show = sort @_;
        my $more = @show > 8 ? ' (and ' . ( @show - 8 ) . ' more)' : '';
        splice @show, 8 if @show > 8;
        return join( ', ', @show ) . $more;
    };
    report( 'WARN', $on . scalar(@$untitled) . ' public page(s) have no title: ' . $list->(@$untitled)
            . ' - a search engine and the sitemap list such a page by its address',
        'give each a title: in its front matter (meta_title: sets the one search engines see, if it should differ)' )
        if @$untitled;
    report( 'WARN', $on . scalar(@$undescribed) . ' public page(s) have no description: ' . $list->(@$undescribed)
            . ' - a search result and the AI-readable summary (llms.txt) show nothing under the title',
        'give each a subtitle: or a meta_desc: of a sentence or two'
            . ( @$ignored
            ? ' - description: is not read by the engine (' . $list->(@$ignored) . ' carry it); subtitle: and meta_desc: are'
            : '' ) )
        if @$undescribed;
    my @dup = grep { @{ $by_title->{$_} } > 1 } sort keys %$by_title;
    report( 'WARN', $on . scalar(@dup) . ' title(s) are shared by more than one public page: '
            . join( '; ', map { join( ' and ', sort @{ $by_title->{$_} } ) } @dup[ 0 .. ( $#dup < 7 ? $#dup : 7 ) ] )
            . ' - a search engine cannot tell them apart',
        'give each page its own title (or meta_title)' )
        if @dup;
    return @$untitled || @$undescribed || @dup ? 1 : 0;
}

# SM1357: THE JSON-LD THE ENGINE EMITS, checked against each mapping's type - built
# from the rows a visitor may read now, exactly as a page would carry it, by the
# engine's own module (the only reader of a mapping; a second one here would be the
# copy that drifts). A required property empty on a row, a date that is not ISO
# 8601, a page the mapping names that the site does not have, a table no visitor
# may read: each is named. Needs the data modules; a site without mappings is told
# so in one line.
sub report_structured_data {
    my $d   = $opt{docroot};
    my $dir = "$LZ/db/tables";
    my $any = 0;
    if ( opendir my $dh, $dir ) {
        for my $f ( grep { /\.ya?ml\z/ } readdir $dh ) {
            open my $fh, '<', "$dir/$f" or next;
            $any = 1 if grep { /^structured_data\s*:/ } <$fh>;
            close $fh;
        }
        closedir $dh;
    }
    unless ($any) {
        report( 'OK', 'no data table declares structured_data, so no page carries mapped JSON-LD' );
        return;
    }
    my $r = eval {
        require Lazysite::Data::StructuredData;
        Lazysite::Data::StructuredData::validate_site($d);
    };
    unless ($r) {
        report( 'WARN', 'structured_data is declared but could not be checked: '
                . ( ( $@ // '' ) =~ s/\s+at \S+ line \d+.*//sr || 'the data modules did not load' ),
            "install the data extension's dependencies (" . cli_spelling() . ' check --dependencies lists them)' );
        return;
    }
    my @f = @{ $r->{findings} };
    if (@f) {
        my $more = @f > 12 ? ' (and ' . ( @f - 12 ) . ' more)' : '';
        report( 'WARN', scalar(@f) . ' finding(s) in the emitted JSON-LD: '
                . join( '; ', @f[ 0 .. ( $#f < 11 ? $#f : 11 ) ] ) . $more,
            'fill the rows named, or change the mapping in the table\'s descriptor (save_data_table)' );
    }
    else {
        report( 'OK', "the JSON-LD of $r->{mappings} mapping(s) holds against each mapping's type" );
    }
    report( 'OK', $_ ) for @{ $r->{notes} };
    return;
}

# Ruling 171 (SM1357): A FOLDER THAT LOOKS LIKE ANOTHER SITE'S CONTENT and is not a
# declared content root - a folder under sites/, or one holding its own
# lazysite.conf (or lazysite/lazysite.conf) - is served on the bare host like any
# folder of the docroot, while the sitemap and llms.txt leave it out as not this
# site's own (the processor's _foreign_site_folder, the same two shapes). Each is
# named with the remedy. Silent when there is none.
sub report_foreign_site_folders {
    my $d = $opt{docroot};
    my %declared;
    if ( open my $fh, '<', "$LZ/lazysite.conf" ) {
        while ( my $l = <$fh> ) {
            next unless $l   =~ /^(?:alias\.\S+\.)?content_root\h*:\h*(.+?)\h*$/;
            ( my $rel = $1 ) =~ s{^["']|["']$}{}g;
            $rel             =~ s{^/+|/+$}{}g;
            $declared{"$d/$rel"} = 1 if length $rel && $rel !~ m{(?:^|/)\.\.(?:/|$)};
        }
        close $fh;
    }
    my @found;
    find_noting( 'the other-site folder check',
        { no_chdir => 1, wanted => sub {
                my $p = $File::Find::name;
                return unless -d $p && $p ne $d;
                if ( $p eq Lazysite::Paths::internal_lazysite_dir($d) || -l $p || $declared{$p} ) {
                    $File::Find::prune = 1;
                    return;
                }
                my $own_conf = -f "$p/lazysite.conf" || -f Lazysite::Paths::lazysite_dir($p) . '/lazysite.conf';
                my $why =
                    $p =~ m{\A\Q$d\E/sites/[^/]+\z} ? 'it is under sites/'
                    : $own_conf                     ? 'it holds its own lazysite.conf'
                    :                                 undef;
                return unless $why;
                push @found, [ $p =~ s{\A\Q$d\E/}{}r, $why ];
                $File::Find::prune = 1;
        } }, $d );
    for my $f ( sort { $a->[0] cmp $b->[0] } @found ) {
        report( 'WARN', "$f->[0] looks like another site's content ($f->[1]) but is not a declared content root:"
                . ' the bare host serves its pages; the sitemap and llms.txt leave it out',
            "declare it as a domain's content root (alias.<host>.content_root: $f->[0] in lazysite.conf),"
                . ' or move it out of the docroot' );
    }
    return;
}

# Ruling 206 (item 7 of the 0.16.9 fault survey): EVERY DECLARED CONTENT ROOT
# IS ONE THE ENGINE WILL SERVE. A content_root (the primary's, or an
# alias.<host>.content_root) that the processor's confine_content_root rejects
# refuses that host with a 503 - it used to serve the docroot root under the
# host's name. The same tests, in the same order: a safe shape, a folder that
# exists, inside the docroot once symlinks are resolved, and not the engine tree.
# One FAIL per root, naming the host and the repair. Silent when all are good.
sub report_content_roots {
    my $d = $opt{docroot};
    open my $fh, '<', "$LZ/lazysite.conf" or return;
    my @roots;
    while ( my $l = <$fh> ) {
        next unless $l =~ /^(alias\.(\S+)\.)?content_root\h*:\h*(.+?)\h*$/;
        push @roots, [ ( defined $2 ? $2 : 'the primary host' ), $3 ];
    }
    close $fh;
    my $droot = abs_path($d) // $d;
    my $lzdir = abs_path( Lazysite::Paths::lazysite_dir($d) );
    for my $r (@roots) {
        my ( $host, $v ) = @$r;
        ( my $rel = $v ) =~ s{^["']|["']$}{}g;
        $rel =~ s{^/+|/+$}{}g;
        next unless length $rel;   # '' or '/' is the docroot root, as the engine reads it
        my $why =
            $rel =~ /\0/ || $rel =~ m{(?:^|/)\.\.(?:/|$)} || $rel =~ m{[<>"'\\]} ? 'is not a safe path'
            : !-d "$d/$rel" ? 'is not a folder in the docroot'
            :                 undef;
        unless ($why) {
            my $abs = abs_path("$d/$rel") // '';
            $why = 'resolves outside the docroot'
                unless $abs eq $droot || index( $abs, "$droot/" ) == 0;
            $why //= 'is inside the engine tree'
                if defined $lzdir && ( $abs eq $lzdir || index( $abs, "$lzdir/" ) == 0 );
        }
        next unless $why;
        report( 'FAIL',
            "the content_root for $host ($v) $why - every request to that host is refused (503)",
            "correct it in '$LZ/lazysite.conf'"
                . ( $why eq 'is not a folder in the docroot' ? ", or create the folder '$d/$rel'" : '' ) );
    }
    return;
}

# Ruling 206 (item 8): session_lifetime and password_min_length, read as the
# engine reads them (Auth::Session, Auth::Credential). An invalid value used to
# become the default in silence; it is refused now, so each is a FAIL naming the
# key, the range and what it stops. Unset (or empty) is the default, and silent.
sub report_auth_numbers {
    open my $fh, '<', "$LZ/lazysite.conf" or return;
    my %raw;
    while ( my $l = <$fh> ) {
        next unless $l =~ /^\s*(session_lifetime|password_min_length)\s*:\s*(.*?)\s*$/;
        $raw{$1} //= $2;
    }
    close $fh;
    my %rule = (
        session_lifetime => [ 300, 31_536_000, 'a whole number of seconds',
            'every sign-in and every session is refused' ],
        password_min_length => [ 8, 128, 'a whole number', 'every password set or reset is refused' ],
    );
    for my $k ( sort keys %rule ) {
        my $v = $raw{$k};
        next unless defined $v && length $v;
        my ( $lo, $hi, $what, $stops ) = @{ $rule{$k} };
        next if $v =~ /\A\d+\z/ && $v >= $lo && $v <= $hi;
        report( 'FAIL', "$k in lazysite.conf is '$v', which is not $what from $lo to $hi - $stops",
            "set $k to a value from $lo to $hi in '$LZ/lazysite.conf', or remove the line for "
                . 'the default' );
    }
    return;
}

# N13-30: lazysite.conf keys 0.13.13 stopped reading. The upgrade converts them
# (install.pl convert_retired_conf_keys); this catches a site that took the code
# some other way, or had one put back by hand. Silent when there is none.
sub report_retired_conf_keys {
    open my $fh, '<', "$LZ/lazysite.conf" or return;
    my @found;
    while ( my $l = <$fh> ) {
        push @found, 'manager_upload_blocked_paths (its name is manager_blocked_paths)'
            if $l =~ /^\s*manager_upload_blocked_paths\s*:/;
        push @found, 'db_render_raw (db: values are always escaped now)' if $l =~ /^\s*db_render_raw\s*:/;
    }
    close $fh;
    return unless @found;
    report( 'WARN',
        'lazysite.conf sets ' . scalar(@found) . ' key(s) the engine no longer reads: ' . join( '; ', @found ),
        'rename manager_upload_blocked_paths to manager_blocked_paths, and delete db_render_raw' );
    return;
}

# SM1412 (ruling 159): notify.conf's `owner_contact` (SM1362, 0.16.6) is retired
# and ignored from 0.16.8, so a site that set it mails its owner nothing now.
# Named with the remedy, which is how a form mails people (ruling 158): a notify
# handler on the form whose recipients name the people, as a group. Silent when
# the key is not set; nothing is changed, with or without --fix.
sub report_retired_notify_keys {
    open my $fh, '<', "$LZ/notify.conf" or return;
    my $set = 0;
    while ( my $l = <$fh> ) {
        $set = 1 if $l =~ /^\s*owner_contact\s*:\s*\S/;
    }
    close $fh;
    return unless $set;
    report( 'WARN',
        'lazysite/notify.conf sets owner_contact, which the engine no longer reads (retired in 0.16.8): '
            . 'no form notice is mailed to that address',
        'to mail people when a form is submitted, add a notify handler on the Handlers page whose '
            . 'recipients name them - a group, e.g. [{"groups":["site-owners"]}] - make it one of the '
            . "form's targets, then delete the owner_contact line" );
    return;
}

# N141D (SM864, remaining half): say that a pre-SM659 shared `manager` account
# is here.
#
# Before SM659 the bootstrap command created a ROLE ACCOUNT called `manager` by
# default - one login, shared by whoever administered the site. SM659 replaced
# it with setup-sysop, which names a person, and deliberately left no alias so
# the old way could not be followed by habit. The installer half of this shipped.
#
# WHAT DID NOT: on a site that predates the change the account is simply still
# there, and NOTHING SAYS SO. An operator who has never read SM659 has no reason
# to look, and a shared credential nobody is reminded of is one nobody rotates,
# scopes or retires - while the audit trail attributes every action it takes to
# a name that is not a person.
#
# REPORTED, NOT REPAIRED, and the filing is explicit about why: "Nothing renames
# or deletes it - an operator may be signing in with it." A check that silently
# removed the account somebody uses to administer the site would be a far worse
# defect than the one it closes.
#
# WARN, because the vocabulary is closed (OK/WARN/FAIL - SM584) and the other two
# are both wrong: OK says there is nothing to do, and FAIL says the site is
# broken, which it is not. It fires only on sites that predate SM659, so it is
# not noise added to every report - and on the sites where it does fire it is
# exactly the population that has never been told.
sub report_shared_manager_account {
    my $users = "$LZ/auth/users";
    return unless -f $users;

    open my $fh, '<', $users or return;
    my $found = 0;
    while ( my $l = <$fh> ) {
        next if $l =~ /^\s*(?:#|$)/;
        my ($name) = split /:/, $l, 2;
        next unless defined $name;
        $name =~ s/^\s+|\s+$//g;
        $found = 1 if $name eq 'manager';
    }
    close $fh;
    return unless $found;

    report( 'WARN',
        'this site has an account called "manager" - the shared role account '
            . 'the bootstrap created before SM659',
        'it still works and nothing here changes it. If a person is signing in '
            . 'with it, give them their own account (users add NAME, then put '
            . 'them in the same group) and disable this one; a shared login '
            . 'records every action under a name that is not a person'
    );
    return;
}

# SM1284 (ruling 27): A SITE'S OWN PAGE AT A /docs PATH WINS, AND SAYS SO HERE.
#
# The manual is the engine's (lazysite/templates/docs/), refreshed by every
# upgrade. A site that keeps its own page at one of its paths is served that
# page instead - an operator's deliberate override, or an edited copy the
# upgrade that moved the manual kept rather than destroy. Either way the
# engine's newer version is not what visitors and agents read, and nothing else
# would ever say so. A copy byte-identical to the engine's shadows nothing.
#
# n814 (SM1437, test plan 0.16.10 Y5): EVERY DOMAIN'S CONTENT ROOT, not the
# primary's alone. A domain with a content_root of its own (alias.<host>.content_root,
# or the primary's) is served its /docs pages from there, so a stale copy under
# sites/<name>/docs/ shadowed the manual and the check never looked. Each line names
# its domain when the site has more than one (ruling 199).
sub report_shadowed_engine_docs {
    my $engine = "$LZ/templates/docs";
    return unless -d $engine;
    my $site_url  = conf_value( $conf, 'site_url' ) // '';
    my ($primary) = $site_url =~ m{\A\w+://([^/:]+)};
    my @roots     = ( [ $DOC, $primary // 'the primary domain' ] );
    my %seen      = ( $DOC => 1 );
    my @declared;
    if ( open my $fh, '<', "$LZ/lazysite.conf" ) {
        while ( my $l = <$fh> ) {
            next unless $l =~ /^(?:alias\.(\S+)\.)?content_root\h*:\h*(.+?)\h*$/;
            my ( $host, $rel ) = ( $1, $2 );
            $rel                            =~ s{^["']|["']$}{}g;
            $rel                            =~ s{^/+|/+$}{}g;
            next unless length $rel && $rel !~ m{(?:^|/)\.\.(?:/|$)};
            push @declared, [ "$DOC/$rel", $host // $primary // 'the primary domain' ];
        }
        close $fh;
    }
    for my $r (@declared) {
        push @roots, $r if -d $r->[0] && !$seen{ $r->[0] }++;
    }
    for my $r (@roots) {
        my ( $root, $label ) = @{$r};
        my @shadow;
        find_noting( 'the engine-docs shadow check',
            { no_chdir => 1,
                wanted => sub {
                    my $p = $File::Find::name;
                    return unless $p =~ /\.md\z/ && -f $p;
                    ( my $rel = $p ) =~ s{\A\Q$engine\E/}{};
                    my $site = "$root/docs/$rel";
                    return unless -f $site;
                    push @shadow, "docs/$rel" if _slurp_raw($site) ne _slurp_raw($p);
                },
            },
            $engine,
        );
        next unless @shadow;
        @shadow = sort @shadow;
        my @shown = @shadow > 10 ? ( @shadow[ 0 .. 9 ], '...' ) : @shadow;
        report( 'WARN',
            ( @roots > 1 ? "$label: " : '' )
                . scalar(@shadow) . ' site page(s) shadow a newer version of the engine\'s /docs manual - '
                . 'visitors and agents read the site\'s copy: ' . join( ', ', @shown ),
            'keep a page you meant to override; delete one you did not, and the engine\'s current '
                . 'page serves at the same path (SM1284)' );
    }
    return;
}

sub _slurp_raw {
    my ($p) = @_;
    open my $fh, '<:raw', $p or return '';
    local $/;
    my $c = <$fh>;
    close $fh;
    return $c // '';
}

# SM1446 (ruling 206): A BACKUP THAT DID NOT FINISH IS NAMED. The listing no
# longer offers one as a backup (Manager::Backups::_unfinished, the one test of
# "finished", read here through the listing itself); this says it is there, when
# it was started and how to remove it. And a staging directory a killed backup
# left behind, which can hold the archive a tar outliving its request finished.
sub report_unfinished_backups {
    my $dir = "$LZ/backups";
    return unless -d $dir;
    require Lazysite::Manager::Backups;
    my $list = do {
        no warnings 'once';
        local $Lazysite::Manager::Backups::LAZYSITE_DIR = $LZ;
        Lazysite::Manager::Backups::action_backup_list();
    };
    my $when = sub { my @t = gmtime( $_[0] // 0 ); sprintf '%04d-%02d-%02d %02d:%02d UTC', $t[5] + 1900, $t[4] + 1, @t[ 3, 2, 1 ] };
    for my $u ( @{ $list->{unfinished} || [] } ) {
        report( 'WARN',
            "an unfinished backup: lazysite/backups/$u->{name} (dated " . $when->( $u->{mtime} )
                . ", $u->{size} bytes) holds no finished archive; it is not listed or offered as a backup",
            $u->{remedy} );
    }
    my @stages;
    if ( opendir my $dh, $dir ) {
        # SM1446 (ruling 248): a staging directory is named for the process
        # taking the backup; one whose process is alive is a backup in progress.
        @stages = sort grep {
            my ($pid) = /\A\.stage-(\d+)-/;
            /\A\.stage-/ && -d "$dir/$_" && !( $pid && ( kill( 0, $pid ) || $!{EPERM} ) )
        } readdir $dh;
        closedir $dh;
    }
    for my $s (@stages) {
        report( 'WARN',
            "a backup's staging directory is left in lazysite/backups/$s (since "
                . $when->( ( stat "$dir/$s" )[9] ) . '): a backup that was stopped before it finished',
            "if no backup is being taken now, remove it: rm -r lazysite/backups/$s" );
    }
    return;
}

sub report_stale_registries {
    my $d = $opt{docroot};
    return unless -d "$LZ/templates/registries";

    my @names;
    if ( opendir my $dh, "$LZ/templates/registries" ) {
        @names = map { s/\.tt\z//r } grep { /\.tt\z/ } readdir $dh;
        closedir $dh;
    }
    return unless @names;

    my @found = grep { -f "$d/$_" } sort @names;
    return unless @found;

    # SM627: repairable, and the repair is a MOVE.
    #
    # This warning stood on all 26 sites of a fleet after an upgrade and could
    # not be cleared by any repair, so `repair --all` reported every site as
    # needing a human forever. It is determinable - the file must not stay where
    # it is, or it is served stale for good - but the ACTION is not simply
    # "delete", because the engine deliberately yields to a sysop's own
    # sitemap or llms.txt and nothing in the file says which it is: the shipped
    # templates emit no generator marker, so a generated registry and a
    # hand-written one are indistinguishable on disk.
    #
    # So it moves rather than deletes. The stale file stops being served, the
    # engine serves a current one, and if it WAS the operator's it is sitting
    # under lazysite/backups/stale-registries/ with its name and the time it was
    # moved. That is the project's own recoverable-vs-irreversible line (SM587,
    # SM591) applied to a file: this tier is allowed to act because what it does
    # can be undone.
    @stale_registries = map { "$d/$_" } @found;

    report(
        'WARN',
        'these generated files are still in the document root: '
            . join( ', ', @found )
            . ' - the engine now generates them on request and caches them '
            . 'outside the document root, so a file left here is served '
            . 'instead and never refreshed',
        '--fix MOVES them to lazysite/backups/stale-registries/ (it does not '
            . 'delete them): the engine then serves a current one, and if you '
            . 'wrote your own it is recoverable by name from there.'
    );
    return;
}

sub report_engine_tree {
    my $d = $opt{docroot};

    require Lazysite::Paths;
    my $ext    = Lazysite::Paths::external_lazysite_dir($d);
    my $inside = Lazysite::Paths::internal_lazysite_dir($d);

    if ( Lazysite::Paths::stray_lazysite($d) ) {
        report(
            'FAIL',
            'this site has an engine tree in BOTH places - beside the document '
                . 'root AND inside it. The engine reads the one outside, so the '
                . 'site works; the one inside is still where a web server can '
                . 'serve it.',
            'confirm the tree beside the document root is the current one '
                . '(compare lazysite.conf and auth/), then remove the copy '
                . 'inside the document root. This tool will not delete '
                . 'credentials for you.'
        );
        return;
    }

    if ( defined $ext && -d $ext ) {
        report( 'OK',
            'the engine tree is held outside the document root, so no '
                . 'front-end rule is needed to keep config, credentials and '
                . 'snapshots unreachable' );
        return;
    }

    if ( -d $inside ) {
        # Deliberately not a WARN. Both layouts are supported, the deny rules
        # are in every shipped template, and nagging every site on every run
        # teaches the reader to skip the section - which is where the FAIL
        # above lives.
        report( 'OK',
            'the engine tree is inside the document root, kept '
                . 'unreachable by the front end\'s deny rules - supported, and '
                . 'the alternative is to move it beside the document root, '
                . 'after which no such rule is needed' );
    }
    return;
}

# ---------------------------------------------------------------------------
# SM286: content that exists in BOTH trees.
#
# The private store's one invariant is that a path lives in exactly one tree.
# A path in both is always a fault, and always the same fault in the same
# direction: the private copy is the one the engine governs, and the public one
# is reachable without asking the engine at all. That is SM283 restored for a
# single file - the gate holds everywhere the engine is consulted, and the front
# end serves the copy beside it.
#
# It cannot arise from a completed move (move_in renames, and refuses when the
# destination is already occupied rather than overwriting). It arises from a
# move interrupted mid-copy on a cross-device fallback, from a restore of an
# archive written before the content was protected, and from a sysop putting
# a file back by hand - none of which anything else would notice.
#
# FAIL, not WARN. The site is serving content it has been told to protect. And
# reported rather than repaired: which copy to delete is a content decision, and
# a tool that silently removes a sysop's file to fix a permission problem is
# a worse tool than one that tells them.
# SM296: can the engine put protected content where it belongs?
#
# Protecting content moves it to <docroot>-lazysite-private, which the CGI has to
# CREATE the first time - a directory beside the document root, in the domain
# folder. On some layouts that parent is not writable by the CGI identity, and
# then every protect operation warns instead of moving: the rule is stored and
# honoured for pages while the files stay in the document root and go on being
# served. Correct, documented, and completely invisible unless something asks.
#
# It was worse than invisible on 0.10.8, where the same condition crashed the
# call outright (SM296). The crash is fixed; this is the half that tells an
# operator whether their site can protect anything at all BEFORE they try.
#
# FAIL, because a site that cannot move content cannot honour the protection its
# own manager offers - and the operator would otherwise learn that from a warning
# buried in one API response.
# SM309: say whether front-door mode is actually on for this site.
#
# SM294 moved the front door under the FastCGI pool in 0.10.9. Whether it is
# running is decided by FRONT_DOOR= in /etc/lazysite/pools/<instance>.conf, which
# is an operator step - and until now NOTHING reported whether that step had been
# taken. `X-Lazysite-Front` exists only in the SM283 proxy template, so on any
# instance without that template installed - which is the instance the SM283
# sweep is still pending on - the mode was indistinguishable from its absence.
#
# A 0.10.9 field test measured ten anonymous samples before and after the
# upgrade, found no difference network noise could resolve, and had no way to
# establish whether the feature was even active. That is the situation 0.10.7
# added an observable for, after three rebuilds and a template install produced
# byte-identical responses; SM294 is a LARGER behavioural change than that one
# and had less observability.
#
# Read from the pool conf on disk rather than from what an installer intended to
# write, and matched to THIS docroot rather than to the instance name, because
# the instance name is conventionally the domain and nothing enforces that. A
# check that reported the wrong site's setting would be worse than none.
# SM893: IS THIS SITE'S PERSISTENT RUNTIME ARMED, AND DOES IT MATCH INTENT?
#
# The one command an operator runs to ask "is this site healthy?" has never
# mentioned the daemon. So the only place the host half (conf + timer, root)
# and the site half (the `daemon` extension, the sysop) could be seen to disagree
# was the manager's Status button, which nobody presses until something is
# already wrong.
#
# The release manager ruled 2026-09-15 that every site is armed. That makes an
# unarmed site a drift worth reporting - and it makes an ARMED, IDLE site the
# normal resting state, which is the reading an operator most often gets wrong:
# `inactive (dead)` here is correct, because a runtime whose extension is off exits
# 0 on purpose.
#
# FOUR STATES, NOT TWO. Armed/unarmed crossed with wanted/not-wanted, and the
# dangerous cell is WANTED BUT NOT ARMED: the sysop has enabled the extension
# and nothing will ever start it. That one is a FAIL; idle is an OK that says
# so; unarmed-and-unwanted is a WARN against the ruling, not against the site.
sub report_daemon_runtime {
    my $dir = $ENV{LAZYSITE_DAEMON_DIR} || '/etc/lazysite/daemon';

    # No directory at all means this host does not use the systemd flow (a
    # plain tarball install with no units). Nothing to say - the same silence
    # the pool check keeps. UNREADABLE is different from ABSENT and is said.
    return unless -e $dir;
    unless ( -d $dir && -r $dir ) {
        report( 'WARN', "cannot read $dir, so the runtime's state is unknown",
            'Run the check as a user that can read it, or as root.' );
        return;
    }

    opendir my $dh, $dir or do {
        report( 'WARN', "cannot list $dir, so the runtime's state is unknown" );
        return;
    };
    my @confs = sort grep { /\.conf\z/ } readdir $dh;
    closedir $dh;

    # Which conf is THIS site's: the one whose DOCROOT resolves to ours. Same
    # method as the front-door check, and for the same reason - the file is
    # named for a domain and a docroot can be reached by more than one.
    my $want = abs_path( $opt{docroot} ) // $opt{docroot};
    my ( $mine, $instance );
    for my $c (@confs) {
        open my $fh, '<', "$dir/$c" or next;
        my $doc;
        while ( my $l = <$fh> ) {
            $doc = $1 if $l =~ /^\s*DOCROOT\s*=\s*"?([^"\s]+)"?/;
        }
        close $fh;
        next unless defined $doc;
        my $r = abs_path($doc) // $doc;
        next unless $r eq $want;
        $mine     = "$dir/$c";
        $instance = $c;
        $instance =~ s/\.conf\z//;
        last;
    }

    # The site's half: is the daemon extension enabled in this site's conf?
    my $wanted = 0;
    if ( open my $cf, '<', "$opt{docroot}/lazysite/lazysite.conf" ) {
        while ( my $l = <$cf> ) {
            $wanted = 1 if $l =~ m{^\s*-\s*extensions/daemon\.pl\s*$};
        }
        close $cf;
    }

    unless ( defined $mine ) {
        if ($wanted) {
            report( 'FAIL',
                'the daemon extension is enabled and this site has no runtime '
                    . 'config, so the runtime can never start',
                "A host operator runs: lazysite-hestia-domain add <user> <domain> "
                    . "(it writes $dir/<domain>.conf and enables the timer)." );
        }
        else {
            report( 'WARN',
                'this site is not armed for the persistent runtime',
                'Every site is armed as of SM893, so that enabling the daemon '
                    . 'extension is all a sysop has to do. Nothing is broken '
                    . 'today - the extension is off - but enabling it would '
                    . 'not work until a host operator provisions the site.' );
        }
        return;
    }

    # Armed. What systemd makes of it - and where systemd cannot be asked, say
    # that rather than guessing from the file's presence.
    my $systemctl = _have_systemctl();
    unless ($systemctl) {
        report( 'OK',
            "armed for the persistent runtime ($instance)"
                . ( $wanted ? ', and the daemon extension is enabled' : '' ),
            'systemctl is not available here, so whether the timer is enabled '
                . 'and the service running could not be read.' );
        return;
    }

    my $timer_state = `systemctl is-enabled lazysited\@$instance.timer 2>/dev/null`;
    $timer_state //= '';
    $timer_state =~ s/\s+\z//;
    my $running = ( system("systemctl is-active --quiet lazysited\@$instance.service 2>/dev/null") == 0 );

    # NOT-FOUND IS NOT DISABLED, and the remedy is different. `is-enabled`
    # answers `not-found` when the unit TEMPLATE is not installed at all, and
    # `disabled` when it is installed and simply off. Reporting the first as
    # the second sends an operator to run `systemctl enable` on a unit that
    # does not exist - which fails, unhelpfully, and looks like their mistake.
    if ( $timer_state eq 'not-found' ) {
        report( $wanted ? 'FAIL' : 'WARN',
            "this site has a runtime config but the lazysited\@ unit template "
                . 'is not installed on this host'
                . ( $wanted ? ' - the daemon extension is enabled and nothing can start it' : '' ),
            'The units ship with the engine. Install the package (or run the '
                . 'Hestia deploy) on this host; enabling the timer cannot work '
                . 'until the template exists.' );
        return;
    }

    my $timer_on = ( $timer_state eq 'enabled' || $timer_state eq 'enabled-runtime' );

    if ( !$timer_on ) {
        report( $wanted ? 'FAIL' : 'WARN',
            "the runtime config exists but lazysited\@$instance.timer is not enabled"
                . ( $wanted ? ' - the daemon extension is enabled and nothing will start it' : '' ),
            "A host operator runs: systemctl enable --now lazysited\@$instance.timer" );
        return;
    }

    if ($wanted) {
        report( 'OK',
            $running
            ? "the persistent runtime is running ($instance)"
            : "armed and the daemon extension is enabled; the timer starts the "
                . "runtime within five minutes ($instance)" );
        return;
    }

    # The common case, and the one that gets misread.
    report( 'OK',
        "armed and idle ($instance) - the daemon extension is not enabled, so "
            . 'the runtime exits 0 and stays inactive, which is correct' );
    return;
}

# systemctl, or not. Kept separate so the report above reads as four states
# rather than as shell plumbing.
sub _have_systemctl {
    return 0 unless -d '/run/systemd/system';
    for my $p (qw(/usr/bin/systemctl /bin/systemctl)) { return 1 if -x $p }
    return 0;
}

# SM1144: THE POOL CONF THAT IS THIS SITE'S, found once for both readers below.
# /etc/lazysite/pools/<instance>.conf, matched on DOCROOT= (not on the instance
# name, which is only conventionally the domain). LAZYSITE_POOLS_DIR moves the
# directory, as lazysite-hestia-domain's does, so a test can stand in for the
# host. Returns undef when the host has no pool dir or none names this docroot.
sub find_pool_conf {
    my $dir = $ENV{LAZYSITE_POOLS_DIR} || '/etc/lazysite/pools';
    return undef unless -d $dir;

    opendir my $dh, $dir or return undef;
    my @confs = sort grep { /\.conf\z/ } readdir $dh;
    closedir $dh;

    my $want = abs_path( $opt{docroot} ) // $opt{docroot};
    for my $c (@confs) {
        open my $fh, '<', "$dir/$c" or next;
        my %v;
        while ( my $l = <$fh> ) {
            $v{docroot}    = $1 if $l =~ /^\s*DOCROOT\s*=\s*"?([^"\s]+)"?/;
            $v{front_door} = $1 if $l =~ /^\s*FRONT_DOOR\s*=\s*"?([^"\s]*)"?/;
            $v{workers}    = $1 if $l =~ /^\s*WORKERS\s*=\s*"?([^"\s]*)"?/;
            $v{socket}     = $1 if $l =~ /^\s*SOCKET\s*=\s*"?([^"\s]+)"?/;
            $v{cgibin}     = $1 if $l =~ /^\s*CGIBIN\s*=\s*"?([^"\s]+)"?/;    # ruling 203
        }
        close $fh;
        next unless defined $v{docroot};
        my $r = abs_path( $v{docroot} ) // $v{docroot};
        next unless $r eq $want;
        ( my $inst = $c ) =~ s/\.conf\z//;
        return { %v, file => $c, instance => $inst };
    }
    return undef;
}

# SM1144 (SM1082 R5): DOES THIS SITE RUN THE POOL, AND WITH HOW MANY WORKERS?
#
# The persistent-runtime work (SM1082) pays only on sites that run the pool, and
# until now the fleet's pool status could only be had by looking at each host.
# One line, always, in a fixed shape a deploy report can grep:
#
#   pool: yes, N worker(s)   ... the host has a pool conf for this docroot
#   pool: no (plain CGI)     ... it has none
#
# WORKERS= defaults to 2 in the launcher (tools/lazysite-pool.pl), so a conf that
# does not set it is reported as that default. The socket is looked at because a
# conf with no socket is a pool that is configured and not running, which is a
# WARN rather than a count of workers nobody is serving from. Not a FAIL: a
# stopped pool still serves, through plain CGI, only slower.
sub report_pool_status {
    my $p = find_pool_conf();
    unless ($p) {
        return report( 'OK', 'pool: no (plain CGI)',
            'Every request starts its own process. A pool answers an anonymous '
                . 'cached page in about a millisecond against about 65 ms; see '
                . 'docs/architecture/performance.md.' );
    }
    my $w = ( defined $p->{workers} && $p->{workers} =~ /\A\d+\z/ && $p->{workers} > 0 ) ? $p->{workers} + 0 : 2;
    my $sock = length( $p->{socket} // '' ) ? $p->{socket} : "/run/lazysite/$p->{instance}.sock";
    my $ws = "$w worker" . ( $w == 1 ? '' : 's' );
    return report( 'OK', "pool: yes, $ws ($p->{file})" ) if -S $sock;
    return report( 'WARN', "pool: configured, $ws ($p->{file}), but its socket $sock is not there",
        'The pool is not running, so this site is served by plain CGI until it is '
            . "started: systemctl start lazysite\@$p->{instance}." );
}

# Ruling 203: THE POOL RUNS THIS SITE'S OWN ENGINE - the processor in the cgi-bin
# its pool conf names (CGIBIN=, else the docroot's sibling, as the launcher
# resolves it) and the lib beside the docroot. When any of the three is missing
# the pool answers every request 503 and never runs the package's engine instead
# (ruling 206: refuse, and name the remedy). Silent with no pool conf: plain CGI
# runs the cgi-bin copy, and the cgi-bin check above covers that.
sub report_pool_engine {
    my $p = find_pool_conf();
    return unless $p;
    require File::Basename;
    my $up  = File::Basename::dirname( abs_path( $opt{docroot} ) // $opt{docroot} );
    my $cgi = length( $p->{cgibin} // '' ) ? $p->{cgibin} : "$up/cgi-bin";
    my @missing;
    push @missing, "$cgi/lazysite-processor.pl" unless -f "$cgi/lazysite-processor.pl";
    push @missing, "$cgi/lazysite-processor/"   unless -d "$cgi/lazysite-processor";
    push @missing, "$up/lib/"                   unless -d "$up/lib/Lazysite";
    return report( 'OK', "pool engine: the site's own ($cgi)" ) unless @missing;
    return report( 'FAIL', "pool engine: the site's own engine is missing: " . join( ', ', @missing ),
        "The pool ($p->{file}) answers every request 503 until it is repaired; it never "
            . "runs the package's engine for a site. Lay the engine again with lazysite "
            . "reinstall --docroot $opt{docroot} (or upgrade, if the site is behind), then "
            . "systemctl restart lazysite\@$p->{instance}." );
}

sub report_front_door_mode {
    my $p = find_pool_conf();
    return unless $p;    # no pools configured: plain CGI, nothing to say
    my ( $mine, $raw ) = ( $p->{file}, $p->{front_door} );

    # A site with no pool conf runs plain CGI, where front-door mode does not
    # apply at all. Silence is right - a check that speaks on every healthy site
    # is one people learn to scroll past.
    return unless defined $mine;

    my $v = defined $raw ? lc $raw : '';
    $v =~ s/\A\s+|\s+\z//g;

    if ( $v =~ /\A(?:1|true|yes|on)\z/ ) {
        report( 'OK', "front-door mode is ON (FRONT_DOOR=$raw in $mine)",
            'The pool worker routes every request itself, so the vhost needs '
                . 'one rule rather than a dozen.' );
    }
    elsif ( $v eq '' || $v =~ /\A(?:0|false|no|off)\z/ ) {
        report( 'OK',
            'front-door mode is OFF'
                . ( length $v ? " (FRONT_DOOR=$raw in $mine)" : " (not set in $mine)" ),
            'Set FRONT_DOOR=1 in the pool conf and restart the pool to enable '
                . 'it. Off is the default, so an existing pool behaves exactly '
                . 'as it did.' );
    }
    else {
        # The pool now refuses to start on this (SM309), so a site in this state
        # has a stopped pool - which the sysop will meet as an outage with no
        # obvious cause unless something names the line.
        report( 'FAIL', "FRONT_DOOR=$raw in $mine is not a yes/no value",
            'The pool refuses to start rather than guess, so this site is not '
                . 'serving through its pool. Use 1, true, yes or on to switch '
                . 'front-door mode on; 0, false, no or off to switch it off.' );
    }
}

# SM315: an active theme whose assets never reached the mirror is a site that is
# rendering unstyled RIGHT NOW.
#
# Theme assets live at layouts/<layout>/themes/<theme>/assets/ and are mirrored
# to /lazysite-assets/<layout>/<theme>/ at activation. Put them one level higher
# and everything succeeds - upload, activation, every page - and the stylesheet
# link is never emitted, because `theme_assets` resolves to nothing. At the HTTP
# level the result is indistinguishable from a working site: 200, valid markup,
# correct content, browser default serif.
#
# SM315 makes activation say so at the moment it happens. This is the standing
# version, for a site that was already in that state, or that got there by some
# other route - a partial deploy, a mirror cleared by hand, an asset directory
# that vanished. The activation warning cannot help those.
sub report_theme_assets_mirrored {
    # SM550: conf_value is ($file, $key). Called with the key alone it opened a
    # file named `layout`, so this check returned before looking - and had
    # never run since SM315 shipped it.
    my $layout = conf_value( $conf, 'layout' );
    my $theme  = conf_value( $conf, 'theme' );
    return unless defined $layout && length $layout;
    return unless defined $theme  && length $theme;

    my $tdir = "$LZ/layouts/$layout/themes/$theme";
    return unless -d $tdir;    # not a layout-and-theme site; nothing to say

    my $mirror = "$DOC/lazysite-assets/$layout/$theme";
    my $n      = 0;
    find_noting( 'the theme-asset mirror check',
        { no_chdir => 1, wanted => sub { $n++ if -f $File::Find::name } },
        $mirror ) if -d $mirror;

    return report_ok_read( 'the theme-asset mirror check', "theme assets are mirrored ($n file(s) for $layout/$theme)" )
        if $n;

    # Nothing mirrored. Name the likely cause rather than the symptom: an author
    # who put the CSS beside theme.json has made one specific mistake and needs
    # one specific sentence.
    my @misplaced;
    if ( opendir my $dh, $tdir ) {
        @misplaced = sort grep { /\.(?:css|js|woff2?|ttf|png|jpe?g|svg|webp)\z/i }
            readdir $dh;
        closedir $dh;
    }

    report(
        'FAIL',
        "the active theme $layout/$theme has no mirrored assets"
            . ( @misplaced
            ? ' - but ' . join( ', ', @misplaced ) . " sit directly in $tdir"
            : '' ),
        ( @misplaced
            ? "move them into $tdir/assets/ and re-activate the layout. "
            : "if this theme has a stylesheet it belongs in $tdir/assets/. " )
            . 'Until then every page renders with no stylesheet and still '
            . 'returns 200, so nothing else will report it.'
    );
    return;
}

# SM1142: THE OLD NAME IS READ BY NOTHING, SO THIS IS WHERE IT IS NAMED.
#
# The upgrade converts a site's list and moves its directory (install.pl,
# extensions-rename) and from then on the readers know `extensions:` and
# `extensions/<file>.pl` only (R3). A list or an entry an operator writes back
# under the old spelling afterwards reads as OFF everywhere, and silently - the
# login rate limiter among what it switches off - so each such line is named
# here with the line to write instead, and so is an old directory left beside
# the docroot, whose files nothing runs.
#
# SM1361 (ruling 210): ON A SHARED ENGINE, ONLY THE ENGINE'S OWN EXTENSIONS RUN.
# Every entry in the site's extensions dir beside the docroot is refused by the
# loader (Lazysite::Extensions::refused_site_files); named here with its remedy.
# A warning, not a failure: the site serves, and what it is told is that this
# file does nothing in this container.
sub report_refused_site_extensions {
    require Lazysite::Extensions;
    my $eng = Lazysite::Extensions::shared_engine();
    return unless defined $eng;
    my @refused = Lazysite::Extensions::refused_site_files( File::Basename::dirname($DOC) );
    report( 'WARN',
        "a site extension is refused on this shared engine: $_ - only the engine's own extensions run here",
        'remove it; a site that needs its own extension moves to a dedicated service '
            . '(Hestia, or a container of its own)' )
        for @refused;
    report( 'OK', 'shared engine: only its own extensions run, and the site holds none' ) unless @refused;
    return;
}

# old-name: begin (SM1142, the check names the spelling it finds)
sub report_extensions_list {
    my $old = 'plugins';
    my @found;
    if ( open my $fh, '<', "$LZ/lazysite.conf" ) {
        my ( $n, $in ) = ( 0, 0 );
        while ( my $l = <$fh> ) {
            $n++;
            chomp $l;
            if ( $l =~ /^(extensions|\Q$old\E)\s*:\s*$/ ) {
                $in = 1;
                push @found, [ $n, "`$old:` - write `extensions:`" ] if $1 eq $old;
                next;
            }
            if ( $in && $l =~ /^\s+-\s+\Q$old\E\/(\S+)\s*$/ ) {
                push @found, [ $n, "`- $old/$1` - write `- extensions/$1`" ];
                next;
            }
            $in = 0 if $in && $l !~ /^\s/;
        }
        close $fh;
    }
    for my $f (@found) {
        report( 'WARN',
            "lazysite.conf line $f->[0] uses the old name: $f->[1]. Nothing reads it, so "
                . 'the extensions it lists are off',
            "edit $LZ/lazysite.conf line $f->[0] (SM1142)" );
    }
    my $dir = "$DOC/../$old";
    if ( -d $dir ) {
        report( 'WARN',
            "$dir is still beside the docroot - nothing runs the files in it",
            'move what you need into the extensions/ beside it and remove it (SM1142)' );
        push @found, 1;
    }
    report( 'OK', 'the enabled extensions are listed under extensions:' ) unless @found;
    return;
}
# old-name: end

# SM1369 X2: THE EXTENSION INDEX (lazysite/extensions.index.json), read as the
# engine reads it - the file, never --describe. Three questions: did the last
# build fail (the note the build leaves beside the index, so "the previous one
# stands" is said here and not only in the event log); does an enabled
# extension that declares hooks have its entry (an index built before it was
# enabled by hand, or whose build failed, runs none of its actions); and which
# capabilities the index declares, which the manager-group walk above reads.
# The index and its failure note, by the names Lazysite::Extensions::Hooks gives
# them ($INDEX_FILE, $INDEX_FAILED), in the site's lazysite/ tree. Subs, not
# file-scope variables: this file's main program runs and exits above them.
sub _hook_index_file        { return 'extensions.index.json' }
sub _hook_index_failed_file { return 'extensions.index.failed' }

sub _read_hook_index {
    my $p = "$LZ/" . _hook_index_file();
    return undef unless -f $p;
    open my $fh, '<:raw', $p or return undef;
    my $raw = do { local $/; <$fh> };
    close $fh;
    my $idx = eval { JSON::PP->new->utf8->decode($raw) };
    return ref $idx eq 'HASH' ? $idx : undef;
}

sub declared_capabilities {
    my $idx = _read_hook_index() or return ();
    my $d   = ref $idx->{declared} eq 'HASH' ? $idx->{declared} : {};
    my %c;
    for my $id ( sort keys %$d ) {
        my $e = $d->{$id};
        next unless ref $e eq 'HASH' && ref $e->{capabilities} eq 'ARRAY';
        $c{$_} = 1 for grep { defined && !ref && /\A[a-z][a-z0-9_]*\z/ } @{ $e->{capabilities} };
    }
    my @caps = sort keys %c;
    return @caps;
}

sub report_hook_index {
    my $failed = "$LZ/" . _hook_index_failed_file();
    if ( -f $failed ) {
        my $why = '';
        if ( open my $fh, '<', $failed ) { $why = <$fh> // ''; close $fh; chomp $why }
        report( 'WARN',
            "the extension index was not rebuilt by the last build, and the previous one stands"
                . ( length $why ? " ($why)" : '' ),
            'enable or save an extension in the manager, or run the upgrade again, to rebuild it' );
    }
    my $idx = _read_hook_index();
    my %on;
    if ( open my $fh, '<:utf8', "$LZ/lazysite.conf" ) {
        my $in = 0;
        while ( my $l = <$fh> ) {
            chomp $l;
            if ( $l =~ /^extensions\s*:\s*$/ ) { $in = 1; next }
            if ( $in && $l =~ /^\s+-\s+(.+?)\s*$/ ) { $on{$1} = 1; next }
            $in = 0 if $in && $l !~ /^\s/;
        }
        close $fh;
    }
    my $declared = $idx && ref $idx->{declared} eq 'HASH'   ? $idx->{declared}   : {};
    my $hooks    = $idx && ref $idx->{extensions} eq 'HASH' ? $idx->{extensions} : {};
    my @missing;
    for my $id ( sort keys %$declared ) {
        my $key = ref $declared->{$id} eq 'HASH' ? $declared->{$id}{key} : undef;
        next unless defined $key && $on{$key};
        push @missing, $id unless $hooks->{$id};
    }
    if (@missing) {
        report( 'WARN',
            'enabled extensions whose declarations are indexed and whose hooks are not: ' . join( ', ', @missing )
                . ' - their actions answer "cannot run now" until the index is rebuilt',
            'enable or save the extension in the manager (or run the upgrade again), which rebuilds the index' );
    }
    elsif ($idx) {
        my $n = scalar keys %$declared;
        report( 'OK', "the extension index is built ($n " . ( $n == 1 ? 'extension declares' : 'extensions declare' )
                . ' capabilities or actions' . ( keys %$hooks ? ', ' . scalar( keys %$hooks ) . ' with hooks indexed' : '' ) . ')' );
    }
    return;
}

# Ruling 206 (SM1417, the 0.16.9 fault survey, items 9-21): A STORE THAT EXISTS
# AND CANNOT BE TOLD IS A FAULT THE ENGINE REFUSES ON, so this is where it is
# named with its repair. One table, one reader per shape:
#   db      opens as a DB_File database (read-only, so a root run changes nothing)
#   jsonl   every non-blank line decodes as a JSON object
#   json    the file decodes as a JSON object; `objects` also needs every value
#           to be an object (the scheduler's run record)
#   read    the file opens (a notice template)
# An absent store is a site with nothing recorded yet, and says nothing here.
# Each line says what the engine does about it, in the words of its log.
sub _store_fault_table {
    return (
        [ 'manager/.upload-rate.db', 'db', 'every upload is refused',
            "remove '%s' (it holds only this hour's upload counts and is made again at the next upload)" ],
        [ 'db/data.sqlite', 'sqlite', 'a data migration, rebuild or import that cannot query it is refused',
            "restore '%s' from a backup" ],
        [ 'notify/suppressed.jsonl', 'jsonl', 'no notification is sent (the queue is kept)',
            "repair the named line of '%s' - it records who unsubscribed, so do not remove the file" ],
        [ 'notify/ledger.jsonl', 'jsonl', 'no notification is sent (the queue is kept)',
            "repair or remove the named line of '%s' (a removed line may let that notice go again)" ],
        [ 'notify/status.json', 'json', "each rule's last-run status is not recorded",
            "remove '%s' (a convenience the next run writes again)" ],
        [ 'forms/submitter-mail.jsonl', 'jsonl', "every form's acknowledgement to the submitter is refused by its cap",
            "repair or remove the named line of '%s'" ],
        [ 'logs/notice-mail.jsonl', 'jsonl', 'every notice mail is refused by its cap',
            "repair or remove the named line of '%s'" ],
        [ 'connectors/calls.jsonl', 'jsonl', 'every capped connector call is refused and the sweep does nothing',
            "repair or remove the named line of '%s'" ],
        [ 'daemon/scheduler-runs.json', 'objects', 'no scheduled job runs',
            "remove '%s' (every job then runs once at the next tick)" ],
        [ 'daemon/*.state.json', 'json', 'the daemon supervisor starts no service',
            "make sure no copy of the service runs, then remove '%s' and restart the host service" ],
        [ '.install-state.json', 'json', 'the installed version reads as unknown',
            "run the upgrade again, which rewrites '%s'" ],
        [ 'notify-templates/*.tt', 'read', "the built-in notice wording is used instead of the site's",
            "make '%s' readable by the site user" ],
    );
}

# Why the file cannot be told, or undef (absent, or fine).
sub _store_shape_fault {
    my ( $f, $shape ) = @_;
    if ( $shape eq 'sqlite' ) {
        return undef unless -e $f;
        return undef unless eval { require DBI; require DBD::SQLite; 1 }; # the data checks say so
        my $ok = eval {
            my $dbh = DBI->connect( "dbi:SQLite:dbname=$f", '', '',
                { RaiseError => 1, PrintError => 0, sqlite_open_flags => DBD::SQLite::OPEN_READONLY() } );
            my ($r) = $dbh->selectrow_array('PRAGMA quick_check');
            $dbh->disconnect;
            ( $r // '' ) eq 'ok';
        };
        return $ok ? undef : 'does not pass SQLite\'s quick_check';
    }
    if ( $shape eq 'db' ) {
        return undef                                         unless -e $f;
        return 'cannot be checked: DB_File is not installed' unless eval { require DB_File; 1 };
        my %t;
        my $tied = eval { require Fcntl; tie %t, 'DB_File', $f, Fcntl::O_RDONLY(), 0 };
        return 'does not open as a DB_File database' unless $tied;
        undef $tied;    # an untie while this still holds the object warns on STDERR
        untie %t;
        return undef;
    }
    open my $fh, '<:raw', $f or return $!{ENOENT} ? undef : "cannot be read ($!)";
    return undef if $shape eq 'read';
    if ( $shape eq 'jsonl' ) {
        my $n = 0;
        while ( my $l = <$fh> ) {
            $n++;
            next unless $l =~ /\S/;
            my $r = eval { JSON::PP::decode_json($l) };
            return "holds a line that is not a record (line $n)" unless ref $r eq 'HASH';
        }
        return undef;
    }
    local $/;
    my $d = eval { JSON::PP::decode_json( <$fh> // '' ) };
    return 'does not decode as a JSON object' unless ref $d eq 'HASH';
    if ( $shape eq 'objects' ) {
        my @bad = grep { ref $d->{$_} ne 'HASH' } sort keys %$d;
        return 'has entries that are not job records (' . join( ', ', @bad ) . ')' if @bad;
    }
    return undef;
}

sub report_store_faults {
    my $bad = 0;
    for my $c ( _store_fault_table() ) {
        my ( $rel, $shape, $means, $repair ) = @$c;
        for my $f ( $rel =~ /\*/ ? sort( glob("$LZ/$rel") ) : ("$LZ/$rel") ) {
            my $why = _store_shape_fault( $f, $shape ) // next;
            ( my $show = $f ) =~ s{\A\Q$LZ\E/}{lazysite/};
            report( 'FAIL', "$show $why, so $means", sprintf( $repair, $f ) );
            $bad++;
        }
    }
    report( 'OK', 'the send records, counters and run records this site has can all be read' ) unless $bad;
    return;
}

# SM798: IS THE LOGIN RATE LIMITER COUNTING? Ruling 206: without DB_File, or
# with a counter the sign-in CGI cannot open, every sign-in is REFUSED (it used
# to be allowed), so this is a FAIL naming the fault and the repair. Switched
# off on purpose is the operator's choice and stays a WARN: NOT in force.
sub report_login_rate_limit {
    # Switched off is the first answer (SM798's ruling: an extension, on by
    # default). Said in the same words, so a limiter an operator turned off and
    # a limiter that broke both read as NOT in force, each with its reason.
    {
        require Lazysite::Manager::Extensions;
        no warnings 'once';
        local $Lazysite::Manager::Extensions::DOCROOT = $opt{docroot};
        unless ( Lazysite::Manager::Extensions::extension_enabled('extensions/login-rate-limit.pl') ) {
            report( 'WARN',
                'the login rate limiter is NOT in force: the login rate limit extension is '
                    . 'switched off, so sign-in attempts are not counted and every one is allowed',
                'switch it on in the manager\'s extensions list (extensions/login-rate-limit.pl), '
                    . 'unless this site is meant to run without it' );
            return;
        }
    }
    unless ( eval { require DB_File; 1 } ) {
        report( 'FAIL',
            'the login rate limiter cannot count: DB_File is not installed, so every '
                . 'sign-in is refused',
            'install DB_File (Debian: libdb-file-perl)' );
        return;
    }
    my $db = "$LZ/auth/.login-rate.db";
    if ( my @s = stat $db ) {
        unless ( cgi_can( 4, @s ) && cgi_can( 2, @s ) ) {
            report( 'FAIL',
                sprintf( 'the login rate limiter cannot count: its counter %s (%04o, %s:%s) '
                        . 'cannot be opened by the CGI (%s), so every sign-in is refused',
                    $db, $s[2] & 07777, owner_name($db), group_name($db), $exp_grp ),
                sprintf( "chown %s:%s '%s' && chmod 0660 '%s'", $exp_user, $exp_grp, $db, $db ) );
            push @chmod_fixes, [ 0660, $db, 'add' ];
            $chown_needed = 1;
            return;
        }

        # Ruling 206: the modes can be right and the file still not a counter.
        # Opened read-only, so a check run as root changes nothing about it.
        my %t;
        my $tied = eval {
            require Fcntl;
            tie %t, 'DB_File', $db, Fcntl::O_RDONLY(), 0;
        };
        if ($tied) {
            undef $tied;    # an untie while this still holds the object warns on STDERR
            untie %t;
        }
        else {
            report( 'FAIL',
                "the login rate limiter cannot count: its counter $db does not open as a "
                    . 'DB_File database, so every sign-in is refused',
                "remove '$db' (it holds only recent attempt counts and is made again at the "
                    . 'next sign-in)' );
            return;
        }
    }
    report( 'OK', 'the login rate limiter is in force (per address; its counter is '
            . ( -e $db ? 'usable' : 'created at the first sign-in' ) . ')' );
    return;
}

# SM1369 X6, H-6 (ruling 55): WHAT AN EXTENSION CHECKS OF ITSELF.
#
# An enabled extension declares its checks (`hooks.checks`, functions in its
# payload lib); each is called through the hook loader with the docroot and the
# lazysite directory and answers [ { level, text, fix } ], printed here with
# report() like any of this tool's own findings. A check that cannot run, or
# dies, is a WARN naming the extension and never ends the run; a finding that
# is not one (another level, no text) is a WARN too, so nothing an extension
# says is lost or invents a level the summary does not count. An extension
# that is installed and off, and declares checks, is one line: installed, off.
sub report_extension_checks {
    require Lazysite::Extensions::Hooks;
    my $idx      = Lazysite::Extensions::Hooks::read_index($LZ);
    my $on       = Lazysite::Extensions::Hooks::enabled_keys($LZ);
    my $declared = ref $idx->{declared} eq 'HASH' ? $idx->{declared} : {};
    my %ran;
    for my $id ( sort keys %{ $idx->{extensions} || {} } ) {
        my $e = $idx->{extensions}{$id};
        next unless ref $e eq 'HASH' && ref $e->{hooks} eq 'HASH' && ref $e->{hooks}{checks} eq 'ARRAY';
        next unless $on->{ $e->{key} // '' };
        $ran{$id} = 1;
        my $name = ( ref $declared->{$id} eq 'HASH' ? $declared->{$id}{name} : undef ) // $id;
        for my $fn ( @{ $e->{hooks}{checks} } ) {
            my ( $ok, $rows ) = Lazysite::Extensions::Hooks::call_hook( $DOC, $id, $fn, $DOC, $LZ );
            unless ($ok) {
                report( 'WARN', "the $name extension's check did not run ($fn): " . ( $rows // 'no reason given' ),
                    'see the site log; the other checks ran' );
                next;
            }
            for my $f ( ref $rows eq 'ARRAY' ? @$rows : () ) {
                my $level = ref $f eq 'HASH' && defined $f->{level} && !ref $f->{level} ? $f->{level} : '';
                unless ( $level =~ /\A(?:OK|WARN|FAIL)\z/ && defined $f->{text} && !ref $f->{text} && length $f->{text} ) {
                    report( 'WARN', "the $name extension's check ($fn) answered a finding that is not one "
                            . '(a level of OK, WARN or FAIL, and its text)' );
                    next;
                }
                report( $level, $f->{text}, defined $f->{fix} && !ref $f->{fix} && length $f->{fix} ? $f->{fix} : undef );
            }
        }
    }
    for my $id ( sort keys %$declared ) {
        my $d = $declared->{$id};
        next unless ref $d eq 'HASH' && $d->{checks} && !$ran{$id};
        next if $on->{ $d->{key} // '' }; # on, and refused or not indexed: report_hook_index says so
        report( 'OK', 'the ' . ( $d->{name} // $id ) . ' extension is installed, off - its checks run while it is on' );
    }
    return;
}


sub report_private_store_usable {
    my $d = $opt{docroot};

    require Lazysite::Private;
    my $store = Lazysite::Private::private_root($d) or return;

    # Only when the site actually protects something, or already has a store.
    #
    # A site that has never gated a path does not need the store and will never
    # try to create it, so demanding a writable parent everywhere would fail
    # every ordinary layout for a facility it is not using. That is the same
    # reasoning that made SM223 safe to ship - no ACL store, no change - and the
    # same reason this section stays quiet rather than nagging: a check that
    # cries on healthy sites is a check people learn to scroll past.
    my $gating = 0;
    if ( open my $afh, '<:raw', "$LZ/auth/acls.json" ) {
        my $raw = do { local $/; <$afh> };
        close $afh;
        my $map = eval { JSON::PP::decode_json( $raw // '{}' ) };
        if ( ref $map eq 'HASH' ) {
            for my $k ( keys %$map ) {
                my $e = $map->{$k};
                next unless ref $e eq 'HASH';
                next if $k =~ m{\A[/.]*\z};    # the site-wide rule moves nothing
                next
                    unless $e->{draft}
                    || ( ref $e->{read} eq 'ARRAY' && @{ $e->{read} } );
                $gating = 1;
                last;
            }
        }
    }
    unless ( $gating || -e $store ) {
        # SM1237: BUT A ROOT --fix CREATES IT WHERE THE ENGINE CANNOT. Quiet, as
        # above - nothing is reported - and only as root, so nobody is nagged.
        #
        # On Hestia the store's parent is the domain folder, mode 0551, so
        # neither the CGI nor the site user can create it. A site that never
        # protected anything therefore has no store, and the first protect of
        # anything fails with the content left public: the manager's, MCP's,
        # and the outside-in probe's own (it protects a throwaway folder as the
        # site user). Measured: the probe answers "ACL PROBE SKIPPED: the engine
        # refused to protect the probe folder" on every such site, so a fleet
        # run reports it "could not run" for a site that has nothing wrong with
        # it. The deploy and `lazysite repair` run --fix as root; creating the
        # store there, empty and in the shape SM313 gives it, is what lets the
        # probe run on the next pass.
        if ( $> == 0 ) {
            ( my $parent = $store ) =~ s{/[^/]+\z}{};
            my @pst = stat $parent;
            $store_create_needed = $store
                if @pst && !( cgi_can( 2, @pst ) && cgi_can( 1, @pst ) );
        }
        return;
    }

    if ( -d $store ) {
        # It exists. The question is then whether the CGI can write INTO it.
        my @st = stat $store;
        if ( cgi_can( 2, @st ) && cgi_can( 1, @st ) ) {
            report( 'OK',
                'the private store exists and the engine can write to it' );
        }
        else {
            # SM323: REPAIR it, do not merely name it.
            #
            # SM313 taught --fix to CREATE a missing store and stopped there, so
            # a store that exists and is unusable was reported on every run and
            # repaired by nothing. That is the state edge reached: the sysop
            # sweep runs as the SITE USER and creates the store through
            # Private::_mkpath, which sets no ownership and no mode - so the
            # store ends up owned by the site user with a umask default, and the
            # CGI identity cannot write into it.
            #
            # The consequence is that protecting content became an OPERATOR-ONLY
            # operation: `acl reapply` works, and the manager UI, MCP and the
            # control API all return a warning with the content still served, on
            # a product whose partner surfaces are supposed to do exactly this.
            #
            # Whichever creator runs first decides. That is the argument for
            # declaring the store in runtime_paths (SM321) so there is ONE
            # description of what it should be - this repairs a store that
            # already exists in the wrong shape, which the declaration alone
            # cannot do.
            $store_repair_needed = $store;
            report(
                'FAIL',
                'the private store exists but the engine cannot write to it '
                    . sprintf( '(%s, owner %s:%s, mode %04o)',
                    $store, owner_name($store), group_name($store),
                    mode_of($store) ),
                'protecting content stores the rule and leaves the files in the '
                    . 'document root, so the manager UI, MCP and the control API '
                    . 'cannot protect anything - only the operator sweep can. '
                    . 'Run with --fix as root to repair the ownership and mode.'
            );
        }
        return;
    }

    if ( -e $store ) {
        report( 'FAIL',
            "something that is not a directory is at $store",
            'the engine cannot create the private store while that exists; move '
                . 'it aside.' );
        return;
    }

    # It does not exist yet, so the question is whether it CAN be created.
    my $parent = $store;
    $parent =~ s{/[^/]+\z}{};
    my @pst = stat $parent;
    unless (@pst) {
        report( 'FAIL', "the private store's parent does not exist: $parent" );
        return;
    }
    if ( cgi_can( 2, @pst ) && cgi_can( 1, @pst ) ) {
        report( 'OK',
            'the private store does not exist yet and the engine can create '
                . 'it when content is first protected' );
        return;
    }
    # SM313: --fix CREATES the store rather than widening its parent.
    #
    # SM270's repair covers the DOCROOT. The store is a SIBLING of the docroot,
    # so creating it needs write access on the docroot's PARENT - a different
    # directory, which that repair never touched. Confirmed in the field on
    # 2026-08-15: after a complete and successful docroot repair, protecting a
    # folder still left 11 of 11 entries public and 8 of 10 probed extensions
    # serving 200 anonymously under an active read rule.
    #
    # THE OBVIOUS REPAIR IS THE WRONG ONE. Making the parent group-writable is
    # "the same operation one directory up", and on the Hestia layout that parent
    # is the domain folder - which also holds cgi-bin. Write permission on a
    # directory is permission to create, delete and RENAME its entries, so that
    # would let anything running as the CGI group replace cgi-bin. Repairing an
    # exposure by opening a larger one is not a repair.
    #
    # Creating the store instead is strictly narrower and it removes the need for
    # the permission entirely: the engine never has to create the directory, only
    # write into one it already owns. `_mkpath` becomes a no-op on the next
    # protect. setgid (2770) so content moved in keeps the group, matching how
    # every other lazysite-owned directory is provisioned.
    $store_create_needed = $store;
    report(
        'FAIL',
        'the private store does not exist and the engine cannot create it - '
            . sprintf( '%s is owner %s:%s mode %04o',
            $parent, owner_name($parent), group_name($parent), mode_of($parent) ),
        'until the store exists, protecting content stores the rule and leaves '
            . 'the files in the document root, where a front end serves them - '
            . 'this is SM283 reached through the mechanism built to prevent it. '
            . 'Run with --fix as root to create it. Note that repairing the '
            . 'DOCROOT does not fix this: the store is its sibling, not its '
            . 'child.'
    );
    return;
}

sub report_stray_public {
    my $d = $opt{docroot};

    require Lazysite::Private;
    my $root = Lazysite::Private::private_root($d);
    return unless defined $root && -d $root;

    # SM1389: the protected folders' history repository (SM1324,
    # <store>/lazysite/git) is the engine's, never moved content, and its HEAD,
    # config, refs and identical objects share relative paths with the docroot's
    # content-history repository at lazysite/git. Walking it reported those as
    # public copies of protected files, and the site as not serviceable. Its path
    # is ProtectedHistory's own helper, so the two cannot drift.
    #
    # THE REPOSITORY ONLY, not the whole <store>/lazysite/: a rule on a path
    # under lazysite/layouts (which the file surfaces write) moves it into the
    # store there (measured, tmp/n764-layout-move-probe.pl), so a copy left
    # beside such a layout is still a stray copy and is still reported.
    require Lazysite::ProtectedHistory;
    my $history = Lazysite::ProtectedHistory::history_git_dir($root);

    my @stray;
    find_noting( 'the protected-content check',
        { no_chdir => 1,
            wanted => sub {
                my $p = $File::Find::name;
                if ( -d $p && !-l $p && $p eq $history ) { $File::Find::prune = 1; return }
                return if -l $p || !-f $p;
                my $rel = substr $p, length($root) + 1;
                push @stray, $rel if -e "$d/$rel";
            },
        },
        $root
    );

    unless (@stray) {
        report_ok_read( 'the protected-content check',
            'protected content is held outside the document root, with no '
                . 'public copy left beside it' );
        return;
    }

    # Cap the listing, but never the COUNT - a truncated list that does not say
    # it was truncated reads as the whole problem.
    my $n     = scalar @stray;
    my @shown = @stray[ 0 .. ( $n > 10 ? 9 : $n - 1 ) ];
    report(
        'FAIL',
        "$n protected "
            . ( $n == 1 ? 'file is' : 'files are' )
            . ' ALSO present in the document root, where the front end serves '
            . 'them without asking the engine: '
            . join( ', ', @shown )
            . ( $n > 10 ? sprintf( ' (and %d more)', $n - 10 ) : '' ),
        'the copy in the document root is the exposure. Confirm the copy in '
            . 'the private store is the current one, then remove the public '
            . 'copy - this tool will not delete content for you.'
    );
    return;
}

# SM1304 (ruling 42): A SYMBOLIC LINK IN THE SERVED ASSET MIRROR IS A FINDING.
#
# Before 0.16.2 the manager's theme upload extracted a zip's symbolic link and
# copied it into /lazysite-assets/ as a link (SM1303), so a public URL there
# named any file the web server can read - lazysite/auth/.secret, the
# session-signing secret, among them. The upload refuses one now; a link it
# planted before stays (a backup restore puts it back, too), and an upgrade
# does not look. Nothing lazysite installs under lazysite-assets/ is a link, so
# every one is named, with its target.
#
# WARNED, NEVER REMOVED: the link may be the operator's own, and removing it
# does not undo what it served - the secret it may have exposed is rotated by
# hand. The message carries the remedy itself, because a deploy report keeps
# the finding line and drops its hint.
sub report_asset_links {
    my $assets = "$DOC/lazysite-assets";
    return unless -e $assets || -l $assets;

    my @links;
    if ( -l $assets ) { push @links, $assets }
    else {
        find_noting( 'the asset-mirror link check',
            { no_chdir => 1, wanted => sub { push @links, $File::Find::name if -l $File::Find::name } },
            $assets );
    }

    unless (@links) {
        report_ok_read( 'the asset-mirror link check', 'no symbolic link in the served asset mirror (lazysite-assets/)' );
        return;
    }

    my $secret = "$LZ/auth/.secret";
    for my $l ( sort @links ) {
        my $target = readlink($l) // '(unreadable)';
        ( my $rel = $l ) =~ s{^\Q$DOC/\E}{};
        report( 'WARN',
            "SYMBOLIC LINK in the served asset mirror: $rel -> $target. Anything it points "
                . "at is public at /$rel. Remove it, and rotate $secret",
            "nothing lazysite installs is a link there; before 0.16.2 a theme upload could "
                . "plant one (SM1303). Remove it (rm '$l'), then rotate the session-signing "
                . "secret: the manager's Sessions page, \"Log out all users\" (rotate-auth-secret), "
                . 'writes a new one and signs every session out. This check never deletes it.' );
    }
    return;
}

END { _acl_probe_cleanup() if defined $PROBE_DIR || defined $PROBE_KEY }

sub _acl_probe_marker { join '', map { sprintf '%02x', int rand 256 } 1 .. 16 }

# SM551: the engine tree may sit beside the docroot (SM293); resolve it the
# way run_checks does rather than assuming it is inside.
sub _acls_file { my ($d) = @_; return Lazysite::Paths::lazysite_dir($d) . '/auth/acls.json' }

# Read the ACL store as raw text -> hash. Deliberately not via
# Lazysite::Auth::Acl: this tool is core-Perl only and runs where the library
# may not be installed.
sub _acl_read {
    my ($d) = @_;
    my $f = _acls_file($d);
    return {} unless -f $f;
    return _read_json($f) || {};
}

sub _acl_write {
    my ( $d, $map ) = @_;
    my $f   = _acls_file($d);
    my $tmp = "$f.probe.$$";
    open my $fh, '>', $tmp or return 0;
    print {$fh} JSON::PP->new->canonical->pretty->encode($map);
    close $fh;
    chmod 0640, $tmp;
    return rename $tmp, $f;
}

# Remove the probe's file tree and its ACL entry. RE-READS the store rather than
# restoring a copy taken earlier, so a rule the sysop added while the probe
# was running is not silently reverted.
sub _acl_probe_cleanup {
    if ( defined $PROBE_KEY ) {
        my $d = $opt{docroot};

        # SM377: unprotect through the ENGINE, so the content it moved comes
        # back and the private store is not left holding a probe folder nobody
        # can see. Deleting the acls.json key alone would orphan it - the
        # inverse of the defect this probe had, and just as quiet.
        my $removed = 0;
        if ( defined $Lazysite::Manager::Files::DOCROOT ) {
            $removed = _probe_unprotect( $d, $PROBE_KEY );
        }
        unless ($removed) {
            my $map = _acl_read($d);
            if ( delete $map->{$PROBE_KEY} ) { _acl_write( $d, $map ) }
        }

        # Whatever route was taken, the private copies are this probe's litter
        # and are removed by path rather than by trusting the move back.
        if ( eval { require Lazysite::Private; 1 } ) {
            my $priv = Lazysite::Private::private_path( $d, $PROBE_KEY );
            if ( defined $priv && -d $priv ) {
                if ( opendir my $ph, $priv ) {
                    for my $e ( readdir $ph ) {
                        next if $e eq '.' || $e eq '..';
                        unlink "$priv/$e";
                    }
                    closedir $ph;
                }
                rmdir $priv;
            }
        }
        undef $PROBE_KEY;
    }
    if ( defined $PROBE_DIR ) {
        if ( -d $PROBE_DIR ) {
            opendir my $dh, $PROBE_DIR or return;
            for my $e ( readdir $dh ) {
                next if $e eq '.' || $e eq '..';
                unlink "$PROBE_DIR/$e";
            }
            closedir $dh;
            rmdir $PROBE_DIR;
        }
        # The public controls sit BESIDE the folder, not inside it, so they need
        # removing separately - they are ordinary readable files and leaving one
        # behind would be litter in the operator's docroot.
        unlink glob("$PROBE_DIR-open.*");
        undef $PROBE_DIR;
    }
    return;
}

# Sweep anything a previous interrupted run left behind, so the tool self-heals
# rather than accumulating gated directories nobody knows about.
sub _acl_probe_sweep {
    my ($d)     = @_;
    my $map     = _acl_read($d);
    my $changed = 0;
    for my $k ( keys %$map ) {
        next unless $k =~ m{\Alazysite-acl-probe-};
        delete $map->{$k};
        $changed = 1;
    }
    _acl_write( $d, $map ) if $changed;

    opendir my $dh, $d or return;
    my @stale = grep { /\Alazysite-acl-probe-/ } readdir $dh;
    closedir $dh;
    for my $s (@stale) {
        if ( -d "$d/$s" ) {
            opendir my $sd, "$d/$s" or next;
            for my $e ( readdir $sd ) {
                next if $e eq '.' || $e eq '..';
                unlink "$d/$s/$e";
            }
            closedir $sd;
            rmdir "$d/$s";
        }
        else { unlink "$d/$s" }    # a stray public control
    }
    report( 'OK', 'cleared a probe left by an interrupted earlier run' )
        if $changed || @stale;
    return;
}

# Read a JSON file into a hash. undef when the file cannot be opened or does
# not decode to an object - the callers each decide what that means for them,
# which is why this does not substitute a default of its own.
sub _read_json {
    my ($path) = @_;
    open my $fh, '<', $path or return undef;
    my $raw = do { local $/; <$fh> };
    close $fh;
    my $d = eval { JSON::PP::decode_json( $raw // '{}' ) };
    return ref $d eq 'HASH' ? $d : undef;
}

# SM1023: the same read, with the three failures told apart, for a store whose
# absence and unreadability mean different things to a security verdict.
# Returns ( $hash, 'ok' ), ( undef, 'absent' ), ( undef, 'unreadable', $! ) or
# ( undef, 'undecodable' ). The open decides - no stat in front of it (SM770).
sub _read_json_state {
    my ($path) = @_;
    my ( $state, $err ) = _open_state($path);
    return ( undef, $state, $err ) unless $state eq 'ok';
    open my $fh, '<:raw', $path or return ( undef, 'unreadable', "$!" );
    my $raw = do { local $/; <$fh> };
    close $fh;
    my $d = eval { JSON::PP::decode_json( length( $raw // '' ) ? $raw : '{}' ) };
    return ref $d eq 'HASH' ? ( $d, 'ok' ) : ( undef, 'undecodable' );
}

# ( 'ok' ), ( 'absent' ) or ( 'unreadable', $! ) for a file this run opens.
sub _open_state {
    my ($path) = @_;
    open my $fh, '<', $path or return $!{ENOENT} ? ('absent') : ( 'unreadable', "$!" );
    close $fh;
    return ('ok');
}

# The account this run reads as, for a finding about what it could not read.
sub _running_as { return scalar( getpwuid($>) ) // "uid $>" }

# n825 (SM1447): the remedy for a check that could not read lazysite/auth/: the user
# that owns the store FILES (not the directory), named, or each owner where they differ.
sub _run_as_remedy {
    my (@paths) = @_;
    require Lazysite::Util;
    my $what = @paths ? "what it could not read" : "the store files";
    my ( $u, $differ ) = @paths
        ? Lazysite::Util::store_run_as( "", @paths )
        : Lazysite::Util::store_run_as( Lazysite::Paths::lazysite_dir( $opt{docroot} ) . "/auth",
        qw(acls.json address-profiles.json address-lists.json.converted) );
    return "run the check as $u, who owns $what (sudo -u $u " . cli_spelling() . " check ...), or as root"
        . ( length $differ ? ". $differ" : "" );
}

# One anonymous GET. Returns (status, body). Cache directives on purpose: a
# cached 200 from an intermediary must not be mistaken for the origin serving
# the file, and neither must it hide a leak.
sub _probe_get { return _curl( '-sS', $_[0], qr/\n(\d{3})\z/ ) }

# The one curl invocation both probes make. $mode is the only difference in the
# command line, and $tail the only difference in how the status code is peeled
# off the end of the output.
sub _curl {
    my ( $mode, $url, $tail ) = @_;
    my @cmd = (
        'curl', $mode,                     '-k', '--max-time', '8',
        '-H',   'Cache-Control: no-cache', '-H', 'Pragma: no-cache',
        '-w',   "\n%{http_code}",          $url,
    );
    open my $ph, '-|', @cmd or return ( '', '' );
    my $out = do { local $/; <$ph> };
    close $ph;
    return ( '', '' ) unless defined $out;
    my $code = '';
    if ( $out =~ s/$tail// ) { $code = $1 }
    return ( $code, $out );
}

# SM319: every path that returns WITHOUT FETCHING says "ACL PROBE SKIPPED".
#
# The token is a designated marker, not incidental prose. A caller has to be able
# to tell "the front end honoured the rule" from "nothing was measured", and the
# deploy's caller is a shell script reading this output - so the distinction has
# to survive someone improving the wording. t/tools/41 pins the token on both
# sides for exactly that reason.
#
# This matters because absence-of-FAIL was read as a pass one layer up, which is
# the defect THIS PROBE ITSELF shipped with: SM285's first implementation had an
# empty extension list, made zero fetches, and reported the front end as
# respecting the ACL against a port with nothing listening.
# SM377: APPLY PROTECTION THE WAY THE ENGINE DOES, OR MEASURE NOTHING.
#
# _acl_write stores acls.json and nothing else. The engine protects content by
# MOVING it into the private store, so a probe that only writes the rule leaves
# its own files in the document root - where a front end serving statics by
# extension serves them CORRECTLY, because nothing ever protected them. The
# probe then read that as the site's protected content being reachable, and
# reported FAIL in the same run where the check above reported "protected
# content is held outside the document root". Two checks, one tool, one run.
#
# content_moved is the assertion that makes this honest. It is a structural flag
# (SM313) rather than a match on warning text, so it cannot be improved away: if
# it is absent or zero, this probe has not established the condition it is about
# to measure, and it says so instead of measuring.
sub _probe_load_engine {
    my ($d) = @_;
    return 'this build cannot load the engine modules'
        unless eval {
        require Lazysite::Manager::Files;
        require Lazysite::Manager::Common;
        require Lazysite::Auth::Acl;
        require Lazysite::Auth::Settings;    # SM912 P1: to name a real principal
        require Lazysite::Paths;
        1;
        };

    my $root = $d;
    $root =~ s{/+\z}{};

    # `no warnings 'once'` because these package globals are SET here and read
    # inside the engine modules, so this file mentions each exactly once - which
    # is indistinguishable from a typo to perl and printed as one on every run.
    no warnings 'once';    ## no critic (ProhibitNoWarnings)
    $Lazysite::Manager::Files::DOCROOT = $root;
    $Lazysite::Manager::Files::LOCK_DIR
        = Lazysite::Paths::lazysite_dir($root) . '/cache/locks';
    $Lazysite::Manager::Common::DOCROOT = $root;
    $Lazysite::Auth::Acl::DOCROOT       = $root;
    $Lazysite::Auth::Acl::token_auth    = 0;
    return '';
}

# Protecting MOVES content, creating directories in the private store as it
# goes. SM139: lazysite never writes into a site tree as root, because
# root-owned files there are exactly what stops the manager working afterwards
# (the Class-B drift SM215 repairs). So as root this probe declines to establish
# the state rather than establishing it badly.
sub _probe_may_protect {
    return 'running as root - protecting content here would leave root-owned '
        . 'files in the site tree (SM139); run the probe as the site user'
        if $> == 0 || $ENV{LAZYSITE_CLI_FAKE_ROOT};
    return '';
}

# SM912 P1: THE PROBE NEEDS A READ LIST THE STORE KNOWS.
#
# It used to name `__lazysite-acl-probe-nobody__`, a sentinel chosen precisely
# because nobody has it: the probe then fetches the file anonymously, and any 200
# is the exposure it exists to find. SM901 (0.15.0) then began refusing a read
# list where every name is unknown to the store - correctly, for a rule somebody
# is authoring - and the sentinel is exactly that shape. So from 0.15.0 the probe
# could not establish its own precondition on any site that has accounts, which
# is every real site, and the fleet run reported SKIPPED.
#
# The probe does not actually need "nobody". It needs "NOT THE ANONYMOUS
# VISITOR", because the measurement is an anonymous fetch. So it names the first
# account the store knows, and keeps the sentinel for the one case SM901 exempts:
# a store that knows nobody at all, where the old behaviour was already correct
# and the check does nothing. Read access to a throwaway folder for one account,
# for the seconds before the probe removes it, buys back the whole measurement.
# A SUB, NOT A FILE-SCOPE ASSIGNMENT, and the suite spent an hour teaching me
# why: this script runs its main flow at the TOP and defines its subs below, so
# `our $PROBE_NOBODY = '...'` down here is an assignment that has not happened
# yet when run_acl_probe executes. The read list became the empty string, the
# rule stored and moved nothing, and ten assertions failed for a name that was
# never wrong - only unset. A sub has no order to get wrong.
sub _probe_nobody { return '__lazysite-acl-probe-nobody__' }

sub _probe_principal {
    my $known = eval {
        # `no warnings 'once'` for the same reason _probe_load_engine carries it:
        # this file mentions the engine's package global exactly once, which perl
        # cannot tell from a typo - and it PRINTS the guess, into the probe's own
        # output, where the integration test reads it as the probe's answer. One
        # warning failed ten assertions that had nothing wrong with them.
        no warnings 'once';    ## no critic (ProhibitNoWarnings)
        local $Lazysite::Auth::Settings::AUTH_DIR = Lazysite::Auth::Acl::settings_dir();
        Lazysite::Auth::Settings::account_names();
    };
    # A NON-EMPTY HASH IS NOT THE SAME AS A STORE THAT NAMES SOMEBODY, and the
    # suite caught this within the hour: a fixture whose users file is absent or
    # blank yields one key - the EMPTY STRING - so the first version of this
    # picked '' as the read list. The rule then stored and moved nothing, which is
    # neither the old behaviour nor the new one, and ten assertions in
    # t/integration/43 failed for it. Only a name that could be a login counts.
    my @named = grep { defined && /\A[^\s:]+\z/ } keys %{ ref $known eq 'HASH' ? $known : {} };
    my $who = @named ? ( sort @named )[0] : _probe_nobody();
    print {*STDERR} "acl-probe: read list names '$who'\n"
        if $ENV{LAZYSITE_ACL_PROBE_DEBUG};
    return $who;
}

sub _probe_protect {
    my ( $d, $name ) = @_;
    my $who = _probe_principal();
    my $r   = eval {
        local $Lazysite::Manager::Files::auth_user = 'local';
        local $Lazysite::Auth::Acl::auth_user      = 'local';
        local @Lazysite::Auth::Acl::user_groups    = ();
        Lazysite::Manager::Files::action_acl_set( "/$name/", 'local',
            [$who], undef, undef, undef );
    };
    return ( 0, "the engine refused to protect the probe folder: $@" )
        if !$r || $@;

    # SM1237: A HALF-APPLIED RULE SAYS WHY. Its error is the generic "IS IN FORCE
    # ... see the warnings", and the warnings - which name the cause, such as a
    # private store that does not exist and cannot be created - were never
    # printed, so the reason a fleet run carried was a pointer to text it did
    # not have. The cause is the warning's, cut to its first sentence.
    if ( ( $r->{kind} // '' ) eq 'partial' ) {
        for my $w ( @{ $r->{warnings} || [] } ) {
            next unless $w =~ /could[ ]not[ ]be[ ]moved[ ](?:out[ ]of|back[ ]into)[ ]the[ ]document[ ]root:[ ](.+?)\.(?:[ ]|\z)/sx;
            return ( 0, "the probe folder could not be moved into the private store: $1" );
        }
    }
    return ( 0, "the engine refused to protect the probe folder: "
            . ( $r->{error} // 'no reason given' ) )
        unless $r->{ok};

    # THE ASSERTION. A rule stored with nothing moved is the exact state that
    # produced the wrong answer for five months of this probe's life.
    return ( 0, 'the rule was stored but no content moved out of the document '
            . 'root, so nothing here was ever protected' )
        unless $r->{content_moved};
    return ( 1, '' );
}

sub _probe_unprotect {
    my ( $d, $name ) = @_;
    return eval {
        local $Lazysite::Manager::Files::auth_user = 'local';
        local $Lazysite::Auth::Acl::auth_user      = 'local';
        local @Lazysite::Auth::Acl::user_groups    = ();
        Lazysite::Manager::Files::action_acl_remove( "/$name/", 'local' );
        1;
    } ? 1 : 0;
}

# SM377 FOLLOW-UP: detect a bypassing front end WITHOUT any protected content.
#
# Fixing SM377 cost the probe this. It now protects the way the engine does,
# which MOVES content out of the document root - so a front end answering
# statics on its own has nothing left to serve and looks identical to one
# routing correctly. The detection was lost precisely because the probe got
# honest.
#
# THE ENGINE'S OWN HEADERS ANSWER IT DIRECTLY. Since SM352 every response the
# engine writes carries the security header set, so their ABSENCE on a static is
# the signature of something else having answered it. No ACL, no fixture files,
# no credentials, nothing to clean up - two GETs.
#
# THE PAGE REQUEST IS LOAD-BEARING and is the first thing a later reader will
# delete as redundant. Without it, "no headers on a static" is ambiguous between
# a bypassing front end and an engine setting no headers anywhere. The page
# establishes that this instance does set them, so the static's silence means
# something. Same shape as the pre-protection fetch in the gating fixture: the
# step that exists to create the confusable case looks like waste until it is
# gone.
#
# NOT HSTS, AND NOT CSP, though a field measurement used HSTS. HSTS is emitted
# only over TLS and CSP only on HTML, so either would report a bypass on a
# plain-HTTP instance or against any static at all. The unconditional markers
# are the ones to compare.
#
# WHAT THIS DOES NOT SAY, stated because the last probe's inference is what went
# wrong: it does NOT mean content is exposed. Protected content has left the
# served tree (SM286), so a front end answering statics is answering public
# files, correctly. This is the PRECONDITION for SM283-shaped exposure, and a
# fact about ROUTING rather than about access control.
sub report_engine_sees_statics {
    my ($url) = @_;
    return unless defined $url && $url =~ m{^https?://\S+$};
    $url =~ s{/+$}{};

    my @markers = ( 'x-content-type-options', 'permissions-policy' );

    my ( $pcode, $phead ) = _probe_head("$url/");
    unless ( ( $pcode // '' ) =~ /^[23]/ ) {
        report( 'WARN', 'ROUTING CHECK SKIPPED: the site root did not answer' );
        return;
    }
    my $page_has = scalar grep { $phead =~ /^\Q$_\E:/mi } @markers;

    unless ( $page_has == @markers ) {
        # The engine is not setting them anywhere, so a static's silence would
        # mean nothing. A different fault, and not this check's to diagnose.
        report( 'WARN',
            'ROUTING CHECK SKIPPED: the engine is not setting its response '
                . 'headers on a page either, so a static cannot be compared '
                . 'against it - check the installed release first' );
        return;
    }

    my $asset = _probe_static_url($url);
    unless ( defined $asset ) {
        report( 'WARN',
            'ROUTING CHECK SKIPPED: no static asset found to compare against' );
        return;
    }

    my ( $scode, $shead ) = _probe_head($asset);
    unless ( ( $scode // '' ) =~ /^2/ ) {
        report( 'WARN',
            'ROUTING CHECK SKIPPED: the static asset did not answer' );
        return;
    }
    my $static_has = scalar grep { $shead =~ /^\Q$_\E:/mi } @markers;

    if ($static_has) {
        report( 'OK',
            'the engine answers static requests: a page and a static asset '
                . 'both carry its response headers, so nothing is intercepting '
                . 'statics ahead of it' );
        return;
    }

    # A fact about ROUTING. Deliberately says nothing about access control:
    # protected content has left the served tree, so what this front end is
    # answering is public files, correctly.
    report( 'WARN',
        'static requests are answered WITHOUT the engine: a page carries the '
            . 'engine response headers and a static asset carries none, so '
            . 'something in front is serving statics directly',
        'not an exposure on its own - protected content has been moved out of '
            . 'the served tree, so what is being served is public. It is the '
            . 'precondition for the SM283 family, and it means engine security '
            . 'headers, ACL decisions and cache behaviour do not apply to '
            . 'statics. The lazysite-proxy template routes them back.' );
    return;
}

# A HEAD request, returning ( status, headers ). Separate from _probe_get
# because this compares HEADERS and has no interest in bodies - and a HEAD
# cannot be answered from a body cache in a way that hides the difference.
sub _probe_head { return _curl( '-sSI', $_[0], qr/\n(\d{3})\s*\z/ ) }

# A static asset this site actually serves, found from the docroot rather than
# guessed - a guessed path that 404s would be indistinguishable from a bypass.
sub _probe_static_url {
    my ($url) = @_;
    my $d = $opt{docroot};
    for my $dir ( "$d/lazysite-assets", "$d/assets", $d ) {
        next unless -d $dir;
        my @found;
        _collect_statics( $dir, \@found, 0 );
        next unless @found;
        my $rel = $found[0];
        $rel =~ s{\A\Q$d\E/}{};
        return "$url/$rel";
    }
    return undef;
}

sub _collect_statics {
    my ( $dir, $out, $depth ) = @_;
    return if @$out || $depth > 3;
    opendir my $dh, $dir or return;
    my @entries = sort grep { $_ ne '.' && $_ ne '..' } readdir $dh;
    closedir $dh;
    for my $e (@entries) {
        my $p = "$dir/$e";
        next if $e eq 'lazysite';    # the engine tree is never served
        if    ( -d $p ) { _collect_statics( $p, $out, $depth + 1 ) }
        elsif ( $e =~ /\.(?:css|js|png|jpg|jpeg|gif|svg|webp)\z/i ) {
            push @$out, $p;
        }
        return if @$out;
    }
    return;
}

sub run_acl_probe {
    my ($url) = @_;
    $url =~ s{/+$}{};
    if ( $url !~ m{^https?://\S+$} ) {
        report( 'WARN', 'ACL PROBE SKIPPED: --check-acl needs an http(s):// URL' );
        return;
    }
    my $d = $opt{docroot};

    # SM1023: the probe adds and removes its own rule by rewriting acls.json. A
    # store this run cannot read or decode would be rewritten from an empty map,
    # losing every rule in it, so the probe does not start from one.
    my ( undef, $acl_state ) = _read_json_state( _acls_file($d) );
    if ( $acl_state eq 'unreadable' || $acl_state eq 'undecodable' ) {
        report( 'WARN',
            'ACL PROBE SKIPPED: acls.json '
                . ( $acl_state eq 'unreadable'
                ? 'cannot be read as ' . _running_as()
                : 'does not decode as a JSON object' )
                . ' - the probe rewrites that store and will not replace rules it could not read' );
        return;
    }

    _acl_probe_sweep($d);

    my $marker = _acl_probe_marker();
    my $name   = "lazysite-acl-probe-$marker";
    $PROBE_DIR = "$d/$name";
    unless ( mkdir $PROBE_DIR ) {
        undef $PROBE_DIR;
        report( 'WARN',
            'ACL PROBE SKIPPED: cannot create a probe directory in the docroot '
                . '- this reports nothing either way about the front end' );
        return;
    }
    my @exts = _probe_exts();
    unless (@exts) {
        _acl_probe_cleanup();
        report( 'FAIL', 'the ACL probe has no file types to test - this is a bug '
                . 'in lazysite-check, and a probe that tests nothing must never '
                . 'report a pass' );
        return;
    }
    for my $ext (@exts) {
        open my $fh, '>', "$PROBE_DIR/probe.$ext" or next;
        print {$fh} $marker;
        close $fh;
        # The CONTROL for this extension: same bytes, same type, OUTSIDE the
        # gated folder. Without it, "refused" and "nothing here works" are the
        # same observation - a 403 because the front end cannot read the file,
        # or a site that is simply down, would read as healthy gating.
        open my $cf, '>', "$PROBE_DIR-open.$ext" or next;
        print {$cf} $marker;
        close $cf;
    }

    # SM331: FETCH THEM WHILE PUBLIC FIRST.
    #
    # This probe created its folder, gated it, and fetched it - so its files were
    # never requested while public, which is precisely the case that works. The
    # field found the case that does not: on a site protected AFTER the fact,
    # which is the whole SM283 remediation story, a file fetched while public
    # kept serving after the move, while untouched files in the same folder
    # gated. The engine had moved everything and reported it moved; something
    # downstream was still answering for the ones that had been asked for.
    #
    # A probe that cannot generate the failing case reports a healthy site while
    # that case leaks - which is SM283's own shape, where a one-extension probe
    # passed a leaking site. So the folder is warmed before it is gated, and the
    # comparison below then covers both populations at once.
    #
    # Cheap: one extra request per extension, on a probe that already makes two.
    for my $ext (@exts) {
        _probe_get("$url/$name/probe.$ext");
    }

    # Gate the folder against a principal that cannot exist. An EMPTY read list
    # would not restrict anything - "no list for this mode" means allowed, which
    # is the documented behaviour and would make this probe pass vacuously.
    $PROBE_KEY = $name;
    for my $reason ( _probe_may_protect(), _probe_load_engine($d) ) {
        next unless length $reason;
        _acl_probe_cleanup();
        report( 'WARN', "ACL PROBE SKIPPED: $reason" );
        return;
    }
    my ( $protected, $why ) = _probe_protect( $d, $name );
    unless ($protected) {
        _acl_probe_cleanup();
        report( 'WARN', "ACL PROBE SKIPPED: $why" );
        return;
    }

    my ( @leaked, @gated, @blind );
    for my $ext (@exts) {
        my ( $code,  $body )  = _probe_get("$url/$name/probe.$ext");
        my ( $ccode, $cbody ) = _probe_get("$url/$name-open.$ext");
        my $served_gated  = defined $body  && index( $body,  $marker ) >= 0;
        my $served_public = defined $cbody && index( $cbody, $marker ) >= 0;

        print {*STDERR} "acl-probe: .$ext gated=$code public=$ccode\n"
            if $ENV{LAZYSITE_ACL_PROBE_DEBUG};

        if    ($served_gated) { push @leaked, $ext }
        elsif ( !$served_public ) {
            # The control did not come back either, so the refusal proves
            # nothing about the ACL.
            push @blind, ".$ext(gated $code / control $ccode)";
        }
        else { push @gated, $ext }
    }

    # SM368: WHICH CAUSE? Asked, rather than inferred.
    #
    # A split - some extensions served, others refused - has two candidates that
    # look identical from here:
    #
    #   SM283  the front end serves a static list by EXTENSION, straight off
    #          the docroot, without consulting the engine. A sysop task.
    #   SM331  the front end still holds a descriptor for a file it fetched
    #          while the folder was public. Clears itself. Nobody's task.
    #
    # This probe reported the first, in the same sentence and the same voice as
    # the measurement, and it was wrong in the field: the finding was carried up
    # as a fleet condition needing a human and relayed onward as one, twice,
    # before anyone re-ran the experiment.
    #
    # THE DISCRIMINATOR IS ONE REQUEST. A file written AFTER the gate and never
    # fetched cannot be in any front-end cache. If it serves, the split is by
    # extension and SM283 is the answer. If it gates, the extensions that served
    # were warmed by the SM331 pass above and are cache residue.
    #
    # Only run when there IS a leak to explain, so a healthy site pays nothing.
    # SM377: THE NEVER-FETCHED FILE GOES WHERE PROTECTED CONTENT LIVES.
    #
    # The folder has left the document root by now, so writing this file to
    # $PROBE_DIR would put an UNPROTECTED file back into the docroot and it
    # would be served for the same reason the old probe's files were - which is
    # the flaw this whole change is about, reappearing one step further along.
    # It goes into the private store instead, which is where the engine just
    # moved everything else.
    my $late_verdict = '';
    if (@leaked) {
        my $late_ext = $leaked[0];
        require Lazysite::Private;
        my $late_priv = Lazysite::Private::private_path( $d, "$name/late.$late_ext" );
        my $late_ok   = 0;
        if ( defined $late_priv ) {
            my $dir = $late_priv;
            $dir =~ s{/[^/]+\z}{};
            require File::Path;
            eval { File::Path::make_path($dir); 1 };
            if ( open my $lf, '>', $late_priv ) {
                print {$lf} $marker;
                close $lf;
                $late_ok = 1;
            }
        }
        if ($late_ok) {
            my ( undef, $lbody ) = _probe_get("$url/$name/late.$late_ext");
            $late_verdict
                = ( defined $lbody && index( $lbody, $marker ) >= 0 )
                ? 'extension'
                : 'cache';
        }
    }

    _acl_probe_cleanup();

    # The verdicts. Note what is NOT said: never the filesystem path, and never
    # the name of a real file - the sysop is told which EXTENSIONS leaked,
    # because that is what identifies the layer at fault.
    if (@leaked) {
        my $l = join ', ', map { ".$_" } @leaked;
        my $g = @gated ? join( ', ', map { ".$_" } @gated ) : '';
        # SM368: the CACHE verdict is not a failure of the site's gating. The
        # engine moved the content and the front end is still answering from a
        # descriptor it already held; it clears itself, and telling an operator
        # to change a template would send them after nothing.
        # SM377: THE VERDICT IS READ FROM THE PAIR, NEVER FROM ONE FILE.
        #
        # Reading the never-fetched file alone can only ever yield a binary, and
        # the distinction that matters is not two points on one scale - it is two
        # different questions:
        #
        #   warmed served / never GATED    residue. Bounded, self-clearing, and
        #                                  nobody's task (SM331)
        #   warmed served / never SERVED   a genuine bypass. Protected content
        #                                  is being served. A sysop's task
        #   neither served                 gated, nothing to report
        #
        # Those have opposite consequences, and the old probe collapsed them.
        if ( $late_verdict eq 'cache' ) {
            report( 'WARN',
                "a file the engine refuses is still being served to anonymous "
                    . "visitors: $l served, $g refused - but a file created "
                    . "AFTER the gate and never requested is refused, so this "
                    . "is a front-end cache still holding descriptors for files "
                    . "fetched while the folder was public, not a routing rule",
                'no action: the front end clears these itself. Re-run this '
                    . 'check after its cache window if you want to confirm. '
                    . 'See SM331.' );
        }
        else {
            my $shape
                = !@gated
                ? "$l served - the front end is answering without consulting the engine"
                : $late_verdict eq 'extension'
                ? "$l served, $g refused, AND a file written into the PROTECTED "
                . "store after the gate and never requested is also served - so "
                . "the front end is serving protected content by FILE "
                . "EXTENSION, and this is not cache residue"
                : "$l served, $g refused - which is either a front end serving "
                . "by file extension or a cache still holding files fetched "
                . "while the folder was public. This probe could not write a "
                . "test file to tell them apart";
            report( 'FAIL',
                "a file the engine refuses is served to anonymous visitors: $shape",
                'the request is not reaching lazysite. On Hestia apply the '
                    . 'lazysite-proxy template (or turn that domain\'s proxy off); '
                    . 'elsewhere check that the front end routes to the engine when '
                    . 'lazysite/auth/acls.json exists. See SM283.' );
        }
    }
    elsif ( @gated == @exts ) {
        report( 'OK',
            'protected content is not reachable anonymously: every probed '
                . 'file type ('
                . join( ', ', map { ".$_" } @exts )
                . ') was served when public and refused after protection'
                . ' - note this is a statement about the CONTENT, not about the'
                . ' front end. Protection MOVES the bytes out of the document'
                . ' root, so a front end that never consults the engine passes'
                . ' this by having nothing left to serve' );
    }
    elsif (@gated) {
        report( 'WARN',
            'the ACL probe could not vouch for some file types: '
                . join( ', ', @blind )
                . ' (confirmed gated: ' . join( ', ', map { ".$_" } @gated ) . ')',
            'no bytes leaked, so this is not an exposure - but the public '
                . 'control was not served for those types either, so a refusal '
                . 'there proves nothing' );
    }
    else {
        report( 'WARN',
            'the ACL probe got no usable answer - nothing was served, gated or '
                . 'public (' . join( ', ', @blind ) . ')',
            'no bytes leaked, and nothing is confirmed. Check the URL is this '
                . 'site and reachable from here; curl must be installed' );
    }
    return;
}

__END__

=head1 NAME

lazysite-check - lazysite install health and permissions doctor

=head1 SYNOPSIS

  perl tools/lazysite-check.pl --docroot PATH [--fix] [options]
  perl tools/lazysite-check.pl --dependencies

=head1 DESCRIPTION

Verifies that a lazysite docroot is set up so the (no-suexec, C<www-data>) CGI
can read its configuration and write the things it must write - cache, logs,
locks, secrets - that secrets are not world-exposed, that the CGI can traverse
into the directories it must cross and use the manager layout, and that the
manager is bootstrapped. Each check reports C<OK>, C<WARN> or C<FAIL> with a
remediation hint; the command exits non-zero if any check C<FAIL>s.

Effective-access checks are evaluated as the CGI identity via ownership and
mode arithmetic, never via C<-r>/C<-w>/C<-x> - run as root those answer for
root, which bypasses file permissions and would pass files the CGI cannot use.

With C<--fix> it applies the safe fixes (C<chmod> always; C<chown> only when
run as root) and then re-runs every check, so the printed report reflects the
post-fix state.

The C<--dependencies> mode is a standalone host query - it needs no docroot and
reports the non-core Perl modules lazysite needs (from
F<dist/config/sbom-deps.json>), which are present, and the install line for any
that are missing.

=head1 OPTIONS

=over 4

=item B<--docroot> PATH

The site's F<public_html> (required for the health checks).

=item B<--cgibin> PATH

The C<cgi-bin> directory. Default: F<< <docroot>/../cgi-bin >>.

=item B<--owner> USER

Expected owner. Default: the owner of the docroot.

=item B<--group> GROUP

Expected group. Default: C<www-data> (the CGI's group), else the docroot's group.

=item B<--fix>

Apply the safe fixes (C<chmod> always; C<chown> only when run as root). When
anything was fixed, the checks run again and the report shows the post-fix
state (the C<fixed:> action lines come first).

=item B<--check-dav> URL

Probe C<< URL/dav/ >> unauthenticated; expect 401 (route wired), not 404 (the web
server or proxy is not forwarding F</dav/>).

=item B<--check-acl> URL

Ask whether the B<front end> respects the ACL - the one question this tool
cannot answer from the inside, and the one three incidents turned on
(SM248, SM268 H17, SM283).

It creates a probe folder in the docroot, gates it against a principal that
cannot exist, and fetches it anonymously from C<URL> under several file
extensions. If any bytes come back, the front end is answering without
consulting the engine, and the check B<FAILs>.

B<Several extensions on purpose.> SM283 leaked C<.png>, C<.pdf>, C<.txt> and
C<.bin> and gated C<.dat>, because C<.dat> was the one extension absent from the
front end's static list. A probe testing one extension would have picked C<.dat>
and reported the site healthy. When the answers split by extension, this check
says so - that split is the signature of a front end serving a static list
straight off the docroot.

Each gated file has a B<public control> of the same type outside the gated
folder. If the control is not served either, the refusal proves nothing - a site
that is simply unreachable would otherwise read as correctly gated - and the
check reports that it could not tell rather than passing.

The probe writes a temporary entry to the ACL store and removes both it and its
files afterwards, including after an interrupt, and it clears anything an
earlier interrupted run left behind. It re-reads the store before removing its
entry, so a rule added while it was running is not reverted. No filesystem path
appears in its output; the operator is told which B<extensions> leaked, because
that is what identifies the layer at fault.

Needs C<curl>, and needs the site to be reachable from where the check runs.

=item B<--dependencies>

Report the OS Perl packages lazysite needs (present vs missing) and the install
line for whatever is absent. No docroot required; informational (exits 0).

=item B<--help>

Print the usage summary.

=back

=head1 EXIT STATUS

Non-zero if any health check C<FAIL>s (after C<--fix>, the post-fix state).
The C<--dependencies> query is informational and exits 0.

=head1 SEE ALSO

L<lazysite-users.pl(1)>, L<install.pl(1)>. See also F<docs/OPERATOR.md> and
F<docs/reference/host-dependencies.md>.

=cut
