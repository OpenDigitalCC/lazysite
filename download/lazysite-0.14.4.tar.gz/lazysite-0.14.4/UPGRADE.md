# Upgrade notes

## How to upgrade — the one way, for every release below

This does not change per release, so it is stated once, here. Install the newer
lazysite on the host, then move each site to it:

```bash
lazysite upgrade --docroot /path/to/public_html          # one site
sudo lazysite upgrade --all                              # every registered site
```

`--dry-run` on the single-site form reports the plan and writes nothing.
From an unpacked tarball, before any package is installed, the same verb works
out of the tree: `perl tools/lazysite-cli.pl upgrade --docroot ...`.

**You say which operation you mean.** Nothing infers it from the state of the
disk, and each verb refuses rather than quietly doing one of the others:

| Verb | For | Refuses |
| --- | --- | --- |
| `provision` | a site that does not exist yet | a docroot that already has one |
| `upgrade` | moving an installed site to this version | nothing installed, or already at this version |
| `reinstall` | re-laying THIS version's files over a site that has them, leaving content, accounts and config alone | a version mismatch — that is an upgrade |

Not `reinstall` but `repair` when the files are right and the ownership, modes
or missing directories are not: `repair` touches no files.

Backups are written before every upgrade and reinstall:

```bash
lazysite backups --docroot /path/to/public_html            # list
lazysite backups --docroot /path/to/public_html --restore  # most recent back
```

`install.sh` installs nothing. It is kept as a signpost to the verbs above,
because the documentation named it for years and deleting it would strand
anyone still typing it.

**After an upgrade, restart anything holding engine code.** A plain CGI site
reads the engine fresh per request and needs nothing. A site on the persistent
runtime or the FastCGI pool has the previous engine in memory; the single-site
verbs name the units, and `upgrade --all` (root) restarts them itself.

Sections below are per-release notes, newest first. Where an older section says
`install.sh`, read it as a record of what that release did.

## Upgrading to 0.13.13 from 0.13.12

**This release breaks how form delivery is written, and converts it for you.**
It is the change the 0.13.x line was built towards: a form calls a named
**handler**, the timer calls handlers too, and there is one way to say where
data goes (SM842).

What the upgrade converts, once, by running `lazysite-handlers.pl convert`
from the newly installed tree (it prints what it changed):

- **`webhook` and `api` handlers** become **connectors** - with the webhook's URL
  and body format, public invocation, and no rate cap, as the webhook had - and
  the handler becomes a `connector` handler naming it.
- **`db` handlers** become `table` handlers with `keep_copy: false`.
- **Inline targets in a form's config** (`- type: file`, `- type: webhook`)
  become named handlers, reusing one that already delivers to the same place.
  An inline target in a form that ALSO names a handler never delivered - the old
  reader ignored it - so it is dropped, not woken up.
- **A connector's own schedule** (`schedule_every`, `schedule_payload`) becomes an
  entry in the new `lazysite/forms/schedule.conf`, calling a connector handler.

What it cannot convert, and says so in the upgrade summary: a **webhook to a
plain `http://` URL on another host** - a connector sends over https, or http to
this host only. That handler delivers nothing until its URL is changed and the
conversion is run again (`lazysite-handlers.pl convert --docroot <docroot>`, as
the site user). `lazysite check` reports any shape the conversion left.

What changes for people and agents:

- Handlers are configured on the new **Handlers** page (System), not in the Form
  Handler's section of Extension Config; the submissions viewer stays there.
- **Who may make a handler depends on where it sends**: a table handler needs
  Data (`manage_data`), a connector handler needs Connectors
  (`manage_connectors`), email and file handlers need Forms (`manage_forms`).
  Binding a form to an existing handler needs Forms alone. Handler actions are
  now available to token clients too.
- MCP's `list_form_handlers` is **`list_handlers`**; `bind_form` takes a handler
  (or `handlers`) and no inline `target`. A form config written over WebDAV whose
  targets are not existing handlers is refused with 422.
- A connector save carrying `schedule_every` or `schedule_payload` is refused by
  name - schedule it on the Handlers page instead.
- The daemon's `connectors-call` job is replaced by `schedule-run`. Its job
  account needs the capability of each scheduled handler's destination.

**Three settings that were kept alive for one release are gone** (pre-stable:
one way to say each thing). The upgrade converts the configuration and says so:

- `manager_upload_blocked_paths` in `lazysite.conf` is renamed to
  `manager_blocked_paths`, its name since SM019c. Where both were set the old
  line is dropped - the new key already won.
- `db_render_raw` is deleted. `db:` values are always escaped (SM786); a site
  that had it on is warned in the upgrade summary, because a value that carried
  HTML now shows it as text.
- `form-list` (and MCP `form_list`) returns the submission count as `row_count`
  only; the `rows` alias for it is gone. `rows` is the array of submissions in
  `form-submissions`, which is why the count needed another name.

`lazysite check` reports either key if it comes back.

**Control API refusals now carry an HTTP status** (SM670). A client of
`/cgi-bin/lazysite-manager-api.pl` that treated every response as 200 sees 403,
404, 409, 413, 429, 207 or 400 on a refusal - by the refusal's `kind`, listed in
`docs/ai-connector-tools.md` under the error model. The JSON body is unchanged
and still carries `ok: false`, so a client that reads the body, as the manager's
own pages do, is unaffected. A client that stops on a non-2xx status before
reading the body should read it anyway: that is where the reason is.

**`whoami` separates what an account may do from what it is** (SM821), on both
the control API and MCP. `capabilities` now holds only the capability keys, and
`ui` in it means manager access (what `manager_ui` meant - that key is gone).
Everything else moved to a new `account` block: `groups`, `email`,
`display_name`, `created_by`/`created_at`/`managed_by`, token and MFA state,
scopes, and `interactive_login` - the setting that `ui` used to report over the
control API. The control API's `partner` is now `user`, as on MCP. A client that
read `capabilities.ui` as "may sign in", `capabilities.email` or top-level
`groups` reads `account.interactive_login`, `account.email` and `account.groups`.

**Login rate limiting is now an extension, and the upgrade switches it on**
(SM798). `plugins/login-rate-limit.pl` is listed in every site's `plugins:` list
by the first upgrade that carries it, and on every fresh install, so nothing
changes for a site unless its operator switches the extension off. Switched off,
sign-in attempts are not counted and no counter is kept; the sign-in log and
`lazysite check` both say the limiter is NOT in force, as they do when DB_File
is missing (Debian: `libdb-file-perl`, now the extension's declared dependency).
The upgrade does this once: switch it off afterwards and it stays off.

**Re-render your vhost** (SM797). The shipped front-end templates now hand a
page's markdown, `.url` and `.brief` files, backups, config, keys and executable
source to the engine instead of serving them from disk - so `/about.md` renders
the page and a stray `config.bak` is *not found*, whether or not the site has an
ACL store. A package upgrade does not rewrite an installed vhost: run
`lazysite-apache-vhost add` or `lazysite-nginx-vhost add` again for the domain
with the options it was added with plus `--force` (an existing vhost is refused
without it), or rebuild the domain in Hestia (which re-applies both the web and proxy
templates). If you maintain your own vhost, apply contract item 5 in
`docs/reference/webserver-wiring.md`. On a multi-domain instance, regenerate the
per-domain block (`... rewrites --docroot <docroot>`) as well.

The same re-render carries a second fix (SM850): the rule that hands existing
files to the engine once a site has an ACL store now also looks for the store
beside the docroot, where it is on a site whose engine tree was moved out
(`lazysite migrate-engine-tree`). Before, that rule never fired on a migrated
site, and the front end served its static files from disk whatever the ACL said
- the private store still held back what had been moved into it. If you
maintain your own vhost, apply contract item 7 in the same reference.

**On Hestia, the rollout now tells you what is left** (N13-41..43). The table
`lazysite-hestia-update-all.sh` prints first has two new columns:

- **ENGINE** - where the site's engine tree is: `inside` the docroot, `outside`
  (migrated), or `BOTH`, a half-finished migration, which is always a fault.
- **VHOST** - whether the vhost Hestia rendered for the site carries this
  release's template (`current`) or an older one (`rebuild`). Every shipped Hestia
  template now carries a `# lazysite-template-rev:` line for this. Every site
  reads `rebuild` on the first rollout of 0.13.13, because no earlier template
  had the line - which is also true: none of them has this release's rules yet.
  Run the rollout with `--rebuild`, or `v-rebuild-web-domain USER DOMAIN` per
  site, and the column turns `current`.

The summary at the end adds **CHECK** - `lazysite check` for each site that
updated, as `clean` or its warning and failure counts - and VHOST as it stands
after the run, with a count of the sites still to rebuild.

The Hestia scripts also stop assuming the engine tree is inside the docroot. On
a migrated site the rollout used to read the version as `?` and the channel as
unset, the lister flagged `NO-INSTALL-MARKER`, and the deploy treated every
upgrade as a first install - re-applying the template, rebuilding the vhost and
re-running the setup-manager step - while its permission sweep and secret
lockdown went to a directory that was no longer there. They now find the tree
where it is. `update-all` requires the lister it ships with; the fallback that
searched `/home` for install markers is gone.

## Upgrading to 0.10.19 from 0.10.18

**This is a BETA build** - the first promotion off the edge line. A site takes
it only if its `update_channel` accepts beta or below; nothing changes for a
site set to `stable` or `certified`.

**No new operator action.** Two fixes are worth knowing about because they
change behaviour you may have worked around:

- **Access rules now travel with content on every surface.** Deleting content
  drops its rules (previously only over WebDAV); moving content carries them.
  If you have been re-applying rules after a move, you no longer need to.
- **The access-rule store stays writable by the manager after a deploy.** If
  you saw `acls.json ... is not writable by the CGI` repaired on every upgrade,
  that was a real fault and it is fixed.

**Coming from 0.10.14 or earlier: the 0.10.15 section's four manual steps
remain your list.**

## Upgrading to 0.10.18 from 0.10.17

**No new operator action, and one thing that now happens for you.** From this
release an upgrade INVALIDATES RENDERED PAGES (SM413): cached pages re-render
on next request, so the first page you check after upgrading reflects the
build you just installed. Before this, a page whose source had not changed
kept its pre-upgrade render indefinitely - a homepage was found serving the
same render through four deployments.

Also automatic: the outside-in ACL probe now drops to the site's owner instead
of refusing when the deploy runs as root, so `lazysite probe` produces a
verdict rather than "NOT CONFIRMED" (SM426).

**Worth knowing:** this release fixes a CRITICAL issue where an authenticated
content editor could write outside the content area (SM418). No action is
needed beyond upgrading.

**Coming from 0.10.14 or earlier: the 0.10.15 section's four manual steps
remain your list.**

## Upgrading to 0.10.17 from 0.10.16

**No new operator action.** The multi-domain apply fix (SM412), the plugin
enabled-gate (SM409 - gates only contract-declaring plugins, of which none
ship yet), and the session-verification module move (SM411) all travel in the
package with behaviour preserved for existing sites. New diagnostic worth
knowing: `plugins/stats.pl --classify --path P [--ua UA] [--status N]
--docroot D` answers the visitor classifier from the command line without
touching the stats.

**Coming from 0.10.14 or earlier: the 0.10.15 section's four manual steps
remain your list.**

## Upgrading to 0.10.16 from 0.10.15

**No new operator action.** Everything 0.10.16 changes travels in the
package: build provenance in the release manifest (SM400), structured
form answers (SM401 - an authoring feature, nothing to migrate), the
form handler recording capture method instead of an unverifiable
identity (SM402 - existing stored submissions are unchanged; only new
submissions carry the new field), checked stats writers (SM404), and a
deterministic release gate (SM406).

**If you are coming from 0.10.14 or earlier, the 0.10.15 section below
is still your list** - its four manual steps (ACL re-apply, the proxy
template, the CSP decision, the front-door check) are cumulative and
none of them is superseded here. Do them once, at whatever version you
land on.

One thing to KNOW rather than do: from this release the artefact can
prove which commit its gate validated - `release-manifest.json` carries
`validated: {commit, files, tests}` and the repo's
`docs/releases/GATE-LOG.md` holds the matching row. If you verify builds
before rollout, that is the field to check.

## Upgrading to 0.10.15 from 0.10.10-0.10.14 (READ THIS ONE)

The package upgrade does the code. **Four things it cannot do**, and the
order matters.

### 1. Re-apply access rules, AFTER the upgrade

From 0.10.8 protecting content MOVES it out of the served tree - but
only on the act of protecting. Any section protected on an earlier
version still has its files in the document root, with the rule honoured
for pages and the files public.

```bash
lazysite acl reapply --docroot <docroot>
```

After the upgrade, never before: it re-issues stored rules through the
new code. It changes no rule. `NOT MOVED: <path>` in the output means
the rule was stored and nothing moved, which is the condition it exists
to find.

### 2. The proxy template, which a package cannot deliver

`lazysite-proxy` is a Hestia template. **A package upgrade does not
install or update one**, and 0.10.15 corrects a defect in it (SM374)
that returns **421 on every request** to a TLS domain.

::: widebox
**While the host's copy is stale the failure is identical to the bug.**
An operator who applies the fix, sees 421, and concludes the fix does
not work has been misled by their own template directory. Confirm the
copy on the host is the new one before drawing any conclusion from a
421.
:::

```bash
v-change-web-domain-proxy-tpl <user> <domain> lazysite-proxy
```

Test on the **body**, not the status: without a correct `Host` the
backend serves its default vhost with a 200, so a status check cannot
say which site answered.

### 3. The private store, if it does not exist yet

Creating it is a root action. `lazysite-check` reports whether the
engine can write to it; if the store is missing on a site that protects
anything, create it before re-applying rules.

### 4. Verify from outside, as the site user

```bash
lazysite check --check-acl https://<domain>
```

**Not as root.** The probe protects a fixture to measure it, and doing
that as root would leave root-owned files in the site tree - so it
declines and says so (SM377). The reason it gives is the one to act on;
the summary no longer overwrites it with a guess (SM385).

### Effective permissions widen if you are coming from 0.9.x

This has its own heading because it is a change of **who can read what**,
not a feature.

An `@group` entry in an ACL grants access to the members of that group.
Until SM288, MCP and the control API **discarded an account's groups**,
so those entries were silently inert on two of the three channels.
WebDAV honoured them; the others did not.

::: widebox
**Nobody gains groups here.** Partners already had them; two channels
were throwing them away. What changes is that an `@group` entry which
has been doing nothing on MCP starts doing what it says.
:::

Before upgrading a site that uses `@group` entries, see exactly who is
affected:

```bash
lazysite acl group-reach --docroot <docroot>
```

It lists each `@group` entry, the paths that grant it, and **every
account it reaches - including through nested groups**. Nested is the
case worth having: an account that reaches a group only by nesting is
precisely the one a quick look at the members list would miss.

If the report names an account you did not expect to have access,
resolve it before upgrading rather than after.

### What changed that you will see

- **A Content-Security-Policy now ships**, `report-only` by default.
  `csp: enforce | report-only | off` in `lazysite.conf`. **Do not set
  `enforce` yet** - the manager's controls use inline handlers a CSP
  hash cannot cover, so the manager is held at report-only regardless
  until they are converted.
- **Engine-served statics revalidate** rather than caching for a decade
  (SM387), and now carry an ETag so revalidation costs a 304 rather than
  a re-download (SM388). The ten-year cache was a property of the
  front-end fast path, not of lazysite.
- **402 and 403 pages** carry the full header set and resolve their own
  domain's content root - on a multi-domain instance they were rendering
  into the primary's docroot.
- **A backup of a live site no longer fails** because a visitor arrived
  mid-snapshot (SM381).

## Upgrading to 0.10.10 from 0.10.0, 0.10.8 or 0.10.9

The fleet spans **0.10.0** (stable) and the edge line, and every one of them
needs the same operator action after upgrading. It is not delivered by the
package.

### Why an upgrade alone is not enough

From 0.10.8, protecting content **moves it out of the document root** into a
private store beside it, so that a front end which serves files without asking
the engine cannot reach protected bytes. That was the structural answer to
SM248, SM268 H17 and SM283.

The move happens **on the act of protecting**. It is not a migration, and no
upgrade performs it retrospectively. So:

```datatable
columns: If the site is on | Then after upgrading to 0.10.10
widths: 3.4cm | X
bold: 1
tone: medium
text: 2
---
0.10.0 (stable) | Every section ever protected still has its FILES in the document root. The rule is stored and honoured for pages; the files are reachable by anyone who knows the path on a front end that answers statics itself. Measured on a real upgraded site: 19 of 25 extensions still served byte-identically to an anonymous request.
0.10.8 (edge) | The same, for anything protected before 0.10.8 - AND anything protected ON 0.10.8 may be in that state too, because SM296 could crash the move after the rule was saved, leaving the content stored-as-protected and still served with no audit line.
0.10.9 (edge) | The same, if the sweep was run and reported success while moving nothing. Until 0.10.10 a re-apply that stored the rule and moved no files counted as "re-applied" and exited 0, so a fleet sweep could report every site done having achieved nothing. **Run it again on 0.10.10 and read the new count.**
```

Both are repaired by the same action, because both are "the rule is right and
the bytes are in the wrong place".

### What 0.10.10 changes about this

Three things, all of which make the SAME action more likely to actually work:

- **The store gets created.** The sweep needs the private store, which is a
  SIBLING of the document root - so repairing the docroot never reached it, and
  a site with a perfectly repaired `public_html` could still move nothing.
  `lazysite check --fix`, run as root, now creates it. See below.
- **A sweep that moves nothing says so.** It is counted as `moved nothing`
  rather than `re-applied`, the cause is named once, and the command exits
  non-zero. On 0.10.9 and earlier it reported success.
- **The rollout checks from OUTSIDE afterwards.** Every run now probes each site
  anonymously and reports whether the front end honoured the rule, because the
  engine's report and the front end's behaviour are different claims and have
  disagreed three times. A site it could not measure is reported as `not
  confirmed` rather than as passing.

### The action

**Re-apply every stored rule.** This re-issues each rule with the values already
in the store - it grants nothing, revokes nothing, and changes no rule. What
changes is where the files live.

Per site:

```bash
# see what would happen (dry run - this is the default)
lazysite acl reapply --docroot /path/to/public_html --actor local

# do it
lazysite acl reapply --docroot /path/to/public_html --actor local --apply
```

Across a Hestia fleet, as part of the rollout:

```bash
bash /tmp/lazysite-0.10.10/installers/hestia/lazysite-hestia-update-all.sh \
     --reapply-acls
```

The sweep runs only on sites that actually upgraded - a site skipped by its
update channel is still on its old version - and runs as each site's own user,
never as root.

::: widebox
**Order matters: upgrade first, then sweep.** The re-apply is the operation
SM296 broke. On 0.10.8 it is the thing that crashes, so running it before the
upgrade repairs nothing and reports failures. `--reapply-acls` sweeps after the
deploy step for exactly this reason.
:::

### The sweep needs the private store to exist

The store is `<docroot>-lazysite-private` - a **sibling** of the document root,
not a directory inside it. Creating it needs write access on the docroot's
*parent*, which on the Hestia layout is the domain folder.

**Repairing the document root does not fix this.** They are different
directories, and a site can have a perfectly repaired `public_html` where the
sweep still moves nothing. That happened on a live instance in August 2026:
`MKCOL`, `PUT`, overwrite and `DELETE` at the site root all worked, and
protecting a folder still left every file public and anonymously reachable.

```bash
lazysite check --docroot /path/to/public_html          # names the store, owner, mode
sudo lazysite check --docroot /path/to/public_html --fix   # creates it
```

`--fix` creates the store owned by the site user, mode 2770. It deliberately
does **not** make the parent directory group-writable: that parent also holds
`cgi-bin`, and write permission on a directory is permission to rename its
entries, so the wider repair would open a larger hole than the one being closed.

From 0.10.10 the sweep reports this rather than hiding it. A re-apply that stores
the rule and moves nothing counts as `moved nothing`, not as `re-applied`, and
the command exits non-zero - so a fleet sweep that achieved nothing can no longer
report success.

### Verify from outside

Do not take the sweep's own word for it. The engine's report and the front end's
behaviour are different claims, and SM283 was the case where they disagreed.

**From 0.10.10 the fleet rollout does this for you**, per site, at the end of
every run - reporting `verified`, `exposed` and `not confirmed` separately, and
exiting non-zero on an exposure. Run it by hand for a single site, or to re-check
after repairing one:

```bash
lazysite check --check-acl https://<domain>/
```

That gates a probe folder against a principal which cannot exist and fetches it
anonymously under several extensions, with a public control of the same type
alongside each - so a refusal that happens because the front end cannot read the
file is distinguishable from a refusal that is the access rule working.

### Also outstanding from 0.10.7, on Hestia

SM283's remedy is an nginx **proxy template**, and it is likewise not delivered
by a package upgrade: the template must be staged and each domain moved onto it.

```bash
bash /tmp/lazysite-0.10.10/installers/hestia/lazysite-hestia-update-all.sh \
     --proxy --reapply-acls
```

Check whether a domain has it with no credentials:

```bash
curl -sI https://<domain>/ | grep -i X-Lazysite-Front
```

A domain with an ACL store and no `X-Lazysite-Front` header is on a stock proxy
and is the SM283 shape. `lazysite-hestia-list.sh` flags those as
`ACL-BYPASSED-BY-PROXY(SM283)`.

### Optional, and separate

`lazysite migrate-engine-tree --apply` moves the `lazysite/` engine tree out of
the document root (SM293). Dry-run by default, reversible with `--back`, and
gated by `--min-version`. It is unrelated to the re-apply sweep and can be done
whenever.

## manager_groups retired (SM138)

The legacy `manager_groups:` key in `lazysite.conf` is retired. Manager access
is granted by **groups**: any group carrying the `ui` capability (manager UI) or
`manage_users` (operator powers), managed on the manager **Groups** page.

**Migration is automatic.** On the first settings read after upgrade, any group
the conf key named receives the full manager grant explicitly (every capability
except the remote `api`/`mcp` channels - manager groups are interactive-only),
and the `manager_groups:` line is removed from `lazysite.conf`. Effective access
is unchanged: those groups had unrestricted operator access through the fallback
already. No operator action is needed; a lingering line (e.g. an unwritable
conf) is simply ignored.

If **no** group grants manager access at all, the site is in the unsecured/dev
mode where any authenticated user is a manager - run
`lazysite-users.pl setup-sysop` (or grant `ui` to a group) to secure it, as
before.

## WebDAV publishing (SM070)

A WebDAV endpoint (`/dav`) is available for headless, per-file
content publishing. It is **off by default** — an existing install is
unchanged after upgrade until you opt in. To enable it:

1. Add `webdav_enabled: true` to `lazysite/lazysite.conf`.
2. Add the `/dav` ScriptAlias to your web server. The shipped Hestia
   templates include it; for a hand-rolled Apache vhost add
   `ScriptAlias /dav /path/to/cgi-bin/lazysite-dav.pl` and ensure the
   `RequestHeader unset X-Remote-*` lines are present (now in the
   shipped templates).
3. For each publishing account, set `webdav on` (and usually a
   `dav_scope`) on the manager Users page, then generate a credential.

The Hestia templates also gained the `RequestHeader unset X-Remote-*`
directives that `docs/architecture/security.md` has always required;
they need Apache's `mod_headers`. See
`docs/features/configuration/webdav.md` for the full guide.

## 0.2.x to 0.3.0

The installer is now upgrade-aware. This is the first version
with safe in-place upgrades: a later release can be applied to a
site without losing its content. (0.3.0 reached that by re-running
`install.sh`; today it is `lazysite upgrade` - see *How to upgrade*
at the top.)

### What this enables

- Seed files you have edited (starter pages, your custom docs,
  registry templates) are preserved across upgrades.
- Code files (processor, plugins, manager UI, system theme)
  are overwritten with each new release.
- Files removed in new versions are cleaned up only if you
  haven't edited them; edited orphans stay and produce a
  warning.
- Pre-upgrade backups accumulate under
  `{docroot}/lazysite/backups/`, retained per
  `backup_retention` in `lazysite.conf` (default 3; 0 = keep
  all).
- `--dry-run` shows the full upgrade plan without modifying
  anything.

### What does NOT get migrated

Installs created with 0.1.x or 0.2.x pre-dating the 0.3.0
installer do not have `.install-state.json`. The installer
treats them as fresh installs: it walks the manifest and
skips-if-present, which is the old behaviour. The first
post-0.3.0 run establishes `.install-state.json` for future
upgrades. Effectively, 0.3.0 is where upgrade-tracking begins.
Plan to back up your docroot before the first 0.3.0 install
on an existing deployment.

### If upgrade goes wrong

Every upgrade creates a backup first. To list them:

```bash
lazysite backups --docroot /path/to/public_html
```

To restore the most recent, or a specific one:

```bash
lazysite backups --docroot /path/to/public_html --restore
lazysite backups --docroot /path/to/public_html --restore --backup PATH
```

Restore does not touch runtime state (auth users, cache,
logs). It invalidates the rendered HTML cache afterwards so
stale pages don't linger.

### No default layout or theme ships

0.3.0 ships no layout or theme content of its own. A fresh
install has no `lazysite/layouts/NAME/layout.tt`, and the
processor falls back to a built-in template until one is
installed. Install a layout + theme via the manager UI at
`/manager/themes` > "Install from Releases" (the configured
`layouts_repo` default is `OpenDigitalCC/lazysite-layouts`),
or drop a layout directory in manually.

### New files installed

`install.sh` now installs:

- `install.pl` at the repo root (the real installer; the
  shell script is a thin wrapper).

### No change for fresh installs

First-time installs work the same as before.
`.install-state.json` is created automatically on first run.

## 0.1.0 to 0.2.0

Breaking changes in this release. Read the whole file before
upgrading a production install.

### Plugin URLs changed

Plugins moved from `/cgi-bin/lazysite-*.pl` to `/cgi-bin/*.pl`:

- `/cgi-bin/lazysite-form-handler.pl` -> `/cgi-bin/form-handler.pl`
- `/cgi-bin/lazysite-payment-demo.pl` -> `/cgi-bin/payment-demo.pl`

Update any external integrations pointing at these URLs:

- Web form `action=` attributes in custom pages
- Webhook URLs in `handlers.conf`
- External systems POSTing to `form-handler`
- Payment flow URLs

`form-smtp` is not a URL endpoint (it runs as a subprocess of
`form-handler`), so nothing to update there.

### Plugin source locations changed

Plugin scripts moved from the repo root (and `tools/`) to
`plugins/`, dropping the `lazysite-` prefix:

- `lazysite-form-handler.pl`   -> `plugins/form-handler.pl`
- `lazysite-form-smtp.pl`      -> `plugins/form-smtp.pl`
- `lazysite-payment-demo.pl`   -> `plugins/payment-demo.pl`
- `lazysite-log.pl`            -> `plugins/log.pl`
- `tools/lazysite-audit.pl`    -> `plugins/audit.pl`

Core scripts keep their `lazysite-` prefix at repo root:

- `lazysite-processor.pl`
- `lazysite-auth.pl`
- `lazysite-manager-api.pl`

`install.sh` now places plugins under `{docroot}/../plugins/`
and symlinks `form-handler.pl` and `payment-demo.pl` into
`cgi-bin/` for Apache routing. The dev server
(`tools/lazysite-server.pl`) discovers both locations.

### Plugin enable-list entries become stale

Your installed `lazysite.conf` has `plugins:` entries referencing
the old plugin paths, for example:

    plugins:
      - cgi-bin/lazysite-form-handler.pl
      - tools/lazysite-audit.pl

After upgrading to 0.2.0, these paths no longer resolve. The
manager UI will treat the plugins as disabled, even though the
underlying scripts are installed. Form processing, audit runs, and
any other affected features stop working silently.

**To fix:**

**Option 1 - via the manager UI.** Visit `/manager/plugins` and
toggle each plugin off then on. The new paths are written to
`lazysite.conf` in the new format.

**Option 2 - hand-edit lazysite.conf.** Replace old paths with
new ones:

    cgi-bin/lazysite-form-handler.pl  -> plugins/form-handler.pl
    cgi-bin/lazysite-form-smtp.pl     -> plugins/form-smtp.pl
    tools/lazysite-audit.pl           -> plugins/audit.pl
    lazysite-log.pl                   -> plugins/log.pl

Leave `lazysite-auth.pl` alone - it stays at repo root and keeps
its old entry.

This migration will be automatic in 0.3.0 when the upgrade-safe
installer lands (D021c).

### Upgrade procedure

1. Review external integrations (webhooks, custom form actions,
   payment flows). Update any URLs that point at the old
   `/cgi-bin/lazysite-*.pl` paths.
2. Take a backup of your site. (The upgrade-safe installer arrives
   in 0.3.0; for now, backup is manual.)
3. Extract `lazysite-0.2.0.tar.gz` and apply it to the same
   `--docroot` and `--cgibin` you used for 0.1.0. (0.2.0 was
   installed by re-running `install.sh`; today that is
   `lazysite upgrade` - see *How to upgrade* at the top.)
4. The installer places new plugins under
   `{docroot}/../plugins/`. Old plugin files left over from 0.1.0
   in `/cgi-bin/` or `{docroot}/../` can be removed manually once
   you have confirmed the new layout works.
5. Reconcile `lazysite.conf` `plugins:` entries per the previous
   section.
6. Restart Apache (or reload the config) to ensure routing
   changes take effect.

### New files installed

`install.sh` now catches up with files that were in the release
manifest but previously not installed by the installer:

- `starter/docs/features/` subtree (authoring, configuration, and
  development feature docs) under `{docroot}/docs/features/`
- `tools/lazysite-server.pl` (dev/evaluation server) and
  `tools/build-static.sh` (static site export) under
  `{docroot}/../tools/`
- `lazysite.conf.example` and `nav.conf.example` as reference
  files under `{docroot}/lazysite/`
- `users.example` and `groups.example` under
  `{docroot}/lazysite/auth/` as references, and as seed sources
  for `users` / `groups` on fresh installs
