---
id: SM786
title: "SM786: a data-table cell is escaped where it renders"
subtitle: "Security review, 0.13.8, VERIFIED AND REPRODUCED HERE: db-bound table values reach the page stash raw, the page-render Template engines set no AUTO_FILTER, and the shipped examples teach the loop without a filter - so whoever can write a row controls markup, and therefore script, on every page that displays that table. Front-matter scalars in the same stash ARE escaped, which is what makes this an asymmetry rather than a policy."
brand: plain
standard-margins: true
status: shipped
status-note: "RULED 2026-09-08 by the release manager: escape by default, with a manager.conf override that is DEPRECATED THE DAY IT SHIPS. The override is set for the three sites that render db fields today, so nothing breaks; the sites agent then fixes those templates through routine updates; the override is removed once they are done. Design of record below - not yet built, and the release it rides is a separate decision."
---

# The finding, and what was verified

Filed by the security review as High. Every load-bearing claim was checked
against the source here before accepting it, and the injection was reproduced
independently rather than taken from the brief:

- **No `AUTO_FILTER` anywhere.** A grep across `lazysite-processor.pl` and
  `lib/Lazysite/` finds none, so `[% p.name %]` emits the cell verbatim.
- **`resolve_db` stashes raw.** `$vars{$key} = $v;` (~5222) takes the row
  hashes from `Lazysite::Data::Tables` as they are.
- **Front-matter and the auth context in the SAME stash are escaped**, through
  `_esc_html` (~6571), with a comment explaining why. So the engine already
  holds the rule; the db path is outside it.
- **CSP does not cover the gap on a default site.** `_csp_mode` returns
  `report-only` when unset (`SecurityHeaders.pm:101`), and report-only logs
  without blocking.
- **The shipped example teaches the unfiltered form**:
  `starter/docs/data-tables.md:110` is
  `[% FOREACH p IN products %]<li>[% p.name %] - [% p.price %]</li>[% END %]`.

Reproduced in `tmp/xss-repro.pl` against the engine's own Template
construction, in both contexts that matter:

    <li data-note=""><script>alert(3)</script>"><script>alert(1)</script></li>

element text AND an attribute breakout, from one row. The same row through
`| html` comes out `&lt;script&gt;...`, so the escape exists and is simply not
applied.

# Why this is worth a release

The row writer is not always the operator. A public form populating a table, an
imported CSV, a custom data app and a connector answer (a remote HTTP response)
all reach the same sink, and the first and last of those are reachable by
someone who has no account. The victim is every visitor to the page, and on a
gated page it is an authenticated session.

# The ruling: escape by default, behind an override that is born deprecated

The release manager's decision, 2026-09-08. It answers the one question the
finding could not answer for itself - what happens to a site that renders
authored HTML out of a table today - and it answers it with a **migration**
rather than a permanent opt-out.

**Escape at the sink**, so a page author cannot forget: either `AUTO_FILTER =>
'html'` on the page-render engines, or `_esc_html` in `resolve_db` as
front-matter already is. `_esc_html` escapes the apostrophe as well as
`< > & "`, so one default covers element text and either quoting style.

**An override in `manager.conf`** turns the escaping off for a site that needs
the old behaviour while its templates are corrected. It is set for the three
sites that render db fields today, so nothing breaks on the day this ships, and
for nothing else.

**The override is deprecated the day it ships.** Not "deprecated when we get
round to it" - it is announced as deprecated in the same release that
introduces it, because its only purpose is to hold the door for three known
sites while they are fixed. That ordering matters: a compatibility flag with no
stated end becomes the configuration everyone copies.

**The sites agent corrects those templates through routine updates** - a
`| html` on each cell, or whatever the marked-safe convention turns out to be -
and reports when a site no longer needs the flag.

**The override is removed** once the three are done. Removing it is a release
of its own, and until then the flag's presence on a site is a to-do list with a
name.

Why this shape rather than a permanent `| raw`: an escape you can opt out of
per column is a feature, and features get used. A flag that exists to be
deleted, set on a known and shrinking list, cannot quietly become the way sites
are built.

# What follows once the sink is settled

- Update `starter/docs/data-tables.md` and the other examples so the taught
  pattern is the safe one. This is the half that stops the defect coming back:
  the current example is where a page author learns the unsafe form.
- A `t/` case that puts `<script>` in a cell, renders, and asserts the output
  is escaped - and a second that asserts the override still renders raw, so the
  flag's behaviour is pinned for as long as it exists.
- The three sites named in the override are the migration list; the flag is
  gone when it is empty.
- A connector answer treated as untrusted wherever else it surfaces (SM790's
  render half).

**Not built.** The design is settled; which release carries it is a separate
decision, and the escaping change should not be dropped into a release that is
already carrying four items without the release manager saying so.

# Provenance

`inbox/2026-09-08-db-table-cells-render-unescaped-stored-xss.md` and the
connector face of it in
`inbox/2026-09-08-connector-answer-and-table-render-xss.md`. Accepted after
independent verification.

# ANSWERED 2026-09-09: no site authors HTML into a db column

The sites agent surveyed every site they hold and the answer to the question as
posed is **none**, which is the best available outcome: **the `manager.conf`
override ships already empty, deprecated on arrival.**

One live page binds a data table - the learning app's `/catalogue` - and every
rendered column already carries a filter (`| html`, or `| uri` for a slug, with
two numeric counts unfiltered). Read directly, `learn_categories` (2 rows) and
`learn_programmes` (3 rows) contain no `& < > " '` at all and no HTML tags.

Coverage was stated plainly rather than implied: 14 sites with local sources
grepped across ~1,100 markdown files; the learning site's 13 pages pulled over
WebDAV; `familyhq.explore` read and found to be **client-side** - rows fetched
through `lazysite-data.pl`, never through the template, and its own `esc()`
applied where it uses `innerHTML`; `edge.explore` carrying 0 tables. Three sites
(`opendigital.info`, `edge-cc2`, `edge-cc3`) were **not surveyed** and are named
as not surveyed.

**And a correction to their own method, which is why the answer is trustworthy.**
Their first pass grepped for `^db:` as a front-matter key, returned nothing, and
nearly answered "none" on that basis. The binding is a source prefix *inside*
`tt_page_var`, indented, so the pattern never matched. They found it, said so,
and re-ran with `^\s+[a-z_]+: *db:`. A confident "none" from a wrong regex would
have been indistinguishable from this one.

# THE SECOND FAILURE MODE, which the question did not ask about

The question asked which sites need the override *to keep rendering authored
HTML*. The learning catalogue is the other shape: **a page that already escapes
correctly, which escape-by-default would escape twice.**

It is latent rather than live - the data contains no escapable character today -
but the first apostrophe typed into a programme title renders as `&#39;` on the
page. **The templates that did the right thing are the ones that break**, which
is the opposite of the usual migration risk and will not be found by looking for
sites that need the override.

Two shapes, and it is a decision rather than an implementation detail, so it is
in `docs/decision-register.md`:

1. **Make escape-by-default idempotent with an explicit `| html`** - nothing
   breaks, no author has to do anything, and the engine carries a rule that
   "already escaped" is detectable, which for arbitrary text it is not reliably.
2. **Tell authors to remove their filters**, loudly, in the migration note. More
   honest, and it asks the people who were careful to change their pages.

The reporter prefers the second and says it needs saying loudly. That reasoning
is recorded rather than settled.

# BUILT 2026-09-10, with the fail-safe the release manager asked for

Escaped at the sink: `_escape_db_rows`, called by `resolve_db` on its way out,
so every `db:` value passes through it once. Not `AUTO_FILTER` on the render
engines - that would also re-escape what the engine itself puts in the stash,
which is already escaped, and this is the one place every db value passes.

**The override is `db_render_raw: true` in `lazysite.conf`, and it logs its own
deprecation on every page that uses it.** A note on the ruling's wording: it
called this a `manager.conf` override, and **there is no `manager.conf` in this
engine** - the site config is `lazysite.conf`, which is where it has gone. Per
the sites agent's survey - fourteen sites, ~1,100 files - **no site needs it**,
so it ships set for nothing, which is the best available version of "set for the
three sites that render db fields today".

## The fail-safe, which is what the release manager added to the ruling

> tell authors as a workaround, with fail safe. later the default changes and
> this would create clear messages as to what the problem is, should there be
> any lingering incompatible pages.

That is a better answer than either option in the register, and it is why the
register's question is closed rather than chosen between. Making the escape
idempotent would have hidden the problem; telling authors alone would have left
it silent. Instead:

- **The value is escaped either way** - it fails safe, not open. A page that was
  already careful renders `&#39;` where an apostrophe belongs: readable and
  wrong, not broken.
- **The log names the table, the column and the remedy** - "if this column
  renders as `&#39;`, remove the `| html` filter from the template" - so a
  lingering incompatible page announces itself instead of being found by eye.
- **Detection is on the INPUT**, before escaping: a value that already looks
  entity-encoded. It can be a false positive, because a row legitimately
  containing the text `&amp;` is indistinguishable from one escaped upstream -
  which is exactly why it reports and does not change what it does.
- **An ordinary value does not trip it**, and there is a test for that: a warning
  on every row of every table would stop being read.

`starter/docs/ai-briefing-data.md` now tells authors not to add `| html`, what
the double-escape looks like, and that the flag is deprecated on arrival.

## What proves it

`t/unit/processor/47` calls the sink directly - the idiom the processor's other
unit tests use - rather than asserting through a render. **That choice is
deliberate and was learned an hour earlier on [[SM820]]**, where a render-based
test passed whether the fix was present or absent. Verified the other way too:
with the escaping line removed, 6 of 15 assertions fail.

Fifteen assertions, covering the markup case, the apostrophe and both quote
styles, that numbers and undefs and references are left alone, the fail-safe with
its message, the absence of a false positive on ordinary text, and the override
with its deprecation notice.
