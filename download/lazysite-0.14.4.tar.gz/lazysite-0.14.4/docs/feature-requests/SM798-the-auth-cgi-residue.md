---
id: SM798
title: "SM798: the auth CGI residue - an empty-password oracle and a rate limit that fails open"
subtitle: "Security review, 0.13.8. The wild-facing auth handler came out of the review largely solid, and these are the two low-severity items left over: an existing empty-password account answers a remote login with 403 while every other outcome answers 302, which is an enumeration oracle for exactly the configuration the engine discourages; and check_login_rate is per-IP only and fails open."
brand: plain
standard-margins: true
status: partial
status-note: "ALL BUT ONE DESIGN QUESTION BUILT. HALF BUILT 2026-09-09 on claude/sm798-sm799-the-smaller-two. The rate limiter still fails OPEN - failing closed would refuse every login on a host missing an optional module, which is a worse failure than not enforcing the cap - but it no longer does so in SILENCE: both unrunnable cases log a WARN saying the limiter is NOT IN FORCE, naming which of the two happened, the file, the error, and the Debian package for the missing module. That is SM784's rule applied where it belongs: the answer stays permissive, the log carries what was actually established. THE ORACLE IS NOW CLOSED (ruled 2026-09-09, built, verified on main 2026-09-10): the passwordless remote refusal is indistinguishable from an absent user and a wrong password - same 302 ?error=1, and THE SAME SLEEP, because matching only the status would have swapped one oracle for a slower, quieter one. The explanation it cost is not lost - it moved to the log and the audit trail, where an operator can reach it and an unauthenticated caller cannot. WHAT REMAINS: the per-IP-only scope, which would be a per-account limiter and is a design change rather than a fix. BUILT 2026-09-11 (0.13.13): the health-check line (lazysite check says when the limiter is NOT in force - no DB_File, a counter the sign-in CGI cannot open, or switched off; t/tools/70); and the switchable extension, ruled on by default the same day - plugins/login-rate-limit.pl, DB_File its owns.deps, listed by the installer on a fresh site and once on upgrade (recorded in the install state, so an operator's off stays off); switched off it counts nothing, keeps no counter and says NOT in force in the log and in lazysite check. t/unit/auth/25 (reproduced first: it could not be switched off), t/tools/03, t/tools/70."
---

# The two items

**An enumeration oracle for empty-password accounts.** From a non-loopback
address, an absent user and a wrong password both answer `302 ?error=1`, while
an account that exists with an empty password answers `403` through
`reject_no_password()`. So the one response that differs identifies an account
that exists *and* is in the state the engine most discourages. Low: it discloses
existence only for a configuration that should not be in production, and the
403 exists to tell an operator why their passwordless account cannot sign in
remotely - which is a real message, not an accident. The fix is to answer the
same 302 and put the reason in the log, at the cost of that message.

**The login rate limit is per-IP only, and fails open.** It cannot be read as
protection for an account, only for an address: a distributed attempt against
one account is not rate-limited at all, and a limiter that fails open when its
own store cannot be read is a cap that stops capping exactly when something is
wrong. Compare `_calls_in_last_hour` in the connector store, which returns undef
on an unreadable record and refuses the call - the same question, answered the
other way in two places.

# What was built, and what deliberately was not

**The limiter says when it is not in force.** Both unrunnable cases - `DB_File`
absent, and a counter that will not open - returned "under the cap" in complete
silence, so a site with no login rate limiting looked exactly like a site with
it, from every surface including its own health report.

The direction is unchanged and that is the decision: failing closed would
refuse every login on a host missing an optional module, and locking an
operator out of their own site to enforce a rate limit is the worse failure.
What changes is that the WARN now says the limiter is **not in force**, names
which of the two happened, the file, the error, and the package that supplies
the missing module. The consequence, not just the cause.

Logged per attempt rather than once, because these are CGI processes with
nothing to remember between them - and a run of those lines is itself the
signal that the limiter has been inert for a while.

**Built in 0.13.13: the health-check line.** `lazysite check` says the limiter
is NOT in force when DB_File is missing (naming libdb-file-perl) or when its
counter cannot be opened by the sign-in CGI (naming the file, with the chown and
chmod, and `--fix` applying them), and says it is in force otherwise - so its
absence from a report means something. `t/tools/70`; before the fix the check
said nothing in all three cases.

# Why the rest is filed rather than built

The oracle is a genuine trade: closing it removes the sentence that tells an
operator why sign-in is refused, and the empty-password state is already
loopback-only. That is the release manager's call.

The rate limiter is the more interesting one, because it is the four-states
rule again (SM784): "I could not read the record" is being answered as "you are
under the cap". Whether it should fail closed is a decision about locking
people out of their own site when a file is unreadable, and it belongs with the
survey SM784 asks for rather than as a lone change here.

# What came out solid, and is worth not re-reviewing

Reproduced by the review rather than read: every IP decision reads
`REMOTE_ADDR`, and `X-Forwarded-For` / `X-Real-IP` / `Forwarded` spoofs of
loopback were all refused. Sessions are HMAC-SHA256 with groups re-resolved
rather than trusted from the cookie. Password hashing is salted, iterated and
constant-time. Reset tokens are 192-bit CSPRNG, stored hashed, single-use, 24
hours, with no enumeration. The `next=` redirect guard rejects `//host` and
backslash forms.

# Provenance

`inbox/2026-09-08-auth-cgi-enumeration-and-rate-limit.md`.

## Ruled 2026-09-09 by the release manager

**Close the empty-password enumeration oracle.** A passwordless account refuses
exactly as a wrong password does. This overrules the recommendation in the
register, which weighed the narrowness of the state (loopback-only, and
discouraged) against the operator's diagnosis and came down on keeping the
explaining 403. The ruling is that an unauthenticated caller must not be able to
tell one refusal from the other, whatever it costs the diagnosis - the operator
reaches the log for that.

## BUILT 2026-09-09 on `claude/sm798-the-empty-password-oracle`

The passwordless refusal is now the SAME refusal an absent account and a wrong
password get: `sleep $LOGIN_DELAY`, then `302 ?error=1`.

**The sleep is part of the fix, not decoration.** The other two refusals pause
and this path did not, so matching only the status would have swapped a loud
oracle for a slower, quieter one - the timing would still have told a caller
which accounts exist without passwords.

`reject_no_password()` has no caller left and is gone, and with it the two
chrome strings that only it rendered (`auth.nopw.title`, `auth.nopw.body`) -
a translated string for a page nothing draws is a declaration the code ignores.
`t/unit/lib/41-i18n.t` used `auth.nopw.title` as the fixture for "an EMPTY
override falls back to English"; it now uses `auth.uidisabled.title`, which
still has a caller.

**The operator's message was not deleted, it moved.** `log_event` and
`_audit_auth` record `no-password-remote` exactly as before, so the diagnosis is
in the log and the audit trail - reachable by the operator, not by the caller.
The new test asserts that too, because that recording is the whole of what the
403 was for and losing it quietly would make this a worse change than the oracle.

`t/unit/auth/10` proves the closure by INDISTINGUISHABILITY rather than against
a hand-written expectation - it requires the passwordless response to be
byte-identical to the other two refusals, so a wrong expectation cannot pass
while the oracle stays open. Checked by reopening the oracle and watching it
fail.

STILL OPEN from this filing: the rate limiter's per-IP-only scope, which would
be a per-account limiter and is a design change rather than a fix; and whether
the limiter should be a plugin, which is the one row of this filing still in
`docs/decision-register.md`.

# RULED 2026-09-10: the rate limiter becomes a switchable extension

This overrules the recommendation recorded here, and the release manager's
reasons are better than the objection they answer:

- **No core requirement for the module.** As an extension, `DB_File` is the
  extension's declared dependency (`owns.deps`) rather than something core must
  carry. That inverts the original argument entirely: the dep check was dismissed
  here because `DB_File` is a core Perl module shipped in `debian/control` - but
  the point is to stop it being one.
- **Less in the core.** The same principle as [[SM817]] and [[SM222]] L0: the
  renderer and the auth path keep only what every site needs.
- **Some situations may not want it.** A single-operator instance behind a VPN,
  or a constrained device, may legitimately not want a per-IP counter and its
  store at all. That is a real deployment, and "you may not turn this off" was
  the whole of the objection.

**What survives from the objection** is the failure mode, not the conclusion: a
rate limiter that is off must be *visibly* off. The WARN built in 0.13.10 says
when it is not in force; a disabled extension must say the same thing in the same
words, so that "disabled deliberately" and "broken quietly" never look alike.

# The semantics of OFF, ruled the same day

The release manager settled what disabling means for the three, and it is the
same answer each time - **off stops COLLECTION, it does not remove what was
collected**:

| | What OFF does |
| --- | --- |
| Audit trail | No further entries. Existing entries stay. If it was never on, the data was never collected - which is the point for a constrained instance. |
| Content history | No further logging. **The existing history is not removed.** |
| Rate limiter | No counting, and no counter store. |

That is a materially different design from the one [[SM222]] was heading towards,
and it removes the objection that made the audit switch look dangerous: **a
switch that stops collection is not a switch that erases evidence.** The hole in
the record has named edges - the disable and re-enable are recorded with the
actor - and nothing already written is touched.

It also answers the constrained-resources case directly: an instance that never
turns these on never pays for them, which is not something a "delete on disable"
design could offer.
# The default an extension cannot express (ruled 2026-09-11)

The ruling makes the limiter a switchable extension, with DB_File its declared
dependency. Building it met the question the audit trail met the day before:
the registry lists what is ON, so an extension is off until someone enables it.
For the limiter that means **a new site has no login rate limiting until its
sysop turns it on, and an existing site loses it at the upgrade** unless the
upgrade enables it.

The audit trail answered this with its own setting (`audit_trail: off`, absence
is on) rather than an extension toggle. The limiter can go either way:

- **As the audit trail**: `login_rate_limit: off` in lazysite.conf, absence is
  on, DB_File stays a core dependency. Every site keeps the limiter; turning it
  off is explicit.
- **As an extension, enabled by the upgrade and by new installs**: DB_File
  becomes the extension's dependency as ruled; the upgrade adds it to every
  site's `plugins:` list once, and the starter conf lists it.

Either way, off stops counting and keeps no counter, and a switched-off limiter
says NOT in force in the same words, in the log and in `lazysite check`. The
per-account limiter is a separate design question and stays open.

## Ruled 2026-09-11: an extension, on by default - and built

The release manager chose the extension, on by default: DB_File becomes the
extension's dependency as the first ruling intended, and nobody loses rate
limiting by upgrading.

- `plugins/login-rate-limit.pl` is the unit: `contract`, `owns.deps: [DB_File]`,
  and no `storage` - a site package carries what that names, and a per-address
  counter in the auth store is nothing another site should receive. The
  sign-in CGI asks the registry through the one reader,
  `Lazysite::Manager::Plugins::plugin_enabled`.
- The installer lists it on a fresh install and on the first upgrade that
  carries it, and records `login-rate-limit-on` in the install state's `once`
  list. The name is the marker, not a version: a site reinstalled at the version
  that introduced the step is not stepped again, so an operator's off stays off.
- Off counts nothing and creates no counter, and says the limiter is NOT in
  force - in the log on each attempt and in `lazysite check` - in the same words
  as a limiter without DB_File or with an unopenable counter, each with its
  reason.

The first version of the test for "off" passed for the wrong reason: the
extension's name sat in a file-scope variable the CGI's main flow had not yet
reached, so the limiter read as off whatever the registry said. The "on" case
caught it; the name is a literal in the check now.
