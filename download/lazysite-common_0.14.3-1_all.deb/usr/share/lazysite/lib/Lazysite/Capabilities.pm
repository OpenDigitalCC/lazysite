package Lazysite::Capabilities;

# SM126: the machine-parseable capability map. One builder, consulted by the
# MCP `describe_capabilities` tool and the control-API `describe-capabilities`
# action (and, later, a static generated doc), so a connecting agent can learn
# up front what it may do and how - instead of discovering by trial and error.
#
# The channel/action split derives from @CAP_KEYS (the single source of truth in
# Auth::Settings), so a new capability appears here automatically. The per-action
# "unlocks" and the task recipes are curated here; t/unit/lib/05-capabilities.t
# cross-checks them against the live control-API %need and MCP %TOOLS maps so
# they cannot silently drift.

use strict;
use warnings;
use JSON::PP                 ();
use Lazysite::Util           ();
use Lazysite::Auth::Settings qw(@CAP_KEYS);
use Exporter 'import';
our @EXPORT_OK = qw(describe capability_keys reachability reach_for channel_keys action_keys channel_service action_channel_surface implied_by implications whoami_grant);

# The four channels (WHERE you operate). Fixed concept; the rest of @CAP_KEYS are
# actions (WHAT you may do).
my @CHANNELS   = qw(ui webdav api mcp);
my %IS_CHANNEL = map { $_ => 1 } @CHANNELS;

sub channel_keys    { return @CHANNELS }
sub action_keys     { return grep { !$IS_CHANNEL{$_} } @CAP_KEYS }
sub capability_keys { return @CAP_KEYS }

# Channel descriptions. All four are enforced at the transport (SM126): ui at
# login, webdav by webdav_enabled_for, api on the control-API token path, mcp on
# the MCP tools/call dispatch.
my %CHANNEL_INFO = (
    ui => 'Interactive manager UI over a browser cookie session.',
    webdav => 'The /dav publishing endpoint (files, themes, layouts). Also gates the per-file ACL actions on the control API (acl-get / acl-set / acl-remove) - alongside manage_content since SM431, because a capability that lets you CREATE gated content must let you inspect and set the rule governing it, on the same surface.',
    api =>
        'The token-authenticated control API (structured actions). Call '
        . '`action=actions-list` for the actions THIS account may use, with '
        . 'the parameters each takes and where each is read from - the '
        . "control API's equivalent of MCP's tools/list (SM350). This map "
        . 'says what you may do; that says what you may call.',
    mcp => 'The MCP connector (Claude.ai / ChatGPT / Code tools).',
);

# SM180: each CHANNEL capability only DOES anything while its site service is
# enabled - the two planes (per-principal grant, per-site killswitch) are
# independent, so a grant can be dormant. This is the map from a channel to the
# lazysite.conf key that gates it: 'ui' by the `manager` key, the three remote
# channels by their *_enabled flags. The manager consults it to flag a
# granted-but-dormant capability (service off) in the Groups/Users grids. Single
# source of truth: surfaced in describe() and read by the control API.
my %CHANNEL_SERVICE = (
    ui     => 'manager',
    webdav => 'webdav_enabled',
    api    => 'control_api_enabled',
    mcp    => 'mcp_enabled',
);
sub channel_service { return {%CHANNEL_SERVICE} }

# Action capabilities: a title and what holding it unlocks, per channel. The
# lists name real MCP tools, control-API actions, or WebDAV path shapes; the
# consistency test keeps the tool/action names honest against the live maps.
my %ACTION_INFO = (
    manage_content => {
        section => 'Content',
        title   => 'Read and write site content (pages, assets).',
        grants => 'Create, edit, move and delete pages and assets, and set who may read them. Over WebDAV it is direct file access to the content tree.',
        unlocks => {
            api => [ qw(aliases-list git-status git-history git-history-summary
                    git-show git-restore lang-status site-export-primary
                    regenerate-registries preview-public
                    acl-get acl-set acl-remove
                    data-table-acl-get data-table-acl-set data-table-acl-remove
                    brief-read briefs-list
                    nav-read page-pdf pages) ],
            mcp => [ qw(list_files read_file write_file upload_file replace_text copy_file
                    move_file delete_file create_page delete_page rename_page
                    list_pages read_page preview_page page_status search_files
                    validate_page invalidate_cache regenerate_registries read_nav audit_site create_form
                    get_permissions set_permissions read_brief
                    list_briefs
                    list_versions list_content_history view_version restore_version preview_public_page)
            ],
            webdav => ['write anywhere in the content namespace (within dav_scope)'],
        },
    },
    manage_nav => {
        section => 'Content',
        title   => 'Edit site navigation.',
        grants => 'Edit the site\'s navigation - what appears in the menu, and in what order.',
        # SM568: nav-read and pages are reads a content author needs as much
        # as a nav editor, so manage_content admits them too (the MCP twins
        # read_nav and list_pages sit under manage_content). Listed under
        # both, as form-submissions is under manage_forms and read_submissions.
        unlocks => {
            api => [qw(nav-read nav-save pages)],
            # SM654 (U-3): read_nav declares cap => 'manage_nav' in %TOOLS, the
            # gate admits it, and it returns the nav - and this said set_nav
            # only. Measured by the site agent; t/lint/90 now refuses the shape.
            mcp    => [qw(set_nav read_nav)],
            webdav => ['lazysite/nav.conf'],
        },
    },
    manage_forms => {
        section => 'Content',
        # SM618: the title said what this capability CONFIGURES and stayed
        # silent on what it READS, while the sentence it did spend words on -
        # that the notification never carries content - reads as a reassurance
        # about the grant. It is a statement about the BELL. `form-submissions`
        # WAS gated on [manage_forms, read_submissions], either admitting - so
        # this grant returned live submission bodies. SM652 narrowed it to
        # read_submissions on both channels; the measurement below is what that
        # capability now hands over, not this one. Measured on edge
        # 2026-08-26: name, email, phone, message and the submitter's IP, under
        # a capability a sysop grants to let an agent wire up a form.
        # SM594/SM652: THIS TEXT WAS STALE AND OVERSTATED THE GRANT. SM652
        # narrowed form-submissions to read_submissions on both channels and
        # updated the comment above while leaving the title saying this
        # capability "returns live submission CONTENT". It is the sentence an
        # operator reads when deciding whether to hand this over, and it
        # described a reach the grant had stopped having - the direction that
        # causes over-granting, since a sysop reading it would reach for
        # read_submissions when manage_forms would have done.
        title => 'Wire forms to delivery handlers - which handlers a form '
            . 'calls - and configure the email and file handlers. This '
            . 'grant does NOT read submissions - SM652 narrowed '
            . '`form-submissions` and `form-list` to `read_submissions` on '
            . 'every channel, so an agent that processes leads needs that '
            . 'capability and this one only changes how forms are wired. '
            . 'SM660: deleting or confirming a submission needs BOTH, because '
            . 'destroying what you may not read is not a coherent grant. '
            . 'A submitted form also raises an '
            . 'sysop notification of its own accord (the manager bell, plus chat '
            . 'where notify-xmpp is configured) naming the form and the time but '
            . 'never the content - so nothing needs to poll to learn that something '
            . 'arrived. See /docs/forms.',
        # SM457: the API list was MISSING, and its absence sent a real
        # operator's agent guessing.
        #
        # form-submissions needs read_submissions (SM652 narrowed it from
        # [manage_forms, read_submissions], where either admitted).
        # read_submissions advertises it correctly; this one advertised no api
        # key at all, so a partner
        # holding manage_forms was told about MCP tools and a WebDAV path and
        # nothing about the control API, while enforcement let them straight
        # in. They tried describe_capabilities, list_form_handlers, forms,
        # form_submissions, list_submissions and submissions - six names, none
        # of them real, four of them snake_case guesses at a kebab-case
        # surface and two of them MCP tool names aimed at the API.
        #
        # SM842: THE GRANT NO LONGER NAMES A NEW DESTINATION. It used to reach any
        # URL through an inline form target; inline targets are gone, and
        # outbound HTTP goes through a connector, which is manage_connectors'.
        # What this grant configures is email and file delivery, and which
        # existing handlers a form calls.
        grants => 'Choose which handlers each form calls, and create, change and delete the email and file handlers - whose settings name the address mail goes to and the store a submission is kept in. A table handler needs manage_data and a connector handler manage_connectors. It does not read what was submitted; read_submissions does.',
        # SM435 was this defect pointed the other way: the descriptor CLAIMED
        # a path enforcement refused. Under-claiming is the quieter failure -
        # nothing 403s, nothing errors, the agent simply cannot find a door it
        # is holding the key to.
        unlocks => {
            # SM632: form-delete/delete_form are the inverse of bind_form.
            # Declared on both surfaces at the same time, because a capability
            # that advertises the create and not the destroy is how an agent
            # concludes the object is permanent (t/lint/71, t/lint/23).
            # SM652: form-submissions and form-list are GONE from here - they
            # need read_submissions on both channels now, and a map that still
            # advertised them would tell a holder it can do something the gate
            # refuses. That is the same stale claim SM652's own test caught in
            # form_list's MCP description.
            # SM842: the handler actions are gated ANY-OF the three destination
            # capabilities (then the handler's type decides), so all three
            # name them - SM457's rule for cross-gated actions.
            api => [ qw(form-delete form-targets-read form-targets-save
                    handler-list handler-save handler-delete
                    schedule-list schedule-save schedule-delete) ],
            mcp => [ qw(bind_form delete_form list_handlers save_handler delete_handler
                    list_schedule save_schedule delete_schedule) ],
            webdav => ['lazysite/forms/<name>.conf (its targets name existing handlers; not smtp.conf, handlers.conf or schedule.conf)'],
        },
    },
    manage_themes => {
        section => 'Appearance',
        title   => 'Install and activate themes.',
        grants => 'Install, author and activate themes, which decide how every page on the site looks.',
        unlocks => {
            # SM457: these are gated on [manage_themes, manage_layouts] -
            # EITHER admits - so both must name them. A partner holding only
            # one was admitted and never told.
            api => [ qw(theme-activate theme-copy theme-list themes-for-layout themes-list-all
                    artifact-manifest artifact-validate preview-grant theme-delete
                    layouts-available layouts-manifest) ],
            mcp => [qw(list_themes theme_tokens activate_theme create_theme copy_theme delete_theme)],
            webdav => ['lazysite/layouts/<layout>/themes/<theme>/ (active theme read-only)'],
        },
    },
    manage_layouts => {
        section => 'Appearance',
        title   => 'Install, author and activate layouts.',
        grants => 'Install, author and activate layouts, which decide the shape of every page on the site.',
        unlocks => {
            # SM457: as above - cross-gated actions belong on both lists.
            api => [ qw(layout-activate layout-install layout-delete layouts-available
                    layouts-manifest
                    artifact-manifest artifact-validate preview-grant
                    theme-list themes-for-layout themes-list-all) ],
            mcp => [qw(activate_layout install_layout delete_layout list_layout_catalogue)],
            webdav => ['lazysite/layouts/<layout>/ (active layout read-only)'],
        },
    },
    manage_domains => {
        section => 'Site',
        title   => 'Manage the domains this instance serves, and portable site packages.',
        grants => 'Add and remove the domains this instance serves, and export or apply a whole site as a package.',
        unlocks => {
            api => [ qw(domains-list domain-add domain-set domain-remove
                    domain-preview domain-check remap-list remap-save
                    site-backup-create site-backup-download site-backup-upload
                    site-backup-apply site-backup-delete site-backup-inspect) ],
            mcp => [qw(list_domains domain_set preview_domain site_backup site_apply)],
        },
    },
    # SM447 / ADR 0009. DECLARED BY plugins/data.pl and mirrored here; the
    # plugin is the owner and t/lint/76 refuses a mirror with no plugin
    # claiming it, or one claimed twice.
    #
    # THE UNLOCK LISTS ARE EMPTY AND THAT IS ACCURATE. The typed core is built
    # and nothing routes to it yet: no control-API action and no MCP tool is
    # gated on this capability. Granting it today therefore admits an account
    # to nothing, which is honest - what it must never do is CLAIM actions that
    # do not exist, which is SM457's defect pointed the other way and the one
    # t/lint/71 exists to catch.
    # SM682: row-write on NAMED tables, and nothing else.
    #
    # manage_data is all-or-nothing: it carries table create, alter and drop AND
    # read/write across every table on the instance. An app with external,
    # semi-trusted users - a learner submitting their own work - had two options
    # and both were wrong: hand instance-wide data administration to the least
    # trusted user class, or collect nothing.
    #
    # `writable_by` MEANS SOMETHING DIFFERENT FOR THIS CAPABILITY, and that is
    # what makes it safe rather than a rename of the problem:
    #
    #   manage_data + empty list  -> may write (unchanged)
    #   manage_data + a list      -> may write only if in it (unchanged, narrows)
    #   write_data  + empty list  -> may NOT write
    #   write_data  + a list      -> may write only if in it
    #
    # For manage_data the list NARROWS; for this one it is an ALLOW-LIST. A
    # table naming nobody is closed to a write_data holder - otherwise this
    # would be instance-wide write under a new name, which is the thing being
    # fixed.
    #
    # The descriptor is still NOT a grant. `data-table-save` is gated on
    # manage_data, so an agent holding it can edit the list - but it cannot
    # invent write_data, which comes from the group store where an operator put
    # it under SM195's ceiling. The most such an agent can do is widen a group
    # the operator already trusted with row-writes elsewhere, and SM682 records
    # the SM647 remedy for that residue.
    write_data => {
        section => 'Data',
        title   => 'Write rows in data tables that name your group, and nothing else.',

        # SM740: a HIERARCHY, declared. manage_data admits every action this
        # unlocks (the gate is ANY-OF, SM662), so an account holding manage_data
        # loses nothing when this is withheld - and two sibling booleans in
        # whoami said otherwise. The field read them as a partition, withheld
        # this to stop row writes, and watched a row land. Declared here, not
        # derived from the unlock lists: manage_services' one unlock is also in
        # manage_config's and is NOT implied (config-set needs both for a
        # service key - an AND), so subsumption alone would lie. t/lint/117
        # holds that a declaration is true and that every undeclared
        # subsumption is exempted with its reason.
        implied_by => ['manage_data'],
        grants     =>
            'Insert, update and delete ROWS in the data tables whose `writable_by` names one of your groups - and no others. It does NOT declare, alter, migrate or drop a table, and it reaches no table that does not name you. Grant this to an app\'s own users where `manage_data` (every table on the instance, plus schema control) would be far too wide.',
        unlocks => {
            api => [qw(data-row-save data-row-delete)],
            mcp => [qw(save_data_row delete_data_row)],
        },
    },

    # SM579 phase 1: WHERE THE SITE'S DATA GOES. A connector is a credentialed
    # destination that forms, callers and jobs send through; creating one
    # names a place site data is disclosed to and holds a secret for it.
    # That is a conferral in the SM647/SM682 sense - authority over the data,
    # not over pages - so it is its own capability and not part of
    # manage_config. Invoking a connector (mode 2) is gated by the connector's
    # own `callers` groups, or this capability.
    manage_connectors => {
        section => 'Site',
        title => 'Configure connectors: where site data may be sent, with what credential, by whom, how often.',
        grants =>
            'Create, change and delete connectors (a destination URL, the header its secret travels in, the modes it permits, the groups that may call it, its rate cap, the table its answers land in), set their secrets, read the record of every call, and call any connector. A connector reachable from a public form is opt-in on the connector and never the default. Every call is one audit row naming the connector, the trigger, the mode and the class of data - never the payload.',
        unlocks => {
            # connector-call is NOT here: the connector gates it (callers
            # groups, or this capability) and the API gate admits any
            # logged-in caller to the action, so the map may not claim it.
            api => [ qw(connector-list connector-save connector-secret-set connector-delete connector-calls
                    handler-list handler-save handler-delete form-targets-read
                    schedule-list schedule-save schedule-delete) ],
            # SM842: a connector handler is this capability's to configure.
            mcp => [qw(list_handlers save_handler delete_handler list_schedule save_schedule delete_schedule)],
        },
    },
    manage_data => {
        section => 'Data',
        title   => 'Read and write the site\'s data tables.',
        grants => 'Read and write every data table on this instance, and declare new ones. A table that names no domain is reachable by any holder, on any site here.',
        unlocks => {
            api => [
                qw(handler-list handler-save handler-delete form-targets-read
                    schedule-list schedule-save schedule-delete
                    data-tables data-table data-table-save data-rows
                    data-migrate data-rebuild data-row-save data-row-delete
                    data-export data-import data-table-source data-migrate-plan
                    data-safety-exports
                    data-safety-export-read data-safety-export-restore)
            ],

            mcp => [
                qw(list_handlers save_handler delete_handler list_schedule save_schedule delete_schedule
                    list_data_tables describe_data_table save_data_table
                    read_data_rows migrate_data_table rebuild_data_table
                    save_data_row delete_data_row
                    list_data_safety_exports
                    read_data_safety_export restore_data_safety_export
                    read_data_table_source plan_data_migration)
            ],
            # NO WEBDAV ENTRY, and this used to claim one. WebDAV allows
            # only lazysite/layouts/ - "the rest of lazysite/ is protected" -
            # so `lazysite/db/tables/<table>.yaml` was a path this capability
            # advertised and the front door refused. That is SM435's defect
            # exactly, and t/lint/68 exists for it on this plane. Descriptors
            # are written through data-table-save / save_data_table, which
            # validate before storing.
        },
    },
    # SM576 part 1: DECLARED BY plugins/briefs.pl and mirrored in @CAP_KEYS,
    # the manage_data pattern (ADR 0009), so that writing another principal's
    # authoring record is a grant of its own rather than a side effect of being
    # allowed to edit pages - which is what SM575 measured happening.
    #
    # THE READS ARE LISTED TWICE ON PURPOSE. brief-read / briefs-list appear
    # here AND under manage_content, because the gate admits either: the
    # migration keeps brief reads with a long-standing manage_content grant and
    # moves only the writes. A capability's unlocks list states what holding it
    # gives you, not what it exclusively gives you (manage_nav's nav-read and
    # manage_forms' form-submissions are listed twice for the same reason).
    manage_briefs => {
        section => 'Content',
        title => 'Write authoring briefs - the "why" record kept beside a content file. '
            # SM654 (R-18): this said DELETING needs manage_briefs. It needs
            # `purge` - brief-delete is gated on it because no copy survives
            # (SM591), and the map immediately below says so correctly. A title
            # contradicting the map beside it is the same hand-kept drift as the
            # unlocks omissions, in prose rather than in data.
            . 'Reading a brief is also admitted by manage_content; creating and '
            . 'appending to one needs this. DELETING a brief needs `purge`, not '
            . 'this capability, because no copy survives it. Declared by the '
            . 'briefs plugin, so it is grantable only where that plugin is '
            . 'installed.',
        grants => 'Read and write authoring briefs - the record of WHY a page is as it is. Does not reach the page itself.',
        unlocks => {
            api => [qw(brief-read brief-append briefs-migrate briefs-list)],
            mcp => [qw(read_brief append_brief list_briefs)],
        },
    },
    run_jobs => {
        section => 'Operations',
        title   => 'Be the account the scheduler runs timed jobs as. This is not '
            . 'permission to DO anything in particular - a job\'s own action '
            . 'faces the ordinary capability gate unchanged, so an account '
            . 'holding only this can carry a job and still be refused the work. '
            . 'It is the separate question of whether an account may be used by '
            . 'the runtime at all, asked so that a job cannot be attached to an '
            . 'account nobody meant to carry one. A job never runs as `system`, '
            . 'because a timer that can call anything is a second write plane '
            . 'wearing a clock. Declared by the daemon plugin, so it is '
            . 'grantable only where that plugin is installed.',
        grants => 'Lets the persistent runtime act as this account when it runs a scheduled job. It confers no ability of its own - whatever the job does still needs the capability for that action, and every run is recorded against this account by name.',
        unlocks => {},
    },
    # SM591: THE LATERAL GRANTS. Deletion and tidying are the same job wherever
    # they happen, so they answer these rather than the module capability that
    # lets a partner USE the module. Which tier an action joins is SM587's copy
    # test and nothing else - see the rule beside %MUTATING / %DESTRUCTIVE /
    # %CHANGES_ACCESS in lazysite-manager-api.pl, which is where an action is
    # classified.
    #
    # THE ACL VERBS ARE DELIBERATELY ABSENT. acl-set, acl-remove, preview-grant
    # and preview-clear stay under manage_content / manage_themes /
    # manage_layouts, carrying SM587's `changes_access` flag. Folding them in
    # here would mean whoever may clear old backups may also un-gate content -
    # a sysop who wanted a housekeeper handing over the permission surface.
    # Housekeeping and permission management are different jobs.
    housekeeping => {
        section => 'Operations',
        title   => 'Destroy things the engine keeps a copy of. The RECOVERABLE tier of '
            . 'the housekeeping grant: a drop mints a safety export of every row before '
            . 'anything goes, so the object is gone and the data is not. Granting a '
            . 'module capability lets a partner USE that module; this is what lets them '
            . 'destroy inside it, which are two different decisions.',
        grants => 'Delete things the engine keeps a copy of - drop a data table, clear an old backup. Recoverable: the safety export survives a table drop. Deleting that export is `purge`, which is a separate grant.',
        unlocks => { api => [qw(data-table-drop)], mcp => [qw(drop_data_table)] },
    },
    purge => {
        section => 'Operations',
        title   => 'Destroy things NO copy survives. The IRREVERSIBLE tier: deleting a '
            . 'safety export is what makes an earlier table drop permanent, and deleting '
            . 'a brief or a backup ends the only record there was. Held separately from '
            . '`housekeeping` and not implied by it. SM577: A BACKUP STORE IS '
            . 'INSTANCE-WIDE - one instance serves many domains from one backups '
            . 'directory, so this reaches archives of OTHER sites on the same instance '
            . 'and a deletion is NOT scoped by the site whose grant authorised it.',
        grants => 'Destroy things NO copy survives: a safety export, a brief, a backup. The backup store is instance-wide, so this reaches other sites\' archives on the same instance.',
        unlocks => {
            api => [qw(brief-delete data-safety-export-delete artifact-backups-delete)],
            mcp => [qw(delete_brief delete_data_safety_export)],
            # Cookie-only on the API (see Actions.pm), so it is named on the
            # surface that serves it. A capability claiming it under `api` would
            # send a token client after a door that is not there.
            ui => ['the manager Backups page: backup-delete (instance-wide store)'],
        },
    },
    manage_config => {
        section => 'Site',
        title   => 'Read and set safe site configuration.',
        grants => 'Read and change ordinary site settings - title, cache lifetime, search defaults, the active layout and theme. The switches that decide whether the remote surfaces answer at all are `manage_services`, held separately.',
        # SM435: this listed lazysite/nav.conf and lazysite/forms/<name>.conf
        # over WebDAV, which 0.8.1 moved to manage_nav and manage_forms
        # respectively - see authorise() in lazysite-dav.pl, which admits
        # neither of them under this capability. Both new entries were written
        # and this one was never trimmed, so the descriptor promised a partner
        # holding manage_config alone a write it would be refused. Nothing was
        # over-permitted; enforcement was always the strict side. The cost was
        # that the descriptor is the ONE per-capability account of the boundary
        # readable from outside the code, so being wrong sent an agent to a 403
        # and then to trial and error - which is what RI-002's deny reasons
        # exist to end. t/lint/68 now checks the two against each other.
        unlocks => {
            # SM664: git-history-summary is reachable with manage_content OR
            # manage_config, so BOTH capabilities claim it. Listing it only
            # under manage_content left this map under-claiming - a holder of
            # this capability could call the action and nothing said so, which
            # is the half of SM654 a lint does not catch (it refuses
            # over-claiming, not silence).
            api => [ qw(config-read config-set git-init bad-url-blocks bad-url-block bad-url-unblock
                    git-history-summary) ],
        },
    },

    # SM633: the switches that decide whether anyone can reach the instance at
    # all are a different size of decision from the site's title and its cache
    # lifetime, and they sat under one capability whose own name says "SAFE".
    #
    # SM612 closed the sharpest edge - a token can no longer switch off the
    # manager surface that would revoke it - by restricting `manager` and
    # `manager_path` to the cookie channel. That was a fix at the KEY level.
    # This is the LOCK being the right shape: an operator can now hand a partner
    # the ability to tune caching without handing it the ability to turn WebDAV
    # off for everyone.
    manage_services => {
        section => 'Site',
        title   => 'Switch the remote surfaces on and off (WebDAV, MCP, OAuth, '
            . 'the control API, the pairing-key exchange).',
        grants => 'Turn the site\'s remote surfaces on or off. Switching one '
            . 'off does not narrow a grant - it stops the surface answering for '
            . 'EVERYONE, including partners and agents already using it, and the '
            . 'manager UI is unaffected.',
        unlocks => { api => [qw(config-set)] },
    },
    manage_users => {
        section => 'Accounts',
        title   => 'Manage user accounts and group membership.',
        grants => 'Create and delete accounts, and change who belongs to which group - including what those groups may do. Manager UI only: no remote surface offers it.',
        unlocks => { ui => ['the manager Users and Groups pages'] },
    },
    analytics => {
        section => 'Insight',
        title   => 'Read sanitised, IP-anonymised visitor analytics.',
        grants => 'Read this site\'s visitor figures. They are sanitised and IP-anonymised before this capability sees them, so they cannot identify an individual visitor.',
        unlocks => { api => [qw(analyse_visitors)], mcp => [qw(analyse_visitors)] },
    },
    # N13-04, ruled 2026-09-10 and 2026-09-11: THE AUDIT TRAIL'S SWITCH IS NOT
    # SITE CONFIGURATION. Turning the trail off is a different authority from
    # configuring a site, so it does not travel with manage_config - the switch
    # needs manage_config AND this. It sits in a group of its own
    # (cap-audit-switch), which no role draws on by default: nobody can silence
    # the trail until an administrator decides somebody should. Reading the
    # trail is `audit`, a different grant in a different group.
    audit_switch => {
        section => 'Operations',
        title   => 'Switch the audit trail off and on again. Always recorded: the '
            . 'switch-off is written to the trail, naming who, before it stops, and '
            . 'the switch-on as it resumes - so the gap has named edges.',
        grants => 'Switch the audit trail off and on (audit-trail-set), together with Site config. Off stops recording and keeps everything already recorded. Granted to no role by default.',
        unlocks => { api => [qw(audit-trail-set)] },
    },
    audit => {
        section => 'Insight',
        # SM618: measured on edge 2026-08-26 under a grant holding `analytics`
        # + `audit` and nothing else - 93 pages, six distinct actors, 180 full
        # IPv4 dotted-quads in 192 sampled entries, and origins `ui`, `cli` and
        # `install`, which are the OPERATOR's own sessions rather than partner
        # traffic. The engine states `scoped: false` in the reply itself.
        #
        # The reach is SANCTIONED, on `purge`'s SM577 precedent: an agent asked
        # "what changed here, and who changed it" needs the whole trail, and a
        # redacted one answers less. What was wrong is that `purge` SAYS SO and
        # this did not. It sat beside `analytics` - which promises anonymisation
        # in its own title and keeps that promise - so the pair invited exactly
        # the wrong inference: that the trail read is at least as careful with
        # personal data as the visitor read. It is the opposite, and an operator
        # learned that only by granting it.
        title => 'Read the append-only audit trail. SM618: THE TRAIL IS '
            . 'INSTANCE-WIDE and is NOT scoped by the grant that authorised the '
            . 'read - one instance serves many domains into one trail, so this '
            . 'reaches entries for OTHER sites, and every entry names the actor '
            . 'and carries a RAW source IP, the sysop\'s own manager, '
            . 'command-line and install sessions among them. Sanctioned '
            . 'instance-wide for the same reason as `purge`. Its sibling '
            . '`analytics` is the sanitised, anonymised read; this one is '
            . 'neither, and the two sit together deliberately.',
        grants => 'Read the WHOLE INSTANCE\'s audit trail - every action, the account behind it, and the raw source IP it came from, including your own manager, command-line and install sessions. It is not scoped to one site.',
        unlocks => { api => [qw(audit)] },
    },
    notifications => {
        section => 'Insight',
        title => 'See sysop notifications (the manager bell: new form submissions, requests awaiting a response).',
        grants => 'See the sysop bell - new submissions and requests awaiting an answer. It names the form and the time, never the content.',
        # SM281 item 3: it unlocked a manager page and nothing else - a
        # capability with no remote surface, which is an SM239 parity gap and
        # the reason remote agents had been editing a shared briefing document
        # to talk to each other. `notices` is READ; emission stays SM231's.
        unlocks => {
            ui  => ['the notifications bell + unread badge in the manager header'],
            api => ['notices'],
        },
    },
    feedback => {
        section => 'Insight',
        title => 'Submit agent feedback over MCP. Off by default: the operator opts a group in so an agent may write to lazysite/feedback/ and notify the operator.',
        grants => 'Write files into lazysite/feedback/ and raise an operator notification. Off unless an operator opts the group in.',
        unlocks => { mcp => [qw(submit_feedback)] },
    },
    read_submissions => {
        # SM758 follow-up (133E-03): an operator hunting for who may READ what
        # visitors sent looks under Insight, not Content - the field said so.
        section => 'Insight',
        title => 'Read form submissions over the API/MCP. A least-privilege, read-only grant for an agent that processes form leads - it does NOT include managing form configs (that is manage_forms). Off by default.',
        grants => 'Read what visitors have submitted through forms - whatever each form collects, with the submitter\'s IP address. Read-only: it cannot change where submissions go.',
        unlocks => { api => [qw(form-submissions form-list)], mcp => [qw(read_form_submissions form_list)] },
    },
    create_sub_users => {
        section => 'Accounts',
        title   => 'Create sub-accounts under your own account.',
        grants => 'Create accounts beneath this one. A sub-account cannot be given capabilities its creator does not hold, or reach further than its creator reaches.',
        unlocks => { ui => ['sub-user creation'] },
    },
    delegate_sub_user_creation => {
        section => 'Accounts',
        title   => 'Grant sub-accounts the ability to create their own sub-users.',
        grants => 'Let the accounts this group creates make sub-accounts of their own, so delegation continues one level further without a sysop.',
        unlocks => { ui => ['onward delegation of sub-user creation'] },
    },
);

# SM197: the per-action channel SURFACE - which channels a capability actually
# exposes something on, derived from the keys of its `unlocks` map. The manager's
# permission grid consults this so a capability x channel cell is ticked only
# where the capability has a REAL surface on that channel (e.g. manage_domains on
# api+mcp, not webdav), rather than merely "granted AND channel held". Same single
# source of truth as describe(); a new capability's surface appears automatically.
sub action_channel_surface {
    my %surface;
    for my $cap ( action_keys() ) {
        my $u = $ACTION_INFO{$cap}{unlocks} || {};
        $surface{$cap} = { map { $_ => 1 } grep { @{ $u->{$_} || [] } } keys %{$u} };
    }
    return \%surface;
}

# Engine-owned paths: protected surface an agent must NOT try to write (the DAV
# blocklist / whole-lazysite denial already enforce this - this list makes the
# boundary legible so an agent uses the API instead of hunting for a workaround).
my @ENGINE_OWNED = (
    'lazysite/auth/**  (credentials, tokens, TOTP seeds, HMAC secret)',
    'lazysite/cache/** (generated HTML cache)',
    'lazysite/forms/smtp.conf, lazysite/forms/handlers.conf (delivery secrets)',
    'lazysite/manager/** (manager UI internals)',
    'cgi-bin/**, *.pl   (the engine scripts)',
);

# Task recipes: the sanctioned sequence for common jobs, machine-readable so an
# agent can plan without prose. The human quickstarts (Phase B) are the twins.
my @TASKS = (
    { id => 'install-theme', title => 'Install and activate a theme',
        requires => ['manage_themes'],
        steps    => [
            'PUT the theme files under lazysite/layouts/<layout>/themes/<name>/ over WebDAV (or use the MCP write_file tool on those paths)',
            'call activate_theme (MCP) or POST action=theme-activate (control API)',
        ],
    },
    { id => 'author-layout', title => 'Author and activate a layout',
        requires => ['manage_layouts'],
        steps    => [
            'PUT layout files (view.tt, components) under lazysite/layouts/<name>/ over WebDAV',
            'call activate_layout (MCP) or POST action=layout-activate (control API)',
        ],
    },
    { id => 'switch-layout', title => 'Switch the site to a different layout',
        requires => ['manage_layouts'],
        steps    => [
            'call list_layout_catalogue (MCP) or GET action=layouts-manifest (control API) to see what is available and installed',
            # SM348: this said "it installs AND activates the new layout in one
            # step". SM314 corrected the TOOL to say installing does not
            # activate, and left this - so the document an agent reads FIRST
            # contradicted the tool it was describing, and an agent following
            # this sequence would install a layout, believe the site had
            # switched, and find it unchanged.
            #
            # Two steps now, because it is two operations. SM176's reasoning
            # holds: activating is the part that changes what visitors see, so
            # it is always asked for explicitly.
            'call install_layout (MCP) or POST action=layout-install (control API) - this places the layout on the site and changes NOTHING a visitor sees',
            'call activate_layout (MCP) or POST action=layout-activate (control API) - this is the step that switches the live site. The response says whether the layout renders the site navigation and page body (SM337); a layout that renders no [% nav %] is activated anyway and warns, because a showcase layout is a legitimate choice',
            'ONLY THEN, if the old layout is no longer wanted: delete_layout / layout-delete. Deleting the ACTIVE layout is always refused - install/activate the replacement first, never delete first',
        ],
    },
    { id => 'restore-from-history', title => 'Undo a content change (restore a recorded version)',
        requires => ['manage_content'],
        steps    => [
            'call list_versions (MCP) or GET action=git-history (control API) for the file - needs the site\'s Content history plugin enabled',
            'call view_version / git-show to confirm the version (content + diff against the current file)',
            'call restore_version / git-restore - the historic content is saved back through the normal save path and the restore itself becomes the newest version, so nothing is lost',
        ],
    },
    { id => 'publish-page', title => 'Publish a page',
        requires => ['manage_content'],
        steps    => [
            'create the page with the MCP create_page tool, or PUT the .md over WebDAV in the content namespace',
            'optionally preview_page (MCP) to confirm the render before it goes live',
        ],
    },
    { id => 'build-from-figma', title => 'Build or restyle a site from a Figma design',
        requires => [ 'manage_themes', 'manage_layouts', 'manage_content' ],
        steps => [ 'Read /docs/integrations/figma for the extraction + translation sequence',
            'Connect the Figma MCP server alongside the lazysite connection; run whoami on both',
            'Extract tokens/structure/screenshots via the Figma MCP (get_metadata, get_variable_defs, get_screenshot)',
            'Map design tokens onto the layout vocabulary (theme_tokens) and rebuild rhythm/scale in CSS',
            'Adapt the nearest layout (copy-and-stage) or scaffold a theme (create_theme)',
            'Verify with preview_page before activating' ] },
    { id => 'wire-form', title => 'Wire a form to a handler',
        requires => ['manage_forms'],
        steps    => [
            'call list_handlers (MCP) or handler-list (control API) to see the handlers',
            'call bind_form (MCP) or form-targets-save (control API), or PUT lazysite/forms/<name>.conf over WebDAV, naming existing handlers - never a destination',
            'a handler that does not exist yet is made with save_handler / handler-save, and the destination decides the capability: manage_forms for email or file, manage_data for a table, manage_connectors for a connector',
        ],
    },
    { id => 'migrate-site', title => 'Migrate a site (package one domain and apply it elsewhere)',
        requires => ['manage_domains'],
        steps    => [
            'ON THE SOURCE: call site_backup (MCP) or POST action=site-backup-create (control API) with the domain host - this writes a portable package (lazysite-site-<host>-<stamp>.tar.gz) holding that domain\'s content + nav + its theme/layout + a manifest. It excludes plugins, instance settings and secrets, so it is safe to hand over',
            'MOVE THE PACKAGE to the target instance if different: GET action=backup-download to fetch it, then POST action=site-backup-upload (multipart) on the target to import it into that instance\'s backups area. Same-instance moves skip this - the package is already there',
            'BEFORE APPLYING, make sure the target domain exists (register it with domain-add if needed) and, if you want a rollback point, take a backup - apply overwrites the target content root',
            'ON THE TARGET: call site_apply (MCP) or POST action=site-backup-apply (control API) with the package name and the target host (omit host to apply to the default site; pass clean:true to clear the target content first). This copies the content in, installs the bundled theme/layout if the target lacks it, places the nav, and sets the target domain\'s presentation. The control-API action also takes a safety snapshot automatically',
            'verify with a domain preview (domain-preview) or by loading the target host',
        ],
    },
);

# SM225: the documentation index. A partner told to "call this first" learns the
# capability model and nothing about the ~30 documentation pages the site
# publishes, so it reasons from the tool surface alone and reinvents documented
# behaviour (or concludes a feature is absent). The index is DERIVED, not curated:
# a scan of {DOCROOT}/docs reading each page's own `title:` / `subtitle:` front
# matter, so a site that adds or removes a doc reports the truth instead of a
# hard-coded list going stale. Briefings are listed first because an agent should
# read those before designing anything; everything else is reference.
#
# Top-level pages only. Subtrees (docs/features/, docs/integrations/) are reached
# from the pages that cite them, and enumerating them here would bury the entry
# points the index exists to surface.
sub _doc_meta {
    my ($path) = @_;
    open my $fh, '<', $path or return;
    my ( $title, $subtitle );
    my $n = 0;
    while ( my $line = <$fh> ) {
        last if ++$n > 20;
        if ( $line =~ /^title\s*:\s*(.+?)\s*$/ )    { $title    = $1 }
        if ( $line =~ /^subtitle\s*:\s*(.+?)\s*$/ ) { $subtitle = $1 }
        last if defined $title && defined $subtitle;
    }
    close $fh;
    for ( $title, $subtitle ) {
        next unless defined;
        s/\A(["'])(.*)\1\z/$2/;    # front matter may quote the value
    }
    return ( $title, $subtitle );
}

sub _scan_docs {
    my ($docroot) = @_;
    return unless defined $docroot && length $docroot;
    my $dir = "$docroot/docs";
    return unless -d $dir;
    opendir my $dh, $dir or return;
    my ( @briefings, @reference );
    for my $f ( sort readdir $dh ) {
        next unless $f =~ /\A([A-Za-z0-9][A-Za-z0-9._-]*)\.md\z/;
        my $slug = $1;
        next unless -f "$dir/$f";
        my ( $title, $subtitle ) = _doc_meta("$dir/$f");
        next unless defined $title && length $title;
        my %entry = ( path => "/docs/$slug", title => $title );
        $entry{answers} = $subtitle if defined $subtitle && length $subtitle;
        push @{ $slug =~ /^ai-briefing-/ ? \@briefings : \@reference }, \%entry;
    }
    closedir $dh;
    return unless @briefings || @reference;
    return {
        note =>
            'The site publishes its own documentation. Read the briefings before '
            . 'designing anything - they answer most questions about what lazysite '
            . 'can do, and a capability you cannot see may be documented rather '
            . 'than absent. Every path below is a public page you can fetch '
            . 'without a credential.',
        briefings => \@briefings,
        reference => \@reference,
    };
}

# SM226: why each entry in `holds` reads the way it does. A false is always the
# same story - the capability exists and was not granted - and saying so is what
# stops a reader treating it as absence. The case worth real explanation is the
# opposite one: a channel capability that IS granted while its site service is
# off, which today renders as a bare true and does nothing. `capabilities` and
# `holds` disagreeing with observable behaviour is exactly the confusion this
# block exists to remove. Needs a docroot to read the killswitches; without one
# the dormancy answer is simply omitted rather than guessed.
# SM740: the declared hierarchy. implied_by($cap) lists the capabilities that
# admit everything $cap unlocks; implications($caps) says, for an account, which
# withheld capabilities are nonetheless satisfied and by what - so whoami can
# print a false that does not read as a withholding.
sub implied_by {
    my ($cap) = @_;
    my $i = ( $ACTION_INFO{$cap} || {} )->{implied_by} || [];
    return @$i;
}

# SM821: WHAT AN ACCOUNT MAY DO, AND WHAT IT IS - APART, AND THE SAME ON EVERY
# SURFACE. Takes the account's resolved settings (Lazysite::Auth::Verify::
# effective_settings - what both whoamis start from) and returns
# ( capabilities => {...}, account => {...} ).
#
# `capabilities` is exactly @CAP_KEYS, as booleans. `ui` among them is the
# CAPABILITY - manager access granted by a group - which the settings map calls
# `manager_ui`, because its own `ui` is a different thing: whether the account
# may sign in interactively. The two sat side by side under one name each, with
# opposite values on an ordinary partner account, and read as a contradiction.
# That setting is `account.interactive_login` here.
#
# `account` is everything else the map carries - the record, not the grant:
# groups, email, provenance, token and MFA state, scopes. MCP returned all of it
# under `capabilities` and the control API returned none of it, so an agent that
# changed surface saw a different shape for the same account.
sub whoami_grant {
    my ($s) = @_;
    $s ||= {};
    my %is_cap = map { $_ => 1 } @CAP_KEYS;
    my %caps   = map {
        my $held = $_ eq 'ui' ? $s->{manager_ui} : $s->{$_};
        $_ => ( $held ? JSON::PP::true() : JSON::PP::false() )
    } @CAP_KEYS;
    my %account = map { $_ => $s->{$_} }
        grep { !$is_cap{$_} && $_ ne 'manager_ui' } keys %$s;
    $account{interactive_login} = ( exists $s->{ui} && !$s->{ui} ) ? JSON::PP::false() : JSON::PP::true();
    return ( capabilities => \%caps, account => \%account );
}

sub implications {
    my ($caps) = @_;
    $caps ||= {};
    my %out;
    for my $k (@CAP_KEYS) {
        next if $caps->{$k};
        my ($by) = grep { $caps->{$_} } implied_by($k);
        next unless defined $by;
        $out{$k} = {
            satisfied_by => $by,
            note => "$k is false above because it was not granted directly; $by is "
                . "held and admits everything $k unlocks, so this account can do all of "
                . "it. Withholding $k here changes nothing.",
        };
    }
    return \%out;
}

# SM758: the CATEGORY each action is shown under, and the order of the
# categories. Twenty-two actions in registry order were a list to be read
# end to end; a grid drawn by category, alphabetised within, is a short
# sorted list in the one place a reader looks. Here beside the title and the
# grant sentence for the reason those are here: the Groups page, the Users
# page and anything else that draws the actions must say the same thing, and
# a copy in JavaScript would drift from this the moment either changed.
# sections() lists every action once, under the section it declares, in
# @CAP_KEYS order (the pages sort by label); t/lint/19 holds that every action
# declares one of @SECTIONS.
our @SECTIONS = qw(Content Appearance Data Site Accounts Operations Insight);

sub section {
    my ($cap) = @_;
    return ( $ACTION_INFO{$cap} || {} )->{section};
}

sub sections {
    my %by;
    push @{ $by{ section($_) // 'Other' } }, $_ for action_keys();
    return [ map { [ $_, $by{$_} ] } grep { $by{$_} } @SECTIONS, 'Other' ];
}

sub _holds_why {
    my ( $caps, $docroot ) = @_;
    my %why;
    for my $k (@CAP_KEYS) {
        if ( !$caps->{$k} ) {
            my ($by) = grep { $caps->{$_} } implied_by($k);
            $why{$k} = defined $by
                ? "not granted directly, but SATISFIED by $by, which admits everything "
                . "$k unlocks - withholding $k from this account changes nothing (SM740)."
                : 'not granted to this account. The capability exists in '
                . 'lazysite - ask the sysop to grant it.';
            next;
        }
        next unless $IS_CHANNEL{$k};
        my $svc = $CHANNEL_SERVICE{$k};
        next unless defined $svc;
        next unless defined $docroot && length $docroot;
        next if Lazysite::Util::service_enabled( $docroot, $svc );
        $why{$k} = "granted, but DORMANT: this site's `$svc` service is off, so "
            . 'the channel refuses regardless of the grant. Ask the operator to '
            . 'enable the service.';
    }
    return \%why;
}

# Build the map. Pass caps => { cap => 0|1 } (the caller's resolved grant) and,
# optionally, groups => [...] and account => "name" to include the "holds" block;
# docroot => "..." adds the SM225 documentation index. Omit caps for the static
# model only (e.g. the generated doc).
# SM491: WHICH OF THIS GRANT'S CHANNELS CAN ACTUALLY REACH EACH CAPABILITY.
#
# A capability is a permission; a channel is a door. An account can hold a
# capability whose every door is shut on a different switch - analytics:true
# with mcp:false was the field case - and whoami reported a bare `true`,
# which is not operationally true. The sysop saw the grant applied, the
# agent saw the capability held, and neither could use it.
#
# Derived from the `unlocks` map rather than declared, so a capability that
# gains or loses a surface changes this answer without anybody remembering to.
# Returns, per capability the account holds, the channels it is reachable on
# and the channels that would unlock it but are off for this grant.
sub reachability {
    my ($settings) = @_;
    my %out;
    for my $cap (@CAP_KEYS) {
        next unless $settings->{$cap};
        my $u = ( $ACTION_INFO{$cap} || {} )->{unlocks} || {};
        my ( @via, @shut );
        for my $ch (qw(api mcp)) {
            next unless ref $u->{$ch} eq 'ARRAY' && @{ $u->{$ch} };

            if   ( $settings->{$ch} ) { push @via,  $ch }
            else                      { push @shut, $ch }
        }
        # `ui` is the manager itself; webdav carries no capability-gated
        # actions of its own. A capability with NO api/mcp surface is a
        # manager-page capability and reachability is not the question.
        next unless @via || @shut;
        $out{$cap} = { via => \@via, ( @shut ? ( requires => \@shut ) : () ) };
    }
    return \%out;
}

# SM564: a group is judged by its REACH, not its record. Given a capability
# set as the resolver returns it ({ cap => 0|1 }), the effective callable set
# per channel, derived from the same `unlocks` tables describe() publishes:
#
#   { api => { held => 0|1, unlocked => [...], callable => [...] }, ... }
#
# `unlocked` is what the ACTION capabilities held would expose on that
# channel; `callable` is that list when the channel itself is held, and empty
# when it is not. Two rules fall out of the tables rather than being declared
# here: a channel flag alone unlocks nothing (SM570 - a door is not an
# authority), and an action capability without its door reaches nothing.
# SM570 is also why this exists: an account's declared capabilities and what
# it can actually call were found to be different things.
sub reach_for {
    my ($caps) = @_;
    $caps ||= {};
    my %out;
    for my $ch (@CHANNELS) {
        my ( %seen, @unlocked );
        for my $cap ( action_keys() ) {
            next unless $caps->{$cap};
            my $u = ( $ACTION_INFO{$cap} || {} )->{unlocks} || {};
            push @unlocked, grep { !$seen{$_}++ } @{ $u->{$ch} || [] };
        }
        my $held = $caps->{$ch} ? 1 : 0;
        $out{$ch} = {
            held     => $held,
            unlocked => \@unlocked,
            callable => [ $held ? @unlocked : () ],
        };
    }
    return \%out;
}

sub describe {
    my (%opt) = @_;
    my $T     = JSON::PP::true();
    my $F     = JSON::PP::false();

    my %channels;
    $channels{$_} = { enforced => $T, note => $CHANNEL_INFO{$_},
        service => $CHANNEL_SERVICE{$_} } for @CHANNELS;

    my %capabilities;
    for my $a ( action_keys() ) {
        my $info = $ACTION_INFO{$a} || { title => $a, unlocks => {} };
        # SM427: `grants` is the plain-sentence answer to "what am I handing
        # over?" - carried beside the title so the Groups page, describe_
        # capabilities and the generated capability map all get the same
        # words. A second copy written for the UI alone would be the shape of
        # defect this project keeps filing.
        my @imp = @{ $info->{implied_by} || [] };
        $capabilities{$a} = {
            title  => $info->{title},
            grants => ( $info->{grants} // '' )
                . ( @imp
                ? ' IMPLIED BY ' . join( ' / ', @imp ) . ': an account holding '
                    . ( @imp > 1 ? 'any of those' : $imp[0] )
                    . ' may already do everything this unlocks, so withholding this from '
                    . 'such an account changes nothing. Grant THIS, alone, for the lower level of privilege.'
                : '' ),
            unlocks => $info->{unlocks},
            ( @imp ? ( implied_by => \@imp ) : () ),
        };
    }

    my %map = (
        channels     => \%channels,
        capabilities => \%capabilities,
        tasks        => \@TASKS,
        engine_owned => \@ENGINE_OWNED,
    );

    if ( my $docs = _scan_docs( $opt{docroot} ) ) { $map{docs} = $docs }

    if ( $opt{caps} ) {
        my $caps = $opt{caps};
        # SM226: `capabilities` above is what lazysite OFFERS; `holds` is what THIS
        # account was GRANTED. Readers flatten the two and read a false as absence -
        # a partner tabulated read_submissions:false, concluded submissions could not
        # be read at all, and specified a replacement store. The scope line is prose
        # in the payload deliberately: the consumer is a language model and the
        # misreading is a language misreading.
        $map{holds} = {
            ( defined $opt{account} ? ( account => $opt{account} ) : () ),
            # SM779: the account's display name beside its login - a partner
            # rendering bylines had no route from a login to a name, not even
            # its own.
            ( defined $opt{display_name} && length $opt{display_name}
                ? ( display_name => $opt{display_name} ) : () ),
            ( $opt{groups} ? ( groups => $opt{groups} ) : () ),
            scope =>
                'What THIS account has been granted. A false value means "not '
                . 'granted to this account", never "not available in lazysite" - see '
                . '"capabilities" for what the platform offers, and ask the sysop '
                . 'for a grant. See "why" for the reason each false is false.',
            capabilities => { map { $_ => ( $caps->{$_} ? $T : $F ) } @CAP_KEYS },
            why          => _holds_why( $caps, $opt{docroot} ),

            # SM740: the pairs where a false above is not a withholding.
            implied => implications($caps),
        };
    }

    return \%map;
}

1;
