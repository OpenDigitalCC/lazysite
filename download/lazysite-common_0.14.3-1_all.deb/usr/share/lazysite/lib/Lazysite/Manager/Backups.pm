package Lazysite::Manager::Backups;

# SM084: docroot content backups - tarball snapshots stored under
# lazysite/backups/ (infrastructure, never served), surfaced in the manager so an
# operator can snapshot before a risky change and download/restore the original.
# A pre-install snapshot is taken by the Hestia hook; manual ones come from here.

use strict;
use warnings;
use POSIX             qw(strftime);
use File::Path        qw(make_path);
use File::Find        ();
use File::Basename    qw(dirname basename);
use Lazysite::Private ();
use Fcntl             qw(O_WRONLY O_CREAT O_EXCL);
use Errno             ();
use Lazysite::Util    qw(log_event);
use Exporter          qw(import);

# BP-6: the attachment stream shared with the file downloads. Upload does not
# load this module back, so naming it here costs no cycle.
use Lazysite::Manager::Upload ();
use Lazysite::Paths           ();
our @EXPORT_OK = qw(action_backup_list action_backup_create action_backup_download
    action_backup_restore action_backup_delete
    write_sha256 read_sha256 verify_sha256
    _claim_name _apply_retention);

our $DOCROOT      = '';
our $LAZYSITE_DIR = '';
our $auth_user    = '';

sub _dir { return "$LAZYSITE_DIR/backups" }

# A backup name is a single tarball basename - strict, no path traversal.
sub _valid_name { return $_[0] =~ /\A[A-Za-z0-9._-]+\.tar\.gz\z/ && $_[0] !~ /[.][.]/ }

# SM183: write the integrity digest beside an artefact, and return it.
#
# A site package is made to TRAVEL - an agency builds a demo and hands it to the
# client's own instance, often across organisations and by whatever channel is to
# hand. The receiving sysop has no way to tell an altered package from an
# intact one, and "apply" overwrites a site. The release tarballs have carried a
# .sha256 sidecar for exactly this reason since long before site packages
# existed; this gives packages and backups the same.
#
# A sidecar file rather than a manifest field, deliberately: it is verifiable
# with sha256sum -c and no lazysite tooling at all, which is the situation the
# receiving sysop is actually in.
#
# Failure to write it is NOT fatal. The artefact is valid without it; a digest
# that cannot be stored should not lose a sysop their backup - but it must
# be REPORTED as absent, which is the SM268 03-F10 half below.
#
# SM268 03-F10: write it atomically, and never report a digest that was not
# stored.
#
# This wrote with a plain `open '>'` - which follows a symlink, has no O_EXCL and
# is not atomic - silently ignored an open failure while STILL returning the
# digest to its caller, and chmod 0664'd the sidecar into the same
# group-writable directory as the artefact it describes. A caller that was told
# a digest and got no file is the worst of the three: package_create recorded a
# sha256 in its response for an artefact that carries none.
sub write_sha256 {
    my ($path) = @_;
    return '' unless -f $path;
    require Digest::SHA;
    my $sha = eval { Digest::SHA->new('sha256')->addfile( $path, 'b' )->hexdigest };
    return '' unless defined $sha && length $sha;
    my $base = $path;
    $base =~ s{.*/}{};

    my $side = "$path.sha256";
    if ( -l $side ) {
        log_event( 'ERROR', 'sha256', 'sidecar path is a symlink - refusing',
            path => $side );
        return '';
    }
    my $tmp = "$side.tmp.$$";
    sysopen my $fh, $tmp, O_WRONLY | O_CREAT | O_EXCL, oct '640'
        or do {
        log_event( 'ERROR', 'sha256', 'cannot write digest sidecar',
            path => $tmp, error => "$!" );
        return '';
        };
    print {$fh} "$sha  $base\n";    # sha256sum -c format
    close $fh;
    unless ( rename $tmp, $side ) {
        log_event( 'ERROR', 'sha256', 'cannot install digest sidecar',
            path => $side, error => "$!" );
        unlink $tmp;
        return '';
    }
    return $sha;
}

# Read the digest beside an artefact, if one was written.
#
# SM268 03-F10: the BASENAME field is checked. This took the first 64 hex
# characters and ignored the rest of the line, so a sidecar describing a
# different artefact was accepted as this one's - which is the whole point of
# sha256sum's second field.
sub read_sha256 {
    my ($path) = @_;
    open my $fh, '<', "$path.sha256" or return '';
    my $line = <$fh> // '';
    close $fh;
    my ( $sha, $named ) = $line =~ /\A([0-9a-f]{64})\s+\*?(\S+)/;
    return '' unless defined $sha;
    my $base = $path;
    $base =~ s{.*/}{};
    return '' unless defined $named && $named eq $base;
    return $sha;
}

# SM268 03-F10: the digest was DISPLAYED and never verified.
#
# action_backup_list surfaced read_sha256 for every artefact and nothing
# anywhere recomputed it. An operator sees a digest in the UI beside a package
# and reads it as "verified"; it meant "a digest was written at some point".
# Misleading assurance is worse than none: someone who tampers with a tarball in
# place and leaves the sidecar alone gets a green-looking listing.
#
# Returns 'verified', 'mismatch', or 'absent'. Not a boolean, because the three
# cases need different responses: absent is an artefact from before the sidecar
# existed and is merely unverified, while mismatch is a fact about this file
# now.
sub verify_sha256 {
    my ($path) = @_;
    my ( undef, $status ) = _sha_and_status($path);
    return $status;
}

# BPO-5: the recorded digest AND the verdict, from one read of the sidecar.
# The verdict is a comparison against exactly the value read here, so a
# listing that wanted both read the same file twice for every artefact.
sub _sha_and_status {
    my ($path) = @_;
    my $want = read_sha256($path);
    return ( '', 'absent' ) unless length $want;
    require Digest::SHA;
    my $got = eval { Digest::SHA->new('sha256')->addfile( $path, 'b' )->hexdigest };
    return ( $want, 'mismatch' ) unless defined $got && length $got;
    return ( $want, $got eq $want ? 'verified' : 'mismatch' );
}

sub action_backup_list {
    my $dir = _dir();
    my @out;
    if ( opendir my $dh, $dir ) {
        for my $f ( readdir $dh ) {
            next unless $f =~ /\.tar\.gz\z/ && -f "$dir/$f";
            my @st = stat "$dir/$f";
            # Kind from the (now lazysite-prefixed) name; `site` is a per-domain
            # site package (SM158) that also lives here.
            my ($kind) = $f =~ /\A(?:lazysite-)?(preinstall|prerestore|manual|full|site)-/;
            # SM782: the installer's pre-upgrade archive (lazysite-backup-
            # <date>-<time>-pre-<version>) is the ENGINE's files, so an upgrade
            # can be undone - not content. It was listed as `manual`, counted
            # toward no cap, and could not be deleted: listed and unmanaged.
            $kind //= $f =~ /\Alazysite-backup-\d{8}-\d{6}-/ ? 'upgrade' : 'manual';
            my $scope = $kind eq 'full' ? 'full' : $kind eq 'site' ? 'site' : $kind eq 'upgrade' ? 'engine' : 'content';

            # SM183: present only when a digest was written beside it, so an
            # artefact from before this is simply unverified rather than
            # looking like one whose digest failed.
            #
            # SM268 03-F10: and RECOMPUTED, not merely echoed. A digest
            # displayed beside a package reads as "verified" whether or not
            # anything checked it, so the listing now says which of the
            # three it is: verified, mismatch, or absent.
            my ( $sha, $status ) = _sha_and_status("$dir/$f");
            push @out, { name => $f, size => $st[7] // 0, mtime => $st[9] // 0,
                kind          => $kind, scope => $scope,
                sha256        => $sha,
                sha256_status => $status };
        }
        closedir $dh;
    }
    @out = sort { $b->{mtime} <=> $a->{mtime} } @out;
    return { ok => 1, backups => \@out };
}

# SM183: the stamp is second-granular and was the ONLY thing making a name
# unique, so two snapshots in the same second produced the same name and the
# second silently overwrote the first.
#
# That is not theoretical and it is not cosmetic. action_backup_restore takes its
# own safety snapshot before restoring; roll back an apply promptly and the
# restore's snapshot lands on the apply's, destroying the artefact being restored
# FROM - and then "restores" the state you were trying to undo. It reported
# success throughout. Found by testing the rollback round trip.
#
# SM268 03-F9: the first fix for that was `if (-e $out) { pick a -N }`, which is
# a check followed by a create and therefore fixed it only for SEQUENTIAL
# callers. An adversarial review ran twelve concurrent snapshots and got two
# files: every caller was told ok => 1 and handed a name, and ten of them named
# someone else's tarball. Two tar processes writing one inode is also not
# guaranteed to produce a valid archive.
#
# O_EXCL is the test and the claim in one syscall, so exactly one caller wins
# each name and the losers take the next suffix. Still disambiguate rather than
# refuse: a backup is a safety net and the caller is usually mid-operation, so
# failing to take one is worse than taking one under a slightly longer name.
#
# Returns (path, basename), or () if 50 suffixes were all taken or the create
# failed for a reason other than "exists" - a full or unwritable backups
# directory, say, which must not be reported as a successful snapshot.
#
# tar then writes THROUGH the placeholder - it opens O_WRONLY|O_CREAT|O_TRUNC,
# so the inode we claimed is the one it fills.
# SM885: drop a staging directory so that an orphaned writer cannot keep it
# alive. RENAME FIRST, THEN DELETE.
#
# Deleting it directly is not enough, and this was measured rather than
# reasoned: remove_tree unlinks the staged file and then rmdirs the directory,
# and an orphaned gzip that recreates its file between those two steps makes
# the rmdir fail on a non-empty directory. The archive was gone - the defect
# this all exists to fix was closed - but the directory survived in `backups/`,
# which is the same flaky assertion one layer down.
#
# A rename is atomic and takes the whole subtree out of reach in one step: from
# that instant the path the orphan holds has no parent, so its open fails and
# nothing new can appear. Whatever it had already created moves with the
# directory and is removed with it. Both interleavings end empty, with no
# timing assumption and no retry.
sub _drop_staging {
    my ($stage_dir) = @_;
    return unless defined $stage_dir && length $stage_dir;
    my $dead = "$stage_dir.dead";
    File::Path::remove_tree($dead) if -e $dead;
    if ( rename $stage_dir, $dead ) { $stage_dir = $dead }
    File::Path::remove_tree($stage_dir);
    return;
}

sub _claim_name {
    my ( $dir, $kind ) = @_;
    my $stamp = strftime( '%Y%m%dT%H%M%SZ', gmtime );
    for my $n ( 1 .. 50 ) {
        my $name = "lazysite-$kind-$stamp" . ( $n > 1 ? "-$n" : q{} ) . '.tar.gz';
        my $path = "$dir/$name";
        if ( sysopen my $fh, $path, O_WRONLY | O_CREAT | O_EXCL, oct '640' ) {
            close $fh;
            return ( $path, $name );
        }
        next if $! == Errno::EEXIST();
        log_event( 'ERROR', 'backup-create', 'cannot create backup file',
            path => $path, error => "$!" );
        return ();
    }
    log_event( 'ERROR', 'backup-create', 'no free backup name in this second',
        dir => $dir );
    return ();
}

# SM268 03-F11: keep the artefact directory bounded.
#
# install.pl's apply_retention globs `lazysite-backup-*` - only the installer's
# own. Every manager artefact (manual, prerestore, full, site) was out of its
# reach, and nothing removed a prerestore snapshot EVER. Since SM183 made every
# surface snapshot before an apply, and action_backup_restore snapshots before
# every restore, each of which is a full copy of the docroot content, an agent
# looping site_apply fills the disk - and on a shared instance that takes every
# hosted site down and corrupts in-flight writes.
#
# Per KIND, because the kinds are not interchangeable: ten manual snapshots and
# ten prerestore snapshots are ten of each, and expiring a sysop's deliberate
# snapshot because a plugin took twenty automatic ones would be the wrong
# trade. `backup_retention: 0` means unlimited. SM753: the value comes from
# Lazysite::Util::backup_retention, the ONE reader - the manager, the theme
# store and the installer used to parse this key three ways with two defaults.
#
# Newest-first, and the newest of a kind is never removed: a retention rule that
# can empty the directory is a rule that deletes the snapshot taken thirty
# seconds ago because the limit was misread.
sub _retention_limit { return Lazysite::Util::backup_retention($LAZYSITE_DIR) } # SM753: the one reader

sub _apply_retention {
    my ($kind) = @_;
    my $keep = _retention_limit();
    return unless $keep > 0;

    my $dir = _dir();
    opendir my $dh, $dir or return;
    my @mine = grep { /\A(?:lazysite-)?\Q$kind\E-/ && /\.tar\.gz\z/ } readdir $dh;
    closedir $dh;
    return if @mine <= $keep;

    # BPO-5: stat once per name rather than twice per comparison. The same
    # mtimes in the same comparator order the same list.
    my @by_age = map { $_->[0] }
        sort { $b->[1] <=> $a->[1] }
        map { [ $_, ( stat "$dir/$_" )[9] // 0 ] } @mine;
    for my $old ( @by_age[ $keep .. $#by_age ] ) {
        next unless unlink "$dir/$old";

        # SM753 / SM183: the integrity sidecar retires with the artefact it
        # describes. install.pl's rotation has always done this; the manager's
        # left a .sha256 for every snapshot it expired, describing an archive
        # that no longer existed.
        unlink "$dir/$old.sha256" if -f "$dir/$old.sha256";
        log_event( 'INFO', 'backup-retention', 'expired old snapshot',
            file => $old, kind => $kind, keep => $keep );
    }
    return;
}

# SM268 03-F11: and a way to remove one deliberately.
#
# The only delete in the API was site-backup-delete, confined to the
# lazysite-site- namespace, so a manual snapshot an operator no longer wanted -
# or a prerestore snapshot of a restore that went fine - could only be removed
# from the shell. Retention bounds the growth; this is for the operator who
# knows which one they want gone.
#
# The site- namespace is deliberately NOT reachable here: it has its own delete
# with its own scope confinement (a scoped partner must not remove another
# domain's package), and duplicating that check in a second place is how the two
# come to disagree.
sub action_backup_delete {
    my ($name) = @_;
    $name = '' unless defined $name;
    return { ok => 0, kind => 'invalid', error => 'Invalid backup name' }
        unless _valid_name($name);
    return { ok => 0, kind => 'invalid',
        error => 'A site package is removed with site-backup-delete, which '
            . 'applies the per-domain scope checks this action does not.' }
        if $name =~ /\A(?:lazysite-)?site-/;
    # SM782: the installer's pre-upgrade archive is deletable here too - it
    # is a file this directory lists, and nothing else removes it once the
    # installer's own rotation has moved past it. The refusal names the two
    # name shapes rather than calling the name invalid.
    return { ok => 0, kind => 'invalid',
        error => 'Not a snapshot this action manages: a manager snapshot is '
            . 'lazysite-<manual|prerestore|full>-<stamp>.tar.gz and an installer '
            . 'pre-upgrade archive is lazysite-backup-<date>-<time>-pre-<version>.tar.gz' }
        unless $name =~ /\A(?:lazysite-)?(?:preinstall|prerestore|manual|full)-/
        || $name =~ /\Alazysite-backup-\d{8}-\d{6}-/;

    my $full = _dir() . "/$name";
    return { ok => 0, kind => 'not-found', error => 'Backup not found' } unless -f $full;

    unlink $full or return { ok => 0, error => "Could not delete the backup: $!" };
    unlink "$full.sha256" if -f "$full.sha256";    # SM753: and its sidecar
    log_event( 'INFO', 'backup-delete', 'snapshot removed',
        file => $name, user => $auth_user );
    return { ok => 1, name => $name };
}

# The archive's member list. LIST FORM, NO SHELL - the doctrine the tar call
# in action_backup_create states and these two reads did not follow: a qx()
# with \Q quoting here and a backtick in the restore, each hand-building a
# shell command line out of a path. fork/exec has no shell to quote for, and
# the stderr redirect happens in the CHILD only (SM381), as _gzip_ok's does.
sub _archive_members {
    my ($path) = @_;
    my $pid    = open my $fh, '-|';
    return () unless defined $pid;
    unless ($pid) {
        open STDERR, '>', '/dev/null' or exit 127;
        exec( 'tar', '-tzf', $path ) or exit 127;
    }
    my @members = <$fh>;
    close $fh;
    chomp @members;
    return @members;
}

# Filesystem paths are never exposed (standing rule), and tar's stderr is full
# of them. Absolute paths under the docroot or the private store become the
# site-relative form a caller can act on; anything else absolute is replaced
# wholesale rather than trimmed, because a path outside the site tells a remote
# caller about the host and nothing about their problem.
# SM484: the common top directory of an archive's members, or undef. Reads
# the member list the same tar reads the archive; ./lazysite members are
# ignored (no content archive carries them and the restore excludes them).
# BPO-1: takes the member list, or an archive to read it from. A restore
# lists once and hands the same list to both consumers - same file, same
# command, and nothing writes between the two reads it used to make.
sub _archive_scope {
    my ($archive) = @_;
    my @members
        = ref $archive eq 'ARRAY' ? @{$archive} : _archive_members($archive);
    my $common;
    for my $raw (@members) {
        ( my $m = $raw ) =~ s{\A\./}{};
        next unless length $m;
        next if $m eq 'lazysite' || $m =~ m{\Alazysite/};
        my ($top) = $m =~ m{\A([^/]+)/};
        # SM544: a bare top-level file is written at the ROOT by the restore,
        # so the root is the blast radius - the full content snapshot. This
        # used to skip it, and the snapshot then missed exactly the file the
        # restore replaced.
        return undef unless defined $top;
        if    ( !defined $common ) { $common = $top }
        elsif ( $common ne $top )  { return undef }
    }
    return undef unless defined $common && length $common;
    # Deepen to the longest common directory under the top, one level at a
    # time, so a sites/edge archive scopes to sites/edge rather than sites.
    my $prefix = $common;
    while (1) {
        my %next;
        for my $m (@members) {
            ( my $r = $m ) =~ s{\A\./}{};
            next unless length $r && index( $r, "$prefix/" ) == 0;
            my $rest = substr( $r, length($prefix) + 1 );
            # SM544: tar lists the prefix directory itself (./sites/), whose
            # rest is empty; that is not a bare file, so it must not stop the
            # deepening here.
            next unless length $rest;
            my ($seg) = $rest =~ m{\A([^/]+)/};
            # A bare file at this level: the scope is its parent, $prefix.
            return $prefix unless defined $seg;
            $next{$seg} = 1;
        }
        return $prefix unless keys %next == 1;
        $prefix .= '/' . ( keys %next )[0];
    }
}

sub _scrub_paths {
    my ($text) = @_;
    return '' unless defined $text;

    # SM386: KEEP THE SITE-RELATIVE PATH. It is the whole diagnostic value and
    # it discloses nothing a caller cannot already list.
    #
    # The first version replaced the docroot with <site> and then ran a generic
    # absolute-path rule that ate what was left, so every message came out as
    # "<site><path>" or "<path>". A partner agent chasing a Permission denied
    # from tar could not tell whether it was failing on the private store, the
    # cache, a lock file, or something under lazysite/ it should not be reading
    # at all - which is the one thing needed to act.
    #
    # The generic rule's lookbehind excluded "<" and not ">", so it matched the
    # relative remainder immediately after the placeholder it had just written.
    # A guard that does not cover its own output.
    #
    # RELATIVE ALWAYS, ABSOLUTE NEVER. A path inside the site keeps its shape
    # under a placeholder root; a path outside keeps only its last two segments,
    # which names the artefact without describing the host's layout.
    my $priv = Lazysite::Private::private_root($DOCROOT);
    my @roots;
    push @roots, [ $priv,    '<private>' ] if defined $priv    && length $priv;
    push @roots, [ $DOCROOT, '<site>' ]    if defined $DOCROOT && length $DOCROOT;

    # Longest first: the private store is a SIBLING of the docroot on some
    # layouts and a child on none, but ordering by length keeps this correct if
    # that ever changes.
    for my $r ( sort { length( $b->[0] ) <=> length( $a->[0] ) } @roots ) {
        my ( $root, $label ) = @$r;
        $text =~ s{\Q$root\E(?=/|\s|\z|:)}{$label}g;
    }

    # Anything still absolute is outside the site. Keep the tail so the reader
    # can tell a lock file from a library, and drop the rest.
    # SM484: '.' joins both lookbehinds - tar's ./-relative member names
    # ("tar: ./primary-only:") matched the generic absolute rule through the
    # leading dot and came back as ".<outside>", partly undoing SM386's
    # name-the-path repair for exactly the messages this sub exists to keep.
    $text =~ s{(?<![\w<>.])(/(?:[\w.\-]+/)*)([\w.\-]+/[\w.\-]+)}{<outside>/$2}g;
    $text =~ s{(?<![\w<>/.])/[\w.\-]+(?=\s|:|\z)}{<outside>}g;

    $text =~ s/\s+\z//;
    my @lines = split /\n/, $text;
    @lines = @lines[ 0 .. 2 ] if @lines > 3;    # the first fault, not the flood
    return join '; ', @lines;
}

# Are two paths one directory? By inode, so a symlinked docroot - whose `..`
# is the target's parent - is told apart from the ordinary sibling layout.
sub _same_dir {
    my ( $a, $b ) = @_;
    my @sa = stat $a or return 0;
    my @sb = stat $b or return 0;
    return ( $sa[0] == $sb[0] && $sa[1] == $sb[1] ) ? 1 : 0;
}

# Is the archive a readable gzip stream? A tar warning is only acceptable if
# what it produced can actually be restored, and "the file exists and is not
# empty" does not establish that.
sub _gzip_ok {
    my ($path) = @_;
    my $pid = fork();
    return 0 unless defined $pid;
    if ( !$pid ) {
        # Checked, because an unchecked open here would leave gzip's chatter on
        # the caller's STDOUT - and in a CGI worker that means diagnostic text
        # in the middle of a response body.
        open STDOUT, '>', '/dev/null' or exit 127;
        open STDERR, '>', '/dev/null' or exit 127;
        exec( 'gzip', '-t', $path ) or exit 127;
    }
    waitpid $pid, 0;
    return ( $? == 0 ) ? 1 : 0;
}

sub action_backup_create {
    my ( $kind, %opt ) = @_;
    $kind = 'manual' unless defined $kind && $kind =~ /\A(manual|prerestore|full)\z/;
    my $dir = _dir();

    # SM412: an optional docroot-relative SCOPE. The safety snapshot before a
    # site-package apply used to tar the whole docroot whatever the target - so
    # on a multi-domain instance, applying to a content-rooted domain
    # (sites/edge2) tried to read the PRIMARY domain's tree, which the calling
    # account could not and the apply would never touch. Diagnosed in the field
    # by the partner agent the refusal blocked: same host, same account,
    # site_backup scoped correctly while the apply's snapshot resolved upward,
    # 26 seconds apart with opposite results.
    #
    # The snapshot's job is to cover the BLAST RADIUS of the operation it
    # guards, and package_apply writes only under the target content_root - so
    # that subtree is what a scoped snapshot carries. Restore is an overlay
    # extract, so a scoped archive restores exactly its own subtree.
    #
    # Same validation posture as package_apply's own content_root: relative,
    # no traversal, must exist. 'full' never scopes - it is the whole-site DR
    # artefact by definition.
    my $root = $opt{root} // '';
    if ( length $root ) {
        return { ok => 0,
            error  => 'Backup failed: a full backup cannot be scoped',
            reason => 'a full backup cannot be scoped' }
            if $kind eq 'full';
        return { ok => 0,
            error  => 'Backup failed: invalid scope',
            reason => 'invalid scope',
            detail => _scrub_paths($root) }
            if $root =~ m{\.\.} || $root =~ m{\A/} || $root !~ m{\A[\w][\w/.-]*\z};

        # A scope that does not exist yet has an EMPTY blast radius - the
        # first apply into a freshly configured domain creates its content
        # root. There is nothing the operation can destroy, so the honest
        # snapshot is a recorded no-op, not a refusal (t/unit/manager/35
        # caught the refusal breaking exactly that first-time apply).
        # A scope that exists as a non-directory is a broken state and stays
        # a refusal.
        unless ( -e "$DOCROOT/$root" ) {
            log_event( 'INFO', 'backup-create',
                'scoped snapshot skipped - the scope does not exist yet',
                root => $root, user => $auth_user );
            return { ok => 1, name => '',
                note => 'nothing to snapshot: the scope does not exist yet' };
        }
        return { ok => 0,
            error  => 'Backup failed: scope is not a directory',
            reason => 'scope is not a directory',
            detail => _scrub_paths("$DOCROOT/$root") }
            unless -d "$DOCROOT/$root";
    }

    # SM381: CHECKED. An unchecked make_path meant a permissions failure here
    # surfaced two frames later as "could not claim a filename", which names the
    # wrong thing entirely - the directory could not be made, and the sysop
    # was sent to look at filenames.
    unless ( -d $dir ) {
        make_path($dir);
        unless ( -d $dir ) {
            return { ok => 0,
                error  => 'Backup failed: cannot create the backup directory',
                reason => 'cannot create the backup directory',
                detail => _scrub_paths("$dir: $!") };
        }
    }
    # All backup artefacts carry the `lazysite-` namespace prefix so they are
    # unmistakably ours (and sort together): lazysite-<kind>-<UTCstamp>.tar.gz.
    # The name is claimed atomically - see _claim_name for why a check-then-create
    # was not enough.
    my ( $out, $name ) = _claim_name( $dir, $kind );
    return { ok => 0, error => 'Backup failed: could not claim a filename' }
        unless defined $out;

    # SM885: TAR DOES NOT WRITE THE CLAIMED NAME. It writes into a staging
    # directory, and the finished archive is renamed into place.
    #
    # `tar czf` forks gzip. We fork tar and waitpid on TAR, so when tar fails
    # early - a -C it cannot enter - we reap tar while gzip is still alive,
    # orphaned to init, and still holding the job of producing the output. The
    # refusal below unlinks the claimed name, and the orphan then RECREATES it:
    # a 20-byte empty gzip stream sitting in the listing as a snapshot that
    # restores nothing. Measured at 7 of 40 runs under load and 0 of 300
    # serially; a control arm with `tar cf` (no compressor) never did it.
    #
    # Unlinking harder cannot win a race against a process we do not own. So
    # the doomed pipeline is pointed somewhere that is NOT the listing: on
    # failure the staging directory is removed whole, and an orphan that opens
    # its file afterwards fails on the missing parent, while one that opened it
    # first writes to an unlinked inode nobody can see. Both orders end with
    # nothing in `backups/`, with no timing assumption.
    #
    # Same shape and naming as the restore path's staging dir below, and inside
    # `backups/` so the rename is same-filesystem and therefore atomic.
    my $stage_dir = "$dir/.stage-$$-" . time;
    make_path($stage_dir);
    unless ( -d $stage_dir ) {
        unlink $out;
        return { ok => 0,
            error  => 'Backup failed: cannot create the staging directory',
            reason => 'cannot create the staging directory',
            detail => _scrub_paths("$stage_dir: $!") };
    }
    my $stage = "$stage_dir/$name";

    # 'full' = the whole site including the lazysite/ infra (config, auth,
    # forms, nav, themes/layouts) - a portable snapshot for DR and for migrating a
    # site to another domain (restored by a system user via install.pl --restore
    # --domain; NOT self-service, because it carries the auth secrets). Only the
    # backups dir (don't nest) and regenerable caches/mirror are excluded.
    # Otherwise = content only, excluding the whole lazysite/ infra as before.
    my @excludes =
        $kind eq 'full'
        ? ( '--exclude=./lazysite/backups', '--exclude=./lazysite/cache',
        '--exclude=./lazysite-assets' )
        : ( '--exclude=./lazysite', '--exclude=./lazysite-assets' );

    # SM381: THE RENDER CACHE'S TEMPFILES, which exist for milliseconds and are
    # renamed away. The processor writes "<page>.html.tmp.<pid>" into the
    # DOCROOT and renames it into place, so a visitor arriving mid-backup lets
    # tar enumerate a temp file that is gone before tar opens it. tar then exits
    # non-zero for a file nobody wanted archived.
    #
    # Excluded rather than only tolerated, because the file is genuinely not
    # wanted in a backup: restoring one would put a half-written page into a site.
    push @excludes, '--exclude=*.tmp.[0-9]*';

    # SM412: a scoped snapshot carries the target subtree and nothing else. The
    # lazysite/-infra excludes are irrelevant (the member set never enters it)
    # but the tempfile exclude still matters - the render cache writes into
    # content dirs too. The private store is NOT carried: apply never writes
    # there, so it is outside the blast radius this snapshot exists to cover.
    my $member = '.';
    if ( length $root ) {
        @excludes = ('--exclude=*.tmp.[0-9]*');
        $member   = "./$root";
    }

    # SM286: the private content store is CONTENT, and it lives outside the
    # docroot - so a tar of the docroot alone silently stops backing up every
    # gated section. That is worse than the exposure the store removes, and it
    # would be discovered at restore time, which is the worst moment to discover
    # anything.
    #
    # A mid-command -C switches tar's directory for the members that follow, so
    # one pass produces `./...` for the docroot and `lazysite-private/...` for
    # the store. The docroot members keep their exact existing spelling, so an
    # archive written before this still restores unchanged - the format is
    # extended, not replaced. (Back-compat is not required here as of
    # 2026-08-13, but breaking it for no gain would still be a choice with a
    # cost and none of the benefit.)
    #
    # SM769: REACH THE STORE WITHOUT OPENING ITS PARENT. The store is the
    # docroot's sibling, and its parent is the domain folder - on the Hestia
    # layout root-owned 0551, which the request path may traverse but not
    # read. GNU tar implements -C by opening the directory O_RDONLY (glibc has
    # no O_SEARCH), so `-C $parent $leaf` died with "Cannot open: Permission
    # denied" on every host laid out that way: the Backups page's own button
    # had never worked there, and nobody noticed because the installer's
    # pre-upgrade snapshots kept the list full. Naming the store as `../leaf`
    # from inside the docroot walks THROUGH the parent (x is enough) instead
    # of opening it; tar strips the leading `../` and stores the member as
    # `leaf/...`, byte-for-byte the name the old form produced, so every
    # archive and every restore reads the same. The `-C parent` form is kept
    # for the one layout where `../leaf` is not the store: a symlinked
    # docroot, whose `..` is the target's parent, not the link's.
    my @store;
    my $priv = length($root) ? undef : Lazysite::Private::private_root($DOCROOT);
    if ( defined $priv && -d $priv ) {
        my $parent = dirname($priv);
        my $leaf   = basename($priv);
        @store = _same_dir( "$DOCROOT/../$leaf", $priv ) ? ("../$leaf") : ( '-C', $parent, $leaf );
    }

    # SM378: SAY WHY. 'Backup failed' discarded tar's exit status, its stderr
    # and which of three distinct conditions actually fired - so a caller met a
    # wall rather than a diagnosable fault. A partner agent hit exactly that:
    # site_apply refused with 'safety snapshot failed', while site_backup on the
    # same host succeeded in both directions minutes later, and there was
    # nothing in the refusal to tell the two apart.
    #
    # The three conditions are NOT the same fault and must not share a message:
    # tar exiting non-zero is a tar problem; a missing archive after a zero exit
    # is a filesystem or permissions problem; a zero-byte archive means tar
    # believed it wrote something and did not.
    # LIST FORM, NO SHELL, AND THE REDIRECT IN THE CHILD ONLY.
    #
    # An earlier draft reached for `sh -c` to get the redirect and used a
    # bashism (${@:3}) that dash - Debian's /bin/sh - does not understand, which
    # would have broken every backup on the platform this ships to.
    #
    # The draft after THAT redirected this process's STDERR around the system()
    # call, which is a hazard in a persistent worker (SM381): for the duration
    # of a multi-second tar every unrelated warning in the process goes to a
    # temp file that is then deleted, and if the call dies between the two
    # opens, STDERR stays redirected for the life of the worker.
    #
    # fork/exec redirects in the CHILD, so the parent's STDERR is never touched.
    # SM885: in the staging directory too, so it is swept with everything else
    # and a stray .err can never appear beside the artefacts.
    my $err_file = "$stage_dir/tar.err";
    my $rc       = 0;
    my $pid      = fork();
    if ( !defined $pid ) {
        $rc = -1;
    }
    elsif ( !$pid ) {
        open STDERR, '>', $err_file or exit 127;
        exec( 'tar', 'czf', $stage, '-C', $DOCROOT, @excludes, $member, @store )
            or exit 127;
    }
    else {
        waitpid $pid, 0;
        $rc = $?;
    }
    my $tar_err = '';
    if ( open my $eh, '<', $err_file ) {
        local $/;
        $tar_err = <$eh> // '';
        close $eh;
    }
    unlink $err_file;

    # SM381: TAR EXIT 1 IS "SOME FILES DIFFER", NOT A FAILURE.
    #
    # tar uses 1 for a warning - a file changed or vanished while being read -
    # and 2 for a fatal error. Treating both as fatal is why a busy site could
    # not be snapshotted: one visitor triggering a render during the tar
    # produced exit 1 and the whole apply refused. It explains every symptom the
    # field reported - intermittent, traffic-correlated, and invisible to a
    # manual backup taken at a quiet moment.
    #
    # The archive still has to be USABLE before a warning is accepted: present,
    # non-empty, and readable as a gzip stream. A warning plus a valid archive
    # is a backup; a warning plus a broken one is a failure.
    # SM885: judged on the STAGED file - that is the one tar wrote. $out is
    # still the empty placeholder at this point and would fail every one of
    # these three tests.
    my $status = $rc >> 8;
    my $usable = ( -f $stage    && !-z $stage && _gzip_ok($stage) ) ? 1 : 0;
    my $warned = ( $status == 1 && $usable ) ? 1 : 0;

    if ($warned) {
        log_event( 'INFO', 'backup-create',
            'tar reported changed files during the snapshot; archive verified',
            file => $name, user => $auth_user );
    }

    if ( ( $rc != 0 && !$warned ) || !-f $stage || -z $stage ) {
        # Drop the placeholder we claimed, or a failed snapshot sits in the
        # listing as a zero-byte tarball that reads as a usable one.
        #
        # SM885: and remove the staging directory WHOLE. Nothing can recreate
        # the claimed name now - the orphaned compressor only ever knew the
        # staged path - and taking the directory with it means an orphan that
        # has not opened its file yet has no parent to create it in.
        unlink $out;
        my $why
            = $rc != 0   ? sprintf( 'tar exited %d', $rc >> 8 )
            : !-f $stage ? 'tar reported success but wrote no archive'
            :              'tar wrote an empty archive';
        _drop_staging($stage_dir);
        # SM769: the unix user is the fact that turns "Permission denied"
        # into an instruction - the same three the store readers log.
        my ($who) = getpwuid($>);
        return { ok => 0,
            error     => "Backup failed: $why",
            reason    => $why,
            unix_user => ( $who // $> ),
            ( length $tar_err ? ( detail => _scrub_paths($tar_err) ) : () ) };
    }
    # SM885: the archive becomes the claimed name here and not before. rename(2)
    # over the placeholder is atomic and same-filesystem (the staging directory
    # is inside `backups/` precisely so it is), so the listing goes from holding
    # an empty reservation to holding a verified archive with no moment in
    # between where it holds a half-written one.
    unless ( rename $stage, $out ) {
        my $why = "could not place the archive: $!";
        unlink $out;
        _drop_staging($stage_dir);
        my ($who) = getpwuid($>);
        return { ok => 0,
            error     => "Backup failed: $why",
            reason    => $why,
            unix_user => ( $who // $> ) };
    }
    _drop_staging($stage_dir);

    log_event( 'INFO', 'backup-create',
        ( $kind eq 'full' ? 'full system snapshot'
            : length $root ? 'scoped snapshot'
            : 'docroot snapshot'
        ),
        file => $name, user => $auth_user,
        ( length $root ? ( root => $root ) : () ) );
    my $sha = write_sha256($out);

    # After the snapshot exists and carries its digest, never before: expiring an
    # old one to make room for a new one that then fails would lose both.
    _apply_retention($kind);

    my @st = stat $out;
    return { ok => 1, name => $name, size => $st[7] // 0, mtime => $st[9] // 0,
        sha256 => $sha,
        scope  => ( $kind eq q{full} ? q{full} : q{content} ) };
}

# SM378: the safety snapshot a destructive operation takes first, and the
# refusal when it cannot be taken - written twice before this, here and in
# SitePackage's apply, differing only in the verb.
#
# CARRY THE CAUSE. A bare 'safety snapshot failed' discards tar's reason and
# turns a diagnosable fault into a wall; measured in the field, where
# site_apply refused while site_backup on the same host succeeded in both
# directions minutes later and nothing in the refusal told the two apart.
#
# Returns ( $snapshot, undef ) or ( undef, $refusal ). %extra joins the
# refusal, for a surface that names the kind of failure it reports.
sub safety_snapshot_or_refuse {
    my ( $verb, $root, %extra ) = @_;
    my $safety = action_backup_create( 'prerestore',
        ( defined $root && length $root ? ( root => $root ) : () ) );
    return ( $safety, undef ) if $safety->{ok};
    my $why = $safety->{reason} || $safety->{error} || 'no reason given';
    return ( undef,
        { ok => 0, %extra,
            error => "Refusing to $verb: safety snapshot failed - $why",
            ( $safety->{detail} ? ( detail => $safety->{detail} ) : () ) } );
}

# SM084 (the open half, eight-dimension review D5): restore a snapshot. OVERLAY
# semantics, matching install.pl --restore: the tarball's files are written
# back over the docroot; files created since the snapshot are left in place.
# A prerestore safety snapshot is taken first, so the restore is itself
# reversible. Rendered caches for restored sources are dropped afterwards -
# the extracted files carry their ORIGINAL (older) mtimes, so without the
# clear the mtime cache check would keep serving the pre-restore pages.
# SM852: put each restored file where a write to that path belongs - the
# private store for a protected section (existing content keeps its home; a new
# path inherits its nearest existing ancestor's tree), the docroot otherwise.
# Directories are made only as a file needs them, at the resolved location, so
# no public folder appears at a gated path. A link is recreated as a link, as
# the extraction into the docroot did. Returns { placed => N, failed => [...] }.
sub _place_restored {
    my ($stage) = @_;
    my ( $placed, @failed ) = (0);
    File::Find::find(
        { no_chdir => 1,
            wanted => sub {
                my $p = $File::Find::name;
                return if $p eq $stage;
                ( my $rel = substr( $p, length($stage) + 1 ) ) =~ s{\A\./}{};
                my ($dst) = Lazysite::Private::resolve_for_write( $DOCROOT, $rel );
                $dst //= "$DOCROOT/$rel";

                # SM874: A DIRECTORY IS CONTENT TOO, when it is empty.
                #
                # This skipped every directory member and let make_path below
                # create whatever a file needed - which is correct for a
                # directory that has files in it and loses one that does not.
                # Invisible while a restore was purely additive: nothing was
                # removed, so an empty folder simply stayed. `replace` clears
                # the target first, which turned that silent gap into an empty
                # folder an operator created and an undo deleted.
                #
                # The archive HAS the member - `./sites/target/emptydir/` is in
                # it - so this is placing what was always carried, not widening
                # what is restored.
                if ( -d $p && !-l $p ) {
                    make_path($dst) unless -d $dst;
                    return;
                }
                make_path( dirname($dst) ) unless -d dirname($dst);
                if ( -l $p ) {
                    unlink $dst if -l $dst;
                    symlink( readlink($p), $dst ) ? $placed++ : push @failed, "$rel: $!";
                    return;
                }
                require File::Copy;
                File::Copy::copy( $p, $dst ) ? $placed++ : push @failed, "$rel: $!";
            },
        },
        $stage
    );
    return { placed => $placed, failed => \@failed };
}

sub action_backup_restore {
    my ( $name, %opt ) = @_;
    $name = '' unless defined $name;
    return { ok => 0, error => 'Invalid backup name' } unless _valid_name($name);

    # A full-system backup carries the auth secrets and overwrites config/accounts;
    # restoring it (especially onto a different domain) is a deliberate system-user
    # operation via install.pl --restore, not a self-service manager click.
    return { ok => 0, error => 'A full-system backup is restored by a system user '
            . 'with install.pl --restore (use --domain to migrate to another domain), '
            . 'not from the manager. Download it and restore it from the shell.' }
        if $name =~ /\A(?:lazysite-)?full-/;    # new + legacy (pre-prefix) names

    my $full = _dir() . "/$name";
    return { ok => 0, error => 'Backup not found' } unless -f $full;

    # SM484: the archive's members ARE its blast radius - a scoped backup
    # restores exactly its own subtree - so the safety snapshot scopes to the
    # common top directory of the members (excluding ./lazysite, which no
    # content archive carries). Reproduced: the unscoped snapshot tarred the
    # WHOLE tree and refused on an unreadable dir the restore would never
    # touch, so a partner who could back up could not roll back. An archive
    # with no single common directory (a primary-site backup) keeps the full
    # snapshot - for that target it IS the blast radius.
    my @members = _archive_members($full);
    my $scope   = _archive_scope( \@members );
    my ( $safety, $refuse ) = safety_snapshot_or_refuse( 'restore', $scope );
    return $refuse if $refuse;

    # SM874: REPLACE, for the one caller that needs a real undo.
    #
    # A restore is an OVERLAY: it writes the archive's files over the site and
    # never removes anything. For recovering a damaged file that is right. For
    # undoing a site-package apply it is not, and the undo bar promises "puts
    # the site back as it was immediately before the apply" - which is false the
    # moment the package ADDS a file. The field case added 241 files; the
    # reproduction added one (tmp/repro-sm874-apply-undo.pl): after a fully
    # confirmed undo the changed file reverted and the added file stayed.
    #
    # So `replace` clears the target first. Deletion is the reason this is
    # opt-in and narrowly guarded rather than the default:
    #
    #   * ONLY within $scope - the archive's own common directory, which is the
    #     blast radius _archive_scope already computes for the safety snapshot.
    #   * REFUSED when there is no scope. A primary-site archive has no single
    #     common directory, so "clear first" would mean clearing the docroot.
    #     That is the one case where this must never guess (SM306 took a site
    #     private by acting on an absent path; the lesson was to refuse).
    #   * The safety snapshot above is already taken, and covers $scope, so the
    #     deletion is itself reversible.
    #   * The directory itself is kept - only its contents go - so ownership and
    #     the setgid bit that lets the CGI write there survive.
    if ( $opt{replace} ) {
        return { ok => 0, kind => 'invalid',
            error => 'Refusing to replace: this archive covers no single folder, '
                . 'so there is nothing safe to clear first. Restore it as an '
                . 'overlay instead.',
            reason => 'no scope to confine the replace to' }
            unless length $scope;

        my $target = "$DOCROOT/$scope";
        if ( -d $target ) {
            if ( opendir my $dh, $target ) {
                my @kids = grep { !/\A\.\.?\z/ } readdir $dh;
                closedir $dh;
                for my $k (@kids) {
                    my $p = "$target/$k";
                    -d $p ? File::Path::remove_tree($p) : unlink($p);
                }
            }
            else {
                return { ok => 0, kind => 'render-failed',
                    error => "Refusing to replace: cannot read $scope to clear it "
                        . "(safety snapshot kept: $safety->{name})" };
            }
        }
    }

    # SEC-2026-07 (M-TAR): --no-same-permissions (with the existing
    # --no-same-owner) so a hostile or ancient tarball cannot restore setuid/
    # setgid bits or world-writable/over-permissive modes onto the docroot;
    # extracted files take the process umask instead of the archived mode.
    #
    # SEC-2026-07 (M-TAR-AUTH): defence-in-depth against a privilege-escalation
    # chain - a crafted content tarball whose members include lazysite/auth/*
    # (accounts, group grants, the HMAC secret) or lazysite.conf would, on plain
    # extraction, overwrite the auth/config namespace and let a manage_config
    # delegate promote itself to operator. A legitimate CONTENT snapshot never
    # contains ./lazysite (action_backup_create excludes it for every non-full
    # kind), and a FULL snapshot is refused above - so excluding ./lazysite here
    # is a no-op for real archives and neutralises the escalation for a hostile
    # one. tar --exclude drops matching members at extraction time.
    # SM268 C3: `--exclude=./lazysite` matched only archives TAR ITSELF made.
    #
    # GNU tar matches --exclude against the member name as stored. A hostile
    # archive naming its member `lazysite/auth/users` (no `./`) or
    # `.//lazysite/auth/users` did not match, so the M-TAR-AUTH guard above -
    # whose comment says it "neutralises the escalation" - was inert for exactly
    # the archives it was written for. Proven end to end by an adversarial
    # review: an uploaded tarball restored through this action replaced the
    # account store and the group grants with the attacker's.
    #
    # Cover every spelling, and add --anchored so the patterns cannot be
    # side-stepped by nesting. Belt and braces with the wildcard form, which
    # matches a `lazysite` segment wherever tar normalises it to.
    # SM852: INTO A STAGING DIRECTORY, then each file to where it belongs.
    #
    # Extracted straight into the docroot, an archive taken before a folder was
    # protected put that folder's pages back PUBLIC - beside the private copies
    # the engine serves, and as a public folder that sends every later write
    # under it out of the store. So the content lands here first and is placed
    # by _place_restored, through the same resolver every other write uses. The
    # excludes below still decide what is extracted at all.
    my $stage = _dir() . "/.restore-$$-" . time;
    make_path($stage);
    my $rc = system(
        'tar',             'xzf', $full, '-C', $stage,
        '--no-same-owner', '--no-same-permissions',
        '--anchored',
        '--exclude=./lazysite', '--exclude=./lazysite/*',
        '--exclude=lazysite',   '--exclude=lazysite/*',

        # SM286: and the private store, which this pass must NOT touch. Its
        # members are extracted separately, into the docroot's parent, below.
        #
        # Without these the first pass extracts `lazysite-private/...` INTO the
        # docroot - putting every gated file back exactly where the front end
        # serves it, which is the whole exposure, restored from a backup, by the
        # operation meant to recover from one. The existing `lazysite` excludes
        # do not cover it: the names differ, and these members carry no `./`.
        # Caught by the test, not by review.
        #
        # Matched by SUFFIX rather than by this site's own store name. The store
        # is named for its docroot, so an archive made on a site whose docroot
        # had a different basename carries a differently-named member - and an
        # exclude that missed it would extract that store into this docroot,
        # which is the exposure this pass exists to avoid. A wildcard cannot
        # under-match here; the separate pass below is what decides whether the
        # store is restored at all, and it uses the exact name.
        '--no-anchored',
        '--exclude=*lazysite-private',
        '--exclude=*lazysite-private/*',
        '--exclude=*/lazysite/*',
    );
    if ( $rc != 0 ) {
        File::Path::remove_tree($stage);
        return { ok => 0, error => 'Restore extraction failed (safety snapshot kept: '
                . $safety->{name} . ')' };
    }
    my $placed = _place_restored($stage);
    File::Path::remove_tree($stage);
    return { ok => 0, error => 'Restore could not place every file (safety snapshot kept: '
            . $safety->{name} . '): ' . join( '; ', @{ $placed->{failed} } ) }
        if @{ $placed->{failed} };

    # SM286: the private store, extracted in its OWN pass, into the docroot's
    # parent - because that is where it lives.
    #
    # This is the most dangerous line in the file and it is worth saying why.
    # The pass above extracts an operator-supplied archive INTO the docroot; the
    # SEC-2026-07 review showed an uploaded tarball replacing the account store
    # through exactly this action, and the `lazysite` excludes are the fix. This
    # pass extracts OUTSIDE the docroot, so a careless version would let an
    # uploaded archive write anywhere its member names pointed.
    #
    # Confined three ways, none of them sufficient alone:
    #   * only members named `lazysite-private` are extracted at all - an
    #     explicit member list, not a filter, so anything else in the archive is
    #     never a candidate;
    #   * --anchored, so the name cannot be reached by nesting;
    #   * the leading `/` strip and `..` refusal that GNU tar applies by default,
    #     which stop an absolute or climbing member.
    # And the pass runs only when the archive actually contains such a member,
    # so an archive without one does no extraction outside the docroot at all.
    {
        my $priv = Lazysite::Private::private_root($DOCROOT);
        my $leaf = defined $priv ? basename($priv) : undef;
        if ( defined $leaf && length $leaf ) {
            if ( grep { index( $_, "$leaf/" ) == 0 } @members ) {
                # SM769: extract INTO the store, not into its parent - the
                # parent is the domain folder the request path cannot open
                # (see action_backup_create). --strip-components=1 drops the
                # `leaf/` prefix the archive carries; --anchored $leaf still
                # confines the pass to that one member. The store is made
                # first, with the docroot's identity, as Private makes it.
                Lazysite::Private::ensure_store($DOCROOT) unless -d $priv;
                my $prc = system(
                    'tar',             'xzf', $full, '-C', $priv,
                    '--no-same-owner', '--no-same-permissions',
                    '--anchored',      '--strip-components=1', $leaf,
                );
                return {
                    ok    => 0,
                    error => 'Restore of the private content store failed '
                        . '(safety snapshot kept: ' . $safety->{name} . ')'
                } if $prc != 0;
            }
        }
    }

    # Drop render caches: only .html with a .md sibling (a bare legacy .html is
    # real migration content since SM133, never a cache - leave it alone).
    my $cleared = 0;
    File::Find::find(
        { no_chdir => 1,
            wanted => sub {
                my $p = $File::Find::name;
                return unless $p =~ /\.html\z/ && -f $p;
                return if index( $p, Lazysite::Paths::internal_lazysite_dir($DOCROOT) . '/' ) == 0;
                ( my $src = $p ) =~ s/\.html\z/.md/;
                return unless -f $src;
                unlink $p and $cleared++;
            },
        },
        $DOCROOT
    );
    # SM110: backups exclude lazysite/cache entirely, so the per-alias-host
    # tree survives a restore and would serve pre-restore renders - drop it
    # wholesale; each host re-renders on its next request.
    Lazysite::Util::clear_host_cache($DOCROOT);

    # SM085: a restore is visible content history, not history erasure - commit
    # the restored state of the whole versioned set (no-op when git is off).
    require Lazysite::Git;
    Lazysite::Git::commit_all( $DOCROOT, $auth_user, "restore from backup $name" );

    log_event( 'INFO', 'backup-restore', 'snapshot restored', file => $name,
        safety => $safety->{name}, cache_cleared => $cleared, user => $auth_user );
    return { ok => 1, restored => $name, safety => $safety->{name},
        cache_cleared => $cleared };
}

# Streams the tarball (Content-Disposition attachment). Returns an error hash
# only on a pre-stream failure; on success it has already written the response.
sub action_backup_download {
    my ($name) = @_;
    $name = '' unless defined $name;
    return { ok => 0, error => 'Invalid backup name' } unless _valid_name($name);
    my $full = _dir() . "/$name";
    return { ok => 0, error => 'Backup not found' } unless -f $full;

    my $size = ( stat $full )[7] // 0;
    log_event( 'INFO', 'backup-download', 'backup downloaded', file => $name, user => $auth_user );

    return { ok => 0, error => 'Cannot read backup' }
        unless Lazysite::Manager::Upload::stream_attachment( $full,
        'application/gzip', $name, $size );
    return { ok => 1, streamed => 1 };
}

1;
