package Lazysite::ControlApi::Actions;

# SM350: the control API's action reference, as data.
#
# WHAT WAS MISSING. MCP has tools/list, with a JSON Schema per tool. The control
# API is an enforced, first-class channel - describe-capabilities declares it as
# one - and had no equivalent and no documentation page. Across 23 reference docs
# and 7 briefings, a search for its action names returned one incidental mention.
# So the only way to learn what an action takes was to read the CGI, which a
# token client cannot do, or to try it and read the error.
#
# WHY THIS IS A DECLARATION AND NOT A DISPATCH TABLE. The filing asked for the
# reference to be GENERATED from the dispatch table rather than hand-written,
# citing three defects already caused by hand-maintained lists. It is right, and
# there is no dispatch table to generate from: the control API dispatches through
# a 108-branch if/elsif chain. SM237 met the same wall, wrote %KNOWN_ACTION as a
# literal, said plainly that the chain "is the underlying issue and it deserves
# its own request", and pinned the literal to the chain with t/lint/22 so drift
# is impossible.
#
# This takes the same treatment one step further. The table below was EXTRACTED
# from the chain rather than typed, and t/lint/58 re-extracts it and fails on any
# difference - action set, capabilities and parameters alike. So it is a fourth
# list, and it is a fourth list that cannot drift, which is the property the
# filing actually wanted. Replacing the chain with a real table remains the right
# fix and remains its own piece of work.
#
# THE THREE CAPABILITY STATES, which are the useful part of this document:
#
#   caps => ['manage_themes','manage_layouts']   any ONE of these is enough
#   caps => []                                   any authenticated caller
#                                                (introspection: whoami,
#                                                describe-capabilities)
#   caps => undef                                NOT reachable with a token.
#                                                Cookie-only - the manager UI
#                                                calls it and an agent cannot.
#
# The third state is the one a caller cannot discover any other way, and it is
# the reason SM237 needed %KNOWN_ACTION at all: without it the token gate could
# not tell "exists, but cookie-only" from "no such action", and reported both as
# the former.
#
# `required => 1` MARKS A PARAMETER THE ACTION REFUSES TO RUN WITHOUT, and
# the dispatcher answers its absence before the branch is reached, in one
# sentence naming the parameter and where it goes (SM773). It is marked only
# where the handler ALREADY refuses an absent value, so hoisting the check
# changes the message and never the behaviour - and the set grows by evidence,
# never by guessing which parameters an action could do without. A `note`
# carries what the generated sentence cannot know - that an empty value MEANS
# something here, which is the difference between "false" and "no answer" and
# the reason this check asks whether a parameter was SENT rather than whether
# it is true. An unmarked
# parameter is not "optional"; it is one nobody has established either way.
#
# WHERE A PARAMETER IS READ FROM is recorded because the two channels are not
# interchangeable in the chain. `query` is the query string, `body` is the JSON
# request body, and `query_or_body` means the branch accepts either - which is
# real, not a hedge: several actions read the query string and fall back to the
# body, and a caller sending only one of them needs to know which.

use strict;
use warnings;

# action => { caps, params => [ { name, in } ] }
#
# EXTRACTED FROM THE CHAIN. Regenerate rather than edit: any change belongs in
# lazysite-manager-api.pl, and t/lint/58 will fail until this matches it.
our %ACTION = (
    'acl-get' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' } ] },
    'acl-remove' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' } ] },
    'acl-set' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query_or_body' }, { name => 'read', in => 'body' }, { name => 'write', in => 'body' }, { name => 'owner', in => 'body' }, { name => 'draft', in => 'body' } ] },
    'actions-list' => { caps => [], params => [] },
    # SM576 part 1: the brief store's own capability. A read takes EITHER
    # (the three-state note above: any ONE of the listed caps is enough), so a
    # long-standing manage_content grant keeps reading; a write takes
    # manage_briefs alone.
    'brief-read' => { caps => [ 'manage_content', 'manage_briefs' ], params => [ { name => 'path', in => 'query', required => 1 } ] },
    'brief-append' => { caps => ['manage_briefs'], params => [ { name => 'path', in => 'query', required => 1 }, { name => 'entry', in => 'body', required => 1 } ] },
    'briefs-migrate' => { caps => ['manage_briefs'],                     params => [] },
    'briefs-list'    => { caps => [ 'manage_content', 'manage_briefs' ], params => [] },
    'brief-delete' => { caps => ['purge'], params => [ { name => 'path', in => 'query' } ] },
    'aliases-list' => { caps => ['manage_content'], params => [ { name => 'host', in => 'query' }, { name => 'path', in => 'query' } ] },
    'analyse_visitors' => { caps => ['analytics'], params => [ { name => 'window', in => 'query' }, { name => 'day', in => 'query' }, { name => 'month', in => 'query' }, { name => 'index', in => 'query' }, { name => 'trails', in => 'query' } ] },
    'artifact-backups-delete' => { caps => ['purge'], params => [ { name => 'path', in => 'query' } ] },
    'artifact-manifest' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'artifact-validate' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'audit' => { caps => ['audit'], params => [ { name => 'user', in => 'query' }, { name => 'target', in => 'query' }, { name => 'start', in => 'query' }, { name => 'end', in => 'query' }, { name => 'page', in => 'query' }, { name => 'per_page', in => 'query' } ] },
    'backup-create' => { caps => undef, params => [ { name => 'scope', in => 'query' } ] },
    'backup-delete' => { caps => undef, params => [ { name => 'name', in => 'query_or_body' } ] },
    'backup-download' => { caps => undef, params => [ { name => 'name', in => 'query' } ] },
    'backup-list'     => { caps => undef, params => [] },
    # SM874: `replace` is the undo-of-apply mode - the target folder is cleared
    # before the snapshot is written back, so files a package ADDED are removed
    # too. Absent or false keeps the historic overlay behaviour.
    'backup-restore' => { caps => undef, params =>
            [ { name => 'name', in => 'query' }, { name => 'replace', in => 'query' } ] },
    'bad-url-blocks' => { caps => ['manage_config'], params => [] },
    'bad-url-block' => { caps => ['manage_config'], params => [ { name => 'ip', in => 'query' } ] },
    'bad-url-unblock' => { caps => ['manage_config'], params => [ { name => 'ip', in => 'query' } ] },
    'cache-invalidate' => { caps => undef, params => [ { name => 'path', in => 'query' }, { name => 'host', in => 'query' } ] },
    'cache-list'       => { caps => undef,             params => [] },
    'channel-services' => { caps => undef,             params => [] },
    'config-read'      => { caps => ['manage_config'], params => [] },
    'config-set' => { caps => ['manage_config'], params => [ { name => 'key', in => 'query_or_body', required => 1 }, { name => 'value', in => 'query_or_body' } ] },
    'copy' => { caps => undef, params => [ { name => 'path', in => 'query' }, { name => 'to', in => 'query' } ] },
    'csrf-token' => { caps => undef, params => [] },

    # SM447: the data tables. EXTRACTED from the dispatch chain, like every
    # entry here - t/lint/58 re-extracts and fails on any difference, so this
    # is a fourth list that cannot drift.
    #
    # NOTE `in => 'query'` throughout: this field records HOW THE CHAIN READS
    # the parameter (%params, populated from either source), not which HTTP
    # method is allowed. The three writers are POST-forced via %MUTATING and
    # t/lint/14 asserts it.
    #
    # `row` is a JSON OBJECT in one parameter rather than loose fields,
    # deliberately: a descriptor may declare a field called `table` or `key`,
    # and flattening the row into the query would make the site's own data
    # collide with the action's own parameters.
    'data-migrate' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' } ] },
    'data-rebuild' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query_or_body' }, { name => 'confirm_lost', in => 'body' } ] },
    'data-row-delete' => { caps => [ 'manage_data', 'write_data' ], params => [ { name => 'table', in => 'query_or_body' }, { name => 'key', in => 'query_or_body' } ] },
    'data-row-save' => { caps => [ 'manage_data', 'write_data' ], params => [ { name => 'table', in => 'query_or_body' }, { name => 'key', in => 'query_or_body' }, { name => 'row', in => 'body' } ] },
    'data-rows' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' }, { name => 'order_by', in => 'query' }, { name => 'order', in => 'query' }, { name => 'limit', in => 'query' }, { name => 'offset', in => 'query' } ] },
    'data-table' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' } ] },
    'data-table-source' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' } ] },
    'data-migrate-plan' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' } ] },
    # SM687: a table's access rule. Gated on manage_content, matching a file's
    # rule rather than inventing a separate policy for tables - reaching the
    # Data page needs manage_data too, so in practice a person holds both.
    'data-table-acl-get' => { caps => ['manage_content'],
        params => [ { name => 'table', in => 'query' } ] },
    'data-table-acl-set' => { caps => ['manage_content'],
        params => [ { name => 'table', in => 'query_or_body' },
            { name => 'owner', in => 'body' },
            { name => 'read',  in => 'body' },
            { name => 'write', in => 'body' } ] },
    'data-table-acl-remove' => { caps => ['manage_content'],
        params => [ { name => 'table', in => 'query' } ] },
    'data-table-save' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query_or_body' }, { name => 'descriptor', in => 'body' } ] },
    'data-import' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' }, { name => 'apply', in => 'query' } ] },
    'data-export' => { caps => ['manage_data'], params => [ { name => 'table', in => 'query' }, { name => 'format', in => 'query' } ] },
    'data-table-drop' => { caps => ['housekeeping'], params => [ { name => 'table', in => 'query_or_body' }, { name => 'confirm', in => 'body' } ] },
    'data-tables'         => { caps => ['manage_data'], params => [] },
    'data-safety-exports' => { caps => ['manage_data'], params => [] },
    'data-safety-export-delete' => { caps => ['purge'], params => [ { name => 'file', in => 'query_or_body' } ] },
    'data-safety-export-read' => { caps => ['manage_data'], params => [ { name => 'file', in => 'query' } ] },
    'data-safety-export-restore' => { caps => ['manage_data'], params => [ { name => 'file', in => 'query_or_body' }, { name => 'apply', in => 'query_or_body' } ] },
    'delete' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'describe-capabilities' => { caps => [], params => [] },

    # SM778: resolve logins the caller ALREADY HOLDS to display names. No
    # capability beyond being signed in, because it answers only for the logins
    # it is given: it is not a listing of accounts and must never become one.
    'display-names' => { caps => [], params => [ { name => 'logins', in => 'query_or_body', required => 1, note => 'an array of logins in the body, or a comma-separated list in the query' } ] },
    'domain-add' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'body' }, { name => 'content_root', in => 'body' }, { name => 'site_url', in => 'body' }, { name => 'site_name', in => 'body' }, { name => 'theme', in => 'body' }, { name => 'layout', in => 'body' }, { name => 'nav_file', in => 'body' }, { name => 'search_default', in => 'body' }, { name => 'lang', in => 'body' }, { name => 'lang_group', in => 'body' }, { name => 'seed', in => 'body' } ] },
    'domain-check' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'query' } ] },
    'domain-preview' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'query' } ] },
    'domain-remove' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'body' }, { name => 'purge', in => 'body' } ] },
    'domain-set' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'body' }, { name => 'key', in => 'body' }, { name => 'value', in => 'body' } ] },
    # SM802: the URL remapper - per-host rules, operator-only.
    'remap-list' => { caps => ['manage_domains'], params => [] },
    'remap-save' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'body', required => 1 }, { name => 'rules', in => 'body', required => 1 } ] },
# N13-04: the audit trail's switch - audit_switch AND manage_config (the second checked in the dispatch).
    'audit-trail-set' => { caps => ['audit_switch'], params => [ { name => 'state', in => 'body', required => 1 }, { name => 'reason', in => 'body' } ] },
    'domains-list'  => { caps => ['manage_domains'], params => [] },
    'file-download' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'file-upload'   => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'file-zip-download' => { caps => undef, params => [] },
    # SM652: read_submissions ONLY, on both channels - form-list returns
    # row_count, which is a read of submission EXISTENCE.
    'form-list' => { caps => ['read_submissions'], params => [] },
    'form-submission-confirm' => { caps => undef, params => [ { name => 'file', in => 'query_or_body' }, { name => 'id', in => 'body' } ] },
    'form-submission-delete' => { caps => undef, params => [ { name => 'file', in => 'query_or_body' }, { name => 'id', in => 'body' } ] },
    # SM652: manage_forms is definition-only now; reading a submission needs
    # the least-privilege capability built for it.
    # SM862: `form` is the one to reach for - it is what the MCP twin and
    # form-targets-read take - and `file` stays for a store named by path.
    # Neither is marked required: exactly one is needed, and the action answers
    # for that by name rather than letting the path validator call an absence a
    # malformed value.
    'form-submissions' => {
        caps   => ['read_submissions'],
        params => [
            { name => 'form', in => 'query',
                note => 'the form\'s name; its store is resolved from the handler it binds to' },
            { name => 'file', in => 'query',
                note => 'the path to a .jsonl store, when naming one directly; `form` is preferred' },
        ],
    },
    'form-submissions-delete-bulk' => { caps => undef, params => [ { name => 'file', in => 'query_or_body' }, { name => 'ids', in => 'body' } ] },
    # SM842: a form's targets name handlers and nothing else, on the token
    # channel as on every other.
    'form-targets-read' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [ { name => 'form', in => 'query', required => 1 } ] },
    'form-targets-save' => { caps => ['manage_forms'], params => [ { name => 'form', in => 'query_or_body', required => 1 }, { name => 'handlers', in => 'body', note => 'a list of handler ids; `targets` as [{handler: id}] is read the same way' }, { name => 'targets', in => 'body' } ] },
    'git-history' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' }, { name => 'limit', in => 'query' } ] },
    # SM664: reachable with either - the overview sits on the Plugin Config
    # page, whose audience holds manage_config, and is a reporting read.
    'git-history-summary' => { caps => [ 'manage_content', 'manage_config' ], params => [] },
    'git-init'            => { caps => ['manage_config'], params => [] },
    'git-restore' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' }, { name => 'sha', in => 'query' } ] },
    'git-show' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' }, { name => 'sha', in => 'query' } ] },
    'git-status' => { caps => ['manage_content'], params => [] },
    # SM632: the inverse of bind_form. Gated on manage_forms for a token, and
    # confirmation names the form - a destructive verb taking only an id is one
    # an agent fires by having the wrong id.
    'form-delete' => { caps => ['manage_forms'],
        # Exactly data-table-drop's shape: the OBJECT may come either way, the
        # CONFIRMATION is body-only. Declaring `form` as body-only was wrong -
        # the dispatch reads `$req->{form} // $params{form}` - and t/lint/58
        # extracts the branch rather than trusting this table, so it said so.
        params => [ { name => 'form', in => 'query_or_body' },
            { name => 'confirm', in => 'body' } ] },
    # SM842: handler CRUD reaches the token channel, reversing SM799's
    # cookie-only rule. Any of the three destination capabilities opens the
    # door; the handler's type then decides (Lazysite::Handlers::cap_for_type).
    'handler-delete' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [ { name => 'id', in => 'body', required => 1 } ] },
    'handler-list' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [] },
    'handler-save' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [ { name => 'id', in => 'body', required => 1 }, { name => 'type', in => 'body', required => 1, note => 'smtp, file, table or connector; handler-list returns each type\'s fields' }, { name => 'name', in => 'body', required => 1 }, { name => 'enabled', in => 'body' } ] },
    'schedule-list' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [] },
    'schedule-save' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [ { name => 'id', in => 'body', required => 1 }, { name => 'handler', in => 'body', required => 1 }, { name => 'every', in => 'body', required => 1, note => 'seconds, at least 300' }, { name => 'payload', in => 'body', note => 'a flat object of fixed fields' }, { name => 'enabled', in => 'body' } ] },
    'schedule-delete' => { caps => [ 'manage_forms', 'manage_data', 'manage_connectors' ], params => [ { name => 'id', in => 'body', required => 1 } ] },
    'key-revoke'     => { caps => undef, params => [] },
    'keys-list'      => { caps => undef, params => [] },
    'lang-status' => { caps => ['manage_content'], params => [ { name => 'group', in => 'query' } ] },
    'layout-activate' => { caps => ['manage_layouts'], params => [ { name => 'path', in => 'query' }, { name => 'layout', in => 'query' } ] },
    'layout-delete' => { caps => ['manage_layouts'], params => [ { name => 'path', in => 'query' } ] },
    'layout-install'    => { caps => ['manage_layouts'], params => [] },
    'layouts-available' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'layouts-install'  => { caps => undef,                                 params => [] },
    'layouts-manifest' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'layouts-release-contents' => { caps => undef, params => [ { name => 'tag', in => 'query' } ] },
    'layouts-releases' => { caps => undef, params => [] },
    'layouts-repo-get' => { caps => undef, params => [] },
    'layouts-repo-set' => { caps => undef, params => [ { name => 'value', in => 'body' } ] },
    'list' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'lock' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'migrate-to-local' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'mkdir' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'move' => { caps => undef, params => [ { name => 'path', in => 'query' }, { name => 'to', in => 'query' } ] },
    'nav-read' => { caps => [ 'manage_content', 'manage_nav' ], params => [ { name => 'host', in => 'query' } ] }, # SM568
    'nav-save' => { caps => ['manage_nav'], params => [ { name => 'items', in => 'body' }, { name => 'host', in => 'query_or_body' } ] },
    'notices'      => { caps => ['notifications'], params => [] },
    'notices-seen' => { caps => undef,             params => [] },
    # SM732: the PDF render, which SM706 shipped with no caller at all.
    # manage_content because converting a page is reading it in another format -
    # the plugin's own reasoning, and the reason it declares no capability.
    'page-pdf' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' } ] },
    'pages' => { caps => [ 'manage_content', 'manage_nav' ], params => [] },    # SM568
    'plugin-action' => { caps => undef, params => [ { name => 'plugin', in => 'query' }, { name => 'script', in => 'body' }, { name => 'action_id', in => 'body' }, { name => 'params', in => 'body' } ] },
    'plugin-disable' => { caps => undef, params => [ { name => 'script', in => 'body' } ] },
    'plugin-enable' => { caps => undef, params => [ { name => 'script', in => 'body' } ] },
    'plugin-list'   => { caps => undef, params => [] },
    'plugin-read' => { caps => undef, params => [ { name => 'plugin', in => 'query' }, { name => 'script', in => 'body' } ] },
    'plugin-save' => { caps => undef, params => [ { name => 'plugin', in => 'query' }, { name => 'script', in => 'body' }, { name => 'values', in => 'body' } ] },
    'preview'       => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'preview-clear' => { caps => undef, params => [] },
    'preview-grant' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'preview-public' => { caps => ['manage_content'], params => [ { name => 'path', in => 'query' } ] },
    'principals'         => { caps => undef, params => [] },
    'protected-sections' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'read' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'recent-changes' => { caps => undef, params => [ { name => 'window', in => 'query' } ] },
    'regenerate-registries' => { caps => ['manage_content'], params => [] },
    'renew-lock' => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'rotate-auth-secret' => { caps => undef, params => [] },
    'save' => { caps => undef, params => [ { name => 'path', in => 'query' }, { name => 'content', in => 'body' }, { name => 'mtime', in => 'body' } ] },
    'session-revoke'    => { caps => undef,              params => [] },
    'sessions-list'     => { caps => undef,              params => [] },
    'site-backup-apply' => { caps => ['manage_domains'], params => [] },
    'site-backup-create' => { caps => ['manage_domains'], params => [ { name => 'host', in => 'query_or_body' }, { name => 'data_tables', in => 'body' } ] },
    'site-backup-delete' => { caps => ['manage_domains'], params => [ { name => 'name', in => 'query_or_body', required => 1 } ] },
    'site-backup-download' => { caps => ['manage_domains'], params => [ { name => 'name', in => 'query_or_body' } ] },
    'site-backup-inspect' => { caps => ['manage_domains'], params => [ { name => 'name', in => 'query' }, { name => 'host', in => 'query' } ] },
    'site-backup-upload' => { caps => ['manage_domains'], params => [] },
    'site-export-primary' => { caps => ['manage_content'], params => [ { name => 'data_tables', in => 'body' } ] },
    'theme-activate' => { caps => ['manage_themes'], params => [ { name => 'path', in => 'query' }, { name => 'theme', in => 'query' } ] },
    'theme-copy' => { caps => ['manage_themes'], params => [ { name => 'path', in => 'query', required => 1 }, { name => 'new_name', in => 'body', required => 1 }, { name => 'layout', in => 'body' } ] },
    'theme-delete' => { caps => ['manage_themes'], params => [ { name => 'path', in => 'query' } ] },
    'theme-list' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'theme-rename' => { caps => undef, params => [ { name => 'path', in => 'query' }, { name => 'new_name', in => 'body' } ] },
    'theme-upload' => { caps => undef, params => [ { name => 'filename', in => 'query' } ] },
    'themes-for-layout' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [ { name => 'layout', in => 'query' } ] },
    'themes-list-all' => { caps => [ 'manage_themes', 'manage_layouts' ], params => [] },
    'unlock'      => { caps => undef, params => [ { name => 'path', in => 'query' } ] },
    'user-revoke' => { caps => undef, params => [] },
    'users'       => { caps => undef, params => [] },
    'version'     => { caps => undef, params => [] },
    # SM671: `plugins=0` omits the plugin catalogue, which is 82% of the answer
    # on a bare site. Opt-out rather than opt-in, so an existing client reading
    # `plugins` keeps seeing it.
    # SM579: connectors. connector-call's caps are undef because the CONNECTOR
    # gates it (callers groups or manage_connectors) - see Connectors::may_call.
    'connector-list' => { caps => ['manage_connectors'], params => [] },
    'connector-save' => { caps => ['manage_connectors'], params => [ { name => 'id', in => 'body' }, { name => 'connector', in => 'body' } ] },
    'connector-secret-set' => { caps => ['manage_connectors'], params => [ { name => 'id', in => 'body', required => 1 }, { name => 'secret', in => 'body', required => 1 } ] },
    'connector-delete' => { caps => ['manage_connectors'], params => [ { name => 'id', in => 'body', required => 1 } ] },
    # SM781: caps => [] - NO capability, not "cookie-only". undef here means
    # the cookie channel alone serves the action, and connector-call is
    # served on every channel (gate 'ALWAYS'); the field found it working and
    # missing from actions-list, and SM779's map would have marked it
    # cookie_only. The connector gates it (Connectors::may_call).
    'connector-call' => { caps => [], params => [ { name => 'id', in => 'body' }, { name => 'payload', in => 'body' }, { name => 'row', in => 'body', note => 'a row key: the connector\'s row_map decides which of its columns are sent' } ] },
    'connector-calls' => { caps => ['manage_connectors'], params => [ { name => 'connector', in => 'query' }, { name => 'state', in => 'query' }, { name => 'limit', in => 'query' } ] },
    'start-page' => { caps => undef, params => [ { name => 'username', in => 'query' } ] },
    'start-page-set' => { caps => undef, params => [ { name => 'username', in => 'body' }, { name => 'value', in => 'body', required => 1, note => 'an empty string clears the start page' } ] },
    'whoami' => { caps => [], params => [ { name => 'plugins', in => 'query' } ] },
);

# The actions this caller may use, in the shape describe_capabilities uses for
# its own lists. Subsets by grant exactly as tools/list does (SM210), so an
# account is never shown an action it cannot call - a reference listing
# everything would be a list of things to try and be refused.
#
# A COOKIE-ONLY action is omitted for a token caller and included for a cookie
# session, because that is precisely what its availability depends on.
sub actions_for {
    my ( $caps, %opt ) = @_;
    $caps ||= {};
    my @out;
    for my $name ( sort keys %ACTION ) {
        my $spec        = $ACTION{$name};
        my $caps_needed = $spec->{caps};

        my $available;
        if    ( !defined $caps_needed ) { $available = $opt{cookie} ? 1 : 0 }
        elsif ( !@$caps_needed )        { $available = 1 }
        else { $available = ( grep { $caps->{$_} } @$caps_needed ) ? 1 : 0 }
        next unless $available;

        push @out, {
            action => $name,
            params => [ map { { %$_ } } @{ $spec->{params} } ],
            ( defined $caps_needed
                ? ( capabilities => [@$caps_needed] )
                : ( cookie_only => 1 ) ),
        };
    }
    return \@out;
}

1;
