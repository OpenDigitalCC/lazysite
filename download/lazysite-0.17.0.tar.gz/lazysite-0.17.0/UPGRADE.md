# Upgrade notes

## How to upgrade — the one way, for every release below

This does not change per release, so it is stated once, here. Install the newer
lazysite on the host, then move each site to it:

```bash
lazysite upgrade --docroot /path/to/public_html          # one site
sudo lazysite upgrade --all                              # every registered site
```

`--dry-run` on the single-site form reports the plan and writes nothing.
From an unpacked tarball, before any package is installed, the same verb works
out of the tree: `perl tools/lazysite-cli.pl upgrade --docroot ...`. The
cgi-bin comes from the site's registry entry; a site with none (provisioned
before the registry existed, or on a host where `/etc/lazysite/sites.d` was
not writable) needs `--cgibin` too, and the verb says so. On a HestiaCP host
`--installdir /home/<user>/web/<domain>` stands for both paths.

**You say which operation you mean.** Nothing infers it from the state of the
disk, and each verb refuses rather than quietly doing one of the others:

| Verb | For | Refuses |
| --- | --- | --- |
| `provision` | a site that does not exist yet | a docroot that already has one |
| `upgrade` | moving an installed site to this version | nothing installed, or already at this version |
| `reinstall` | re-laying THIS version's files over a site that has them, leaving content, accounts and config alone | a version mismatch — that is an upgrade |

Not `reinstall` but `repair` when the files are right and the ownership, modes
or missing directories are not: `repair` touches no files.

Backups are written before every upgrade and reinstall:

```bash
lazysite backups --docroot /path/to/public_html            # list
lazysite backups --docroot /path/to/public_html --restore  # most recent back
```

`install.sh` installs nothing. It is kept as a signpost to the verbs above,
because the documentation named it for years and deleting it would strand
anyone still typing it.

**After an upgrade, restart anything holding engine code.** A plain CGI site
reads the engine fresh per request and needs nothing. A site on the persistent
runtime or the FastCGI pool has the previous engine in memory; the single-site
verbs name the units, and `upgrade --all` (root) restarts them itself.

**A security release reaches every site, stable ones included.** A release whose
manifest declares `"security_critical": true` (cut on stable with `tools/release.sh
--final --security-critical`; SM1314) is pushed past each site's `update_channel`:

```bash
# a HestiaCP host - its sites are not in the registry; as root:
bash /tmp/lazysite-X.Y.Z/installers/hestia/lazysite-hestia-update-all.sh --force-security
# a host whose sites are registered (/etc/lazysite/sites.d):
sudo lazysite upgrade --all --force-security
```

Both refuse the flag, before any site is touched, for a release that does not
declare itself security-critical. The Hestia updater names each site it forced
in the table, the findings and the summary, and each site's audit log records
`upgrade-forced`; a site excluded from the update (an install marker without the
lazysite-app template) stays excluded. On a Hestia host with no registry,
`lazysite upgrade --all` says to use the updater rather than reporting nothing
to do (SM1307).

Sections below are per-release notes, newest first. Where an older section says
`install.sh`, read it as a record of what that release did.

## An unfinished backup is named, a full backup runs in the background, and the rest of 0.17.0 (the stable)

0.17.0 is the stable (rulings 227, 242): the 0.16.12 beta plus only the fixes of the 0.16.11 and
0.16.12 field passes, listed below, and the first stable since 0.16.0. It is not security-critical.
**A site on the stable line (0.16.0) takes 0.16.1 to 0.16.12 in order, then this**, and the
sections below are those releases' notes, newest first, so read them from the bottom up: 0.16.1
and 0.16.2 have no section here (the CHANGELOG has them: 0.16.2 closed a theme archive planting a
link in the served asset mirror, so run `lazysite check`, which names a link already planted,
remove it and rotate the session secret as docs/OPERATOR.md says; and from 0.16.1 the visitor log
names signed-in accounts); 0.16.3, "Starter pages are opt-in for new sites" and "The /docs manual
moves into the engine", with `lazysite check` naming any access rule wider than the rule around
it; 0.16.4, "Plugins become extensions"; 0.16.5, "Address lists become address profiles"; 0.16.6,
"The primary's content leaves out the other domains"; 0.16.7, "Odoo's modules leave core's lib";
0.16.8, "Odoo's actions become the extension's"; 0.16.9, "A broken store now refuses", the longest,
with the Odoo package, CryptX and the container; 0.16.10, "The container image carries git";
0.16.11, "Address profiles are chosen from those that exist"; and 0.16.12, "A full restore gives a
site that serves". Then run `lazysite upgrade` once, run `lazysite check`, and restart what holds
engine code. The feature freeze is over: 0.17.x edge takes the features held for it.

**An unfinished backup is named, and is yours to remove (SM1446).** A backup whose request was
killed before tar finished left its name in `lazysite/backups/` as an empty file (or, if it was
taken before SM885, as an archive that stops part way), and the Backups page listed it as a
backup. After the upgrade the page shows each such file under "Unfinished backups" and
`lazysite check` names it with its date. Nothing removes one for you: when no backup is being
taken, delete it on the Backups page or with `rm lazysite/backups/<name>`, and remove any
`lazysite/backups/.stage-*` directory the check names. Restore, a site-package apply and
`install.pl --restore-full` refuse an unfinished file by name.

**A full backup runs in the background (SM1446, ruling 248).** The Backups page's full-system
backup, and `backup-create` with `scope=full`, now answer at once with the file's name and
`in_progress: true`; the backup is taken by a process of the user the manager runs as, which carries on
after the request. A script that called `backup-create&scope=full` and read `sha256` or `size`
from the answer should instead read `backup-list` until the name is listed under `backups` (or
under `unfinished`, if it stopped). A second full backup is refused while one is being taken
(409, naming it); restore and delete refuse the one in progress. A content backup is unchanged.

**Smaller changes, nothing to do.**

- The bad-URL blocker counts requests for credential files (SM1444, ruling 245): `/.docker/`,
  `/.claude/`, `/.cursor/`, `/.kube/`, `/.azure/`, `/.vscode/`, `/.idea/`, `/.terraform/`,
  `/.gnupg/`, `appsettings*.json`, `aws-exports.js` and `/wp-json/batch` join the built-in
  patterns, as `/.env` always was. No lazysite site serves them; a file the site really has is
  still spared, and `bad_url_extra` still adds. `/app.js` is not counted.
- A refusal names the user who can run the command (SM1447). On a Hestia host the store files in
  `lazysite/auth/` belong to the web server's user, not to the directory's owner, so
  `lazysite acl` as root, the handlers tool, the users tool and `lazysite check` now name the
  owner of the files they read and write (each owner, where they differ), and the
  address-profile refusal names the file's owner and the user to run as. A refusal through a web
  door still names no unix user.
- `lazysite check` says ok only about what it read (SM1447): a walk that could not read part of
  the tree prints no ok and warns, naming the user who owns what was not read; an `acls.json`
  that will not decode now makes the page check say so instead of "0 public page(s)"; every
  piece of advice spells the command that exists on the host. The upgrade's ADDRESS PROFILES
  line says it could not check an unread directory, names its owner and the rerun.
- The restore rehearsal on the shipped 0.16.12 tarball is recorded in docs/RELIABILITY.md
  (SM1443), and `t/tools/158` runs in a fraction of the time (SM1442).

## A full restore gives a site that serves, and the rest of 0.16.12 (the second beta)

0.16.12 is the second beta (ruling 242): 0.16.11 plus the changes below, on the beta channel,
and the release the 0.17.0 stable is promoted from. It is not security-critical, so it reaches
only the sites that take beta builds. The feature freeze still holds: only fixes follow it.

**`--restore-full` is one command (SM1439, ruling 239).** `install.pl --restore-full` (and
`lazysite backups --restore-full`) used to extract the docroot only, so the restored site had no
cgi-bin entry points and no serving group, and ended on "Check file ownership/permissions on the
target host". It now lays the engine's entry points from the release it runs, as provision does,
applies the serving group and the modes, writes the install state, and ends with the health check
(exit 4 when the site is not serviceable yet). A restore script or runbook now needs `--cgibin`
(or, for `lazysite backups`, `--installdir`) and, on a host that does not serve under `www-data`,
`--serving-group`. Without `--cgibin` the command refuses before it extracts anything and prints
the command to run. It also refuses, with nothing changed, a backup whose `lazysite/`,
`lazysite/auth` or `lazysite/forms` is a symlink. Run it from the unpacked release you want on the
restored site.

**Smaller changes, nothing to do.**

- A refusal names the unix user to run as (SM1440). `lazysite acl set` as root names the user that
  owns `lazysite/auth/` and spells the command with it; a command that cannot read an auth store
  says which user it ran as and who owns the file. Through the manager API or MCP the same
  refusal says "the web server's user" and "the owner of the file" and names no unix user.
  "Nothing was changed" stays.
- `lazysite check` says ok only about what it read (SM1440): when it could not read acls.json it
  says it could not check the address profiles a rule names, naming the file, the user and the
  owner, instead of printing "ok". The "re-run with --fix" hint shows only when `--fix` has
  something to apply.
- `group-settings-set` with an address limit on a group that does not exist is refused, naming
  the group (SM1440); before, it said a profile was missing, or wrote a record for the group.
  Create the group first with `group-create`.
- The restore rehearsal of 11 Nov 2026 is recorded in docs/RELIABILITY.md (SM1438).

## Address profiles are chosen from those that exist, and the rest of 0.16.11 (the beta)

0.16.11 is the beta (ruling 236): 0.16.10 plus the changes below, on the beta channel, and
the release the 0.17.0 stable is promoted from. It is not security-critical, so it reaches
only the sites that take beta builds. The feature freeze starts at this cut: only fixes follow it.

**A rule names only address profiles that exist (SM1435, rulings 234 and 235).** A rule, a
group's address limit, or a page's `addresses:` or `addresses_deny:` that names an address
profile the store does not hold is now refused when it is saved, naming the profile; before,
it was stored with a warning. A name no profile carries matches no address, so an allow naming
it admitted nobody and a **deny naming it excluded nobody**: a deny list that meant to keep an
address out kept nothing out. The refusal is at every door: the manager API's `acl-set`, MCP
`set_permissions` and `lazysite acl set`; the Groups page and the users
tool's `group-settings-set`; and, for a page, the manager save, the control API, MCP `write_file` and
`create_page`, and WebDAV, with `validate_page` reporting it as an issue. A rule or page saved
earlier that already names a missing profile still stands, as it did; run `lazysite check`,
which names each one, and create the profile or set the name to Not used. Such a rule is
refused on its next save until the name is cleared, and a page naming one is refused on its next
save by every content door.

**A profile a rule names cannot be deleted (SM1435, ruling 234).** `address-profile-delete`
has no `--force` and the API no `force`: a profile a rule names cannot be deleted, and may be
changed. A script that passed `--force` fails with "unknown option". The Address profiles page
no longer offers "Delete anyway"; it shows the refusal, naming the rules.

**Smaller changes, nothing to do.**

- After Require sign-in again, a revoked session or a removed account, public pages no longer
  draw "Sign out" from a signed-in marker the session left (SM1430): a page response to a request
  that carries the display marker and no signed-in identity clears it, and that one response is
  not stored. A visitor without the marker is unaffected.
- `lazysite check` says when it could not read part of the site (SM1437): run as a user who
  cannot open a directory, the page check names each path it could not read and the user it ran
  as, warns, and no longer says "ok" about the pages it did not see; run it as root or the
  site's owner. The `/docs` shadow check covers every domain's content root and names the
  domain; `check --fix` says "--fix: nothing to change" when it changed nothing, and `repair`
  says "nothing to repair" when it applied no change.
- The Groups page says where the settle panel is: the Unknown Odoo writes page, linked from its
  card on Extensions - configure (SM1435).

## The container image carries git, a new Hestia site is one command, and the rest of 0.16.10

**The container image now carries `git` (SM1423).** The 0.16.1 and 0.16.9 images
installed no `git`, so content history could not be turned on in the container. The
image now installs Debian's `git`. Rebuild the image to have it; no site changes. Content
history stays off until a site turns it on, and `installers/docker/README.md`, "Content
history", has the command. A site whose `lazysite.conf` already says
`git_history: enabled` with no history behind it (it was enabled where `git` was
missing) is repaired by the same command.

The upgrade now sets the declared mode (mode only, never an owner) on every directory the
install declares, as ruling 215 did for the account and form stores. A directory you
tightened below its declared mode is set back to it.

**A new Hestia site is one command (SM1427).** On a host that runs lazysite from the
tarball, `lazysite-hestia-deploy.sh USER DOMAIN --sysop NAME` installs the site, applies the
`lazysite-proxy` template when Hestia has it, sets `site_url: https://DOMAIN`, writes the
registry entry `/etc/lazysite/sites.d/DOMAIN` (not over an existing one) and makes `NAME` the
first operator, printing the claim link as a full URL. Nothing changes for an upgrade of an
existing site: the deploy writes none of these on a site that already has an install marker.
On a host with several sites, `--all` (check, repair, probe, upgrade, users, and `sites`)
now means the registry's sites and the Hestia list's together, merged by docroot, a registry
entry winning for a site in both (its channel and policy). Until now the Hestia list was read
only when the registry was empty, so registering one site hid the rest; with no registry
nothing changes. Also, `lazysite repair` and `lazysite probe` now take `--docroot D`, as their
usage always said.

**Smaller changes, nothing to do.**

- A manager who is not the operator can no longer add an OpenID Connect map entry that
  points a provider group at a capability group (SM1422). On a site that ran 0.16.9 with
  the `oidc` extension on, read the provider's group map once for an entry a manager added
  and remove any; the operator's own entries are kept as saved.
- `lazysite-hestia-deploy.sh` refuses, with exit 2, a DOMAIN that is not a plain host name
  and a USER that is not a Hestia user, before it touches anything; its summary says the
  claim link is a credential for 24 hours.
- The `lazysite-common` Debian package now Recommends `git` (SM1426), which content history
  runs; apt installs it unless Recommends are switched off, and history stays off until a
  site turns it on.
- After Require sign-in again, the page no longer shows "Sign in" to a person who is
  signed in (SM1425, SM1426): a renewal sets the display marker again, and one function
  now writes it for every sign-in and renewal.
- A change refused by an address rule says the rule limits changes to its allowed addresses
  and that the change must be made from one (SM1424). `lazysite check` and `validate_page`
  say a `description:` front-matter key is not read; use `subtitle:` or `meta_desc:`.
- `lazysite check` over a sound DB_File counter prints nothing on STDERR, a check message
  quotes its apostrophe, and `lazysite repair` says how many changes it applied beside its
  "awaiting your decision" count (SM1421). The shipped docs pages have distinct titles
  (SM1420).

## A broken store now refuses, Odoo's sign-in becomes an identity provider, and the rest of 0.16.9

**A broken store or setting now refuses (SM1417, ruling 206).** Until 0.16.8 a site with a
damaged access store or an invalid setting carried on, guessing an answer. From 0.16.9
it refuses until the fault is repaired. Run `lazysite check --docroot <docroot>` after
the upgrade: every case below is a FAIL line there, naming the file and the repair. A
site where the check shows none of them sees no change.

| Fault | What people see | Repair |
| --- | --- | --- |
| `lazysite/auth/acls.json` does not decode, or cannot be read | Every file and table-row check is refused (503, "cannot tell"), the operator's included; every rule change and file copy is refused, and the file is left untouched | Repair the JSON, or restore it from a backup |
| `lazysite/auth/.consume.lock` cannot be opened or locked | Every account change, password reset and invitation is refused ("cannot change the account store safely"); the CLI exits non-zero with the same sentence | `chown`/`chmod` as the check line says (`--fix` applies it) |
| The login rate limiter cannot count: DB_File missing, or `lazysite/auth/.login-rate.db` not openable or not a database | Every sign-in is refused: the sign-in page says sign-in is unavailable; token doors, the Odoo sign-in and an OIDC sign-in start answer 503 | Install DB_File (`perl-DB_File` on RHEL); fix the counter's ownership as the check says; or remove a counter that is not a database (it holds only recent attempt counts). Switching the extension off is still a choice |
| `lazysite/auth/groups-settings.json` does not decode, or cannot be read | Every signed-in page is refused (503: "the site cannot read part of its configuration"); anonymous pages are unchanged | Repair the JSON, or restore it from a backup |
| `lazysite/auth/groups` cannot be read by the web server | Every sign-in is refused (unavailable) and every signed-in visitor is treated as signed out | `chown`/`chmod` as the check line says (`--fix` applies it) |
| A `content_root:` or `alias.<host>.content_root:` the engine rejects (missing folder, unsafe path, outside the docroot, inside the engine tree) | Every request to that host is refused (503); it used to serve the docroot root's pages under that host's name. Other hosts are unaffected | Correct the line in `lazysite.conf`, or create the folder |
| `session_lifetime:` not a whole number from 300 to 31536000 (e.g. `0`, `1h`) | Every sign-in is refused (unavailable) and every existing session is signed out | Set a value in range, or remove the line for the 24-hour default |
| `password_min_length:` not a whole number from 8 to 128 | Every password set or reset is refused ("the site's password policy setting is invalid"); signing in with an existing password still works | Set a value in range, or remove the line for the default of 12 |

The log carries a WARN for each refusal naming the file and the check, so a site that
starts refusing after the upgrade says why in the site log. An absent file is not a
fault: a fresh site with no rules, groups or counter yet behaves as before.

**A damaged store now stops what it guards (SM1417, ruling 206).** Before 0.16.9 these
were carried past in silence; now each refuses and leaves the file as it was found.
Run `lazysite check --docroot <docroot>` after the upgrade: each one is a FAIL that
names the file and the repair. A store that does not exist yet is not a fault.

| What an operator sees | The file | The repair |
|---|---|---|
| Every upload refused (503, "cannot accept this upload") | `lazysite/manager/.upload-rate.db` | remove it; it holds only this hour's counts |
| The notify-outbox job reports "nothing was sent"; queued notices wait | `lazysite/notify/ledger.jsonl` or `notify/suppressed.jsonl` | repair the line the check names; never remove `suppressed.jsonl`, it records who unsubscribed |
| A form's acknowledgement, a notice mail, or a capped connector call refused by its cap | `lazysite/forms/submitter-mail.jsonl`, `logs/notice-mail.jsonl`, `connectors/calls.jsonl` | repair or remove the line the check names |
| No scheduled job runs | `lazysite/daemon/scheduler-runs.json` | remove it; every job runs once at the next tick |
| The daemon starts no service and stays down until the file is repaired (exit 4, which `lazysited@.service` no longer restarts; the timer's five-minute run refuses again); Status says `failed` | `lazysite/daemon/<service>.state.json` | make sure no copy of the service runs, remove the file, restart `lazysited@<domain>` |
| A data migration, rebuild or import refused ("could not be queried") | `lazysite/db/data.sqlite` | the check runs SQLite's quick_check; restore from a backup if it fails |
| The manager says "This page cannot be served right now" (503) to a signed-in person | `lazysite/auth/groups-settings.json` | repair the JSON (the check already names it) |
| Forgot-password answers `?error=unavailable` | `lazysite/auth/user-settings.json` | repair the JSON (the check already names it) |

Three only say so: the notify status (`notify/status.json`) is no longer written over
(remove it), the installed version reads unknown with a WARN when
`.install-state.json` does not decode (run the upgrade again), and an unreadable notice
template under `notify-templates/` is logged while the built-in wording is used (make it
readable). Nothing to do on a site whose check is clean.

**A signed-in page refuses a session it cannot check (SM297, ruling 217).** A page
request carrying a session cookie, while `lazysite/auth/user-settings.json`,
`revoked.json` or `users` cannot be read or decoded, now answers 503, on the CGI
path and in the pool, where it was rendered as if signed out. The answer is the one
every page refused for a damaged store gets, and names no file; the log line names
the store and the repair (`lazysite check` names it). Visitors with no session
cookie are served as before.

**The data endpoint refuses a session it cannot check (SM297).** A page's data
(`/cgi-bin/lazysite-data.pl`) answered a signed-in visitor as anonymous when a session
store (`lazysite/auth/user-settings.json`, `revoked.json` or `users`) could not be read.
It now answers 503 with `kind: cannot-tell`, naming the store, and logs it; `lazysite
check` names the same fault. Repair the store from the command line and the same session
is served again. Nothing changes for an anonymous visitor or a store that reads.

**An unreadable group store now refuses password sign-in (SM1352, ruling 206).** If
`lazysite/auth/groups-settings.json` exists and the web server cannot read or decode
it, every password sign-in is refused, the operator's included, until it is repaired:
the engine cannot tell whether a group says passkey only. Run `lazysite check` before
and after the upgrade; it names the file, and the fix is at the command line (its
ownership and mode, or a restore from a backup).

**A site whose engine tree sits beside its docroot gets its store's modes put right
by the upgrade; run `lazysite repair` for what it leaves (T-115, ruling 215).** This
covers a site moved with `lazysite migrate-engine-tree`, or any site with
`<docroot>-lazysite`. On such a site, earlier upgrades laid the auth and forms example
files, `forms/smtp.conf` and the form configs world-readable. The `auth/` and `forms/`
directories kept others out, except where `forms/` had world access. This upgrade lays
every file it ships there at its private mode, and sets the declared mode on each of
these, edited or not, changing no content:
- the user store, the group list and the ACLs: 0660;
- the auth and forms examples: 0640;
- the two directories: 2770.

The auth code's lock files are created 0660. `lazysite check` names any of these modes
that drifts later, along with a world-readable user store, group list or ACL file, and
a path owned by another account, which the upgrade cannot change. Run `lazysite repair
--domain DOMAIN` (or `lazysite check --docroot DOCROOT --fix`) to set each to its
declared mode. A site whose engine tree is inside its docroot is not affected.

**A pool site keeps its own engine until it runs `upgrade` (SM1416, ruling 203).** The FastCGI
pool (`lazysite@<site>`) now runs the site's own processor, from its cgi-bin, and its own
lib, as the manager, auth and DAV CGIs already did. It used to run the package's, so
after a package upgrade the pool rendered with the new engine while the rest of the site
ran the old one. Now, after a package upgrade, a pool site keeps its own version until
`lazysite upgrade --docroot ...` (or `upgrade --all`) moves it, and then the pool's
restart picks it up. Nothing to do on upgrade beyond the usual restart. A site whose
engine copy is missing or unreadable is answered 503 and logged, never served by the
package's engine; `lazysite check` names it (`pool engine: ...`) and the remedy:
`lazysite reinstall` (or `upgrade`), then `systemctl restart lazysite@<site>`. A pool
conf whose `CGIBIN=` points somewhere other than the site's cgi-bin must be corrected.

**Install CryptX for passkeys and web push (SM1352, SM1363, ruling 187).** The Debian
package now recommends `libcryptx-perl`, so `apt` installs it with the upgrade unless
recommends are turned off; a tarball host installs it by hand
(`apt install libcryptx-perl`, RHEL `perl-CryptX`, Alpine `perl-cryptx`). Without it
nothing changes, the two new features are simply unavailable, and `lazysite check` says
so.

**Odoo is its own package, `lazysite-odoo` (SM1369 X7, rulings 188, 205).** On a deb host
that uses Odoo, install `lazysite-odoo` with the upgrade. It brings `libodoo-oom-perl`
with it, so the host needs the repository that carries that package. If a site has Odoo
on and the package is missing, `lazysite upgrade` refuses that site before changing
anything, and names the package. A site with Odoo off just has the extension's old copies
removed; a copy you edited is kept, with its orphan warning. Tarball and Hestia installs
still carry Odoo and lay it out as before. Nothing a site configures changes.

**The Docker recipe now serves many sites from one container (SM1361, rulings 201, 205,
208, 210).** The 0.16.1 recipe had one site in three volumes, and its volume layout has
changed: the new recipe keeps every site as a folder in one volume, listed in
`sites.conf`. Moving a site from the old recipe is a by-hand step, written out with its exact
commands in `installers/docker/README.md`, "Moving a site from the 0.16.1 recipe":
build the new image, stop the old container, create the new volume, copy the three
old volumes into `NAME/` as `www-data`, set `site_name` and `site_url` in the copied
`lazysite.conf` (the upgrade leaves them as the old recipe wrote them), then start the
new container and run `lazysite-sites add NAME DOMAIN [ALIAS...]`.

In the new container:
- the engine runs from the image, and every site runs as `www-data`;
- only the image's own extensions run. `lazysite check` names a site's own extension
  file as refused;
- a site whose end user takes it over moves to a dedicated service: Hestia, or a
  container of its own.

`installers/docker/README.md` covers upgrade by tag, rollback by `lazysite-sites restore`,
and the canary as a second container.

**The Odoo site sign-in is an identity provider (SM1369, X4).** A site whose sign-in is
the Odoo login (`odoo_site_signin: on`) keeps working as it did: the same `lazysite_auth`
cookie, the same `odoo:<login>` identity, the same groups from `odoo_group_map`, the same
`/odoo-signin` page, "Sign in with Odoo" on `/login`, the "Signed in as" banner and the
same log lines. Nobody is signed out by the upgrade: a session signed in before it
verifies after it. What changes:

- The sign-in is the extension's declaration, read from the extension index the upgrade
  rebuilds. **The Odoo extension must be enabled** for its sessions to count: on a site
  that had `odoo_site_signin: on` in `odoo.conf` with the extension turned off, those
  sessions are now refused (off means off). Turn the extension on, or the setting off.
- A layout of your own that renders `[% odoo_signin_banner %]` keeps working; the
  default layout now renders the general `[% signin_banner %]`, and `/login` lists each
  provider's option from `login_options`. A site's own copy of `login.md` that tested
  `odoo_signin_banner` keeps its old link.
- A group the Odoo map names is still refused if it carries any capability; that rule is
  now the engine's own, applied to every identity provider.

**Odoo bindings are configured with `manage_odoo` (ruling 178).** Creating, changing,
deleting and scheduling a handler of type `odoo` needed `manage_connectors`; it now needs
`manage_odoo`. The upgrade's capability top-up (0.16.8, ruling 167) already gives
`manage_odoo` to every group holding `manage_connectors`, so nothing changes for such a
group, its people, its tokens or a scheduled binding's job account. A group whose
operator set `manage_odoo` off keeps it off, and now cannot configure Odoo bindings, and a
scheduled binding whose job account holds only `manage_connectors` with `manage_odoo` off
is refused at its next run, naming `manage_odoo`: grant it, or move the entry to another
account. Saved bindings and their rows in `handlers.conf` are unchanged. A group given
`manage_odoo` alone now reaches the Handlers page, the handler and schedule actions and
their MCP tools for Odoo bindings and nothing else (ruling 192).

**Accepted as built (ruling 193).** With the Odoo extension off, its sessions are
refused; an unsecured site refuses every provider's session; and new session records no
longer carry the old `odoo => 1` flag, so going back to 0.16.8 after this upgrade signs
out the people who signed in through Odoo since.

**The Odoo extension's endpoint, services, checks, page and keys are its declaration
(SM1369, X5 and X6).** The upgrade rebuilds the extension index on every site, as it
does on each upgrade; from it the engine finds what it used to know by Odoo's name.
Nothing a site configures changes, and nothing needs doing; what an operator sees:

- **The Unknown Odoo writes panel is a page.** It is `/manager/odoo-unknown-writes`,
  linked as **Unknown Odoo writes** from the Odoo card on the extension-config page
  for a manager holding `settle_odoo_writes`, and shown only to one (403 to one who
  does not). It
  lists, settles and dismisses runs as the panel did.
- **`lazysite check`** prints Odoo's lines (its scheduled keys' expiry, the OOM it
  loads, oomd, the Odoo sign-in's group map, old read caps) only while the extension
  is on; with it off, one line says it is installed and off.
- **A POST to `/cgi-bin/lazysite-odoo.pl` with no token at all** is refused `403 csrf`
  before anything runs, a batch included; it was `401 signin-required` for a binding
  that runs as the person signed in, and per call in a batch. The browser helper always
  sends a token and fetches fresh ones once on a `csrf` refusal, so a page that uses it
  is unchanged. A page that posts without the helper sends the visitor token from
  `?csrf=1`, as the docs have always said.
- **oomd and the endpoint's warm-fork parent** run under lazysited as before, from the
  extension's declaration; the socket is `lazysite/run/odoo-endpoint.sock` as before.
  An index left unbuilt (an upgrade interrupted before its index step) starts neither,
  and the endpoint answers as a CGI until the index is built (enable or save any
  extension, or run the upgrade again).
- **Secrets have one store** (H-11): `lazysite/<owner>/keys/<name>.key`, `0600` in a
  `0700` directory. The Odoo keys are where they were. A connector's secret moves from
  `lazysite/connectors/secrets.json` to `lazysite/connectors/keys/<id>.key` when it is
  next set; until then it is read from the old file, which goes when the last entry
  leaves it. A backup or a copy of `lazysite/` carries both, as it carried the one.

**Signing in through an OpenID Connect provider (SM1351).** A new extension, off until
you enable it: people sign in at a provider the site trusts and its groups become site
groups. Nothing changes on a site that does not enable it. To use it, see
[Authentication](/docs/auth) ("Signing in through an OpenID Connect provider"): register
`https://<site>/cgi-bin/lazysite-oidc.pl` as the redirect URI at the provider, then add
each provider, with its client secret, in the extension's settings on the Extensions page;
saving fetches its discovery. The settings are kept in `lazysite/oidc.conf` and the secret
in the secrets store; `extensions/oidc.pl --secret <name> --docroot <docroot>` (read from
standard input) sets a secret from the command line for a repair. The endpoint is reached through the existing
`/cgi-bin/` rule, so no web server configuration changes. A provider group may map to a
group that carries capabilities, operators included: map such a group only from a
provider whose membership you control; only the operator can save such a mapping. A site's own copy of `login.md` that builds the
provider links as `[% o.path %]?next=` needs `[% o.sep %]` in place of the `?` for an
OIDC provider's link to work when the page carries a `next`. The Sessions page gains
**Require sign-in again** for the selected sessions: a provider's session (OIDC or Odoo)
signs in again through its provider at its next request, and a local one is signed out.

**Passkeys arrive on the sign-in, setup-link and account pages (SM1352).** Nothing is
needed: the shipped `/login`, `/claim` and `/account` system pages offer a passkey to a
browser that can use one. A site that wrote its own `login.md`, `claim.md` or
`account.md` keeps it unchanged; to offer passkeys there, copy the passkey block from the
engine's page (the `data-ls-account="passkey-signin"`, `"passkey-claim"` and
`::: account-passkeys` parts). A layout that overrides `components/account-*.tt` gains
`account-passkeys.tt` from the engine. To make a group sign in by passkey only:
`lazysite users --docroot <docroot> group-set <group> passkey_only on`.

**Two hourly notice bounds (SM1363, rulings 195 and 199).** `mail.per_hour` in
`lazysite/notify.conf` counted notice mail; it now counts every route but webhook -
mail and web push together. The webhook route has its own bound, `webhook.per_hour`,
20 an hour unless set. A site that routes nothing new sees no change. One that adds
`webpush` and keeps a low `mail.per_hour` should raise it to cover the pushes; one that
sends text messages by webhook sets `webhook.per_hour` to what it will pay for. Nothing else changes for a site
that does not use the new routes; to use them, see "Notices to the app, and by text
message" in `/docs/forms`. A site whose own `account.md` should offer app notices adds
`::: account-push`, and `::: account-phone` for the phone text notices go to (ruling
196); an operator can also set an account's phone on the Users page.

**The XMPP notice account answers a subscribe from its recipient (SM1418).** No
setting changes and nothing to migrate. On the first notice after the upgrade to a
person (not a room) the account asks the recipient to subscribe and approves their
request; once both directions hold it does nothing more. The recipient accepts the
account's request in their client and, in Conversations and other OMEMO-default
clients, taps the padlock in the chat and chooses Unencrypted (see
`/docs/forms`, "Configuring chat delivery"). While the subscription is incomplete a
notice to a person waits up to a second for a pending request.

**A table may read its rows from another system (SM1364).** Nothing changes for an
existing table: a descriptor without `source:` behaves as before. To use it, see
[Data tables](/docs/data-tables): a GET connector, a `connector` handler for it, a
schedule entry, and `source:` in the descriptor naming the connector and the entry -
the descriptor is the one link, so the connector needs no `answer_table`. Two things to
know. A connector whose `answer_table` names a table with a `source:` no longer
appends a call row there - the answer becomes the table's rows, and a failed call adds
nothing; a connector whose `answer_table` names an ordinary table keeps appending. And the schedule's run record
(`lazysite/daemon/schedule-runs.json`) gains `last_ok` per entry, written from the first
run after the upgrade; until an entry delivers once, a sourced table's age reads "never
refreshed". The record is now written under a lock file beside it,
`schedule-runs.json.lock`, which the daemon and the manager share; both users must be
able to write `lazysite/daemon/` for an on-demand refresh to count in the age.

**Smaller changes, nothing to do.**

- The Groups page adds the two roles too (SM1407, as 0.16.8 said it would): opening it
  now adds `analysts` and `lead-readers` on an older site, as the Users page already did.
  They arrive only on a site that has an operator group and at least one shipped bundle
  group (a `cap-*` or `ch-*` group), and only a role the site lacks and has not had
  before: a site without the bundle layer gets neither, because there they would grant
  nothing, and a role an operator deleted stays deleted. On a site whose operator group
  carries the `seeded` mark an absent role is taken as deleted, so none is added. They
  arrive with no members, so nobody's access changes. The groups listing (MCP `list_groups`, the control API's `groups`) says for each group
  whether it shipped with the engine (`seeded`).
- A page whose body names a filter a page body does not have (anything beyond Template
  Toolkit's own, `json` and `url_safe` - `markdown` is a layout's) is refused on save and
  reported by `validate_page`; such a page already rendered with its whole body as
  written. `| json` now works in a page body (SM1398).
- The operator's Files listing is MCP's listing (SM1404): the manager API's `list` no
  longer carries the permissions editor's address-profile choices beside the entries.
  The Files page reads them from `principals`, and `acl-get` carries them as before.
- `lazysite check`'s shared-title and missing-description warnings read each domain's
  own public pages (SM1357), so two domains' home pages with the same title are no
  longer reported as a duplicate; each warning names the page's address, and its domain
  on a site of several.

## Odoo's actions become the extension's, owner_contact is retired, and the rest of 0.16.8

**`owner_contact` is ignored from 0.16.8 (SM1412, ruling 159).** The `owner_contact:`
line in `lazysite/notify.conf` (0.16.6, SM1362) no longer mails a form's notice to that
address; nothing reads it. By default no form mails anyone: submissions are stored, and
the notice goes to the bell. To mail people when a form is submitted, add a `notify`
handler on the Handlers page whose recipients name them - usually a group, e.g.
`[{"groups":["site-owners"]}]` (SM1413), with the addresses set on each account on the
Users page - and add it to the form's targets after the handler that stores the
submission. Then delete the `owner_contact` line. `lazysite check` names a site that
still sets it. A form's acknowledgement to the submitter (`acknowledge_field`) is
unchanged.

**Odoo's actions and capabilities are the extension's own declaration (SM1369, X2).**
The ten `odoo-*` control-API actions and `odoo_*` MCP tools, their parameters, their
gates, the tools' descriptions and schemas, and the capabilities `settle_odoo_writes`
and the new `manage_odoo` are declared by `extensions/odoo.pl` and read by the engine
from the extension index (`lazysite/extensions.index.json`), which the upgrade rebuilds
on every site, a new site's install builds, and the manager rebuilds when an extension is enabled, disabled or saved.
The wire names, the parameters and the listing an agent sees are unchanged. Nothing a
site configures changes.

**`manage_odoo` (ruling 71).** The Odoo connection user's key, the connection's state
and the call record (`odoo-status`, `odoo-calls`, `odoo-secret-set`, `odoo-secret-clear`
and their tools) were `manage_connectors`' and are now the extension's own capability,
`manage_odoo`, which also stands in for manage_connectors as the capability that may run
any Odoo binding. The upgrade tops up every group holding `manage_connectors` with it
and prints one line naming them (`groups:    topped up: <group> (manage_odoo), ...`;
nothing when none), so nothing changes for a group; a group whose operator has set it
off is left as decided. The same top-up still runs the next time the site's accounts
are touched, for a group given manage_connectors later. The Groups and Users pages show
it as "Odoo connection" under Site.

**If the index did not build.** The upgrade prints `declarations indexed: odoo` for a
site with Odoo installed. Should the build fail (a full disk, an unwritable
`lazysite/`), the previous index stands, the upgrade warns, and `lazysite check` says
so (`the extension index was not rebuilt by the last build`) until an extension is
enabled or saved in the manager or the upgrade is run again. On a site whose index was
built by hand before Odoo was enabled, the check names it (`enabled extensions whose
declarations are indexed and whose hooks are not`) and the actions answer "cannot run
now" until the index is rebuilt the same way.

**The Odoo browser helper and the sign-in component are the extension's (SM1369,
X5's asset part).** `/assets/lazysite-odoo.js` is no longer a file in the docroot: the
upgrade removes `{DOCROOT}/assets/lazysite-odoo.js` (it left the manifest; an edited
copy is kept with its orphan warning, and then still served by the front end as a
static file, so delete it to get the engine's) and lays the file out at
`{DOCROOT}/../extensions/odoo/assets/lazysite-odoo.js`, where the engine serves it
from at the same path, `/assets/lazysite-odoo.js` (and at `/assets/odoo-lazysite-odoo.js`),
on every domain, while the Odoo extension is on. The component `::: odoo-signin` moves
from `{LAZYSITE}/templates/components/` to `{DOCROOT}/../extensions/odoo/templates/components/`
and renders as before. The upgrade rebuilds the hook index, which is how the engine
finds both; a site that enables Odoo by editing `lazysite.conf` by hand must run
`lazysite upgrade` or `reinstall`, or save the extension's settings once, for the index
to be built. Nothing a layout references changes: `[% odoo_signin_banner %]`,
`[% odoo_display_name %]`, `data-ls-odoo-*` and the helper's path stay.

What does change: **with the Odoo extension off, the helper is not served and not added
to a page** (before, the docroot carried a copy whatever the conf said). A site that
used the helper with the extension disabled had nothing for it to talk to.

The front end needs nothing: a request for a missing `/assets/...` path already reaches
the engine on the shipped nginx and Apache configurations (`try_files` and
`FallbackResource`).

**The sitemap and llms.txt list every public page (SM1357, ruling 165).** Until now they
listed only pages whose front matter said `register: [sitemap.xml]` (or `llms.txt`).
From this release a page with no `register:` key is in both, so on upgrade the sitemap
and the summary grow to the site's whole public content. A page that has a `register:`
list keeps what it says, and one that names either the sitemap or `llms.txt` is now in
both (ruling 174: the two list exactly the same pages); a protected, draft, copied,
`api:`/`raw:`, redirect or starter demonstration page and the engine's sign-in and error
pages are never listed. On a multi-site docroot the bare host lists no folder that looks
like another site's content - one under `sites/`, or one holding its own `lazysite.conf`
- that is not a declared `content_root` (ruling 171); nor does its site search or a `scan:` listing find
its pages (ruling 176); the bare host still serves it, and
`lazysite check` names each such folder: declare it as a domain's content root or move it
out of the docroot. To keep a
page out, give it `search: false`, or a `register:` list that does not name the
registry. `llms.txt` is on by default (a site that had no page registered for it now
has one listing its pages); `llms_txt: off` in `lazysite.conf` turns it off. An existing
site's `llms.txt.tt` is its own and is not replaced: the *About* section the new
template prints from the organisation details appears on a site only once its template
is taken from the starter (`starter/lazysite/templates/registries/llms.txt.tt`).

**Row changes are recorded (SM1355).** From this release every row save, delete and
switch is recorded in the data store, in a table named `_row_changes` that the first
recorded write creates; nothing needs migrating. The history is kept 90 days unless a
table's descriptor sets `row_history_days`. Where the daemon runs, its new daily job
`row-history-prune` removes expired changes from a store nobody writes to, as the
existing `daemon_job_user`; it needs no grant beyond `run_jobs`. A table gains a switch only when its
descriptor names an `availability` field, and wizards exist only where
`lazysite/db/wizards/` holds them, so an upgraded site's tables and pages behave as
before.

**Schedules and the site's time zone (SM1356).** New and opt-in: a table is a schedule
only when its descriptor says `schedule: true`, and `time_zone:` defaults to UTC, which
is what every date in the engine already was. A site with dated rows or a schedule sets
`time_zone:` to its zone (the host needs the `tzdata` package, which `lazysite-common`
now recommends, so an install that skips Recommends must add it; `lazysite check` names a
zone it cannot find). Passed exceptions are removed by the daemon's new
`schedule-exceptions` job, which runs as the job account and needs `manage_data` on it;
without that grant the job records a refusal and the exceptions stay, harmlessly.

**A rule whose owner was removed is named (SM1401).** Removing an account
(`lazysite-users.pl remove`, or Delete on the manager's Users page) now says which access
rules it owned, and `lazysite check` names each stored rule whose owner is no account.
Such a rule stays in force as written, and only the operator can change it: remove it on
the manager's Permissions page, or re-own it with `lazysite acl set --owner`. The engine
changes no rule.


**Members can be let back into the manager API to save content (SM1414, ruling 169).**
A new capability, `write_content`, lets an account without `ui` call `read`, `list`, `save`,
`mkdir`, `move` and `delete` on `/cgi-bin/lazysite-manager-api.pl` over its own
signed-in session, writing only where an access rule names it or its group as a
writer. Nothing changes for a site that grants no `write_content`: no group holds it
after the upgrade except the operator group, whose access it does not change, and an
account without `ui` is refused as before. To let a member app's authors save posts,
grant their group `write_content` on the Groups page and give the folder they write
a rule naming the group in its write list. See `/docs/auth`.

**A new capability, `publish_copies`, held by nobody (SM1354).** Pages can be copied,
changed and published over the original. A person in the manager publishes with
`manage_content`, as they save today. An agent publishes over MCP or the control API
only with `publish_copies` as well, which the upgrade grants to no group: the manager
groups' top-up and `lazysite check` leave it out by design, and a manager group is
offered it to grant. Grant it to an agent's group only where the site has decided an
agent may publish its own change. The copies live in `lazysite/copies/`, which content
history leaves out; nothing else changes on upgrade.

**The offline kit (SM1396).** A new extension, `app-offline`, off until enabled on the
Extensions page; it needs the Odoo extension on, and the Odoo sign-in as the site
sign-in (`odoo_site_signin: on`) to keep anything. Enabling it adds nothing to a page
until a layout renders `[% app_offline_kit %]`. On a site with the Odoo site sign-in,
the page endpoint's `?csrf=1` answers one more field, `owner` (a label of the
signed-in login, from the site session); a person already signed in has it at once.
On a default Odoo site `?csrf=1` names no owner and the kit keeps no reads and queues
no changes. The identity cookie is unchanged.

**A row written refreshes the pages that show it (SM1357).** A page binding a table with
`db:` and carrying a `ttl:` used to show a changed row only when the ttl ran out; it now
renders again on its next request after any row write the engine makes (each table has a
change stamp in `lazysite/db/stamps/`, made on first use). A row changed outside the
engine (an `sqlite3` shell) touches no stamp and still waits for the ttl.

**An import with no valid row is refused (SM1410).** `accounts-import-stage` and
`stage_accounts` given only invalid rows now answer `ok: 0` with the same `invalid`
list and no id, and keep nothing; before, they answered ok with an id and kept an empty
run. A script that staged and then checked `staged` needs no change; one that took `ok`
alone as "kept" now sees the refusal. Empty runs kept by earlier releases stay in the
import list until removed there.

**Smaller changes, nothing to do.**

- The editor holds its lock again (SM1411): the manager's editor takes and renews its
  edit lock with a POST, so opening a file no longer shows "This action must be sent as
  POST." beside the toolbar, and a second editor on the same file is told who has it.
  The upgrade replaces the page.
- Two roles reach an older site (SM1407): on a site bootstrapped before 0.11.3 that has
  the role bundles, the next Users or Groups page load adds the `analysts` and
  `lead-readers` roles it lacks, with no members, nested into their bundles as on a new
  install (and the `cap-audit` bundle with `analysts`). Nobody's access changes until an
  operator puts an account in one; a role deleted after it was added stays deleted.
- A layout's backup snapshot (`<name>-backup-<stamp>`, kept by `delete_layout` and an
  activate) is no longer listed as a layout on the Appearance page, by MCP `list_themes`
  or by the control API; it is listed under Backups and removed there (SM1400).
- `set_form_notify` (MCP) and `form-notify-save` (control API) refuse a form that is
  neither registered nor bound on a page (`kind: not-found`), naming `create_form`
  (SM1402).
- MCP `list_files` no longer carries an entry named after a folder rule's address
  profile; the permissions editor's choices ride on the manager's own listing (SM1404).
- A notice mail - a notify rule's, an account notice, an import's claim link - arrives
  with its own subject and the notice as its body, with no Submitted or IP lines
  (SM1405).
- A token's refusal to delete or change a group it did not create now says a token is
  bound by that rule, and that the operator changes any group on the Groups page
  (SM1408).
- `domain-set` of a layout alone, with the domain's theme still another layout's, is
  accepted and mirrors no mixed pair; the warning says what to send, the layout and the
  theme together (SM1409).
- A site with no favicon answers `/favicon.ico` and `/favicon.svg` with the engine's
  (SM1397), and templates gain `page_url_raw` (SM1398).


## Odoo's modules leave core's lib, and the rest of 0.16.7

**Odoo's modules leave core's lib (SM1369, X7 part one).** The Odoo extension's Perl
modules now install beside its descriptor, in `{DOCROOT}/../extensions/odoo/lib/`, and
no longer in `{DOCROOT}/../lib/Lazysite/`. The upgrade does it: it installs the new
copies, removes the old ones and the directories they leave empty, and rebuilds the
extension hook index. Nothing a site configures changes: the extension's conf entry,
`odoo.conf`, the `lazysite/odoo/` store, the bindings, the cookies (nobody is signed
out), `/cgi-bin/lazysite-odoo.pl`, `/assets/lazysite-odoo.js`, `/odoo-signin`, the
actions, the MCP tools, the capabilities and oomd's socket all stay as they are.

If a site **edited** one of the old module files, the upgrade keeps that file and
names it in its summary, under `Orphans: N (edited post-install, left in place):`,
as `- {DOCROOT}/../lib/Lazysite/Odoo/<Name>.pm`. Odoo then refuses to load rather
than run the stale copy, and the error the web server logs names the file:
`Lazysite/Odoo/<Name>.pm is in the payload lib .../extensions/odoo/lib and also at
.../lib/Lazysite/Odoo/<Name>.pm - a copy an earlier release left outside the
extension; remove it`. Keep any change you need from that file (the released copy
is in `extensions/odoo/lib/`), delete the named file, and Odoo answers again; no
restart is needed. A site that edited none has nothing to do.

Odoo still ships in the same package as the engine. The separate package is 0.16.9.

**A stale Odoo site session is renewed, not refused (SM1381).** On a site with
`odoo_site_signin: on`, a person idle past `odoo_identity_ttl` who opens a protected
page now passes through `/cgi-bin/lazysite-odoo.pl?renew=1` and back to the page. If
Odoo has ended their session they reach the site's sign-in page instead
(`auth_redirect`, else `/login`), with `next` kept; `/login?action=session` goes
through the same step. The step needs no configuration. A front end that sends
`/cgi-bin/lazysite-odoo.pl` to the engine already sends it there. The step sets a
short-lived cookie, `lzs_renewed`, which stops a loop: one renewal a minute, then the
sign-in. The refusal is logged at INFO.

**Deleting a group is refused while anything names it (SM1387).** The Groups page's
Delete, and the new `group-delete` (control API) and `delete_group` (MCP), refuse a
group a page, an access rule, a domain, a data table, a binding or a connector still
names, and say which: remove the group from those first. A group with a member is
refused too. The operator group is never deleted, even when there is more than one
(before, only the last was kept). A domain-confined token or MCP grant deletes only a
group it created with `group-set`. An empty agent role (SM1371) may be deleted;
`reset-groups` restores a shipped one. Each deletion is audited.

**An account named `v1` cannot hold a session, and cannot be created (SM1390).** `v1`
is the theme-preview cookie's marker, and a session payload beginning with it is
refused, so a site with an account of that exact name has it sign in and be refused on
every request: `lazysite check` names it; rename it (`users rename v1 NEW-NAME`). The
users tool, the manager and an accounts import refuse the name from now on. A session
cookie whose issue time is more than 300 seconds ahead of the server's clock is
refused as well; a host whose clock runs that far ahead of the one that minted the
cookie sees sign-ins refused until the clocks agree.

**A hand-written schedule entry under the 300-second floor is now reported (SM1391).**
It never ran before and still does not; `lazysite check` names it, and the daemon's
run record (`lazysite/daemon/schedule-runs.json`) holds a refusal for it, written once
and logged. Set `every:` to 300 or more.

**The agent roles and the shipped bundles appear on an older site (SM1393).** 0.16.6's
note said the four agent roles appear on a site's first Users or Groups page load after
the upgrade. On a site bootstrapped before the `seeded` mark existed (before 0.11.3, or
whose manager group came from `lazysite.conf`'s `manager_groups`) they did not, and nor
did any bundle a release had added since (`cap-tidy`, `cap-services`,
`cap-maintenance`, `cap-audit-switch`, `ch-files`, as the site's roles draw on them).
After this release, the first Users or Groups page load (or any users-tool command
that reads the group store, such as `group-add`; the CLI `groups` listing is not one)
adds the four roles and, on a site that has the bundle layer, the bundles it lacks,
nested into the roles present under their shipped names. The roles have no members and
the bundles are nested only into roles already there, so nobody's access changes;
delete any you do not want and it stays deleted. A group an operator made under a
shipped name on a site that carries the mark is left alone, as before. The site's
audit log records each adoption. On such a site `reset-groups` and the Groups page's
"shipped" badge still read the mark, so they answer for the roles as they did.

**A form's own conf opens in the manager's editor (SM1392).** An account holding
`manage_forms` can open `lazysite/forms/<name>.conf` in the editor from the Files page;
without the capability the server's refusal names it. Over MCP, `read_file` and
`write_file` on that path now ask `manage_forms` rather than `manage_content`: a grant
holding `manage_forms` without `manage_content` reaches a form's own conf through the
connector as it has over WebDAV; a grant holding `manage_content` without `manage_forms`
is refused it, as it was. If an account holds `manage_forms` it should not, this is the
release to check. No other path changes. From ruling 152 the tool listing offers
`read_file` and `write_file` to a grant holding `manage_forms` without `manage_content`,
each saying it reaches a form's own configuration and nothing else, and
`whoami.tools_by_reach` names that reach under `path_only_reach`.

**A check line that goes away (SM1389).** On a site with a protected folder's history
on (`history: true`, SM1324), 0.16.6's `lazysite check` reported the history repository
in the private store (`<store>/lazysite/git`) as stray public copies of the docroot's
`lazysite/git`, and the site NOT SERVICEABLE. The walk now skips that one repository;
nothing to do. A layout a rule moved into the store, and a copy beside it, are still
reported.

**Smaller changes, nothing to do.**

- A theme is deleted by its path, under any layout (SM1385): `delete_theme` (MCP),
  `theme-delete` (control API) and the manager's Themes page take
  `lazysite/layouts/<layout>/themes/<name>` as `theme-copy` does; the bare name still
  means the active layout's theme, and the same refusals apply by path (the active
  theme, a theme a domain serves, a theme another account made, a path into a served
  copy). The Themes page offers Delete under every layout.
- A theme install warns when its stylesheets are outside `assets/` (SM1386), on every
  install door (`theme-upload`, MCP `install_theme`, the layout installs), naming each
  stylesheet and where it belongs; warned, never refused. Only `assets/` is served, so
  such a theme previews with no CSS until the files are moved.
- A rule with `history: true` on a folder that does not exist yet is refused with a
  sentence that says so and to create the folder first (SM1388); it said "is not a
  folder", which read as a file.
- Live data is a scheduled connector answer in a table row (SM1382): the "Live data"
  section of `/docs/ai-briefing-building-sites` is the recipe, with its measured limits
  (a 300-second floor, an interval rounded up to a multiple of 300, fixed fields, one
  row per poll, `ttl:` the only freshness bound). A connector cannot express a
  submit-poll-read job protocol; that is filed as SM1384, a candidate.
- The session cookie's format is an external contract (SM1383):
  `docs/architecture/session-cookie-contract.md` states what an outside process on the
  same host verifies, read-only, and the format changes only versioned, reader before
  writer. Nothing changes for a site. A site that gives a process read access to its
  `auth/` directory trusts it as far as the web server, because the key is symmetric
  (OBLIGATIONS.md).

## The primary's content leaves out the other domains, and the rest of 0.16.6

**The primary site's content leaves out the other domains' folders (SM1372).** On an
instance serving more than one domain, each secondary domain's content lives in its own
folder under the document root (`sites/<host>/` as a rule). Until now an account that
reaches the primary site - one granted nothing (no domain names its group), or one whose
group is on the primary's row - reached those folders too, through the primary's
content: over WebDAV, MCP, the control API and the manager's Files. From this release it
does not (ruling 126): the primary's content is the document root less the other
domains' content roots. What it is refused says which folder and how to grant it. Nor
does it see them listed (ruling 137): the manager's Files, MCP `list_files` and a WebDAV
PROPFIND of `sites/` leave out each other domain's folder the account is refused, so a
client that synced the whole tree over WebDAV no longer finds them there.

Unchanged: the operator (a member of the operator group, the group `setup-sysop` makes,
in the manager or over WebDAV) still reaches every folder, and an account already
granted a secondary domain keeps that domain.

Who loses something: any other account - a manager holding `manage_users` but not in
the operator group included, and often an agent's token or WebDAV login - that edited a
secondary domain's pages through the primary, without being granted that domain. Before
upgrading, find them: any non-operator account that writes under `sites/` and whose
group is named in no `alias.<host>.allowed_groups` line for that host.

How to give it back: grant the domain. Name the account's group in that domain's
`allowed_groups` (the Domains page, or `domain-set` with the access keys, or
`alias.<host>.allowed_groups: <group>` in `lazysite.conf`). Grants add, but naming a
secondary takes away the primary that an account granted nothing had: to keep the
primary as well, name the group on the primary's row too (the bare
`allowed_groups: <group>` line; the Domains page row `(default)`).

**The data endpoint, and the control API's `data-rows`, refuse a parameter they do not
read (SM1377, rulings 131 and 139).** A page's own script that reads
`/cgi-bin/lazysite-data.pl` with a query parameter other than `table`, `order_by`,
`order`, `limit`, `offset`, `csrf` or `_` now gets a 400,
`{ ok: 0, kind: "unknown-parameter" }`, naming the parameter, where the parameter was
ignored and every row came back. A call to `action=data-rows` with a query parameter
other than those it reads (`table`, `order_by`, `order`, `limit`, `offset`) or `_` and
`csrf_token` gets the same refusal. The shipped `lazysite-data.js`, a page using
`data-ls-db`, the manager's Data page and MCP `read_data_rows` are unaffected.

Who is affected: a custom script or a token client that adds its own parameter, such as
a filter (`chunk=AAA`, which never filtered) or a cache-buster under another name.
Before upgrading, search the site's scripts for `lazysite-data.pl?` and token scripts for
`data-rows`. Filter on the page binding (`db:t(chunk=AAA)`) or in the script after
reading the rows, and name a cache-buster `_`.

**`manage_forms` reaches a form's config on more doors, and four agent roles appear
(SM1371, ruling 122).** An account holding `manage_forms` can now read and write
`lazysite/forms/<name>.conf` through MCP `read_file`/`write_file` and the manager's file
editor, as it already could over WebDAV. The file's targets must name existing handlers.
`smtp.conf`, `handlers.conf` and `schedule.conf` stay closed to every grant. If an
account holds `manage_forms` it should not, this is the release to check. The first use
of the users tool after the upgrade (any Users or Groups page load) adds
`content-agent`, `data-agent`, `forms-reader` and `analytics-agent` to a site that has
the shipped roles and lacks them. They have no members, so nobody's access changes;
delete any you do not want and it stays deleted. To move an agent onto a role, put it in
the role on the Groups or Users page and take the matching capabilities off its own
`role-<account>` group; the Users page shows what an account holds beyond its roles.

**A script that reads the audit trail's actor for an Odoo call (SM1366).** A call made
under a person's Odoo session, on a request also signed in to the site, is recorded and
audited under that site account (a local account, or `odoo:<login>`), with the session's
hash beside it (`session` on the call record, `session=` on the audit row), where the
actor was `session:<hash>`. A filter or report that keyed on `session:` for those rows
reads the account instead. With no site identity the hash is the actor, as before.

**Smaller changes, nothing to do.**

- The extension hook index (SM1369). Every upgrade and reinstall rebuilds
  `lazysite/extensions.index.json` from the enabled extensions' descriptors, as the site
  user, after the other steps. A site whose extensions declare no hooks, which is every
  site today, gets no index and the summary says nothing about it. An enabled extension
  that declares a hook this release does not build is named in the summary as
  `hooks refused: <id> (...)`, with the slice that builds it, and runs nothing. If the
  rebuild cannot write the index, the summary warns under `HOOKS:` and the previous index
  stands. Enabling or saving an extension in the manager rebuilds it.
- Existing tokens (SM1370). A token's capabilities are its account's grant at each
  request, as every token door already resolved them (measured on 0.16.5), so no
  existing token gains or loses anything at the upgrade; `whoami` now says so in a
  `grant` block. An agent whose client shows an old tool list after a grant lists its
  tools again, or reconnects the connector; it needs no new pairing key, and rotating a
  token changes nothing about its grant.
- A form can tell its owner by email, and answer the submitter (SM1362). Both are off
  until set: `owner_contact:` in `lazysite/notify.conf`, and a form's
  `acknowledge_field` and `acknowledge_message`. Both send through the Form SMTP
  extension's settings. A site that sets `owner_contact` for a `notify: full` form mails
  the submission's fields to that address, and accounts for it (OBLIGATIONS.md).
- An extension's settings read (`extension-read`) answers only the keys that extension
  declares, never the rest of `lazysite.conf` (SM1373).
- A plan Odoo refused tells the visitor Odoo's own words for a validation error, and a
  plain sentence otherwise (SM1374); the counts stay in the journal and the log.
- The shipped 403 page lists the groups a page needs as a list (SM1375). A site with its
  own `403.md` is unchanged.
- Installing, activating or binding a layout whose `layout.json` says it needs a newer
  engine answers with a warning naming both versions, and goes ahead (SM1378).
- A form's quarantine leaves email fields out of the "same value in every field" rule,
  and quarantines an email field holding quotes or SQL-shaped text (SM1379); one
  apostrophe in an address's local part passes.

## Address lists become address profiles, and the rest of 0.16.5

**Address profiles (SM1343-SM1345).** Address lists are now address profiles. The
upgrade to 0.16.5 converts `lazysite/auth/address-lists.json` to
`address-profiles.json` once: the same names and entries, with no allow or deny
kind. The old file is kept as `address-lists.json.converted`. The same step renames
`visitor.in_list` / `visitor.in_any` to `visitor.in_profile` /
`visitor.in_any_profile` in the site's pages, layouts, themes, templates and private
store, and lists each file it changed. Whether a profile allows or denies is now set
by the rule that names it: `addresses` allows, `addresses_deny` denies.

After upgrading, run `lazysite check`. It names:

- any rule that now allows a profile that was a deny list, or denies one that was an
  allow list. Such a rule was possible only by hand-editing; it refused every
  visitor before, and now does what its key says;
- any template call still using the old names, which now always answer false;
- an old store the upgrade could not convert. Until it is converted, every rule that
  names a profile refuses.

Scripts and agents: the actions are `address-profiles`, `address-profile-set` and
`address-profile-delete`, the MCP tool is `list_address_profiles`, and the users-tool
commands are named the same way (no `--kind`). The old names, and a `kind` sent, are
refused with a message naming the new spelling.

**The bad-URL blocker (SM1321).** A request for a file the site really has is never
counted, and loopback (127.0.0.0/8, ::1) is always exempt. `bad_url_exempt` names
address profiles whose addresses are exempt too; `bad_url_exempt: none` takes
loopback's exemption away. If a front end on the same host (a reverse proxy on
127.0.0.1) forwards to the engine, name it in `trusted_proxies` (`127.0.0.1`): the
default trusts the private ranges only, so until then every visitor is the proxy,
loopback, and the blocker counts nothing. Before 0.16.5 the same site refused every
visitor once a theme's scripts under `vendor/` were requested often enough.

**A site with its own `login.md` (SM1322).** The shipped sign-in page asks the server
whether the session is still honoured before it says "You are already signed in". A
site's own `login.md` carries that only if its signed-in panel has the
`data-ls-auth-check` attribute; add it, and the "Sign in as someone else" link
(`/cgi-bin/lazysite-auth.pl?action=logout&then=signin`, with the page's `next`), as
the shipped page has them.

**Theme copies under `/lazysite-assets/` (SM1335, SM1336, SM1339).** A theme's served
copies now follow its source: a write to `lazysite/layouts/<layout>/themes/<theme>/`
reaches every host's copy at once, with no activation. A write into a copy itself,
on any surface and for the operator too, is refused, naming the source to write
instead. The theme and the layout a secondary domain serves are read-only, as the
primary's are: copy, edit, then activate with `host`. A script or agent that wrote
into `/lazysite-assets/` or edited a domain's active theme in place must change.
A theme whose `assets/` holds a symbolic link or a file the web server would run is
not copied; the log and the write's answer name the entry to remove.

**Connect an AI assistant is public (SM1341).** `/docs/ai-connector-setup`, which
says how a client connects and authenticates, no longer needs a sign-in. It names no
site's accounts or credentials. A site that wants it signed-in puts an access rule on
`docs/` or a page of its own at that path.

**Smaller changes, nothing to do.** A protected folder may keep a history
(`history: true` on its rule, SM1324) and a site may audit agents' reads
(`audit_reads: on`, SM1325); both are off unless set. MCP `write_file` takes an
optional `base_mtime` and refuses a write over a newer version (SM1327). The Odoo
extension's `odoo_display_name` names Odoo in what a visitor reads (SM1328). A page
refused by an `auth/acls.json` read list now gets the site's 403, naming the list's
groups, never a user on it (SM1365). A grant on a secondary domain no longer takes
the primary away, and an account scoped today keeps exactly its reach (SM1332-SM1334).

## Plugins become extensions, on disk and in lazysite.conf (SM1142)

The upgrade to 0.16.4 moves each site in place, once, and the result is in its
summary under `Extensions:`:

- the files left in `{docroot}/../plugins/` move to `{docroot}/../extensions/`.
  A copy of a shipped file the site edited is replaced by the release's, as an
  edited code file always is, and the edit is kept beside it as
  `extensions/<file>.pl.from-plugins`; a file the site added itself moves as it
  is. The emptied `plugins/` is removed (on HestiaCP by the root-run deploy);
- `lazysite.conf`'s `plugins:` list becomes `extensions:` and each
  `- plugins/<file>.pl` entry `- extensions/<file>.pl`, so every extension that
  was on stays on - the login rate limiter among them;
- a cgi-bin link into `plugins/` is pointed at the moved file, and an account
  whose start page was the Extensions page keeps it at its new address.

Nothing reads the old names afterwards. `lazysite check` names a `plugins:` list
or a `- plugins/...` entry written back by hand, by line.

**What you check yourself** - references the upgrade cannot see, made by hand
from older docs:

- a crontab or script running `perl .../plugins/stats.pl --classify` or
  `--export`: it is `extensions/stats.pl` now;
- a pipe to `perl .../plugins/form-smtp.pl --pipe`: `extensions/form-smtp.pl`;
- a `cgi-bin` link you made yourself outside the site's cgi-bin;
- a bookmark to `/manager/plugins` or `/manager/plugin-config`: the pages are
  `/manager/extensions` and `/manager/extension-config`, and the old addresses
  are not kept;
- a script calling the manager or control API as `plugin-list`, `plugin-read`,
  `plugin-save`, `plugin-action`, `plugin-enable` or `plugin-disable`, or passing
  `?plugin=`: those are refused now, naming the `extension-*` action and the
  `extension` parameter to use. `extension-list` answers under `extensions`;
- an audit or log filter on the old names: from 0.16.4 the audit writes an
  extension action's row as `extension-*` (`extension-save`, `extension-action`
  and the rest; rows written before stay `plugin-*`), SM831's
  `spelling=deprecated` flag is gone with the old spelling, and a disabled
  extension's refusal logs as `extension-gate` (was `plugin-gate`). Match both
  spellings until the old rows age out.

## Starter pages are opt-in for new sites (SM1285, SM1286)

Nothing changes on an existing site. Its starter pages are kept: the demos, the
sample contact and members pages and the starter's welcome page. A site
provisioned from now on gets none of them unless `provision --starter` asks. It
has the system pages, the site search, the `/docs` manual and a minimal home page
that the engine serves until the site writes its own `index.md`.

To clear out the starter pages a site never edited:

```bash
lazysite starter --docroot /path/to/public_html --list
lazysite starter --docroot /path/to/public_html --remove-unmodified --dry-run
lazysite starter --docroot /path/to/public_html --remove-unmodified
```

An edited page is never removed. A menu entry left linking a removed page is
named in the output, for you to edit.

## The /docs manual moves into the engine (SM1284)

The whole `/docs` manual, the agent briefings included, now ships in the engine
tree (`lazysite/templates/docs/`) and is served from there whenever the site has
no page of its own at the path. Upgrades refresh it, and clearing a site's
content leaves it in place.

What the upgrade does to a site's `docs/` folder:

- **A page the site never edited is removed**, along with its cached render.
  The install state's checksum says it is unchanged, so the engine's copy now
  serves at the same URL.
- **An edited page is kept** and named in the output as `orphan (edited
  post-install, left in place)`. It still serves in place of the engine's page,
  and `lazysite check` warns that it shadows a newer version. Delete it to serve
  the engine's page, or keep it as a deliberate override.
- **A page the site wrote itself is untouched.** So is everything outside
  `docs/`, the starter pages included.

The manual stays out of the site's search, sitemap, feeds and `llms.txt`. Set
`engine_docs_public: true` in `lazysite.conf` on a site that should list it,
such as the product's own documentation site.

## The visitor's address, if this site is behind a reverse proxy (SM929)

Nothing to do on a site served directly: the engine reads the connecting address,
exactly as before.

**A site behind a reverse proxy needs two things, and until both are present every
address the engine records is the proxy's** - the `_ip` on a form submission, the
audit trail's actor column, the login and form rate-limit buckets, the bad-URL
auto-blocker and the daily visitor count:

1. **The proxy must send the visitor's address.** The shipped nginx templates now
   do (`X-Forwarded-For`, template revision `2026-10-01`). A template reaches a
   site only when Hestia rebuilds that site's vhost, so the rollout table's VHOST
   column reads `rebuild` until it has been - that column is how you tell which
   sites are still on the old template.

   **Hestia renders a vhost from its OWN copy of the template, not from the
   package's** (SM1196). That copy is put there by hand once, so an upgrade used
   to leave it old and every `v-rebuild-web-domain` re-rendered the old template:
   edge's installed `lazysite-proxy` predated SM929 and kept passing the client's
   `X-Forwarded-For` through after a rebuild. `lazysite-hestia-update-all.sh` now
   compares each lazysite template in Hestia's directories (the nginx
   `lazysite-proxy`, and `lazysite-app`, `lazysite-cgi`, `lazysite-fcgi` where
   installed) with the release's on EVERY run, replaces one that differs (the old
   copy kept beside it as `NAME.EXT.bak-TIMESTAMP`, which Hestia does not offer as
   a template), names the domains that render it until rebuilt, and rebuilds them
   with `--rebuild`. A refresh that fails is a FAILURE line and exit status 1. On a
   host that only has the packages, copy the templates again after every upgrade
   (`lazysite-hestia-domain` says when its copy is STALE). To check the result:
   `grep -n "X-Forwarded-For" /usr/local/hestia/data/templates/web/nginx/lazysite-proxy.*tpl`
   must match in both files, and a request sent with `X-Forwarded-For: 192.0.2.55`
   must not be seen as 192.0.2.55.

   **`--rebuild-exposed` rebuilds only the sites at risk** (SM1265). A site whose
   vhost still passes the client's `X-Forwarded-For` through, and which trusts
   forwarded addresses (`trusted_proxies` absent, empty or a list), is a FAILURE:
   any visitor chooses their address. With `--rebuild-exposed` the rollout
   rebuilds those sites, and no others, after it has refreshed Hestia's template
   copies and before it deploys, so the deploy's permission pass and the repair
   put back what the rebuild resets (SM270). Each one is logged as `auto-rebuilt`.
   Without the flag the FAILURE line names it. It cannot be combined with
   `--list`, which changes nothing.
2. **The engine must be told the proxy is trustworthy.** `trusted_proxies` on the
   Config page, or in `lazysite.conf`. Absent or empty means the private ranges
   `10.0.0.0/8`, `172.16.0.0/12` and `192.168.0.0/16`, which covers a proxy on a
   private address and needs no action. **If your front end is on this machine,
   name it** - `127.0.0.1` is not trusted unless you say so. `trusted_proxies:
   none` ignores forwarded headers entirely.

`lazysite-check` reports an entry it could not parse, and says when the setting
resolves to no trusted address at all.

**One consequence worth knowing before you enable it.** Where a site previously
recorded one private address on every submission, it will now record the
visitor's real address - which is personal data where the proxy's address was
not.

**That is a decision, not an oversight** (ruled 2026-10-01): the address is kept
in full because it is what abuse handling needs - an operator who wants to block
or report a source has nothing to act on without it, and the nine submissions
that produced this filing were indistinguishable from each other precisely
because the address identified nobody. Truncating it the way the visitor log does
would reproduce that problem one octet higher up. The two stores differ on
purpose: counting distinct visitors needs no identity, and handling abuse does.

## Upgrading to 0.13.13 from 0.13.12

**This release breaks how form delivery is written, and converts it for you.**
It is the change the 0.13.x line was built towards: a form calls a named
**handler**, the timer calls handlers too, and there is one way to say where
data goes (SM842).

What the upgrade converts, once, by running `lazysite-handlers.pl convert`
from the newly installed tree (it prints what it changed):

- **`webhook` and `api` handlers** become **connectors** - with the webhook's URL
  and body format, public invocation, and no rate cap, as the webhook had - and
  the handler becomes a `connector` handler naming it.
- **`db` handlers** become `table` handlers with `keep_copy: false`.
- **Inline targets in a form's config** (`- type: file`, `- type: webhook`)
  become named handlers, reusing one that already delivers to the same place.
  An inline target in a form that ALSO names a handler never delivered - the old
  reader ignored it - so it is dropped, not woken up.
- **A connector's own schedule** (`schedule_every`, `schedule_payload`) becomes an
  entry in the new `lazysite/forms/schedule.conf`, calling a connector handler.

What it cannot convert, and says so in the upgrade summary: a **webhook to a
plain `http://` URL on another host** - a connector sends over https, or http to
this host only. That handler delivers nothing until its URL is changed and the
conversion is run again (`lazysite-handlers.pl convert --docroot <docroot>`, as
the site user). `lazysite check` reports any shape the conversion left.

What changes for people and agents:

- Handlers are configured on the new **Handlers** page (System), not in the Form
  Handler's section of Extension Config; the submissions viewer stays there.
- **Who may make a handler depends on where it sends**: a table handler needs
  Data (`manage_data`), a connector handler needs Connectors
  (`manage_connectors`), email and file handlers need Forms (`manage_forms`).
  Binding a form to an existing handler needs Forms alone. Handler actions are
  now available to token clients too.
- MCP's `list_form_handlers` is **`list_handlers`**; `bind_form` takes a handler
  (or `handlers`) and no inline `target`. A form config written over WebDAV whose
  targets are not existing handlers is refused with 422.
- A connector save carrying `schedule_every` or `schedule_payload` is refused by
  name - schedule it on the Handlers page instead.
- The daemon's `connectors-call` job is replaced by `schedule-run`. Its job
  account needs the capability of each scheduled handler's destination.

**Three settings that were kept alive for one release are gone** (pre-stable:
one way to say each thing). The upgrade converts the configuration and says so:

- `manager_upload_blocked_paths` in `lazysite.conf` is renamed to
  `manager_blocked_paths`, its name since SM019c. Where both were set the old
  line is dropped - the new key already won.
- `db_render_raw` is deleted. `db:` values are always escaped (SM786); a site
  that had it on is warned in the upgrade summary, because a value that carried
  HTML now shows it as text.
- `form-list` (and MCP `form_list`) returns the submission count as `row_count`
  only; the `rows` alias for it is gone. `rows` is the array of submissions in
  `form-submissions`, which is why the count needed another name.

`lazysite check` reports either key if it comes back.

**Control API refusals now carry an HTTP status** (SM670). A client of
`/cgi-bin/lazysite-manager-api.pl` that treated every response as 200 sees 403,
404, 409, 413, 429, 207 or 400 on a refusal - by the refusal's `kind`, listed in
`docs/ai-connector-tools.md` under the error model. The JSON body is unchanged
and still carries `ok: false`, so a client that reads the body, as the manager's
own pages do, is unaffected. A client that stops on a non-2xx status before
reading the body should read it anyway: that is where the reason is.

**`whoami` separates what an account may do from what it is** (SM821), on both
the control API and MCP. `capabilities` now holds only the capability keys, and
`ui` in it means manager access (what `manager_ui` meant - that key is gone).
Everything else moved to a new `account` block: `groups`, `email`,
`display_name`, `created_by`/`created_at`/`managed_by`, token and MFA state,
scopes, and `interactive_login` - the setting that `ui` used to report over the
control API. The control API's `partner` is now `user`, as on MCP. A client that
read `capabilities.ui` as "may sign in", `capabilities.email` or top-level
`groups` reads `account.interactive_login`, `account.email` and `account.groups`.

**Login rate limiting is now an extension, and the upgrade switches it on**
(SM798). `plugins/login-rate-limit.pl` is listed in every site's `plugins:` list
by the first upgrade that carries it, and on every fresh install, so nothing
changes for a site unless its operator switches the extension off. Switched off,
sign-in attempts are not counted and no counter is kept; the sign-in log and
`lazysite check` both say the limiter is NOT in force, as they do when DB_File
is missing (Debian: `libdb-file-perl`, now the extension's declared dependency).
The upgrade does this once: switch it off afterwards and it stays off.

**Re-render your vhost** (SM797). The shipped front-end templates now hand a
page's markdown, `.url` and `.brief` files, backups, config, keys and executable
source to the engine instead of serving them from disk - so `/about.md` renders
the page and a stray `config.bak` is *not found*, whether or not the site has an
ACL store. A package upgrade does not rewrite an installed vhost: run
`lazysite-apache-vhost add` or `lazysite-nginx-vhost add` again for the domain
with the options it was added with plus `--force` (an existing vhost is refused
without it), or rebuild the domain in Hestia (which re-applies both the web and proxy
templates). If you maintain your own vhost, apply contract item 5 in
`docs/reference/webserver-wiring.md`. On a multi-domain instance, regenerate the
per-domain block (`... rewrites --docroot <docroot>`) as well.

The same re-render carries a second fix (SM850): the rule that hands existing
files to the engine once a site has an ACL store now also looks for the store
beside the docroot, where it is on a site whose engine tree was moved out
(`lazysite migrate-engine-tree`). Before, that rule never fired on a migrated
site, and the front end served its static files from disk whatever the ACL said
- the private store still held back what had been moved into it. If you
maintain your own vhost, apply contract item 7 in the same reference.

**On Hestia, the rollout now tells you what is left** (N13-41..43). The table
`lazysite-hestia-update-all.sh` prints first has two new columns:

- **ENGINE** - where the site's engine tree is: `inside` the docroot, `outside`
  (migrated), or `BOTH`, a half-finished migration, which is always a fault.
- **VHOST** - whether the vhost Hestia rendered for the site carries this
  release's template (`current`) or an older one (`rebuild`). Every shipped Hestia
  template now carries a `# lazysite-template-rev:` line for this. Every site
  reads `rebuild` on the first rollout of 0.13.13, because no earlier template
  had the line - which is also true: none of them has this release's rules yet.
  Run the rollout with `--rebuild`, or `v-rebuild-web-domain USER DOMAIN` per
  site, and the column turns `current`.

The summary at the end adds **CHECK** - `lazysite check` for each site that
updated, as `clean` or its warning and failure counts - and VHOST as it stands
after the run, with a count of the sites still to rebuild.

The Hestia scripts also stop assuming the engine tree is inside the docroot. On
a migrated site the rollout used to read the version as `?` and the channel as
unset, the lister flagged `NO-INSTALL-MARKER`, and the deploy treated every
upgrade as a first install - re-applying the template, rebuilding the vhost and
re-running the setup-manager step - while its permission sweep and secret
lockdown went to a directory that was no longer there. They now find the tree
where it is. `update-all` requires the lister it ships with; the fallback that
searched `/home` for install markers is gone.

## Upgrading to 0.10.19 from 0.10.18

**This is a BETA build** - the first promotion off the edge line. A site takes
it only if its `update_channel` accepts beta or below; nothing changes for a
site set to `stable` or `certified`.

**No new operator action.** Two fixes are worth knowing about because they
change behaviour you may have worked around:

- **Access rules now travel with content on every surface.** Deleting content
  drops its rules (previously only over WebDAV); moving content carries them.
  If you have been re-applying rules after a move, you no longer need to.
- **The access-rule store stays writable by the manager after a deploy.** If
  you saw `acls.json ... is not writable by the CGI` repaired on every upgrade,
  that was a real fault and it is fixed.

**Coming from 0.10.14 or earlier: the 0.10.15 section's four manual steps
remain your list.**

## Upgrading to 0.10.18 from 0.10.17

**No new operator action, and one thing that now happens for you.** From this
release an upgrade INVALIDATES RENDERED PAGES (SM413): cached pages re-render
on next request, so the first page you check after upgrading reflects the
build you just installed. Before this, a page whose source had not changed
kept its pre-upgrade render indefinitely - a homepage was found serving the
same render through four deployments.

Also automatic: the outside-in ACL probe now drops to the site's owner instead
of refusing when the deploy runs as root, so `lazysite probe` produces a
verdict rather than "NOT CONFIRMED" (SM426).

**Worth knowing:** this release fixes a CRITICAL issue where an authenticated
content editor could write outside the content area (SM418). No action is
needed beyond upgrading.

**Coming from 0.10.14 or earlier: the 0.10.15 section's four manual steps
remain your list.**

## Upgrading to 0.10.17 from 0.10.16

**No new operator action.** The multi-domain apply fix (SM412), the plugin
enabled-gate (SM409 - gates only contract-declaring plugins, of which none
ship yet), and the session-verification module move (SM411) all travel in the
package with behaviour preserved for existing sites. New diagnostic worth
knowing: `plugins/stats.pl --classify --path P [--ua UA] [--status N]
--docroot D` answers the visitor classifier from the command line without
touching the stats.

**Coming from 0.10.14 or earlier: the 0.10.15 section's four manual steps
remain your list.**

## Upgrading to 0.10.16 from 0.10.15

**No new operator action.** Everything 0.10.16 changes travels in the
package: build provenance in the release manifest (SM400), structured
form answers (SM401 - an authoring feature, nothing to migrate), the
form handler recording capture method instead of an unverifiable
identity (SM402 - existing stored submissions are unchanged; only new
submissions carry the new field), checked stats writers (SM404), and a
deterministic release gate (SM406).

**If you are coming from 0.10.14 or earlier, the 0.10.15 section below
is still your list** - its four manual steps (ACL re-apply, the proxy
template, the CSP decision, the front-door check) are cumulative and
none of them is superseded here. Do them once, at whatever version you
land on.

One thing to KNOW rather than do: from this release the artefact can
prove which commit its gate validated - `release-manifest.json` carries
`validated: {commit, files, tests}` and the repo's
`docs/releases/GATE-LOG.md` holds the matching row. If you verify builds
before rollout, that is the field to check.

## Upgrading to 0.10.15 from 0.10.10-0.10.14 (READ THIS ONE)

The package upgrade does the code. **Four things it cannot do**, and the
order matters.

### 1. Re-apply access rules, AFTER the upgrade

From 0.10.8 protecting content MOVES it out of the served tree - but
only on the act of protecting. Any section protected on an earlier
version still has its files in the document root, with the rule honoured
for pages and the files public.

```bash
lazysite acl reapply --docroot <docroot>
```

After the upgrade, never before: it re-issues stored rules through the
new code. It changes no rule. `NOT MOVED: <path>` in the output means
the rule was stored and nothing moved, which is the condition it exists
to find.

### 2. The proxy template, which a package cannot deliver

`lazysite-proxy` is a Hestia template. **A package upgrade does not
install or update one**, and 0.10.15 corrects a defect in it (SM374)
that returns **421 on every request** to a TLS domain.

::: widebox
**While the host's copy is stale the failure is identical to the bug.**
An operator who applies the fix, sees 421, and concludes the fix does
not work has been misled by their own template directory. Confirm the
copy on the host is the new one before drawing any conclusion from a
421.
:::

```bash
v-change-web-domain-proxy-tpl <user> <domain> lazysite-proxy
```

Test on the **body**, not the status: without a correct `Host` the
backend serves its default vhost with a 200, so a status check cannot
say which site answered.

### 3. The private store, if it does not exist yet

Creating it is a root action. `lazysite-check` reports whether the
engine can write to it; if the store is missing on a site that protects
anything, create it before re-applying rules.

### 4. Verify from outside, as the site user

```bash
lazysite check --check-acl https://<domain>
```

**Not as root.** The probe protects a fixture to measure it, and doing
that as root would leave root-owned files in the site tree - so it
declines and says so (SM377). The reason it gives is the one to act on;
the summary no longer overwrites it with a guess (SM385).

### Effective permissions widen if you are coming from 0.9.x

This has its own heading because it is a change of **who can read what**,
not a feature.

An `@group` entry in an ACL grants access to the members of that group.
Until SM288, MCP and the control API **discarded an account's groups**,
so those entries were silently inert on two of the three channels.
WebDAV honoured them; the others did not.

::: widebox
**Nobody gains groups here.** Partners already had them; two channels
were throwing them away. What changes is that an `@group` entry which
has been doing nothing on MCP starts doing what it says.
:::

Before upgrading a site that uses `@group` entries, see exactly who is
affected:

```bash
lazysite acl group-reach --docroot <docroot>
```

It lists each `@group` entry, the paths that grant it, and **every
account it reaches - including through nested groups**. Nested is the
case worth having: an account that reaches a group only by nesting is
precisely the one a quick look at the members list would miss.

If the report names an account you did not expect to have access,
resolve it before upgrading rather than after.

### What changed that you will see

- **A Content-Security-Policy now ships**, `report-only` by default.
  `csp: enforce | report-only | off` in `lazysite.conf`. **Do not set
  `enforce` yet** - the manager's controls use inline handlers a CSP
  hash cannot cover, so the manager is held at report-only regardless
  until they are converted.
- **Engine-served statics revalidate** rather than caching for a decade
  (SM387), and now carry an ETag so revalidation costs a 304 rather than
  a re-download (SM388). The ten-year cache was a property of the
  front-end fast path, not of lazysite.
- **402 and 403 pages** carry the full header set and resolve their own
  domain's content root - on a multi-domain instance they were rendering
  into the primary's docroot.
- **A backup of a live site no longer fails** because a visitor arrived
  mid-snapshot (SM381).

## Upgrading to 0.10.10 from 0.10.0, 0.10.8 or 0.10.9

The fleet spans **0.10.0** (stable) and the edge line, and every one of them
needs the same operator action after upgrading. It is not delivered by the
package.

### Why an upgrade alone is not enough

From 0.10.8, protecting content **moves it out of the document root** into a
private store beside it, so that a front end which serves files without asking
the engine cannot reach protected bytes. That was the structural answer to
SM248, SM268 H17 and SM283.

The move happens **on the act of protecting**. It is not a migration, and no
upgrade performs it retrospectively. So:

```datatable
columns: If the site is on | Then after upgrading to 0.10.10
widths: 3.4cm | X
bold: 1
tone: medium
text: 2
---
0.10.0 (stable) | Every section ever protected still has its FILES in the document root. The rule is stored and honoured for pages; the files are reachable by anyone who knows the path on a front end that answers statics itself. Measured on a real upgraded site: 19 of 25 extensions still served byte-identically to an anonymous request.
0.10.8 (edge) | The same, for anything protected before 0.10.8 - AND anything protected ON 0.10.8 may be in that state too, because SM296 could crash the move after the rule was saved, leaving the content stored-as-protected and still served with no audit line.
0.10.9 (edge) | The same, if the sweep was run and reported success while moving nothing. Until 0.10.10 a re-apply that stored the rule and moved no files counted as "re-applied" and exited 0, so a fleet sweep could report every site done having achieved nothing. **Run it again on 0.10.10 and read the new count.**
```

Both are repaired by the same action, because both are "the rule is right and
the bytes are in the wrong place".

### What 0.10.10 changes about this

Three things, all of which make the SAME action more likely to actually work:

- **The store gets created.** The sweep needs the private store, which is a
  SIBLING of the document root - so repairing the docroot never reached it, and
  a site with a perfectly repaired `public_html` could still move nothing.
  `lazysite check --fix`, run as root, now creates it. See below.
- **A sweep that moves nothing says so.** It is counted as `moved nothing`
  rather than `re-applied`, the cause is named once, and the command exits
  non-zero. On 0.10.9 and earlier it reported success.
- **The rollout checks from OUTSIDE afterwards.** Every run now probes each site
  anonymously and reports whether the front end honoured the rule, because the
  engine's report and the front end's behaviour are different claims and have
  disagreed three times. A site it could not measure is reported as `not
  confirmed` rather than as passing.

### The action

**Re-apply every stored rule.** This re-issues each rule with the values already
in the store - it grants nothing, revokes nothing, and changes no rule. What
changes is where the files live.

Per site:

```bash
# see what would happen (dry run - this is the default)
lazysite acl reapply --docroot /path/to/public_html --actor local

# do it
lazysite acl reapply --docroot /path/to/public_html --actor local --apply
```

Across a Hestia fleet, as part of the rollout:

```bash
bash /tmp/lazysite-0.10.10/installers/hestia/lazysite-hestia-update-all.sh \
     --reapply-acls
```

The sweep runs only on sites that actually upgraded - a site skipped by its
update channel is still on its old version - and runs as each site's own user,
never as root.

`--reapply-acls-dry-run` (SM1238) runs the dry run on the same sites, as the same
users, and moves nothing. Each `NOT MOVED: <path>` line it prints - a rule stored
with its files still in the document root - is reported as a finding, and the
rollout exits 2 if there is one.

::: widebox
**Order matters: upgrade first, then sweep.** The re-apply is the operation
SM296 broke. On 0.10.8 it is the thing that crashes, so running it before the
upgrade repairs nothing and reports failures. `--reapply-acls` sweeps after the
deploy step for exactly this reason.
:::

### The sweep needs the private store to exist

The store is `<docroot>-lazysite-private` - a **sibling** of the document root,
not a directory inside it. Creating it needs write access on the docroot's
*parent*, which on the Hestia layout is the domain folder.

**Repairing the document root does not fix this.** They are different
directories, and a site can have a perfectly repaired `public_html` where the
sweep still moves nothing. That happened on a live instance in August 2026:
`MKCOL`, `PUT`, overwrite and `DELETE` at the site root all worked, and
protecting a folder still left every file public and anonymously reachable.

```bash
lazysite check --docroot /path/to/public_html          # names the store, owner, mode
sudo lazysite check --docroot /path/to/public_html --fix   # creates it
```

`--fix` creates the store owned by the site user, mode 2770. It deliberately
does **not** make the parent directory group-writable: that parent also holds
`cgi-bin`, and write permission on a directory is permission to rename its
entries, so the wider repair would open a larger hole than the one being closed.

From 0.10.10 the sweep reports this rather than hiding it. A re-apply that stores
the rule and moves nothing counts as `moved nothing`, not as `re-applied`, and
the command exits non-zero - so a fleet sweep that achieved nothing can no longer
report success.

### Verify from outside

Do not take the sweep's own word for it. The engine's report and the front end's
behaviour are different claims, and SM283 was the case where they disagreed.

**From 0.10.10 the fleet rollout does this for you**, per site, at the end of
every run - reporting `verified`, `exposed` and `not confirmed` separately, and
exiting non-zero on an exposure. Run it by hand for a single site, or to re-check
after repairing one:

```bash
lazysite check --check-acl https://<domain>/
```

That gates a probe folder against a principal which cannot exist and fetches it
anonymously under several extensions, with a public control of the same type
alongside each - so a refusal that happens because the front end cannot read the
file is distinguishable from a refusal that is the access rule working.

### Also outstanding from 0.10.7, on Hestia

SM283's remedy is an nginx **proxy template**, and it is likewise not delivered
by a package upgrade: the template must be staged and each domain moved onto it.

```bash
bash /tmp/lazysite-0.10.10/installers/hestia/lazysite-hestia-update-all.sh \
     --proxy --reapply-acls
```

Check whether a domain has it with no credentials:

```bash
curl -sI https://<domain>/ | grep -i X-Lazysite-Front
```

A domain with an ACL store and no `X-Lazysite-Front` header is on a stock proxy
and is the SM283 shape. `lazysite-hestia-list.sh` flags those as
`ACL-BYPASSED-BY-PROXY(SM283)`.

### Optional, and separate

`lazysite migrate-engine-tree --apply` moves the `lazysite/` engine tree out of
the document root (SM293). Dry-run by default, reversible with `--back`, and
gated by `--min-version`. It is unrelated to the re-apply sweep and can be done
whenever.

## manager_groups retired (SM138)

The legacy `manager_groups:` key in `lazysite.conf` is retired. Manager access
is granted by **groups**: any group carrying the `ui` capability (manager UI) or
`manage_users` (operator powers), managed on the manager **Groups** page.

**Migration is automatic.** On the first settings read after upgrade, any group
the conf key named receives the full manager grant explicitly (every capability
except the remote `api`/`mcp` channels - manager groups are interactive-only),
and the `manager_groups:` line is removed from `lazysite.conf`. Effective access
is unchanged: those groups had unrestricted operator access through the fallback
already. No operator action is needed; a lingering line (e.g. an unwritable
conf) is simply ignored.

If **no** group grants manager access at all, the site is in the unsecured/dev
mode where any authenticated user is a manager - run
`lazysite-users.pl setup-sysop` (or grant `ui` to a group) to secure it, as
before.

## WebDAV publishing (SM070)

A WebDAV endpoint (`/dav`) is available for headless, per-file
content publishing. It is **off by default** — an existing install is
unchanged after upgrade until you opt in. To enable it:

1. Add `webdav_enabled: true` to `lazysite/lazysite.conf`.
2. Add the `/dav` ScriptAlias to your web server. The shipped Hestia
   templates include it; for a hand-rolled Apache vhost add
   `ScriptAlias /dav /path/to/cgi-bin/lazysite-dav.pl` and ensure the
   `RequestHeader unset X-Remote-*` lines are present (now in the
   shipped templates).
3. For each publishing account, set `webdav on` (and usually a
   `dav_scope`) on the manager Users page, then generate a credential.

The Hestia templates also gained the `RequestHeader unset X-Remote-*`
directives that `docs/architecture/security.md` has always required;
they need Apache's `mod_headers`. See
`docs/features/configuration/webdav.md` for the full guide.

## 0.2.x to 0.3.0

The installer is now upgrade-aware. This is the first version
with safe in-place upgrades: a later release can be applied to a
site without losing its content. (0.3.0 reached that by re-running
`install.sh`; today it is `lazysite upgrade` - see *How to upgrade*
at the top.)

### What this enables

- Seed files you have edited (starter pages, your custom docs,
  registry templates) are preserved across upgrades.
- Code files (processor, plugins, manager UI, system theme)
  are overwritten with each new release.
- Files removed in new versions are cleaned up only if you
  haven't edited them; edited orphans stay and produce a
  warning.
- Pre-upgrade backups accumulate under
  `{docroot}/lazysite/backups/`, retained per
  `backup_retention` in `lazysite.conf` (default 3; 0 = keep
  all).
- `--dry-run` shows the full upgrade plan without modifying
  anything.

### What does NOT get migrated

Installs created with 0.1.x or 0.2.x pre-dating the 0.3.0
installer do not have `.install-state.json`. The installer
treats them as fresh installs: it walks the manifest and
skips-if-present, which is the old behaviour. The first
post-0.3.0 run establishes `.install-state.json` for future
upgrades. Effectively, 0.3.0 is where upgrade-tracking begins.
Plan to back up your docroot before the first 0.3.0 install
on an existing deployment.

### If upgrade goes wrong

Every upgrade creates a backup first. To list them:

```bash
lazysite backups --docroot /path/to/public_html
```

To restore the most recent, or a specific one:

```bash
lazysite backups --docroot /path/to/public_html --restore
lazysite backups --docroot /path/to/public_html --restore --backup PATH
```

Restore does not touch runtime state (auth users, cache,
logs). It invalidates the rendered HTML cache afterwards so
stale pages don't linger.

### No default layout or theme ships

0.3.0 ships no layout or theme content of its own. A fresh
install has no `lazysite/layouts/NAME/layout.tt`, and the
processor falls back to a built-in template until one is
installed. Install a layout + theme via the manager UI at
`/manager/themes` > "Install from Releases" (the configured
`layouts_repo` default is `OpenDigitalCC/lazysite-layouts`),
or drop a layout directory in manually.

### New files installed

`install.sh` now installs:

- `install.pl` at the repo root (the real installer; the
  shell script is a thin wrapper).

### No change for fresh installs

First-time installs work the same as before.
`.install-state.json` is created automatically on first run.

## 0.1.0 to 0.2.0

Breaking changes in this release. Read the whole file before
upgrading a production install.

### Plugin URLs changed

Plugins moved from `/cgi-bin/lazysite-*.pl` to `/cgi-bin/*.pl`:

- `/cgi-bin/lazysite-form-handler.pl` -> `/cgi-bin/form-handler.pl`
- `/cgi-bin/lazysite-payment-demo.pl` -> `/cgi-bin/payment-demo.pl`

Update any external integrations pointing at these URLs:

- Web form `action=` attributes in custom pages
- Webhook URLs in `handlers.conf`
- External systems POSTing to `form-handler`
- Payment flow URLs

`form-smtp` is not a URL endpoint (it runs as a subprocess of
`form-handler`), so nothing to update there.

### Plugin source locations changed

Plugin scripts moved from the repo root (and `tools/`) to
`plugins/`, dropping the `lazysite-` prefix:

- `lazysite-form-handler.pl`   -> `plugins/form-handler.pl`
- `lazysite-form-smtp.pl`      -> `plugins/form-smtp.pl`
- `lazysite-payment-demo.pl`   -> `plugins/payment-demo.pl`
- `lazysite-log.pl`            -> `plugins/log.pl`
- `tools/lazysite-audit.pl`    -> `plugins/audit.pl`

Core scripts keep their `lazysite-` prefix at repo root:

- `lazysite-processor.pl`
- `lazysite-auth.pl`
- `lazysite-manager-api.pl`

`install.sh` now places plugins under `{docroot}/../plugins/`
and symlinks `form-handler.pl` and `payment-demo.pl` into
`cgi-bin/` for Apache routing. The dev server
(`tools/lazysite-server.pl`) discovers both locations.

### Plugin enable-list entries become stale

Your installed `lazysite.conf` has `plugins:` entries referencing
the old plugin paths, for example:

    plugins:
      - cgi-bin/lazysite-form-handler.pl
      - tools/lazysite-audit.pl

After upgrading to 0.2.0, these paths no longer resolve. The
manager UI will treat the plugins as disabled, even though the
underlying scripts are installed. Form processing, audit runs, and
any other affected features stop working silently.

**To fix:**

**Option 1 - via the manager UI.** Visit `/manager/plugins` and
toggle each plugin off then on. The new paths are written to
`lazysite.conf` in the new format.

**Option 2 - hand-edit lazysite.conf.** Replace old paths with
new ones:

    cgi-bin/lazysite-form-handler.pl  -> plugins/form-handler.pl
    cgi-bin/lazysite-form-smtp.pl     -> plugins/form-smtp.pl
    tools/lazysite-audit.pl           -> plugins/audit.pl
    lazysite-log.pl                   -> plugins/log.pl

Leave `lazysite-auth.pl` alone - it stays at repo root and keeps
its old entry.

This migration will be automatic in 0.3.0 when the upgrade-safe
installer lands (D021c).

### Upgrade procedure

1. Review external integrations (webhooks, custom form actions,
   payment flows). Update any URLs that point at the old
   `/cgi-bin/lazysite-*.pl` paths.
2. Take a backup of your site. (The upgrade-safe installer arrives
   in 0.3.0; for now, backup is manual.)
3. Extract `lazysite-0.2.0.tar.gz` and apply it to the same
   `--docroot` and `--cgibin` you used for 0.1.0. (0.2.0 was
   installed by re-running `install.sh`; today that is
   `lazysite upgrade` - see *How to upgrade* at the top.)
4. The installer places new plugins under
   `{docroot}/../plugins/`. Old plugin files left over from 0.1.0
   in `/cgi-bin/` or `{docroot}/../` can be removed manually once
   you have confirmed the new layout works.
5. Reconcile `lazysite.conf` `plugins:` entries per the previous
   section.
6. Restart Apache (or reload the config) to ensure routing
   changes take effect.

### New files installed

`install.sh` now catches up with files that were in the release
manifest but previously not installed by the installer:

- `starter/lazysite/templates/docs/features/` subtree (authoring, configuration, and
  development feature docs) under `{docroot}/docs/features/`
- `tools/lazysite-server.pl` (dev/evaluation server) and
  `tools/build-static.sh` (static site export) under
  `{docroot}/../tools/`
- `lazysite.conf.example` and `nav.conf.example` as reference
  files under `{docroot}/lazysite/`
- `users.example` and `groups.example` under
  `{docroot}/lazysite/auth/` as references, and as seed sources
  for `users` / `groups` on fresh installs
