---
title: "lazysite - dated obligations register"
subtitle: "Every obligation with a date or a version anchor, in one place. Reviewed at every release."
brand: plain
standard-margins: true
---

# What this file is

The single register of every lazysite obligation that has **a date, a version
anchor, or both**. It exists because those obligations were previously spread
across four documents with no combined view, and one of them was written
relatively ("five years from the first stable release") - which decays the
moment a reader has to work out which release that was.

Nothing here is new policy. Each row points at the document that *is* the
policy; this file is the calendar over them.

::: widebox
**This file is reviewed at every release.** The release gate runs
`tools/lazysite-compliance.pl --check`, which fails when a row's date has
entered its lead time with the row still `open`, or when `reviewed_at_version`
is behind the version being cut. Updating this file is therefore part of
cutting a release, not something to remember afterwards.
:::

```yaml
reviewed_at_version: 0.17.0
content_sha:         c8547d3d824105d1
reviewed_on:         2026-11-12
next_review:         at the next release, whichever channel
owner:               release manager
```

# Build-side obligations

Discharged by the development team, in the repository, as part of making a
release. Each has a version anchor: the release that must carry it.

```datatable
columns: Obligation | Due | Version anchor | State | Source
widths: 4.2cm | 2.4cm | 2.4cm | 1.8cm | X
bold: 1
tone: medium
text: 5
---
Declaration of Conformity finalised and signed | at the certified cut (ADR 0010) | certified cut | OPEN | docs/DECLARATION-OF-CONFORMITY.md - draft restamped to 0.16.0 on 20 Oct 2026 and unsigned; the release manager signs it at the certified cut
Significant-change register entry per triggering release | at each release | 0.17.0 | STARTED | docs/SECURITY.md - four entries cover 0.17.0, the stable (rulings 227, 242), not security-critical, all dated 12 Nov 2026 and drafted by the developer agent and confirmed by the release manager on 12 Nov 2026 (ruling 251): SM1444 (the bad-URL blocker counts probes for credential files, ruling 245: a hardening of a default list; no trigger), SM1446 (a backup that did not finish is never listed or restored, and a full backup runs in a detached worker, one at a time, ruling 248: the request's own code and identity continued; one residual, that two starts in the same instant can both pass the one-at-a-time check; no trigger), SM1447 (a refusal names the user who can run the command, and the check says ok only about what it read, holding ruling 243; no trigger) and the 0.17.0 walk's entry (SM1442, SM1443 and SM1445, and each change's assessment, with the statement that 0.17.0 is the stable promotion of 0.16.12 with the field-pass fixes), which fires no trigger. Three entries cover 0.16.12, the second beta (ruling 242), not security-critical, drafted by the developer agent and confirmed by the release manager on 11 Nov 2026 (ruling 243): SM1439 (`install.pl --restore-full` lays the engine from the release, applies the serving group and modes and writes the install state, ruling 239: a system-user operation, the code and modes from the release and the data from the tarball; no trigger), SM1440 (a refusal names the unix user to run as on the CLI and names none through a web door, ruling 243, the check says ok only about what it read, no `--fix` hint with nothing to fix, and one tightened write, a group limit on a group that does not exist; no trigger) and the 0.16.12 walk's entry (SM1438's rehearsal record, with each change's assessment), which fires no trigger. Two entries cover 0.16.11, the beta (ruling 236), not security-critical, both drafted by the developer agent and confirmed by the release manager on 11 Nov 2026 (ruling 237): SM1435 (address profiles chosen from those that exist, ruling 234 and, for a page's front matter, ruling 235: a rule, a group's address limit or a page naming a missing profile is refused at every door, and a profile a rule names cannot be deleted; a hardening, no trigger) and the 0.16.11 walk's entry (SM1430, the display-only signed-in marker cleared on a page response with no session, SM1435's Groups page wording and SM1437's check output; 17c1edb13), which fires no trigger. Two entries cover 0.16.10, an edge release, not security-critical (ruling 229), both drafted by the developer agent and confirmed by the release manager on 10 Nov 2026 (ruling 233): SM1422 (a manager cannot point a new OIDC map entry at a capability group; ruling 229 rules it ships in 0.16.10 with no advisory, because the code is only in 0.16.9, off by default) and the 0.16.10 walk's entry (SM1420, SM1421, SM1423, SM1424, SM1425, SM1426, SM1427, 17a681a71), which fires no trigger. Seventeen entries cover 0.16.9, an edge release. Sixteen, dated 8 and 9 Nov 2026, were written on their branches and confirmed by the release manager on 10 Nov 2026 at the 0.16.9 compliance walk (ruling 225), against the stack's tip 63e8f1970. Seven assess a fired trigger, each confirmed contained: SM1369 X4 (an extension declares an identity provider; the Odoo site sign-in is the first) and SM1351 (an outside OpenID Connect provider, whose groups may grant, ruling 186's first use) fire the sign-in-method trigger, SM1351 with new-external-interface; SM1352 passkeys fire new-authentication-method and new-external-interface; the CryptX entry (SM1352, SM1363) fires new-dependency-with-authentication-logic; SM1363 web push and webhook fire new-external-interface; SM1363's phone number and SM1364 (a table reads its rows from another system's API, ruling 190) fire new-processing-of-restricted-data. SM1364 stays as ruling 190 has it. Nine fire none: SM1369 X5 and X6 (X6 records that the `/manager/` path is within the existing manager surface), SM297 (identity is a value), SM1357 (the page set for `lazysite check`), SM1416 (the pool runs the site's own engine), both SM1417 entries (a damaged store refuses), SM1361/X7 (the shared engine's loader rule) and T-115 (a beside site's store modes). No early third-party review: the OIDC grant mapping and the passkey paths are named in the scope of the engagement ADR 0007 already requires (the first third-party penetration test row below). One was written at the walk and confirmed by the release manager on 10 Nov 2026 (ruling 226): SM1418, SM1407 (T-112), SM1404 (T-113), SM1398 (T-114), the container's tooling and the restack's wording, no trigger fired (n794's XMPP change is in it, ruling 225). Fourteen entries cover 0.16.8, an edge release. Thirteen, dated 7 Nov 2026, were written on their branches and confirmed by the release manager on 8 Nov 2026 at the 0.16.8 compliance walk (ruling 177), against the stack's tip d092a5b8c. Three assess a fired trigger, each confirmed contained: SM1414 (`write_content` opens the manager API's cookie door to an account without `ui`, for six content actions, where a rule's write list names it) fires new-external-interface; SM1355 (the row history keeps rows' earlier values for the table's period, 90 days by default, rulings 170 and 175; contained by the daily `row-history-prune` job and the write path's prune) and SM1396 (the offline kit keeps a person's reads and queued changes in their browser; contained by the purge at sign-out keyed to the login) fire new-processing-of-restricted-data, which ruling 177 names new processing of personal data. Ten fire none: SM1369 X2 (an extension's declared capabilities and actions, the trigger X1 recorded exercised by its first callers), X3 (page sources and delivery handler types; the Odoo type stays `manage_connectors`', ruling 178) and X5's asset part, SM1395 (an anonymous public write binding keeps no join; a hardening), SM1413 (a notify handler names a group), SM1412 (`owner_contact` retired; a hardening), SM1354 (a page's copy, and `publish_copies`), SM1356 (schedules, dated rows and a daemon job that deletes rows, its removals audited and not in the row history, ruling 179), SM1357 (JSON-LD, every public page in the sitemap and `llms.txt`) and SM1407 (two roles reach an older site). One was written at the walk and confirmed by the release manager on 8 Nov 2026 (ruling 182): SM1400, SM1402, SM1404, SM1405, SM1409, SM1411 (a backup snapshot is not a layout, a conf for no form refused, a listing's pickers, a notice mail's shape, a mixed pair not mirrored, the editor's lock), no trigger fired. Eight entries cover 0.16.7, an edge release, dated 7 Nov 2026. Seven were written on their branches and walked at the 0.16.7 compliance walk against the stack's tip 58d5d6e26, each gaining a "walked" note: SM1383 (the session cookie as a format an outside process on the same host verifies read-only, holding the key) fires new-external-interface in a narrow form and is confirmed contained by the release manager on 7 Nov 2026 (ruling 146); SM1381 (a stale Odoo site session renewed through a tokenless GET on the Odoo endpoint) fires new-external-interface and is that trigger's assessment, confirmed contained by the release manager on 7 Nov 2026 (ruling 150); SM1369 X7 part one (Odoo's modules in the extension's payload lib, the same code from one place), SM1390 (another signed value is not a session, a future timestamp is refused; hardening by ruling 147), SM1387 (a group deleted on every door once nothing uses it, audited; its new action on an existing door is no new interface, ruling 151), SM1393 (the agent roles and bundles reach a site the mark never reached) and SM1392 (the editor and MCP name `manage_forms` for a form's own conf) fire none, each confirmed by the release manager on 7 Nov 2026 (ruling 149; SM1392 also ruling 152). One was written at the walk and confirmed by the release manager on 7 Nov 2026 (ruling 149): SM1385, SM1389, SM1391 (a theme deleted by its path, the check's walk past the history repository, a schedule entry under the floor), no trigger fired. No change in 0.16.7 processes restricted data in a new way. Twelve entries cover 0.16.6, an edge release, dated 6 Nov 2026. Ten were written on their branches and confirmed by the release manager on 6 Nov 2026 (rulings 134, 140), and each was walked at the 0.16.6 compliance walk against the stack's tip 41c47b006, gaining a "walked" note: SM1369 X0, X1 (an extension's own code loaded into a core process, with no caller yet) fires new-external-interface and SM1362 (a form's owner mailed a `notify: full` submission; an opt-in acknowledgement) fires new-processing-of-restricted-data, each that trigger's assessment, confirmed contained; SM1366, SM1370-SM1374, SM1377 and SM1379 fire none. One was written at the walk and confirmed by the release manager on 6 Nov 2026 (ruling 142): SM1375 and SM1378 (the 403 page's group list, whose names the stash did not escape, found at the walk; a layout's engine requirement), no trigger fired. One records ruling 141, confirmed by the release manager on 6 Nov 2026: the 403 page escapes the groups it names (a hardening), no trigger fired. Six entries cover 0.16.5, an edge release, confirmed by the release manager on 6 Nov 2026 (ruling 127). Of those, four dated 5 Nov 2026 were written on their branches and walked on 6 Nov 2026: SM1324 (a protected folder's history, opt-in, a second copy of protected content) and SM1325 (the AI read audit, opt-in, account and path and address in a log) each fire new-processing-of-restricted-data, found at the walk, as SM286 and SM1219 fired it, and are that trigger's assessment; SM1332-SM1334 (domain grants add, the primary grantable, a group pin) and SM1343-SM1345 (address lists become address profiles, allow or deny chosen where used; the upgrade converts the store and the template calls) fire none. Two dated 6 Nov 2026 were written at the walk: SM1335, SM1336, SM1339 (a theme's served copies follow its source on every write and are refused to every writer; the mirror refuses a link or a server-run file) and the rest of 0.16.5 that moves a control (SM1321 the bad-URL blocker's exemptions, SM1322 /login's session check, SM1327, SM1328, SM1340, SM1341 the public setup page, SM1347, SM1365); no trigger fired. One entry dated 6 Nov 2026 covers 0.16.4, an edge release that is SM1142 alone (the rename to extensions): the one-time upgrade step `extensions-rename` moves files and links in every site's tree and converts which extensions are on, the login rate limiter among them, and the wire's old spelling is refused and its response keys renamed for an external reader (ruling 95); no trigger fired; a developer-agent draft until the release manager confirms. Two entries cover 0.16.3, an edge release. The entry dated 4 Nov 2026 (SM1308, SM1309, SM1311-SM1313): a confined grant answered from the whole docroot when it named no path, and a member of a protected area could widen its rule on a subfolder; no trigger fired, each recorded as a bypass of a boundary the register names (confinement; the access rule); drafted by the developer agent and accepted by the release manager on 5 Nov 2026 (ruling 65). The entry dated 5 Nov 2026 records the rest of 0.16.3 that moves a control (access, the served tree with the engine's /docs manual, MCP install_theme reaching the theme upload with a token, the settle_odoo_writes capability, the deploy hook's --force-security); no trigger fired; drafted by the developer agent and accepted by the release manager on 5 Nov 2026 (ruling 93). Ruling 94 (5 Nov 2026): no exploitation of SM1308 or SM1309 is known, so no CRA Article 14 notification and no advisory; the 0.16.3 release notes carry it. One entry dated 23 Oct 2026 covers 0.16.2, a security release: a theme archive's symbolic link reached the served asset mirror and could serve the session-signing secret (SM1303, with SM1304's planted-link warning); no trigger fired, recorded as a bypass of boundary 6 as SM1213 and SM1257 were; drafted by the developer agent and accepted by the release manager on 5 Nov 2026 (ruling 65). SM1305 (release.sh --security-critical) and SM1307 (the Hestia updater's --force-security) are release and rollout tooling and touch no boundary. Five entries dated 23 Oct 2026 cover 0.16.1: the warm-forked Odoo endpoint (SM1226, a new local interface), a page's stem rule on move and delete (SM1257, SM1242, SM1258), the Odoo extension's options and OOM 0.42 (SM1223-SM1225, SM1244, SM1247, SM1248, SM1261), the Docker Compose package (SM1233), and the access, rollout and channel changes with no trigger; each drafted by the developer agent and accepted by the release manager on 23 Oct 2026. SM1219 and SM1118, accepted on 21 Oct 2026, are recorded as landed in 0.16.1. Previous 20-21 Oct 2026 for 0.15.3 to 0.16.0, confirmed by the release manager on 21 Oct 2026
Threat model current with the architecture | at each release | 0.17.0 | met | for 0.17.0, docs/SECURITY.md has one STRIDE row added at the 0.17.0 walk (a full backup taken in a detached worker that outlives its request, SM1446, with the one-at-a-time check and its residual), drafted by the developer agent and confirmed by the release manager on 12 Nov 2026 (ruling 251), and trust boundaries 11 and 15, the assets line and the not-yet-code line need no change (no loader caller, store, sign-in method or interface was added: the worker is the manager API's own code continued); docs/architecture/security.md (a 0.17.0 section: the unfinished backup, the detached full backup, the blocker's list, the user a refusal names), added 12 Nov 2026; no new trust boundary; for 0.16.12, docs/SECURITY.md has one STRIDE row added at the 0.16.12 walk (a full backup restored by `install.pl --restore-full`, SM1439), drafted by the developer agent and confirmed by the release manager on 11 Nov 2026 (ruling 243), and trust boundaries 11 and 15, the assets line and the not-yet-code line need no change (no loader caller, store, sign-in method or interface was added; a full backup still carries the auth secrets and is restored only by a system user); docs/architecture/security.md (a 0.16.12 section: the full restore, the refusals and the check), added 11 Nov 2026; no new trust boundary; for 0.16.11, docs/SECURITY.md has one STRIDE row added at the 0.16.11 walk (a rule, group limit or page naming an address profile the store lacks, and a profile deleted while a rule names it, SM1435), confirmed by the release manager on 11 Nov 2026 (ruling 237), and trust boundary 11 (the address rule) restated with the same sentence; trust boundary 15, the assets line and the not-yet-code line need no change (no loader caller, store or sign-in method was added); docs/architecture/security.md (a 0.16.11 section: address profiles chosen from those that exist, the stale marker cleared), added 11 Nov 2026; no new trust boundary; for 0.16.10, docs/SECURITY.md has one STRIDE row added at the 0.16.10 walk (the root-run Hestia deploy, SM1427), confirmed by the release manager on 2026-11-10 (ruling 233), and trust boundary 15, the assets line and the not-yet-code line need no change (no loader caller, store or sign-in method was added); docs/architecture/security.md (a 0.16.10 section: the map entry, the signed-in marker, the Hestia deploy and the fleet's sites, the declared modes), added 10 Nov 2026; no new trust boundary; for 0.16.9, docs/SECURITY.md trust boundary 15 restated (the loader's callers added by X4 to X7: an extension's identity provider, which the `oidc` extension is the second of; its endpoint behind core's request kit; the services the supervisor runs; the checks `lazysite check` runs; the manager page it ships; the shared engine's rule), the assets line restated (passkey public keys, web-push endpoints and the phone number, the site's push key, an outside provider's client secret in the secrets store, the rows a sourced table takes from an API), the "not yet code" line corrected for OIDC, and nine STRIDE rows (an extension's identity provider; an outside OIDC provider's answer; its group claim reaching a capability group; a passkey sign-in; a web-push endpoint and a notice's content; the phone number; an identity written into the data endpoint's environment; code in a site's extensions directory on the shared engine; a sourced table's writes), added 10 Nov 2026 at the 0.16.9 walk, confirmed by the release manager on 10 Nov 2026 (ruling 226), beside the entries they restate (ruling 225); docs/architecture/security.md (a 0.16.9 section: identity providers, OIDC, the endpoint kit and secrets, passkeys, web push, webhook and the phone, API-backed tables, identity as a value, the damaged-store refusals, the shared container engine), added 10 Nov 2026; no new trust boundary; for 0.16.8, docs/SECURITY.md trust boundary 15 restated (the loader's three callers from 0.16.8: an extension's declared actions on the manager API and MCP, SM1369 X2; its page sources and handler types, X3; its asset files, components and template variables, X5's asset part, with the offline kit, SM1396, the second consumer), the assets line restated (rows' earlier values in the row history, SM1355; a person's kept reads and queued changes in their browser, SM1396) and three STRIDE rows (the member content door, SM1414; rows' earlier values kept, SM1355; the kit's storage on a shared browser, SM1396), added 8 Nov 2026 at the 0.16.8 walk, confirmed by the release manager on 8 Nov 2026 (ruling 182), beside the STRIDE row X3 wrote on its branch (a declared page source or handler type), confirmed with the X3 entry on 8 Nov 2026 (ruling 177); docs/architecture/security.md (a 0.16.8 section: the declared actions and capabilities, page sources and handler types, the asset hooks, the offline kit, notices through notify handlers and `owner_contact` retired, a page's copy and `publish_copies`, row history and undo, schedules, JSON-LD and the listings, the member content door, the smaller changes), added 8 Nov 2026; no new trust boundary; for 0.16.7, docs/SECURITY.md trust boundary 12 restated (the Odoo extension's modules in its payload lib, SM1369 X7; the renewal step, SM1381), the assets line restated (a session cookie as a format an outside process may verify, SM1383) and four STRIDE rows (an Odoo module found in the wrong place, SM1369 X7; the renewal step reached with no token, SM1381; one key signing three payloads, SM1383 and SM1390; a group deleted while something names it, SM1387), added 7 Nov 2026 at the 0.16.7 walk, confirmed by the release manager on 7 Nov 2026 (ruling 149); docs/architecture/security.md (the payload lib and the renewal step, the cookie contract and the three verifier rules, group deletion and the reference walk, the roles on a pre-mark site, a form's conf in the editor and over MCP, a theme deleted by path, the check's prune, the schedule floor), added 7 Nov 2026; no new trust boundary; for 0.16.6, docs/SECURITY.md trust boundary 15 (an extension's code in a core process, SM1369) and three STRIDE rows (the hook loader, SM1369; the primary's content reaching the other domains' folders, closed by SM1372; the site used as a mailer by an acknowledgement, SM1362), added 6 Nov 2026 at the 0.16.6 walk, confirmed by the release manager on 6 Nov 2026 (ruling 142); docs/architecture/security.md (the hook loader, agent roles and a form's config, a token following its grant, the primary's reach, the owner mail and acknowledgement, the data endpoint's refusal, the extension settings read, Odoo's refusals and the record's actor), added 6 Nov 2026; for 0.16.5, docs/SECURITY.md two STRIDE rows (a theme's source re-mirrored on every write, SM1335; the bad-URL blocker's loopback exemption behind an uncovered front end, SM1321), added 6 Nov 2026, and trust boundary 11 restated for address profiles (SM1343), added 5 Nov 2026; docs/architecture/security.md (address profiles and domain grants, added 5 Nov 2026; a protected folder's history and the read audit, a theme's served copies, the bad-URL blocker's exemptions, the sign-in page's session check, the ACL 403 page and the public setup page, added 6 Nov 2026); no new trust boundary; for 0.16.4, a STRIDE row for an extension list left under the old spelling (SM1142) and docs/architecture/security.md (extensions on disk and the step that moves a site to them), added 6 Nov 2026; no new trust boundary; for 0.16.3, two STRIDE rows (a confined grant's walks, SM1308; a rule inside another, SM1309), added 4 Nov 2026, and docs/architecture/security.md (a confined grant's walks and a rule inside another; the engine's /docs manual and pages beside a moved engine tree; the zip upload over MCP; a write whose answer never came; the shared sign-in return), added 5 Nov 2026; no new trust boundary; for 0.16.2, a STRIDE row for the theme archive's link (SM1303, SM1304) and docs/architecture/security.md (the zip upload and the served asset mirror), added 23 Oct 2026; for 0.16.1, trust boundary 14 (the warm-fork parent) and two STRIDE rows (the stem rule, the parent), and docs/architecture/security.md (the warm-forked endpoint, Odoo idempotency, sizes and downloads, the stem rule, MCP remove_permissions, bundle adoption, Permissions-Policy, the rate counter, the Docker package), added 23 Oct 2026; boundaries 9-13 20 Oct 2026
SBOM regenerated and shipped | at each release | every release | met | strict gate, tools/manifest-to-sbom.pl --strict - run 12 Nov 2026 on the 0.17.0 stable tree (the branch tip f2596d3ff, staged with the 0.17.0 release material, manifest of 426 files, channel stable, not security-critical): exit 0, 495 components, none more than at 0.16.12 (SM1444, SM1446 and SM1447 add no shipped file and no sbom-deps.json entry: the changes are ten tests added and edits to existing files). At 0.16.12: strict gate, run 11 Nov 2026 on the 0.16.12 beta tree (the branch tip 9a578d947 with the walk, staged with the 0.16.12 release material, manifest of 426 files, channel beta): exit 0, 495 components, none more than at 0.16.11 (no shipped file and no sbom-deps.json entry added: five tests added, and edits to existing files). At 0.16.11: strict gate - run 11 Nov 2026 on the 0.16.11 beta tree (the line's tip 17c1edb13 with the walk, staged with the 0.16.11 release material, manifest of 426 files, channel beta): exit 0, 495 components, none more than at 0.16.10 (no shipped file and no sbom-deps.json entry added: the change is twelve tests added, one removed, and edits to existing files). At 0.16.10: strict gate - run 10 Nov 2026 on the 0.16.10 tree (the line's tip 17a681a71): exit 0, 495 components, none more than at 0.16.9 (no shipped file and no sbom-deps.json entry added: `git`, which the image and the package's Recommends now install, was declared in sbom-deps.json for content history, SM085). At 0.16.9: strict gate - run 10 Nov 2026 on the 0.16.9 tree (the stack's tip 63e8f1970; the 0.16.9 release material is written by the release commit): exit 0, 495 components, the nineteen more being fifteen shipped files, `Lazysite::Crypto`, `Lazysite::Endpoint`, `Lazysite::Secrets`, `Lazysite::WebPush` and `Lazysite::Auth::Passkey` (lib), `Lazysite::Odoo::Check` (the Odoo extension's own checks), the `oidc` extension's descriptor `extensions/oidc.pl`, its module `Lazysite::Ext::OIDC` and its endpoint `lazysite-oidc.pl`, the three account components `account-passkeys`, `account-phone` and `account-push`, Odoo's panel page `unknown-writes.md`, and the container's `lazysite-sites` and `front.conf.example`; and four entries sbom-deps.json gains, the first since 0.16.2: `Crypt::PK::ECC`, `Crypt::PK::RSA` and `Crypt::PK::Ed25519` (CryptX, lazy-loaded by passkeys and web push; Debian `libcryptx-perl`, a Recommends) and `Template::Filters` (a module of Template Toolkit, already declared, which the page-body filter guard reads). At 0.16.8: strict gate - run 8 Nov 2026 on the 0.16.8 tree (the 0.16.8 stack's tip d092a5b8c with the 0.16.8 release material written in, manifest not security-critical): exit 0, 476 components, the thirteen more being `lib/Lazysite/Extensions/Declared.pm` (SM1369 X2), Odoo's `Lazysite/Odoo/Actions.pm` and `Lazysite/Odoo/Hooks.pm` in `extensions/odoo/lib/` (X2, X3), the processor part `lazysite-processor/extensions.pm` (X5's asset part), the offline kit's descriptor `extensions/app-offline.pl`, its script `kit.js` and its module `Lazysite::Ext::AppOffline` (SM1396), `Lazysite::PageCopy` and `Lazysite::Manager::PageCopy` (SM1354), `Lazysite::Data::RowHistory` and `Lazysite::Data::Wizard` (SM1355), `Lazysite::Data::Schedule` (SM1356) and `Lazysite::Data::StructuredData` (SM1357); the Odoo helper and the sign-in component are renamed into `extensions/odoo/` and counted as before; sbom-deps.json is unchanged since 0.16.2. At 0.16.7: 463 components, the one more being the group-reference walk `lib/Lazysite/Auth/GroupRefs.pm` (SM1387), whose `use` lines are core modules (File::Find, JSON::PP) and lazysite's own; Odoo's fifteen modules are renamed into `extensions/odoo/lib/` (SM1369 X7) and counted as before; sbom-deps.json is unchanged since 0.16.2. At 0.16.6: 462 components, the one more being the hook loader `lib/Lazysite/Extensions/Hooks.pm` (SM1369), whose `use` lines are core modules (Cwd, JSON::PP, Time::HiRes) already declared. At 0.16.5: 461 components, the two more being `lib/Lazysite/ProtectedHistory.pm` (SM1324) and `Lazysite/Odoo/Name.pm` (SM1328; in Odoo's payload lib, `extensions/odoo/lib/`, since SM1369 X7), with the address modules renamed (`Auth::AddressProfiles`, `Manager::AddressProfiles`; SM1343); sbom-deps.json is unchanged since 0.16.2
Annex VII technical file kept current | continuous; complete before CE marking | 2027-12-11 | STARTED | docs/compliance/TECHNICAL-FILE.md - index form, walked to 0.17.0 on 12 Nov 2026 (0.16.12 and 0.16.11 on 11 Nov 2026, 0.16.10 on 10 Nov 2026)
Signed releases (Sigstore/cosign) | before CE marking; cannot be applied retroactively | 2027-12-11 | OPEN | docs/POLICY.md - every unsigned release is permanently unattestable; stays for the certified release (release manager, 20 Oct 2026)
OpenChain 5230 + 18974 written policies | before CE marking | 2027-12-11 | OPEN | docs/POLICY.md
Bench baseline re-captured | at each stable cut | next stable | OPEN | dist/config/bench-baseline.json - captured 2026-09-30; re-capture with `perl tools/bench.pl --baseline` on a quiet host (stable-gate plan P8). Ruling 250 (12 Nov 2026): the row stays OPEN through the 0.17.0 cut; the baseline is re-captured after 0.17.0, at the release manager's chosen moment, before the certified cut it blocks. The 0.17.0 walk did not re-capture it (this host is shared and not quiet) and the check reports it advisory on stable; SM1447's tidy moved one statement count in the baseline, which is not a re-capture
Restore rehearsal recorded | at least once per stable cycle | next stable | met | docs/RELIABILITY.md - the 11 Nov 2026 row stands as the honest record of the restore gap (a scratch rehearsal on the shipped 0.16.11 tarball, SM1438; 91 ms restore, content, auth store and conf intact, no cgi-bin entry points and no serving group; rulings 237, 238, 241); SM1439 (ruling 239) closes the gap in 0.16.12, and the rehearsal was rerun on 11 Nov 2026 on the shipped 0.16.12 tarball by the developer on this host (SM1443; one `install.pl --restore-full` command, 743 ms, content, auth store, conf, the three cgi-bin entry points and the 0.16.12 install state present, `lazysite check --group` 0 failures; the rerun row in docs/RELIABILITY.md), confirmed by the release manager on 12 Nov 2026 (ruling 247) as the 0.17.0 stable cycle's rehearsal, so this row is closed (rulings 241, 242); the row before the 0.16.11 one was 2026-08-26, before the last stable cut (0.16.0, 2026-10-22); the rehearsal on a scratch copy of a real site at the candidate version is otherwise the operator's (stable-gate plan P6)
```

# Operate-side obligations

Discharged by whoever **runs** a lazysite instance. On this project that is
sometimes the same people and sometimes not, and the lifecycles differ: a build
obligation is met by cutting a release, an operate obligation is met by a
person doing something on a running service, on a calendar that has nothing to
do with the release cadence.

An operator records their own instance's state in their filled-in copy of
`docs/compliance/OPERATIONS-TEMPLATE.md`; the rows below are the obligations
that copy must account for.

```datatable
columns: Obligation | Due | State | Source
widths: 4.6cm | 3cm | 1.8cm | X
bold: 1
tone: medium
text: 4
---
CRA Article 14 reporting path rehearsed before the clock is live | 2026-09-11 | OPEN | toolchain OPERATIONS-GUIDE.md #report-path-rehearsal; named triage owner + deputy, platform access verified, 24h/72h/14d cascade walked as a tabletop
Named security triage owner and deputy | 2026-09-11 | OPEN | as above - the DoC names a function, not an individual
First third-party penetration test | 2026-12-31, or first GA marketing, whichever first | OPEN | docs/adr/0007-pentest-deferral.md - after expiry an absent report is a refusal condition, not a deferral. Ruling 249 (12 Nov 2026): the 0.17.0 stable is not the beginning of general-availability marketing, so the waiver is not shortened and the engagement stays due by the date in this row. Its scope names, from the 0.16.9 walk (ruling 225, 10 Nov 2026; no early review): the OIDC grant mapping, a provider's group claim reaching a capability group (SM1351, ruling 186's first use), and the passkey paths (SM1352: the two unauthenticated auth-wrapper actions, enrolment, `passkey_only`)
Significant-change assessment on each fired trigger | continuous | confirmed to 0.16.12 | docs/adr/0007-pentest-deferral.md - the register is what keeps the waiver valid; no 0.17.0 entry assesses a fired trigger (SM1444 is a hardening of a default list, SM1446's detached worker is the request's own code and identity continued, SM1447 is messages and check text, and the walk's entry records SM1442, SM1443 and SM1445), all four drafted on 12 Nov 2026 and confirmed by the release manager the same day (ruling 251); no 0.16.12 entry assesses a fired trigger (SM1439's restore lays code and modes from the release and the data from the tarball, SM1440 is wording and one tightened write, and the walk's entry records SM1438), all three drafted on 11 Nov 2026 and confirmed by the release manager the same day (ruling 243); no 0.16.11 entry assesses a fired trigger (SM1435 is a hardening of address rules, and the walk's entry, SM1430's display-only marker and SM1437's check output, fires none), both drafted on 11 Nov 2026 and confirmed by the release manager the same day (ruling 237); no 0.16.10 entry assesses a fired trigger (SM1422 restores a control 0.16.9 shipped, and the walk's entry fires none), and both are confirmed by the release manager on 2026-11-10 (ruling 233) (ruling 229 rules how SM1422 ships); of the sixteen 8 and 9 Nov 2026 entries for 0.16.9, confirmed on 10 Nov 2026 (ruling 225), seven assess a fired trigger, each confirmed contained, so the waiver stands: SM1369 X4 (sign-in method: an extension declares an identity provider), SM1351 (sign-in method and new-external-interface: an outside OpenID Connect provider, whose groups may grant, ruling 186's widening exercised for the first time; audited at every sign-in), SM1352 passkeys (new-authentication-method and new-external-interface), the CryptX entry (new-dependency-with-authentication-logic), SM1363 web push and webhook (new-external-interface) and SM1363's phone number and SM1364 (new-processing-of-restricted-data; SM1364 contained by the connector's callers, the table's read rules and the read-only mapping, ruling 190); the other nine fire none; no early third-party review is proposed, and the OIDC grant mapping and the passkey paths are named in the scope of the engagement ADR 0007 already requires (the first third-party penetration test row); the walk's entry (SM1418, SM1407, SM1404, SM1398, the container's tooling, the restack's wording) fires none and was confirmed on 10 Nov 2026 (ruling 226); of the thirteen 7 Nov 2026 entries for 0.16.8, confirmed on 8 Nov 2026 (ruling 177), three assess a fired trigger, each confirmed contained, so the waiver stands: SM1414 (new-external-interface: the member content door) and SM1355 and SM1396 (new-processing-of-restricted-data: rows' earlier values in the row history, contained by the daily `row-history-prune` job and the write path's prune; a person's data in their browser, contained by the purge at sign-out keyed to the login); the other ten fire none, X2 exercising the trigger X1 recorded (ruling 134); the walk's entry (SM1400, SM1402, SM1404, SM1405, SM1409, SM1411) fires none and was confirmed on 8 Nov 2026 (ruling 182), with boundary 15, the assets line and the three STRIDE rows; of the eight 7 Nov 2026 entries for 0.16.7, two assess a fired trigger, new-external-interface: SM1383 (an outside reader of the session cookie, holding the key) was confirmed contained on 7 Nov 2026 (ruling 146), and SM1381 (the renewal step, a tokenless GET on the Odoo endpoint) was confirmed contained on 7 Nov 2026 (ruling 150), so the waiver stands; SM1387's new action on an existing door is no new interface (ruling 151); the other five fire none and were confirmed on 7 Nov 2026 (ruling 149), the walk's entry, boundary 12 and the four STRIDE rows with them; the 20 Oct 2026 entries were confirmed by the release manager on 21 Oct 2026; of the 23 Oct 2026 entries, the five for 0.16.1 were confirmed on 23 Oct 2026 and the SM1303 entry for 0.16.2 on 5 Nov 2026; the 4 Nov 2026 entry for 0.16.3 (SM1308, SM1309) was confirmed on 5 Nov 2026, and the 5 Nov 2026 entry for the rest of 0.16.3 on 5 Nov 2026 (ruling 93); the 6 Nov 2026 entry for 0.16.4 (SM1142) and the six entries for 0.16.5 (5 and 6 Nov 2026) were confirmed on 6 Nov 2026 (ruling 127), two of them (SM1324, SM1325) the assessments of a fired trigger, new-processing-of-restricted-data, confirmed contained (ruling 125); of the twelve 6 Nov 2026 entries for 0.16.6, the ten written on their branches were confirmed on 6 Nov 2026 (rulings 134, 140), two of them the assessments of a fired trigger: SM1369 (new-external-interface, ruling 134) and SM1362 (new-processing-of-restricted-data, ruling 140), both contained; the one written at the 0.16.6 walk (SM1375, SM1378) and the one for ruling 141 fire none and were confirmed on 6 Nov 2026 (rulings 141, 142)
Vulnerability handling in operation (intake, triage, advisory, VEX) | continuous | PARTIAL | SECURITY.md declares CVD intake; the dated remediation register against the ADR 0007 SLAs stays for the certified release (release manager, 20 Oct 2026). 0.16.2 is cut as a security release for SM1303 (ruling 41 as revised, 41b): its manifest declares security_critical (SM1305) and it is pushed with `lazysite upgrade --all --force-security`, or on a Hestia host the updater's `--force-security` (SM1307); the fix is in the register, its dated remediation record with the rest at certified. 0.16.3 carries the fixes for SM1308 and SM1309 as an edge release, not security-critical, so each site takes them by its own update channel; from 0.16.3 a security release is cut on stable (SM1314) and the deploy hook passes `--force-security` itself when the manifest declares it (SM1315). 0.16.4, SM1142 alone, is an edge release, not security-critical, and fixes no vulnerability. 0.16.5 is an edge release, not security-critical, and fixes no vulnerability: its fixes are of availability (SM1321's blocker refusing every visitor behind a front proxy), of a lost update (SM1327) and of what a page says (SM1322, SM1365). 0.16.6 is an edge release, not security-critical, and fixes no vulnerability, judged at the 0.16.6 walk and ruled so by the release manager on 6 Nov 2026 (ruling 142): SM1373 (an extension's settings read answered the rest of `lazysite.conf`) narrows what a cookie session holding `manage_config`, an account trusted with the site's settings, is shown, where no shipped extension keeps a credential in that file; SM1372 closes a reach recorded as residual risk at 0.16.5 (ruling 126); SM1374 and SM1377 narrow what a visitor or a script is told. SM1375's unescaped group names on the 403 page, found at the walk and written only by accounts that can already put markup in a page, are escaped in 0.16.6 as a hardening (ruling 141). 0.16.7 is an edge release, not security-critical, and fixes no vulnerability, judged at the 0.16.7 walk for the release manager to confirm: SM1390 (a preview cookie read as a session for an account named `v1`, a session as a preview, a future timestamp, found while writing SM1383's contract) is a hardening by ruling 147 - the preview cookie is minted only for a signed-in manager, no site is known to hold such an account, and a holder of the key can mint at will; SM1387 closes a reach the cookie Groups page had (a group deleted while rules named it); SM1381 fixes what a stale session is told; SM1389 fixes a false NOT SERVICEABLE. 0.16.8 is an edge release, not security-critical, and fixes no vulnerability, judged at the 0.16.8 walk and ruled so by the release manager on 8 Nov 2026 (ruling 182): SM1395 and SM1412 are hardenings (less processing of personal data); SM1404 and SM1405 narrow what an MCP listing and a notice mail carry; SM1402 refuses a conf for a form nobody made; SM1411 restores the editor's lock, which the API's refusal of a mutating GET had kept from every editor; SM1414 opens a door, assessed under its trigger, rather than closing one. 0.16.9 is an edge release, not security-critical (ruling 226): it fixes no known vulnerability, and the entries record hardenings. SM1417 makes eight access decisions and thirteen more refuse on a damaged store, where a broken acls.json, groups file, auth lock or rate counter was read as empty or as permissive (items 1-8 and 9-21 of the ruling 206 survey); item 1 stopped an ordinary rule write replacing a whole damaged rule set with the one rule written; T-115 closes world bits on a beside site's seeds and form configs, which was real for `forms/` alone, and SM297 removes a header channel on the data endpoint. 0.16.10 is an edge release, not security-critical, and carries no advisory (ruling 229): SM1422 closes a flaw in a control that only 0.16.9 (edge) shipped, found proving SM1351 against a local authentik - a `manage_config` holder could add an OIDC map entry pointing a provider group at a capability group the operator had already mapped - in the `oidc` extension, which is off by default and in no stable release, fixed before the beta; the rest of 0.16.10 fixes no vulnerability. 0.16.11 is the beta (ruling 236), cut with `--beta` from 0.16.10 plus SM1430, SM1435 and SM1437, and it is not security-critical and carries no advisory: no change in it fixes a known vulnerability. SM1435 is a hardening (a deny rule naming a missing address profile excluded nobody, and now cannot be saved), SM1430 clears a display-only marker, and neither is a known vulnerability. 0.17.0 is the stable (rulings 227, 242), cut with `--final` as the promotion of the 0.16.12 beta with only the fixes of the 0.16.11 and 0.16.12 field passes, and it is not security-critical and carries no advisory: no change since 0.16.12 fixes a known vulnerability (SM1444 is a hardening of a default list, SM1446 stops an unfinished backup being listed or restored, SM1447 is messages and check text); to a stable site coming from 0.16.0 it brings the fixes of 0.16.2 (SM1303, cut security-critical and already pushed to every site by `--force-security`) and 0.16.3 (SM1308, SM1309, ruling 94: no exploitation known, no advisory), and whether the release manager wants `--security-critical` for the promotion is a question the walk raises and answers no. 0.16.12 is the second beta (ruling 242), cut with `--beta` from 0.16.11 plus SM1438, SM1439 and SM1440, and it is not security-critical and carries no advisory: no change in it fixes a known vulnerability (SM1439 repairs a restore that left a site unable to serve; SM1440 is wording and one tightened write); the release manager confirmed that judgement on 11 Nov 2026 (ruling 237). It is the release the 0.17.0 stable promotion is drawn from (rulings 227, 228), and the feature freeze on main starts at this cut
People who sign in told that the visitor log records their account | on running 0.16.1 or later with the visitor log on | OPEN | docs/OPERATOR.md "The visitor log names signed-in accounts" (SM1219) - account names are personal data; the site's privacy notice says so, or the log is turned off or its retention shortened. The engine publishes no notice (SM1010)
A symbolic link planted in the served asset mirror removed, and the session secret rotated | on upgrading to 0.16.2, where `lazysite check` names each link | OPEN | docs/OPERATOR.md "A symbolic link in the asset mirror is left for you" (SM1304) - before 0.16.2 a theme upload could plant one, serving what it points at, `lazysite/auth/.secret` included; the engine warns and never deletes, so the operator removes the link and rotates the secret (the manager's Sessions page, "Log out all users")
An access rule wider than its enclosing rule, written before 0.16.3, reviewed | on upgrading to 0.16.3, where `lazysite check` names each | OPEN | docs/OPERATOR.md "A rule wider than the rule around it is left for you" (SM1313, ruling 61) - before 0.16.3 any account that could write inside a protected area could open a subfolder to people the area's rule does not admit; 0.16.3 refuses that (SM1309) and keeps the rules stored, so the operator keeps or removes each one the check names; the engine changes none
References the upgrade to extensions/ cannot see, updated | on upgrading to 0.16.4 | OPEN | UPGRADE.md, the SM1142 entry (ruling 95) - the upgrade converts the site's own tree, lazysite.conf and stored start pages; the rest is the operator's: a crontab or pipe running the old directory's stats.pl or form-smtp.pl, a link made by hand outside the site's cgi-bin, a bookmark to the old manager pages, a script on the old action spelling or reading the old response keys, and an audit filter on the old action names. `lazysite check` names an old-spelling line in lazysite.conf and an old directory left beside the docroot
Each address rule whose slot differs from its old list's kind, and each old template call, reviewed | on upgrading to 0.16.5, where `lazysite check` names each | OPEN | UPGRADE.md, the SM1343-SM1345 entry (rulings 56-58, 105-108) - the upgrade converts the store and renames the template calls; a rule naming a list in the other slot, possible only by a hand edit, refused every visitor before and now applies in its slot, so it can widen; a call written back under an old name is false. The engine changes no rule, so the operator keeps or corrects each one the check names
A protected folder's history and the AI read audit, where a site turns them on, accounted for | on turning on `history: true` or `audit_reads: on` (0.16.5) | OPEN | docs/SECURITY.md, the SM1324 and SM1325 entries - the history is a second copy of protected content, in the site's backups, kept until the operator purges it (`lazysite acl purge-history`); the read audit records which agent account read which path, when and from where, kept and rotated as the trail is. The site's records of what it holds, and the notice to whoever runs the agents, are the operator's (SM1010 principle, as SM1219's row)
An account that worked on a secondary domain's folder through the primary, granted that domain | on upgrading to 0.16.6 | OPEN | UPGRADE.md, the SM1372 entry (rulings 126, 137) - the primary's content leaves out the other domains' content roots, so a non-operator account (a manager holding `manage_users` outside the operator group, an agent's token, a WebDAV login) that edited `sites/<host>/` with no grant on that domain is refused and no longer sees it listed; the operator names its group in that domain's `allowed_groups`, and on the primary's row too to keep the primary
Who holds `manage_forms`, and which agent roles a site keeps | on upgrading to 0.16.6, and on a site the `seeded` mark never reached on upgrading to 0.16.7 | OPEN | UPGRADE.md, the SM1371 entry (ruling 122) and the SM1393 and SM1392 entries - `manage_forms` now reads and writes a form's own `lazysite/forms/<name>.conf` over MCP and the manager's editor, as over WebDAV; from 0.16.7 the editor page opens it and MCP `read_file`/`write_file` ask `manage_forms` for it (SM1392); four agent roles (`content-agent`, `data-agent`, `forms-reader`, `analytics-agent`) appear with no members, and an operator deletes any it does not want. A site bootstrapped before the mark existed (SM1393) gets the roles, and the shipped bundles it lacked, at the first users-tool read after upgrading to 0.16.7, nested only into roles present under their shipped names; the audit log records each adoption, and the operator reviews the Groups page once
An edited copy of an Odoo module left in core's lib, removed | on upgrading to 0.16.7, where the upgrade's summary names it under `Orphans:` | OPEN | UPGRADE.md, the SM1369 X7 entry - Odoo's modules now load only from `extensions/odoo/lib/`; an old copy the site edited is kept by the upgrade and named, and Odoo then refuses to load until it is removed (the error names the file). The operator keeps any change from that file and deletes it; nothing else needs doing on a site that edited none
An account named `v1`, renamed | on upgrading to 0.16.7, where `lazysite check` names it | OPEN | UPGRADE.md, the SM1390 entry (ruling 147) - `v1` is the theme-preview cookie's marker and a session payload beginning with it is refused, so such an account signs in and is refused on every request; `users rename v1 NEW-NAME`. The users tool, the manager and an import refuse the name from 0.16.7
A schedule entry under the 300-second floor, raised | on upgrading to 0.16.7, where `lazysite check` names it | OPEN | UPGRADE.md, the SM1391 entry (ruling 148) - a hand-written `every:` below 300 never ran and still does not; from 0.16.7 the daemon records a refusal for it once and the check names it; the operator sets `every:` to 300 or more
An outside process that verifies the session cookie, accounted for | on giving a process read access to the site's `auth/` directory (0.16.7) | OPEN | docs/architecture/session-cookie-contract.md and docs/SECURITY.md, the SM1383 entry (ruling 146) - the key is symmetric, so a process that can verify `lazysite_auth` can mint one for any account; "read-only" is that process's promise, and the operator trusts it as far as the web server. The operator's record of which processes hold that access is their own (OPERATIONS-TEMPLATE.md)
Rows' earlier values in the row history, and the offline kit's browser storage, accounted for | on upgrading to 0.16.8 (the history, on any site whose data store is written); on enabling `app-offline` on a site with the Odoo site sign-in (0.16.8) | OPEN | docs/SECURITY.md, the SM1355 and SM1396 entries (ruling 177) - the history keeps each changed or deleted row's earlier values, personal data among them, for the table's period (90 days, or the table's `row_history_days`), in the store and so in the site's backups; the daily `row-history-prune` job runs only where the daemon is enabled with a usable job account, and the write path prunes otherwise. The kit keeps a person's reads and queued changes in their own browser under a label of their login; a sign-out through the Odoo helper drops the reads. The site's records of what it holds, and its privacy notice, are the operator's (SM1010 principle, as SM1324's row)
Every public page now in the sitemap and `llms.txt`, reviewed | on upgrading to 0.16.8 | OPEN | UPGRADE.md, the SM1357 entry (rulings 165, 171, 174) - a page with no `register:` key is now in both, and `llms.txt` is on by default; a public page meant to stay out of search engines gets `search: false`, and `llms_txt: off` turns the summary off. `lazysite check` names a folder that looks like another site's content served on the bare host
`write_content` and `publish_copies` granted only where decided | on granting either (0.16.8) | OPEN | docs/SECURITY.md, the SM1414 and SM1354 entries (rulings 155, 169) - no shipped role holds either. `write_content` lets a group's members read, list, save, move and delete content over their own session wherever an access rule's write list names them or their group; `publish_copies` lets an agent's group publish its own copy over a page with no person looking. Which groups hold them, and the rules that name members' groups, are the operator's decision and record
An access rule whose owner is no account, re-owned or removed | on upgrading to 0.16.8, where `lazysite check` names each | OPEN | UPGRADE.md, the SM1401 entry (triage T-91) - a rule keeps its owner's login after the account is removed, in force as written and changeable by the operator alone; the check names each such rule with the remedy (remove it on the manager's Permissions page, or `lazysite acl set --owner`). The engine changes no rule
A form's acknowledgement, and who a notify handler mails, accounted for | on setting a form's `acknowledge_field` (0.16.6) or a notify handler's recipients (0.16.8); on upgrading to 0.16.8 where `owner_contact` is still set, which `lazysite check` names | OPEN | docs/SECURITY.md, the SM1362, SM1412 and SM1413 entries (rulings 140, 158, 159) - `owner_contact` is ignored from 0.16.8 and its owner mail is gone: a form mails people only through a notify handler it names, whose recipients may be a group's member accounts (nested members included) at the addresses the Users page holds; the operator replaces the line with such a handler and deletes it. An acknowledgement sends the form's fixed words to an address a visitor typed, within the caps. The owner words it so that receiving it unasked is harmless, and the site's records and privacy notice are the operator's (SM1010 principle)
A store the engine now refuses on, repaired | on upgrading to 0.16.9, where `lazysite check` names each | OPEN | UPGRADE.md, the SM1417 entries (rulings 206, 207) - a damaged `acls.json`, groups file, auth lock, login rate counter, `content_root`, `session_lifetime` or `password_min_length`, and the stores of survey items 9-21 (an upload counter, the notice ledger and unsubscribe store, a send record, the scheduler's run record, a daemon service state), refuse the action they guard where they were worked around; the engine repairs nothing, the sysadmin repairs each from the command line as the check says, and a host without DB_File refuses every sign-in until it is installed or the extension is switched off. A site whose check is clean sees no change
An outside sign-in provider's group map, and who controls each mapped group, accounted for | on enabling the `oidc` extension (0.16.9) | OPEN | docs/SECURITY.md, the SM1351 entry (rulings 185, 186, 214) - a provider group may map to any site group, operators included, so whoever controls that group's membership at the provider can make a manager here; every sign-in is audited with the groups it granted; membership is read at sign-in only (the Sessions page's "Require sign-in again" asks the provider again); the ID token's signature is not checked, so the trust rests on TLS to the provider. From 0.16.10 (SM1422, ruling 229) a manager who is not the operator cannot add an entry to a capability group, so on a site that ran 0.16.9 with `oidc` on, the operator reads the map once for entries a manager added and removes any. Which provider, which groups and the record of who controls them are the operator's
A rule, a group's limit or a page naming an address profile the store lacks, corrected | on upgrading to 0.16.11, where `lazysite check` names each | OPEN | UPGRADE.md, the SM1435 entry (rulings 234, 235) and docs/SECURITY.md, the SM1435 entry - before 0.16.11 a rule could name a profile no store held: an allow admitted nobody and a deny excluded nobody (so a deny list that meant to keep an address out kept nothing out). 0.16.11 refuses the save at every door and keeps what is stored, so the operator creates the profile or sets the name to Not used for each one the check names; the engine changes no rule. A profile a rule names can no longer be deleted
A script that runs `--restore-full` given the new flags | on upgrading to 0.16.12, for any restore script or runbook | OPEN | UPGRADE.md, the 0.16.12 notes, and docs/SECURITY.md, the SM1439 entry (ruling 239) - `install.pl --restore-full` (and `lazysite backups --restore-full`) is one command that lays the engine's entry points, applies the group and modes and ends with the health check, so it needs `--cgibin` (or `--installdir`) and, on a host not serving under `www-data`, `--serving-group`; without `--cgibin` it refuses before it extracts. The operator's restore runbook and the copy of the full backup kept off the box (SM602) are theirs
A script that reads the answer of a full `backup-create`, and an unfinished backup removed | on upgrading to 0.17.0, where `lazysite check` names each unfinished backup | OPEN | UPGRADE.md, the 0.17.0 notes, and docs/SECURITY.md, the SM1446 entry (ruling 248) - `backup-create` with `scope=full` answers at once with the name and `in_progress` and a worker of the manager's user carries on, so a script that read `sha256` or `size` from the answer reads `backup-list` until the name is listed under `backups` (or `unfinished`); a backup killed before it finished is listed under unfinished, never as a backup and never restored, and the engine removes none, so the operator deletes it on the Backups page or with `rm` when no backup is being taken. One full backup runs at a time, with the residual that two starts in the same instant can both pass the check
A site coming from the 0.16.0 stable takes the upgrade notes in order | on upgrading from 0.16.0 to 0.17.0 | OPEN | UPGRADE.md, the 0.17.0 notes - 0.17.0 is the first stable since 0.16.0 and carries 0.16.1 to 0.16.12; the notes' opening paragraph names each release's section in order, and the operator reads those sections (address profiles, extensions, the shared container, the damaged-store refusals, `--restore-full`) before running `lazysite upgrade`, then runs `lazysite check` and restarts what holds engine code
Passkeys, web push, the webhook route and phone numbers accounted for | on turning any on (0.16.9) | OPEN | docs/SECURITY.md, the SM1352 and SM1363 entries (rulings 187, 195, 196, 199) - a passkey is a public key, a counter and a label; a web-push endpoint is a capability for a device, and nothing of a notice's content goes to the push service; an account's phone number goes to the operator's gateway through the connector `webhook.connector` names, and is personal data; `notify_routes: webhook` is an operator's setting; CryptX (`libcryptx-perl`, a Recommends) must be installed for passkeys and web push. The site's records of what it holds, and its privacy notice, are the operator's (SM1010 principle, as SM1324's row)
A table that names a source, and what it publishes, accounted for | on naming a `source:` in a table descriptor (0.16.9) | OPEN | docs/SECURITY.md, the SM1364 entry (rulings 189-191) - a remote system's values, personal data among them, become column values a page can render, and a refresh removes rows the source stops sending (a recorded, undoable change); `public: true` on a sourced table publishes what the source sends. The connector's callers, the table's read rules and what is kept are the operator's
A shared container's sites belong to one operator | on running the shared container (0.16.9) | OPEN | docs/SECURITY.md, the SM1361 and SM1369 X7 entry (rulings 205, 210) - every site in the container runs as www-data on the image's read-only engine, so one site's process can read another's state and only the image's own extensions run; a site whose end user takes it over moves to a dedicated service
A site's own scripts that send the data endpoint, or `data-rows`, a parameter it does not read, changed | on upgrading to 0.16.6 | OPEN | UPGRADE.md, the SM1377 entry (rulings 131, 139) - such a read is now a 400 (`kind: unknown-parameter`) where it was every row; the operator searches the site's scripts for `lazysite-data.pl?` and token scripts for `data-rows`, and filters on the page binding or after reading. The shipped `lazysite-data.js` and the manager are unaffected
CE marking applied | 2027-12-11 | OPEN | docs/POLICY.md
Support period ends | 2031-07-10 | running | docs/POLICY.md - five years from 0.7.0, cut 2026-07-10. The absolute date is written here so the commitment does not depend on anyone recalling which release was first stable
```

# Walked for 0.17.0: what a person must confirm

Walked on 2026-11-12 by the developer agent for 0.17.0, the **stable** (rulings 227, 242): every
row above was read against the CHANGELOG's `## Unreleased` section and `git log
930e7f32a..f02c7cbb0` (19 commits: SM1442 on n821, SM1443 on n822, SM1444 and SM1445 on n823,
SM1446 on n824 and SM1447 on n825, stacked on the 0.16.12 release commit and main). The rows
below hold what only a person can close. The 0.16.12 walk's items follow in the next section,
where they still stand.

- 0.17.0 is cut with `--final` and is the first stable since 0.16.0. It is the stable
  promotion of the 0.16.12 beta: 0.16.12 plus only the fixes of the 0.16.11 and 0.16.12 field
  passes (SM1442 a test, SM1443 a record, SM1444 a hardening of a default list, SM1445 a
  filing, SM1446 and SM1447 fixes), and it carries everything since 0.16.0 (0.16.1 to 0.16.10
  edge, 0.16.11 and 0.16.12 beta). The feature freeze (ruling 228) ends with this cut. It is
  **not security-critical**: no change in it since 0.16.12 fixes a known vulnerability, and
  `--security-critical` is not set. For a site coming from 0.16.0 it passes 0.16.2 (SM1303, cut
  security-critical, so `upgrade --all --force-security` pushed it past every channel already)
  and 0.16.3 (SM1308, SM1309: no exploitation known, no notice or advisory, ruling 94); the walk
  confirmed (ruling 251) as no new finding.
- Four register entries in `docs/SECURITY.md` cover 0.17.0, all dated 12 Nov 2026,
  **drafted by the developer agent and confirmed by the release manager on 12 Nov 2026 (ruling
  251)**. SM1444 (the bad-URL blocker
  counts probes for credential files, ruling 245: a hardening of a default list) fires no
  trigger. SM1446 (an unfinished backup is never listed or restored; a full backup runs in a
  detached worker, one at a time, ruling 248) fires none: the worker is the request's own code and
  identity continued, with one residual, that two starts in the same instant can both
  pass the one-at-a-time check, and a worker past six hours stops counting as in progress,
  accepted as written (ruling 251). SM1447 (a refusal names the user who can run the command; the
  check says ok only about what it read) fires none and holds ruling 243. The walk's entry, which
  closes 0.17.0, records SM1442, SM1443 and SM1445 and each change's assessment, fires none, and
  says 0.17.0 is the stable promotion of 0.16.12 with the field-pass fixes.
- One STRIDE row was added at this walk (a full backup taken in a detached worker, a Denial of
  service row naming the one-at-a-time check and its residual). Trust boundaries and the assets
  line are unchanged by 0.17.0.
- An operate-side row asks the operator, on upgrading to 0.17.0, to read `backup-list` for a
  script's full backups (the answer is now `in_progress`) and to remove an unfinished backup the
  check names; and one row asks a site coming from the 0.16.0 stable to take UPGRADE.md's 0.17.0
  notes, which gather 0.16.1 to 0.16.12 in order.
- **The restore rehearsal row is closed.** SM1443 reran it on the shipped 0.16.12 tarball (11
  Nov 2026, ISO row in `docs/RELIABILITY.md`, one command, 743 ms, `lazysite check --group` 0
  failures) and the release manager confirmed it on 12 Nov 2026 (ruling 247) as the 0.17.0
  stable cycle's rehearsal. This walk adds no evidence for it and does not change
  `docs/RELIABILITY.md`.
- **What a stable cut needs that a beta did not**, read from `tools/lazysite-compliance.pl`,
  `tools/release.sh` and `docs/compliance/SIGNOFF.md`:
  - The two version stamps block, as for any channel (`signoff_required: yes`): OBLIGATIONS.md
    `reviewed_at_version` and TECHNICAL-FILE.md `covers_version`, both now 0.17.0. Done here.
  - The Declaration of Conformity is **not required to be signed or current on stable**. The
    check reports it advisory on edge, beta and stable and blocks only on `certified` (ADR 0010:
    stable ships supported software; certification is the deliberate act). It is the developer's
    to restamp the unsigned draft to the stable it describes, as SM1231 did for 0.16.0, and that
    is done: `docs/DECLARATION-OF-CONFORMITY.md` is an unsigned draft for 0.17.0, its code the
    code of 0.16.12 plus the field-pass fixes. The signature, the responsible person's and the
    legal review, are the release manager's at the certified cut; the check still warns "unsigned"
    on stable, by design.
  - The restore rehearsal is measured against the newest STABLE cut in the CHANGELOG. The
    rehearsal rows are dated 2026-11-11 and the 0.17.0 section will carry its cut date, so a cut
    dated after 11 Nov 2026 makes the check print "older than the last stable cut" as an advisory
    ("blocking at certified"). The row is closed by ruling 247; the advisory is the check not
    knowing that. Nothing blocks.
  - The coverage record: a stable cut runs the coverage stage (`release.sh` refuses a stable
    build without it; SM1083), so the gate takes about an hour longer than the beta's and writes
    the coverage record in the release commit. That is the gate's, not this walk's.
  - The SBOM strict gate runs as on every channel (see the SBOM row).
  - The bench baseline: the check prints "re-capture at a stable cut" (advisory) and row
    above stays OPEN through the 0.17.0 cut (ruling 250). `dist/config/bench-baseline.json` was
    captured on 2026-09-30; it is re-captured after 0.17.0 with `perl tools/bench.pl --baseline`
    on a quiet host, at the release manager's chosen moment, before the certified cut it blocks.
    Not done here: this host is shared.
  - Obligation due dates: none OPEN or STARTED is inside 30 days of 12 Nov 2026. The nearest is the
    first third-party penetration test, due by 31 Dec 2026: ruling 249 (12 Nov 2026) says the 0.17.0
    stable is not the beginning of general-availability marketing in ADR 0007's waiver, so the
    date stands.
  - The download/ commit: a stable cut adds a second commit replacing `download/` with the new
    stable set (lint 113 waits for it). That is `release.sh build` with `--final`.
  - The tag section is headed `STABLE`, which the rehearsal rule reads; and as a new minor,
    0.17.0 moves the 0.16 line into `docs/releases/CHANGELOG-archive.md` (SM946) in the release
    commit.
- The release manager's answers of 12 Nov 2026: the four register entries (SM1444, SM1446,
  SM1447 and the walk's), the STRIDE row and the closing walk entry are confirmed, no ADR 0007
  trigger, SM1446's residual accepted as written (ruling 251); the 0.17.0 stable is not the
  beginning of general-availability marketing, so the first third-party penetration test stays
  due by 31 Dec 2026 (ruling 249); the bench baseline stays OPEN through the cut and is
  re-captured after 0.17.0 on a quiet host, before the certified cut (ruling 250).
- `content_sha` in OBLIGATIONS.md and TECHNICAL-FILE.md is left for the release manager at
  sign-off; the check prints the value for the changed content.
- The check, run as the gate runs it (a clone of the branch, `release-material.pl 0.17.0
  --channel stable --date 2026-11-12`, then `lazysite-compliance.pl --check --channel stable`),
  exits 0: 5 ok, 3 warnings, 0 masked, 0 blocking. The three warnings are the Declaration of
  Conformity (stamped 0.17.0, unsigned), the bench baseline (re-capture at a stable cut) and the
  restore rehearsal (newest 2026-11-11, older than the stable cut of 2026-11-12, which the
  check measures by date and which ruling 247 closes); all advisory on stable.
- SBOM: strict, exit 0, 495 components, none more than at 0.16.12 (manifest of 426 files, not
  security-critical).
- Test files: 1,824 at 0.17.0, 1,814 at 0.16.12 (ten added: t/tools/640, 645, 646, 650 to 653
  and t/unit/manager/975 to 977; none removed).

# Walked for 0.16.12: what a person must confirm

Walked on 2026-11-11 by the developer agent for 0.16.12, the second beta (ruling 242): every row
above was read against the CHANGELOG's `## Unreleased` section and `git log
b050272f9..2920a8f8a` (10 commits: SM1438 on n816, SM1439 on n817 and SM1440 on n818,
stacked on the 0.16.11 release commit). The rows below hold what only a person can close. The
0.16.11 walk's items follow in the next section, where they still stand.

- 0.16.12 is cut with `--beta` from 0.16.11 plus the beta field-pass fixes: SM1438 (the restore
  rehearsal record of 11 Nov 2026, which found the restore gap), SM1439 (`install.pl
  --restore-full` lays the engine, applies the serving group and writes the install state,
  ruling 239) and SM1440 (refusals name the unix user to run as; the check says ok only about
  what it read; no `--fix` hint with nothing to fix; a missing group is named before a missing
  profile; a group limit on a group that does not exist is refused). It is the second beta, the
  release the 0.17.0 stable is promoted from (rulings 227, 242); the feature freeze (ruling 228)
  holds. It is **not security-critical** (no change in it fixes a known vulnerability) and carries
  no advisory. Confirmed by the release manager on 11 Nov 2026 (ruling 243), except the disclosure, which the ruling changed (below).
- Three register entries in `docs/SECURITY.md` cover 0.16.12, all drafted by the developer agent
  on 11 Nov 2026 and **confirmed by the release manager the same day (ruling 243)**. SM1439 (the full restore: a
  system-user operation, the code and the modes from the release, the data from the tarball,
  a backup carrying a symlinked `lazysite/` refused before anything is changed) fires no trigger. SM1440 (messages and check text; the one behaviour
  change is the group refusal) fires none. Ruling 243 changed the one thing the walk raised: a
  refusal shown through a web door (the manager API, MCP) names no unix user and says "the web
  server's user", and the CLI keeps naming the users; built in a2180ad72. The walk's entry (SM1438's record, with each change's
  assessment) fires none.
- One STRIDE row was added at this walk (a full backup restored by `--restore-full`), confirmed by
  the release manager on 11 Nov 2026 (ruling 243). Trust boundaries 11 and 15, the assets line and the
  not-yet-code line are unchanged by 0.16.12.
- An operate-side row asks the operator, on upgrading to 0.16.12, to give any restore script the
  new flags (`--cgibin`, and `--serving-group` where the web server's group is not `www-data`).
- **The restore rehearsal row stays OPEN** (rulings 241, 242). The 11 Nov 2026 row in
  `docs/RELIABILITY.md` is the honest record of the gap and is not changed. SM1439 closes the gap
  in code. The rehearsal is rerun by the developer on this host against the shipped 0.16.12
  tarball after the beta build, as a scratch rehearsal, with the restore now one command
  (`install.pl --restore-full <file> --docroot X --cgibin C --domain Y --serving-group G`) and
  `lazysite check` run on the restored docroot as the proof that it serves; the release manager
  confirms the dated row before the 0.17.0 stable cut. No evidence for it is invented here.
- What a beta needs that an edge cut did not: nothing the records do not already carry (see the
  0.16.11 section below; the channel rules are the same). The two version stamps block
  (OBLIGATIONS.md `reviewed_at_version` and TECHNICAL-FILE.md `covers_version`, both now 0.16.12);
  everything else is advisory. `content_sha` in OBLIGATIONS.md and TECHNICAL-FILE.md is left for
  the release manager at sign-off; the check prints the value for the changed content. The
  release manager's `--beta` gate is `tools/gate-main.sh --beta`; a security-critical flag is
  refused on a beta (release.sh), and this release does not set it.
- The check, run as the gate runs it (a clone of the branch, `release-material.pl 0.16.12
  --channel beta`, then `lazysite-compliance.pl --check --channel beta`), exits 0: 5 ok, 2
  warnings, 0 masked, 0 blocking. The two warnings are the Declaration of Conformity (stamped
  0.16.0, unsigned) and the restore rehearsal, both "blocking at certified" and neither blocking a
  beta. The rehearsal warning still reads "newest is 2026-08-26": the check does not read the
  "11 Nov 2026" row of docs/RELIABILITY.md as a date, and the row stays the record of the restore
  gap in any case (ruling 241); the rerun on the shipped 0.16.12 tarball is the one that closes
  the row. No dated obligation is inside 30 days.
- SBOM: strict, exit 0, 495 components, none more than at 0.16.11 (no shipped file and no sbom-deps.json entry added: the change is five tests added and edits to existing files; the manifest is 426 files, not security-critical).
- Test files: 1,814 at 0.16.12, 1,808 at 0.16.11 (six added: t/tools/628 and 630 to 634; none
  removed).

# Walked for 0.16.11: what a person must confirm

Walked on 2026-11-11 by the developer agent for 0.16.11, the beta (ruling 236): every row
above was read against the CHANGELOG's `## Unreleased` section and `git log
bc1d27efd..17c1edb13` (14 commits: SM1430 on n811, SM1435 on n812 and SM1437 on n814, stacked). The rows
below hold what only a person can close. The 0.16.10 walk's items are carried below where
they still stand.

- 0.16.11 is cut with `--beta` from 0.16.10 plus SM1430, SM1435 and SM1437, and is the release the
  0.17.0 stable is promoted from (rulings 227, 228). The feature freeze on main starts at
  this cut (ruling 228): only fixes land until 0.17.0. It is **not security-critical** (no
  change in it fixes a known vulnerability) and carries no advisory; the release manager
  confirmed that judgement with the register entries on 11 Nov 2026 (ruling 237).
- Two register entries in `docs/SECURITY.md` cover 0.16.11, both drafted by the developer
  agent on 11 Nov 2026 and **confirmed by the release manager the same day (ruling 237)**. SM1435 (ruling 234:
  a rule, a group's address limit or a page naming an address profile the store lacks is
  refused at every door, and a profile a rule names cannot be deleted; the deny list that
  named a missing profile used to exclude nobody, silently) fires no trigger and names every
  door it applies to. Ruling 235, which carries the refusal to a page's front matter, is a
  developer call, confirmed with the entry. The walk's entry (SM1430, a display-only
  marker the page response now clears when the session is gone, which carries no authority;
  SM1437, a check that refuses to say ok about what it could not read, names the unread paths,
  covers every domain's shadow check and says what `--fix` and repair did, a hardening of what
  the check reports; SM1435's Groups page wording) fires none and says why.
- One STRIDE row was added at this walk (a rule naming a missing address profile, and a
  profile deleted while a rule names it) and trust boundary 11 (the address rule) carries a
  restating sentence, both confirmed by the release manager on 11 Nov 2026 (ruling 237). Trust boundary 15, the assets line and the
  not-yet-code line are unchanged by 0.16.11.
- An operate-side row asks the operator, on upgrading to 0.16.11, to correct each rule,
  limit or page `lazysite check` names as naming a missing profile.
- **What a beta needs that an edge cut did not: nothing the records do not already carry.**
  `tools/lazysite-compliance.pl` has no rule of its own for `beta`. Its only channel tests
  are `certified` (the Declaration of Conformity and the restore rehearsal become blocking,
  and sign-off is forced on) and `stable` (the bench-baseline advisory). On `beta`, as on
  `edge`, the two version stamps block (OBLIGATIONS.md `reviewed_at_version` and
  TECHNICAL-FILE.md `covers_version`, both now 0.16.11) and everything else is advisory.
  The check's result on this tree with `--channel beta` is the item below.
  What a person must still do, none of it blocking a beta:
  - The restore rehearsal row stays OPEN. The newest rehearsal in `docs/RELIABILITY.md` is
    2026-08-26, older than the last stable cut (0.16.0, 2026-10-22), so the check says so as
    an advisory on every channel below certified. Ruling 237 (11 Nov 2026) puts it during the
    beta, before the 0.17.0 stable cut, and ruling 238 (11 Nov 2026) makes it a scratch
    rehearsal that the developer runs on this host against the shipped 0.16.11 tarball after
    the beta build, confirmed by the release manager. It is due before the 0.17.0 stable
    because 0.17.0 is the next stable cut and the cycle is measured against stable cuts. No
    evidence for it is invented here; its result is a dated row in `docs/RELIABILITY.md`.
    The steps, as the last rehearsal ran them (`tmp/rehearsal-0.11.0.sh`):
    1. Take the shipped 0.16.11 tarball, not the working tree, and install it into a scratch
       docroot on this host.
    2. Add canary content and a manager account.
    3. Make a full backup (`action_backup_create('full')`) and copy it out of the docroot,
       which holds it in `lazysite/backups/`.
    4. Destroy the scratch docroot.
    5. Restore onto a different docroot with `install.pl --restore-full <file> --docroot X
       --domain Y`, timing it.
    6. Verify the canary content, the auth store and `lazysite.conf` are intact, then remove
       the scratch site.
    7. Add the dated row, with the recovery time, to `docs/RELIABILITY.md`.
  - The Declaration of Conformity stays an unsigned draft at 0.16.0, advisory until a
    certified cut; the release manager signs it then.
  - The bench baseline (captured 2026-09-30) is re-captured on a quiet host at the stable
    cut, as the row says. Coverage is not run for a beta (SM1083, ruling 2026-10-16).
  - `content_sha` in OBLIGATIONS.md and TECHNICAL-FILE.md is left for the release manager at
    sign-off; the check prints the value for the changed content.
  - The release manager's `--beta` gate is `tools/gate-main.sh --beta`; a security-critical
    flag is refused on a beta (release.sh), and this release does not set it.
- The check, run as the gate runs it (a clone of the branch, `release-material.pl 0.16.11
  --channel beta`, then `lazysite-compliance.pl --check --channel beta`), exits 0: 5 ok, 2
  warnings, 0 masked, 0 blocking. The two warnings are the Declaration of Conformity (stamped
  0.16.0, unsigned) and the restore rehearsal (newest 2026-08-26, older than the last stable
  cut, 2026-10-22), both "blocking at certified" and neither blocking a beta. No dated
  obligation is inside 30 days.
- SBOM: strict, exit 0, 495 components (see the SBOM row).
- Test files: 1,808 at 0.16.11, 1,797 at 0.16.10 (twelve added, one removed: t/unit/manager/361,
  the old delete-with-force test, replaced by 974).

Carried from the 0.16.10 walk (confirmed by the release manager on 2026-11-10, ruling 233),
which read `git log 64d5c3c11..17a681a71` (23 commits: SM1420 to SM1427, the line n799 to n807):

- Two register entries in `docs/SECURITY.md` cover 0.16.10, both drafted by the developer agent and confirmed by the release manager on 2026-11-10 (ruling 233). SM1422 (n801: a manager cannot point a new OIDC map
  entry at a capability group) fires no trigger; ruling 229 rules that it ships in
  0.16.10, not security-critical, with no advisory, because the code is only in 0.16.9
  (edge), off by default and in no stable release. The walk's entry (SM1420, SM1421,
  SM1423, SM1424, SM1425, SM1426, SM1427) fires none and says why each moves no control:
  the Hestia deploy's registry entry, site address and first operator, and the fleet
  verbs' `--all` (ruling 231); `git` in the image and in the package's Recommends, and
  the declared modes the upgrade sets; wording; the signed-in marker's one writer;
  output and docs.
- One STRIDE row was added at this walk (the root-run Hestia deploy), confirmed by the release manager on 2026-11-10 (ruling 233), with the claim-link residual risk. Trust
  boundary 15, the assets line and the not-yet-code line are unchanged by 0.16.10.
- 0.16.10 is edge, not security-critical (ruling 229): it fixes no vulnerability that
  reached a stable release (the vulnerability-handling row).
- Two defects found at the walk are fixed in their own commits, each with a test that
  fails without it: `lazysite repair` ran the doctor through the shell with unquoted
  paths (now list-form pipes), and the Hestia deploy checked USER and DOMAIN only by the
  docroot existing (now plain names, USER a Hestia user, exit 2 before anything is
  touched). The claim link the deploy prints is left as `setup-sysop`'s own behaviour and
  recorded as residual risk.
- SBOM: strict, exit 0, 495 components, none more than at 0.16.9; 1,797 test files.
- No operate-side row was added. The SM1351 row (an outside sign-in provider's group map)
  gains one sentence: on a site that ran 0.16.9 with `oidc` on, the operator reads the
  map once for entries a manager added.
- Carried from the 0.16.9 walk: the sixteen 0.16.9 register entries and the walk's own
  entry, trust boundary 15 with the X4 to X7 callers, the assets line and the nine STRIDE
  rows are confirmed (rulings 225, 226); seven of the entries fired a trigger, contained,
  and no early third-party review is proposed, the OIDC grant mapping and the passkey
  paths being named in the scope of the engagement ADR 0007 already requires (the first
  third-party penetration test row above); 0.16.9 is edge, not security-critical; the
  operate-side rows added at that walk (SM1417's refused stores, SM1351's group map,
  SM1352 and SM1363, SM1364's source, SM1361's shared container) stand.
- Carried from the 0.16.8 walk: the kit's purge at sign-out is the Odoo helper's
  sign-out emptying that owner's kept reads and keeping their queue (rulings 177, 183);
  the operate-side rows for SM1355, SM1396, SM1357, SM1414, SM1354, SM1401 and SM1362
  (SM1412, SM1413), and those for SM1369 X7, SM1390, SM1391 and SM1383, SM1372, SM1371,
  SM1362 and SM1377, SM1343-SM1345 and SM1324 and SM1325, SM1142, SM1313, SM1304 and
  SM1219, added at their walks.
- The Declaration of Conformity (restamped, unsigned).
- Operate-side rows the developer agent cannot observe: the CRA Article 14 reporting
  path rehearsal and the named triage owner and deputy (both dated 2026-09-11, still
  OPEN), the first third-party penetration test (2026-12-31, or first GA marketing),
  OpenChain 5230 and 18974 (pending in `docs/POLICY.md`), CE marking, and the support
  period (`docs/POLICY.md`, ending 2031-07-10).
- The restore rehearsal (operator, root) and the SM296 re-apply sweep on each production
  site (operator): stable-gate plan P6 and P7.
- Left open for the certified release by ruling: signed releases and the vulnerability
  register.

# How a row is discharged

open
: the obligation has not been met and its date has not passed.

met
: met for the version named in the version anchor. A row that is `met` for
  0.10.8 is **not** met for 0.10.9 - obligations with a per-release cadence
  return to `open` when a new release is cut. That is what the release gate
  checks.

started
: partially discharged, with the artefact existing and incomplete. Used where
  completing early is cheaper than completing late - the technical file is the
  case in point.

running
: a continuing commitment with an end date rather than a due date.

# Why this file is anchored on versions as well as dates

A compliance claim is always a claim about **a version**. "The threat model is
current" is meaningless without saying current as of what; "the SBOM matches
the code" is a statement about one tarball. The eight-dimension review that
prompted this file made the same point about itself - a verdict belongs to the
tree it was measured on.

So every build-side row carries the release that must satisfy it, and
`reviewed_at_version` at the head of this file records the last release at
which the whole register was walked. If that value is behind the version being
cut, the register has not been reviewed for this release and the gate fails.

# References

- `docs/POLICY.md` - the regulatory posture and the CRA Article 13 table.
- `docs/DECLARATION-OF-CONFORMITY.md` - the declaration these obligations
  support.
- `docs/adr/0007-pentest-deferral.md` - the waiver, its expiry and its triggers.
- `docs/compliance/TECHNICAL-FILE.md` - the Annex VII index.
- `docs/compliance/OPERATIONS-TEMPLATE.md` - what an operator fills in.
- `/srv/projects/toolchain-development/OPERATIONS-GUIDE.md` - the operate-half
  items this register's operate section is drawn from.
