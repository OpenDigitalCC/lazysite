# lazysite - Implementor guide

For someone **installing or integrating** lazysite. The authoritative, worked
procedure (HestiaCP) is
[installers/hestia/INSTALL-RUNBOOK.md](../installers/hestia/INSTALL-RUNBOOK.md);
this is the map. For running it afterwards see [OPERATOR.md](OPERATOR.md).

## Requirements

- A **CGI-capable web server**. Apache is first-class: lazysite relies on
  `FallbackResource`, `ScriptAlias`, `mod_headers` (the `RequestHeader unset
  X-Remote-*` trust-strip), `mod_rewrite`, and `+ExecCGI`. nginx is supported
  through the `lazysite-nginx` glue package (fcgiwrap as the CGI bridge, or
  the pool below); other servers implement the contract in
  [reference/webserver-wiring.md](reference/webserver-wiring.md). For
  production speed, visitor pages can instead be served by a persistent
  per-site **FastCGI pool** (SM142: `mod_proxy_fcgi`/`fastcgi_pass` to
  `/run/lazysite/<site>.sock`; needs `libfcgi-perl` +
  `libfcgi-procmanager-perl`) - the auth wrapper and cgi-bin endpoints stay
  CGI either way.
- **Perl** (5.x core). Optional: Template Toolkit (theming), Archive::Zip
  (layout install), DB_File (rate limiting). All declared in
  `dist/config/sbom-deps.json`; the packaged list (Debian names + purpose) is
  at [docs/reference/host-dependencies.md](reference/host-dependencies.md), and
  `lazysite-check.pl --dependencies` reports which are present on a given host
  and the install line for anything missing.

## Install model

`install.pl` deploys files per `dist/config/classification.json`:

- **code** bucket - always overwritten on upgrade (scripts, manager UI, docs).
- **seed** bucket - conffile model: overwritten only if unchanged since the
  last install, otherwise preserved (your content, config).

It records per-file SHAs in `lazysite/.install-state.json`, so upgrades never
clobber edited content and an unwritable file is skipped non-fatally.

## Deploying (packaged, since 0.7.2)

The install path is the **debs**: `lazysite-common` (engine payload at
`/usr/share/lazysite`, the `lazysite` CLI, the site registry, the FastCGI
pool machinery) and, on HestiaCP, `lazysite-hestia` (web templates +
`lazysite-hestia-domain`). Per domain, one root command that **drops to the
site user** for every site-tree write:

```bash
lazysite-hestia-domain add <user> <domain>           # plain CGI
lazysite-hestia-domain add <user> <domain> --fcgi    # + persistent FastCGI pool
```

then apply the matching web template (`lazysite-cgi` / `lazysite-fcgi`). On a
non-Hestia host, provision **as the site user** with
`sudo -u <user> lazysite provision --docroot D --cgibin C --domain NAME`
(the CLI refuses to run as root - no root writes into site trees), then wire
the web server with the matching glue package: `lazysite-apache` or
`lazysite-nginx` ship commented vhost templates for both runtime patterns
plus a render command (`lazysite-apache-vhost add <domain> --docroot D
[--fcgi]`, same for nginx). **The wiring reference for every front-end** -
the two patterns explained once, Apache/nginx/Caddy/lighttpd snippets, and
the generic contract - is
[reference/webserver-wiring.md](reference/webserver-wiring.md). To evaluate
lazysite with no web server at all, `lazysite demo` provisions a scratch
site and serves it on the built-in dev server. The full worked Hestia
procedure, including the one-time template copy and `a2enmod` lines, is the
runbook. On a host with only the release tarball, one command
(`lazysite-hestia-deploy.sh USER DOMAIN --sysop NAME`) installs a site and makes its
first operator; the runbook's first section describes it.

## Deploying with Docker Compose (since 0.16.1)

`installers/docker/` in the release tarball is a Docker Compose package. Since
0.16.9 one container serves many sites (SM1361):
- the engine and its extensions are the image, read-only;
- each site is a folder in one volume, listed in its `sites.conf`, with its own
  FastCGI pool and runtime;
- nginx in front routes each request by its host, on plain HTTP behind your own
  TLS proxy.

The container belongs to one operator: every site runs as `www-data`, and only
the image's own extensions run. It is built on your machine from the unpacked
tarball, and nothing is pushed to a registry.

```bash
tar xzf lazysite-X.Y.Z.tar.gz
cd lazysite-X.Y.Z/installers/docker
docker compose build
docker compose up -d
docker compose exec lazysite lazysite-sites add example example.com www.example.com
docker compose exec lazysite lazysite-sites sysop example NAME
```

How each start treats a site:
- A site is provisioned at its first start.
- An older site is upgraded to the image, with a backup first.
- A site at the image's version has the engine's templates and manager files
  copied in again.
- A site whose state is newer than the image is refused, and the restore command
  is printed.

A site that is refused or keeps crashing answers 503, while the others serve.
`lazysite-sites status` names it. Sites are added and removed without a restart.
A one-site canary needs a second container.
[installers/docker/README.md](../installers/docker/README.md) covers the
variables, the volume, upgrades by tag, rollback, health and logs.

A site whose end user takes it over moves to a dedicated service: Hestia, or a
container of its own.

## First-run configuration

In `lazysite/lazysite.conf` (or the manager Config page):

- Manager access is the `ui` **capability on a group** (SM095): bootstrap with
  `lazysite-users.pl setup-sysop --user NAME`, which creates the sysops group and a
  NAMED account in it (there is no default account); grant
  `ui` to further groups on the manager Groups page. (SM138: the legacy
  `manager_groups:` conf key is retired - on upgrade any group it named receives
  its capabilities explicitly and the conf line is removed. When NO group grants
  manager access, an unsecured/dev site treats any authenticated user as a
  manager.)
- `webdav_enabled: yes` - **off by default**; `/dav` returns 404 to every
  method until set (by design). The `webdav` capability is then granted
  per-group like any other.
- `site_name`, `layout`, `theme` - activate a theme globally.
- Set the manager password: `lazysite-users.pl passwd manager '<pass>'`.

## Integrating an AI publishing partner

Create an account, issue an `lzp_` pairing key, hand over the onboarding brief.
The partner exchanges it for an `lzs_` token and publishes over `/dav` + the
control API within its grant. The trust model, scope and deny-set are enforced
server-side; see [SECURITY.md](../SECURITY.md) and the publishing briefing.

A connecting agent should learn what it may do from the **capability map** rather
than by trial and error: the MCP `describe_capabilities` tool (or the control-API
`describe-capabilities` action) returns the channels, what each capability
unlocks, task recipes, the engine-owned paths not to touch, and the account's own
grant. The same model, for humans, is at
[docs/reference/capability-map.md](reference/capability-map.md) with copy-pasteable
[quickstarts](reference/quickstarts.md). Grant a partner the channel it uses
(`api` for the control API, `mcp` for the connector, `webdav` for `/dav`) plus the
action capabilities for its role - the standard onboarding does this.
