#!/usr/bin/perl
# tools/lazysite-hestia-domain.pl - HestiaCP panel-side integrator (SM139
# increment 4). The lazysite-hestia deb installs this as
# /usr/bin/lazysite-hestia-domain.
#
# The hook-shaped provisioning command: it runs AS ROOT by design, because
# it is the panel-side integrator - the piece that does the few things only
# root can do on a Hestia box (lay out the 0551-locked domain root, hand
# the docroot to the web-server group, write the host-side registry, pool
# and daemon files, enable the systemd units) and then DROPS to the site
# user for everything that writes into the site tree. The drop is explicit
# and early: after the bounded root layout pass, every site-tree write
# happens under `sudo -n -u <panel-user>`, keeping the SM139 principle
# intact - no root writes into site trees.
#
# Verbs:
#   add USER DOMAIN [--channel edge|beta|stable] [--policy auto|manual] [--fcgi]
#                   [--workers N] [--max-requests N] [--daemon]
#   remove DOMAIN
#   list
#
# It deliberately does NOT apply the Hestia web template
# (v-change-web-domain-tpl) itself: template application forces a vhost
# rebuild and is the operator's panel action - see README.Debian in the
# lazysite-hestia package for the 3-step onboarding.
#
# Core-only Perl; no CPAN deps.

use strict;
use warnings;
use Cwd            qw(abs_path);
use File::Basename qw(dirname);
use File::Compare  ();
use File::Find     ();
use Getopt::Long   ();

Getopt::Long::Configure( 'no_ignore_case', 'bundling_override' );

# Host-layout defaults, each overridable by environment for non-standard
# hosts (Hestia's HOMEDIR is configurable) and for the test suite.
my $HOME_BASE = length( $ENV{LAZYSITE_HESTIA_HOME} // '' )
    ? $ENV{LAZYSITE_HESTIA_HOME}
    : '/home';
my $REGISTRY_DIR = length( $ENV{LAZYSITE_REGISTRY_DIR} // '' )
    ? $ENV{LAZYSITE_REGISTRY_DIR}
    : '/etc/lazysite/sites.d';
my $POOLS_DIR = length( $ENV{LAZYSITE_POOLS_DIR} // '' )
    ? $ENV{LAZYSITE_POOLS_DIR}
    : '/etc/lazysite/pools';
my $DAEMON_DIR = length( $ENV{LAZYSITE_DAEMON_DIR} // '' )
    ? $ENV{LAZYSITE_DAEMON_DIR}
    : '/etc/lazysite/daemon';
# SM760: the web server's CGI user, which is the runtime's user on the plain
# CGI flow (see `add --daemon`).
# SM1196: where Hestia keeps its template trees, and where this release's own
# copies are. Overridable so the hints below can be tested on fixtures.
my $TPL_BASE = length( $ENV{LAZYSITE_HESTIA_TEMPLATES} // '' )
    ? $ENV{LAZYSITE_HESTIA_TEMPLATES}
    : '/usr/local/hestia/data/templates/web';
my $TPL_SRC_DIR = length( $ENV{LAZYSITE_TEMPLATE_SRC} // '' )
    ? $ENV{LAZYSITE_TEMPLATE_SRC}
    : '/usr/share/lazysite-hestia/templates';
my $WEB_USER = length( $ENV{LAZYSITE_WEB_USER} // '' ) ? $ENV{LAZYSITE_WEB_USER} : 'www-data';
my $WEB_GROUP = length( $ENV{LAZYSITE_WEB_GROUP} // '' )
    ? $ENV{LAZYSITE_WEB_GROUP}
    : 'www-data';

my $verb = shift @ARGV;
$verb = defined $verb ? $verb : '';

if    ( $verb eq '' )                                     { usage(2) }
elsif ( $verb eq 'help' || $verb =~ /^-{0,2}help$|^-h$/ ) { usage(0) }
elsif ( $verb eq 'add' )                                  { exit cmd_add() }
elsif ( $verb eq 'remove' )                               { exit cmd_remove() }
elsif ( $verb eq 'list' )                                 { exit cmd_list() }
else {
    print {*STDERR} "lazysite-hestia-domain: unknown verb '$verb'\n\n";
    usage(2);
}

# ---------- usage / errors ----------

sub usage {
    my ($rc) = @_;
    my $fh = ( $rc // 0 ) == 0 ? *STDOUT : *STDERR;
    print {$fh} <<'USAGE';
Usage: lazysite-hestia-domain VERB [options]

HestiaCP panel-side integrator for lazysite domains. Runs as root (the
panel context) and drops to the site user for every site-tree write.

Verbs:
  add USER DOMAIN [--channel edge|beta|stable] [--policy auto|manual] [--fcgi]
                  [--workers N] [--max-requests N] [--daemon]
        Prepare the Hestia domain layout as root (locked domain root,
        docroot group/setgid), then provision the site AS THE PANEL USER
        (sudo -u USER lazysite provision), register it in
        /etc/lazysite/sites.d/, and with --fcgi write
        /etc/lazysite/pools/DOMAIN.conf and enable lazysite@DOMAIN.
        ALWAYS writes /etc/lazysite/daemon/DOMAIN.conf and enables
        lazysited@DOMAIN.timer, the site's persistent runtime (SM666).
        That does nothing until the site's sysop also enables the
        `daemon` plugin - the unit is the host's switch, the plugin the
        site's - so a site not using it costs one short-lived process
        every five minutes and shows as `inactive (dead)`, which is the
        correct resting state and not a fault. --daemon is accepted and
        ignored; it used to be how you asked for this.
        Afterwards apply BOTH templates yourself - the Apache one that
        carries the access rules, and the nginx proxy in front of it,
        which otherwise answers static requests before Apache sees them:
          v-change-web-domain-tpl       USER DOMAIN lazysite-cgi|lazysite-fcgi yes
          v-change-web-domain-proxy-tpl USER DOMAIN lazysite-proxy
  remove DOMAIN
        Stop and disable the lazysite@DOMAIN pool and the lazysited@DOMAIN
        runtime (whichever exist), remove their configs and the registry
        entry. NEVER deletes the docroot -
        the site files stay; switch the domain's web template back in
        Hestia to take it off lazysite.
  list
        List registered lazysite sites (alias for `lazysite sites`).
  help
        This help.

Environment (host-layout overrides):
  LAZYSITE_HESTIA_HOME    Hestia home base (default /home)
  LAZYSITE_REGISTRY_DIR   site registry (default /etc/lazysite/sites.d)
  LAZYSITE_POOLS_DIR      pool configs (default /etc/lazysite/pools)
  LAZYSITE_DAEMON_DIR     daemon configs (default /etc/lazysite/daemon)
  LAZYSITE_HESTIA_TEMPLATES  Hestia web template root (default
                          /usr/local/hestia/data/templates/web)
  LAZYSITE_TEMPLATE_SRC   this release's template copies (default
                          /usr/share/lazysite-hestia/templates)
  LAZYSITE_WEB_GROUP      web-server group (default www-data)
  LAZYSITE_WEB_USER       web-server CGI user (default www-data) - the runtime's
                          user for `add --daemon` without --fcgi

Full documentation: man lazysite-hestia-domain.
USAGE
    exit( $rc // 0 );
}

sub fail {
    my ($msg) = @_;
    $msg =~ s/\n?$/\n/;
    print {*STDERR} "lazysite-hestia-domain: $msg";
    exit 1;
}

sub require_root {
    my ($what) = @_;
    return if $> == 0;
    fail( "'$what' must run as root: it is the panel-side integrator (it\n"
            . "prepares the Hestia-owned domain layout and the host registry/pool\n"
            . "files), and it DROPS to the site user for every site-tree write.\n"
            . 'Re-run with sudo.' );
}

sub run_or_fail {
    my (@cmd) = @_;
    my $rc = system(@cmd);
    return if $rc == 0;
    my $why = $rc == -1 ? "cannot run: $!" : 'exit ' . ( $rc >> 8 );
    fail( "command failed ($why): " . join( ' ', @cmd ) );
}

# ---------- shared helpers ----------

# The lazysite CLI lives next to this command in every install shape:
#   /usr/bin/lazysite-hestia-domain      -> /usr/bin/lazysite       (deb)
#   TREE/tools/lazysite-hestia-domain.pl -> TREE/tools/lazysite-cli.pl
sub cli_path {
    my $bin = dirname( abs_path($0) );
    for my $cand ( "$bin/lazysite", "$bin/lazysite-cli.pl" ) {
        return $cand if -f $cand;
    }
    fail( "cannot locate the `lazysite` CLI next to $bin\n"
            . '(is lazysite-common installed?)' );
}

# Domain names become file names (registry, pool conf, unit instance) and
# path components - allow only the safe hostname alphabet.
sub check_domain {
    my ($domain) = @_;
    fail('DOMAIN is required') unless length( $domain // '' );
    # SM791: \A...\z, not ^...$. Perl's $ matches BEFORE a trailing newline, so
    # "example.com\n" passed this check - and a newline in the domain is the
    # only route by which one could reach a value in write_kv_file, which
    # writes KEY=VALUE lines into a root-owned systemd EnvironmentFile. Not
    # exploitable as it stands (the alphabet has no '=' and no space, so an
    # injected tail is a bare path systemd ignores), which is exactly why it is
    # cheap to close.
    fail("invalid domain '$domain' (allowed: [A-Za-z0-9._-], no leading dot/dash)")
        if $domain !~ /\A[A-Za-z0-9][A-Za-z0-9._-]*\z/;
    return $domain;
}

sub pool_conf_path {
    my ($domain) = @_;
    return "$POOLS_DIR/$domain.conf";
}

sub daemon_conf_path {
    my ($domain) = @_;
    return "$DAEMON_DIR/$domain.conf";
}

# ---------- add ----------

sub cmd_add {
    my %o = (
        channel      => '',
        policy       => '',
        fcgi         => 0,
        daemon       => 0,
        workers      => 2,
        max_requests => 500
    );
    # GetOptions first (it permutes options out of @ARGV), positionals after,
    # so `add --fcgi USER DOMAIN` and `add USER DOMAIN --fcgi` both work.
    Getopt::Long::GetOptions(
        'channel=s'      => \$o{channel},
        'policy=s'       => \$o{policy},
        'fcgi'           => \$o{fcgi},
        'daemon'         => \$o{daemon},
        'workers=i'      => \$o{workers},
        'max-requests=i' => \$o{max_requests},
    ) or usage(2);
    my ( $user, $domain ) = @ARGV;
    fail('add needs USER and DOMAIN: lazysite-hestia-domain add USER DOMAIN')
        unless length( $user // '' ) && length( $domain // '' );
    check_domain($domain);
    fail("--channel must be 'edge', 'beta' or 'stable'")
        if length $o{channel} && $o{channel} !~ /^(?:edge|beta|stable)$/;
    fail("--policy must be 'auto' or 'manual'")
        if length $o{policy} && $o{policy} !~ /^(?:auto|manual)$/;
    require_root('add');

    my ( $uid, $ugid ) = ( getpwnam $user )[ 2, 3 ];
    fail("panel user '$user' does not exist") unless defined $uid;
    fail("panel user must not be root (SM139: sites are never owned by root)")
        if $uid == 0;
    my $web_gid = getgrnam($WEB_GROUP);
    fail( "web-server group '$WEB_GROUP' does not exist "
            . '(set LAZYSITE_WEB_GROUP for a non-Apache-standard host)' )
        unless defined $web_gid;

    my $domdir  = "$HOME_BASE/$user/web/$domain";
    my $docroot = "$domdir/public_html";
    my $cgibin  = "$domdir/cgi-bin";
    fail( "no Hestia domain at $domdir - create the domain in Hestia first\n"
            . "(v-add-web-domain $user $domain), then re-run this command" )
        unless -d $domdir;
    fail("no docroot at $docroot") unless -d $docroot;

    # --- root layout pass (bounded; the only root actions on the tree) ---
    # The Hestia domain root is mode 0551: the owner cannot create entries
    # in it, so the sibling trees install.pl populates (plugins/, tools/,
    # lib/) must be pre-created by root, owned by the user.
    print "==> preparing domain layout (as root)\n";
    for my $sib (qw(plugins tools lib)) {
        my $d = "$domdir/$sib";
        if ( !-d $d ) {
            mkdir $d or fail("mkdir $d: $!");
        }
        chown $uid, $ugid, $d or fail("chown $d: $!");
    }
    if ( !-d $cgibin ) {
        mkdir $cgibin or fail("mkdir $cgibin: $!");
    }
    # The CGI runs as the web-server user (SuexecUserGroup is off in the
    # shipped templates) and writes rendered .html across the docroot:
    # hand the tree to <user>:<web-group> with setgid dirs so everything
    # the site user provisions below inherits the web group - ownership
    # correct by construction, no chown-after repair pass.
    for my $top ( $docroot, $cgibin ) {
        File::Find::find(
            {
                no_chdir => 1,
                wanted   => sub {
                    my $p = $File::Find::name;
                    return if -l $p;    # never chase symlinks out of the tree
                    chown $uid, $web_gid, $p or fail("chown $p: $!");
                    if ( -d _ ) {
                        chmod 02775, $p or fail("chmod $p: $!");
                    }
                },
            },
            $top
        );
    }

    # --- THE DROP: every site-tree write below runs as the panel user ---
    print "==> provisioning $domain from the host payload (as $user)\n";
    my @prov = ( 'sudo', '-n', '-u', $user, '--', $^X, cli_path(),
        'provision', '--docroot', $docroot, '--cgibin', $cgibin,
        '--domain',  $domain );
    push @prov, '--channel', $o{channel} if length $o{channel};
    push @prov, '--policy',  $o{policy}  if length $o{policy};
    run_or_fail(@prov);

    # Secrets dirs: group-writable, off the world, so the web-server CGI
    # can mint auth/.secret and the rate-limit DBs (login depends on it).
    # Mode-only adjustments, same as the old template rebuild hook.
    # SM850: built by hand on purpose - this core-only root tool loads no
    # Lazysite module, and the tree is the one the install above just laid out
    # in a fresh docroot, which is always inside it (t/lint/37 names it).
    for my $sec ( "$docroot/lazysite/auth", "$docroot/lazysite/forms" ) {
        next unless -d $sec;
        chmod 02770, $sec or fail("chmod $sec: $!");
    }

    # --- host-side registration (root territory: /etc/lazysite) ---
    # The unprivileged provision run above cannot write the root-owned
    # registry (it prints the entry instead); this integrator IS the admin,
    # so record the site for fleet tooling (lazysite upgrade --all / sites).
    # Key set matches the CLI's reader: docroot/cgibin/owner/channel/policy.
    # channel/policy are provision-time caches; without --channel the conf
    # seeded by `provision --domain` says update_channel: stable, so cache
    # that, not 'edge'.
    write_kv_file(
        "$REGISTRY_DIR/$domain",
        [
            [ docroot => $docroot ],
            [ cgibin  => $cgibin ],
            [ owner   => $user ],
            [ channel => length $o{channel} ? $o{channel} : 'stable' ],
            [ policy  => length $o{policy}  ? $o{policy}  : 'manual' ],
        ],
        ''
    );
    print "==> registered: $REGISTRY_DIR/$domain\n";

    # --- FastCGI pool (production shape; plain CGI needs none of this) ---
    if ( $o{fcgi} ) {
        my $conf = pool_conf_path($domain);
        write_kv_file(
            $conf,
            [
                [ DOCROOT      => $docroot ],
                [ USER         => $user ],
                [ GROUP        => $WEB_GROUP ],
                [ WORKERS      => $o{workers} ],
                [ MAX_REQUESTS => $o{max_requests} ],
            ],
            "# lazysite FastCGI pool for $domain - consumed by lazysite\@.service\n"
                . "# via tools/lazysite-pool.pl. After editing:\n"
                . "#   systemctl restart lazysite\@$domain\n"
        );
        print "==> pool config: $conf\n";
        enable_unit( 'lazysite', $domain,
            "pool enabled: lazysite\@$domain (socket /run/lazysite/$domain.sock)" );
    }

    # --- persistent runtime (SM666) - the host's half of two switches ---
    # The conf carries the same two keys the pool's does, because the unit
    # has the same problem: systemd cannot template User= from an instance
    # name that is a domain. lazysited drops to USER before loading any
    # daemon code. The OTHER switch is the `daemon` plugin, the site's own
    # and born disabled (ADR 0009); with the plugin off the unit starts,
    # exits 0 and stays quiet, which is why it is safe to enable here.
    # SM893: ARMED FOR EVERY SITE, ruled by the release manager 2026-09-15.
    #
    # This used to be `if ( $o{daemon} )` - opt-in, on a flag somebody had to
    # remember. The Hestia deploy path already armed every site on every run,
    # so the two flows disagreed: a tarball site got the host half whether it
    # wanted it or not, and a deb site got it only if the operator typed
    # --daemon. A sysop who then enabled the plugin on such a site got a
    # runtime that never ran and nothing that said why.
    #
    # Arming everyone is safe for the reason written below and already
    # demonstrated by the tarball flow: with the plugin off the unit starts,
    # exits 0 and stays quiet. The cost is one short-lived process every five
    # minutes per site that is not using it; the benefit is that enabling the
    # extension is all a sysop ever has to do.
    #
    # `--daemon` is still accepted and now means nothing. It is not removed,
    # because runbooks and scripts pass it, and a flag that errors is a worse
    # welcome than a flag that is already true.
    {
        my $conf = daemon_conf_path($domain);
        # SM760: USER= is the unix user the REQUEST PATH writes as - the
        # pool's USER with --fcgi (the pool serves requests as the panel
        # user), the web server's CGI user otherwise. The runtime reads what
        # the request path writes and vice versa, and a 0660 file owned by
        # one is closed to the other; the first version wrote the panel user
        # unconditionally and the runtime could not read a groups-settings
        # file www-data had just rewritten.
        my $runtime_user = $o{fcgi} ? $user : $WEB_USER;
        write_kv_file(
            $conf,
            [ [ DOCROOT => $docroot ], [ USER => $runtime_user ], ],
            "# lazysite persistent runtime for $domain - consumed by\n"
                . "# lazysited\@.service via tools/lazysited.pl. After editing:\n"
                . "#   systemctl restart lazysited\@$domain\n"
        );
        print "==> daemon config: $conf\n";
        # SM757: the TIMER is what is enabled - it starts the service, and
        # re-starts it every five minutes while it is not running, so a sysop
        # enabling the plugin (no root) is picked up without an operator.
        enable_unit( 'lazysited', "$domain.timer",
            "runtime enabled: lazysited\@$domain.timer - it starts the runtime "
                . 'within five minutes of the sysop enabling the daemon plugin '
                . 'and naming a daemon_job_user holding run_jobs' );
    }

    print "\nDone. Now apply the matching web template in Hestia:\n"
        . '    v-change-web-domain-tpl '
        . "$user $domain "
        . ( $o{fcgi} ? 'lazysite-fcgi' : 'lazysite-cgi' )
        . " yes\n";
    template_hint( $o{fcgi} ? 'lazysite-fcgi' : 'lazysite-cgi' );

    # SM283. Printed as a second step rather than folded into the line above,
    # because it is a second LAYER: the web template is Apache's and carries
    # lazysite's access rules, while nginx sits in front of it and answers
    # static requests by extension. Leave the domain on a stock proxy and a
    # protected section gates its pages while publishing its images and PDFs.
    print "\nAnd the proxy template, so the front end respects the same rules:\n"
        . "    v-change-web-domain-proxy-tpl $user $domain lazysite-proxy\n"
        . "    curl -sI https://$domain/ | grep -i x-lazysite-front"
        . "    # confirms which front end replied\n";
    proxy_template_hint();
    return 0;
}

# Atomic-ish key=value file write (tmp + rename), shared by the registry
# entry and the pool config. $header is prepended verbatim ('' for none).
sub write_kv_file {
    my ( $path, $pairs, $header ) = @_;
    my $dir = dirname($path);
    fail("$dir does not exist (is lazysite-common installed?)") unless -d $dir;
    my $tmp = "$path.tmp.$$";
    open my $fh, '>', $tmp or fail("write $tmp: $!");
    print {$fh} $header if length $header;

    # SM791: A VALUE MAY NOT SPLIT THE LINE. This writes the root-owned
    # EnvironmentFile that lazysited@.service consumes, and it is shared with
    # the registry and pool writers - so the guard belongs here rather than in
    # each caller, where the next caller may not have the domain alphabet
    # protecting it. A value carrying a newline AND an '=' would let systemd
    # honour a setting nobody wrote.
    for my $p (@$pairs) {
        fail("refusing to write $path: the value for '$p->[0]' contains a line break")
            if defined $p->[1] && $p->[1] =~ /[\r\n]/;
    }
    print {$fh} "$_->[0]=$_->[1]\n" for @$pairs;
    close $fh or fail("close $tmp: $!");
    rename $tmp, $path or do {
        unlink $tmp;
        fail("rename $tmp -> $path: $!");
    };
    return;
}

# Enable + start a templated unit (lazysite@ for the pool, lazysited@ for the
# runtime) for the domain. On a systemd-less host (containers, test rigs)
# print the command instead of failing the whole onboarding.
sub enable_unit {
    my ( $unit, $domain, $done_msg ) = @_;
    my $systemctl = first_existing( '/usr/bin/systemctl', '/bin/systemctl' );
    if ( !defined $systemctl ) {
        print "==> systemctl not found - enable the unit yourself:\n"
            . "    systemctl enable --now $unit\@$domain\n";
        return;
    }
    run_or_fail( $systemctl, 'enable', '--now', "$unit\@$domain" );
    print "==> $done_msg\n";
    return;
}

sub first_existing {
    my (@paths) = @_;
    for my $p (@paths) {
        return $p if -x $p;
    }
    return undef;
}

# SM1196: is Hestia's copy of template NAME in DIR missing, stale or current?
# Hestia renders a vhost from ITS copy, which is put there once by hand, so an
# upgrade that refreshes /usr/share/lazysite-hestia/templates leaves it old and
# every rebuild re-renders the old template (edge, 2026-10-19: no X-Forwarded-For
# in the installed lazysite-proxy, so the vhost passed the client's through).
# 'stale' = either file of the pair differs from this release's copy; with no
# release copy to compare, an installed .tpl is called current (the old test).
sub template_state {
    my ( $dir, $name ) = @_;
    return 'missing' unless -f "$dir/$name.tpl";
    for my $ext (qw(tpl stpl)) {
        my $shipped = "$TPL_SRC_DIR/$name.$ext";
        next unless -f $shipped;
        return 'stale' unless -f "$dir/$name.$ext" && File::Compare::compare( $shipped, "$dir/$name.$ext" ) == 0;
    }
    return 'current';
}

# Point the operator at the shipped template copies if Hestia does not have
# them yet (the one-off host step from README.Debian), or has an OLD copy of
# them (SM1196). Advisory only.
sub template_hint {
    my ($tpl) = @_;
    my $hestia_tpl = "$TPL_BASE/apache2/php-fpm";
    return unless -d $hestia_tpl;    # no Hestia here (tests) - stay quiet
    my $state = template_state( $hestia_tpl, $tpl );
    return if $state eq 'current';
    if ( $state eq 'stale' ) {
        print "NOTE: $tpl in $hestia_tpl is STALE: it differs from this release's copy,\n"
            . "      so Hestia renders the OLD vhost on every rebuild. Refresh it, then\n"
            . "      rebuild every domain on it (the updater does both: --rebuild):\n"
            . "    cp /usr/share/lazysite-hestia/templates/$tpl.* $hestia_tpl/\n"
            . "    v-rebuild-web-domain USER DOMAIN\n";
        return;
    }
    print "NOTE: $tpl is not installed in $hestia_tpl yet; copy it first:\n"
        . "    cp /usr/share/lazysite-hestia/templates/$tpl.* $hestia_tpl/\n";
    return;
}

# The same hint for the nginx proxy layer (SM283), which lives in a DIFFERENT
# Hestia template directory - copying the web templates does not put it there.
sub proxy_template_hint {
    my $hestia_tpl = "$TPL_BASE/nginx";
    return unless -d $hestia_tpl;    # no Hestia here (tests) - stay quiet
    my $state = template_state( $hestia_tpl, 'lazysite-proxy' );
    return if $state eq 'current';
    if ( $state eq 'stale' ) {
        print "NOTE: lazysite-proxy in $hestia_tpl is STALE: it differs from this\n"
            . "      release's copy (an old one passes a visitor's X-Forwarded-For\n"
            . "      through, SM929). Refresh it, then rebuild every domain on it\n"
            . "      (the updater does both: --rebuild):\n"
            . "    cp /usr/share/lazysite-hestia/templates/lazysite-proxy.* $hestia_tpl/\n"
            . "    v-rebuild-web-domain USER DOMAIN\n";
        return;
    }
    print "NOTE: lazysite-proxy is not installed in $hestia_tpl yet; copy it\n"
        . "      first, or the front end serves gated static files directly:\n"
        . "    cp /usr/share/lazysite-hestia/templates/lazysite-proxy.* $hestia_tpl/\n";
    return;
}

# ---------- remove ----------

sub cmd_remove {
    Getopt::Long::GetOptions() or usage(2);
    my ($domain) = @ARGV;
    check_domain($domain);
    require_root('remove');

    my $did = 0;
    for my $u (
        [ 'lazysite',  pool_conf_path($domain),   'pool' ],
        [ 'lazysited', daemon_conf_path($domain), 'daemon' ],
        )
    {
        my ( $unit, $conf, $what ) = @$u;
        next unless -f $conf;

        # Best-effort stop: the unit may never have been enabled, or the
        # host may not run systemd - the config removal below is what
        # permanently retires it (ConditionPathExists in both units).
        my $systemctl = first_existing( '/usr/bin/systemctl', '/bin/systemctl' );
        if ( defined $systemctl ) {
            # SM757: the runtime's timer first, or it would start the service
            # again five minutes after this stopped it.
            system( $systemctl, 'disable', '--now', "$unit\@$domain.timer" ) == 0
                or print "==> ($what timer was not enabled)\n"
                if $unit eq 'lazysited';
            system( $systemctl, 'disable', '--now', "$unit\@$domain" ) == 0
                or print "==> ($what unit was not running/enabled)\n";
        }
        unlink $conf or fail("unlink $conf: $!");
        print "==> $what config removed: $conf\n";
        $did++;
    }
    my $entry = "$REGISTRY_DIR/$domain";
    if ( -f $entry ) {
        unlink $entry or fail("unlink $entry: $!");
        print "==> deregistered: $entry\n";
        $did++;
    }
    if ( !$did ) {
        fail( "nothing registered for '$domain' (no $entry, no pool or "
                . 'daemon config) - nothing removed' );
    }
    # The docroot is deliberately untouched: removal takes the domain off
    # lazysite's fleet tooling, it does not destroy the sysop's site.
    print "\nSite files under the docroot were NOT touched. To take the domain\n"
        . "off lazysite entirely, switch its web template back in Hestia:\n"
        . "    v-change-web-domain-tpl USER $domain default\n";
    return 0;
}

# ---------- list ----------

sub cmd_list {
    # Delegate to the CLI's fleet listing - one source of truth for the
    # registry format. No root needed.
    my $rc = system( $^X, cli_path(), 'sites' );
    exit 127 if $rc == -1;
    return $rc >> 8;
}

__END__

=head1 NAME

lazysite-hestia-domain - HestiaCP panel-side provisioning for lazysite domains

=head1 SYNOPSIS

  lazysite-hestia-domain add USER DOMAIN [--channel edge|beta|stable]
                             [--policy auto|manual] [--fcgi]
                             [--workers N] [--max-requests N] [--daemon]
  lazysite-hestia-domain remove DOMAIN
  lazysite-hestia-domain list

=head1 DESCRIPTION

The Hestia integration command shipped by the C<lazysite-hestia> package
(SM139 increment 4). It is B<root-run by design>: it is the panel-side
integrator, doing the few things only root can do on a Hestia host and
then B<dropping to the site user> (C<sudo -n -u USER>) for everything
that writes into the site tree - the SM139 principle (no root writes
into site trees) holds throughout, so ownership in the site tree is
correct by construction.

It replaces the hand-run C<installers/hestia> deploy scripts of the
tarball era; the runbook (F<installers/hestia/INSTALL-RUNBOOK.md>)
describes the full packaged onboarding.

=head1 VERBS

=over 4

=item B<add> USER DOMAIN [--channel edge|beta|stable] [--policy auto|manual] [--fcgi] [--workers N] [--max-requests N] [--daemon]

Onboard an existing Hestia web domain (create it in Hestia first). As
root it prepares the panel-specific layout: the C<plugins/>, C<tools/>
and C<lib/> siblings inside the 0551-locked domain root, and the docroot
and cgi-bin handed to C<USER:www-data> with setgid dirs so files the
site user creates inherit the web group. It then drops to USER and runs
C<lazysite provision --docroot ... --cgibin ... --domain DOMAIN>
(passing C<--channel>/C<--policy> through), tightens the secrets dirs
(C<lazysite/auth>, C<lazysite/forms>) to 2770, and writes the site
registry entry at F</etc/lazysite/sites.d/DOMAIN>.

With C<--fcgi> it also writes F</etc/lazysite/pools/DOMAIN.conf>
(C<DOCROOT=>, C<USER=>, C<GROUP=>, C<WORKERS=>, C<MAX_REQUESTS=> - the
keys C<lazysite-pool.pl> consumes) and runs
C<systemctl enable --now lazysite@DOMAIN>, giving the domain a
persistent FastCGI pool on F</run/lazysite/DOMAIN.sock>.

With C<--daemon> it also writes F</etc/lazysite/daemon/DOMAIN.conf>
(C<DOCROOT=>, C<USER=> - the keys C<lazysited@.service> consumes) and
runs C<systemctl enable --now lazysited@DOMAIN>, giving the domain its
persistent runtime (SM666). This is the host's half of two switches:
the runtime does nothing until the site's sysop enables the C<daemon>
plugin on the Plugin Manager page and names a C<daemon_job_user>
holding C<run_jobs>. With the plugin off the unit starts, exits 0 and
stays quiet, so enabling it at onboarding costs nothing.

It finishes by printing the two template-application commands
(C<v-change-web-domain-tpl USER DOMAIN lazysite-cgi|lazysite-fcgi yes>
and C<v-change-web-domain-proxy-tpl USER DOMAIN lazysite-proxy>);
applying them is deliberately left to the sysop because each forces
a Hestia vhost rebuild.

Both are needed, and the second is the one that is easy to skip. On
Hestia the request path is nginx to Apache. lazysite's access rules
live in the Apache template, while Hestia's stock nginx proxy serves a
fixed list of static B<extensions> straight off the docroot - so a
protected section gates its pages and publishes its images, PDFs and
archives, with nothing in the manager or the audit trail to say so
(SM283). C<lazysite-proxy> hands those requests back to Apache
whenever the site has an ACL store, and leaves a site without one
serving statics directly as before.

=item B<remove> DOMAIN

Stop and disable the C<lazysite@DOMAIN> pool and the C<lazysited@DOMAIN>
runtime, whichever are configured, delete their configs and the
registry entry. The docroot is B<never>
deleted - the site's files stay in place and become inert once the
domain's web template is switched back in Hestia.

=item B<list>

List the registered sites; a pass-through to C<lazysite sites>.

=back

=head1 ENVIRONMENT

C<LAZYSITE_HESTIA_HOME> (Hestia home base, default C</home> - match a
custom Hestia C<HOMEDIR>), C<LAZYSITE_REGISTRY_DIR> (default
C</etc/lazysite/sites.d>), C<LAZYSITE_POOLS_DIR> (default
C</etc/lazysite/pools>), C<LAZYSITE_DAEMON_DIR> (default
C</etc/lazysite/daemon>), C<LAZYSITE_WEB_GROUP> (default C<www-data>).

=head1 EXIT STATUS

0 on success; 1 on refusals and failures; 2 on usage errors.

=head1 SEE ALSO

lazysite(1), and F</usr/share/doc/lazysite-hestia/README.Debian> for the
3-step domain onboarding and the shipped web templates.

=cut
