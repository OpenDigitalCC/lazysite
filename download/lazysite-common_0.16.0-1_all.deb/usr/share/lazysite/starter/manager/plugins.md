---
title: Extensions
auth: manager
search: false
---

<!-- SM957: ONE MENU ENTRY, "Extensions", for two pages that were two entries:
     this one enables and disables, /manager/plugin-config configures what is
     enabled. Both addresses work and both light the same entry; each links to
     the other. Handlers left the menu by ruling and is reached from here and
     from each form on the Submissions page. -->
<div class="mg-toolbar">
  <a class="mg-btn mg-btn-sm" href="/manager/plugin-config">Configure</a>
  <a class="mg-btn mg-btn-sm" href="/manager/handlers">Handlers</a>
</div>

<div class="mg-note mg-note-info">Enable or disable extensions here. Configure an enabled extension under <a href="/manager/plugin-config">Configure</a>; choose what each form delivers to under <a href="/manager/handlers">Handlers</a>.</div>

<div id="plugin-status" class="mg-status"></div>
<div id="plugin-registry">Loading&hellip;</div>

<script>
var API = '/cgi-bin/lazysite-manager-api.pl';
// The processor publishes itself as a plugin (id 'lazysite') to expose the site
// config schema; it is the host, not a togglable plugin, so it is filtered out.
var SITE_PLUGIN_ID = 'lazysite';

// SEC-2026-07 (Low/Info): textContent->innerHTML escapes < > & but NOT quotes,
// so it was unsafe in the attribute contexts below (data-script, title, the
// onchange handler). Escape all five significant characters - attribute-safe.
function esc(s) {
  s = (s == null ? '' : String(s));
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
// SM1084: a refusal is styled as one (mg-status-error), not in the muted
// colour of a progress line.
function warn(msg, isError) {
  var el = document.getElementById('plugin-status');
  if (!el) return;
  el.textContent = msg || '';
  el.style.display = msg ? '' : 'none';
  el.classList.toggle('mg-status-error', !!(msg && isError));
}
// SM1084: A REFUSED TOGGLE SAYS WHY AT THE ROW. The reason went only to the
// status line at the top of the page, above the list, in muted text - so an
// operator toggling an extension further down saw the switch spring back and
// nothing else ("the toggle just springs back - it should explain why it wont
// enable"). The server's sentence names what is missing and how to install
// it; this puts it under the extension it is about, where the eye already is.
function showRowRefusal(input, msg) {
  var row = input.closest('.mg-plugin-row');
  var main = row && row.querySelector('.mg-plugin-main');
  if (!main) return;
  var note = main.querySelector('.mg-plugin-refusal');
  if (!note) {
    note = document.createElement('div');
    note.className = 'mg-note mg-note-danger mg-plugin-refusal';
    note.setAttribute('role', 'alert');
    main.appendChild(note);
  }
  note.textContent = msg;
}
function clearRowRefusal(input) {
  var row = input.closest('.mg-plugin-row');
  var note = row && row.querySelector('.mg-plugin-refusal');
  if (note) note.parentNode.removeChild(note);
}

function loadPluginRegistry() {
  fetch(API + '?action=extension-list').then(function (r) { return r.json(); }).then(function (data) {
    var container = document.getElementById('plugin-registry');
    if (!data.ok) { warn(data.error || 'Failed to load extensions'); container.textContent = ''; return; }
    warn('');
    var plugins = (data.plugins || []).filter(function (p) { return p.id !== SITE_PLUGIN_ID; });
    renderPluginRegistry(plugins);
  }).catch(function (e) { warn('Error: ' + e.message); document.getElementById('plugin-registry').textContent = ''; });
}

function renderPluginRegistry(plugins) {
  var container = document.getElementById('plugin-registry');
  if (!plugins.length) { container.innerHTML = '<p class="mg-empty">No extensions discovered.</p>'; return; }
  var html = '<div class="mg-list">';
  plugins.forEach(function (p) {
    // .mg-plugin-row, not the generic .mg-row: this line has THREE parts
    // (controls, name and description, the end badge) and that class carries
    // the template for them. On the two-column .mg-row the third wrapped to a
    // second implicit row and the description ran over the checkbox.
    html += '<div class="mg-plugin-row' + (p.core ? ' mg-plugin-core' : '') + '" data-script="' + esc(p._script) + '">';
    // Control column: the enable toggle, with Configure stacked beneath it when
    // enabled (so enabling never shifts the row across a column).
    html += '<div class="mg-plugin-ctl">';
    if (!p.core) {
      var checked = p._enabled ? ' checked' : '';
      // JS-string args in an attribute: JSON.stringify makes a valid literal,
      // esc() makes it safe inside the double-quoted attribute (the browser
      // decodes the entities back before the JS engine parses it).
      html += '<input type="checkbox" class="mg-toggle"' + checked
        + ' onchange="togglePlugin(this,' + esc(JSON.stringify(p._script))
        + ',' + esc(JSON.stringify(p.name)) + ')">';
      if (p._enabled) {
        html += '<a class="mg-plugin-row-config" href="/manager/plugin-config">Edit</a>';
      }
    }
    html += '</div>';
    // Main column: name + description.
    html += '<div class="mg-plugin-main">' +
      '<div class="mg-plugin-row-name">' + esc(p.name) + '</div>' +
      '<div class="mg-muted">' + esc(p.description || '') + '</div></div>';
    // End column (info only): the core badge, or an info tooltip carrying the
    // plugin details (its file is here, not cluttering the row).
    html += '<div class="mg-plugin-end">';
    if (p.core) {
      html += '<span class="mg-tag enabled" title="Always on - wired in the web server config">core</span>';
    } else {
      var info = 'File: ' + p._script + (p.version ? '  ·  v' + p.version : '') + (p.id ? '  ·  id: ' + p.id : '');
      html += '<span class="mg-info" tabindex="0" role="img" aria-label="Extension details" data-note="' + esc(info) + '">&#9432;</span>';
    }
    html += '</div></div>';
  });
  html += '</div>';
  container.innerHTML = html;
}

function togglePlugin(input, script, name) {
  var action = input.checked ? 'extension-enable' : 'extension-disable';
  input.disabled = true;
  clearRowRefusal(input);
  fetch(API + '?action=' + action, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ script: script })
  }).then(function (r) { return r.json(); }).then(function (data) {
    input.disabled = false;
    if (!data.ok) {
      input.checked = !input.checked;
      // SM711: the VERB COMES FROM THE ACTION, not from the checkbox. The line
      // above puts the checkbox back, so reading it here named the state it was
      // reverted TO - a failed enable reported "Failed to disable". An operator
      // reading that while trying to enable concludes the UI has lost track of
      // the switch, and the real reason, which is in this same banner, gets read
      // as noise. `action` was computed before the revert and is the truth.
      var why = 'Failed to ' + (action === 'extension-enable' ? 'enable' : 'disable') + ' ' + name + ': ' + (data.error || 'unknown');
      warn(why, true);
      showRowRefusal(input, why);
    } else {
      // A plugin may run a setup/teardown step with its toggle (on_enable /
      // on_disable) - its outcome IS the news, so show it here.
      var h = data.hook;
      if (h && h.message) { warn(name + ': ' + h.message); }
      else if (h && !h.ok) { warn(name + ' is toggled, but its setup step failed: ' + (h.error || 'unknown') + ' - open its config page for status.'); }
      else { warn(''); }
      loadPluginRegistry();
    }
  }).catch(function (e) {
    input.disabled = false; input.checked = !input.checked;
    warn('Error: ' + e.message, true); showRowRefusal(input, 'Error: ' + e.message);
  });
}

loadPluginRegistry();
</script>
