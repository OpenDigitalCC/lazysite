#!/usr/bin/perl
# lazysite-auth.pl - lightweight built-in auth wrapper
# Sets X-Remote-* headers from signed cookie, then execs the processor
use strict;
use warnings;
use Digest::SHA    qw(hmac_sha256_hex);
use Fcntl          qw(:flock O_RDWR O_WRONLY O_APPEND O_CREAT);
use File::Path     qw(make_path);
use File::Basename qw(dirname);
use IPC::Open2     qw(open2);

BEGIN {
    # Locate the Lazysite module tree relative to this script (run-in-place,
    # tar and Hestia installs), falling back to the system @INC (package
    # installs). No configuration needed.
    require Cwd;
    require File::Basename;
    # SM1078: then the docroot's ../lib, where install.pl puts it whatever
    # --cgibin was (one rule in every script a cgi-bin runs, t/lint/263).
    my $bin = File::Basename::dirname( Cwd::abs_path(__FILE__) );
    my $doc = $ENV{DOCUMENT_ROOT} || $ENV{REDIRECT_DOCUMENT_ROOT} || '';
    for my $cand ( "$bin/lib", "$bin/../lib", "$bin/../../lib", ( length $doc ? "$doc/../lib" : () ) ) {
        if ( -d "$cand/Lazysite" ) { unshift @INC, $cand; last }
    }
}
use Lazysite::Timing ();    # SM1144: first, so its load phase covers the modules below
use Lazysite::Util          qw(log_event request_address);
use Lazysite::Auth::Session qw(
    verify_session_cookie account_disabled load_user_groups session_store_fault
    SESSION_COOKIE_NAME SESSION_COOKIE_MAX);
use Lazysite::Paths            ();
use Lazysite::Audit            qw(audit_log);
use Lazysite::Auth::Credential qw(generate_random_hex hash_password verify_password);
use Lazysite::Auth::Settings   qw(read_settings groups_grant_cap);
use Lazysite::Auth::Verify ();                   # SM685: verify in-process, no subprocess
use Lazysite::Auth::Identity   ();    # SM1131: the proxy's user, read the readers' way
use Lazysite::Auth::LoginRate  ();    # SM1043: the sign-in rate limiter, shared
use Lazysite::I18n         qw(chrome_string);    # SM179 P8: engine-chrome i18n
$Lazysite::Util::COMPONENT = 'auth';

if ( grep { $_ eq '--describe' } @ARGV ) {
    require JSON::PP;
    print JSON::PP::encode_json( {
            id          => 'auth',
            name        => 'Built-in Auth',
            description => 'Cookie-based authentication with user and group management',
            version     => '1.0',
            # Wired in the web-server config (FallbackResource), not toggled via
            # the plugins list - the manager renders core plugins as "always on".
            core        => 1,
            config_file => '',
            config_keys => [ qw(auth_default auth_redirect auth_header_user
                    auth_header_name auth_header_email auth_header_groups
                    auth_header_groups_separator auth_group_map) ],
            config_schema => [
                { key => 'auth_default', label => 'Default auth requirement', type => 'select',
                    options => [ 'none', 'optional', 'required' ], default => 'none' },
                { key => 'auth_redirect', label => 'Login page path', type => 'text', default => '/login' },
                { key => 'auth_header_user', label => 'User header name', type => 'text', default => 'X-Remote-User' },
                { key => 'auth_header_name', label => 'Display name header', type => 'text', default => 'X-Remote-Name' },
                { key => 'auth_header_email', label => 'Email header name', type => 'text', default => 'X-Remote-Email' },
                { key => 'auth_header_groups', label => 'Groups header name', type => 'text', default => 'X-Remote-Groups' },
                { key => 'auth_header_groups_separator', label => 'Groups header separator', type => 'text', default => ',' },
                { key => 'auth_group_map', label => 'Directory group map', type => 'text', default => '' },
            ],
            actions => [
                { id => 'manage-users', label => 'Manage users', link => '/manager/users' },
            ],
    } );
    exit 0;
}

my $DOCROOT = $ENV{DOCUMENT_ROOT} || $ENV{REDIRECT_DOCUMENT_ROOT}
    or die "DOCUMENT_ROOT not set\n";
my $LAZYSITE_DIR = Lazysite::Paths::lazysite_dir($DOCROOT);    # SM293
my $AUTH_DIR     = "$LAZYSITE_DIR/auth";
Lazysite::Timing::begin(); # SM1144: the wrapper's own time, handed over at the exec below
$Lazysite::Audit::LAZYSITE_DIR         = $LAZYSITE_DIR;
$Lazysite::Auth::Settings::AUTH_DIR    = $AUTH_DIR;
$Lazysite::Auth::Session::LAZYSITE_DIR = $LAZYSITE_DIR;        # SM411

# FDO-2: lazysite.conf's lines, read once per process. Declared here, above
# the dispatch and above the first sub that reads them, so nothing is
# initialised too late (t/lint/39). See _conf_lines.
my @CONF_LINES;
my $CONF_READ = 0;

# FDO-2: one pass over lazysite.conf per request.
#
# _bad_url_guard reads the file on EVERY request, and a login then reads it
# twice more through read_conf_key (auth_redirect, manager). Same path, same
# :utf8 layer, three opens for one small file.
#
# WHY THIS IS THE SAME ANSWER. What is cached is the LINES, not a value:
# each caller still runs its own regex over the same text in the same order.
# So _bad_url_guard keeps last-match-wins over its bad_url_* keys and
# read_conf_key keeps first-match-wins for the key it was asked for - two
# different rules that stay different, which a shared key/value map would
# have quietly merged into one. A CGI process is one request, and nothing on
# this path writes lazysite.conf.
#
# _host_lang is NOT a caller: it opens the same path :raw and matches with
# \h rather than \s, so it is a different read of the same file, not a
# fourth copy of this one.
sub _conf_lines {
    return \@CONF_LINES if $CONF_READ;
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    $CONF_READ = 1;
    if ( open my $fh, '<:utf8', "$LAZYSITE_DIR/lazysite.conf" ) {
        while (<$fh>) { push @CONF_LINES, $_ }
        close $fh;
    }
    return \@CONF_LINES;
}

# Record a material authentication event in the audit trail (login/logout, claim,
# token exchange/rotate), in addition to the application log. Origin defaults to
# 'ui' (interactive browser); credential-API flows pass 'api'.
# SM641: AN ACTOR IS AN ACCOUNT, and a login attempt has not proved it is one.
#
# The trail's first field after the timestamp answers WHO. Every other surface
# fills it from an identity already established - the manager API from
# $auth_user, MCP from the bearer's resolved user, the users tool from the
# account it is acting as - and lazysite-oauth.pl passes an empty string on the
# paths where nobody has authenticated yet. This file did not: it audits a
# login failure BEFORE it knows the account exists, including on the branch
# that runs precisely because it does not, so a string of the caller's choosing
# was written into the actor column, listed as a distinct actor in the Audit
# page's filter, rendered as a link to an account that never existed, and
# forwarded to the sysop's syslog.
#
# WHY HERE AND NOT AT THE THIRTEEN CALL SITES: this is the only function in the
# product that ever holds a name nobody has proved, and it is the single writer
# for every auth event in this file. A rule at the call sites is a rule the
# fourteenth caller forgets.
#
# The attempted name is KEPT - a run against `admin`, `root` and `test` is
# worth seeing - but it moves from the field that asserts identity to the field
# that reports what was claimed.
sub _actor_or_system {
    my ( $name, $detail ) = @_;
    $name   = '' unless defined $name;
    $detail = '' unless defined $detail;

    # 'system' is this file's existing pseudo-actor (ip-auto-blocked). Passing
    # it through untouched matters: rewriting it would append a note about
    # itself to every entry it already writes.
    return ( $name, $detail ) if $name eq 'system';

  # SM1160: `odoo:<login>` is the identity of a verified Odoo-minted session. A local name
  # cannot hold a ':' (handle_login strips all but [a-zA-Z0-9_.-] before anything is
  # audited), so an attempted name can never take this form.
    return ( $name, $detail ) if $name =~ /\Aodoo:[^\x00-\x1f\x7f|]{1,254}\z/;

    return ( $name, $detail )
        if length $name
        && exists Lazysite::Auth::Settings::account_names()->{$name};

    my $note = length $name
        ? 'attempted username: ' . _safe_attempt($name)
        : 'no username supplied';
    return ( 'system', ( length $detail ? "$detail; $note" : $note ) );
}

# SANITISED MEANS BOUNDED, not merely escaped. audit_log already strips pipes
# and newlines, which protects the record FORMAT; this protects what a person
# reads. Characters an account name cannot contain are replaced ONE FOR ONE
# rather than dropped, so the length of what was tried survives - a 400-byte
# probe should not read as a short name - and the whole thing is capped.
sub _safe_attempt {
    my ($n) = @_;
    $n = '' unless defined $n;
    my $over = length($n) > 64;
    $n = substr( $n, 0, 64 ) if $over;
    $n =~ s/[^A-Za-z0-9._\@-]/?/g;
    $n .= '...' if $over;
    return $n;
}

sub _audit_auth {
    my ( $user, $act, $status, $detail, $origin ) = @_;
    ( $user, $detail ) = _actor_or_system( $user, $detail );
    # Record WHICH site (Host) the auth event happened on, so the audit says
    # where a login/logout/claim occurred rather than a bare blank target.
    my $host = lc( $ENV{HTTP_HOST} // '' );
    $host =~ s/:\d+\z//;          # strip port
    $host =~ s/[^a-z0-9.-]//g;    # keep it audit-safe
    audit_log( $user, $act, $host, _request_ip(), $status,
        $origin // 'ui', $detail );
}

# SM929: THE request address for this CGI - the visitor, not the front proxy.
# Cached: every caller below asks the same question about the same request.
#
# It cannot use read_conf_key, which returns '' for a key that is ABSENT as well
# as one that is EMPTY - and those are different states here. Absent means the
# RFC1918 default; empty means trust nothing.
{
    my $request_ip;

    sub _request_ip {
        return $request_ip if defined $request_ip;
        my $spec;
        for my $line ( @{ _conf_lines() } ) {
            if ( $line =~ /^trusted_proxies\s*:\s*(.*?)\s*$/ ) { $spec = $1; last }
        }
        $request_ip = request_address($spec);
        return $request_ip;
    }
}

# SM128: the bad-URL auto-blocker enforcement - a blocked IP is refused, and a
# probe path counts toward a block. SM1181 S1: the decision is
# Lazysite::BadUrl::guard, shared with the pool's front door (S3); this keeps the
# CGI's half, which is the 403 and the exit. Given this request's conf lines and
# THE visitor address (SM929), as it always used.
sub _bad_url_guard {
    my ($path) = @_;
    require Lazysite::BadUrl;
    _bad_url_deny()
        if Lazysite::BadUrl::guard( docroot => $DOCROOT, path => $path,
        ip => _request_ip(), conf_lines => _conf_lines() );
    return;
}

sub _bad_url_deny {
    print "Status: 403 Forbidden\r\n";
    print "Content-Type: text/plain; charset=utf-8\r\n\r\n";
    print "403 Forbidden\n";
    exit 0;
}
# SM411: the name and lifetime live in Lazysite::Auth::Session, beside the
# verifier that depends on them - this script mints with the same pair.
my $COOKIE_NAME = SESSION_COOKIE_NAME;
# SM614: the cookie's Max-Age must match what the verifier will accept, or the
# browser discards a cookie the server would still have honoured (or keeps one
# it will not). Read from the same single source rather than the constant, so
# raising session_lifetime in lazysite.conf raises both halves together.
my $COOKIE_MAX = Lazysite::Auth::Session::session_lifetime();

# H-3: login rate limiting is Lazysite::Auth::LoginRate's (SM1043); the delay
# a refused sign-in waits stays here, with the refusals that wait it.
my $LOGIN_DELAY = 2;    # seconds sleep on failure

# --- Main ---

my $method = $ENV{REQUEST_METHOD} // 'GET';
my $uri    = $ENV{REDIRECT_URL}   // '/';
my $query  = $ENV{QUERY_STRING}   // '';
my $action = '';
# Capture the FULL action token (including hyphens) so a short action like
# `rotate` does not shadow a longer one such as `rotate-auth-secret`.
$action = $1 if $query =~ /action=([a-z][a-z-]*)/;

# SM1099: THIS WRAPPER HONOURS log_level. Every request passes through it and
# its log lines go to the web server's error log; the processor has read
# log_level from lazysite.conf since it was added, and this file never did, so
# it logged at INFO whatever the site said. The env override still wins, as in
# the processor.
{
    my $lvl = read_conf_key('log_level');
    $ENV{LAZYSITE_LOG_LEVEL} = $lvl if length $lvl && !$ENV{LAZYSITE_LOG_LEVEL};
}

# SM128: bad-URL auto-blocker. Refuse a blocked IP outright and count scanner
# probes toward a block. Enabled by default; runs before the auth dispatch so it
# covers every request through the wrapper (a blocked IP cannot even try to log in).
_bad_url_guard($uri);

if ( $action eq 'login' && $method eq 'POST' ) {
    handle_login();
}
elsif ( $action eq 'logout' ) {
    handle_logout();
}
elsif ( $action eq 'claim' && $method eq 'POST' ) {
    handle_claim();
}
elsif ( $action eq 'exchange' && $method eq 'POST' ) {
    _require_token_exchange();
    handle_exchange();
}
elsif ( $action eq 'rotate' && $method eq 'POST' ) {
    _require_token_exchange();
    handle_rotate();
}
elsif ( $action eq 'forgot' && $method eq 'POST' ) {
    handle_forgot();
}
elsif ( $action eq 'unsubscribe' ) {
    handle_unsubscribe();
}
else {
    handle_request();
}

# --- Handlers ---

sub handle_login {
    my %form = parse_post();

    my $username = $form{username} // '';
    $username =~ s/[^a-zA-Z0-9_.-]//g;
    $username = substr( $username, 0, 64 ) if length($username) > 64;

    my $password = $form{password} // '';
    my $next     = sanitise_next( $form{next} // '/' );

    my $auth_redirect = read_conf_key('auth_redirect') || '/login';
    # SM929: per-VISITOR, not per-proxy. On REMOTE_ADDR this was one bucket shared
    # by everyone behind the front end, so one visitor's failures locked out all.
    my $ip = _request_ip();

    # SM1159 (L2): conf `signin_addresses` / `signin_addresses_deny` limit where a
    # sign-in may come from. The refusal is first - before the rate limiter counts the
    # attempt (a refused address is not a rate) and before the password is looked at -
    # with its own reason in the log and the audit, and a plain sentence on the page.
    require Lazysite::Auth::AddressScope;
    if ( Lazysite::Auth::AddressScope::refuse_signin( $LAZYSITE_DIR, 'web' ) ) {
        log_event( 'WARN', $username, 'sign-in refused: address not allowed', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'address-refused' );
        redirect("$auth_redirect?error=address");
        return;
    }

    # H-3: per-IP rate limit before checking credentials (fail-closed on ok).
    unless ( check_login_rate($ip) ) {
        log_event( 'WARN', $username, 'login rate limit exceeded', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'rate-limited' );
        sleep $LOGIN_DELAY;
        redirect("$auth_redirect?error=rate");
        return;
    }

    return unless _verify_credential( $username, $password, $ip, $auth_redirect );

    return unless _account_gates( $username, $ip, $auth_redirect, \%form );

    # Load groups for user
    my $groups_str = load_user_groups($username);

    my ( $cookie, $ts, $sid ) = _mint_session( $username, $groups_str );

    # SM141: record the session in the registry (listing metadata only -
    # losing the file degrades the Sessions page, never authentication).
    # A registry failure must NEVER block a valid login: eval-guard + WARN.
    eval { _session_register( $username, $ts, $sid ); 1 }
        or log_event( 'WARN', $username, 'session registry write failed', error => "$@" );

    my $secure = $ENV{HTTPS} ? '; Secure' : '';

    log_event( 'INFO', $username, 'login success', ip => _request_ip() );
    _audit_auth( $username, 'login', 'ok', '' );

    # Manager-aware landing: a recognised manager who did not come from a specific
    # page (next defaulted to home) lands in the manager UI instead of the public
    # home, so they always have a way in. Only when the manager UI is enabled.
    if ( $next eq '/'
        && ( read_conf_key('manager') // '' ) eq 'enabled'
        && _login_is_manager($groups_str) )
    {
        # SM724: the account's START PAGE, when it set one and can still reach
        # it; otherwise the manager with its own account sheet open, saying why
        # when a set page could not be honoured. Only for an arrival with no
        # destination - an explicit next was honoured above and is not here.
        # The module validates a domain target against the domains this
        # instance serves, which is why the result is not put through
        # sanitise_next: a chosen page on another of our own hosts is exactly
        # what that guard exists to refuse from a caller.
        $next = _start_page_landing($username);
    }

    binmode( STDOUT, ':utf8' );
    print "Status: 302 Found\r\n";
    print "Content-Type: text/html; charset=utf-8\r\n";    # SM353
    print "Set-Cookie: $COOKIE_NAME=$cookie; HttpOnly; SameSite=Lax; Path=/; Max-Age=$COOKIE_MAX$secure\r\n";
    # SM099: a non-HttpOnly display-only marker so client JS can show the right
    # sign-in/out control without trusting cached HTML. Carries no authority - the
    # HttpOnly cookie above remains the gate.
    print "Set-Cookie: lzs_session=1; SameSite=Lax; Path=/; Max-Age=$COOKIE_MAX$secure\r\n";
    print "Location: $next\r\n\r\n";
    return;
}

# FD-25: handle_login's credential half - the username shape, the users
# file, the localhost-only no-password branch and the H-2 password check
# with its legacy rehash, in the order handle_login ran them.
#
# Every refusal answers the request itself, with the audit reason and the
# delay that refusal carried before; the caller returns without adding
# anything. True means the credential is good and the account gates are
# next.
sub _verify_credential {
    my ( $username, $password, $ip, $auth_redirect ) = @_;

    unless ( length $username ) {
        log_event( 'WARN', $username, 'login failed', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'invalid-credentials' );
        sleep $LOGIN_DELAY;
        redirect("$auth_redirect?error=1");
        return 0;
    }

    my $users    = load_users();
    my $expected = $users->{$username};

    unless ( defined $expected ) {
        log_event( 'WARN', $username, 'login failed', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'invalid-credentials' );
        sleep $LOGIN_DELAY;
        redirect("$auth_redirect?error=1");
        return 0;
    }

    if ( !length $expected ) {
        # No-password account: only allowed from localhost.
        #
        # SM929 LEAVES THIS ON REMOTE_ADDR DELIBERATELY. It does not ask who the
        # visitor is, it asks whether the PEER is this machine - and the answer
        # must come from the connection, never from a header a proxy could carry
        # or a visitor could write. docs/architecture/security.md says in those
        # words that only the immediate remote address matters here.
        my $addr = $ENV{REMOTE_ADDR} // '';
        unless ( $addr eq '127.0.0.1' || $addr eq '::1' ) {
            # SM798: ANSWER EXACTLY AS A WRONG PASSWORD DOES. This used to
            # send a 403 explaining that the account has no password, while
            # an absent user and a wrong password both got 302 ?error=1 - so
            # the one response that differed identified an account that
            # exists AND is in the state the engine most discourages. The
            # explanation was real and it is not lost: it is in the log and
            # the audit trail, where the operator can reach it and an
            # unauthenticated caller cannot.
            #
            # THE SLEEP IS PART OF THE FIX, not decoration. The other two
            # refusals pause for $LOGIN_DELAY and this path did not, so
            # matching only the status would have swapped one oracle for a
            # slower, quieter one.
            log_event( 'WARN', $username, 'no-password login refused (not localhost)', ip => $addr );
            _audit_auth( $username, 'login', 'fail', 'no-password-remote' );
            sleep $LOGIN_DELAY;
            redirect("$auth_redirect?error=1");
            return 0;
        }
        log_event( 'INFO', $username, 'no-password login (localhost)', ip => $addr );
        _audit_auth( $username, 'login', 'ok', 'no-password' );
    }
    else {
        # H-2: verify_password handles both legacy (unsalted) and new
        # (sha256iter) formats. Legacy hashes are auto-rehashed on
        # successful login.
        unless ( length $password && verify_password( $password, $expected ) ) {
            log_event( 'WARN', $username, 'login failed', ip => $ip );
            _audit_auth( $username, 'login', 'fail', 'invalid-credentials' );
            sleep $LOGIN_DELAY;
            redirect("$auth_redirect?error=1");
            return 0;
        }
        if ( $expected =~ /\A[0-9a-f]{64}\z/ ) {
            my $new_hash = hash_password($password);
            if ( update_user_hash( $username, $new_hash ) ) {
                log_event( 'INFO', $username, 'password rehashed to salted format' );
            }
        }
    }
    return 1;
}

# FD-25: the five account gates a verified credential still has to pass,
# in the order handle_login ran them - disabled, credential expired,
# account expired, interactive-ui, second factor.
#
# THE ORDER IS THE SECURITY PROPERTY: every one of these sits after the
# credential check so that none of them tells a password guesser anything
# about an account it cannot open. The comments moved with the gates they
# describe. Each refusal answers the request itself; true means a cookie
# may now issue.
sub _account_gates {
    my ( $username, $ip, $auth_redirect, $form ) = @_;

    # SM070: enforce the per-user `ui` access mechanism. Placed after
    # credential verification (both the verified-password and the
    # localhost no-password branches converge here), so it leaks
    # nothing to a password guesser - an attacker without the password
    # never reaches it. A ui-disabled account never receives a cookie,
    # which keeps it out of the manager UI, the manager API, and
    # auth-protected pages alike.
    # SM071 Phase 2: a disabled account fails authentication outright,
    # ahead of the ui mechanism check. After credential verification, so
    # it leaks nothing to a password guesser.
    # SM1024 (ruled 2026-10-12, "Close all three"): first, can the engine tell?
    # A user-settings.json or revoked.json that exists and cannot be read or
    # decoded refuses every sign-in until it is repaired - cannot-tell, the
    # answer the API doors give - rather than "disabled" (or, before, a cookie
    # for an account the broken store may have disabled). The page says sign-in
    # is unavailable; the log names the file, and so does `lazysite check`.
    if ( my $store = session_store_fault() ) {
        log_event( 'WARN', $username, 'login refused: cannot tell - a session store cannot be read',
            store => $store, ip => $ip,
            repair => 'lazysite check --docroot <docroot> names it; repair or restore the file' );
        _audit_auth( $username, 'login', 'fail', "cannot-tell: $store" );
        redirect("$auth_redirect?error=unavailable");
        return 0;
    }
    if ( account_disabled($username) ) {
        log_event( 'WARN', $username, 'login refused: account disabled', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'account-disabled' );
        redirect("$auth_redirect?error=1");
        return 0;
    }

    # SM071 Phase 2: an expired access-token credential cannot start a
    # session (a human password has no expiry, so this never affects them).
    if ( token_expired($username) ) {
        log_event( 'WARN', $username, 'login refused: credential expired', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'credential-expired' );
        redirect("$auth_redirect?error=1");
        return 0;
    }

    # SM072: account-level expiry (time-boxed access)
    if ( account_expired($username) ) {
        log_event( 'WARN', $username, 'login refused: account expired', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'account-expired' );
        redirect("$auth_redirect?error=1");
        return 0;
    }

    unless ( ui_enabled($username) ) {
        log_event( 'WARN', $username, 'interactive login disabled for account', ip => $ip );
        _audit_auth( $username, 'login', 'fail', 'ui-disabled' );
        reject_ui_disabled();
        return 0;
    }

    # SM072 batch 4: second factor. If TOTP is enrolled, a valid code (or a
    # single-use recovery code) is required before a cookie issues. After
    # password + ui verification, so it leaks nothing to a password guesser.
    if ( mfa_enrolled($username) ) {
        my $code = $form->{code} // '';
        $code =~ s/[^0-9A-Za-z-]//g;
        my $v = users_tool_api( { action => 'mfa-verify', username => $username, code => $code } );
        unless ( ref $v eq 'HASH' && $v->{ok} ) {
            log_event( 'WARN', $username, 'login refused: 2FA required or invalid', ip => $ip );
            _audit_auth( $username, 'login', 'fail', 'mfa' );
            sleep $LOGIN_DELAY;
            redirect("$auth_redirect?error=mfa");
            return 0;
        }
    }
    return 1;
}

# FD-25: mint the signed session cookie. SM141: the payload carries a short
# random session id (user:ts:sid:groups) so this session can be listed and
# revoked individually. Legacy 3-field cookies (user:ts:groups) minted
# before SM141 stay valid until natural expiry - see handle_request.
#
# Returns ( $cookie, $ts, $sid ): the caller needs the last two for the
# session registry.
sub _mint_session {
    my ( $username, $groups_str ) = @_;
    my $ts      = time();
    my $sid     = generate_random_hex(8);                 # 16 hex chars
    my $secret  = load_auth_secret();
    my $payload = "$username:$ts:$sid:$groups_str";
    my $sig     = hmac_sha256_hex( $payload, $secret );
    return ( uri_encode_simple($payload) . ":$sig", $ts, $sid );
}

# Verify the session cookie and return ( $user, $sid ) - $sid is '' for a
# legacy (pre-SM141) user:ts:groups cookie. Returns ( '', '' ) on any failure.
#
# SM411: delegates to the one verification chain in Lazysite::Auth::Session.
# This is deliberately STRICTER than the sub it replaces, which skipped the
# disabled-account and revoked-session checks: a disabled account's logout is
# now the unauthenticated no-op path (the cookie still clears), and a revoked
# session cannot re-revoke itself. Neither loses anything a user could want.
sub _session_identity {
    # SM1160: a signed-out Odoo-minted session is revoked even when it has gone stale
    my ($ident) = verify_session_cookie( odoo_stale_ok => 1 );
    return ( '',             '' ) unless $ident;
    return ( $ident->{user}, $ident->{sid} );
}

sub handle_logout {
    my ( $user, $sid ) = _session_identity();
    # Only audit a real logout (a valid session). An unauthenticated hit on
    # ?action=logout - common from vulnerability scanners - must write no audit
    # noise; and a genuine logout now records the actual username (not the empty
    # HTTP_X_REMOTE_USER it used to read on this direct call).
    if ( length $user ) {
        log_event( 'INFO', $user, 'logout', ip => _request_ip() );
        _audit_auth( $user, 'logout', 'ok', '' );

        # SEC-2026-07 (M4): actually invalidate the session server-side, not just
        # clear the browser cookie - otherwise a cookie captured before logout
        # keeps authenticating for the full 24h TTL. Add this sid to the revoked
        # set (the same mechanism an operator's session-revoke uses; enforced in
        # the cookie-verify path above). A legacy cookie carries no sid, so it
        # cannot be revoked individually - it still ages out at COOKIE_MAX.
        if ( length $sid ) {
            # SM557: the package is require'd at runtime, so this file mentions the
            # variable once by design - t/lint/04 refuses the 'used only once' warning.
            no warnings 'once';
            require Lazysite::Manager::Sessions;
            local $Lazysite::Manager::Sessions::LAZYSITE_DIR = $LAZYSITE_DIR;
            local $Lazysite::Manager::Sessions::auth_user    = $user;
            my $r = Lazysite::Manager::Sessions::action_session_revoke($sid);
            log_event( 'WARN', $user, 'logout: session revoke failed',
                error => $r->{error} )
                if ref $r eq 'HASH' && !$r->{ok};
        }
    }

    my $secure = $ENV{HTTPS} ? '; Secure' : '';

    binmode( STDOUT, ':utf8' );
    print "Status: 302 Found\r\n";
    print "Content-Type: text/html; charset=utf-8\r\n";                           # SM353
    print "Set-Cookie: $COOKIE_NAME=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0$secure\r\n";
    print "Set-Cookie: lzs_session=; SameSite=Lax; Path=/; Max-Age=0$secure\r\n"; # SM099 marker
    print "Location: /logout\r\n\r\n";
}

# SM072: public claim redemption. The holder of a single-use setup/reset
# claim sets their own credential here - the operator never sees it. The
# claim token IS the authentication; we shell to the (tested) users-tool
# claim-redeem, which returns ONE generic error on any failure.
sub handle_claim {
    my %form     = parse_post();
    my $username = $form{username} // '';
    $username =~ s/[^a-zA-Z0-9_.-]//g;
    $username = substr( $username, 0, 64 ) if length($username) > 64;
    my $claim = $form{claim} // '';
    $claim =~ s/[^a-zA-Z0-9_]//g;
    my $password = $form{password} // '';
    # SM929: two different questions, two values. _secure_transport asks whether
    # the PEER is local (so plaintext is a dev loopback, not an exposed one); the
    # rate limit asks who the VISITOR is.
    my $peer = $ENV{REMOTE_ADDR} // '';
    my $ip   = _request_ip();

    # HTTPS-only (setting a secret); localhost allowed for dev/CLI.
    #
    # P7 (WORK-PLAN-0154): ITS OWN ANSWER. This shared error=1 with a bad or
    # used link, so the page said the link had expired and the person asked for
    # another, which failed the same way. Refused before the link or the
    # account is looked at, so error=https says nothing about either.
    unless ( _secure_transport($peer) ) {
        log_event( 'WARN', $username, 'claim over plaintext refused', ip => $ip );
        redirect("/claim?u=$username&error=https");
        return;
    }

    # H-3: reuse the per-IP login rate limiter.
    unless ( check_login_rate($ip) ) {
        sleep $LOGIN_DELAY;
        redirect("/claim?u=$username&error=1");
        return;
    }

    my $r = users_tool_api( {
            action => 'claim-redeem', username => $username,
            claim  => $claim,         password => $password,
    } );

    # SM1041: a valid link with a password the policy refuses. The claim is not
    # spent, so the page offers the form again and says how long a password
    # must be - the length is the site's policy, not a fact about the account,
    # and the claim has already proved who is asking.
    if ( ref $r eq 'HASH' && !$r->{ok} && ( $r->{field} // '' ) eq 'password' ) {
        my $min = ( $r->{min} // '' ) =~ /\A(\d{1,3})\z/ ? $1 : '';
        log_event( 'INFO', $username, 'claim refused: password too short', ip => $ip );
        _audit_auth( $username, 'claim-redeem', 'fail', 'password-policy' );
        redirect("/claim?u=$username&c=$claim&error=short&min=$min");
        return;
    }

    unless ( ref $r eq 'HASH' && $r->{ok} ) {
        sleep $LOGIN_DELAY;
        log_event( 'WARN', $username, 'claim redeem failed', ip => $ip );
        _audit_auth( $username, 'claim-redeem', 'fail', '' );
        redirect("/claim?u=$username&error=1");
        return;
    }

    log_event( 'INFO', $username, 'claim redeemed', ip => $ip );
    _audit_auth( $username, 'claim-redeem', 'ok', '' );
    if ( $r->{token} ) {
        claim_token_page( $username, $r->{token} );    # machine: show token once
    }
    else {
        my $auth_redirect = read_conf_key('auth_redirect') || '/login';
        redirect("$auth_redirect?claimed=1");          # human: go sign in
    }
    return;
}

# Show a freshly-minted token once (a mint-token claim was redeemed).
sub claim_token_page {
    my ( $user, $token ) = @_;
    $user  =~ s/[^a-zA-Z0-9_.-]//g;
    $token =~ s/[^a-zA-Z0-9_]//g;
    binmode( STDOUT, ':utf8' );
    print "Status: 200 OK\r\n";
    print "Content-Type: text/html; charset=utf-8\r\n\r\n";
    print <<"HTML";
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Credential</title></head>
<body style="font-family:system-ui,sans-serif;max-width:560px;margin:3em auto;padding:0 1em;">
<h1 style="font-size:1.3rem;">Your credential for $user</h1>
<p>Store this now &mdash; it is shown once and cannot be retrieved again. Use it
as the password for WebDAV / API requests (username: <code>$user</code>).</p>
<p style="font-family:ui-monospace,Menlo,Consolas,monospace;background:#f0f0f0;padding:0.6em 0.8em;border-radius:4px;word-break:break-all;">$token</p>
</body></html>
HTML
    return;
}

# Locate the users tool (same candidates as the manager API).
sub _users_tool_path {
    for my $c (
        $ENV{LAZYSITE_USERS_TOOL},
        dirname($0) . "/../tools/lazysite-users.pl",
        "$DOCROOT/../tools/lazysite-users.pl",
    ) {
        return $c if defined $c && -f $c;
    }
    return undef;
}

# Invoke the users tool in --api mode with a JSON payload; return the
# decoded response (or undef on any failure).
sub users_tool_api {
    my ($payload) = @_;
    my $tool = _users_tool_path() or return undef;
    require JSON::PP;
    my ( $out, $in );
    local $SIG{PIPE} = 'IGNORE';    # SM959: a child that exits early must not kill us
    my $pid = eval { open2( $out, $in, $^X, $tool, '--api', '--docroot', $DOCROOT ) };
    return undef unless $pid;
    print $in JSON::PP::encode_json($payload);
    close $in;
    my $resp = do { local $/; <$out> };
    close $out;
    waitpid $pid, 0;
    return eval { JSON::PP::decode_json( $resp // '{}' ) };
}

# Service killswitch (0.9.0): the AI-partner token surface (pairing-key exchange
# + token rotation) is OFF unless the operator enables it in lazysite.conf
# (token_exchange_enabled: true), mirroring webdav_enabled. Default off; opt in
# from the Services page.
sub _require_token_exchange {
    return if Lazysite::Util::service_enabled( $DOCROOT, 'token_exchange_enabled' );
    # NOT 404: a 404 reads as "endpoint absent / not deployed" and sent a real
    # field diagnosis down the wrong path (redeploy, re-check routing) when the
    # feature was merely switched off. Match the control API's shape - a 200 body
    # with ok:0 + a stable machine-readable code - so a client branches on the
    # payload, never on a misleading status.
    json_response( { ok => 0, code => 'service_disabled',
            error => 'Token exchange is not enabled on this site '
                . '(ask the operator to enable it: Services -> AI partner tokens).' }, 200 );
    exit 0;
}

# Emit a JSON body with an HTTP status (the control token-lifecycle paths).
sub json_response {
    my ( $data, $code ) = @_;
    $code ||= 200;
    require JSON::PP;
    binmode( STDOUT, ':utf8' );
    print "Status: $code\r\n";
    print "Content-Type: application/json; charset=utf-8\r\n\r\n";
    print JSON::PP::encode_json($data);
    return;
}

# SM072 Flow C: public pairing-key -> access-token exchange. The agent
# presents its single-use pairing key and receives {token, expires_at}.
sub handle_exchange {
    my %form     = parse_post();
    my $username = $form{username} // '';
    $username =~ s/[^a-zA-Z0-9_.-]//g;
    my $key = $form{pairing_key} // $form{key} // '';
    $key =~ s/[^a-zA-Z0-9_]//g;
    # SM929: the peer for the transport check, the visitor for the rate limit.
    my $peer = $ENV{REMOTE_ADDR} // '';
    my $ip   = _request_ip();

    unless ( _secure_transport($peer) ) {
        json_response( { ok => 0, error => 'HTTPS required' }, 403 );
        return;
    }
    unless ( check_login_rate($ip) ) {
        sleep $LOGIN_DELAY;
        json_response( { ok => 0, error => 'Too many attempts' }, 429 );
        return;
    }

    my $r = users_tool_api( {
            action => 'token-exchange', username => $username, pairing_key => $key,
    } );
    unless ( ref $r eq 'HASH' && $r->{ok} ) {
        sleep $LOGIN_DELAY;
        log_event( 'WARN', $username, 'pairing exchange failed', ip => $ip );
        json_response( { ok => 0, error => 'Invalid or expired pairing key' }, 401 );
        return;
    }
    log_event( 'INFO', $username, 'access token issued (HTTP exchange)', ip => $ip );
    _audit_auth( $username, 'token-exchange', 'ok', '', 'api' );
    json_response( { ok => 1, token => $r->{token}, expires_at => $r->{expires_at} }, 200 );
    return;
}

# SM072 Flow C: rotate the access token. The agent authenticates with its
# CURRENT token (Basic auth) and receives a fresh {token, expires_at}.
sub handle_rotate {
    # SM929: the PEER answers whether the transport is safe; the VISITOR is what
    # the two log lines below are about.
    my $peer = $ENV{REMOTE_ADDR} // '';
    my $ip   = _request_ip();
    unless ( _secure_transport($peer) ) {
        json_response( { ok => 0, error => 'HTTPS required' }, 403 );
        return;
    }
    my ( $u, $token );
    if ( ( $ENV{HTTP_AUTHORIZATION} // '' ) =~ /^Basic\s+(\S+)/ ) {
        require MIME::Base64;
        ( $u, $token ) = split /:/, ( MIME::Base64::decode_base64($1) // '' ), 2;
    }
    unless ( defined $u && length $u && defined $token && $token =~ /^lzs_/ ) {
        json_response( { ok => 0, error => 'Token authentication required' }, 401 );
        return;
    }
    $u =~ s/[^a-zA-Z0-9_.-]//g;
    unless ( check_login_rate($ip) ) {
        sleep $LOGIN_DELAY;
        json_response( { ok => 0, error => 'Too many attempts' }, 429 );
        return;
    }
    # SM685: verified IN THIS PROCESS. Every authenticated request used to
    # spawn a perl interpreter and compile the whole of lazysite-users.pl -
    # three thousand statements - to answer one question. The subprocess was
    # never needed for privilege reasons here: the module reads the same
    # files this CGI can already read, as the same user.
    # A deployment that NOMINATES a users tool (LAZYSITE_USERS_TOOL) has
    # nominated the authority on credentials - ask it. Otherwise verify in
    # process: SM685 takes the subprocess off the DEFAULT path, which is the
    # one every site runs. The choice is made HERE and never inside the module,
    # because the module is also loaded inside the tool - and a tool that
    # consults the variable naming itself spawns itself, without limit.
    my $v
        = $ENV{LAZYSITE_USERS_TOOL}
        ? users_tool_api(
        { action => 'verify-credential', username => $u, secret => $token } )
        : Lazysite::Auth::Verify::verify_credential( $DOCROOT, $u, $token );
    unless ( ref $v eq 'HASH' && $v->{ok} ) {
        sleep $LOGIN_DELAY;
        # An EXPIRED (but correct) token can't rotate itself - the agent must
        # re-exchange a fresh pairing key. Give that guidance instead of a bare
        # "Invalid token" (the diagnosis a partner agent had to do by hand).
        if ( ref $v eq 'HASH' && ( $v->{reason} // '' ) eq 'expired' ) {
            log_event( 'INFO', $u, 'token rotation: token expired', ip => $ip );
            json_response( {
                    ok     => 0,
                    reason => 'expired',
                    error  => 'Your access token has expired and cannot be rotated. '
                        . 'Ask the sysop for a new pairing key and exchange it '
                        . '(POST action=exchange with the pairing key).',
            }, 401 );
            return;
        }
        log_event( 'WARN', $u, 'token rotation: invalid current token', ip => $ip );
        json_response( { ok => 0, error => 'Invalid token' }, 401 );
        return;
    }
    my $r = users_tool_api( { action => 'token-rotate', username => $u } );
    unless ( ref $r eq 'HASH' && $r->{ok} ) {
        json_response( { ok => 0, error => 'Rotation failed' }, 500 );
        return;
    }
    log_event( 'INFO', $u, 'access token rotated (HTTP)', ip => $ip );
    _audit_auth( $u, 'token-rotate', 'ok', '', 'api' );
    json_response( { ok => 1, token => $r->{token}, expires_at => $r->{expires_at} }, 200 );
    return;
}

# SM072 batch 2: forgot-password. Mint a set-password claim and email the
# link to the account's registered address - gated on SMTP being configured
# and the account having an email. ALWAYS a generic response, so it cannot
# enumerate accounts or emails.
sub handle_forgot {
    my %form  = parse_post();
    my $ident = $form{identifier} // $form{username} // $form{email} // '';
    $ident =~ s/^\s+|\s+$//g;
    my $ip            = _request_ip();    # SM929: per visitor, not per proxy
    my $auth_redirect = read_conf_key('auth_redirect') || '/login';

    if ( check_login_rate($ip) ) {
        eval { _forgot_dispatch( $ident, $ip ); 1 };
    }
    else { sleep $LOGIN_DELAY }

    redirect("$auth_redirect?reset=1");    # generic, always
    return;
}

sub _forgot_dispatch {
    my ( $ident, $ip ) = @_;
    return unless length $ident;

    # SM136: without SMTP the self-service email can't go out, so this request
    # would otherwise dead-end silently while a person waits. Tell the operators
    # (bell + XMPP if configured) so a human can respond. Real accounts only -
    # an unknown identifier stays generic (no notice, no enumeration signal).
    unless ( -f "$LAZYSITE_DIR/forms/smtp.conf" ) {
        my ($user) = _resolve_account($ident);
        if ( $user && !account_disabled($user) ) {
            require Lazysite::Notify;
            Lazysite::Notify::notify( $DOCROOT, {
                    type    => 'reset-request',
                    message => "Password reset requested for '$user' - no SMTP is "
                        . 'configured, so no email was sent. Issue them a setup link '
                        . 'from the Users page.',
                    target => $user,
                    url    => "/manager/users?user=$user",
            } );
            _audit_auth( $user, 'forgot', 'ok', 'reset requested; no SMTP - sysops notified', 'ui' );
        }
        return;
    }

    my ( $user, $email ) = _resolve_account($ident);
    return unless $user && $email;
    return if account_disabled($user);
    return unless ui_enabled($user);    # interactive accounts only

    my $r = users_tool_api( { action => 'claim-create', username => $user } );
    return unless ref $r eq 'HASH' && $r->{ok} && $r->{claim};

    my $scheme = $ENV{HTTPS} ? 'https' : 'http';
    my $host   = $ENV{HTTP_HOST} // '';
    _send_setup_email( $email, $user, "$scheme://$host/claim?u=$user&c=$r->{claim}" );
    log_event( 'INFO', $user, 'forgot-password claim emailed', ip => $ip );
    # SM072: a real reset link was issued - a material auth event. (The HTTP
    # response stays generic; only the internal audit trail records the match.)
    _audit_auth( $user, 'forgot', 'ok', 'reset link emailed', 'ui' );
    return;
}

# SM1073 (SM1010 R4, ruled "Per rule, default on"; SM1034 Q1: the session-less
# unsubscribe goes on the auth CGI): ONE CLICK STOPS ONE RULE WRITING TO ONE
# RECIPIENT, with no sign-in.
#
# The link in every message of a notify rule, and its List-Unsubscribe header,
# is ?action=unsubscribe&t=<token>. The token is the whole of its authority -
# Lazysite::Unsubscribe says how it is made unguessable and bound to its own
# rule and recipient - so this reads nothing else from the request.
#
#   GET   a page asking to confirm, and changes nothing: mail scanners fetch
#         links, and a fetch must not unsubscribe anyone.
#   POST  records the stop (idempotent) and says so. A mail client's RFC 8058
#         one-click POST (body List-Unsubscribe=One-Click) is the same request.
#
# Every POST is audited: a stop, a repeat, and a token that does not verify.
# The audit names the rule and the recipient's hash, never an address.
sub handle_unsubscribe {
    my %q;
    for my $pair ( split /[&;]/, $query ) {
        my ( $k, $v ) = split /=/, $pair, 2;
        next unless defined $k && defined $v;
        $v =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
        $q{$k} //= $v;
    }
    my %body;
    if ( $method eq 'POST' ) {
        return _unsubscribe_page( 413, 'Too large', 'This request is larger than an unsubscribe can be.' )
            if ( $ENV{CONTENT_LENGTH} // 0 ) > 4096;
        %body = parse_post();
    }
    my $token = $q{t} // $body{t} // '';
    require Lazysite::Unsubscribe;
    my ( $rule, $p ) = Lazysite::Unsubscribe::verify( $DOCROOT, $token );
    unless ( defined $rule ) {
        audit_log( '', 'unsubscribe', 'notify', _request_ip(), 'denied', 'ui', 'the link is not valid' )
            if $method eq 'POST';
        return _unsubscribe_page( 400, 'This link is not valid',
            'This unsubscribe link is not one this site made, or it has been withdrawn. '
                . 'Nothing was changed.' );
    }
    my $name = _rule_name($rule);
    if ( $method ne 'POST' ) {
        my $stopped = Lazysite::Unsubscribe::suppressed($DOCROOT);
        return _unsubscribe_page( 200, 'Already stopped',
            "You have already stopped the messages from \x{201c}$name\x{201d}. Nothing more is needed." )
            if $stopped && $stopped->{"$rule\0$p"};
        return _unsubscribe_page( 200, 'Stop these messages?',
            "Stop the messages from \x{201c}$name\x{201d} to this address? Other messages from this site "
                . 'are not affected.', $token );
    }
    my ( $done, $why ) = Lazysite::Unsubscribe::record( $DOCROOT, $rule, $p );
    unless ( defined $done ) {
        audit_log( '', 'unsubscribe', "notify:$rule", _request_ip(), 'failed', 'ui', "recipient $p - $why" );
        log_event( 'ERROR', 'unsubscribe', 'an unsubscribe could not be recorded', rule => $rule, error => $why );
        return _unsubscribe_page( 503, 'Not recorded yet',
            'Your request could not be recorded just now. Please try the link again later.' );
    }
    audit_log( '', 'unsubscribe', "notify:$rule", _request_ip(), 'ok', 'ui',
        "recipient $p" . ( $done eq 'already' ? ' - already stopped' : '' ) );
    # SM1106 (0.15.6 test plan R3): a repeat POST showed the same "Unsubscribed"
    # page as the first, so a person who followed the link twice (or a mail
    # client that re-posted) was told it had just been done again. It is the
    # GET's answer for a stop already recorded; still 200, nothing written.
    return _unsubscribe_page( 200, 'Already stopped',
        "You have already stopped the messages from \x{201c}$name\x{201d}. Nothing more is needed." )
        if $done eq 'already';
    return _unsubscribe_page( 200, 'Unsubscribed',
        "You will get no more messages from \x{201c}$name\x{201d}." );
}

# The rule's name as its handler gives it, else its id - for the page only.
sub _rule_name {
    my ($rule) = @_;
    my $name = eval {
        require Lazysite::Handlers;
        no warnings 'once';
        local $Lazysite::Handlers::DOCROOT = $DOCROOT;
        my $h = Lazysite::Handlers::find_handler( Lazysite::Handlers::read_handlers() || [], $rule );
        $h && length( $h->{name} // '' ) ? $h->{name} : undef;
    };
    return $name // $rule;
}

# A page of its own: no layout, no script, no stylesheet, no outside resource -
# and no Referer, because the URL that reached it carries the token.
sub _unsubscribe_page {
    my ( $code, $title, $text, $token ) = @_;
    my $esc = sub {
        my $s = shift // '';
        $s =~ s/&/&amp;/g;
        $s =~ s/</&lt;/g;
        $s =~ s/>/&gt;/g;
        $s =~ s/"/&quot;/g;
        $s =~ s/'/&#39;/g;
        return $s;
    };
    my $form = defined $token
        ? '<form method="post" action="?action=unsubscribe&amp;t=' . $esc->($token) . '">'
        . '<button type="submit" name="confirm" value="1">Stop these messages</button></form>'
        : '';
    binmode( STDOUT, ':utf8' );
    print "Status: $code\r\n";
    print "Content-Type: text/html; charset=utf-8\r\n";
    print "Cache-Control: no-store\r\n";
    print "Referrer-Policy: no-referrer\r\n";
    print "X-Robots-Tag: noindex\r\n";
    print "Content-Security-Policy: default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'\r\n\r\n";
    print '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<meta name="robots" content="noindex"><title>' . $esc->($title) . '</title></head>'
        . '<body><main><h1>' . $esc->($title) . '</h1><p>' . $esc->($text) . "</p>$form</main></body></html>\n";
    return;
}

# Resolve a username or email to (username, email) from user-settings.json.
sub _resolve_account {
    my ($ident) = @_;
    my $path = "$AUTH_DIR/user-settings.json";
    return () unless -f $path;
    # ALL user-settings.json readers in this file open :raw - decode_json
    # takes octets, and a :utf8 handle made it die on any non-ASCII byte,
    # silently failing every gate below OPEN (2026-07-10 review, D1).
    open my $fh, '<:raw', $path or return ();
    my $raw = do { local $/; <$fh> };
    close $fh;
    require JSON::PP;
    my $data = eval { JSON::PP::decode_json( $raw // '{}' ) } || {};
    return () unless ref $data eq 'HASH';
    if ( $ident =~ /\@/ ) {
        for my $u ( sort keys %$data ) {
            my $s = $data->{$u};
            return ( $u, $s->{email} )
                if ref $s eq 'HASH' && lc( $s->{email} // '' ) eq lc($ident);
        }
        return ();
    }
    $ident =~ s/[^a-zA-Z0-9_.-]//g;
    my $s = $data->{$ident};
    return () unless ref $s eq 'HASH' && $s->{email};
    return ( $ident, $s->{email} );
}

# Send the setup link by invoking the form-smtp plugin (--pipe).
sub _send_setup_email {
    my ( $to, $user, $link ) = @_;
    my $smtp;
    for my $c ( dirname($0) . "/../plugins/form-smtp.pl",
        "$DOCROOT/../plugins/form-smtp.pl",
        "$DOCROOT/plugins/form-smtp.pl" ) {
        if ( -f $c ) { $smtp = $c; last }
    }
    return unless $smtp;
    require JSON::PP;
    my $payload = JSON::PP::encode_json( {
            config => { to => $to, subject_prefix => 'Set your password - ' },
            form   => { message =>
                    "A password setup link was requested for '$user'.\n\n"
                    . "Open this one-time link (it expires in 24 hours) to set your password:\n\n"
                    . "$link\n\n"
                    . "If you did not request this, you can ignore this email." },
    } );
    my ( $out, $in );
    local $SIG{PIPE} = 'IGNORE';    # SM959: a child that exits early must not kill us
    my $pid = eval { open2( $out, $in, $^X, $smtp, '--pipe' ) };
    return unless $pid;
    print $in $payload;
    close $in;
    do { local $/; <$out> };
    close $out;
    waitpid $pid, 0;
    return;
}

sub handle_request {
    # SM411: one verification chain, in Lazysite::Auth::Session, shared with
    # every surface that must turn a cookie into an identity without being
    # behind this wrapper (the SM402 lesson: the form handler trusted
    # X-Remote-User as the client sent it because it had no way to verify).
    # This wrapper keeps its per-stage log lines - they are how auth failures
    # have always been diagnosed - and the success block keeps setting the
    # trusted headers the children consume.
    #
    # SM1130: UNDER PROXY TRUST THE PROXY'S IDENTITY WINS. With
    # auth_proxy_trusted on, the peer listed in auth_proxy_trusted_from (SM1129,
    # the same Lazysite::Util::proxy_identity every reader asks) and the request
    # carrying a user, the directory has said who this is. The success block
    # below used to overwrite X-Remote-User/Groups with a valid cookie's identity,
    # so a stale local session - a day-old login of someone since removed from the
    # directory, or of someone else on a shared browser - beat the directory. The
    # cookie is not consulted at all: no merge, no fallback to it. A request with
    # NO proxy user keeps today's cookie behaviour (a site may use both), and the
    # processor and manager API believe the proxy's headers by the same function.
    #
    # SM1131: and the proxy's USER is read by the one identity reader, under the
    # configured name, with this request's proxy answer - the same name every
    # reader downstream will read. The wrapper used to try X-Remote-User first and
    # the configured name second, so on a site that renamed its proxy header a
    # client-sent X-Remote-User the proxy passed through set the cookie aside for a
    # user no reader would then see. With no proxy user the cookie path below sets
    # the FIXED names and LAZYSITE_AUTH_TRUSTED, which the reader reads as the
    # cookie's identity: the two rules are one rule.
    #
    # SM1181 S1 (SM1082 C2, R2): the rule is Lazysite::Auth::Session::request_session
    # now - this wrapper, the data endpoint and the pool's front door ask the one
    # function, so none of them can come to decide differently (T10,
    # t/integration/290). The proxy answer is asked here, once, and passed in; the
    # cookie is passed as the header it is. What this wrapper writes for the surface
    # it execs is Lazysite::Auth::Identity::write_identity_env's contract, made
    # from the value: user, groups, the sentinel, the SM794 clears, the Odoo name,
    # the sid and the passwordless flag.
    my $pid = Lazysite::Util::proxy_identity($LAZYSITE_DIR);
    my ( $ident, $why, %detail ) = Lazysite::Auth::Session::request_session(
        lazysite_dir => $LAZYSITE_DIR, proxy => $pid, cookie => $ENV{HTTP_COOKIE} // '' );

    # A cookie identity is written for the surface this execs. C-1: these headers
    # come from our HMAC-verified cookie, not from the client; the sentinel tells
    # the processor so. SEC-2026-07 (M5): the groups are the verifier's FRESH
    # resolution, never the set baked into the cookie at login. SM794: every trusted
    # field is produced or cleared. A proxy identity's headers are the identity and
    # reach the surface as sent; this sets nothing over them.
    Lazysite::Auth::Identity::write_identity_env($ident) if $ident && $ident->{source} ne 'proxy';

    # SM1181 S3 (T11): the outcome's log line, at the level each has always had, is
    # Lazysite::Auth::Session::session_log_line's - the pool's front door, which now
    # decides a signed-in page in its worker, logs the same line from the same
    # function.
    my @line = Lazysite::Auth::Session::session_log_line( $ident, $why, \%detail,
        cookie_sent => length( $ENV{HTTP_COOKIE} // '' ) ? 1 : 0 );
    log_event( $line[0], $uri, @line[ 1 .. $#line ] ) if @line;

    # Exec processor. LAZYSITE_PROCESSOR names the real CGI target (the
    # dev server and the Apache cgi-bin->auth rewrite thread it through so
    # the manager-api etc. run behind the wrapper). Apache may surface a
    # mod_rewrite [E=] var REDIRECT_-prefixed after a passthrough, so accept
    # either spelling before falling back to the processor.
    my $processor = $ENV{LAZYSITE_PROCESSOR}
        // $ENV{REDIRECT_LAZYSITE_PROCESSOR}
        // "$DOCROOT/../cgi-bin/lazysite-processor.pl";

    # SEC-2026-07 (H7): never exec ourselves. A direct request to
    # lazysite-auth.pl with no ?action (notably a bare POST) reaches this
    # passthrough with LAZYSITE_PROCESSOR pointing back at this wrapper; exec'ing
    # it would re-enter with the same env and loop forever, wedging a
    # single-threaded server. Refuse with a 400 instead.
    my $self      = Cwd::abs_path(__FILE__)   // '';
    my $proc_real = Cwd::abs_path($processor) // $processor;
    if ( length $self && $proc_real eq $self ) {
        log_event( 'WARN', $uri, 'auth: refusing self-exec (no action)',
            method => $method );
        print "Status: 400 Bad Request\r\n";
        print "Content-Type: text/plain; charset=utf-8\r\n\r\n";
        print "lazysite-auth: no action. Use ?action=login or ?action=logout.\n";
        exit 0;
    }

    # SM1144: the wrapper's whole time is the surface's `identity`, and its module
    # loading joins the surface's own `load`. Handed across the exec in the
    # environment, which only the web server and this program write.
    Lazysite::Timing::handover();
    exec $^X, $processor;
    die "exec failed: $!\n";
}

# --- Data ---

sub load_users {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my $path = "$AUTH_DIR/users";
    return {} unless -f $path;

    open( my $fh, '<:utf8', $path ) or return {};
    my %users;
    while (<$fh>) {
        chomp;
        s/^\s+|\s+$//g;
        next if /^#/ || !length;
        my ( $user, $hash ) = split /:/, $_, 2;
        $users{$user} = $hash if defined $user && defined $hash;
    }
    close $fh;
    return \%users;
}

# SM070: per-user `ui` access mechanism. Defaults to on (accounts with
# no settings row behave exactly as before SM070). A corrupt settings
# file fails open for ui - matching pre-SM070 behaviour so a damaged
# file cannot lock the sysop out of the manager - and the WARN
# surfaces the problem. The settings file is written only by
# tools/lazysite-users.pl; this is a read-only consumer.
#
# FD-19: the only reader here that still opens the file itself. The WARN
# is the reason - it names the account and says which default was taken,
# and read_settings' own warning says neither. The other three readers
# below go through read_settings.
sub ui_enabled {
    my ($username) = @_;
    my $path = "$AUTH_DIR/user-settings.json";
    return 1 unless -f $path;

    open my $fh, '<:raw', $path or return 1;
    my $raw = do { local $/; <$fh> };
    close $fh;

    require JSON::PP;
    my $data = eval { JSON::PP::decode_json( $raw // '{}' ) };
    if ( !$data || ref $data ne 'HASH' ) {
        log_event( 'WARN', $username, 'user-settings.json unparseable; ui defaults on' );
        return 1;
    }
    my $s = $data->{$username};
    return 1 unless ref $s eq 'HASH' && exists $s->{ui};
    return $s->{ui} ? 1 : 0;
}

# SM071 Phase 2: a credential with an access-token expiry in the past is
# treated as invalid. Read-only consumer; fails open (not expired) on a
# missing/corrupt file, matching the other settings consumers here.
sub token_expired {
    my ($username) = @_;
    my $s = read_settings()->{$username};
    return 0 unless ref $s eq 'HASH' && $s->{token_expires_at};
    return time() > $s->{token_expires_at} ? 1 : 0;
}

# SM072: account-level expiry (time-boxed access). After expires_at the
# whole account fails authentication, whatever credential it holds.
sub account_expired {
    my ($username) = @_;
    my $s = read_settings()->{$username};
    return 0 unless ref $s eq 'HASH' && $s->{expires_at};
    return time() > $s->{expires_at} ? 1 : 0;
}

# SM072 batch 4: is TOTP enrolled for this account?
sub mfa_enrolled {
    my ($username) = @_;
    my $s = read_settings()->{$username};
    # SM148: a PENDING (unconfirmed) enrolment does not enforce 2FA - the user
    # has not yet proved their authenticator works, so it must not gate login.
    return ( ref $s eq 'HASH' && $s->{totp_secret} && !$s->{mfa_pending} ) ? 1 : 0;
}

# SM141: attacker-controlled field -> safe registry string (control chars
# stripped against log injection, length-capped). The wrapper's own small
# copy of the SM140 recorder's sanitisation pattern (_access_field in
# lazysite-processor.pl) - kept local so the wrapper stays self-contained;
# JSON escaping is JSON::PP's job here, so no _json_str step.
sub _session_field {
    my ( $s, $cap ) = @_;
    $s //= '';
    $s =~ s/[\x00-\x1f\x7f]//g;
    $s = substr( $s, 0, $cap ) if length($s) > $cap;
    return $s;
}

# SM141: append one {sid, user, t, ip, ua} line to the session registry
# (lazysite/auth/sessions.jsonl - advisory listing metadata, never on the
# per-request path). Self-prunes on write: entries older than COOKIE_MAX are
# dead by definition, so when any line has aged out the file is rewritten
# keeping only fresh lines (atomic temp+rename, 0660) and stays tiny
# (~ logins per day). Dies on IO failure; the caller eval-guards.
sub _session_register {
    my ( $user, $ts, $sid ) = @_;
    my $path = "$AUTH_DIR/sessions.jsonl";
    require JSON::PP;
    my $line = JSON::PP::encode_json( {
            sid  => $sid,
            user => $user,
            t    => $ts + 0,
            ip   => _session_field( _request_ip(),         45 ),
            ua   => _session_field( $ENV{HTTP_USER_AGENT}, 120 ),
    } ) . "\n";

    my $cutoff = $ts - $COOKIE_MAX;
    my ( @keep, $stale );
    if ( open my $rfh, '<:raw', $path ) {
        while ( my $l = <$rfh> ) {
            my ($t) = $l =~ /"t":(\d+)/;
            if ( defined $t && $t <= $cutoff ) { $stale = 1; next }
            push @keep, $l;
        }
        close $rfh;
    }

    if ($stale) {
        my $tmp = "$path.tmp.$$";
        open my $wfh, '>:raw', $tmp or die "cannot write $tmp: $!\n";
        chmod 0o660, $tmp;
        print {$wfh} @keep, $line;
        close $wfh or die "cannot finish $tmp: $!\n";
        rename $tmp, $path or do { my $e = $!; unlink $tmp; die "cannot replace $path: $e\n" };
        return 1;
    }

    my $is_new = !-e $path;
    sysopen( my $afh, $path, O_WRONLY | O_APPEND | O_CREAT, 0o660 )
        or die "cannot append $path: $!\n";
    binmode $afh;
    syswrite( $afh, $line );
    close $afh;
    chmod 0o660, $path if $is_new;    # sysopen's mode is umask-masked
    return 1;
}

sub load_auth_secret {
    my $path = "$AUTH_DIR/.secret";
    make_path($AUTH_DIR) unless -d $AUTH_DIR;

    if ( -f $path ) {
        open( my $fh, '<', $path ) or die "Cannot read auth secret\n";
        chomp( my $s = <$fh> );
        close $fh;
        return $s if $s;
    }

    # M-6: fail closed if CSPRNG unavailable rather than falling back to rand()
    my $s = generate_random_hex(32);

    open( my $fh, '>', $path ) or die "Cannot write auth secret\n";
    # 0660, not 0600: the secret is shared between the two identities that
    # legitimately run this code on a group-shared docroot (the site user's
    # CLI/setup context and the www-data CGI, joined by the setgid auth dir's
    # group). An owner-only file minted from the CLI 500s every CGI cookie
    # verification. Never any world bits.
    chmod 0o660, $path;
    print $fh "$s\n";
    close $fh;
    return $s;
}

# Rewrite one user's hash in the users file, preserving other lines.
sub update_user_hash {
    my ( $user, $new_hash ) = @_;
    my $path = "$AUTH_DIR/users";
    return 0 unless -f $path;

    # Hold ONE exclusive lock across the whole read-modify-write. The old code
    # released the read lock before reopening for write, so a concurrent writer
    # (another password change, or the users tool) could slip in and be clobbered
    # by our stale copy. The shared store lock (.consume.lock) also makes us
    # mutually exclusive with lazysite-users.pl's mutations. Write atomically
    # (temp + rename) so a login reading the store never sees it truncated; mode
    # 0660 in the setgid auth dir keeps CLI + www-data both able to write.
    open my $lk, '>', "$AUTH_DIR/.consume.lock" or return 0;
    flock( $lk, LOCK_EX ) or do { close $lk; return 0 };

    open my $fh, '<:utf8', $path or do { close $lk; return 0 };
    my @lines = <$fh>;
    close $fh;
    for my $line (@lines) {
        next unless $line =~ /^\Q$user\E:/;
        $line = "$user:$new_hash\n";
    }

    my $tmp = "$path.tmp.$$";
    open my $wfh, '>:utf8', $tmp or do { close $lk; return 0 };
    print $wfh @lines;
    unless ( close $wfh ) { unlink $tmp; close $lk; return 0 }
    chmod 0o660, $tmp;
    unless ( rename $tmp, $path ) { unlink $tmp; close $lk; return 0 }
    close $lk;    # release the store lock
    return 1;
}

# H-3: the sign-in rate limiter, per visitor address. SM1043: the counter, its
# window and its three not-in-force cases live in Lazysite::Auth::LoginRate now,
# moved unchanged, so the member's account page counts its password and code
# checks against this same limiter rather than a copy (SM1034, Q3).
sub check_login_rate {
    my ($ip) = @_;
    return Lazysite::Auth::LoginRate::check_login_rate( $ip,
        auth_dir => $AUTH_DIR, docroot => $DOCROOT );
}

sub read_conf_key {
    my ($key) = @_;
    for my $line ( @{ _conf_lines() } ) {
        if ( $line =~ /^\Q$key\E\s*:\s*(.+)$/ ) {
            my $v = $1;
            $v =~ s/^\s+|\s+$//g;
            return $v;
        }
    }
    return '';
}

# Does a user with these (comma-separated) groups have manager access? Mirrors
# the processor's _is_manager: the `ui` capability granted through a group
# (SM095), else the unsecured/dev mode where NO group grants manager access and
# any authenticated user has it. SM138: the conf manager_groups fallback is
# retired (the migration granted those groups their capabilities explicitly).
sub _login_is_manager {
    my ($groups_str) = @_;
    my @ug = grep { length } split /\s*,\s*/, ( $groups_str // '' );
    return 1 if groups_grant_cap( 'ui', @ug );
    return Lazysite::Auth::Settings::site_grants_manager() ? 0 : 1;
}

# SM724: where a manager lands with no destination. Fails to the plain manager
# root if the module cannot answer, so a defect here can never keep someone
# out.
sub _start_page_landing {
    my ($username) = @_;
    my $url = eval {
        require Lazysite::Manager::StartPage;
        no warnings 'once';
        local $Lazysite::Manager::StartPage::DOCROOT = $DOCROOT;
        my $r = Lazysite::Manager::StartPage::resolve_start_page($username);
        log_event( 'INFO', $username, 'start page unreachable, landing on the fallback',
            reason => $r->{unreachable} )
            if $r->{unreachable};
        $r->{url};
    };
    return ( defined $url && length $url ) ? $url : '/manager/';
}

# --- Utilities ---

sub parse_post {
    my $len  = $ENV{CONTENT_LENGTH} || 0;
    my $data = '';
    if ( $len > 0 ) {
        read( STDIN, $data, $len );
    }
    else {
        local $/;
        $data = <STDIN> // '';
    }

    my %form;
    for my $pair ( split /&/, $data ) {
        my ( $k, $v ) = split /=/, $pair, 2;
        next unless defined $k;
        $k =~ s/\+/ /g;
        $k =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
        $v //= '';
        $v =~ s/\+/ /g;
        $v =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
        $v =~ s/[\r\n]/ /g;
        $form{$k} = $v;
    }
    return %form;
}

# FD-9: the transport gate handle_claim, handle_exchange and handle_rotate
# share - a secret may cross the wire under TLS, or from the loopback
# address a dev/CLI caller comes from, and nowhere else. lazysite-dav.pl
# has a fourth copy which is NOT this one: it also honours the conf key
# dav_allow_insecure, so it is a different decision.
sub _secure_transport {
    my ($ip) = @_;
    return ( $ENV{HTTPS} || $ip eq '127.0.0.1' || $ip eq '::1' ) ? 1 : 0;
}

sub sanitise_next {
    my ($next) = @_;
    return '/' unless defined $next && length $next;
    # H-1: reject protocol-relative URLs (//host) and backslash forms
    # before the permissive character-class check below - otherwise
    # //evil.com matches \A/[\w/.-]*\z.
    return '/' if $next     =~ m{\A(?://|\\)};
    return '/' unless $next =~ m{\A/[\w/.-]*\z};
    return $next;
}

sub redirect {
    my ($url) = @_;
    binmode( STDOUT, ':utf8' );
    print "Status: 302 Found\r\n";
    print "Content-Type: text/html; charset=utf-8\r\n";    # SM353
    print "Location: $url\r\n\r\n";
}

# SM179 P8: the requesting host's language (conf `lang:`, or alias.<host>.lang),
# sanitised to a bare code; 'en' when unset. Display-only - it selects the text
# of the reject pages below and NEVER gates an auth decision.
sub _host_lang {
    my $host = lc( $ENV{HTTP_HOST} // '' );
    $host =~ s/:.*//;    # strip any port
    my ( $base, $alias ) = ( '', '' );
    if ( open my $fh, '<:raw', "$LAZYSITE_DIR/lazysite.conf" ) {
        while ( my $line = <$fh> ) {
            if    ( $line =~ /^lang\h*:\h*(\S+)/ ) { $base = $1 }
            elsif ( length $host
                && $line =~ /^alias\.\Q$host\E\.lang\h*:\h*(\S+)/ )
            {
                $alias = $1;
            }
        }
        close $fh;
    }
    my $lang = length $alias ? $alias : $base;
    $lang =~ s/[^A-Za-z-]//g;
    return length $lang ? $lang : 'en';
}

# SM070: a credential-valid account whose `ui` mechanism is disabled.
# No Set-Cookie is emitted, so the account cannot reach the manager or
# auth-protected pages through the browser. These accounts are for
# WebDAV / automation; point the operator there.
sub reject_ui_disabled {
    binmode( STDOUT, ':utf8' );
    my $lang  = _host_lang();
    my $pt    = chrome_string( $DOCROOT, $lang, 'signin.title' );
    my $title = chrome_string( $DOCROOT, $lang, 'auth.uidisabled.title' );
    my $body  = chrome_string( $DOCROOT, $lang, 'auth.uidisabled.body' );
    print "Status: 403 Forbidden\r\n";
    print "Content-Type: text/html; charset=utf-8\r\n\r\n";
    print <<"HTML";
<!DOCTYPE html>
<html lang="$lang"><head><meta charset="utf-8"><title>$pt</title></head>
<body style="font-family:system-ui,sans-serif;max-width:480px;margin:3em auto;padding:0 1em;">
<h1 style="font-size:1.3rem;">$title</h1>
<p>$body</p>
</body></html>
HTML
}

sub uri_encode_simple {
    my ($str) = @_;
    $str =~ s/([^a-zA-Z0-9_.~:-])/sprintf('%%%02X', ord($1))/ge;
    return $str;
}
