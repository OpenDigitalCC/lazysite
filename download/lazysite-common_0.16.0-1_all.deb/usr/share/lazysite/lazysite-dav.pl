#!/usr/bin/perl
# lazysite-dav.pl - WebDAV (class 1 + 2) publishing endpoint for
# lazysite.
#
# The helpers this file once duplicated by convention - log_event,
# verify_password, the settings reader, the blocked-path check, the ACL
# decision, cache and registry invalidation - are imported from the
# shared lib/Lazysite tree below, which is where
# docs/architecture/code-quality.md now puts them. What is still written
# out here is the lock-record pair and the @DANGEROUS_EXT copy that
# t/lint/17 pins equal to Lazysite::Manager::Common.
#
# Reached directly under /dav (its own ScriptAlias), NOT through
# lazysite-auth.pl: it performs its own HTTP Basic authentication and
# never reads cookies or X-Remote-* headers. Credentials are verified
# against lazysite/auth/users; access is governed by per-user
# settings in lazysite/auth/user-settings.json (webdav flag, dav_scope
# path restriction). See docs/feature-requests/archive/SM070-webdav-publishing.md.
use strict;
use warnings;
use MIME::Base64   qw(decode_base64);
use Digest::SHA    ();
use Cwd            qw(realpath);
use File::Path     qw(make_path remove_tree);
use File::Basename ();
use File::Copy     qw(copy);
use Fcntl          qw(:flock O_RDWR O_CREAT);
use POSIX          qw(strftime);
use Errno          ();

BEGIN {
    # Locate the Lazysite module tree relative to this script (run-in-place,
    # tar and Hestia installs), falling back to the system @INC (package
    # installs). No configuration needed.
    require Cwd;
    require File::Basename;
    # SM1078: then the docroot's ../lib, where install.pl puts it whatever
    # --cgibin was (one rule in every script a cgi-bin runs, t/lint/263).
    my $bin = File::Basename::dirname( Cwd::abs_path(__FILE__) );
    my $doc = $ENV{DOCUMENT_ROOT} || $ENV{REDIRECT_DOCUMENT_ROOT} || '';
    for my $cand ( "$bin/lib", "$bin/../lib", "$bin/../../lib", ( length $doc ? "$doc/../lib" : () ) ) {
        if ( -d "$cand/Lazysite" ) { unshift @INC, $cand; last }
    }
}
use Lazysite::Timing (); # SM1144: first of ours, so its load phase covers the modules below
use Lazysite::Util             qw(log_event);
use Lazysite::Paths            ();
use Lazysite::Audit            qw(audit_log);
use Lazysite::Auth::Acl        qw(_acl_allows);
use Lazysite::Private          ();
use Lazysite::Auth::Credential qw(verify_password);
use Lazysite::Auth::Settings   qw(read_settings caps_for resolve_user_scopes);
$Lazysite::Util::COMPONENT = 'dav';

my $DOCROOT = $ENV{DOCUMENT_ROOT} // $ENV{REDIRECT_DOCUMENT_ROOT};

# RI-002: reason recorded by a denial (see _deny / authorise), read by the
# dispatcher into the response so a refused partner knows what to fix. Declared
# here so it is in scope at both the call site and the authorise() subs below.
our $DENY_REASON;
our $REFUSAL_DETAIL; # SM750: the `kind: cause - remedy` line a 415 refusal leaves for the audit
our $DENY_DETAIL;    # SM750: the same, for a 403 whose rule composes one

my $LAZYSITE_DIR = defined $DOCROOT ? Lazysite::Paths::lazysite_dir($DOCROOT) : undef; # SM293
# SM929: THE request address for this request - the visitor, not the front proxy.
# One reader, cached, because everything below asks the same question about one
# request. Behind a front proxy REMOTE_ADDR is a single constant for every visitor
# a site will ever have, so an address column held the infrastructure's identity
# and anything keyed on it shared one bucket with the world.
{
    my $request_ip;

    sub _request_ip {
        return $request_ip if defined $request_ip;
        require Lazysite::Util;
        $request_ip = Lazysite::Util::request_address(
            Lazysite::Util::trusted_proxy_spec($LAZYSITE_DIR) );
        return $request_ip;
    }
}

$Lazysite::Audit::LAZYSITE_DIR = $LAZYSITE_DIR;
$Lazysite::Auth::Acl::DOCROOT  = $DOCROOT;
my $AUTH_DIR    = defined $DOCROOT ? "$LAZYSITE_DIR/auth"          : undef;
my $LOCK_DIR    = defined $DOCROOT ? "$LAZYSITE_DIR/manager/locks" : undef;
my $DAV_RATE_DB = defined $DOCROOT ? "$AUTH_DIR/.dav-rate.db"      : undef;
$Lazysite::Auth::Settings::AUTH_DIR = $AUTH_DIR;

# Failed-auth rate limit (per IP), mirroring the login limiter (H-3).
my $RATE_MAX    = 5;                                      # failures per window
my $RATE_WINDOW = 300;                                    # seconds
my $FAIL_DELAY  = defined $ENV{LAZYSITE_DAV_FAIL_DELAY}
    ? $ENV{LAZYSITE_DAV_FAIL_DELAY} : 2;

# Lock parameters.
my $LOCK_DEFAULT   = 300;     # seconds, when client asks for none
my $LOCK_MAX       = 3600;    # ceiling on any grant
my $MAX_LOCKS_USER = 100;     # concurrent dav locks per user
my $OWNER_MAX      = 1024;    # bytes of client owner XML retained

my $PUT_CHUNK = 65536;

# SM888 A6: how many bytes of the request body this process has consumed, so a
# refusal knows how much is still coming and send_response can finish reading
# it. Request-lifetime state, declared with the rest of it (t/lint/39).
my $BODY_READ = 0;

# SM1114 (U12): the temp file a PUT is writing, so that every way out of the
# request - a return, a die, a signal, an exit - can remove it. A failed 7.5 MB
# PUT left xitext-motif-print-room.mp4.tmp.545808 in the tree, visible over
# WebDAV, until it was deleted by hand. Request-lifetime state, declared with
# the rest of it (t/lint/39).
my $PUT_TMP;
END { unlink $PUT_TMP if defined $PUT_TMP }

# FDO-1: caps_for() answers for this process. Declared up here, with the
# other request-lifetime state, so nothing is initialised below the
# dispatch (t/lint/39). See _caps_for for what it is and why it is safe.
my %CAPS_CACHE;

# SM019 download Content-Type table. The canonical copy is
# %Lazysite::Manager::Upload::CONTENT_TYPE_MAP; this one is kept so the
# GET path loads no manager module.
my %CONTENT_TYPE_MAP = (
    md    => 'text/plain; charset=utf-8',
    txt   => 'text/plain; charset=utf-8',
    html  => 'text/html; charset=utf-8',
    htm   => 'text/html; charset=utf-8',
    css   => 'text/css; charset=utf-8',
    js    => 'text/javascript; charset=utf-8',
    json  => 'application/json; charset=utf-8',
    jsonl => 'application/jsonl; charset=utf-8',
    xml   => 'application/xml; charset=utf-8',
    yaml  => 'text/yaml; charset=utf-8',
    yml   => 'text/yaml; charset=utf-8',
    csv   => 'text/csv; charset=utf-8',
    png   => 'image/png',
    jpg   => 'image/jpeg',
    jpeg  => 'image/jpeg',
    gif   => 'image/gif',
    webp  => 'image/webp',
    svg   => 'image/svg+xml',
    ico   => 'image/x-icon',
    pdf   => 'application/pdf',
    zip   => 'application/zip',
    # SM1112: media and its captions, the same set as the processor's
    # %STATIC_CT (t/lint/264 holds every map together).
    mp4  => 'video/mp4',
    m4v  => 'video/mp4',
    webm => 'video/webm',
    ogv  => 'video/ogg',
    mp3  => 'audio/mpeg',
    ogg  => 'audio/ogg',
    oga  => 'audio/ogg',
    opus => 'audio/ogg',
    wav  => 'audio/wav',
    m4a  => 'audio/mp4',
    flac => 'audio/flac',
    vtt  => 'text/vtt; charset=utf-8',
);

my %REASON = (
    200 => 'OK',                201 => 'Created',     204 => 'No Content',
    207 => 'Multi-Status',      400 => 'Bad Request', 401 => 'Unauthorized',
    403 => 'Forbidden',         404 => 'Not Found',   405 => 'Method Not Allowed',
    409 => 'Conflict',          412 => 'Precondition Failed',
    413 => 'Payload Too Large', 415 => 'Unsupported Media Type',
    422 => 'Unprocessable Entity',
    423 => 'Locked',                429 => 'Too Many Requests',
    500 => 'Internal Server Error', 502 => 'Bad Gateway',
    503 => 'Service Unavailable',   507 => 'Insufficient Storage',
);

# Unit-test hook: a `do "lazysite-dav.pl"` with this set returns after
# the lexicals and subs are in place but before any request handling,
# so tests can call helpers (sanitise_path, parse_if_tokens, etc.)
# directly. No effect in normal CGI use.
return 1 if $ENV{LAZYSITE_DAV_LOAD_ONLY};

main();
exit 0;

# ---------------------------------------------------------------------
# Main request pipeline
# ---------------------------------------------------------------------

sub main {
    my $method = uc( $ENV{REQUEST_METHOD} // 'GET' );
    Lazysite::Timing::begin();    # SM1144: where this request's time goes
    Lazysite::Timing::configure( Lazysite::Paths::lazysite_dir($DOCROOT) ) if defined $DOCROOT && length $DOCROOT;
    # SM929: TWO QUESTIONS, TWO VALUES. The transport gate below asks whether the
    # PEER is this machine (so plaintext is a dev loopback rather than an exposed
    # one); the failed-attempt limiter inside _authenticate asks who the VISITOR
    # is, and on REMOTE_ADDR it shared one bucket with everybody behind the front
    # end - including the lockout.
    my $peer = $ENV{REMOTE_ADDR} // '';
    my $ip   = _request_ip();

    unless ( defined $DOCROOT && length $DOCROOT ) {
        return send_status( 500, body => "DOCUMENT_ROOT not set\n" );
    }

    my $conf = read_conf();

    # 1. Site gate - feature off => the endpoint does not exist.
    unless ( is_truthy( $conf->{webdav_enabled} ) ) {
        return send_status( 404, body => "Not found\n" );
    }

    # 2. Transport gate - never accept Basic credentials over plaintext.
    my $loopback = ( $peer eq '127.0.0.1' || $peer eq '::1' );
    unless ( $ENV{HTTPS} || $loopback || is_truthy( $conf->{dav_allow_insecure} ) ) {
        log_event( 'WARN', '-', 'dav over plaintext refused', ip => $ip );
        return send_status( 403, body => "HTTPS required\n" );
    }

    # 3. Authentication (Basic) with the per-IP failed-attempt limiter, the
    #    SM071 Phase 2 account gates and 4. the mechanism gate, then SM163's
    #    credential touch - _authenticate keeps them in that order, which is
    #    the security property. It answers the request itself on every
    #    refusal and hands back the status main returns.
    Lazysite::Timing::to('identity');    # SM1144
    my ( $user, $refused ) = _authenticate($ip);
    return $refused unless defined $user;
    Lazysite::Timing::operator(1);       # SM1144: a verified account is shown the phases
    Lazysite::Timing::to('render');

    # OPTIONS advertises capabilities and touches no files.
    if ( $method eq 'OPTIONS' ) {
        return do_options();
    }

    # 5. Path resolution and authorisation.
    my $rel = sanitise_path( $ENV{PATH_INFO} // '' );
    unless ( defined $rel ) {
        return send_status( 400, body => "Bad request path\n" );
    }
    my $scope    = scope_for($user);
    # SM992 (ruled 2026-10-12, "Lock needs write access"): UNLOCK is authorised
    # as a write too, as LOCK always was: a caller the path's rule does not let
    # write is refused UNLOCK as it is refused LOCK - the lock's own holder too,
    # once the rule stops naming it.
    my $is_write = ( $method =~ /^(?:PUT|DELETE|MKCOL|MOVE|COPY|LOCK|UNLOCK)$/ );
    if ( my $code = authorise( $rel, $scope, $is_write, $conf, $user ) ) {
        my $reason = $DENY_REASON;
        log_event( 'WARN', $user, 'dav path denied',
            path => $rel, status => $code,
            ( defined $reason ? ( reason => $reason ) : () ) );
        # RI-002: name the reason so a partner agent knows what to fix, rather
        # than retrying blindly. Plain body for a human/curl; a stable
        # X-Lazysite-Deny-Reason header for a machine client to parse.
        my $body = defined $reason ? "Forbidden: $reason\n" : "Forbidden\n";

        # SM750: a denied WRITE is a fact for the trail, with its reason - the
        # API and MCP audit their forbidden attempts; this stack logged them and
        # did not record them, so a partner's refused PUT was invisible to the
        # sysop reading the audit page.
        audit_log( $user, lc($method), $rel, $ip, 'fail', 'dav',
            defined $DENY_DETAIL ? $DENY_DETAIL
            : defined $reason    ? "forbidden: $reason"
            :                      "http $code" )
            if $is_write;
        return send_status( $code, body => $body,
            ( defined $reason ? ( headers => ["X-Lazysite-Deny-Reason: $reason"] ) : () ) );
    }

    Lazysite::Timing::to('write') if $is_write;    # SM1144

    # SM071 Phase 3 (P3.6): per-token volume throttle on writes (a deploy
    # is many PUTs). 429 + Retry-After per the retry contract.
    if ($is_write) {
        my $rl = _rate_ok($user);
        unless ( $rl->{ok} ) {
            log_event( 'WARN', $user, 'dav rate limited', ip => $ip );
            return send_status( 429,
                headers => ["Retry-After: $rl->{retry_after}"],
                body    => "Rate limit exceeded\n" );
        }
    }

    # 6. Dispatch. Read methods return directly; state-changing methods have
    # their outcome captured and recorded to the shared audit trail (origin =
    # dav) so a partner's WebDAV writes are visible alongside the manager UI /
    # control-API entries.
    my %args = ( rel => $rel, user => $user, conf => $conf, scope => $scope, ip => $ip );

    # HEAD / LOCK / UNLOCK are not audited (metadata probe + lock plumbing).
    if    ( $method eq 'HEAD' )   { return do_get( %args, head => 1 ) }
    elsif ( $method eq 'LOCK' )   { return do_lock(%args) }
    elsif ( $method eq 'UNLOCK' ) { return do_unlock(%args) }

    # Reads (GET / PROPFIND) are NOT audited - the audit trail records MATERIAL
    # actions only, not access (the access log + a future stats plugin cover
    # browsing). Only state-changing methods are recorded below.
    if ( $method eq 'GET' )      { return do_get( %args, head => 0 ) }
    if ( $method eq 'PROPFIND' ) { return do_propfind(%args) }

    my $code;
    if    ( $method eq 'PROPPATCH' ) { $code = do_proppatch(%args) }
    elsif ( $method eq 'PUT' )    { $code = guarded_put( \%args, sub { do_put(%args) } ) }
    elsif ( $method eq 'MKCOL' )     { $code = do_mkcol(%args) }
    elsif ( $method eq 'DELETE' )    { $code = do_delete(%args) }
    elsif ( $method eq 'COPY' )      { $code = do_copy_move( %args, move => 0 ) }
    elsif ( $method eq 'MOVE' )      { $code = do_copy_move( %args, move => 1 ) }
    else {
        return send_status( 405,
            headers => [ allow_header() ],
            body    => "Method not allowed\n" );
    }

    my $target = $rel;
    if ( $method eq 'MOVE' || $method eq 'COPY' ) {
        my $dest = destination_rel();
        $target .= ' -> ' . $dest if defined $dest;
    }
    # Meaningful file-event labels: a PUT is a create (201) or an edit (204).
    my $act =
        $method eq 'PUT'      ? ( ( defined $code && $code == 201 ) ? 'create' : 'edit' )
        : $method eq 'DELETE' ? 'delete'
        : $method eq 'MKCOL'  ? 'mkdir'
        : $method eq 'MOVE'   ? 'move'
        : $method eq 'COPY'   ? 'copy'
        :                       lc($method);
    my $ok = defined $code && $code < 400;
    # SM750: a refusal that knows its cause and remedy says so in the trail;
    # everything else keeps the status line.
    my $detail = $ok ? '' : ( $REFUSAL_DETAIL // "http $code" );
    $REFUSAL_DETAIL = undef;
    audit_log( $user, $act, $target, $ip, ( $ok ? 'ok' : 'fail' ), 'dav', $detail );
    return $code;
}

# FD-13: main's authentication half - the per-IP failed-attempt limiter,
# the Basic credentials, the password check, the SM071 Phase 2 account
# gates, the mechanism gate and SM163's credential touch.
#
# THE ORDER IS THE SECURITY PROPERTY and is unchanged: the disabled and
# expired gates sit AFTER the password check so neither leaks anything to
# a guesser, and touch_credential runs only once every gate has passed.
# The comments moved with the statements they belong to.
#
# Returns ( $user, undef ) when the caller may go on, and ( undef, $code )
# when the response has already been sent - $code is what main returns.
sub _authenticate {
    my ($ip) = @_;

    if ( dav_rate_blocked($ip) ) {
        log_event( 'WARN', '-', 'dav auth rate limit exceeded', ip => $ip );
        return ( undef, send_status( 429, body => "Too many failed attempts\n" ) );
    }
    my ( $user, $pass ) = parse_basic_auth();
    unless ( defined $user ) {
        # No / malformed credentials: challenge, no rate penalty (this
        # is the normal first probe of any DAV client).
        return ( undef,
            send_status( 401,
                headers => ['WWW-Authenticate: Basic realm="lazysite-dav"'],
                body    => "Authentication required\n" ) );
    }
    my $users  = load_users();
    my $stored = $users->{$user};
    unless ( defined $stored && length $stored && verify_password( $pass, $stored ) ) {
        dav_rate_record($ip);
        sleep $FAIL_DELAY if $FAIL_DELAY;
        log_event( 'WARN', $user, 'dav auth failed', ip => $ip );
        return ( undef,
            send_status( 401,
                headers => ['WWW-Authenticate: Basic realm="lazysite-dav"'],
                body    => "Authentication failed\n" ) );
    }

    # SM071 Phase 2: a disabled account is denied outright, ahead of the
    # mechanism gate.
    if ( disabled_for($user) ) {
        log_event( 'WARN', $user, 'dav access denied (account disabled)', ip => $ip );
        return ( undef, send_status( 403, body => "Account disabled\n" ) );
    }

    # SM071 Phase 2: an expired access token must be rotated/re-exchanged.
    if ( token_expired($user) ) {
        log_event( 'WARN', $user, 'dav access denied (credential expired)', ip => $ip );
        return ( undef,
            send_status( 401,
                headers => ['WWW-Authenticate: Basic realm="lazysite-dav"'],
                body    => "Credential expired\n" ) );
    }

    # 4. Mechanism gate - WebDAV must be enabled for this user.
    unless ( webdav_enabled_for($user) ) {
        log_event( 'WARN', $user, 'dav access denied (mechanism off)', ip => $ip );
        return ( undef,
            send_status( 403, body => "WebDAV not enabled for this account\n" ) );
    }

    # SM163: record that this machine key was used (throttled), so the Sessions &
    # Keys view shows it in-use - WebDAV verifies the credential directly here, so
    # without this a key used only over /dav would read "not used yet".
    Lazysite::Auth::Settings::touch_credential($user);

    return ( $user, undef );
}

# ---------------------------------------------------------------------
# Methods
# ---------------------------------------------------------------------

sub do_options {
    send_response(
        200,
        headers => [
            'DAV: 1, 2',
            'MS-Author-Via: DAV',
            allow_header(),
            'Content-Length: 0',
        ],
    );
}

sub allow_header {
    return 'Allow: OPTIONS, GET, HEAD, PUT, DELETE, PROPFIND, PROPPATCH, '
        . 'MKCOL, COPY, MOVE, LOCK, UNLOCK';
}

sub do_propfind {
    my (%a) = @_;
    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};
    return send_status( 404,       body => "Not found\n" )
        if !$r->{parent_ok} || !-e $r->{abs};

    my $depth = $ENV{HTTP_DEPTH};
    $depth = '1' unless defined $depth;
    $depth =~ s/^\s+|\s+$//g;
    if ( lc($depth) eq 'infinity' ) {
        return send_status( 403, body => "Depth infinity not supported\n" );
    }
    $depth = ( $depth eq '0' ) ? 0 : 1;

    # P-perf: the lzs:sha256 live property means hashing each file, which is
    # expensive on a directory listing. Compute it only when the client asks
    # for it by name. Vanilla clients (davfs2, Finder, ...) send allprop /
    # propname and never request it, so they skip the hashing entirely - and
    # a custom dead property need not appear under allprop (RFC 4918).
    my $want_sha = ( read_request_body() =~ /sha256/ ) ? 1 : 0;

    my @blocks = prop_response( $a{rel}, $r->{abs}, $want_sha );
    if ( $depth == 1 && -d $r->{abs} ) {
        if ( opendir my $dh, $r->{abs} ) {
            # SM1114: the engine's own PUT temp (name.tmp.<pid>) is not content;
            # a leftover from a failed upload must not be listed as a file.
            my @kids = sort grep { $_ ne '.' && $_ ne '..' && !/\.tmp\.\d+\z/ } readdir $dh;
            closedir $dh;
            for my $kid (@kids) {
                my $krel = length $a{rel} ? "$a{rel}/$kid" : $kid;
                push @blocks, prop_response( $krel, "$r->{abs}/$kid", $want_sha );
            }
        }
    }

    my $xml = qq{<?xml version="1.0" encoding="utf-8"?>\n}
        . qq{<D:multistatus xmlns:D="DAV:" xmlns:lzs="urn:lazysite:dav">\n}
        . join( '', @blocks )
        . qq{</D:multistatus>\n};
    send_response( 207, type => 'application/xml; charset=utf-8', body => $xml );
}

# A single <D:response> for one resource.
sub prop_response {
    my ( $rel, $abs, $want_sha ) = @_;
    my @st      = stat $abs;
    my $is_dir  = -d _;
    my $href    = href_for( $rel, $is_dir );
    my $name    = xml_escape( length $rel ? ( split m{/}, $rel )[-1] : '' );
    my $mtime   = $st[9] // 0;
    my $lastmod = strftime( '%a, %d %b %Y %H:%M:%S GMT', gmtime($mtime) );

    my $props = "        <D:displayname>$name</D:displayname>\n";
    if ($is_dir) {
        $props .= "        <D:resourcetype><D:collection/></D:resourcetype>\n";
    }
    else {
        my $size = $st[7] // 0;
        my $ct   = xml_escape( content_type_for($rel) );
        my $etag = etag_for( \@st );
        $props .= "        <D:resourcetype/>\n";
        $props .= "        <D:getcontentlength>$size</D:getcontentlength>\n";
        $props .= "        <D:getcontenttype>$ct</D:getcontenttype>\n";
        $props .= "        <D:getetag>$etag</D:getetag>\n";
        # SM071 Phase 3: content-hash manifest. A custom live property
        # gives a vanilla DAV client a content identity (not the weak
        # dev-ino-mtime-size ETag) for drift detection. Scoped to the
        # layouts subtree so content PROPFINDs are not made to hash files.
        if ( $want_sha && $rel =~ m{^lazysite/layouts/} ) {
            my $sha = file_sha256($abs);
            $props .= "        <lzs:sha256>$sha</lzs:sha256>\n" if defined $sha;
        }
    }
    $props .= "        <D:getlastmodified>$lastmod</D:getlastmodified>\n";
    $props .= "        <D:supportedlock>\n"
        . "          <D:lockentry><D:lockscope><D:exclusive/></D:lockscope>"
        . "<D:locktype><D:write/></D:locktype></D:lockentry>\n"
        . "        </D:supportedlock>\n";
    $props .= lockdiscovery_xml( read_lock($rel) );

    return "  <D:response>\n"
        . "    <D:href>$href</D:href>\n"
        . "    <D:propstat>\n"
        . "      <D:prop>\n"
        . $props
        . "      </D:prop>\n"
        . "      <D:status>HTTP/1.1 200 OK</D:status>\n"
        . "    </D:propstat>\n"
        . "  </D:response>\n";
}

sub do_proppatch {
    my (%a) = @_;
    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};
    return send_status( 404,       body => "Not found\n" )
        if !$r->{parent_ok} || !-e $r->{abs};

    # SM070 scope exclusion 3: no dead-property store. Property writes
    # are refused, spec-compliantly, with a per-property 403.
    my $href = href_for( $a{rel}, -d $r->{abs} );
    my $xml  = qq{<?xml version="1.0" encoding="utf-8"?>\n}
        . qq{<D:multistatus xmlns:D="DAV:">\n}
        . "  <D:response>\n"
        . "    <D:href>$href</D:href>\n"
        . "    <D:propstat>\n"
        . "      <D:prop/>\n"
        . "      <D:status>HTTP/1.1 403 Forbidden</D:status>\n"
        . "    </D:propstat>\n"
        . "  </D:response>\n"
        . qq{</D:multistatus>\n};
    send_response( 207, type => 'application/xml; charset=utf-8', body => $xml );
}

sub do_get {
    my (%a) = @_;
    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};
    return send_status( 404,       body => "Not found\n" )
        if !$r->{parent_ok} || !-e $r->{abs};
    return send_status( 403, body => "Is a collection\n" ) if -d $r->{abs};

    open my $fh, '<:raw', $r->{abs}
        or return send_status( 404, body => "Not found\n" );
    my @st      = stat $r->{abs};
    my $lastmod = strftime( '%a, %d %b %Y %H:%M:%S GMT', gmtime( $st[9] // 0 ) );
    print "Status: 200 OK\r\n";
    print "Content-Type: " . content_type_for( $a{rel} ) . "\r\n";
    print "Content-Length: " . ( $st[7] // 0 ) . "\r\n";
    print "ETag: " . etag_for( \@st ) . "\r\n";
    print "Last-Modified: $lastmod\r\n";
    my $tm = Lazysite::Timing::header_line();    # SM1144
    print "$tm\r\n" if length $tm;
    print "\r\n";
    unless ( $a{head} ) {
        binmode STDOUT;
        my $buf;
        print $buf while read( $fh, $buf, $PUT_CHUNK );
    }
    close $fh;
    return 200;
}

# SM1114 (U12): do_put under a guard. Kept apart from do_put so the
# write-path lints still read the PUT's own body in one piece.
sub guarded_put {
    my ( $a, $run ) = @_;
    # SM1114 (U12): the front's timeout arrives here as SIGTERM, a client that
    # left as SIGPIPE. Either would end the process with the temp file still on
    # disk; exit instead, so the END guard above removes it.
    local $SIG{TERM} = sub { exit 143 };
    local $SIG{PIPE} = sub { exit 141 };
    local $SIG{HUP}  = sub { exit 129 };
    my $code = eval { $run->() };
    if ( my $e = $@ ) {
        # A die between creating the temp and renaming it was a bare 500 from
        # the hosting front, with the temp left behind. Answer from the engine,
        # log the cause (it may name a path, so the caller gets only its kind).
        unlink $PUT_TMP if defined $PUT_TMP;
        $PUT_TMP = undef;
        $e =~ s/\s+\z//;
        log_event( 'ERROR', $a->{user}, 'dav put died', path => $a->{rel}, error => $e );
        $REFUSAL_DETAIL = 'engine fault while storing the file';
        return send_status( 500,
            body => "Cannot store the file: the engine failed part-way and the "
                . "upload was discarded. The cause is in the engine log.\n" );
    }
    unlink $PUT_TMP if defined $PUT_TMP;
    $PUT_TMP = undef;
    return $code;
}

sub do_put {
    my (%a) = @_;
    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};

    # RFC 4918 §9.7.1: a PUT to a URL whose parent collection does not exist MUST
    # fail with 409 (Conflict) - the client MKCOLs the parent(s) first. 0.9.x
    # briefly auto-created the parent chain (SM166) for agent convenience, but
    # that silently deviated from the standard AND from the publishing brief
    # (which teaches MKCOL-parents-first); 0.9.3 restores the compliant, documented
    # behaviour so strict WebDAV clients interoperate and a typo'd parent is an
    # error, not a silent create-in-the-wrong-place.
    return send_status( 409,
        body => "Parent collection missing - MKCOL the parent(s) first (RFC 4918 9.7.1)\n" )
        unless $r->{parent_ok};
    return send_status( 405, body => "Cannot PUT a collection\n" )
        if -d $r->{abs};

    my $exists = -e $r->{abs};
    if ( my $code = check_conditionals( \@_, $r->{abs}, $exists, $a{rel} ) ) {
        return send_status( $code, body => "Precondition failed\n" );
    }
    if ( my $code = lock_blocks( $a{rel}, $a{user} ) ) {
        return send_status( $code, body => "Locked\n" );
    }

    # SM504: a .brief write refuses once the briefs plugin owns the record on
    # this site (path-based, so the body is never read). A site still on
    # sidecars - the plugin disabled - keeps working; migration is per site.
    # Common loads LAZILY on this path (the SM189 check below carries the
    # only require, which sits after this wire) - so load it here first; the
    # probe that found this met "Undefined subroutine" with the sub defined.
    require Lazysite::Manager::Common;
    if ( my ( $err, $why ) = Lazysite::Manager::Common::brief_write_refusal( $a{rel} ) ) {
        $REFUSAL_DETAIL = $why;
        return send_status( 415, body => "$err\n" );
    }

    # Size gate before reading the body.
    my $max  = max_bytes( $a{conf} );
    my $clen = $ENV{CONTENT_LENGTH};
    if ( defined $clen && $clen =~ /^\d+$/ && $clen > $max ) {
        return send_status( 413, body => "Payload too large\n" );
    }

    my $tmp    = "$r->{abs}.tmp.$$";
    $PUT_TMP = $tmp;
    my $stream = _stream_body( $tmp, $max, $clen );
    my $failed = $stream->{failed} // '';
    # SM1114: the body ended before CONTENT_LENGTH - the client went, or a
    # proxy cut it off. The old code renamed the partial bytes into place as
    # the whole file; now nothing is stored and the caller is told how far it got.
    if ( $failed eq 'short' ) {
        $REFUSAL_DETAIL = "body ended at $stream->{written} of $clen bytes";
        return send_status( 400,
            body => "Request body ended after $stream->{written} of $clen bytes "
                . "- the upload was cut off, nothing was stored. Send it again.\n" );
    }
    return _write_failure( 'create the file', $stream->{errno}, $r->{abs} )
        if $failed eq 'create';
    return send_status( 413, body => "Payload too large\n" )
        if $failed eq 'toobig';
    return _write_failure( 'write the file', $stream->{errno}, $r->{abs} )
        if $failed eq 'write';
    my $written = $stream->{written};
    # SM976 Q15h ("Refuse + walker skips"): a page's bytes are valid UTF-8, or it
    # does not land - the rule the choke point asks of a binary save
    # (Manager::Common::page_bytes_refusal), for every account. 415: the
    # request was well formed, its content is what cannot be served.
    if ( $a{rel} =~ /\.md\z/ ) {
        require Lazysite::Manager::Common;
        my $bytes;
        if ( open my $uf, '<:raw', $tmp ) { $bytes = do { local $/; <$uf> }; close $uf }
        else { unlink $tmp; return _write_failure( 'read the file back', $!, $r->{abs} ) }
        if ( my ( $err, $why ) = Lazysite::Manager::Common::page_bytes_refusal( $a{rel}, $bytes ) ) {
            unlink $tmp;
            $REFUSAL_DETAIL = $why;
            return send_status( 415, body => "$err\n" );
        }
    }
    # SM189: refuse a content page that ships raw HTML/SVG (api:/raw: front matter
    # + a script-capable content_type) - the same guard the manager/MCP save path
    # applies (Lazysite::Manager::Common::raw_html_page_refusal). The front matter
    # sits at the file head, so a bounded read is enough; refuse before the rename
    # so nothing lands on disk.
    {
        require Lazysite::Manager::Common;
        if ( open my $hf, '<:raw', $tmp ) {
            my $head = '';
            read( $hf, $head, 16384 );
            close $hf;
            if ( my ( $err, $why ) = Lazysite::Manager::Common::raw_html_page_refusal($head) ) {
                unlink $tmp;
                $REFUSAL_DETAIL = $why;
                return send_status( 415, body => "$err\n" );
            }
        }
    }
    # SM729: and the page-parse guard, the same way. SM708 built it on the
    # manager/MCP path only, so an unparseable page was ACCEPTED here - measured
    # in the field on 0.11.10, on an auth-enabled site where such a page renders
    # with every [% %] dead. Nobody exempted WebDAV; the guard was in a file this
    # one cannot reach.
    #
    # THE WHOLE BODY, not a bounded head. A parse failure can be anywhere,
    # unlike front matter. That is affordable here and only here: the streamed
    # write above already enforced the size cap, so $tmp is bounded by
    # construction and is local - this reads a file that is already on disk and
    # already partly read.
    #
    # Refused BEFORE the rename, so nothing lands, and 415 rather than 400: the
    # request was well formed, its CONTENT is what cannot be served.
    {
        require Lazysite::Manager::Common;
        if ( open my $bf, '<:encoding(UTF-8)', $tmp ) {
            my $body = do { local $/; <$bf> };
            close $bf;
            if ( my ( $err, $why )
                = Lazysite::Manager::Common::page_parse_refusal( $a{rel}, $body ) )
            {
                unlink $tmp;
                $REFUSAL_DETAIL = $why;
                return send_status( 415, body => "$err\n" );
            }
        }
    }
    # SM976 Q15e ("Refuse new binding"): a page that newly binds a form this
    # account does not reach is refused, as at the choke point - the same rule
    # (Manager::Common::form_bind_refusal), asked with the account's scopes. A
    # page that cannot be read back cannot be judged, so it does not land.
    {
        require Lazysite::Manager::Common;
        my $text;
        if ( open my $ff, '<:raw', $tmp ) { $text = do { local $/; <$ff> }; close $ff }
        else { unlink $tmp; return _write_failure( 'read the file back', $!, $r->{abs} ) }
        # Q15f: the bytes landed raw; read them as the processor will.
        $text = Lazysite::Manager::Common::text_as_processor_reads($text);
        if ( my ( $err, $why ) = Lazysite::Manager::Common::form_bind_refusal(
                $a{rel}, $text, scopes => ( ref $a{scope} eq 'ARRAY' ? $a{scope} : [] ) ) )
        {
            unlink $tmp;
            $REFUSAL_DETAIL = $why;
            return send_status( 403, body => "$err\n" );
        }
    }
    # SM842: A FORM'S CONFIG MEETS THE BINDING RULES HERE TOO. Its targets name
    # handlers that exist and nothing else - the same rule form-targets-save
    # and bind_form apply - so an inline target cannot come back through the
    # file door after the upgrade converted every one. 422: the request was
    # well formed and its content is what the engine cannot take.
    if ( $a{rel} =~ m{\Alazysite/forms/[A-Za-z0-9_-]+\.conf\z} ) {
        require Lazysite::Handlers;
        no warnings 'once';
        local $Lazysite::Handlers::DOCROOT = $DOCROOT;
        if ( open my $cf, '<:encoding(UTF-8)', $tmp ) {
            my $text = do { local $/; <$cf> };
            close $cf;
            my $problems = Lazysite::Handlers::form_conf_problems($text);
            if (@$problems) {
                unlink $tmp;
                $REFUSAL_DETAIL = join '; ', @$problems;
                return send_status( 422, body => join( "\n", @$problems ) . "\n" );
            }
        }
    }
    # P23 (WORK-PLAN-0154, ruled 2026-10-12): a navigation file carries no
    # address that can run script - the rule nav-save and set_nav apply
    # (Manager::Nav::nav_url_refusal). 422, as for a form's conf: the request
    # was well formed and its content is what the engine cannot take.
    if ( ( $a{conf}{nav_files} || {} )->{ $a{rel} } ) {
        require Lazysite::Manager::Nav;
        my $text;
        if ( open my $nf, '<:encoding(UTF-8)', $tmp ) { $text = do { local $/; <$nf> }; close $nf }
        if ( my ( $err, $why ) = Lazysite::Manager::Nav::nav_url_refusal( $a{rel}, $text // '' ) ) {
            unlink $tmp;
            $REFUSAL_DETAIL = $why;
            return send_status( 422, body => "$err\n" );
        }
    }
    unless ( rename $tmp, $r->{abs} ) {
        my $e = $!;
        unlink $tmp;
        return _write_failure( 'store the file', $e, $r->{abs} );
    }

    _sweep_stale_put_temps( $r->{abs} );
    _after_put( $a{rel}, $r->{abs}, $a{user} );
    # SM085: a DAV write is a content-history commit with the same actor
    # attribution as the audit trail (instant no-op when git history is off).
    # It stays in this sub's own body: t/unit/lib/18-git-guarantee.t registers
    # DAV::do_put as hooked and looks for the call HERE, so a write verb that
    # delegates its commit is indistinguishable from one that forgot it.
    require Lazysite::Git;
    Lazysite::Git::commit_paths( $DOCROOT, $a{user},
        ( $exists ? "edit $a{rel}" : "create $a{rel}" ), $a{rel} );
    log_event( 'INFO', $a{user}, 'dav put',
        path   => $a{rel}, bytes => $written,
        status => ( $exists ? 204 : 201 ) );
    send_status( $exists ? 204 : 201 );
}

# FD-12: PUT's body stream. Opens the temp file, copies at most $max bytes
# from STDIN and closes it - the guard order above it is what do_put is
# about, and it now reads on one screen.
#
# Returns a hashref: { written => $n } once the bytes are on disk, or
# { failed => 'create'|'write'|'toobig', errno => $! } for the three
# outcomes do_put already answered separately. The temp file is removed
# on every failure here, exactly as before.
sub _stream_body {
    my ( $tmp, $max, $clen ) = @_;
    open my $out, '>:raw', $tmp
        or return { failed => 'create', errno => $! };
    binmode STDIN;
    my $written = 0;
    my $buf;
    my $remaining = ( defined $clen && $clen =~ /^\d+$/ ) ? $clen : undef;
    while (1) {
        my $want = $PUT_CHUNK;
        $want = $remaining if defined $remaining && $remaining < $want;
        last if defined $remaining && $remaining <= 0;
        my $n = read( STDIN, $buf, $want );
        last unless $n;
        $written   += $n;
        $BODY_READ += $n;    # SM888 A6: so a later refusal drains only the rest
        if ( $written > $max ) {
            close $out; unlink $tmp;
            return { failed => 'toobig' };
        }
        # SM1114: a failed write is seen here, not only at close - ENOSPC /
        # EDQUOT surface on whichever flush meets them first.
        unless ( print {$out} $buf ) {
            my $e = $!;
            close $out; unlink $tmp;
            return { failed => 'write', errno => $e };
        }
        $remaining -= $n if defined $remaining;
    }
    unless ( close $out ) {
        my $e = $!;
        unlink $tmp;
        return { failed => 'write', errno => $e };
    }
    if ( defined $remaining && $remaining > 0 ) {
        unlink $tmp;
        return { failed => 'short', written => $written };
    }
    return { written => $written };
}

# SM1114 (U12): a PUT that was killed outright (SIGKILL, power) cannot clean
# up after itself, and its name.tmp.<pid> stays. Once the same name is stored
# successfully the leftovers of earlier attempts at it are removed - but only
# those older than an hour, because a fresh one belongs to an upload still in
# flight from another client.
sub _sweep_stale_put_temps {
    my ($abs) = @_;
    my $cut   = rindex( $abs, "/" );
    my $dir   = substr( $abs, 0, $cut );
    my $base  = substr( $abs, $cut + 1 );
    opendir my $dh, $dir or return;
    my @stale = grep { /\A\Q$base\E\.tmp\.\d+\z/ && -f "$dir/$_" && -M _ > 1 / 24 }
        readdir $dh;
    closedir $dh;
    for my $t (@stale) {
        log_event( 'INFO', 'dav-write', 'removed stale upload temp', name => $t )
            if unlink "$dir/$t";
    }
    return;
}

# FD-12: the housekeeping a completed PUT owes the rest of the site, in the
# order do_put ran it: the render cache, the SM438 stray private mirror
# copy, the SM483 registries and the SM134 alias map. Nothing here can
# refuse the write - it has already happened - so none of it returns a
# status.
#
# The SM085 history commit is deliberately NOT here; it stays in do_put,
# where t/unit/lib/18-git-guarantee.t's write-path registry can see it.
sub _after_put {
    my ( $rel, $abs, $user ) = @_;

    invalidate_cache($abs);
    # SM438: a stale PRIVATE copy of a mirror asset is what redirected updates
    # into the void (resolve() prefers private, so it would ALSO shadow this
    # write for every engine read). The mirror is derived output; the stray is
    # removed, named in the log, and the site heals on its own next publish
    # instead of needing delete-then-create.
    if ( $rel =~ m{\Alazysite-assets/} ) {
        my $stray = Lazysite::Private::private_path( $DOCROOT, $rel );
        if ( defined $stray && -f $stray && unlink $stray ) {
            log_event( 'INFO', $user, 'removed stale private copy of mirror asset',
                path => $rel );
        }
    }
    # SM483: a DAV content write never invalidated the registries at all, so
    # a page published this way stayed out of the sitemap until the TTL. Same
    # trigger as the alias map below - .md content changed.
    if ( $rel =~ /\.md\z/ ) {
        _invalidate_registries_as($user);
    }
    # SM134: keep the alias-redirect map current for content pages.
    if ( $rel =~ /\.md\z/ ) {
        require Lazysite::Aliases;
        my $body = '';
        if ( open my $rf, '<:raw', $abs ) { local $/; $body = <$rf>; close $rf }
        ( my $arel = $abs ) =~ s{^\Q$DOCROOT\E/?}{};
        Lazysite::Aliases::index_page( $DOCROOT, $arel, $body );
    }
    return;
}

sub do_mkcol {
    my (%a) = @_;
    # A body on MKCOL is unsupported (no extended-mkcol).
    my $clen = $ENV{CONTENT_LENGTH} // 0;
    return send_status( 415, body => "Body not supported\n" )
        if $clen =~ /^\d+$/ && $clen > 0;

    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};
    # SM284: MKCOL had two 409s worded almost identically, so a missing parent
    # and an unwritable one were indistinguishable to the caller - and they are
    # different problems with different fixes. This one stays 409 (RFC 4918:
    # the request is wrong, create the parent first) and now says which.
    return send_status( 409,
        body => "Cannot create collection: the parent collection does not "
            . "exist. Create it first.\n" )
        unless $r->{parent_ok};
    return send_status( 405, body => "Already exists\n" ) if -e $r->{abs};

    # The other one was a server fault dressed as a client error. It goes to the
    # shared helper, which answers 507 when the parent is unwritable.
    unless ( mkdir $r->{abs} ) {
        return _write_failure( 'create the collection', $!, $r->{abs} );
    }
    log_event( 'INFO', $a{user}, 'dav mkcol', path => $a{rel}, status => 201 );
    send_status(201);
}

sub do_delete {
    my (%a) = @_;
    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};

    # SM1092 (0.15.5 test plan: "DELETE of the folder returned 204, and the
    # folder and both .md files were still there"): A PATH CAN BE IN BOTH TREES.
    # A rule on a page moves it into the private store and makes its folder
    # there; removing the rule moves the page back and leaves that folder. The
    # resolver prefers the private copy, so DELETE removed the empty twin and
    # answered 204 over the public folder and its pages. Deleting a path deletes
    # it wherever it is: every copy that exists is a target.
    my @targets = grep { $_->{parent_ok} && ( -e $_->{abs} || -l $_->{abs} ) } $r;
    if ( my $twin = _delete_twin( $a{rel}, $r ) ) {
        return send_status( $twin->{err}, body => "Error\n" ) if $twin->{err};
        push @targets, $twin;
    }
    if ( !@targets ) {
        # The 0.13.1 field pass read `http 404` in the trail beside rows that
        # said what and why: the same shape (SM750) for the one refusal a
        # write verb makes without a rule - there is nothing here to delete.
        $REFUSAL_DETAIL = "not-found: '$a{rel}' does not exist - nothing to delete";
        return send_status( 404, body => "Not found: '$a{rel}' does not exist\n" );
    }

    $r = $targets[0];
    if ( my $code = check_conditionals( \@_, $r->{abs}, 1, $a{rel} ) ) {
        return send_status( $code, body => "Precondition failed\n" );
    }
    if ( my $code = lock_blocks( $a{rel}, $a{user} ) ) {
        return send_status( $code, body => "Locked\n" );
    }

    # SM535: the pages this entry covers, listed BEFORE the removal - the
    # path itself, or every page beneath a collection. The housekeeping below
    # used to key on the request path ending in .md, which a directory never
    # does, so a collection DELETE removed the pages and left the alias map
    # and the registries promising them: a 301 to a 404.
    ( my $key = $a{rel} ) =~ s{\A/+}{};
    require Lazysite::Aliases;
    # A .md path is its own list whether or not the public spelling exists
    # (a gated page lives in the private store, SM286); a collection is
    # walked.
    # SM1092: and the pages in either tree - md_rels walks the root it is given.
    my %seen;
    my @pages = $key =~ /\.md\z/ ? ($key)
        :   grep { !$seen{$_}++ } map { Lazysite::Aliases::md_rels( $_->{root}, $key ) } @targets;

    # SM1092: A FOLDER DELETE IS A DELETE OF EVERY PATH BENEATH IT, so each one
    # is asked what a DELETE of it alone would be asked. main() authorised the
    # folder; a page inside it whose rule refuses the caller write was removed
    # with it all the same. The safe answer when one member refuses: nothing is
    # removed and the response names the member (RFC 4918 9.6.1 allows a server
    # to refuse a collection it cannot delete whole; removing the rest and
    # answering 207 would leave a half-deleted folder nobody asked for).
    if ( my $deny = _delete_member_refusal( \%a, \@targets ) ) {
        return $deny;
    }

    my ( $ok, $partial ) = (1);
    for my $t (@targets) {
        if ( -d $t->{abs} && !-l $t->{abs} ) {
            remove_tree( $t->{abs}, { safe => 1, error => \my $err } );
            next unless -e $t->{abs};
            $ok = 0;
            # SM939 SC2 (ruled R1, amended 2026-10-07): A COLLECTION THAT IS PARTLY GONE.
            # The top-level check below cannot see this - the parent is writable and
            # remove_tree got some way in before a directory INSIDE refused it - so it
            # answered a bare 500 and skipped every housekeeping step for the pages
            # that WERE removed. Name the directory that stopped it and what is left.
            $partial //= _partial_delete( $t->{abs}, $err, $t->{root} ) if $err && @$err;
        }
        else {
            unlink $t->{abs} or $ok = 0;
        }
    }
    # SM284: removing an entry is a write to the directory that CONTAINS it, so
    # an unwritable parent fails a DELETE for exactly the reason it fails a PUT -
    # and used to answer "Delete failed", which tells an agent nothing it can act
    # on. Same helper, same 507-versus-500 split.
    return _write_failure( 'delete the entry', $!, $r->{abs} ) unless $ok || $partial;
    return _partial_delete_answer( \%a, $key, \@pages, $partial ) if $partial;

    remove_lock( $a{rel} );
    invalidate_cache( $r->{abs} );

    # SM134: drop this page's alias-redirect entries.
    #
    # SM286: keyed on the REQUEST path, not derived from the resolved absolute
    # one. This was `$r->{abs} =~ s{^\Q$DOCROOT\E/?}{}`, which silently does
    # nothing once the file lives in the private store - the substitution fails
    # to match and $arel is left as a full ABSOLUTE FILESYSTEM PATH, which then
    # goes into the alias store as a key. Wrong key, and a path where paths must
    # never appear. WebDAV already keys every other decision on $a{rel}, so
    # there was never a reason to derive it.
    #
    # SM535: per page the entry covered, so a collection gives the same answer
    # a single page always did.
    for my $page (@pages) {
        Lazysite::Aliases::deindex_page( $DOCROOT, $page );
        invalidate_cache("$DOCROOT/$page");
    }
    # SM483: a deleted page must leave the registries too.
    _invalidate_registries_as( $a{user} ) if @pages;

    # SM212 (site-agent report): drop the ACL entry with the file.
    #
    # A deleted path left an entry behind, and the entry outlives the content:
    # create a file at the same path later - by any surface - and it is born
    # governed by a rule nobody set, owned by whoever owned the file that used
    # to be there. The manager's delete has always done this; WebDAV never did,
    # so the two surfaces disagreed about what deleting means.
    #
    # A directory takes its descendants' entries with it, for the same reason:
    # the paths they name no longer exist.
    # CF-2: through the shared helper, so this surface and the manager give the
    # same answer. The inline copy that used to live here is what let the two
    # drift - and the comment above, claiming the manager already did this, was
    # wrong for four surfaces until CF-2.
    Lazysite::Auth::Acl::forget_path($key) if length $key;
    # SM507: the brief store entry goes with the file, on this surface too.
    # Docroot passed explicitly - this process never sets the package var.
    require Lazysite::Manager::Briefs;
    Lazysite::Manager::Briefs::store_entry_remove( $DOCROOT, $key );
    # SM085: a deletion (file or whole collection) is one history commit.
    require Lazysite::Git;
    Lazysite::Git::commit_paths( $DOCROOT, $a{user}, "delete $a{rel}", $a{rel} );
    log_event( 'INFO', $a{user}, 'dav delete', path => $a{rel}, status => 204 );
    send_status(204);
}

# SM1092: the copy of a DELETE's path in the tree the resolver did NOT choose,
# when there is one. Returns undef (no other copy), a target as
# resolve_under_docroot shapes it, or { err } when the other copy fails the
# confinement - which refuses the DELETE rather than leaving it behind.
# The engine tree and the theme-asset mirror have one home only (SM850, SM438),
# so they have no twin.
sub _delete_twin {
    my ( $rel, $r ) = @_;
    return undef unless length $rel;
    return undef if $rel =~ m{\A(?:lazysite|lazysite-assets)(?:/|\z)};
    my $priv = Lazysite::Private::private_root($DOCROOT);
    return undef unless defined $priv;
    my ( $pub_real, $priv_real ) = ( realpath($DOCROOT), realpath($priv) );
    return undef unless defined $pub_real && defined $priv_real;
    my $other = ( defined $r->{root} && $r->{root} eq $priv_real ) ? $pub_real : $priv_real;
    return undef if defined $r->{root} && $r->{root} eq $other;
    my $t = resolve_under_docroot( $rel, $other );
    return $t if $t->{err};
    return undef unless $t->{parent_ok} && ( -e $t->{abs} || -l $t->{abs} );
    return $t;
}

# SM1092: every path beneath a collection DELETE's targets, asked what a DELETE
# of that path alone is asked - authorise(), so scope, blocklist and per-file
# rule, all as main() asks them of the request path. Answers the 403 itself and
# returns its code when one refuses, undef when all agree. Symlinks are listed
# and not followed: removing a link removes the link.
sub _delete_member_refusal {
    my ( $a, $targets ) = @_;
    ( my $key = $a->{rel} ) =~ s{\A/+}{};
    my %members;
    require File::Find;
    for my $t (@$targets) {
        next unless -d $t->{abs} && !-l $t->{abs};
        my $base = $t->{abs};
        File::Find::find( { no_chdir => 1, wanted => sub {
                    return if $File::Find::name eq $base;
                    ( my $sub = substr( $File::Find::name, length $base ) ) =~ s{\A/+}{};
                    $members{ length $key ? "$key/$sub" : $sub } = 1;
        } }, $base );
    }
    for my $m ( sort keys %members ) {
        my $code = authorise( $m, $a->{scope}, 1, $a->{conf}, $a->{user} ) or next;
        my $why  = $DENY_REASON // "http $code";
        $REFUSAL_DETAIL = "member-refused: '$m' inside '$key' refuses this delete ($why); nothing was removed";
        log_event( 'WARN', $a->{user}, 'dav delete refused by a member',
            path => $a->{rel}, member => $m, reason => $why, status => $code );
        ( my $hdr = "'$m' inside the folder: $why" ) =~ s/[\r\n]+/ /g;
        return send_status( $code,
            headers => ["X-Lazysite-Deny-Reason: $hdr"],
            body => "Forbidden: cannot delete '$key': '$m' inside it refuses you ($why). "
                . "Nothing was removed - a folder is deleted whole or not at all. Delete or "
                . "move what you may, or ask the owner of '$m'.\n" );
    }
    return undef;
}

# CF-2: the ACL key, spelled the same way DELETE already spells it.
# SM939 SC2: what remove_tree's error list says stopped it, and what is left.
# The first entry naming a path is the blocker; a path under the docroot is
# reported relative to it and nothing else is (the SM-wide rule: no filesystem
# paths in answers).
sub _partial_delete {
    my ( $abs, $err, $root ) = @_;
    $root //= $DOCROOT;    # SM1092: the tree the collection was in
    my ( $blocker, $why );
    for my $e (@$err) {
        my ( $p, $m ) = %$e;
        next unless length $p;
        # remove_tree names the FILE it could not unlink; what refused is the
        # directory holding it (unlinking is a write to the directory).
        $p =~ s{/[^/]+\z}{} if !-d $p;
        ( $blocker, $why ) = ( $p, $m );
        last;
    }
    return undef unless defined $blocker;
    my $left = 0;
    require File::Find;
    File::Find::find( { no_chdir => 1, wanted => sub { $left++ if -f $_ } }, $abs ) if -d $abs;
    ( my $rel = $blocker ) =~ s{\A\Q$root\E/*}{};
    $rel = '(outside the site)' if $rel eq $blocker;
    return { blocker => $rel, why => $why // '', left => $left };
}

# Housekeeping for the pages that ARE gone, and a 507 that says what stopped the
# rest. The collection's own ACL entry is NOT forgotten: forget_path takes every
# rule beneath a key, and the files still there keep their protection.
sub _partial_delete_answer {
    my ( $a, $key, $pages, $p ) = @_;
    # SM1092: gone from both trees - a page left in the private store is not gone.
    my @gone = grep { !( Lazysite::Private::resolve( $DOCROOT, $_ ) )[0] } @$pages;
    require Lazysite::Aliases;
    require Lazysite::Manager::Briefs;
    for my $page (@gone) {
        Lazysite::Aliases::deindex_page( $DOCROOT, $page );
        invalidate_cache("$DOCROOT/$page");
        Lazysite::Auth::Acl::forget_path($page);
        Lazysite::Manager::Briefs::store_entry_remove( $DOCROOT, $page );
    }
    _invalidate_registries_as( $a->{user} ) if @gone;
    require Lazysite::Git;
    Lazysite::Git::commit_paths( $DOCROOT, $a->{user}, "delete $a->{rel} (partial)", $a->{rel} );
    $REFUSAL_DETAIL = "partial-delete: '$p->{blocker}' is not writable by the server; $p->{left} file(s) left";
    log_event( 'ERROR', $a->{user}, 'dav delete partial', path => $a->{rel},
        blocker => $p->{blocker}, left => $p->{left}, error => $p->{why}, status => 507 );
    return send_status( 507,
        body => "Cannot delete '$a->{rel}' completely: the directory '$p->{blocker}' inside it is "
            . "not writable by the server, so $p->{left} file(s) were left in place. Everything "
            . "else was removed. This is a server configuration fault, not a permission "
            . "decision about your request - the operator must fix that directory's "
            . "permissions, then the DELETE can be sent again.\n" );
}

sub _dav_acl_key { my ($r) = @_; $r =~ s{\A/+}{}; return $r }

# CF-2: put the bytes where the rule now says they belong.
#
# The manager has done this since SM286 (Files.pm's _sync_private_store) and
# this surface never did, because it had no ACL code in its move at all. The
# decision is identical - a rule that gates the public read means the content
# lives in the private store - so the SHAPE is shared even though the mover is
# called from two places: gates ? move_in : move_out, then the .brief sidecar
# with it, and the stale public render deleted rather than moved because it is
# derived and a regenerable file cannot be lost.
#
# Returns warnings rather than dying: a move whose bytes could not be
# re-homed must still report, or the caller learns nothing.
sub _sync_acl_store {
    my ( $rel, $rec ) = @_;
    my @warnings;
    ( my $path = $rel ) =~ s{\A/+}{};
    $path =~ s{/+\z}{};

    # A site-wide rule cannot be expressed as a move - the docroot cannot
    # become its own sibling - so it stays enforced by the engine (SM287).
    return @warnings unless length $path;

    my $gates = 0;
    if ( ref $rec eq 'HASH' ) {
        $gates = 1 if $rec->{draft};
        $gates = 1 if ref $rec->{read} eq 'ARRAY' && @{ $rec->{read} };
    }

    # SM981 (ruled 2026-10-11, "Land where save would"): and any rule that governs
    # the path and relocates content - an ancestor folder's read list or draft.
    # Judged by the moved path's own record, a MOVE of a file carrying an
    # owner-only rule into a held-back folder put it straight back into the
    # document root. An unreadable store moves nothing out.
    my $placed = eval { Lazysite::Auth::Acl::placement_for( $DOCROOT, $path ) } // 'unknown';
    $gates = 1 if $placed ne 'public';

    my ( $ok, $err, $notes )
        = $gates
        ? Lazysite::Private::move_in( $DOCROOT, $path )
        : Lazysite::Private::move_out( $DOCROOT, $path );
    push @warnings, "content could not be re-homed: $err" if !$ok && $err;
    push @warnings, @$notes if ref $notes eq 'ARRAY';    # SM981: a merge says what it did

    if ($ok) {
        my ( $bok, $berr )
            = $gates
            ? Lazysite::Private::move_in( $DOCROOT, "$path.brief" )
            : Lazysite::Private::move_out( $DOCROOT, "$path.brief" );
        push @warnings, "the notes beside this page could not be moved with it"
            if !$bok && $berr && $berr !~ /No such file/i;

        # The pre-gate render is a complete public copy sitting in the docroot -
        # SM283 exactly. Deleted rather than moved: it is derived, the next
        # render writes it where it belongs, and deleting a regenerable file
        # cannot lose anything.
        if ( $gates && $path =~ /\.md\z/ ) {
            ( my $cache = $path ) =~ s/\.md\z/.html/;
            unlink "$DOCROOT/$cache" if -f "$DOCROOT/$cache";
        }
    }
    return @warnings;
}

# FD-11: remove one entry, whichever kind it is, and say whether it went.
# do_copy_move wrote this out three times - clearing an existing
# destination, removing a MOVE's source, and rolling a failed MOVE's copy
# back - with the same two branches each time.
#
# The answers are the ones the original returned: `!-e` for a collection
# (SM284 - the removal decides a MOVE's outcome, so it is checked rather
# than performed for effect) and unlink's own count for a file.
#
# do_delete keeps its own pair: it passes remove_tree an `error` collector,
# which changes what remove_tree does when a removal fails, so it is not
# the same call.
sub _remove_entry {
    my ($abs) = @_;
    if ( -d $abs ) {
        remove_tree( $abs, { safe => 1 } );
        return !-e $abs;
    }
    return unlink $abs;
}

# FD-11: MOVE's byte mover - rename where the filesystem allows it, and a
# copy-then-remove across devices otherwise. Returns whether the move
# completed, which is what the SM284 message below depends on.
sub _move_bytes {
    my ( $src, $dst ) = @_;

    my $ok = rename( $src, $dst );
    return $ok if $ok;

    # cross-device: copy then remove
    $ok = copy_tree( $src, $dst );
    return $ok unless $ok;

    # SM284: the removal decides the outcome too. It was performed
    # for effect and never checked, so a MOVE out of an unwritable
    # directory copied the entry, failed to remove the original, and
    # answered 201 - a MOVE silently downgraded to a COPY, with both
    # copies live and the client told it had moved. Found while
    # building the source-side failure case, which could not fire
    # until this did.
    $ok = _remove_entry($src);

    # SM582: a removal can fail HALFWAY, and the collection case always
    # does - remove_tree empties the directory and only then fails to
    # unlink it from its unwritable parent. So the source came back as a
    # bare directory while the answer said the move had not happened, and
    # the rollback below then took the complete copy with it: the client
    # told nothing happened, and the content gone. Restore the source from
    # the copy FIRST, because at this instant the copy is the only whole
    # thing on disk. A file needs nothing restored - unlink either removes
    # the entry or leaves it intact - and re-copying it is a no-op over
    # identical bytes.
    #
    # Then roll the copy back, so a failed MOVE leaves no entry the
    # caller never asked to create. Reporting the failure while
    # leaving the copy in place would be the same defect one step
    # further on: the client is told nothing happened, and a second
    # file exists.
    unless ($ok) {
        copy_tree( $dst, $src );
        _remove_entry($dst);
    }
    return $ok;
}

sub do_copy_move {
    my (%a)  = @_;
    my $move = $a{move};
    my $src  = resolve_under_docroot( $a{rel} );
    return send_status( $src->{err}, body => "Error\n" ) if $src->{err};
    if ( !$src->{parent_ok} || !-e $src->{abs} ) {
        $REFUSAL_DETAIL = "not-found: source '$a{rel}' does not exist - nothing to " . ( $move ? 'move' : 'copy' );
        return send_status( 404, body => "Not found: '$a{rel}' does not exist\n" );
    }

    my $drel = destination_rel();
    return send_status( 400, body => "Bad Destination\n" ) unless defined $drel;

    # Destination passes the full authorisation chain too.
    if ( my $code = authorise( $drel, $a{scope}, 1, $a{conf}, $a{user} ) ) {
        return send_status( $code, body => "Forbidden destination\n" );
    }
    my $dst = resolve_under_docroot($drel);
    return send_status( $dst->{err}, body => "Error\n" ) if $dst->{err};
    return send_status( 409,         body => "Destination parent missing\n" )
        unless $dst->{parent_ok};

    my $dst_exists = -e $dst->{abs};
    my $overwrite  = $ENV{HTTP_OVERWRITE} // 'T';
    if ( $dst_exists && uc($overwrite) eq 'F' ) {
        return send_status( 412, body => "Destination exists\n" );
    }

    # Lock checks: destination is written by both; source is removed by MOVE.
    if ( my $code = lock_blocks( $drel, $a{user} ) ) {
        return send_status( $code, body => "Destination locked\n" );
    }
    if ( $move && ( my $code = lock_blocks( $a{rel}, $a{user} ) ) ) {
        return send_status( $code, body => "Source locked\n" );
    }

    # SM976 Q15e: a page moved or copied is a new binding where it lands - every
    # page the source carries, judged at its destination path, before anything
    # is removed or written.
    {
        require Lazysite::Manager::Common;
        if ( my ( $err, $why ) = Lazysite::Manager::Common::form_bind_tree_refusal(
                $src->{abs}, $drel, scopes => ( ref $a{scope} eq 'ARRAY' ? $a{scope} : [] ) ) )
        {
            $REFUSAL_DETAIL = $why;
            return send_status( 403, body => "$err\n" );
        }
    }

    _remove_entry( $dst->{abs} ) if $dst_exists;

    my $ok;
    if ($move) {
        $ok = _move_bytes( $src->{abs}, $dst->{abs} );
        remove_lock( $a{rel} ) if $ok;
    }
    else {
        $ok = copy_tree( $src->{abs}, $dst->{abs} );
    }
    # SM284: MOVE and COPY are the two-directory case. A COPY only writes the
    # destination; a MOVE also has to remove the source, so an unwritable SOURCE
    # parent fails it while the destination is perfectly fine. Naming which side
    # is the whole value of the message - "Operation failed" left an agent with
    # nowhere to go, and the sysop with nothing to fix.
    unless ($ok) {
        return _write_failure(
            'complete the move', $!,
            [ $dst->{abs}, 'destination' ],
            [ $src->{abs}, 'source' ],
        ) if $move;
        return _write_failure( 'copy the entry', $!,
            [ $dst->{abs}, 'destination' ] );
    }

    invalidate_cache( $src->{abs} ) if $move;
    invalidate_cache( $dst->{abs} );
    # SM134 follow-ups: keep the alias-redirect map current across MOVE/COPY -
    # the moved/copied page(s) would otherwise re-index only on the next save.
    {
        require Lazysite::Aliases;
        if ($move) { Lazysite::Aliases::reindex_move( $DOCROOT, $a{rel}, $drel ) }
        else       { Lazysite::Aliases::reindex_copy( $DOCROOT, $drel ) }
    }
    # SM534: the registries too. SM483 reached PUT and DELETE only, so a page
    # renamed here stayed in the sitemap at its old URL (a 404) and off it at
    # the new one until the TTL; a copy was absent. Same helper, same answer
    # as the manager's action_move / action_copy.
    _invalidate_registries_as( $a{user} );
    # SM085: a batched MOVE/COPY (a whole collection included) is ONE commit.
    # SM175: a MOVE records the rename (Lazysite-Renamed-From) so content history
    # follows it; a COPY is a fresh file and starts its own thread (no trailer).
    # CF-2: THE RULE FOLLOWS THE CONTENT, on this surface too.
    #
    # This handler had no ACL code at all. resolve_under_docroot resolves a
    # GATED path into the private store, so a MOVE to an ungated destination
    # physically relocated the bytes out of the private tree and into the
    # public docroot - and with no re-key, no rule followed them. Protected
    # content became public through an ordinary operation, with no error and
    # nothing for anyone to notice. That is the exact inverse of SM286, whose
    # rule is that protecting content MOVES it: moving content has to carry
    # its protection.
    #
    # The re-key runs FIRST and the store sync SECOND, in that order, because
    # the destination's tree was chosen before the rule moved - so the bytes
    # are wherever the OLD rule said, and syncing against the NEW key is what
    # puts them right. That settles both directions: into a gated folder and
    # back out of one.
    #
    # A COPY makes a fresh file, which gets a fresh owner entry and inherits no
    # read/write lists - the same rule action_copy applies, for the same reason.
    if ($move) {
        if ( Lazysite::Auth::Acl::rekey_path( $a{rel}, $drel ) ) {
            my $acls = Lazysite::Auth::Acl::load_acls();
            my @w    = _sync_acl_store( $drel, $acls->{ _dav_acl_key($drel) } );
            log_event( 'WARN', $a{user}, 'dav move: private store', detail => $_ )
                for @w;
        }
    }
    elsif ( defined $a{user} && length $a{user} ) {
        my $acls = Lazysite::Auth::Acl::load_acls();
        $acls->{ _dav_acl_key($drel) } = { owner => $a{user} };
        Lazysite::Auth::Acl::save_acls($acls);
    }

    # SM507: a MOVE carries the brief store entry to the new key (a COPY is
    # a fresh file and starts unbriefed, exactly as it starts with a fresh
    # ACL). Docroot passed explicitly.
    if ($move) {
        require Lazysite::Manager::Briefs;
        Lazysite::Manager::Briefs::store_entry_move( $DOCROOT, $a{rel}, $drel );
    }

    {
        require Lazysite::Git;
        if ($move) {
            Lazysite::Git::commit_move( $DOCROOT, $a{user},
                "move $a{rel} -> $drel", $a{rel}, $a{rel}, $drel );
        }
        else {
            Lazysite::Git::commit_paths( $DOCROOT, $a{user},
                "copy $a{rel} -> $drel", $drel );
        }
    }
    log_event( 'INFO', $a{user}, ( $move ? 'dav move' : 'dav copy' ),
        path   => $a{rel}, dest => $drel,
        status => ( $dst_exists ? 204 : 201 ) );
    send_status( $dst_exists ? 204 : 201 );
}

# ---------------------------------------------------------------------
# Locking (class 2)
# ---------------------------------------------------------------------

sub do_lock {
    my (%a) = @_;
    my $depth = $ENV{HTTP_DEPTH};
    $depth = '0' unless defined $depth;
    $depth =~ s/^\s+|\s+$//g;
    return send_status( 403, body => "Only Depth 0 locks supported\n" )
        if lc($depth) eq 'infinity' || $depth eq '1';

    my $body     = read_request_body();
    my $existing = read_lock( $a{rel} );

    # Refresh: empty body + an If header carrying the current token.
    if ( !length $body ) {
        return send_status( 400, body => "Missing lock body\n" )
            unless $existing;
        my @tokens = parse_if_tokens( $ENV{HTTP_IF} // '' );
        unless ( $existing->{origin} eq 'dav'
            && grep { $_ eq $existing->{token} } @tokens ) {
            return send_status( 423, body => "Lock token required to refresh\n" );
        }
        $existing->{at}      = time();
        $existing->{timeout} = grant_timeout();
        write_lock( $a{rel}, $existing );
        return lock_ok( $a{rel}, $existing );
    }

    return send_status( 403, body => "Only exclusive locks supported\n" )
        if $body =~ /<\s*(?:\w+:)?shared\b/i;

    # A live lock held by someone else (or a manager session) blocks.
    if ($existing) {
        my @tokens = parse_if_tokens( $ENV{HTTP_IF} // '' );
        my $own    = ( $existing->{origin} eq 'dav'
                && $existing->{user} eq $a{user}
                && grep { $_ eq $existing->{token} } @tokens );
        return send_status( 423, body => "Already locked\n" ) unless $own;
    }

    # Per-user lock flood guard.
    if ( !$existing && count_user_locks( $a{user} ) >= $MAX_LOCKS_USER ) {
        log_event( 'WARN', $a{user}, 'dav lock flood guard', path => $a{rel} );
        return send_status( 503, body => "Too many locks\n" );
    }

    # LOCK on an unmapped URL creates an empty resource, after the full
    # write-path authorisation already run in main().
    my $r = resolve_under_docroot( $a{rel} );
    return send_status( $r->{err}, body => "Error\n" ) if $r->{err};
    my $created = 0;
    unless ( -e $r->{abs} ) {
        return send_status( 409, body => "Parent collection missing\n" )
            unless $r->{parent_ok};
        open my $fh, '>:raw', $r->{abs}
            or return _write_failure( 'create the file', $!, $r->{abs} );
        close $fh;
        $created = 1;
    }

    my $owner = extract_owner($body);
    my $rec   = {
        user    => $a{user},
        at      => time(),
        origin  => 'dav',
        token   => 'opaquelocktoken:' . make_uuid(),
        timeout => grant_timeout(),
        owner   => $owner,
    };
    write_lock( $a{rel}, $rec );
    log_event( 'INFO', $a{user}, 'dav lock', path => $a{rel} );
    lock_ok( $a{rel}, $rec, created => $created );
}

sub do_unlock {
    my (%a)     = @_;
    my $hdr     = $ENV{HTTP_LOCK_TOKEN} // '';
    my ($token) = $hdr =~ /<([^>]+)>/;
    return send_status( 400, body => "Missing Lock-Token\n" )
        unless defined $token && length $token;

    my $lock = read_lock( $a{rel} );
    return send_status( 409, body => "No such lock\n" )
        unless $lock && $lock->{origin} eq 'dav' && $lock->{token} eq $token;
    return send_status( 403, body => "Not the lock owner\n" )
        unless $lock->{user} eq $a{user};

    remove_lock( $a{rel} );
    log_event( 'INFO', $a{user}, 'dav unlock', path => $a{rel} );
    send_status(204);
}

# Does a live lock block a write to $rel by $user? Returns 423 or undef.
sub lock_blocks {
    my ( $rel, $user ) = @_;
    my $lock = read_lock($rel);
    return undef unless $lock;                 # unlocked
    return 423 if $lock->{origin} ne 'dav';    # manager lock: opaque
    my @tokens = parse_if_tokens( $ENV{HTTP_IF} // '' );
    return undef if grep { $_ eq $lock->{token} } @tokens;
    return 423;
}

sub lock_ok {
    my ( $rel, $rec, %o ) = @_;
    my $body = qq{<?xml version="1.0" encoding="utf-8"?>\n}
        . qq{<D:prop xmlns:D="DAV:">\n}
        . "  <D:lockdiscovery>\n"
        . activelock_xml($rec)
        . "  </D:lockdiscovery>\n"
        . qq{</D:prop>\n};
    send_response(
        ( $o{created} ? 201 : 200 ),
        type    => 'application/xml; charset=utf-8',
        headers => ["Lock-Token: <$rec->{token}>"],
        body    => $body,
    );
}

sub lockdiscovery_xml {
    my ($rec) = @_;
    return "        <D:lockdiscovery/>\n" unless $rec;
    return "        <D:lockdiscovery>\n"
        . activelock_xml($rec)
        . "        </D:lockdiscovery>\n";
}

sub activelock_xml {
    my ($rec) = @_;
    my $owner = defined $rec->{owner} && length $rec->{owner}
        ? "      <D:owner>" . xml_escape( $rec->{owner} ) . "</D:owner>\n" : '';
    my $remain = ( $rec->{at} + $rec->{timeout} ) - time();
    $remain = 0 if $remain < 0;
    return "    <D:activelock>\n"
        . "      <D:locktype><D:write/></D:locktype>\n"
        . "      <D:lockscope><D:exclusive/></D:lockscope>\n"
        . "      <D:depth>0</D:depth>\n"
        . $owner
        . "      <D:timeout>Second-$remain</D:timeout>\n"
        . "      <D:locktoken><D:href>" . xml_escape( $rec->{token} )
        . "</D:href></D:locktoken>\n"
        . "    </D:activelock>\n";
}

sub grant_timeout {
    my $req = $ENV{HTTP_TIMEOUT} // '';
    for my $part ( split /\s*,\s*/, $req ) {
        if ( $part =~ /^Second-(\d+)$/i ) {
            my $s = $1;
            return $s > $LOCK_MAX ? $LOCK_MAX : $s;
        }
        return $LOCK_MAX if $part =~ /^Infinite$/i;
    }
    return $LOCK_DEFAULT;
}

sub extract_owner {
    my ($body) = @_;
    return '' unless $body =~ m{<\s*(?:\w+:)?owner\b[^>]*>(.*?)</\s*(?:\w+:)?owner\s*>}is;
    my $owner = $1;
    $owner = substr( $owner, 0, $OWNER_MAX ) if length $owner > $OWNER_MAX;
    return $owner;
}

sub make_uuid {
    my @b = unpack( 'C16', random_bytes(16) );
    $b[6] = ( $b[6] & 0x0f ) | 0x40;    # version 4
    $b[8] = ( $b[8] & 0x3f ) | 0x80;    # RFC 4122 variant
    my $h = unpack( 'H*', pack( 'C16', @b ) );
    return join '-', substr( $h, 0, 8 ), substr( $h, 8, 4 ),
        substr( $h, 12, 4 ), substr( $h, 16, 4 ), substr( $h, 20, 12 );
}

# ---------------------------------------------------------------------
# Lock store (shared format with lazysite-manager-api.pl)
# ---------------------------------------------------------------------
#
# One file per resource at $LOCK_DIR/<key>.lock, key = rel with '/'
# replaced by ':'. Content is a JSON record:
#   {"user","at","origin":"dav"|"manager","token","timeout","owner"}
# A legacy single-line "user epoch" file (pre-SM070 manager locks) is
# read as an origin=manager record with the default timeout.

sub lock_file_for {
    my ($rel) = @_;
    ( my $key = $rel ) =~ s{/}{:}g;
    return "$LOCK_DIR/$key.lock";
}

sub read_lock {
    my ($rel) = @_;
    my $file = lock_file_for($rel);
    return undef unless -f $file;
    open my $fh, '<', $file or return undef;
    my $raw = do { local $/; <$fh> };
    close $fh;
    my $rec = parse_lock_record($raw);
    return undef unless $rec;
    my $age = time() - ( $rec->{at} // 0 );
    if ( $age >= ( $rec->{timeout} // $LOCK_DEFAULT ) ) {
        unlink $file;    # expired: opportunistic sweep
        return undef;
    }
    return $rec;
}

sub parse_lock_record {
    my ($raw) = @_;
    return undef unless defined $raw;
    $raw =~ s/^\s+//;
    if ( $raw =~ /^\{/ ) {
        require JSON::PP;
        my $rec = eval { JSON::PP::decode_json($raw) };
        return undef unless ref $rec eq 'HASH';
        $rec->{origin}  ||= 'manager';
        $rec->{timeout} ||= $LOCK_DEFAULT;
        return $rec;
    }
    # Legacy "user epoch" line.
    my ( $user, $at ) = split /\s+/, $raw, 2;
    return undef unless defined $user;
    $at //= 0;
    $at =~ s/\D.*$//;
    return { user => $user, at => ( $at || 0 ), origin => 'manager',
        timeout => $LOCK_DEFAULT, token => undef, owner => '' };
}

sub write_lock {
    my ( $rel, $rec ) = @_;
    make_path($LOCK_DIR) unless -d $LOCK_DIR;
    require JSON::PP;
    my $file = lock_file_for($rel);
    my $tmp  = "$file.tmp.$$";
    open my $fh, '>', $tmp or return 0;
    print $fh JSON::PP->new->canonical->encode($rec);
    close $fh;
    chmod 0640, $tmp;
    return rename $tmp, $file;
}

sub remove_lock {
    my ($rel) = @_;
    my $file = lock_file_for($rel);
    unlink $file if -f $file;
}

sub count_user_locks {
    my ($user) = @_;
    return 0 unless -d $LOCK_DIR;
    opendir my $dh, $LOCK_DIR or return 0;
    my @files = grep { /\.lock$/ } readdir $dh;
    closedir $dh;
    my $n = 0;
    for my $f (@files) {
        open my $fh, '<', "$LOCK_DIR/$f" or next;
        my $raw = do { local $/; <$fh> };
        close $fh;
        my $rec = parse_lock_record($raw) or next;
        next unless ( $rec->{origin} // '' ) eq 'dav'
            && ( $rec->{user} // '' ) eq $user;
        next if time() - ( $rec->{at} // 0 ) >= ( $rec->{timeout} // $LOCK_DEFAULT );
        $n++;
    }
    return $n;
}

# ---------------------------------------------------------------------
# Conditionals
# ---------------------------------------------------------------------

sub check_conditionals {
    my ( undef, $abs, $exists, $rel ) = @_;
    my $im   = $ENV{HTTP_IF_MATCH};
    my $inm  = $ENV{HTTP_IF_NONE_MATCH};
    my $etag = $exists && -f $abs ? etag_for( [ stat $abs ] ) : undef;

    if ( defined $im ) {
        $im =~ s/^\s+|\s+$//g;
        if ( $im eq '*' ) { return 412 unless $exists }
        else {
            return 412 unless defined $etag && etag_in_list( $etag, $im );
        }
    }
    if ( defined $inm ) {
        $inm =~ s/^\s+|\s+$//g;
        if ( $inm eq '*' ) { return 412 if $exists }
        else {
            return 412 if defined $etag && etag_in_list( $etag, $inm );
        }
    }
    return undef;
}

sub etag_in_list {
    my ( $etag, $list ) = @_;
    for my $t ( split /\s*,\s*/, $list ) {
        $t =~ s/^\s+|\s+$//g;
        $t =~ s/^W\///;         # weak-tag marker, ignored
        return 1 if $t eq $etag;
    }
    return 0;
}

# ---------------------------------------------------------------------
# Authorisation chain
# ---------------------------------------------------------------------

# Clean PATH_INFO into a docroot-relative path with no leading slash.
# PATH_INFO arrives already %-decoded from the web server, so it is NOT
# decoded again here (double-decoding would re-open traversal). Returns
# undef on a rejected path.
sub sanitise_path {
    my ($path) = @_;
    $path = '' unless defined $path;
    return undef if $path =~ /\0/;             # null byte
    return undef if $path =~ /[\x00-\x1f]/;    # control chars
    $path =~ s{^/+}{};                         # strip leading slashes
    $path =~ s{/+$}{};                         # strip trailing slashes
    return '' if $path eq '';
    for my $seg ( split m{/}, $path ) {
        return undef if $seg eq '..';          # traversal
    }
    return $path;
}

# SM074/SM077: per-file ACLs live in lazysite/auth/acls.json (set through the
# control API, never a raw PUT; the dav only reads). The owner/allowlist + the
# @group rules are delegated to the shared Lazysite::Auth::Acl so WebDAV
# enforces exactly what the manager and MCP do - previously a private copy here
# silently ignored @group entries.

# The user's group memberships, read from lazysite/auth/groups (for @group
# ACLs). WebDAV has no X-Remote-Groups, so it resolves them from the store.
# SM288: the local groups reader that used to live here is DELETED. It parsed
# the group file itself and returned direct memberships only - the right answer
# in practice, because _acl_allows expands them again, but a second
# implementation of "which groups is this user in". SM279's lesson: a second
# answer to a question that must have exactly one is not a compatibility
# surface, it is a defect waiting for the two to disagree. The shared resolver
# is Lazysite::Auth::Acl::groups_for_user.

# 1 if $user may access $rel in $mode ('read'|'write'); delegates to the shared
# allow check with the user's groups in scope (so @group entries match).
sub acl_allows {
    my ( $rel, $mode, $user ) = @_;
    local @Lazysite::Auth::Acl::user_groups
        = Lazysite::Auth::Acl::groups_for_user($user);
    return _acl_allows( $rel, $mode, $user ) ? 1 : 0;
}

# RI-002: record a human-readable reason alongside a denial so the WebDAV
# response can tell a partner (typically an agent) WHY a write was refused -
# which capability is missing, or which rule applies - instead of a bare 403.
# A partner that gets "Forbidden" with no detail resorts to trial and error
# (the reported theme-install pain). Set the reason just before returning the
# code; the dispatcher reads $DENY_REASON into the body + X-Lazysite-Deny-Reason.
sub _deny { ( $DENY_REASON, $DENY_DETAIL ) = ( $_[1], $_[2] ); return $_[0]; }

# SM976: a nav file is a domain's, and dav_scope - a content-path rule - never
# reached it: these paths return before the scope check. So an account confined
# to one domain read and replaced another domain's navigation, and the
# primary's. The rule is the control API's and MCP's (Manager::Nav): reading
# needs one domain the file is the navigation of, writing needs every one. A
# WebDAV account is a grant, so it is confined to its scope, as MCP's are.
sub _nav_reach_deny {
    my ( $rel, $scope, $is_write ) = @_;
    require Lazysite::Manager::Nav;
    no warnings 'once';
    local $Lazysite::Manager::Nav::DOCROOT      = $DOCROOT;
    local $Lazysite::Manager::Nav::LAZYSITE_DIR = $LAZYSITE_DIR;
    my $r = Lazysite::Manager::Nav::nav_file_reach_refusal( $rel, ( $is_write ? 'write' : 'read' ),
        scopes => ( ref $scope eq 'ARRAY' ? $scope : [] ) )
        or return undef;
    return _deny( 403, $r->{error} );
}

# SM976 F2 (ruled 2026-10-09, "Confine both"): a form's conf is that form's, and
# a form is reached through the pages that bind it - Manager::Common's rule,
# which the control API and MCP ask of every form verb. Every WebDAV account is a
# grant, so it is asked with its scopes.
sub _form_reach_deny {
    my ( $name, $scope ) = @_;
    require Lazysite::Manager::Common;
    no warnings 'once';
    local $Lazysite::Manager::Common::DOCROOT  = $DOCROOT;
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
    my $r = Lazysite::Manager::Common::form_reach_refusal( $name,
        scopes => ( ref $scope eq 'ARRAY' ? $scope : [] ) )
        or return undef;
    return _deny( 403, $r->{error} );
}

# Returns an HTTP error code if denied, or undef if allowed.
sub authorise {
    my ( $rel, $scope, $is_write, $conf, $user ) = @_;
    $DENY_REASON = undef;    # cleared here; set by _deny(), read by the caller
    $DENY_DETAIL = undef;

    # SM072: lazysite/nav.conf is agent-editable over WebDAV, gated by the
    # dedicated `manage_nav` capability - the SAME capability the control-API
    # (nav-save) and MCP (set_nav) require for the same file, and the one
    # Capabilities.pm documents as owning nav.conf (cross-plane consistency,
    # 0.8.1: WebDAV previously used the coarser manage_config here). Nav is
    # benign structure and carries no privilege-escalation keys, unlike
    # lazysite.conf which stays denied.
    # SM443: and the same applies to a PER-DOMAIN nav file. This tested
    # `$rel eq 'lazysite/nav.conf'` - an exact match on one filename - so a
    # domain whose nav_file was set to lazysite/nav-<site>.conf had a nav file
    # that NO surface could populate: nav-save writes the shared file, and
    # WebDAV fell through to the blanket lazysite/ denial. domain-set would
    # accept the setting, and because layouts guard on [% IF nav.size %] the
    # result was a site with no navigation rather than an error.
    #
    # The set comes from lazysite.conf and is shape-checked when it is read
    # (see read_conf): lazysite/<name>.conf only. A path that is not CONFIGURED
    # as somebody's nav_file is not admitted here, so this widens the carve-out
    # to the files the sysop has already declared and no further.
    # The DEFAULT nav file keeps its own branch and its literal deny reason.
    # That is not duplication for its own sake: t/lint/68 reads these strings as
    # enforcement's own statement of the rule and checks them against the
    # capability descriptor, so folding this into the dynamic branch below would
    # take lazysite/nav.conf out of that check without anything failing.
    if ( $rel eq 'lazysite/nav.conf' ) {
        return _nav_reach_deny( $rel, $scope, $is_write ) if manage_nav_for($user);
        return _deny( 403, 'editing lazysite/nav.conf requires the manage_nav capability' );
    }

    # Any OTHER path the operator has declared as a nav file.
    if ( ( $conf->{nav_files} || {} )->{$rel} ) {
        return _nav_reach_deny( $rel, $scope, $is_write ) if manage_nav_for($user);
        return _deny( 403, "editing $rel requires the manage_nav capability" );
    }

    # A per-form dispatch config (lazysite/forms/<name>.conf) is agent-editable
    # over WebDAV, gated by `manage_forms` - the same capability the control-API
    # (handler-save / form-targets-save) and MCP (bind_form) require, and the one
    # Capabilities.pm documents as owning lazysite/forms/<name>.conf (cross-plane
    # consistency, 0.8.1: WebDAV previously used manage_config). It only names
    # which handlers a form dispatches to, never credentials. The files that are
    # not forms - smtp.conf (SMTP creds), handlers.conf (handler definitions,
    # addresses) and schedule.conf (what the timer calls, SM842) - and
    # .smtp-password and the submissions store stay denied: handlers and the
    # schedule are created through the handler actions, where the DESTINATION
    # decides who may (SM842), and a raw file write would skip that. A form's
    # own config is shape-checked in do_put: its targets name existing
    # handlers and nothing else.
    if ( $rel =~ m{^lazysite/forms/([A-Za-z0-9_-]+)\.conf$} ) {
        my $name = $1;
        return _deny( 403, "lazysite/forms/$name.conf is protected (it holds credentials/handler definitions) and is not editable over WebDAV" )
            if $name eq 'smtp' || $name eq 'handlers' || $name eq 'schedule';
        return _form_reach_deny( $name, $scope ) if manage_forms_for($user);
        return _deny( 403, "editing lazysite/forms/$name.conf requires the manage_forms capability" );
    }

    # SM071 Phase 3: the one carve-out from the whole-lazysite/ denial is
    # theme/layout authoring under lazysite/layouts/**, governed per object
    # by the manage_themes / manage_layouts capabilities and the active
    # pointers. Everything else under lazysite/ stays denied.
    if ( $rel eq 'lazysite' || $rel =~ m{^lazysite/} ) {
        return authorise_layout( $rel, $is_write, $conf, $user, $scope );
    }

    # SM082: the content namespace requires the content capability (defaults to
    # the webdav grant). A theme-only partner (manage_content off) is refused -
    # they keep theme/layout access via the carve-out above.
    return _deny( 403, 'publishing site content requires the manage_content capability' )
        unless manage_content_for($user);

    # Content namespace: scope confinement (SM155: the UNION of the user's group
    # scopes - allow if the path is within ANY of them) + write blocklist.
    if ( ref $scope eq 'ARRAY' && @$scope ) {
        my $ok = 0;
        for my $sc (@$scope) {
            ( my $s = $sc ) =~ s{^/+|/+$}{}g;
            next unless length $s;
            if ( $rel eq $s || index( $rel, "$s/" ) == 0 ) { $ok = 1; last }
        }
        unless ($ok) {
            my $names = join ', ',
                map { ( my $s = $_ ) =~ s{^/+|/+$}{}g; "$s/" } @$scope;
            return _deny( 403, "outside your assigned WebDAV scope ($names)" );
        }
    }

    # Apply the blocklist on READS as well as writes - otherwise an unscoped
    # account could GET the source of cgi-bin/*.pl (the blocklist's own
    # cgi-bin / manager entries imply these are meant to be unreachable).
    return _deny( 403, 'this path is on the server blocklist (protected file type or location)' )
        if is_blocked( $rel, $conf );

    # SM1139: a file under an address rule is limited by the address it is asked
    # from, over this door as over the page itself - a GET, PUT, DELETE, COPY or
    # MOVE from outside the rule is refused with the ruled sentence, and audited
    # once per file and address per hour. Before the ACL below: it needs no
    # identity, and no capability or ownership lifts it.
    if ( my $by_address = Lazysite::Auth::Acl::address_denial( $rel, 'dav' ) ) {
        return _deny( 403, $by_address->{error} );
    }

    # SM074: per-file ACLs (content namespace; the lazysite/ subtree returned
    # earlier). Ownership + read/write lists come from the central store.
    return _deny( 403, 'a per-file ACL denies you ' . ( $is_write ? 'write' : 'read' ) . ' access to this path' )
        unless acl_allows( $rel, ( $is_write ? 'write' : 'read' ), $user );

    return undef;
}

# SM071 Phase 3: per-object authorisation for the lazysite/layouts/** tree.
# Returns 403 (deny) or undef (allow). dav_scope is a content-namespace
# control and does not apply here - theme/layout reachability is governed by
# the capabilities, the active-pointer read-only rule and (SM976 F1) the reach
# of the sites that serve the theme or layout.
sub authorise_layout {
    my ( $rel, $is_write, $conf, $user, $scope ) = @_;

    my $can_themes  = manage_themes_for($user);
    my $can_layouts = manage_layouts_for($user);
    return _deny( 403, 'theme/layout authoring over WebDAV requires the manage_themes or manage_layouts capability' )
        unless $can_themes || $can_layouts;

    # Only the layouts subtree is reachable; the rest of lazysite/ is denied.
    return _deny( 403, 'only lazysite/layouts/ is writable over WebDAV; the rest of lazysite/ is protected. Install a theme under lazysite/layouts/<layout>/themes/<theme>/' )
        unless $rel eq 'lazysite/layouts'
        || $rel =~ m{^lazysite/layouts/};

    my $active_layout = $conf->{active_layout} // '';
    my $active_theme  = $conf->{active_theme}  // '';

    # SM749: the artefact BEING SERVED is read-only - the rule and its message
    # live in Manager::Common and the choke point (Files.pm) asks the same
    # function, so the three surfaces answer alike and the answer names the
    # workflow (copy, edit, activate) rather than a way round within WebDAV.
    # This stack reads its own pointers and passes them; the rule is pure.
    if ($is_write) {
        require Lazysite::Manager::Common;
        if ( my ( $err, $why ) = Lazysite::Manager::Common::active_artifact_refusal(
                $rel, $active_layout, $active_theme ) )
        {
            return _deny( 403, $err, $why );
        }
        # SM976 F1 (ruled 2026-10-09, "Yes, any served artifact"): and a theme
        # or layout another site serves is that site's. dav_scope does not confine
        # this tree as a content path, but it is the account's reach: a scoped
        # account writes only a pair no site serves, or one only its own domains
        # serve. The rule is Manager::Common's, as the choke point asks it.
        no warnings 'once';
        local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
        if ( my ( $err, $why ) = Lazysite::Manager::Common::served_artifact_refusal(
                $rel, scopes => ( ref $scope eq 'ARRAY' ? $scope : [] ) ) )
        {
            return _deny( 403, $err, $why );
        }
    }

    # The all-layouts container: read-only navigation with either capability.
    return _deny( 403, 'lazysite/layouts is a read-only container; write inside a specific layout (lazysite/layouts/<layout>/)' )
        if $is_write && $rel eq 'lazysite/layouts';
    return undef if $rel eq 'lazysite/layouts';

    my ( $layout, $rest ) = $rel =~ m{^lazysite/layouts/([^/]+)(?:/(.*))?$};
    return _deny( 403, 'malformed layouts path' ) unless defined $layout;
    $rest //= '';

    # SEC-2026-07 (F3): the layouts carve-out returns before the general
    # is_blocked check, so re-assert the extension block here - a theme/layout
    # must never carry an executable or server-config file.
    return _deny( 403, 'that file type is not allowed under lazysite/layouts/ (executable/server-config content)' )
        if $is_write && is_blocked( $rel, $conf );

    # A theme path: lazysite/layouts/<L>/themes/<T>/...
    if ( $rest =~ m{^themes/([^/]+)} ) {
        my $theme = $1;
        return _deny( 403, 'installing or editing a theme requires the manage_themes capability' )
            unless $can_themes;
        return undef;
    }

    # The layout dir or its themes/ container: structural. Readable with
    # either capability (navigation); writing structure needs manage_layouts
    # and the layout must not be the active one.
    if ( $rest eq '' || $rest eq 'themes' ) {
        return undef unless $is_write;
        return _deny( 403, 'authoring layout structure requires the manage_layouts capability' )
            unless $can_layouts;
        return undef;
    }

    # layout.tt and other layout-level assets.
    return _deny( 403, 'editing layout files requires the manage_layouts capability' )
        unless $can_layouts;
    return undef;
}

# SM095: all capability checks go through the one central resolver (caps_for),
# the same one the manager UI / control API / MCP consult - so a group grant
# applies identically over WebDAV.

# FDO-1: caps_for($user), asked once per process.
#
# Every one of the gates below calls it, and so does webdav_enabled_for.
# Each call re-reads groups-settings.json and re-parses the groups file
# (Lazysite::Auth::Settings::read_group_settings and _groups_membership) -
# a write request asks three to five of them, and a COPY or a MOVE up to
# eight, because authorise runs twice.
#
# WHY EVERY CALL AFTER THE FIRST WAS ALREADY GOING TO AGREE. caps_for
# resolves group MEMBERSHIP and the per-group capability union, and reads
# nothing else: the groups file and groups-settings.json, both written only
# by tools/lazysite-users.pl. Nothing a DAV request does touches either -
# the one settings write on this path is SM163's touch_credential, into
# user-settings.json, which caps_for never reads.
#
# THE MEMO'S LIFETIME IS THE PROCESS, and this endpoint is a plain CGI
# under its own ScriptAlias: one process serves one request and exits, so
# the memo's lifetime is the request's. If /dav is ever put behind a
# persistent worker, this needs the (mtime, size) key that
# Auth::Settings::read_settings carries for exactly that reason - a
# capability revoked through the CLI must not go on working because a
# worker is still up.
sub _caps_for {
    my ($user) = @_;
    my $key = defined $user ? $user : '';
    $CAPS_CACHE{$key} = caps_for($user) unless exists $CAPS_CACHE{$key};
    return $CAPS_CACHE{$key};
}

sub manage_themes_for  { return _caps_for( $_[0] )->{manage_themes}  ? 1 : 0 }
sub manage_layouts_for { return _caps_for( $_[0] )->{manage_layouts} ? 1 : 0 }
sub manage_content_for { return _caps_for( $_[0] )->{manage_content} ? 1 : 0 }
sub manage_nav_for     { return _caps_for( $_[0] )->{manage_nav}     ? 1 : 0 }
sub manage_forms_for   { return _caps_for( $_[0] )->{manage_forms}   ? 1 : 0 }

# SEC-2026-07: extensions that must never be written/served (execute or
# reconfigure the server). Always blocked, case-insensitive, in addition to the
# operator's configured list. Parity with Manager::Common @DANGEROUS_EXT.
our @DANGEROUS_EXT
    = qw(pl pm cgi fcgi shtml shtm phtml php php3 php4 php5 phps phar htaccess htpasswd);

sub is_blocked {
    my ( $rel, $conf ) = @_;
    for my $p ( @{ $conf->{blocked_paths} || [] } ) {
        return 1 if $rel eq $p || index( $rel, "$p/" ) == 0;
    }
    my ($ext) = $rel =~ /\.([^.\/]+)$/;
    if ( defined $ext ) {
        $ext = lc $ext;
        return 1 if grep { $ext eq $_ } @DANGEROUS_EXT;
        for my $b ( @{ $conf->{blocked_extensions} || [] } ) {
            return 1 if $ext eq lc $b;
        }
    }
    return 0;
}

# ---------------------------------------------------------------------
# Filesystem resolution
# ---------------------------------------------------------------------

sub resolve_under_docroot {
    my ( $rel, $in_root ) = @_;

    # SM286: content may live in the private store. Choose the TREE first and
    # then run the identical confinement against it, rather than teaching the
    # checks below to span two roots - a boundary test that has to accept two
    # prefixes is a weaker boundary test, and this one is load-bearing.
    #
    # resolve_for_write, so a PUT or MKCOL inside a gated section lands in the
    # private tree with it instead of creating a public directory for it.
    #
    # WebDAV keys its ACL decisions on the REQUEST path, not on the resolved
    # absolute one, so unlike the processor there is no key-derivation to fix
    # here - authorise() already receives the docroot-relative rel.
    # SM836: one answer to "which tree owns this", shared with every write path.
    #
    # SM850: and a `lazysite/...` rel - the sanctioned carve-outs authorise()
    # has already ruled on - is in the engine tree, wherever it is. Rooted at
    # the docroot, a PUT to lazysite/nav.conf on a site whose tree moved beside
    # the docroot (SM293) looked for a directory that is not there.
    my ( $root, $under ) = ( undef, $rel );
    # SM1092: or a named tree - DELETE asks for the OTHER tree's copy of a path
    # held in both, through the same confinement.
    if ( defined $in_root ) {
        $root = $in_root;
    }
    elsif ( $rel =~ m{\Alazysite(?:/(.*))?\z}s ) {
        ( $root, $under ) = ( $LAZYSITE_DIR, $1 // '' );
    }
    else {
        $root = Lazysite::Private::write_root( $DOCROOT, $rel );
    }

    my $droot = defined $root ? realpath($root) : undef;
    return { err => 500 } unless defined $droot;
    if ( !length $under ) {
        return { abs => $droot, parent => $droot, parent_ok => 1, root => $droot };
    }
    my $abs = "$droot/$under";
    ( my $parent = $abs ) =~ s{/[^/]*$}{};
    my $base = ( split m{/}, $rel )[-1];
    my $rp   = realpath($parent);
    # realpath() resolves the existing prefix and appends a missing
    # trailing component without erroring, so an existence check on the
    # resolved parent is required to detect a genuinely-missing parent.
    return { abs => $abs, parent => $parent, parent_ok => 0, root => $droot }
        unless defined $rp && -d $rp;
    return { err => 403 }
        unless $rp eq $droot || index( $rp, "$droot/" ) == 0;
    my $full = "$rp/$base";
    if ( -e $full ) {
        my $tr = realpath($full);
        return { err => 403 }
            unless defined $tr && ( $tr eq $droot || index( $tr, "$droot/" ) == 0 );
        $full = $tr;
    }

    # SM795 (the DAV half). The engine tree is blocked by REQUEST REL - the
    # authorise() path refuses a request whose relative path starts lazysite/ -
    # and everything above confines only to the DOCROOT BOUNDARY on the
    # resolved path. In the inside-docroot layout the engine tree is under the
    # docroot, so a symlink at content/leak.png resolving into lazysite/ passes
    # both: its request rel does not begin with lazysite/, and its real path is
    # inside the docroot.
    #
    # This is the rule the project already holds (SM268): blocklist on the
    # CANONICAL resolved path, never on the request string. The processor's
    # _resolve_include has always done it, and _serve_content_static learned it
    # in the same filing; this is the third and last sink.
    #
    # Checked on BOTH the resolved parent and the resolved target: a symlinked
    # DIRECTORY would otherwise put every file beneath it in reach without any
    # single target resolving into the tree by itself.
    #
    # AND ONLY WHERE THE REQUEST REL IS NOT ITSELF AN ENGINE PATH. This is
    # where DAV differs from the processor, and it is why this half was filed
    # as its own change rather than folded into that one: DAV has SANCTIONED
    # ways into the engine tree - lazysite/nav.conf, lazysite/forms/<name>.conf
    # under manage_forms, the layouts subtree - each carved out in authorise()
    # BY REQUEST REL, which has already ruled on them by the time we get here.
    # A blanket exclusion would refuse those, and the first version of this did
    # exactly that: t/unit/dav/13 caught it.
    #
    # The defect is narrower than "a resolved path in the engine tree". It is a
    # request that does NOT name an engine path resolving into one anyway -
    # which is precisely the symlink, and precisely what authorise() cannot see.
    my $names_engine = $rel =~ m{\Alazysite(?:/|\z)};
    if ( !$names_engine && defined $LAZYSITE_DIR && length $LAZYSITE_DIR ) {
        my $lz = realpath($LAZYSITE_DIR);
        if ( defined $lz ) {
            for my $p ( $rp, $full ) {
                return { err => 403 }
                    if $p eq $lz || index( $p, "$lz/" ) == 0;
            }
        }
    }
    return { abs => $full, parent => $rp, parent_ok => 1, root => $droot };
}

# Parse the Destination header (COPY/MOVE) into a docroot-relative path
# under our /dav mount, or undef. The header value IS url-encoded (it
# is a header, not server-decoded PATH_INFO), so it is decoded here.
sub destination_rel {
    my $dest = $ENV{HTTP_DESTINATION};
    return undef unless defined $dest && length $dest;
    $dest =~ s{^\s+|\s+$}{}g;
    $dest =~ s{^[a-zA-Z][\w+.-]*://[^/]+}{};       # strip scheme://host
    my $prefix = script_prefix();
    return undef unless $dest eq $prefix || index( $dest, "$prefix/" ) == 0;
    my $path = substr( $dest, length $prefix );
    $path =~ s/%([0-9A-Fa-f]{2})/chr hex $1/ge;    # url-decode
    return sanitise_path($path);
}

# ---------------------------------------------------------------------
# Cache invalidation (mirrors action_save / action_delete)
# ---------------------------------------------------------------------

# SM534: the manager's own registry invalidation, run for this surface. The
# manager modules are loaded lazily here and never see their $DOCROOT set, so
# the package var is localised for the call (SM483 shape). Failure is logged,
# never fatal: the write has already happened and must still be answered.
sub _invalidate_registries_as {
    my ($user) = @_;

    # SM557: the module is require'd at runtime, so this file mentions the
    # package variable once by design and perl warns "used only once";
    # t/lint/04 refuses that warning, so the suppression is scoped here.
    no warnings 'once';
    require Lazysite::Manager::Files;
    local $Lazysite::Manager::Files::DOCROOT = $DOCROOT;
    eval { Lazysite::Manager::Files::invalidate_registries(); 1 }
        or log_event( 'WARN', $user, 'registry invalidation failed', error => "$@" );
    return;
}

sub invalidate_cache {
    my ($abs) = @_;
    return unless $abs   =~ /\.md$/;
    ( my $cache = $abs ) =~ s/\.md$/.html/;
    unlink $cache if -f $cache;
    # SM110: drop the per-alias-host copies of this page's render too.
    Lazysite::Util::unlink_host_copies( $DOCROOT, $cache );
}

# ---------------------------------------------------------------------
# Authentication and per-user settings
# ---------------------------------------------------------------------

sub parse_basic_auth {
    my $h = $ENV{HTTP_AUTHORIZATION} // $ENV{REDIRECT_HTTP_AUTHORIZATION} // '';
    return ( undef, undef ) unless $h =~ /^Basic\s+(\S+)/i;
    my $decoded = eval { decode_base64($1) };
    return ( undef, undef ) unless defined $decoded && $decoded =~ /:/;
    my ( $user, $pass ) = split /:/, $decoded, 2;
    return ( undef, undef ) unless defined $user && length $user;
    return ( $user, $pass );
}

sub load_users {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my $path = "$AUTH_DIR/users";
    my %users;
    return \%users unless -f $path;
    open my $fh, '<:utf8', $path or return \%users;
    while (<$fh>) {
        chomp;
        s/^\s+|\s+$//g;
        next if /^#/ || !length;
        my ( $u, $h ) = split /:/, $_, 2;
        $users{$u} = $h if defined $u && defined $h;
    }
    close $fh;
    return \%users;
}

sub webdav_enabled_for {
    return _caps_for( $_[0] )->{webdav} ? 1 : 0;
}

# SM071 Phase 3 (P3.6): per-token volume token-bucket, shared with the
# control API (same store + format under auth/, keyed by user). Defaults
# burst 200 / refill 20/s, env-overridable. Fails open on any IO error.
sub _rate_ok {
    my ($key) = @_;
    my $burst = defined $ENV{LAZYSITE_RATE_BURST}  ? $ENV{LAZYSITE_RATE_BURST}  : 200;
    my $rate  = defined $ENV{LAZYSITE_RATE_REFILL} ? $ENV{LAZYSITE_RATE_REFILL} : 20;
    return { ok => 1 } if $burst <= 0;
    my $path = "$AUTH_DIR/.token-rate.json";
    sysopen( my $fh, $path, O_RDWR | O_CREAT, 0600 ) or return { ok => 1 };
    flock( $fh, LOCK_EX );
    my $raw  = do { local $/; <$fh> };
    my $data = eval { JSON::PP::decode_json( $raw || '{}' ) };
    $data = {} unless ref $data eq 'HASH';
    my $now    = time();
    my $b      = $data->{$key} || { tokens => $burst, last => $now };
    my $tokens = $b->{tokens} + ( $now - ( $b->{last} // $now ) ) * $rate;
    $tokens = $burst if $tokens > $burst;
    my ( $allow, $retry ) = ( 0, 0 );
    if ( $tokens >= 1 ) { $tokens -= 1; $allow = 1 }
    else                { $retry = $rate > 0 ? int( ( 1 - $tokens ) / $rate ) + 1 : 60 }
    $data->{$key} = { tokens => $tokens, last => $now };
    seek( $fh, 0, 0 ); truncate( $fh, 0 ); print $fh JSON::PP::encode_json($data);
    flock( $fh, LOCK_UN ); close $fh;
    return $allow ? { ok => 1 } : { ok => 0, retry_after => $retry };
}

# SM071 Phase 2: a disabled account fails all DAV access.
sub disabled_for {
    my ($user) = @_;
    my $s = read_settings()->{$user};
    return ( ref $s eq 'HASH' && $s->{disabled} ) ? 1 : 0;
}

# SM071 Phase 2: an access token past its expiry is invalid (a password
# or permanent credential has no token_expires_at, so this never trips).
sub token_expired {
    my ($user) = @_;
    my $s = read_settings()->{$user};
    return 0 unless ref $s eq 'HASH' && $s->{token_expires_at};
    return time() > $s->{token_expires_at} ? 1 : 0;
}

# SM165: the content-root scope(s) the user is confined to, resolved from DOMAIN
# access (allowed_groups + locked_users) and capped by the sub-user ceiling - the
# ONE shared resolver every channel uses, so a lock holds identically over WebDAV.
# Returns an arrayref (empty = unconfined; a DENY_ALL_SCOPE element = nothing).
sub scope_for {
    my ($user) = @_;
    return [ resolve_user_scopes( $DOCROOT, $user ) ];
}

# ---------------------------------------------------------------------
# Rate limiting (per IP, failed attempts), mirroring the H-3 limiter
# ---------------------------------------------------------------------

sub dav_rate_blocked {
    my ($ip) = @_;
    return 0 unless $ip;
    my %db;
    eval { require DB_File; 1 } or return 0;
    eval { tie %db, 'DB_File', $DAV_RATE_DB, O_CREAT | O_RDWR, 0o600 };
    return 0 if $@ || !tied %db;
    my $window = int( time() / $RATE_WINDOW );
    my $count  = $db{"$ip:$window"} // 0;
    untie %db;
    return $count >= $RATE_MAX ? 1 : 0;
}

sub dav_rate_record {
    my ($ip) = @_;
    return unless $ip;
    my %db;
    eval { require DB_File; 1 } or return;
    eval { tie %db, 'DB_File', $DAV_RATE_DB, O_CREAT | O_RDWR, 0o600 };
    return if $@ || !tied %db;
    my $window = int( time() / $RATE_WINDOW );
    $db{"$ip:$window"} = ( $db{"$ip:$window"} // 0 ) + 1;
    for my $k ( keys %db ) {
        delete $db{$k} if $k =~ /:(\d+)\z/ && $1 < $window - 1;
    }
    untie %db;
}

# ---------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------

sub read_conf {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my %c = (
        webdav_enabled     => 0,
        dav_allow_insecure => 0,
        max_bytes          => 10 * 1024 * 1024,
        active_layout      => '',                 # SM071 Phase 3: theme/layout pointers
        active_theme       => '',
        blocked_paths      => [ qw(
                lazysite/auth lazysite/forms lazysite/cache
                lazysite/manager cgi-bin manager
        ) ],
        blocked_extensions => [qw(pl cgi)],
        # SM443: every path configured as a navigation file - the base
        # `nav_file` plus each `alias.<host>.nav_file` override. The default is
        # always admitted, so an unconfigured site behaves exactly as before.
        nav_files => { 'lazysite/nav.conf' => 1 },
    );
    my $path = "$LAZYSITE_DIR/lazysite.conf";
    return \%c unless -f $path;
    open my $fh, '<', $path or return \%c;
    while (<$fh>) {
        if    (/^webdav_enabled\s*:\s*(\S+)/)     { $c{webdav_enabled}     = $1 }
        elsif (/^dav_allow_insecure\s*:\s*(\S+)/) { $c{dav_allow_insecure} = $1 }
        elsif (/^layout\s*:\s*(\S+)/)             { $c{active_layout}      = $1 }
        elsif (/^theme\s*:\s*(\S+)/)              { $c{active_theme}       = $1 }
        elsif ( /^manager_upload_max_mb\s*:\s*(\d+)/ && $1 > 0 ) {
            $c{max_bytes} = $1 * 1024 * 1024;
        }
        # Greedy (\S+) so a host containing dots - which every real one does -
        # still splits at the LAST dot before the key. The same reason the
        # processor's alias parse is written that way; keys never contain dots.
        elsif (/^(?:alias\.\S+\.)?nav_file\s*:\s*(.+)/) {
            # SM443: admit only the NAV-FILE SHAPE - lazysite/<name>.conf, one
            # level down, no traversal, no subdirectory. authorise() returns
            # ALLOWED for these before the scope, blocklist and ACL gates run,
            # so a conf value is not permitted to name an arbitrary path: this
            # pattern is the boundary, not a tidy-up. lazysite.conf itself is
            # excluded because it carries privilege-bearing keys, and anything
            # under lazysite/forms/ cannot match a pattern with no slash.
            my $v = $1;
            $v =~ s/^\s+|\s+$//g;
            $c{nav_files}{$v} = 1
                if $v =~ m{\Alazysite/[A-Za-z0-9._-]+\.conf\z}
                && $v ne 'lazysite/lazysite.conf';
        }
        elsif (/^manager_blocked_paths\s*:\s*(.+)/) {
            my $v = $1; $v =~ s/\s+$//;
            $c{blocked_paths} = [ map { s{^/+|/+$}{}gr } grep { length }
                    split /\s*,\s*/, $v ] if length $v;
        }
        elsif (/^manager_upload_blocked_extensions\s*:\s*(.+)/) {
            my $v = $1; $v =~ s/\s+$//;
            $c{blocked_extensions} = [ map { lc } grep { length }
                    split /\s*,\s*/, $v ] if length $v;
        }
    }
    close $fh;
    return \%c;
}

sub max_bytes { return $_[0]->{max_bytes} }

sub is_truthy {
    my ($v) = @_;
    return 0 unless defined $v;
    $v = lc $v;
    return ( $v eq '1' || $v eq 'true' || $v eq 'yes'
            || $v eq 'on' || $v eq 'enabled' ) ? 1 : 0;
}

# ---------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------

sub random_bytes {
    my ($n) = @_;
    open my $fh, '<:raw', '/dev/urandom'
        or die "Cannot open /dev/urandom: $!\n";
    my $buf = '';
    my $got = read( $fh, $buf, $n );
    close $fh;
    die "Short read from /dev/urandom\n" unless defined $got && $got == $n;
    return $buf;
}

sub etag_for {
    my ($st) = @_;
    my ( $dev, $ino, $mtime, $size ) = ( $st->[0], $st->[1], $st->[9], $st->[7] );
    return sprintf( '"%x-%x-%x-%x"', $dev // 0, $ino // 0, $mtime // 0, $size // 0 );
}

# SM071 Phase 3: content SHA-256 of a file (the manifest identity).
sub file_sha256 {
    my ($abs) = @_;
    open my $fh, '<:raw', $abs or return undef;
    my $sha = Digest::SHA->new(256);
    $sha->addfile($fh);
    close $fh;
    return $sha->hexdigest;
}

sub content_type_for {
    my ($rel) = @_;
    my ($ext) = $rel =~ /\.([^.\/]+)$/;
    $ext = lc( $ext // '' );
    return $CONTENT_TYPE_MAP{$ext} // 'application/octet-stream';
}

sub script_prefix {
    my $p = $ENV{SCRIPT_NAME} // '/dav';
    $p =~ s{/+$}{};
    $p = '/dav' unless length $p;
    return $p;
}

sub href_for {
    my ( $rel, $is_dir ) = @_;
    my $href = script_prefix();
    $href .= '/' . uri_escape_path($rel) if length $rel;
    $href .= '/'                         if $is_dir && $href !~ m{/$};
    return xml_escape($href);
}

sub uri_escape_path {
    my ($path) = @_;
    my @out;
    for my $seg ( split m{/}, $path, -1 ) {
        $seg =~ s/([^A-Za-z0-9\-._~])/sprintf '%%%02X', ord $1/ge;
        push @out, $seg;
    }
    return join '/', @out;
}

sub xml_escape {
    my ($s) = @_;
    $s = '' unless defined $s;
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&quot;/g;
    $s =~ s/'/&apos;/g;
    return $s;
}

sub parse_if_tokens {
    my ($if) = @_;
    return () unless defined $if;
    my @tokens;
    push @tokens, $1 while $if =~ /<(opaquelocktoken:[^>]+)>/g;
    return @tokens;
}

sub read_request_body {
    my $len = $ENV{CONTENT_LENGTH};
    return '' unless defined $len && $len =~ /^\d+$/ && $len > 0;
    my $body = '';
    binmode STDIN;
    my $n = read( STDIN, $body, $len );
    $BODY_READ += $n if $n;
    return $body;
}

# SM888 A6: DRAIN A BODY WE REFUSED TO READ.
#
# A refusal decided from the PATH - the reserved tree, a missing capability, a
# lock - answers before anything touches STDIN, and the client is still
# sending. Under one pipe buffer the whole body fits and the client reads its
# 403. Above it the client blocks writing to a process that has exited, and the
# front end - which cannot relay a response for a request that never finished -
# answers 502.
#
# So the status a caller saw depended on the size of a body the server had
# decided not to look at, and the one status that means "stop asking" was the
# one it stopped seeing. The field measured it as 403 under about 100 KB and
# 502 above, on byte-identical re-PUTs.
#
# ONE DRAIN, AT THE ONE PLACE EVERY ANSWER LEAVES THROUGH. Putting it beside
# each refusal would be the same mistake in fifteen copies, and the fifteenth
# would be the one somebody adds next year.
#
# BEFORE the status is written, not after: the point is that the client
# finishes sending, and a status printed into a buffer the client is not
# reading yet helps nobody.
#
# Bounded by CONTENT_LENGTH minus what was already consumed - a successful PUT
# has read it all and drains nothing - and stopped at EOF, so a header that
# overstates the body cannot hold the process open.
sub _drain_request_body {
    my $len = $ENV{CONTENT_LENGTH};
    return unless defined $len && $len =~ /^\d+$/;
    my $remaining = $len - $BODY_READ;
    return unless $remaining > 0;
    binmode STDIN;
    my $buf;
    while ( $remaining > 0 ) {
        my $want = $remaining < $PUT_CHUNK ? $remaining : $PUT_CHUNK;
        my $n    = read( STDIN, $buf, $want );
        last unless $n;
        $remaining -= $n;
        $BODY_READ += $n;
    }
    return;
}

sub copy_tree {
    my ( $src, $dst ) = @_;
    if ( -d $src ) {
        make_path($dst) unless -d $dst;
        opendir my $dh, $src or return 0;
        my @kids = grep { $_ ne '.' && $_ ne '..' } readdir $dh;
        closedir $dh;
        for my $k (@kids) {
            copy_tree( "$src/$k", "$dst/$k" ) or return 0;
        }
        return 1;
    }
    return copy( $src, $dst );
}

# ---------------------------------------------------------------------
# Response emission
# ---------------------------------------------------------------------

sub send_status {
    my ( $code, %o ) = @_;
    send_response( $code, %o );
}

# SM235: a write that fails because the TARGET DIRECTORY is not writable is an
# environment fault, not a server bug, and answering both with a bare 500 leaves
# a client unable to tell three different situations apart: the path is denied to
# this grant (stop asking), the server cannot currently store it (an operator must
# act), or something unexpected broke (report it). A site agent hit the middle
# case - the docroot itself was unwritable while its subdirectories were not - and
# probed to characterise the failure, then reported to the operator that root
# writes were denied by policy, which was wrong. A misleading error costs more
# than a terse one.
#
# 507 is the honest status: the request is valid and the server is at fault, which
# is exactly what a 403 would deny. The body names the operation and the condition
# and NEVER the filesystem path - a client has no use for it and it discloses the
# layout.
# SM284: all five write verbs, not just PUT. DELETE, MOVE, COPY and MKCOL met the
# identical condition and answered with a bare 500 (or, for MKCOL, a 409 whose
# wording was near-identical to the one it returns for a genuinely missing
# parent, so two different faults were indistinguishable to the caller). A write
# path that explains itself on one verb and not the other four is a half-built
# contract, and the half that is missing is the half nobody tested.
#
# Callers pass the paths whose CONTAINING directory the operation needed to
# write, each optionally paired with the role that directory plays in the
# request - because MOVE has two of them and "the target directory" would be a
# guess. First unwritable one wins, so callers order them most-likely-first. A
# bare scalar keeps the PUT wording byte-identical to what SM235 shipped.
sub _write_failure {
    my ( $what, $errno, @where ) = @_;
    for my $w (@where) {
        my ( $abs, $role ) = ref $w eq 'ARRAY' ? @$w : ( $w, 'target' );
        my $dir = $abs;
        $dir =~ s{/[^/]*\z}{};
        next unless length $dir && -d $dir && !-w $dir;
        log_event( 'ERROR', 'dav-write', 'target directory not writable',
            op => $what, role => $role );
        return send_status( 507,
            body => "Cannot $what: the $role directory is not writable by the "
                . "server. This is a server configuration fault, not a permission "
                . "decision about your request - the operator must fix the "
                . "directory permissions.\n" );
    }
    # SM1114 (U12): a full disk or an exhausted quota says so. xisl.com's
    # partner saw "Internal Server Error" for a 600 KB file and could not tell a
    # full disk from a broken server.
    {
        no warnings 'numeric';
        my $n = $errno + 0;
        if ( $n == Errno::ENOSPC() || $n == Errno::EDQUOT() ) {
            log_event( 'ERROR', 'dav-write', 'storage full', op => $what,
                error => "$errno" );
            return send_status( 507,
                body => "Cannot $what: the storage is full ($errno) or the "
                    . "account's quota is used up. Nothing was stored and the "
                    . "partial upload was removed. The operator must free space "
                    . "or raise the quota; retrying will not help until then.\n" );
        }
    }
    log_event( 'ERROR', 'dav-write', 'write failed', op => $what,
        error => "$errno" );
    # SM1114: name the cause (an errno text carries no path) - a bare
    # "Cannot write the file." left the caller to guess.
    return send_status( 500, body => "Cannot $what: $errno.\n" );
}

sub send_response {
    my ( $code, %o ) = @_;
    my $reason = $REASON{$code} // 'Status';

    # SM888 A6: finish reading whatever the caller sent before answering. See
    # _drain_request_body - a refusal decided from the path never touches the
    # body, and a client left blocked on one is what a front end turns into a
    # 502 over the top of a perfectly good 403.
    _drain_request_body();

    binmode( STDOUT, ':utf8' );
    print "Status: $code $reason\r\n";
    # SM071 Phase 3 (P3.6): the retry contract - 423 (locked) and 429
    # (throttled) always carry a Retry-After so clients back off.
    my @headers = @{ $o{headers} || [] };
    if ( ( $code == 423 || $code == 429 )
        && !grep { /^Retry-After:/i } @headers ) {
        push @headers, 'Retry-After: 30';
    }
    for my $h (@headers) {
        print "$h\r\n";
    }
    my $tm = Lazysite::Timing::header_line();    # SM1144
    print "$tm\r\n" if length $tm;
    if ( defined $o{body} ) {
        my $type = $o{type} // 'text/plain; charset=utf-8';
        print "Content-Type: $type\r\n";
        print "\r\n";
        print $o{body};
    }
    else {
        print "\r\n";
    }
    return $code;    # so main() can audit write outcomes
}
