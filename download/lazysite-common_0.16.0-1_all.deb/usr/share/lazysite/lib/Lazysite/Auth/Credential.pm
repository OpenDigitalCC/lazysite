package Lazysite::Auth::Credential;

# Credential primitives shared by the modular lazysite scripts (SM079): a
# /dev/urandom CSPRNG, password + token hashing and verification, single-use
# secret verification, and token minting. Stored credentials are
# `sha256iter:salt:iters:hash` (passwords iters=100k, tokens iters=1). The
# processor does not use this module.

use strict;
use warnings;
use Digest::SHA    qw(sha256_hex);
use Lazysite::Util qw(const_eq);
use Exporter 'import';

our @EXPORT_OK = qw(
    generate_random_hex hash_password verify_password
    hash_token verify_secret generate_token
    password_min_length password_policy_refusal
);

# CSPRNG: $bytes of /dev/urandom as a hex string. Dies (fail-closed) if the
# kernel CSPRNG is unavailable or short-reads.
sub generate_random_hex {
    my ($bytes) = @_;
    open my $fh, '<:raw', '/dev/urandom'
        or die "Cannot open /dev/urandom - no CSPRNG available: $!\n";
    my $raw = '';
    my $got = read( $fh, $raw, $bytes );
    close $fh;
    die "Short read from /dev/urandom ($got of $bytes bytes)\n"
        unless defined $got && $got == $bytes;
    return unpack( 'H*', $raw );
}

# DA-27: THE SALTED ITERATION, ONCE. Four subs wrote out the same loop.
# hash_token's single round is this loop with $iters = 1, which is what its
# comment already said it was.
sub _iterate {
    my ( $salt, $plain, $iters ) = @_;
    my $h = $plain;
    $h = sha256_hex( $salt . $h ) for 1 .. $iters;
    return $h;
}

# Salted, iterated password hash (100k iterations).
sub hash_password {
    my ($password) = @_;
    my $salt       = generate_random_hex(16);                # 32 hex chars = 16 bytes
    my $iters      = 100_000;
    my $hash       = _iterate( $salt, $password, $iters );
    return "sha256iter:$salt:$iters:$hash";
}

# Verify a password against a stored hash. Handles the salted format and the
# legacy unsalted SHA-256 (which the caller rehashes on success). Constant-time.
sub verify_password {
    my ( $password, $stored ) = @_;
    return 0 unless defined $password && defined $stored && length $stored;
    if ( $stored =~ /\Asha256iter:([0-9a-f]{32}):(\d+):([0-9a-f]{64})\z/ ) {
        my ( $salt, $iters, $expected ) = ( $1, $2, $3 );
        return 0 if $iters < 1 || $iters > 1_000_000;    # sanity cap
        my $hash = _iterate( $salt, $password, $iters );
        return const_eq( $hash, $expected );
    }
    elsif ( $stored =~ /\A[0-9a-f]{64}\z/ ) {
        # Legacy unsalted SHA-256 - accept, caller rehashes on success.
        return const_eq( sha256_hex($password), $stored );
    }
    return 0;
}

# Single-iteration salted hash for an access token (the token is high-entropy,
# so one round suffices; this just avoids storing it in the clear).
sub hash_token {
    my ($token) = @_;
    my $salt    = generate_random_hex(16);
    my $hash    = _iterate( $salt, $token, 1 );
    return "sha256iter:$salt:1:$hash";
}

# Verify a single-use secret (claim / pairing key / recovery code) against its
# stored sha256iter hash. Constant-time.
sub verify_secret {
    my ( $plain, $stored ) = @_;
    return 0 unless defined $plain && defined $stored;
    return 0 unless $stored =~ /\Asha256iter:([0-9a-f]+):(\d+):([0-9a-f]{64})\z/;
    my ( $salt, $iters, $want ) = ( $1, $2, $3 );
    my $h = _iterate( $salt, $plain, $iters );

    # DA-27: const_eq, which is imported, IS this comparison - same length
    # check first, same xor-accumulate, same 1/'' answer.
    return const_eq( $h, $want );
}

# Mint a new access token (lzs_ + 32 random bytes).
sub generate_token {
    return 'lzs_' . generate_random_hex(32);    # 64 hex chars = 32 bytes
}

# SM1041 (ruled 2026-10-12, "Min 12, configurable"): THE PASSWORD POLICY, ONCE.
#
# A password was refused only when empty. `password_min_length` in lazysite.conf
# sets the shortest password any door accepts - the users tool's add, passwd and
# account-create, a redeemed setup or reset link, setup-sysop, and the member's
# own change on /account - and it is read here so that all of them ask the same
# question of the same file. Existing passwords keep working until changed:
# this is asked only when a password is SET, never when one is checked.
#
# The default is 12. A value outside 8..128 is a typo rather than a policy and
# falls back to the default, as session_lifetime treats one: 8 is the floor NIST
# SP 800-63B sets for a chosen password, and above 128 nobody could type it.
# Length is counted in characters, so a non-ASCII password is not credited
# with its bytes.
our $PASSWORD_MIN_DEFAULT = 12;

sub password_min_length {
    my ($lazysite_dir) = @_;
    my $v;
    if ( defined $lazysite_dir && length $lazysite_dir
        && open my $fh, '<', "$lazysite_dir/lazysite.conf" )
    {
        while ( my $l = <$fh> ) {
            next unless $l =~ /^\s*password_min_length\s*:\s*(\d+)\s*$/;
            $v = $1 + 0;
            last;
        }
        close $fh;
    }
    $v = undef unless defined $v && $v >= 8 && $v <= 128;
    return $v // $PASSWORD_MIN_DEFAULT;
}

# The refusal for a password the policy does not accept, or undef. One sentence,
# naming the length and nothing about any account, so it is safe to show on a
# page nobody has signed in to.
sub password_policy_refusal {
    my ( $password, $lazysite_dir ) = @_;
    my $min   = password_min_length($lazysite_dir);
    my $chars = defined $password ? $password : '';
    utf8::decode($chars) unless utf8::is_utf8($chars);
    return "A password must be at least $min characters long."
        if length($chars) < $min;
    return undef;
}

1;
