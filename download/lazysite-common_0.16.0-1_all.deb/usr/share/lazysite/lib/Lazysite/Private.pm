package Lazysite::Private;

# SM286 step 1: the private content store - a tree OUTSIDE the document root
# holding content that is gated, so no front end can serve it whatever its
# configuration says.
#
# WHY THIS EXISTS. Three defects in three releases (SM248, SM268 H17, SM283)
# were one cause: security living in front-end configuration that lazysite ships
# as templates, cannot test where it is installed, and on most deployments
# cannot even see. SM283 was live across a fleet for weeks - a protected section
# gating its pages and serving its images, PDFs and archives to anyone who knew
# the path, because Hestia's nginx answered by file extension before Apache saw
# the request.
#
# Every fix so far has been "put the rule in one more config file". This is the
# other answer: if the bytes are not in a directory any front end serves, no
# front-end rule is needed and none can be got wrong. It makes SM283
# structurally impossible rather than fixed once per deployment shape.
#
# WHERE. A sibling of the docroot, not a subdirectory of it - a subdirectory is
# exactly what the front end serves. The docroot's parent already holds engine
# files on the Hestia layout (tools/, lazysite-log.pl), so this follows an
# established convention rather than inventing a location.
#
# THE INVARIANT, and it is the whole point: a path is in EXACTLY ONE tree. A
# copy left in the docroot is the very exposure this removes, so a move that
# cannot complete leaves the content where it was and reports failure - it never
# leaves both.

use strict;
use warnings;
# make_path is deliberately NOT imported: it CROAKS, and an unqualified call is
# how SM296 happened. _mkpath below is the only way this module creates a
# directory, and it returns.
use File::Path     qw(remove_tree);
use File::Basename qw(dirname basename);
use File::Copy     qw(copy);
use Cwd            qw(realpath);
use Errno          qw(EXDEV);
use Exporter 'import';

our @EXPORT_OK = qw(private_root private_path resolve resolve_for_write
    write_root is_private move_in move_out stray_public count_private ensure_store);

# The store's directory name. A leading dot would hide it from a sysop
# looking at the tree, and the point is that they can see where their private
# content went.
our $DIRNAME = 'lazysite-private';

# The store is named for the docroot it shadows, NOT a fixed name in the parent.
#
# A fixed "<parent>/lazysite-private" is shared by every docroot with the same
# parent. Two sites side by side - /srv/sites/a and /srv/sites/b, which is what
# the dev server invites and what a container image tends to look like - would
# then share ONE private store, and each would resolve the other's protected
# content by path. Two sites' members-only content silently merged is a worse
# disclosure than the one this store exists to remove.
#
# It was not a hypothetical: every test using a bare tempdir() as its docroot had
# a parent of /tmp, so the whole suite shared /tmp/lazysite-private and files
# from one test file appeared in another. That is the same defect, found the easy
# way.
#
# Deriving the name from the docroot makes collision impossible: two docroots
# with the same parent have different basenames, or they are the same directory.
sub private_root {
    my ($docroot) = @_;
    return undef unless defined $docroot && length $docroot;
    $docroot =~ s{/+\z}{};
    return undef unless length $docroot;
    return dirname($docroot) . '/' . basename($docroot) . "-$DIRNAME";
}

sub private_path {
    my ( $docroot, $rel ) = @_;
    my $root = private_root($docroot) or return undef;
    $rel = '' unless defined $rel;
    $rel =~ s{\A/+}{};
    return length $rel ? "$root/$rel" : $root;
}

# Where does this path actually live? Returns ( $abs, $where ) with $where being
# 'private', 'public' or '' (nowhere).
#
# PRIVATE WINS when both exist. That is not a preference, it is the fail-safe
# direction: if a stray public copy is left behind, the front end can already
# serve it, and having the engine ALSO serve the public one would hide the fault
# from every check that compares them. Preferring private means the engine
# serves the governed copy while stray_public() can still report the leak.
sub resolve {
    my ( $docroot, $rel ) = @_;
    return ( undef, '' ) unless defined $rel && length $rel;
    $rel =~ s{\A/+}{};

    my $priv = private_path( $docroot, $rel );
    return ( $priv, 'private' ) if defined $priv && -e $priv;

    my $pub = "$docroot/$rel";
    return ( $pub, 'public' ) if -e $pub;

    return ( undef, '' );
}

sub is_private {
    my ( $docroot, $rel )   = @_;
    my ( undef,    $where ) = resolve( $docroot, $rel );
    return $where eq 'private' ? 1 : 0;
}

# Where a path should be WRITTEN, which is not the same question as where it is.
#
# Existing content keeps its home. A NEW path inherits the tree of its nearest
# existing ancestor - so a file created inside a gated folder is created
# PRIVATELY. Without that rule a naive save recreates a public copy of a section
# that was moved out: the folder does not exist in the docroot, mkdir -p makes
# it, and the section is half-published by an operation nobody thought of as a
# permission change. That is the "one write choke point" the filing asks for,
# expressed as a resolution rule rather than a check every caller must remember.
sub resolve_for_write {
    my ( $docroot, $rel ) = @_;
    return ( undef, '' ) unless defined $rel && length $rel;
    $rel =~ s{\A/+}{};

    # SM438: the theme-asset mirror is ENGINE-OWNED, DERIVED output, and its
    # canonical writer - the activation mirror's cp -r - writes the public tree
    # unconditionally. So a write to it resolves public unconditionally too.
    # Before this, "existing content keeps its home" sent an UPDATE of any
    # mirror file that had a private-store copy to the private store: the PUT
    # answered 204, the bytes landed where nothing serves them, and the public
    # mirror kept serving the old content - create worked, update was a silent
    # no-op, which is exactly what the field reported. The one write path that
    # disagreed with the mirror writer about where the mirror lives loses.
    return ( "$docroot/$rel", 'public' ) if $rel =~ m{\Alazysite-assets(?:/|\z)};

    my ( $abs, $where ) = resolve( $docroot, $rel );
    return ( $abs, $where ) if $where;

    # SM981 (ruled 2026-10-11, "Land where save would"): A NEW PATH A RELOCATING
    # RULE GOVERNS IS WRITTEN PRIVATELY, whatever the tree says. The walk below
    # reads the trees, and a tree can be wrong: one stray public copy of a held-
    # back folder (a move that landed in the docroot, a front-end upload, a git
    # merge) recreates the folder in the docroot, after which "a public ancestor
    # settles it" sent EVERY later save, upload and PUT into that folder public
    # too. The rule is the statement of intent, so it decides; the tree decides
    # only what the rules leave open. An unreadable store ('unknown') changes
    # nothing here - the tree evidence stands, as before.
    {
        require Lazysite::Auth::Acl;
        my $placed = eval { Lazysite::Auth::Acl::placement_for( $docroot, $rel ) } // 'unknown';
        if ( $placed eq 'private' ) {
            my $p = private_path( $docroot, $rel );
            return ( $p, 'private' ) if defined $p;
        }
    }

    # An ancestor that exists in the DOCROOT settles it as public, and is checked
    # FIRST - a directory existing in the store is not on its own evidence that
    # the folder is gated.
    #
    # Moving a single FILE into the store creates its parent directories there
    # too. Using resolve() here, that bare container made the folder look
    # private, so protecting one file in `content/` silently caused every file
    # created in `content/` afterwards to be written privately - unpublishing new
    # public content through an operation nobody thinks of as a permission
    # change, which is the exact failure this function was written to prevent,
    # pointed the other way.
    #
    # The distinction is structural and needs no ACL lookup: a genuinely gated
    # folder was MOVED, so it does not exist in the docroot at all. A folder in
    # both trees is a public folder that happens to hold some private files.
    my @parts = split m{/}, $rel;
    pop @parts;    # the path itself does not exist; start at its parent
    while (@parts) {
        my $anc = join( '/', @parts );
        last if -e "$docroot/$anc";    # a public ancestor settles it

        my $priv_anc = private_path( $docroot, $anc );
        return ( private_path( $docroot, $rel ), 'private' )
            if defined $priv_anc && -e $priv_anc;

        pop @parts;
    }
    return ( "$docroot/$rel", 'public' );
}

# SM836: WHICH TREE OWNS A WRITE TARGET - the docroot, or the private store.
#
# Every write path has to answer this before it touches the filesystem, and until
# now the ones that answered it each wrote the same five lines by hand: call
# resolve_for_write, discard the path, and swap in private_root when the answer
# was 'private'. lazysite-dav.pl did it; Manager::Upload did it after SM836 found
# it missing. Three faults in one release cycle came from write paths that
# disagreed with the store about where a gated file lives - SM438 (a mirror update
# landed where nothing serves it), SM418/SM286 (an upload wrote a public copy
# beside protected content) and SM836 (an upload could not find a protected folder
# at all) - and every one was found by a person hitting it.
#
# So the answer lives here, once. A caller confines against the root this returns,
# which is the whole of what the hand-written copies were doing; t/lint/128 fails
# any other file that rebuilds it from resolve_for_write and private_root.
#
# An empty rel is the docroot itself.
sub write_root {
    my ( $docroot, $rel ) = @_;
    return $docroot unless defined $rel && length $rel;
    my ( undef, $where ) = resolve_for_write( $docroot, $rel );
    return ( $where // '' ) eq 'private' ? private_root($docroot) : $docroot;
}

# A path that exists in BOTH trees. Always a fault: the private copy is the one
# the engine governs and the public one is reachable without asking it. Surfaced
# rather than silently repaired, because deleting content is not a repair a tool
# should decide on its own.
sub stray_public {
    my ( $docroot, $rel ) = @_;
    return 0 unless defined $rel && length $rel;
    $rel =~ s{\A/+}{};
    my $priv = private_path( $docroot, $rel );
    return ( defined $priv && -e $priv && -e "$docroot/$rel" ) ? 1 : 0;
}

# Count the regular files held in the store under a relative prefix ('' or undef
# = the whole store). Directories and symlinks are not counted; the question this
# answers is always "how much CONTENT is in there", asked by something that is
# about to tell an operator a number.
#
# SM286: exists so that code which cannot carry private content has to state how
# much it left behind. A silent omission is the failure mode this whole work item
# is about, and a caller with no way to count is a caller that will stay silent.
sub count_private {
    my ( $docroot, $rel ) = @_;
    my $base = private_path( $docroot, $rel );
    return 0 unless defined $base && -d $base;
    # SM557: the package is require'd at runtime, so this file mentions the
    # variable once by design - t/lint/04 refuses the 'used only once' warning.
    no warnings 'once';
    require File::Find;
    my $n = 0;
    File::Find::find(
        { no_chdir => 1,
            wanted => sub {
                my $p = $File::Find::name;
                return if -l $p;    # never follow a link out of the store
                $n++   if -f $p;
            },
        },
        $base
    );
    return $n;
}

# make_path that RETURNS rather than dies.
#
# SM296: `make_path($parent) unless -d $parent` looks like it reports failure by
# returning false. It does not - File::Path::make_path CROAKS. So the guard on
# the very next line ("cannot create the private store") was unreachable, and an
# unwritable parent threw straight out through action_acl_set and killed the CGI.
#
# What that cost, live on 0.10.8: the ACL is saved BEFORE the move, so the rule
# was stored and honoured for pages while the content stayed in the document
# root and kept being served - SM283's exposure, reached through the mechanism
# built to make it impossible. The caller saw "Tool error"; the audit line was
# never written, because the process died before it. The documented warning for
# exactly this case existed and could not be reached.
#
# Both callers already handle a false return correctly. They only ever needed
# the failure to BE a return.
# SM323: a directory in the store must be usable by the identity that writes
# content, which is the CGI - not merely by whoever happened to create it.
#
# This was a bare make_path. Whoever called it first owned the result with a
# umask default, and there are two callers with different identities: the
# operator sweep runs as the SITE USER, and an ordinary protect runs as the CGI.
# The sweep gets there first on any site being repaired, so the store ended up
# owned by the site user with no group write - and protecting content through
# the manager UI, MCP or the control API then failed with Permission denied
# while `acl reapply` succeeded. Protection became an operator-only operation on
# a product whose partner surfaces are supposed to perform it.
#
# The store is the docroot's private twin, so it carries the DOCROOT's identity -
# not its own parent's. The parent is the domain folder, which on the Hestia
# layout is root-owned 0551, and matching that would lock everyone out. That is
# why Util::secure_write_perms, which mirrors the parent, is the wrong helper
# here despite being the obvious one.
#
# Mode 2770 rather than the docroot's 2775: setgid so content moved in keeps the
# group, and no world bit, because the whole point of this tree is that content
# in it is not readable by anything that has not asked the engine.
sub _store_perms {
    my ( $docroot, $dir ) = @_;
    return unless defined $docroot && defined $dir && -d $dir;
    my @d = stat $docroot or return;
    my ( $duid, $dgid ) = @d[ 4, 5 ];

    # Root can set both. Anyone else can set the group only, and only to a group
    # they belong to - best effort, because the alternative is refusing to
    # protect content at all on a correctly configured site.
    if ( $> == 0 ) { chown $duid, $dgid, $dir }
    else           { chown -1, $dgid, $dir }
    chmod 02770, $dir;
    return;
}

sub _mkpath {
    my ( $dir, $docroot ) = @_;
    return 1 if -d $dir;
    my $err;
    File::Path::make_path( $dir, { error => \$err } );
    return 0 unless -d $dir;

    # Every level this call created, not just the leaf: make_path may have made
    # the store root itself, and that is the one the CGI must write into.
    if ( defined $docroot ) {
        my $root = private_root($docroot);
        if ( defined $root && -d $root ) {
            my $rel = $dir;
            if ( index( $rel, "$root/" ) == 0 || $rel eq $root ) {
                my $walk = $root;
                _store_perms( $docroot, $walk );
                for my $seg ( split m{/}, substr( $dir, length $root ) ) {
                    next unless length $seg;
                    $walk .= "/$seg";
                    _store_perms( $docroot, $walk );
                }
            }
        }
    }
    return 1;
}

# The store root, made with the docroot's identity if it is absent (SM769:
# a restore extracts into it, and the parent it would otherwise be created
# under is the domain folder the request path cannot open). Returns 1 when
# the store exists afterwards, 0 when it could not be made.
sub ensure_store {
    my ($docroot) = @_;
    my $root = private_root($docroot) or return 0;
    return _mkpath( $root, $docroot );
}

# Confinement: never let a caller's path escape either tree. Both roots are
# resolved with realpath so a symlink cannot be used to write outside.
sub _within {
    my ( $root, $abs ) = @_;
    return 0 unless defined $root && defined $abs;
    my $rroot = realpath($root)           or return 0;
    my $rabs  = realpath( dirname($abs) ) or return 0;
    return ( $rabs eq $rroot || index( $rabs, "$rroot/" ) == 0 ) ? 1 : 0;
}

# SM307: say why the rename failed, having checked.
#
# This reported one of two causes and determined NEITHER. On the host where it
# was found both were wrong, and the correct diagnosis was available two layers
# away in the same codebase - the WebDAV layer, on the same docroot, minutes
# apart, said "the target directory is not writable by the server. This is a
# server configuration fault, rather than a permission decision about your
# request - the sysop must fix the directory permissions", which was exactly
# right. The ACL path said "cannot move a folder across filesystems".
#
# The old comment was honest about the uncertainty - "Cross-device, or a rename
# the filesystem refused" - and the message below it dropped the second half and
# stated the first as fact. rename() sets $!, so the distinction the comment
# already drew was one branch away from being made.
#
# The wrong diagnosis is expensive: mount layout is not something a sysop
# changes casually, and on the Hestia layout the store sits in the domain folder
# beside public_html, which looks like somewhere a separate mount could
# plausibly be. The suggested cause is credible enough to be investigated, and
# the real fix was a chown.
#
# Worse, it CONTRADICTED a check that shipped alongside it: SM296 added a
# `lazysite check` report on whether the store exists, is writable, or could be
# created, naming the directory, its owner and its mode. On a host where the
# docroot is not writable that check answers correctly while this blamed the
# filesystem layout - two parts of one release giving a sysop different
# accounts of one fault, and the wrong one returned at the moment they act.
#
# Both directions share this so a single condition cannot be described two ways
# depending on which way the content was going.
sub _move_failure {
    my ( $src, $dst, $is_dir ) = @_;
    my $errno = $!;

    # A genuine cross-device move of a DIRECTORY is the one case the original
    # message described correctly. Name both locations, because the sysop's
    # next question is which two filesystems.
    if ( $errno == EXDEV && $is_dir ) {
        return "cannot move a folder across filesystems: \"$src\" and \"$dst\" "
            . 'are on different mounts, and moving a folder between them '
            . 'cannot be done in one atomic step. Protecting a section refuses '
            . 'rather than copy-then-delete, because a partial copy would leave '
            . 'half a section public.';
    }

    # Everything else. Borrow the shape of the WebDAV wording, which separates a
    # server configuration fault from a decision about the request - the ACL
    # path has MORE need of that distinction, because its failure leaves content
    # served while the rule reads as applied.
    return "could not move \"$src\" into place: $errno. This is a server "
        . 'configuration fault rather than a permission decision about your '
        . 'request - `lazysite check` reports the private store\'s directory, '
        . 'owner and mode, and `lazysite check --fix` repairs a docroot that '
        . 'came back from a control-panel rebuild without group write.';
}

# Move public -> private. Returns ( $ok, $error ).
#
# rename() is atomic within a filesystem and moves a whole directory in one
# step, which is what makes protecting a section safe: there is no window in
# which half a section is public. Across filesystems it fails with EXDEV, and
# for a FILE the fallback copies, VERIFIES, and only then removes the original -
# so an interrupted copy leaves the content public and reports failure, rather
# than leaving it half-moved and unreadable.
#
# SM307: THE FALLBACK COVERS FILES ONLY. A directory stops at the -d guard below
# and is refused, deliberately - a recursive copy-then-delete would reintroduce
# exactly the window that rename() exists to close, on the operation whose whole
# purpose is to close it. Since a folder ACL is the normal way to protect a
# section, the fallback is unreachable in the common case, and the comment above
# used to describe it as though it were general.
sub move_in {
    my ( $docroot, $rel ) = @_;
    $rel = '' unless defined $rel;
    $rel =~ s{\A/+}{};
    return ( 0, 'no path given' ) unless length $rel;

    my $src = "$docroot/$rel";
    return ( 1, undef ) unless -e $src;    # nothing to move is not a failure

    my $dst = private_path( $docroot, $rel );
    return ( 0, 'cannot resolve the private store' ) unless defined $dst;

    my $parent = dirname($dst);
    _mkpath( $parent, $docroot );

    # SM307: whatever the store cannot do, a file and a folder describe it the
    # same way. This branch is where a SINGLE FILE failed on the host that
    # prompted the filing, producing "cannot create the private store" for the
    # very condition a folder reported as a cross-filesystem move - one fault,
    # two messages, neither naming the cause.
    return ( 0, "cannot create the private store at \"$parent\": $!. This is a "
            . 'server configuration fault rather than a permission decision '
            . 'about your request - `lazysite check` reports the store\'s '
            . 'directory, owner and mode, and `lazysite check --fix` repairs a '
            . 'docroot that came back from a control-panel rebuild without '
            . 'group write.' )
        unless -d $parent;
    return ( 0, 'refusing a path outside the private store' )
        unless _within( private_root($docroot), $dst );

    # An existing destination means a previous move left something behind. Do
    # not overwrite it silently - that would destroy the governed copy in
    # favour of one the front end has been serving.
    #
    # SM981 (ruled 2026-10-11, "Land where save would"): AND DO NOT REFUSE
    # EITHER - this was the repair's dead end. A held-back folder whose stray
    # public copy appeared after it was protected (a move that landed in the
    # docroot, a front-end upload) exists in BOTH trees, and every re-issue of
    # its rule - `acl reapply`, which exists to repair exactly this - stopped
    # here with the stray still public. So the stray is MERGED IN: what the
    # store lacks moves in; what both hold is decided by _merge_in (the store's
    # copy wins, the public one is kept as a recoverable backup outside both
    # trees). Never exposed, never deleted.
    return _merge_in( $docroot, $rel, $src, $dst ) if -e $dst;

    return ( 1, undef ) if rename $src, $dst;

    return ( 0, _move_failure( $src, $dst, 1 ) ) if -d $src;
    return ( 0, _move_failure( $src, $dst, 0 ) ) unless copy( $src, $dst );
    unless ( -s $dst == -s $src ) {
        unlink $dst;
        return ( 0, 'the copy did not match the original; nothing was moved' );
    }
    unlink $src or return ( 0, 'the copy landed but the original could not be '
            . 'removed - the content is still public' );
    return ( 1, undef );
}

# SM981: move one FILE, atomically where the filesystem allows, else copy,
# verify the size, and only then remove the original. 1 on success.
sub _move_one {
    my ( $from, $to ) = @_;
    return 1 if rename $from, $to;
    return 0 if -d $from;
    return 0 unless copy( $from, $to );
    unless ( -s $to == -s $from ) { unlink $to; return 0 }
    return unlink($from) ? 1 : 0;
}

# SM981 (ruled 2026-10-11, "Land where save would"): A PATH HELD IN BOTH TREES,
# put right without exposing or deleting anything. Returns ( $ok, $error, \@notes ).
#
# WHICH COPY WINS, AND WHY: THE PRIVATE STORE'S. It is the copy the rule governs
# and the one the engine has been serving under that rule (Private::resolve
# prefers it when both exist), so it is what the rule's readers have seen; the
# public one is the copy a front end has been handing to anyone, and it must
# leave the document root either way. Neither is deleted: the public copy of a
# path both trees hold is moved to <engine tree>/displaced/<UTC stamp>/<path> -
# outside the document root and outside the private store, in the engine tree
# the front door refuses and the shipped front-end configs deny - where a sysop
# can recover it. Every such move is named in the notes.
#
# A FOLDER IN BOTH TREES MERGES: each file under the public copy that the store
# lacks moves into the store at the same place; each one the store already holds
# is displaced as above. A symlink is never moved into the store (it could point
# a governed path anywhere); it is displaced. The emptied public folders are then
# removed. If anything could not be moved, the answer is a failure naming how
# many paths are still public, so the caller reports it rather than "done".
#
# A file in one tree and a folder in the other cannot be merged and is refused,
# moving nothing.
sub _merge_in {
    my ( $docroot, $rel, $src, $dst ) = @_;
    my ( $sdir, $ddir ) = ( ( -d $src && !-l $src ) ? 1 : 0, -d $dst ? 1 : 0 );
    if ( $sdir != $ddir ) {
        return ( 0, "'$rel' is a " . ( $sdir ? 'folder' : 'file' ) . ' in the document root and a '
                . ( $ddir ? 'folder' : 'file' ) . ' in the private store, so the two cannot be merged; '
                . 'nothing was moved - move one of them aside by hand and apply the rule again' );
    }
    my $stamp;
    my $displace = sub {
        my ( $from, $sub ) = @_;
        require POSIX;
        require Lazysite::Paths;
        $stamp //= POSIX::strftime( '%Y%m%dT%H%M%SZ', gmtime ) . "-$$";
        my $to = Lazysite::Paths::lazysite_dir($docroot) . "/displaced/$stamp/$sub";
        _mkpath( dirname($to) );
        return undef unless -d dirname($to);
        return _move_one( $from, $to ) ? $to : undef;
    };
    my ( @notes, @failed );
    my $why = 'the private store\'s copy is kept - it is the one the rule governs and the '
        . 'engine serves - and the document root\'s copy was moved';

    if ( !$sdir ) {
        my $to = $displace->( $src, $rel );
        return ( 0, "both trees hold '$rel' and the document root's copy could not be moved "
                . 'aside - it is still public' )
            unless defined $to;
        return ( 1, undef, ["both trees held '$rel': $why to $to, outside both trees, where it can be recovered"] );
    }

    require File::Find;
    my ( @files, @dirs );
    File::Find::find( { no_chdir => 1, wanted => sub {
                return if $File::Find::name eq $src;
                if ( -d $File::Find::name && !-l $File::Find::name ) { push @dirs, $File::Find::name }
                else { push @files, $File::Find::name }
    } }, $src );
    my $moved = 0;
    for my $f ( sort @files ) {
        ( my $sub = substr( $f, length $src ) ) =~ s{\A/+}{};
        my $target = "$dst/$sub";
        if ( -l $f || -e $target || -l $target ) {
            my $to = $displace->( $f, "$rel/$sub" );
            if ( defined $to ) { push @notes, "both trees held '$rel/$sub': $why to $to, where it can be recovered" }
            else               { push @failed, "$rel/$sub" }
            next;
        }
        _mkpath( dirname($target), $docroot );
        if ( -d dirname($target) && _within( private_root($docroot), $target ) && _move_one( $f, $target ) ) {
            $moved++;
        }
        else { push @failed, "$rel/$sub" }
    }
    rmdir $_ for sort { length $b <=> length $a } @dirs;
    rmdir $src;
    unshift @notes, "'$rel' was in both trees: $moved file(s) the store lacked were moved into it"
        if $moved;
    return ( 0, scalar(@failed) . " path(s) under '$rel' could not be moved out of the document "
            . 'root and are still public: ' . join( ', ', @failed ), \@notes )
        if @failed;
    return ( 1, undef, \@notes );
}

# Move private -> public, for un-protecting. Same contract in reverse.
sub move_out {
    my ( $docroot, $rel ) = @_;
    $rel = '' unless defined $rel;
    $rel =~ s{\A/+}{};
    return ( 0, 'no path given' ) unless length $rel;

    my $src = private_path( $docroot, $rel );
    return ( 1, undef ) unless defined $src && -e $src;

    my $dst = "$docroot/$rel";
    return ( 0, 'the docroot already holds this path' ) if -e $dst;

    my $parent = dirname($dst);
    _mkpath($parent);
    return ( 0, 'cannot create the destination folder' ) unless -d $parent;
    return ( 0, 'refusing a path outside the docroot' )
        unless _within( $docroot, $dst );

    return ( 1, undef ) if rename $src, $dst;

    # SM307: the same reporter as move_in. Un-protecting used to misreport the
    # identical condition in the identical way, so an operator hitting one fault
    # from two directions got two different accounts of it.
    return ( 0, _move_failure( $src, $dst, 1 ) ) if -d $src;
    return ( 0, _move_failure( $src, $dst, 0 ) ) unless copy( $src, $dst );
    unless ( -s $dst == -s $src ) {
        unlink $dst;
        return ( 0, 'the copy did not match the original; nothing was moved' );
    }
    unlink $src or return ( 0, 'the copy landed but the private original could '
            . 'not be removed' );
    return ( 1, undef );
}

1;
