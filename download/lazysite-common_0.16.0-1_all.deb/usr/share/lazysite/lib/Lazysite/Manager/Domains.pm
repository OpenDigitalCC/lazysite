package Lazysite::Manager::Domains;

# SM154 (P2): the domain engine - configure / list / update / remove the
# domains this one lazysite instance serves. A domain is `alias_hosts` (the
# comma list of served hosts) + `alias.<host>.<key>` overrides in
# lazysite.conf, plus a content-root directory under the docroot. This module
# is the SINGLE source of that logic, shared by the manager control-API
# (domain-* actions) and the `lazysite-domains` CLI, so an external control
# panel can drive the lazysite side identically to the UI.
#
# HARD SCOPE LINE: lazysite owns only the lazysite side (conf + content root).
# DNS, the web-server domain alias and TLS are a PRECONDITION handled by the
# operator / Hestia / an external orchestrator - this module never touches
# them.

use strict;
use warnings;
use Cwd                       qw(realpath);
use Digest::SHA               qw(hmac_sha256_hex);
use File::Path                qw(make_path);
use Lazysite::Util            qw(log_event);
use Lazysite::Manager::Common qw(path_is_reserved processor_path);
use Exporter 'import';
use Lazysite::Paths   ();
use Lazysite::Private ();    # N141D: purge reaches the private store too
our @EXPORT_OK = qw(domains_list domains_using domain_usage domain_add creation_root_refusal domain_add_alias domain_remove domain_set domain_access_edit domain_check domain_preview preview_public known_domain_host valid_host host_refusal domain_content_root instance_public_ips host_for_path content_root_for_path served_at domains_for_scopes valid_presentation_name presentation_value action_domain_check action_domains_list);

our $DOCROOT;    # set by the caller (manager-api or the CLI)
our $LAZYSITE_DIR;           # set by the script (SM944 S27)

# SM293: this site's engine tree - beside the docroot once migrated,
# inside it before. Asked, never computed, so both layouts work on one
# code path and a site migrates by moving the directory.
sub _lz { return Lazysite::Paths::lazysite_dir($DOCROOT) }
our $auth_user = '';    # for log attribution

# Per-host presentation/routing keys that may be overridden for an alias. Same
# set the read-only view (action_domains_list) surfaces and domain_set accepts.
# content_root is the one that actually roots a domain's content; the rest are
# presentation. SM165 adds the two ACCESS keys: allowed_groups (comma list of
# groups that may manage this domain) and locked_users (comma list of accounts
# confined to it). SM179 adds the language keys: lang (this host's language) and
# lang_group (the language set it belongs to) - so a language set is configurable
# through the Domains page / control API / CLI, not only by hand-editing the conf.
my @DOMAIN_KEYS = qw(content_root site_url site_name theme layout nav_file
    search_default allowed_groups locked_users lang lang_group);
my %IS_KEY = map { $_ => 1 } @DOMAIN_KEYS;

# SM583: the two keys that name a layout or a theme rather than describing one.
my %IS_PRESENTATION = map { $_ => 1 } qw(layout theme);

sub _conf_path { return _lz() . "/lazysite.conf" }

# SM583: what a `layout:` or `theme:` conf value is allowed to be, stated ONCE.
#
# Two readers of the same key disagreed. Themes::_read_active_layout_and_theme
# matched \S+ and then stripped the capture to [A-Za-z0-9_-]; _parse below took
# the whole trimmed line. So `layout: my layout` was `my` to the active-pointer
# reader and `my layout` to every domain surface - one line, two answers, and
# neither of them what the sysop wrote. The SM516 review proposed folding one
# reader onto the other as duplicate conf reading; the row was refused and filed
# instead, because unifying them without deciding this would have picked a
# winner silently.
#
# THE RULE IS REJECT, NOT TRUNCATE. Truncation was the worse behaviour and the
# one that looked like agreement: `my` is a layout nobody wrote, it may well
# exist on this instance, and the reader handed it back as the ACTIVE layout -
# indistinguishable from a working answer. Rejection says the site has no layout
# configured, which is true, which every caller already handles because it is
# the fresh-install state, and which leaves the sysop's own text in the conf
# where they can see and correct it.
#
# [A-Za-z0-9_-]+ is not a new rule. It is the one theme_config_issues,
# action_create_theme and the layout walkers already enforce; it simply was not
# written down anywhere a READER could ask for it.
#
# It lives here, in the lower module, because Themes uses Domains and not the
# other way round - a predicate in Themes could not be reached from _parse
# without closing the loop.
sub valid_presentation_name {
    my ($v) = @_;
    return 0 unless defined $v;
    return $v =~ /^[A-Za-z0-9_-]+\z/ ? 1 : 0;
}

# The single application point for the rule above, used by _parse here and by
# Themes::_read_active_layout_and_theme.
#
# An EMPTY value passes through: unset is a legitimate state, and an alias
# override deliberately cleared to empty is a choice rather than a mistake.
# A non-empty value that is not a name returns undef - so a caller can tell a
# refused value from a cleared one, and store neither.
sub presentation_value {
    my ( $key, $raw ) = @_;
    $raw = '' unless defined $raw;
    $raw =~ s/^\s+|\s+$//g;
    return $raw unless length $raw;
    return $raw if valid_presentation_name($raw);
    _warn_refused_value( $key, $raw );
    return undef;
}

# Once per process per offending value. A site whose layout will not resolve
# renders without its chrome, and at the HTTP level that is indistinguishable
# from a working site - so the refusal has to say so somewhere. Once, because
# _parse runs on every domain listing and a misconfigured instance would
# otherwise write this line on every request.
my %_refused_warned;

sub _warn_refused_value {
    my ( $key, $raw ) = @_;
    return if $_refused_warned{"$key\0$raw"}++;
    log_event( 'WARN', 'conf-read',
        'refused a presentation value that is not a name',
        key  => $key, value => $raw, rule => '[A-Za-z0-9_-]+',
        user => $auth_user );
    return;
}

# A host label is a lowercase DNS name: dot-separated labels of [a-z0-9-], no
# leading/trailing hyphen, no traversal, no scheme/port/path. Kept strict so a
# host can never be spelled to inject a conf line or escape a directory.
# SM594/site-agent 2026-08-28: "Invalid domain host" was returned both when no
# host arrived and when the host was malformed, and it never said what a valid
# host looks like.
#
# It cost a real test run. domain-set and domain-add read `host` from the JSON
# BODY only, so an agent sending it in the query string got a message blaming
# the value it had carefully checked - and a fresh agent trying to add a domain
# could not tell what shape was wanted, which blocked SM647's measurement
# entirely. Same class as SM237: the message pointed at the wrong thing.
sub host_refusal {
    my ($h) = @_;
    return { ok => 0, kind => 'invalid',
        error => 'No domain host was supplied. Send `host` in the JSON body '
            . '(domain-set and domain-add read it from the body, not the query '
            . 'string).' }
        unless defined $h && length $h;
    return { ok => 0, kind => 'invalid',
        error => "Invalid domain host '$h'. A host is dot-separated labels of "
            . 'letters, digits and hyphens - no leading or trailing dot or '
            . 'hyphen, no empty label, 253 characters at most. The primary '
            . "site's own row is '(default)' and is not addressable here." };
}

sub valid_host {
    my ($h) = @_;
    return 0 unless defined $h && length $h && length $h <= 253;
    $h = lc $h;
    return 0 if $h =~ /[^a-z0-9.-]/;
    return 0 if $h =~ /\.\./ || $h =~ /^[.-]/ || $h =~ /[.-]$/;
    for my $label ( split /\./, $h ) {
        return 0 unless length $label && $label !~ /^-/ && $label !~ /-$/;
    }
    return 1;
}

# A content root is a docroot-relative directory. Reject traversal and any
# reserved (system) root - path_is_reserved is the single definition, shared
# with the manager blocklist and mirrored by the processor's
# confine_content_root: a domain's content must never be the secrets/auth/ACL
# tree. Returns the cleaned relative path, or undef.
sub _clean_content_root {
    my ($rel) = @_;
    return undef unless defined $rel && length $rel;
    $rel =~ s{^/+|/+$}{}g;
    return undef unless length $rel;
    return undef if $rel =~ m{(?:^|/)\.\.(?:/|$)};    # traversal
    return undef if $rel =~ m{(?:^|/)\.[^/]};         # dotfile/dotdir segment

    # SM268 03-F12: collapse `.` segments and refuse what is left empty. A
    # content_root of `.` is the docroot itself, and it passed every check above:
    # the dotdir test wants a character after the dot, and path_is_reserved
    # normalises `.` away to nothing. Accepted, it made package_create stage its
    # copy INSIDE the tree it was copying - the copy fed itself until the kernel
    # refused the path length and the CGI died with a 500, leaving a ~50-deep
    # directory behind. The staging prune in SitePackage::_copy_tree is the
    # second line; this is the first.
    $rel =~ s{(?:^|/)\.(?=/|$)}{/}g;
    $rel =~ s{/+}{/}g;
    $rel =~ s{^/+|/+$}{}g;
    return undef unless length $rel;

    return undef if path_is_reserved($rel);    # engine-owned (system) area
    return $rel;
}

# Parse the conf into ( \%base, \%overrides, \@hosts ). %overrides is
# host => { key => value }; @hosts is the ordered alias_hosts list.
# TLO-5: the verbs that rewrite the file slurp it anyway, so they pass the text
# they already hold rather than making this open it a second time. With no
# argument it reads the file itself, as every other caller does. split /^/ keeps
# each line's newline, which is what the readline loop it replaces produced.
sub _parse {
    my ($text) = @_;
    $text = _slurp() unless defined $text;
    my %base;
    my %ov;
    # SM583: a `layout:` or `theme:` value that is not a name is REFUSED here,
    # not stored - so every surface downstream (the listing, _effective, the
    # usage map, the delete guard) resolves it to unset, which is the same
    # answer _read_active_layout_and_theme now gives. An alias override that is
    # refused leaves the domain INHERITING, exactly as if the line had never
    # been written. See valid_presentation_name for why reject and not truncate.
    for my $line ( split /^/, ( $text // '' ) ) {
        if ( $line =~ /^alias\.(\S+?)\.(\w+)\s*:\s*(.*?)\s*$/ ) {
            my ( $host, $key, $value ) = ( lc $1, $2, $3 );
            $value = presentation_value( $key, $value ) if $IS_PRESENTATION{$key};
            next unless defined $value;
            $ov{$host}{$key} = $value;
        }
        elsif ( $line =~ /^(\w+)\s*:\s*(.*?)\s*$/ ) {
            my ( $key, $value ) = ( $1, $2 );
            $value = presentation_value( $key, $value ) if $IS_PRESENTATION{$key};
            next unless defined $value;
            $base{$key} = $value;
        }
    }
    my @hosts = grep { length } map { s/^\s+|\s+$//gr } split /,/,
        ( $base{alias_hosts} // '' );
    return ( \%base, \%ov, \@hosts );
}

# Read the whole conf verbatim (for line-level rewrites).
sub _slurp {
    open my $fh, '<:utf8', _conf_path() or return undef;
    local $/;
    my $c = <$fh>;
    close $fh;
    return $c;
}

# SM255: conf writes go through the ONE shared path, which locks, writes in place
# (preserving the inode and so the owner and mode - the field bug this module's
# own writer existed to avoid) and records the change in content history. Before
# this, config-set committed lazysite.conf and the domain verbs did not, on the
# same file; an operator cannot tell those apart and should not have to.
sub _write {
    my ( $content, $message ) = @_;
    # Each manager module carries its own $DOCROOT / $auth_user, set per request
    # by the dispatcher, so bridge this module's context into Common's for the
    # duration of the write - otherwise the shared writer looks in the wrong
    # docroot and attributes the commit to nobody.
    no warnings 'once';
    local $Lazysite::Manager::Common::DOCROOT   = $DOCROOT;
    local $Lazysite::Manager::Common::auth_user = $auth_user;
    return Lazysite::Manager::Common::write_conf_content( $content, $message );
}

# Set (or replace) one `alias.<host>.<key>: value` line in $content, returning
# the new content. Appends if absent.
sub _set_line {
    my ( $content, $host, $key, $value ) = @_;
    my $k  = "alias.$host.$key";
    my $qk = quotemeta $k;
    if ( $content =~ /^$qk\s*:/m ) {
        $content =~ s/^$qk\s*:.*$/$k: $value/m;
    }
    else {
        $content =~ s/\n?$/\n/;
        $content .= "$k: $value\n";
    }
    return $content;
}

# Set (or replace) a bare `key: value` line (used for alias_hosts).
sub _set_base {
    my ( $content, $key, $value ) = @_;
    my $qk = quotemeta $key;
    if ( $content =~ /^$qk\s*:/m ) {
        $content =~ s/^$qk\s*:.*$/$key: $value/m;
    }
    else {
        $content =~ s/\n?$/\n/;
        $content .= "$key: $value\n";
    }
    return $content;
}

# The value a host actually resolves to: its own alias.<host>.<key> override
# where it has one, the base site's key otherwise. '' is the base site itself,
# which has no overrides to consult. Every surface that answers "what does this
# host use" resolves it here, so the listing, the usage map and the mirror
# cannot drift apart.
sub _effective {
    my ( $base, $ov, $host, $key ) = @_;
    return $base->{$key} // '' if $host eq '';
    return defined $ov->{$host}{$key} ? $ov->{$host}{$key} : ( $base->{$key} // '' );
}

# --- public: list ----------------------------------------------------------

# The domains this instance serves: the primary/default host (base keys) plus
# each alias, an override winning over the inherited base value. Mirrors the
# manager's read-only domains view.
sub domains_list {
    my ( $base, $ov, $hosts ) = _parse();
    my @domains = ( {
            host       => '(default)',
            is_primary => 1,
            map { $_ => ( $base->{$_} // '' ) } @DOMAIN_KEYS,
    } );
    for my $h (@$hosts) {
        my %row = ( host => $h, is_primary => 0 );
        for my $k (@DOMAIN_KEYS) {
            $row{$k} = defined $ov->{$h}{$k} ? $ov->{$h}{$k}      : ( $base->{$k} // '' );
            $row{ $k . '_inherited' } = defined $ov->{$h}{$k} ? 0 : 1;
        }
        push @domains, \%row;
    }

    # SM217: THE RELATIONSHIP IS ALREADY REAL AND WAS INVISIBLE. Two hosts
    # serving one content root is what the engine has always supported - a host
    # with no content_root of its own mirrors the primary, and two hosts may be
    # pointed at the same folder - but the list showed them as unrelated peers,
    # so the one thing an operator needed to see (these are the same site) was
    # the one thing they had to work out by comparing paths.
    #
    # DERIVED, NEVER STORED. There is no `alias_of` key in lazysite.conf and
    # there must not be: a stored relationship can disagree with the
    # content_root that actually decides what is served, and then the list is
    # confidently wrong. The canonical row is the FIRST one carrying that root,
    # in list order - which puts the primary first, so every rootless host reads
    # as an alias of (default) rather than of whichever alias was registered
    # first.
    my %first_for_root;
    for my $d (@domains) {
        my $root = $d->{content_root} // '';
        if ( exists $first_for_root{$root} ) {
            $d->{alias_of} = $first_for_root{$root};
        }
        else {
            $first_for_root{$root} = $d->{host};
            $d->{alias_of} = '';
        }
    }
    return { ok => 1, domains => \@domains, keys => \@DOMAIN_KEYS };
}

# SM647: the content root a host serves from, or undef for a host that is not
# configured. A domain's reach IS its content root, and domain-set is addressed
# by host - so a scope check on this action has nothing to compare until it can
# resolve one. Derived from domains_list rather than re-parsing, so it inherits
# the primary's value exactly as the served row does.
sub domain_content_root {
    my ($host) = @_;
    return undef unless defined $host && length $host;
    $host = lc $host;
    my $list = domains_list();
    for my $d ( @{ $list->{domains} || [] } ) {
        next unless lc( $d->{host} // '' ) eq $host;
        return $d->{content_root} // '';
    }
    return undef;
}

# SM238 follow-up: shared by domain_preview here and action_domain_check in the
# control API, so it carries a public name. Both bound an outbound probe or a
# render to operator-declared hosts - never an arbitrary target.
sub known_domain_host {
    my ($host) = @_;
    my @rows = @{ domains_list()->{domains} || [] };
    for my $r (@rows) {
        next     if $r->{is_primary};
        return 1 if lc( $r->{host} // '' ) eq $host;
    }
    my ($prim) = grep { $_->{is_primary} } @rows;
    if ( $prim && ( $prim->{site_url} // '' ) =~ m{^https?://([^/:]+)}i ) {
        return 1 if lc($1) eq $host;
    }
    return 0;
}

# SM436: does this value name a host that a public request could actually
# carry, and does it agree with the site_url beside it?
#
# NOT folded into valid_host, deliberately: that is shared with domain_remove
# and domain_set, and tightening it there would strand an already-configured
# bad row - unremovable by the verb that exists to remove it. Registration is
# the only moment this can be caught, and it is also the LAST moment: `host`
# is not in @DOMAIN_KEYS, so domain_set cannot correct it and there is no
# rename verb. A value that cannot be edited afterwards has exactly one chance
# to be right.
#
# The incident: a domain configured as `dhcf` with site_url
# https://dhcf.sites.lazysite.io. The processor matches the FULL Host header
# with eq, so `dhcf` never matched, no alias overlay applied, and every
# request fell through to the primary - serving a different organisation's
# site under that name. The domain record, the render, the alias map and the
# domain check all looked correct; only following a request showed it. Both
# halves of the answer were already in the row.
sub _host_cannot_match {
    my ($host) = @_;
    return undef if $host =~ /\./;
    return 'A domain name needs at least one dot - "' . $host . '" is a single '
        . 'label, and no public request can arrive with it as its Host. If this '
        . 'is a subdomain, configure the full name (for example '
        . $host . '.example.com).';
}

# The other half: the row disagreeing with itself. Kept separate from the dot
# check because domain_set must apply THIS one and not that one - an
# already-configured dotless host cannot be corrected (host is not settable and
# there is no rename), so answering a site_url edit with a message about
# configuring it differently would misdirect. Removing it is the only route,
# and domain_remove deliberately does not run either check.
sub _host_disagrees_with_url {
    my ( $host, $site_url ) = @_;
    return undef unless defined $site_url && length $site_url;
    # A placeholder site_url (the primary's ${SERVER_NAME} form) names no host.
    return undef if $site_url     =~ /\$\{/;
    return undef unless $site_url =~ m{^https?://([^/:?#]+)}i;
    my $url_host = lc $1;
    return undef if $url_host eq $host;
    return 'The site address names ' . $url_host . ' but the domain is '
        . $host . '. A request arrives under the name in the site address, so '
        . 'these disagreeing means this domain never matches and visitors get '
        . 'the default site instead. Use ' . $url_host . '.';
}

# SM441: which configured domain OWNS a docroot-relative path.
#
# The page previews shelled the processor without a Host, so SM151's per-Host
# routing never fired and a domain's page rendered with the BASE layout, theme
# and nav - whoever it belonged to. The content was right, because the
# docroot-relative path resolves under the primary, and the presentation was
# another site's. That is the awkward shape of it: it looks like a working
# preview of a page given the wrong theme, rather than a preview that has not
# been told which site it is previewing.
#
# LONGEST content_root wins, so a domain nested inside another's tree is
# resolved to the inner one. Returns '' for a path no content root contains -
# the primary owns it, and today's behaviour is already correct there.
#
# AMBIGUITY IS NOT RESOLVED HERE, only made deterministic: if two domains
# declare the SAME content_root there is no fact that decides between them, and
# the honest answer is a host selector on the preview. This picks the first by
# sorted host so the same path always previews the same way, which is strictly
# better than the primary-always behaviour it replaces, and returns the count
# so a caller can say so.
# SM440: the same walk, answering for the CONTENT ROOT rather than the host.
# Aliases need the root - to make a URL relative to the site that serves it,
# and to key the map per domain; previews need the host. ONE traversal, so the
# containment rule cannot drift between the two callers.
sub content_root_for_path {
    my ($rel) = @_;
    my ( $host, $tied, $root ) = _owner_for_path($rel);
    return ( $root, $host, $tied );
}

sub host_for_path {
    my ($rel) = @_;
    my ( $host, $tied ) = _owner_for_path($rel);
    return ( $host, $tied );
}

# SM1065: WHERE A DOCROOT PATH IS SERVED - the Host of the domain that owns it
# and the URL that domain serves it at. Every preview that renders one page asks
# here, so the Host and the URL cannot come apart again.
#
# They did: SM441 set the owner's Host and left the URL at the docroot path, and
# under that Host the processor resolves the URL against the domain's own
# content root - /sites/mine/index under mine.test looked for
# sites/mine/sites/mine/index and answered 404. SM1031 (c) fixed it in MCP
# preview_page with the arithmetic written inline; SM1064 found it still in
# preview_public and the manager's preview.
#
# Returns ( $host, $url, $tied ). $host is '' for a path the primary owns, and
# the caller then renders WITHOUT a Host rather than inheriting the request's:
# a request that arrived under a domain's name would otherwise resolve the
# primary's page against that domain's root (SM1031 (c), its other half).
sub served_at {
    my ($rel) = @_;
    $rel = '' unless defined $rel;
    $rel =~ s{^/+}{};
    my ( $root, $host, $tied ) = content_root_for_path($rel);
    return ( '', "/$rel", 0 ) unless length( $host // '' );
    my $url = $rel eq $root ? '/' : '/' . substr( $rel, length($root) + 1 );
    return ( $host, $url, $tied );
}

# SM593/SM578: which domains a CONFINED caller may act on, derived from the
# grant rather than from anything the caller says.
#
# A grant with no dav_scopes is UNCONFINED - that is the sysop, and the
# empty list means "no restriction", never "no domains". Callers must treat an
# empty return as "ask no further", which is why this returns a list and the
# confinement decision is made by whoever called it: a function that answered
# "these domains" for the sysop would have to enumerate every domain, and a
# bug in the caller would then read as a narrow answer rather than a wide one.
#
# A scope and a content_root match if either contains the other. A partner
# scoped INTO a domain (sites/jpm-stock/docs) is confined to that domain; a
# partner scoped ABOVE several (sites) reaches all of them. Both are the same
# question - do these two paths overlap - asked in the two directions a grant
# can be written.
sub domains_for_scopes {
    my (@scopes) = @_;
    return () unless @scopes;

    my $r = eval { domains_list() };
    return () unless ref $r eq 'HASH' && $r->{ok};

    my @clean = grep { length } map { my $x = $_ // ''; $x =~ s{^/+|/+$}{}g; $x } @scopes;
    return () unless @clean;

    my %host;
    for my $d ( @{ $r->{domains} || [] } ) {
        my $cr = $d->{content_root} // '';
        $cr =~ s{^/+|/+$}{}g;
        next unless length $cr;
        next if $cr =~ m{(?:^|/)\.\.(?:/|$)};
        for my $sc (@clean) {
            if ( $cr eq $sc
                || index( $cr, "$sc/" ) == 0
                || index( $sc, "$cr/" ) == 0 )
            {
                $host{ $d->{host} } = 1 if length( $d->{host} // '' );
                last;
            }
        }
    }
    # Listed, not returned straight from sort: perlcritic is right that a
    # sort in a return is undefined in scalar context, and this is called in
    # list context everywhere - which is exactly how that stays true by
    # accident until it does not.
    my @hosts = sort keys %host;
    return @hosts;
}

sub _owner_for_path {
    my ($rel) = @_;
    $rel = '' unless defined $rel;
    $rel =~ s{^/+}{};

    my $r = eval { domains_list() };
    return ( '', 0, '' ) unless ref $r eq 'HASH' && $r->{ok};

    my ( $best, @tied ) = ('');
    for my $d ( @{ $r->{domains} || [] } ) {
        next if $d->{is_primary};
        my $cr = $d->{content_root} // '';
        $cr =~ s{^/+|/+$}{}g;
        next unless length $cr;
        next if $cr =~ m{(?:^|/)\.\.(?:/|$)};
        next unless $rel eq $cr || index( $rel, "$cr/" ) == 0;

        if ( !length $best || length($cr) > length($best) ) {
            $best = $cr;
            @tied = ( $d->{host} );
        }
        elsif ( length($cr) == length($best) ) {
            push @tied, $d->{host};
        }
    }
    return ( '', 0, '' ) unless @tied;
    @tied = sort @tied;
    return ( $tied[0], scalar @tied, $best );
}

# SM466: what the rendered page says about its own presentation.
#
# From the RESPONSE, never the configuration. "What should this domain use" was
# always answerable; "what did a visitor actually get" was not, and they came
# apart in SM441 - a domain's page rendered with the BASE layout while the
# configuration said otherwise, and every tool that consulted the configuration
# agreed with the configuration.
#
# The asset path is the evidence, because SM193 mirrors an active theme to
# /lazysite-assets/<layout>/<theme>/ - so the stylesheet a visitor loaded names
# both. Absent when a page renders through the built-in fallback, which is
# itself the answer to "why does this look wrong".
sub _rendered_presentation {
    my ( $head, $body ) = @_;
    my %out;

    my ( $layout, $theme )
        = ( $body // '' ) =~ m{/lazysite-assets/([A-Za-z0-9_-]+)/([A-Za-z0-9_-]+)/};
    if ( defined $layout ) {
        $out{rendered_layout} = $layout;
        $out{rendered_theme}  = $theme;
    }
    else {
        # Said explicitly rather than left absent: a missing field reads as
        # "the check did not look", and this IS the finding when a page is
        # unstyled.
        $out{rendered_layout} = undef;
        $out{rendered_theme}  = undef;
        $out{presentation_note}
            = 'no theme asset was referenced - this page rendered through the '
            . 'built-in fallback, not a layout';
    }
    return ( \%out );
}

# SM520: the identity strip is the mechanism of BOTH previews. Anything that
# could tell the processor who is asking has to go, or the preview shows the
# operator their own view and reports it as the public's - which is the defect
# preview_public existed to remove, and which domain_preview then had in its
# own hand-written strip list (HTTP_X_REMOTE_* and LAZYSITE_AUTH_* only; the
# session cookie and Authorization header rode along, and a gated section
# previewed as visible under the domain check). One list, one place, so the
# twins cannot drift again. Callers `local %ENV` first; this edits the copy.
sub _anonymous_env {
    delete @ENV{
        grep {
            m{ \A (?: HTTP_X_REMOTE_ | LAZYSITE_AUTH_
                | HTTP_COOKIE | HTTP_AUTHORIZATION ) }x
        } keys %ENV
    };
    return;
}

# --- public: preview -------------------------------------------------------

# SM282: what a PUBLIC visitor gets for one path.
#
# A draft section is invisible to the public and visible to a signed-in editor.
# That is the feature working, and it is exactly why the editor is the one
# person who cannot check it: everything looks fine from where they are
# standing. The current answer is a private browsing window, which works and
# means leaving the manager - while the thing being checked is precisely
# whether leaving the manager changes what you see.
#
# The machinery already existed one scope up. domain_preview shells the
# processor with every auth marker stripped, so a domain can be seen before DNS
# points at it. This is the same trick at page scope.
#
# SAFE BY CONSTRUCTION, and the construction is the point: the processor applies
# the identical refusal it would apply to a visitor, because it is not told who
# is asking. So a 404 or a redirect to /login is the CORRECT answer for a gated
# path and is reported as the finding rather than as an error - which is the
# whole reason a sysop would run this.
sub preview_public {
    my ($rel) = @_;
    $rel = '/'     unless defined $rel && length $rel;
    $rel = "/$rel" unless $rel =~ m{^/};

    return { ok => 0, error => 'Invalid path' }
        if $rel =~ m{ \0 }x || $rel =~ m{ (?:^|/) \.\. (?:/|$) }x;

    local %ENV = %ENV;
    _anonymous_env();

    # SM441: render under the OWNING domain's Host, so the per-Host overlay
    # supplies that site's layout, theme and nav. Without this the preview
    # inherited the manager request's Host - normally the primary - and this
    # tool, whose whole claim is to show what a public visitor gets, showed a
    # different site's presentation.
    #
    # SM1065: AT THE URL THAT DOMAIN SERVES IT AT. The docroot path under the
    # owner's Host is resolved against the owner's content root, so a domain's
    # page came back 404. A primary page renders with no Host, never the
    # request's, which may be a domain's name.
    my ( $owner, $url ) = served_at($rel);
    my $rendered_as = length $owner ? $owner : '(default)';

    $ENV{DOCUMENT_ROOT}    = $DOCROOT;
    $ENV{REDIRECT_URL}     = $url;
    $ENV{REQUEST_METHOD}   = 'GET';
    $ENV{QUERY_STRING}     = '';
    $ENV{LAZYSITE_NOCACHE} = '1';
    $ENV{LAZYSITE_PREVIEW} = '1';        # SM1064: a preview is no visit (SM1031)
    if ( length $owner ) { $ENV{HTTP_HOST} = $owner }
    else                 { delete $ENV{HTTP_HOST} }

    my $processor = processor_path();
    my $raw       = qx($^X \Q$processor\E 2>/dev/null);
    my $status    = $?;

    if ( $status != 0 ) {
        return { ok => 0, kind => 'render-failed',
            error => 'The processor failed to render ' . $rel };
    }
    unless ( defined $raw && $raw =~ /\r?\n\r?\n/ ) {
        return { ok => 0, kind => 'no-cgi-headers',
            error => 'The processor returned no CGI response for ' . $rel };
    }

    my ($head) = $raw =~ /\A(.*?)\r?\n\r?\n/s;
    ( my $body = $raw ) =~ s/\A.*?\r?\n\r?\n//s;
    utf8::decode($body);

    my ($code) = ( $head // '' ) =~ /^Status:\s*(\d{3})/m;
    $code //= 200;
    my ($location) = ( $head // '' ) =~ /^Location:\s*(\S+)/m;

    # The VERDICT, in the sysop's terms rather than HTTP's. "404" is a fact
    # about a response; "a visitor does not see this page" is the answer to the
    # question they asked.
    my $visible
        = $code == 200                     ? 'visible'
        : ( $code == 404 )                 ? 'not-found'
        : ( $code >= 300 && $code < 400 )  ? 'redirected'
        : ( $code == 401 || $code == 403 ) ? 'refused'
        :                                    'other';

    return {
        ok      => 1,
        path    => $rel,
        status  => $code + 0,
        public  => ( $visible eq 'visible' ? JSON::PP::true : JSON::PP::false ),
        verdict => $visible,
        ( defined $location ? ( location => $location ) : () ),

        # SM436: SAY WHICH HOST THIS WAS RENDERED UNDER.
        #
        # A preview that does not name its Host lets "it previews fine" be
        # read as "it will serve", and those came apart badly: a domain
        # configured under a name no request carries previewed perfectly while
        # every real request fell through to the primary. domain_preview feeds
        # the STORED key back in, so it agrees with the configuration by
        # construction and cannot detect a name that no visitor will send.
        #
        # Naming the host does not fix that blind spot - nothing at preview
        # scope can - but it stops the answer being mistaken for one it did
        # not give.
        rendered_as_host => $rendered_as,

        # SM466: WHICH LAYOUT AND THEME THE VISITOR ACTUALLY GOT.
        #
        # The reported gap was that nothing could confirm a page renders its
        # OWN layout. preview_public already renders under the owning Host
        # (SM441), so it had the answer and did not say it - and the field
        # agent was left comparing an excerpt of HTML by eye, or fetching the
        # page directly, which is egress outside the grant model and proves
        # nothing about what the grant can establish.
        #
        # READ OUT OF THE RENDERED HEAD, not from the configuration. Reading
        # the config would report what SHOULD have been used, which is the
        # question that was already answerable and not the one being asked. The
        # generator meta and the stylesheet path are what the visitor received.
        ( map { %{$_} }
                _rendered_presentation( $head, $body )
        ),

        # A bounded excerpt, not the page. Enough to tell a rendered 404 from a
        # rendered page without shipping a whole document through the API.
        excerpt => substr( $body, 0, 400 ),
        note    => $visible eq 'visible'
        ? 'A visitor WOULD see this page.'
        : 'A visitor would NOT see this page - this is the expected result for '
            . 'a draft or protected section, and is the check succeeding.',
    };
}

# SM238: render a configured domain as an anonymous visitor would see it, under
# its own Host - so a domain can be prepared and checked before DNS or TLS point
# at it. Moved here from lazysite-manager-api.pl so the control API and the MCP
# connector share ONE implementation rather than the connector growing a copy;
# that shared-module shape is also what SM239 asks for across the two surfaces.
#
# Shells the processor exactly as the dev server does: no auth headers, the
# target Host, and cache bypassed - so what comes back is the real per-Host
# render, with that domain's content root, layout, theme and nav all applied.
sub domain_preview {
    my ($host) = @_;
    $host = lc( $host // '' );
    # SM662-shaped: this had its OWN copy of the host rule, which could drift
    # from valid_host and answer differently for the same host on two actions.
    return host_refusal($host) unless valid_host($host);

    # Only a configured domain (or the primary site's own host) may be previewed.
    return { ok => 0, error => "Not a configured domain: $host" }
        unless known_domain_host($host);

    local %ENV = %ENV;
    _anonymous_env();
    $ENV{DOCUMENT_ROOT}    = $DOCROOT;
    $ENV{HTTP_HOST}        = $host;
    $ENV{REDIRECT_URL}     = '/';
    $ENV{REQUEST_METHOD}   = 'GET';
    $ENV{QUERY_STRING}     = '';
    $ENV{LAZYSITE_NOCACHE} = '1';
    $ENV{LAZYSITE_PREVIEW} = '1';        # SM1064: a preview is no visit (SM1031)

    # SM257: this tool exists to VERIFY a domain renders before DNS points at it,
    # so it must not report success without having verified anything. It used to
    # discard the processor's stderr (2>/dev/null), never look at its exit
    # status, and return ok:1 whatever came back - so a dead processor, a render
    # that emitted nothing, and a genuinely blank page were one answer. An agent
    # checking its own work was told "fine" in every case.
    require File::Temp;
    my ( $efh, $errfile ) = File::Temp::tempfile( 'lzs-preview-XXXXXX', TMPDIR => 1 );
    close $efh;

    my $processor = processor_path();
    my $raw       = qx($^X \Q$processor\E 2>\Q$errfile\E);
    my $status    = $?;

    my $stderr = '';
    if ( open my $ef, '<:utf8', $errfile ) {
        local $/;
        $stderr = <$ef> // '';
        close $ef;
    }
    unlink $errfile;
    $stderr =~ s/\s+\z//;
    # Enough to identify the fault without returning a whole stack trace.
    $stderr = substr( $stderr, 0, 500 ) if length $stderr > 500;

    if ( $status != 0 ) {
        my $code = $status >> 8;
        my $sig  = $status & 127;
        return { ok => 0, kind => 'render-failed',
            error => "The processor failed to render $host"
                . ( $sig           ? " (killed by signal $sig)" : " (exit $code)" )
                . ( length $stderr ? ": $stderr" : '. It produced no diagnostic.' ) };
    }

    # A CGI response is headers, a blank line, then the body. No blank line means
    # the processor did not produce a response at all - distinct from producing
    # an empty one, and a different fault to chase.
    unless ( defined $raw && $raw =~ /\r?\n\r?\n/ ) {
        return { ok => 0, kind => 'no-cgi-headers',
            error => "The processor returned no CGI response for $host"
                . ( length $stderr ? ": $stderr" : '. Output was: '
                    . ( defined $raw && length $raw
                    ? '"' . substr( $raw, 0, 200 ) . '"'
                    : 'nothing at all.' ) ) };
    }

    ( my $output = $raw ) =~ s/\A.*?\r?\n\r?\n//s;  # strip CGI headers (ASCII, byte-safe)

    # qx() returns the processor's raw UTF-8 BYTES. respond() emits the JSON via
    # encode_json, which UTF-8-encodes CHARACTER strings - so bytes handed to it
    # get double-encoded (e => é -> Ã©, Thai -> mojibake). Decode to characters
    # here so the round-trip is clean. (Same raw-bytes-vs-characters trap the
    # resolve_json path fixed on the render side.)
    require Encode;
    $output = Encode::decode( 'UTF-8', $output );

    # An empty body is the signature of a broken render, not of a blank page: the
    # engine always emits a layout around whatever content it found, and a
    # missing page is a 404 document rather than nothing.
    return { ok => 0, kind => 'empty-render',
        error => "The processor rendered nothing for $host. The domain is "
            . 'configured, so check its content_root points at a directory with '
            . 'an index page.' }
        unless $output =~ /\S/;

    # SM436: name the Host this was rendered under, and say plainly that it
    # was supplied rather than observed. domain_preview feeds the STORED key
    # back in as the Host, so it agrees with the configuration BY
    # CONSTRUCTION and cannot detect the one fault that matters here - a
    # domain configured under a name no real request carries. It previewed
    # perfectly while every visitor got the primary's site.
    return {
        ok               => 1,
        host             => $host,
        rendered_as_host => $host,
        note             => "Rendered with Host: $host, which is the stored "
            . 'domain name. This shows how the site renders for that name; it '
            . 'cannot show whether visitors arrive under it. Use the domain '
            . 'check for that.',
        html => $output,
    };
}

# SM234: the whole usage picture in ONE parse. domains_using() re-reads and
# re-parses the domain config on every call, so asking it per theme costs a parse
# per row; a listing needs the inverse mapping anyway. Returns
# { layouts => { <layout> => [hosts] }, themes => { "<layout>\0<theme>" => [hosts] } }
# with '(default)' standing for the base site, matching domains_using's own
# vocabulary. Effective per-host values, so an alias inheriting the active layout
# but pinning its own theme is counted against that theme.
sub domain_usage {
    my ( $base, $ov, $hosts ) = _parse();
    my %use = ( layouts => {}, themes => {} );
    for my $h ( '', @$hosts ) {
        my $layout = _effective( $base, $ov, $h, 'layout' );
        my $theme  = _effective( $base, $ov, $h, 'theme' );
        my $who    = ( $h eq '' ? '(default)' : $h );
        next unless length $layout;
        push @{ $use{layouts}{$layout} },          $who;
        push @{ $use{themes}{"$layout\0$theme"} }, $who if length $theme;
    }
    return \%use;
}

# SM177: which configured domains (base + every alias/sub-domain) currently
# depend on a given layout - or a given theme UNDER a given layout. Sub-domains
# are first-class peers here: a theme/layout one of them uses must block its
# deletion just as the primary's active one does. Effective values resolve the
# same way the engine serves them - a per-host override wins, else the base value
# is inherited - so an alias that inherits the base layout but pins its own theme
# is matched correctly. Returns the list of host labels ('(default)' for the
# primary) that use it, most useful hosts first. Pass (layout => L) to find
# layout users; (theme => T, layout => L) to find theme users under layout L.

sub domains_using {
    my (%q) = @_;
    my ( $base, $ov, $hosts ) = _parse();

    my @using;
    for my $h ( '', @$hosts ) {
        next unless _effective( $base, $ov, $h, 'layout' ) eq ( $q{layout} // '' );
        next
            if defined $q{theme}
            && _effective( $base, $ov, $h, 'theme' ) ne $q{theme};
        push @using, ( $h eq '' ? '(default)' : $h );
    }
    return @using;
}

# --- public: add -----------------------------------------------------------

# SM1046 (ruled 2026-10-12, "Allow, own group only"): THE ROOT OF A DOMAIN A
# CALLER GIVES TO ITS OWN GROUP. Naming a group in a new domain's
# allowed_groups adds that domain's content root to the scope of every member
# of the group, so the root decides what the group reaches from then on. The
# ruling is that it reaches the new domain and no other, so the root must be
# outside every domain:
#
#   - not another domain's root, nor inside one, nor containing one (a root
#     that contains another domain's would put that domain inside the scope).
#
# D-2 (ruled 2026-10-12, "Allow adoption"): an existing folder outside every
# domain may be adopted. Its content becomes reachable by every member of the
# group, as the ruling accepts. A PROTECTED folder may not: one in the private
# store, or one that any access rule touches (its own, one below it, one above
# it). Measured before deciding (tmp/n512-adopt-probe.pl): a group member scoped
# elsewhere, still refused the gated page by its rule, was shown the rule
# itself - owner, read and write lists - by protected-sections, and under a rule
# that leaves its write list empty it overwrote the gated page; the
# token adopting it, which cannot read the content, would be handing reach to
# content it is not allowed to see. Those stay the operator's. An access store
# that cannot be read refuses, since it cannot say which case this is.
#
# Returns the refusal, or undef. A root that does not clean is left to
# domain_add, which refuses it in its own words; an empty root (the host
# serves the primary site) adds no scope to anyone and passes.
sub creation_root_refusal {
    my ($raw) = @_;
    return undef unless defined $raw && $raw =~ /\S/;
    my $rel = _clean_content_root($raw);
    return undef unless defined $rel;
    my $list = domains_list();
    for my $d ( @{ $list->{domains} || [] } ) {
        my $r = _clean_content_root( $d->{content_root} // '' );
        next unless defined $r && length $r;
        next
            unless $r eq $rel
            || index( "$rel/", "$r/" ) == 0
            || index( "$r/",   "$rel/" ) == 0;
        return { ok => 0, kind => 'forbidden',
            error => "The content root '$rel' overlaps '$r', which "
                . ( $d->{is_primary} ? 'the primary site' : "the domain '$d->{host}'" )
                . ' serves. A domain given to your own group must have content of its '
                . 'own, so that the group reaches the new domain and no other: pick a '
                . 'folder outside every existing domain.' };
    }
    my ( $existing, $where ) = Lazysite::Private::resolve( $DOCROOT, $rel );
    return undef unless defined $existing;    # a new folder
    require Lazysite::Auth::Acl;
    my $keys = Lazysite::Auth::Acl::rule_keys_touching( $DOCROOT, $rel );
    return { ok => 0, kind => 'forbidden',
        error => "The content root '$rel' already exists and the access rules cannot be "
            . 'read, so whether it is protected cannot be told. An operator can point a '
            . 'domain at existing content (Domains page).' }
        unless ref $keys eq 'ARRAY';
    return { ok => 0, kind => 'forbidden',
        error => "The content root '$rel' is protected content ("
            . ( @{$keys} ? 'access rules on ' . join( ', ', map { "'$_'" } @{$keys} ) : 'held in the private store' )
            . '). A domain given to your own group may adopt an existing folder only '
            . 'when no access rule touches it; an operator can point a domain at '
            . 'protected content (Domains page).' }
        if $where eq 'private' || @{$keys};
    return undef;
}

# %opts: content_root (OPTIONAL - empty means the host serves the DEFAULT site,
# i.e. the docroot root, no per-host content of its own), and any of
# site_url/site_name/theme/layout/nav_file/search_default; seed => 1 to write a
# starter index.md (ignored when there is no content root of its own).
sub domain_add {
    my ( $host, %opts ) = @_;
    $host = lc( $host // '' );
    return host_refusal($host) unless valid_host($host);

    # SM436: refuse a name no request can carry, and a name that disagrees
    # with its own site_url. Both are unrecoverable after this call - `host`
    # is not settable and there is no rename - and both are silent in
    # production: the domain simply never matches and the visitor is served
    # the primary's site under someone else's name.
    for my $why ( _host_cannot_match($host),
        _host_disagrees_with_url( $host, $opts{site_url} ) )
    {
        return { ok => 0, kind => 'invalid', error => $why } if $why;
    }

    # Empty content_root is allowed: the host then serves the default site.
    # A NON-empty value must clean (under the docroot, not a reserved area).
    my $raw      = $opts{content_root};
    my $has_root = defined $raw && $raw =~ /\S/;
    my $rel      = '';
    if ($has_root) {
        $rel = _clean_content_root($raw);
        return { ok => 0, kind => 'invalid',
            error => 'The content folder must be inside your site. '
                . 'The lazysite system area is reserved - pick another folder.' }
            unless defined $rel;
    }

    # SM179: validate the language keys the same way domain_set does - they land
    # in <html lang> and name an i18n file, so fail closed on a bad value.
    if ( defined $opts{lang} && length $opts{lang}
        && $opts{lang} !~ /^[A-Za-z]+(?:-[A-Za-z0-9]+)*\z/ )
    {
        return { ok => 0, kind => 'invalid', error => 'Invalid language tag' };
    }
    if ( defined $opts{lang_group} && length $opts{lang_group}
        && $opts{lang_group} !~ /^[A-Za-z0-9_-]+\z/ )
    {
        return { ok => 0, kind => 'invalid', error => 'Invalid lang_group name' };
    }
    # SEC (F6.11): every override value is written as a single conf line via
    # _set_line, so reject CR/LF in ANY of them - matching domain_set - so a value
    # cannot smuggle a second conf directive (e.g. a reserved content_root).
    for my $k (@DOMAIN_KEYS) {
        next unless defined $opts{$k};
        return { ok => 0, kind => 'invalid', error => 'Value must be a single line' }
            if $opts{$k} =~ /[\r\n]/;
    }
    # SM1046: allowed_groups arrives here only from the manager API's own-group
    # creation path, already checked against the caller's groups; it is held to
    # domain_set's shape rule as well, since this writes it as a conf line.
    if ( defined $opts{allowed_groups} && length $opts{allowed_groups} ) {
        my @toks = grep { length } map { s/^\s+|\s+$//gr } split /,/, $opts{allowed_groups};
        for my $t (@toks) {
            return { ok => 0, kind => 'invalid', error => "Invalid name in allowed_groups: $t" }
                unless $t =~ /^[A-Za-z0-9_-]+\z/;
        }
        my %seen;
        $opts{allowed_groups} = join ', ', grep { !$seen{$_}++ } @toks;
    }

    my $content = _slurp();
    my ( $base, $ov, $hosts ) = _parse($content);
    return { ok => 0, kind => 'exists', error => "Domain already configured: $host" }
        if grep { $_ eq $host } @$hosts;

    return { ok => 0, error => 'Cannot read lazysite.conf' } unless defined $content;

    # content_root first (only when the host has its own), then any presentation
    # overrides. With no content root the host writes no content_root line and
    # inherits the base - it serves the default site.
    $content = _set_line( $content, $host, 'content_root', $rel ) if length $rel;
    for my $k (@DOMAIN_KEYS) {
        next if $k eq 'content_root';
        next unless defined $opts{$k} && length $opts{$k};
        $content = _set_line( $content, $host, $k, $opts{$k} );
    }

    # Append the host to alias_hosts (preserve order).
    my @new_hosts = ( @$hosts, $host );
    $content = _set_base( $content, 'alias_hosts', join( ',', @new_hosts ) );

    my ( $ok, $err ) = _write( $content, "configure domain $host" );
    return { ok => 0, error => $err } unless $ok;

    # A host with no content root of its own serves the default site - nothing
    # to provision or seed.
    unless ( length $rel ) {
        log_event( 'INFO', $host, 'domain configured (serves the default site)',
            host => $host, user => $auth_user,
            ( length( $opts{allowed_groups} // '' ) ? ( allowed_groups => $opts{allowed_groups} ) : () ) );
        return { ok => 1, host => $host, content_root => '',
            ( length( $opts{allowed_groups} // '' ) ? ( allowed_groups => $opts{allowed_groups} ) : () ) };
    }

    # Provision the content-root directory (+ optional seed). A directory that
    # already exists is fine (adopting an existing tree).
    #
    # N141D (SM852 S3): ASK WHERE THE CONTENT ROOT ACTUALLY IS FIRST.
    #
    # This resolved nothing: it built "$DOCROOT/$rel" and tested `-d`, then
    # `-e "$dir/index.md"`. A PROTECTED folder's bytes live in the private store
    # beside the docroot, so both tests answered "not there" about content that
    # was there - and domain_add created a public folder at the gated path and
    # wrote a public seed page into it. The domain then served the seed instead
    # of the client's homepage.
    #
    # Reproduced before fixing (tmp/repro-sm852-s3-seed-over-gated.pl): a
    # protected index.md present, no public folder, and after the call a public
    # folder and a public seed reading "# Client work".
    #
    # AND IT COMPOUNDS, which is SM852's central point: creating a public
    # directory at a gated path pulls every LATER write under that folder into
    # the served tree, including writes from the manager, MCP and DAV paths that
    # resolve correctly - because those resolvers find the public directory
    # first.
    #
    # ADOPTING, NOT MOVING. When the root already exists in the private store
    # the right answer is to leave it alone: the operator is pointing a domain
    # at content that is already there, which is the adoption case the comment
    # above already describes. Relocating a protected tree on a domain-add would
    # be a much larger decision than this call is making.
    my ( $existing, $where ) = Lazysite::Private::resolve( $DOCROOT, $rel );
    my $dir = ( defined $existing && $where eq 'private' )
        ? $existing
        : "$DOCROOT/$rel";
    unless ( -d $dir ) {
        eval { make_path($dir); 1 }
            or return { ok => 0,
            error => "Domain configured but content root could not be created: $@" };
    }
    if ( $opts{seed} && !-e "$dir/index.md" ) {
        my $title = $opts{site_name} || $host;
        if ( open my $sf, '>:utf8', "$dir/index.md" ) {
            print {$sf} "---\ntitle: $title\n---\n\n# $title\n\n"
                . "This domain is served by lazysite. Replace this page.\n";
            close $sf;
        }
    }

    log_event( 'INFO', 'domain-add', 'domain configured',
        host => $host, content_root => $rel, user => $auth_user,
        ( length( $opts{allowed_groups} // '' ) ? ( allowed_groups => $opts{allowed_groups} ) : () ) );
    return { ok => 1, host => $host, content_root => $rel,
        ( length( $opts{allowed_groups} // '' ) ? ( allowed_groups => $opts{allowed_groups} ) : () ) };
}

# SM217: register a host as an ALIAS of one that already exists.
#
# A CONVENIENCE OVER THE EXISTING MECHANISM, and deliberately nothing more: it
# resolves the canonical domain's content root and registers the new host with
# the same one, through domain_add. The serving path is untouched, because there
# is nothing for it to learn - two hosts sharing a content root is what it
# already does.
#
# WHAT THIS REMOVES is the hand-copying. An operator had to add a second domain
# and type the shared path themselves, and a typo there does not fail: it
# silently forks the content into a folder nobody is looking at, and the alias
# serves a site that is not the one it is an alias of.
#
# THE ROOT IS READ, NOT ASKED FOR. A caller that supplied the path would be able
# to supply the wrong one, which is the mistake this exists to remove.
#
# AN EMPTY CANONICAL ROOT IS A VALID ANSWER, not a missing one: a host with no
# content_root of its own serves the default site, so an alias of it also has
# none and they mirror the primary together.
#
# PRESENTATION OVERRIDES PASS THROUGH. The filing's own words: per-host theme,
# layout, nav and lang still apply, so an alias may look different while serving
# the same content. `seed` does not pass through and is forced off - the content
# is already there by definition, and seeding would write a page into the
# canonical domain's own tree.
sub domain_add_alias {
    my ( $host, $of, %opts ) = @_;
    $host = lc( $host // '' );
    $of   = lc( $of   // '' );

    return { ok => 0, kind => 'invalid', error => 'the domain to alias is required' }
        unless length $of;
    return { ok => 0, kind => 'invalid',
        error => "a host cannot be an alias of itself ($host)" }
        if length $host && $host eq $of;

    # A CONTENT ROOT FROM THE CALLER IS REFUSED, not silently overridden. The
    # first version of this took %opts and then wrote content_root after it, so a
    # supplied root was quietly dropped - which honours the rule by accident and
    # is its own small lie: a caller who passed one would believe it had been
    # used. A sabotage that reordered those two found exactly that, because
    # nothing was asserting it.
    return { ok => 0, kind => 'invalid',
        error => 'content_root is not an argument here - an alias serves the '
            . "content root '$of' already has, which is the point of the action. "
            . 'Use domain-add to register a host with a root of its own.' }
        if defined $opts{content_root} && length $opts{content_root};

    # NOT known_domain_host: that admits the primary's site_url host, which is
    # not a registered row and has no content root of its own to share. The
    # canonical domain has to be one this file can resolve a root for.
    my $root = domain_content_root($of);
    return { ok => 0, kind => 'not-found',
        error => "no domain '$of' is configured, so there is nothing to be an alias of" }
        unless defined $root;

    my $r = domain_add( $host, %opts, content_root => $root, seed => 0 );
    return $r unless $r->{ok};
    log_event( 'INFO', 'domain-alias-add', 'domain configured as an alias',
        host => $host, alias_of => $of, content_root => $root, user => $auth_user );
    $r->{alias_of} = $of;
    return $r;
}

# --- public: set -----------------------------------------------------------

sub domain_set {
    my ( $host, $key, $value ) = @_;
    $host = lc( $host // '' );
    return host_refusal($host) unless valid_host($host);
    return { ok => 0, kind => 'invalid', error => "Not a settable domain key: $key" }
        unless defined $key && $IS_KEY{$key};
    $value = '' unless defined $value;

    # SM436: the same disagreement can be introduced after registration by
    # pointing site_url at a different name. The host cannot be changed to
    # match (not in @DOMAIN_KEYS, no rename verb), so accepting this would
    # leave a row that can never serve and can never be corrected in place.
    if ( $key eq 'site_url' && length $value ) {
        if ( my $why = _host_disagrees_with_url( $host, $value ) ) {
            return { ok => 0, kind => 'invalid', error => $why };
        }
    }

    if ( $key eq 'content_root' ) {
        my $rel = _clean_content_root($value);
        return { ok => 0, kind => 'invalid', error => 'Invalid content_root' }
            unless defined $rel;
        $value = $rel;
    }
    elsif ( $key eq 'allowed_groups' || $key eq 'locked_users' ) {
        # SM165: a comma list of group / account names. Normalise (trim, drop
        # blanks, dedupe) and reject any token that is not a plain name - this is
        # access-control config, so it fails closed rather than storing garbage.
        my @toks = grep { length } map { s/^\s+|\s+$//gr } split /,/, $value;
        # SM1014: a group is named @name everywhere one is picked, so a group
        # arrives with or without its @. allowed_groups STORES the plain name
        # (DomainAccess compares it with the groups file's), so the @ comes off
        # here. locked_users names accounts, where an @ is no part of a name and
        # stays refused below.
        @toks = map { s/\A\@//r } @toks if $key eq 'allowed_groups';
        for my $t (@toks) {
            return { ok => 0, kind => 'invalid', error => "Invalid name in $key: $t" }
                unless $t =~ /^[A-Za-z0-9_-]+\z/;
        }
        my %seen;
        my @names = grep { !$seen{$_}++ } @toks;
        if ( my $refusal = _refuse_unknown_names( $host, $key, @names ) ) {
            return $refusal;
        }
        $value = join ', ', @names;
    }
    elsif ( $key eq 'lang' ) {
        # SM179: a BCP-47-ish language tag (en, fr, pt-BR). Strict - it lands in
        # <html lang> and names the i18n override file. Empty clears it.
        $value =~ s/^\s+|\s+$//g;
        return { ok => 0, kind => 'invalid', error => 'Invalid language tag' }
            unless $value eq '' || $value =~ /^[A-Za-z]+(?:-[A-Za-z0-9]+)*\z/;
    }
    elsif ( $key eq 'lang_group' ) {
        # SM179: the language-set name, shared across the set's hosts. A plain
        # name token; empty clears it.
        $value =~ s/^\s+|\s+$//g;
        return { ok => 0, kind => 'invalid', error => 'Invalid lang_group name' }
            unless $value eq '' || $value =~ /^[A-Za-z0-9_-]+\z/;
    }
    elsif ( $IS_PRESENTATION{$key} ) {
        # SM583: the read side refuses a value that is not a name; this is
        # where the same rule fails LOUD, so a conf never acquires a value no
        # reader will accept. Empty clears the key.
        $value =~ s/^\s+|\s+$//g;
        return { ok => 0, kind => 'invalid',
            error => "Invalid $key name '$value': a layout or theme name must "
                . 'match [A-Za-z0-9_-]+. The value is refused rather than cut '
                . 'down to its first word, which would activate something '
                . 'nobody named. Leave it empty to clear the key.' }
            unless $value eq '' || valid_presentation_name($value);
    }
    # Values are single-line conf values: no newlines.
    return { ok => 0, kind => 'invalid', error => 'Value must be a single line' }
        if $value =~ /[\r\n]/;

    my $content = _slurp();
    my ( undef, undef, $hosts ) = _parse($content);
    return { ok => 0, kind => 'not-found', error => "Domain not configured: $host" }
        unless grep { $_ eq $host } @$hosts;

    return { ok => 0, error => 'Cannot read lazysite.conf' } unless defined $content;
    $content = _set_line( $content, $host, $key, $value );
    my ( $ok, $err ) = _write( $content, "set domain key $host" );
    return { ok => 0, error => $err } unless $ok;

    log_event( 'INFO', 'domain-set', 'domain key set',
        host => $host, key => $key, user => $auth_user );

    # SM241: binding a layout/theme to a domain must PUBLISH that theme's assets,
    # not merely record the choice. Without this the domain serves a 404
    # stylesheet: the layout renders its header, nav and footer correctly and the
    # page looks chrome-less because nothing styles it. That is what happened to
    # a secondary domain whose theme source was in the right place and whose
    # public mirror was never written.
    #
    # The mirror was previously written only by theme-activate, theme upload,
    # layout activate/install and site_apply - so the natural action for a
    # secondary domain was the one action that published nothing, and the
    # documented remedy (re-activate) is instance-wide and would switch the
    # PRIMARY site's theme.
    #
    # Mirrors the pair the host resolves to AFTER this change, using the theme's
    # own layout - the whole failure case is a secondary domain on a layout other
    # than the active one. Best-effort and non-fatal: the binding is recorded
    # either way, and _mirror_theme_assets already logs its own failure.
    # SM322: and REPORT what it mirrored. SM315 gave activation an
    # `assets_mirrored` count on the reasoning that zero is the whole point - a
    # theme that mirrors nothing is a site about to render unstyled, and at the
    # HTTP level that is indistinguishable from a working one. It was added to
    # action_theme_activate and not here, so the per-domain path - which is the
    # path a MULTI-DOMAIN instance uses, and the one whose failure SM315 was
    # written about - ran the mirror and threw the answer away.
    #
    # An agent binding a theme to a domain got ok:1 and no indication whether
    # anything had been published. That is how a fully unstyled site was handed
    # over on edge2 in August with every page returning 200.
    my $mirror;
    if ( $key eq 'layout' || $key eq 'theme' ) {
        my ( $l, $t ) = _effective_presentation($host);
        if ( length $l && length $t ) {
            local $@;
            eval {
                # Loaded and imported at RUNTIME: Themes uses this module, so a
                # compile-time `use` here would close the loop. _mirror_theme_assets
                # is in the Themes @EXPORT_OK set (SitePackage imports it the
                # ordinary way), so this is a published helper, not a reach inside.
                require Lazysite::Manager::Themes;
                Lazysite::Manager::Themes->import(
                    '_mirror_theme_assets', '_mirror_warning' );
                no warnings 'once';    # fully-qualified package vars
                local $Lazysite::Manager::Themes::DOCROOT      = $DOCROOT;
                local $Lazysite::Manager::Themes::LAZYSITE_DIR = _lz();
                local $Lazysite::Manager::Themes::action       = 'domain-set';
                $mirror = _mirror_theme_assets( $l, $t );
                1;
            } or log_event( 'WARN', 'domain-set', 'theme asset mirror skipped',
                host => $host, error => "$@" );
        }
    }

    my $res = { ok => 1, host => $host, key => $key, value => $value };
    if ( ref $mirror eq 'HASH' ) {
        $res->{assets_mirrored} = $mirror->{mirrored};
        # Themes is loaded by the block above - a mirror result only exists
        # because the require succeeded - so the shared builder is reachable.
        push @{ $res->{warnings} ||= [] },
            _mirror_warning(
            $mirror,
            'no theme assets were mirrored for this domain: ',
            'This domain will render with no stylesheet, and every page '
                . 'will still return 200.'
            ) unless $mirror->{mirrored};
    }
    return $res;
}

# SM1016: RULED by the release manager on 2026-10-12, "lazysite-domains.pl
# should reject invalid groups" - and so every surface, because they all write
# through domain_set: the Domains page, the control API's domain-set, MCP
# domain_set, `lazysite-domains.pl set` and group-add/user-add.
#
# A misspelt group in allowed_groups admits nobody to the domain, and a
# misspelt account in locked_users locks nobody, each while the write reports
# success. So a NEW name - one the host's own list does not already hold - must
# be a group (in the groups file or groups-settings.json, the test group-nest
# uses) or an account (in the users file). Every unknown name is named, and
# nothing is written.
#
# ONLY NEW NAMES. A name the list already holds is not asked about: a group
# deleted after it was allowed would otherwise make the list unwritable,
# including the write that takes it out.
#
# A store that cannot be read is no answer (SM906), so the write is refused,
# naming the store, rather than taken as "nobody exists".
sub _refuse_unknown_names {
    my ( $host, $key, @names ) = @_;
    my $kind = $key eq 'allowed_groups' ? 'group' : 'account';
    my ( undef, $ov ) = _parse();
    my %had = map { $_ => 1 } grep { length }
        map { s/^\s+|\s+$//gr } split /,/, ( ( ref $ov eq 'HASH' && $ov->{$host}{$key} ) // '' );
    my @new = grep { !$had{$_} } @names;
    return undef unless @new;

    require Lazysite::Auth::Settings;
    no warnings 'once';
    local $Lazysite::Auth::Settings::AUTH_DIR = $Lazysite::Auth::Settings::AUTH_DIR
        // ( _lz() . '/auth' );
    my ( %known, $store );
    if ( $kind eq 'group' ) {
        my $members  = Lazysite::Auth::Settings::group_names();
        my $bad      = $Lazysite::Auth::Settings::GROUPS_UNREADABLE;
        my $settings = Lazysite::Auth::Settings::read_group_settings();
        $store
            = $bad ? 'lazysite/auth/groups'
            : Lazysite::Auth::Settings::group_settings_unreadable()
            ? 'lazysite/auth/groups-settings.json'
            : '';
        %known = ( %{ $members || {} }, ( ref $settings eq 'HASH' ? %$settings : () ) );
    }
    else {
        my $accounts = Lazysite::Auth::Settings::account_names();
        $store = $Lazysite::Auth::Settings::USERS_UNREADABLE ? 'lazysite/auth/users' : '';
        %known = %{ $accounts || {} };
    }
    my $shown = sub { $kind eq 'group' ? "\@$_[0]" : $_[0] };
    my $list  = join ', ', map { $shown->($_) } @new;
    return { ok => 0, kind => 'unreadable',
        error => "Cannot tell whether $list exists: $store cannot be read, so "
            . "${host}'s $key is unchanged." }
        if length $store;
    my @unknown = grep { !$known{$_} } @new;
    return undef unless @unknown;
    my $names = join ', ', map { $shown->($_) } @unknown;
    return { ok => 0, kind => 'unknown-principals', unknown => \@unknown,
        error => 'No ' . ( @unknown == 1 ? $kind : "${kind}s" ) . " $names on this site, so "
            . "${host}'s $key is unchanged: "
            . ( $kind eq 'group'
            ? 'a group that does not exist admits nobody to the domain.'
            : 'an account that does not exist is locked to nothing.' ) };
}

# SM1015: add or remove ONE name in a domain's allowed_groups (or locked_users),
# leaving the others as they are. Ruled 2026-10-12: "lets have cli command to
# add the domain group" (lazysite-domains.pl group-add / group-remove, and
# user-add / user-remove for locked_users).
#
# THE WRITE IS domain_set's. The list is read, one name added or taken out, and
# the whole list goes back through domain_set, so its validation, the conf
# writer's lock and content-history commit, and its log line are the ones every
# other surface gets. Caller rules (manage_users, the SM976 reach) belong to
# the caller, as they do for domain_set: the CLI is the operator's.
#
# THE OWN VALUE, NOT THE EFFECTIVE ONE. DomainAccess reads only the host's own
# alias.<host>.<key> line - a primary's allowed_groups is not inherited - so
# that is the list edited here.
#
# A NAME THAT IS NOT THERE IS REFUSED ON ADD, by domain_set (SM1016,
# _refuse_unknown_names). Remove asks nothing: taking out a name the site no
# longer has is how such a list is repaired.
#
# Idempotent: adding a name already there, or removing one that is not, writes
# nothing and answers ok with changed => 0 and a sentence saying so.
sub domain_access_edit {
    my ( $host, $key, $op, $name ) = @_;
    $host = lc( $host // '' );
    return host_refusal($host) unless valid_host($host);
    my %KIND = ( allowed_groups => 'group', locked_users => 'account' );
    my $kind = $KIND{ $key // '' }
        or return { ok => 0, kind => 'invalid',
        error => 'Not an access key: ' . ( $key // '' ) . ' (allowed_groups or locked_users)' };
    return { ok => 0, kind => 'invalid', error => "Not an operation: " . ( $op // '' ) }
        unless defined $op && ( $op eq 'add' || $op eq 'remove' );

    $name = defined $name ? $name =~ s/^\s+|\s+$//gr : '';
    $name =~ s/\A\@// if $kind eq 'group';    # SM1014: @name or name
    return { ok => 0, kind => 'invalid', error => "A $kind name is required" }
        unless length $name;
    return { ok => 0, kind => 'invalid', error => "Not a $kind name: $name" }
        unless $name =~ /\A[A-Za-z0-9_-]+\z/;
    my $shown = $kind eq 'group' ? "\@$name" : $name;

    my ( undef, $ov, $hosts ) = _parse();
    return { ok => 0, kind => 'not-found', error => "Domain not configured: $host" }
        unless grep { $_ eq $host } @$hosts;
    my @have = grep { length } map { s/^\s+|\s+$//gr } split /,/, ( $ov->{$host}{$key} // '' );
    my $present = grep { $_ eq $name } @have;

    if ( $op eq 'add' && $present ) {
        return { ok => 1, changed => 0, host => $host, key => $key, value => join( ', ', @have ),
            message => "$shown is already in ${host}'s $key; nothing changed." };
    }
    if ( $op eq 'remove' && !$present ) {
        return { ok => 1, changed => 0, host => $host, key => $key, value => join( ', ', @have ),
            message => "$shown is not in ${host}'s $key; nothing changed." };
    }

    # The name added is checked by domain_set (SM1016), as every new name on
    # every surface is.
    my @new = $op eq 'add' ? ( @have, $name ) : grep { $_ ne $name } @have;
    my $r   = domain_set( $host, $key, join( ', ', @new ) );
    return $r unless ref $r eq 'HASH' && $r->{ok};
    $r->{changed} = 1;
    $r->{message} = $op eq 'add' ? "$shown added to ${host}'s $key." : "$shown removed from ${host}'s $key.";
    return $r;
}

# SM241: the layout+theme a host actually resolves to - its own override where it
# has one, the base site's value otherwise. Same resolution domain_usage uses, so
# what gets mirrored is what gets served.
sub _effective_presentation {
    my ($host) = @_;
    my ( $base, $ov ) = _parse();
    return ( _effective( $base, $ov, $host, 'layout' ),
        _effective( $base, $ov, $host, 'theme' ) );
}

# --- public: remove --------------------------------------------------------

# Removes the host from this instance: drops it from alias_hosts and strips every
# alias.<host>.* line. The content directory is LEFT IN PLACE by default (data
# safety); pass purge => 1 to remove it too.
sub domain_remove {
    my ( $host, %opts ) = @_;
    $host = lc( $host // '' );
    return host_refusal($host) unless valid_host($host);

    my $content = _slurp();
    my ( undef, $ov, $hosts ) = _parse($content);
    return { ok => 0, kind => 'not-found', error => "Domain not configured: $host" }
        unless grep { $_ eq $host } @$hosts;

    my $rel = $ov->{$host}{content_root};

    return { ok => 0, error => 'Cannot read lazysite.conf' } unless defined $content;

    # Strip every alias.<host>.<key> line.
    my $qh = quotemeta $host;
    $content =~ s/^alias\.$qh\.\w+\s*:.*\n//mg;

    # Rewrite alias_hosts without this host.
    my @remaining = grep { $_ ne $host } @$hosts;
    $content = _set_base( $content, 'alias_hosts', join( ',', @remaining ) );

    my ( $ok, $err ) = _write( $content, "remove domain $host" );
    return { ok => 0, error => $err } unless $ok;

    # N141D (SM852 MISS row): PURGE BOTH HALVES, AND ONLY CLAIM WHAT WAS DONE.
    #
    # This built its target as realpath("$DOCROOT/$clean") - the public path -
    # and a protected section's bytes live in the PRIVATE STORE beside the
    # docroot. So a domain whose content root is gated had the one thing most
    # worth deleting left on disk, and the call answered `purged => 1`.
    #
    # Reproduced before fixing (tmp/repro-sm852-purge-reports-purged.pl): two
    # files in the private store before, two after, purged => 1. An operator
    # removing a domain to be rid of its content was told the content was gone,
    # and what had actually been deleted was the empty public husk a gated
    # folder leaves behind.
    #
    # THE CLAIM IS NOW DERIVED FROM WHAT HAPPENED. `$purged` counts the trees
    # actually removed rather than being set to 1 by reaching the end of a
    # block: a remove_tree that dies inside the eval used to leave purged => 1
    # as well, so the flag reported the attempt and not the outcome. Each half
    # is confined to its own root separately - the private store is NOT under
    # the docroot, so the docroot containment check cannot speak for it, and
    # reusing it would have been the same mistake in the other direction.
    my $purged = 0;
    if ( $opts{purge} && defined $rel ) {
        my $clean = _clean_content_root($rel);
        if ( defined $clean ) {
            my $priv_root = Lazysite::Private::private_root($DOCROOT);
            for my $base ( $DOCROOT, $priv_root ) {
                next unless defined $base && length $base;
                my $real = realpath("$base/$clean") or next;
                my $root = realpath($base)          or next;
                next if $real eq $root;
                next unless index( $real, "$root/" ) == 0;
                eval {
                    File::Path::remove_tree($real);
                    $purged++ unless -e $real;
                    1;
                };
            }
        }
    }

    log_event( 'INFO', 'domain-remove', 'domain removed',
        host => $host, purged => $purged, user => $auth_user );
    return { ok => 1, host => $host, purged => $purged };
}

# --- public: check a domain's live configuration (SM156) -------------------

# Resolve a host to its distinct IP addresses (v4 + v6). Returns the list, or
# () when the name does not resolve. Loaded lazily - the network modules must
# not add to every manager request's startup.
sub _resolve_ips {
    my ($host) = @_;
    return () unless eval { require Socket; 1 };    # absent => treated as "no resolution"
    my ( $err, @res )
        = Socket::getaddrinfo( $host, '', { socktype => Socket::SOCK_STREAM() } );
    return () if $err;
    my ( %seen, @ips );
    for my $ai (@res) {
        my ( $e, $ip )
            = Socket::getnameinfo( $ai->{addr}, Socket::NI_NUMERICHOST(), Socket::NIx_NOSERV() );
        next if $e;
        push @ips, $ip unless $seen{$ip}++;
    }
    return @ips;
}

# SSRF guard (SEC-2026-07, 0.8.1): domain-check opens outbound TLS + HTTPS
# connections to a caller-influenced host. A manage_domains delegate could point
# that at the server's own internal network - loopback, RFC1918, the cloud
# metadata endpoint (169.254.169.254), CGNAT, an IPv6 ULA/link-local - directly
# (an IP-literal or 'localhost' host, both of which pass valid_host) or via DNS
# rebinding (a public name that resolves to an internal address). The connection
# is refused unless every RESOLVED address is public, so the guard holds for the
# rebinding case too (it keys on the resolved IPs, not the name). Returns 1 for a
# routable public address, 0 for anything internal/reserved/malformed.
#
# SM526: this is also the filter instance_public_ips applies to this install's
# OWN addresses. A second classifier for that purpose drifted (8 of 15 probe
# inputs disagreed) and offered a mapped loopback or a CGNAT address as "this
# server". One question, one answer: an address the guard would refuse to
# connect to is never an address of this server either.
sub _ip_is_public {
    my ($ip) = @_;
    return 0 unless defined $ip && length $ip;
    $ip =~ s/^::ffff:(?=\d+\.\d+\.\d+\.\d+$)//i;    # IPv4-mapped IPv6 -> test the v4
    if ( $ip =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/ ) {
        my @o = ( $1, $2, $3, $4 );
        return 0 if grep { $_ > 255 } @o;                           # malformed
        return 0 if $o[0] == 0;                                     # 0.0.0.0/8 this-host
        return 0 if $o[0] == 10;                                    # 10/8 private
        return 0 if $o[0] == 127;                                   # 127/8 loopback
        return 0 if $o[0] == 169 && $o[1] == 254;    # 169.254/16 link-local + metadata
        return 0 if $o[0] == 172 && $o[1] >= 16 && $o[1] <= 31;    # 172.16/12 private
        return 0 if $o[0] == 192 && $o[1] == 168;                  # 192.168/16 private
        return 0 if $o[0] == 100 && $o[1] >= 64 && $o[1] <= 127;    # 100.64/10 CGNAT
        return 0 if $o[0] >= 224;    # 224/4 multicast, 240/4 reserved
        return 1;
    }
    my $l = lc $ip;
    $l =~ s/%.*$//;                           # strip an IPv6 zone id (fe80::1%eth0)
    return 0 if $l eq '::' || $l eq '::1';    # unspecified / loopback
    return 0 if $l =~ /^fe[89ab]/;            # fe80::/10 link-local
    return 0 if $l =~ /^f[cd]/;               # fc00::/7 unique-local
    return 1;                                 # global unicast
}

# Open a verified TLS connection to $host:443. A connection only forms when the
# certificate is valid AND matches the host (SSL_verify_mode PEER + SNI), so a
# returned {ok=>1} means "trusted HTTPS". When full verification fails we probe
# again verifying the CHAIN but NOT the hostname, to tell a SAN/coverage gap
# (a trusted cert is served but does not cover this host - e.g. Hestia did not
# add the sub-domain to the certificate) apart from "no trusted HTTPS at all".
# Detail carries the CN and expiry when they can be read; never throws.
sub _tls_probe {
    my ( $host, $timeout ) = @_;
    return { ok => 0, detail => 'TLS check unavailable (IO::Socket::SSL not installed)' }
        unless eval { require IO::Socket::SSL; 1 };

    my $sock = IO::Socket::SSL->new(
        PeerHost          => $host,
        PeerPort          => 443,
        Timeout           => $timeout,
        SSL_verify_mode   => IO::Socket::SSL::SSL_VERIFY_PEER(),
        SSL_hostname      => $host,
        SSL_verifycn_name => $host,
    );
    if ($sock) {
        my $cn      = eval { $sock->peer_certificate('commonName') } // '';
        my $expires = eval {
            require Net::SSLeay;    # IO::Socket::SSL's backend; named for the SBOM
            my $t = Net::SSLeay::X509_get_notAfter( $sock->peer_certificate );
            $t ? Net::SSLeay::P_ASN1_TIME_get_isotime($t) : '';
        } // '';
        close $sock;
        my $detail = 'valid certificate';
        $detail .= " for $cn"           if length $cn;
        $detail .= ", expires $expires" if length $expires;
        return { ok => 1, detail => $detail, expires => $expires };
    }

    my $e = do { no warnings 'once'; $IO::Socket::SSL::SSL_ERROR || $! || 'connection failed' };
    $e =~ s/\s+/ /g;

    # Chain-only probe: same connection, hostname verification disabled. If it
    # succeeds, a TRUSTED certificate is served - it just does not cover $host.
    my $chain = IO::Socket::SSL->new(
        PeerHost            => $host,
        PeerPort            => 443,
        Timeout             => $timeout,
        SSL_verify_mode     => IO::Socket::SSL::SSL_VERIFY_PEER(),
        SSL_hostname        => $host,     # SNI, so the server returns its cert
        SSL_verifycn_scheme => 'none',    # verify the chain, NOT the hostname
    );
    if ($chain) {
        # What the cert DOES cover: its dNSName SANs (type 2), falling back to
        # the CN - so the operator sees exactly which name is missing.
        my @san = eval {
            map  { $_->[1] }
            grep { ref $_ eq 'ARRAY' && $_->[0] == 2 }
                $chain->peer_certificate('subjectAltNames');
        };
        my $cn = eval { $chain->peer_certificate('commonName') } // '';
        close $chain;
        my ( %seen, @cover );
        for ( @san, $cn ) { push @cover, $_ if defined && length && !$seen{$_}++ }
        my $shown
            = @cover > 6 ? ( join( ', ', @cover[ 0 .. 5 ] ) . ', …' ) : join( ', ', @cover );
        my $detail = 'a certificate is served';
        $detail .= " (covers $shown)" if length $shown;
        $detail .= ' but not this host'
            . ' - add this host to the certificate (e.g. via Hestia SSL)';
        return { ok => 0, kind => 'cert-mismatch', detail => $detail, covers => \@cover };
    }

    return { ok => 0, detail => "no trusted HTTPS ($e)" };
}

# GET the public instance marker over $host and read back its instance id, so
# the caller can tell whether the request terminated on THIS install.
sub _marker_fetch {
    my ( $host, $timeout ) = @_;
    return { ok => 0, detail => 'HTTPS check unavailable (HTTP::Tiny not installed)' }
        unless eval { require HTTP::Tiny; 1 };
    my $http = HTTP::Tiny->new(
        timeout    => $timeout,
        verify_SSL => 1,
        agent      => 'lazysite-domain-check/1 ',
    );
    my $res = $http->get("https://$host/.well-known/lazysite-instance.json");
    unless ( $res->{success} ) {
        my $why = $res->{status} == 599 ? ( $res->{content} || 'network error' )
            :   "HTTP $res->{status}";
        $why =~ s/\s+/ /g;
        return { ok => 0, detail => $why };
    }
    my ($inst) = ( $res->{content} // '' ) =~ /"instance"\s*:\s*"([0-9a-f]{1,64})"/;
    return { ok => 1, instance => ( $inst // '' ), detail => 'marker answered' };
}

# The PUBLIC address(es) an operator would point a domain at to reach THIS
# install - for the "points to this server" check. Behind a proxy/NAT the
# private SERVER_ADDR is wrong, so discover the public address in order:
#   1. canonical_ip (an explicit override, or the config key) - authoritative;
#   2. resolving the install's own domain (the primary site_url host), which
#      goes through the same public entry point a new domain must;
#   3. SERVER_ADDR, only if it is itself public (a non-proxied host).
# Empty list => undecidable; the check then reports "unknown", not a failure.
sub instance_public_ips {
    my (%o)    = @_;
    my ($base) = _parse();

    my $cfg = ( defined $o{canonical_ip} && length $o{canonical_ip} )
        ? $o{canonical_ip}
        : ( $base->{canonical_ip} // '' );
    if ( length $cfg ) {
        my @ips = grep { _ip_is_public($_) } map { s/^\s+|\s+$//gr } split /,/, $cfg;
        return @ips if @ips;
    }

    my $site_url = $base->{site_url} // '';
    if ( $site_url =~ m{^https?://([^/:]+)}i ) {
        my @ips = grep { _ip_is_public($_) } _resolve_ips( lc $1 );
        return @ips if @ips;
    }

    return ( $o{fallback_ip} )
        if length( $o{fallback_ip} // '' ) && _ip_is_public( $o{fallback_ip} );

    return ();
}

# domain_check($host, %opt) - is $host configured to serve THIS install live?
# Runs four ordered checks and returns them as an array (UI renders in order):
#   dns        - the name resolves to an address
#   host       - one of those addresses is THIS server (opt{self_ips}); undef
#                (indeterminate) when our public address is unknown
#   ssl        - a trusted certificate terminates for the host
#   terminates - an HTTPS request lands on THIS install (marker id == opt{instance_id})
# %opt: self_ips (arrayref) or self_ip, instance_id, timeout; and
#       resolve/tls/fetch code-ref overrides
# so tests drive every branch without touching the network. A check `pass` is
# 1, 0, or undef (indeterminate - e.g. this server's own address is unknown).
sub domain_check {
    my ( $host, %opt ) = @_;
    $host = lc( $host // '' );
    return host_refusal($host) unless valid_host($host);

    # The server's own PUBLIC address(es). A list, because behind a proxy / NAT
    # the private SERVER_ADDR is useless - the caller self-discovers the public
    # IP(s) (sysop canonical_ip, or resolving the install's own domain) and
    # passes them here. self_ip (scalar) is still accepted for a simple caller.
    my @self_ips
        = $opt{self_ips} ? grep { length } @{ $opt{self_ips} }
        : ( defined $opt{self_ip} && length $opt{self_ip} ) ? ( $opt{self_ip} )
        :                                                     ();
    my $instance = $opt{instance_id} // '';
    my $timeout  = $opt{timeout} || 6;
    my $resolve  = $opt{resolve} || \&_resolve_ips;
    my $tls      = $opt{tls}     || \&_tls_probe;
    my $fetch    = $opt{fetch}   || \&_marker_fetch;

    my @checks;

    # 1. DNS resolution.
    my @ips    = $resolve->($host);
    my $dns_ok = @ips ? 1 : 0;
    push @checks, {
        id     => 'dns',
        label  => 'DNS resolves',
        pass   => $dns_ok,
        detail => $dns_ok
        ? ( 'resolves to ' . join( ', ', @ips ) )
        : 'the host name does not resolve yet - add the DNS record',
    };

    # SSRF guard: if ANY resolved address is non-public, refuse the outbound TLS
    # and marker connections below. Keying on the resolved IPs (not the host name)
    # closes the DNS-rebinding path too. A public domain legitimately never
    # resolves to an internal address, so this only ever fires on abuse.
    my @nonpublic  = grep { !_ip_is_public($_) } @ips;
    my $ssrf_block = @nonpublic ? 1 : 0;

    # 2. Points to this server (a resolved IP is one of ours). Behind a proxy or
    # NAT the server cannot know its own public IP, so when none was discovered
    # this is INDETERMINATE (undef), not a failure - the "Serves this lazysite"
    # check below is the authoritative reachability signal.
    if ( !$dns_ok ) {
        push @checks, { id => 'host', label => 'Points to this server',
            pass => 0, detail => 'skipped - the host does not resolve' };
    }
    elsif ( !@self_ips ) {
        push @checks, {
            id     => 'host',
            label  => 'Points to this server',
            pass   => undef,
            detail => "this server's public address is unknown (behind a proxy/NAT?) - "
                . 'set canonical_ip in config to enable this check',
        };
    }
    else {
        my %mine = map { $_ => 1 } @self_ips;
        my ($match) = grep { $mine{$_} } @ips;
        push @checks, {
            id     => 'host',
            label  => 'Points to this server',
            pass   => $match ? 1 : 0,
            detail => $match
            ? "points here ($match)"
            : ( 'resolves to ' . join( ', ', @ips )
                    . ', not this server (' . join( ', ', @self_ips ) . ')' ),
        };
    }

    # 3. Trusted HTTPS certificate. Refused (not probed) when the host resolves
    # to a non-public address - see the SSRF guard above.
    if ($ssrf_block) {
        push @checks, { id => 'ssl', label => 'HTTPS certificate valid', pass => 0,
            detail => 'refused - the host resolves to a non-public address ('
                . join( ', ', @nonpublic ) . '); not probed (SSRF guard)' };
    }
    else {
        my $ssl = $tls->( $host, $timeout );
        push @checks, { id => 'ssl', label => 'HTTPS certificate valid',
            pass => $ssl->{ok} ? 1 : 0, detail => $ssl->{detail} };
    }

    # 4. Terminates on THIS install (marker id match). Also refused under the guard.
    if ($ssrf_block) {
        push @checks, { id => 'terminates', label => 'Serves this lazysite', pass => 0,
            detail => 'refused - the host resolves to a non-public address ('
                . join( ', ', @nonpublic ) . '); not fetched (SSRF guard)' };
    }
    else {
        my $mk = $fetch->( $host, $timeout );
        my $term_ok
            = ( $mk->{ok} && length $instance && ( $mk->{instance} // '' ) eq $instance ) ? 1 : 0;
        my $tdetail
            = !$mk->{ok} ? ( 'no reply over HTTPS - ' . ( $mk->{detail} || 'unreachable' ) )
            : $term_ok   ? 'serves this lazysite instance'
            :              'reachable, but answered by a different server or instance';
        push @checks, { id => 'terminates', label => 'Serves this lazysite',
            pass => $term_ok, detail => $tdetail };
    }

    my $all_pass = ( grep { defined $_->{pass} && !$_->{pass} } @checks ) ? 0 : 1;
    return { ok => 1, host => $host, all_pass => $all_pass, checks => \@checks };
}

# --- SM944 S27: the control API's domain actions ----------------------------
# Moved unchanged out of lazysite-manager-api.pl, but for one line:
#   _instance_id          this install's SM156 marker value
#   action_domain_check   domain-check: is a configured domain live here, for an account
#   action_domains_list   domains-list: the domains, filtered by the domain rule
# Ruled 2026-10-10 ("Read Common's value"): the check's refusal reads WHO IS
# ASKING as $Lazysite::Manager::Common::auth_user, by its full name. A bare
# $auth_user in this package is this module's own copy of the acting user, for
# log attribution only: the manager API sets it per request (SM154), MCP,
# WebDAV and the domains CLI never do, and reset_request_context() does not
# empty it - read here it would let a check run after a request's reset
# (t/unit/manager/217). $LAZYSITE_DIR is set by the script; the CLI calls
# neither action.

# SM155: render a configured domain's HOME page as an anonymous public visitor
# would see it under its own Host - so an operator can prepare/debug a new domain
# BEFORE DNS/TLS is pointing at it. Shells the processor exactly like the dev
# server / action_preview, but with HTTP_HOST set (SM151 per-Host routing picks
# the domain's content_root + theme/layout/nav overrides) and the auth headers
# cleared (so the render is the public site, no manager admin bar).
# A host is "known" iff it is a registered alias host OR it is the primary
# site's own host (derived from its site_url). This BOUNDS the preview render
# and, more importantly, the domain-check outbound probe to operator-declared
# hosts - grepping `|| is_primary` matched the ever-present (default) row and so
# accepted ANY host, which for the SSRF-sensitive check must not happen.
# SM156: a stable, non-sensitive per-install id - identical to the processor's
# (same one-way function over the same docroot), so a domain-check can tell
# whether an HTTPS request to the candidate host lands back on THIS install.
sub _instance_id {
    my $base = realpath($DOCROOT) // $DOCROOT;
    return substr( hmac_sha256_hex( $base, 'lazysite-instance' ), 0, 32 );
}

# SM156: check whether a configured domain is configured to serve THIS install
# live (DNS resolves -> points here -> valid HTTPS cert -> terminates on this
# instance). The authoritative half of the hybrid check - it does the DNS / IP /
# TLS / marker work a browser cannot. self_ip is the address Apache accepted the
# manager request on (SERVER_ADDR); instance_id is our own marker value.
sub action_domain_check {
    my ($host) = @_;
    # SM944 S27, the established fail-closed pattern (ruled 2026-10-10, "Read
    # Common's value"): A DOMAIN CHECK PROBES FOR AN ACCOUNT. Inside a request
    # the dispatcher has refused an empty $auth_user (and asked the domain rule)
    # before this runs, so it is never empty here; reached outside one (the
    # request context's reset leaves nobody) it ran its outbound DNS/TLS probe
    # with nobody asking (tmp/sm944-s27-s28-refusal-probe.out). The account is
    # Manager::Common's - the one the reset empties - never a module's own
    # log-attribution copy, which nothing resets.
    return { ok => 0, kind => 'forbidden',
        error => 'A domain check is run by a signed-in account, and no account is asking.' }
        unless length $Lazysite::Manager::Common::auth_user;
    $host = lc( $host // '' );
    # A THIRD copy of the host rule lived here and could answer differently
    # from Domains.pm for the same host. It defers to the one rule now, and to
    # the refusal that says which of "absent" and "malformed" happened.
    return host_refusal($host) unless valid_host($host);

    # Bound the outbound probe to sysop-declared hosts (no SSRF to arbitrary
    # targets): only a configured domain or the primary site's own host.
    return { ok => 0, error => "Not a configured domain: $host" }
        unless known_domain_host($host);

    # Self-discover this install's PUBLIC address(es): SERVER_ADDR is the private
    # inbound IP behind a proxy/NAT, so instance_public_ips prefers the sysop's
    # canonical_ip config, then the install's own domain, then a public
    # SERVER_ADDR. An empty list makes the "points here" check indeterminate
    # rather than a false failure.
    my @self = Lazysite::Manager::Domains::instance_public_ips(
        fallback_ip => ( $ENV{SERVER_ADDR} // '' ) );

    return domain_check(
        $host,
        self_ips    => \@self,
        instance_id => _instance_id(),
    );
}

# SM151: read-only view of the domains this instance serves - the primary host
# plus each declared alias, with the presentation/routing keys that vary per
# host (an alias inherits the base value where it has no override). Parsed
# straight from lazysite.conf; aliases are sysop conf-file territory, so the
# manager only displays them, never edits them.
sub action_domains_list {
    my @keys = qw(site_name site_url content_root theme layout nav_file search_default
        allowed_groups locked_users lang lang_group);
    my %base;
    my %ov;    # host => { key => value }
    if ( open my $fh, '<', "$LAZYSITE_DIR/lazysite.conf" ) {
        while ( my $line = <$fh> ) {
            if ( $line =~ /^alias\.(\S+)\.(\w+)\s*:\s*(.*?)\s*$/ ) {
                $ov{ lc $1 }{$2} = $3;
            }
            elsif ( $line =~ /^(\w+)\s*:\s*(.*?)\s*$/ ) {
                $base{$1} = $2;
            }
        }
        close $fh;
    }
    # SM917: no alias overrides read means every domain appears to inherit the
    # base settings, which is what a site with no overrides looks like.
    else { Lazysite::Util::cannot_read( 'the site conf', "$LAZYSITE_DIR/lazysite.conf" ) }

    my @domains;
    push @domains,
        {
        host       => '(default)',
        is_primary => 1,
        map { $_ => ( $base{$_} // '' ) } @keys,
        };
    for my $h ( split /,/, ( $base{alias_hosts} // '' ) ) {
        $h =~ s/^\s+|\s+$//g;
        next unless length $h;
        my %row = ( host => lc $h, is_primary => 0 );
        for my $k (@keys) {
            # An alias override wins; otherwise the host inherits the base value.
            $row{$k} = defined $ov{ lc $h }{$k} ? $ov{ lc $h }{$k} : ( $base{$k} // '' );
            $row{ $k . '_inherited' } = ( defined $ov{ lc $h }{$k} ) ? 0 : 1;
        }
        push @domains, \%row;
    }
    # SM976: a domain-confined caller is shown its own domains only. A row
    # carries another domain's content root, access groups and address.
    @domains = grep { Lazysite::Manager::Common::caller_may_reach_domain( host => $_->{host} ) }
        @domains;
    return { ok => 1, domains => \@domains, keys => \@keys };
}

1;
