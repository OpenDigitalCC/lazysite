package Lazysite::Manager::StartPage;

# SM724: a user has a start page - where a sign-in with no destination lands.
#
# THE RULING (release manager, 2026-09-05): the fallback is the manager with the
# user's own account sheet open; the user, or a user manager, may set the start
# page; a domain target is a chosen page on that domain, not only its root.
#
# THREE THINGS DECIDE THE SHAPE, and each is a rule here rather than a comment:
#
# 1. A DOMAIN IS NOT A PATH. The login's `next` guard (sanitise_next) exists to
#    stop a sign-in redirecting off-site, and a "domains" dropdown proposes
#    exactly that. So a domain target is checked against the domains THIS
#    INSTANCE SERVES, by name, never against a character class - and the two
#    kinds of target are stored as two kinds (`manager:<page>` and
#    `domain:<host>|<path>`) so the distinction cannot be lost in one field.
#
# 2. A START PAGE THE USER CANNOT REACH TURNS SIGN-IN INTO A REFUSAL. The
#    choices offered for an account are computed from THAT account's grants -
#    the target's, never the operator's building the list - and a grant can
#    change after the choice is made, so resolve() checks again at every login
#    and falls back WITH A REASON rather than sending someone to a 403 forever.
#
#    SM774 (131E-05): the same rule for the OTHER kind of target. A page on a
#    site is checked for existence when set and again at every sign-in - a
#    content page is the kind that gets deleted - so a start page whose page
#    is gone lands on the fallback with the reason, never on a 404 that is
#    one click from the sheet that could fix it.
#
# 3. AN EXPLICIT `next` WINS. Someone bounced to login from a page is going
#    somewhere; the start page is for an arrival with no destination. The
#    caller decides that (lazysite-auth.pl asks only when next is '/').
#
# The setting is a PREFERENCE, like display_name (SM642): nothing grants,
# confines, audits or looks an account up by it.
use strict;
use warnings;
use Lazysite::Paths ();
use Exporter qw(import);
# SM944 S23: the manager API's two actions read the request's account and its
# caps, and set through the users tool - Common's, set only by the manager API.
# S33: start-page-set's handler reads the request's body (_json_body).
use Lazysite::Manager::Common qw($auth_user _user_caps users_api _json_body);
our @EXPORT_OK = qw(parse_start_page validate_start_page start_page_choices
    resolve_start_page fallback_landing manager_pages current_start_page apply_start_page
    action_start_page action_start_page_set dispatch_start_page_set);

our $DOCROOT = '';

# THE MANAGER PAGES A START PAGE MAY NAME, with the capability that reaches
# each (any-of; an empty list means every interactive account). This is the
# nav's own gating in starter/lazysite/manager/layout.tt, held here as data;
# t/lint/116 pins the two together so a page cannot be offered that the nav
# would not show, or shown that this would refuse. `plugin` names a plugin the
# page needs enabled. Pages that take a path (edit) or are a reference
# (style-guide) are not start pages.
our %PAGES = (
    # SM957: the menu's first entry - every form's submissions in one place.
    # SM979: approve_accounts reaches it as well, showing the account requests.
    'submissions' => { label => 'Submissions', caps => [ 'read_submissions', 'approve_accounts' ] },
    'index'      => { label => 'Site settings', caps => [] },
    'files'      => { label => 'Files',         caps => ['manage_content'] },
    'nav'        => { label => 'Navigation',    caps => ['manage_nav'] },
    'appearance' => { label => 'Appearance', caps => [ 'manage_themes', 'manage_layouts' ] },
    # SM957: ONE entry, "Extensions"; its configuration is a tab of the same
    # page (/manager/plugin-config), so it is not a start page of its own.
    'plugins'  => { label => 'Extensions',      caps => [] },
    'users'         => { label => 'Users',           caps => [] },
    'groups'        => { label => 'Groups',          caps => [] },
    'address-lists' => { label => 'Address lists',   caps => [] },                # SM1138
    'sessions'      => { label => 'Sessions & keys', caps => [] },
    'domains'       => { label => 'Domains',         caps => ['manage_domains'] },
    'cache'         => { label => 'Cache',           caps => [] },
    'backups'       => { label => 'Backups',         caps => [] },
    'audit'         => { label => 'Audit log',       caps => ['audit'] },
    # SM579 phase 2: the operator's page for the destinations this site may
    # send to. manage_connectors, the capability that already gates every
    # connector action - writing a destination IS the authority here.
    'connectors' => { label => 'Connectors', caps => ['manage_connectors'] },
    # SM957: Handlers left the menu (reached from each form and from
    # Extensions), so it is not offered as a start page either - lint 116.
    # SM759: registry keys, as the conf lists them - a bare name matches nothing.
    'data' => { label => 'Data tables', caps => ['manage_data'], plugin => 'plugins/data.pl' },
    'stats' => { label => 'Visitor statistics', caps => [], plugin => 'plugins/stats.pl' },
);
# SM957: the menu's order.
my @PAGE_ORDER = qw(submissions files nav stats appearance plugins connectors data
    domains users groups address-lists sessions index cache backups audit);

sub manager_pages { return map { { id => $_, %{ $PAGES{$_} } } } @PAGE_ORDER }

# The fallback: the manager, with the signed-in user's own account sheet open.
# `start=unreachable` when a set start page could not be honoured, so the
# manager can say why they are here instead of where they asked to be.
sub fallback_landing {
    my (%o) = @_;
    my $url = '/manager/?account=1';
    $url .= '&start=unreachable' if $o{unreachable};
    return $url;
}

# --- the stored form --------------------------------------------------------

# `manager:<page>` or `domain:<host>|<path>` (host may be `(default)` for the
# primary). Returns a hashref, or undef with the reason in $_[1] if given.
sub parse_start_page {
    my ($value) = @_;
    return undef unless defined $value && length $value;
    if ( $value =~ /\Amanager:([a-z][a-z-]*)\z/ ) {
        my $page = $1;
        return { kind => 'manager', page => $page };
    }
    if ( $value =~ /\Adomain:([^|]+)\|(.*)\z/s ) {
        my ( $host, $path ) = ( $1, $2 );
        $path = q{/} unless length $path;
        return { kind => 'domain', host => $host, path => $path };
    }
    return undef;
}

sub _path_ok {
    my ($path) = @_;
    return 0 unless defined $path && length $path;
    return 0 if $path     =~ m{\A(?://|\\)};
    return 0 unless $path =~ m{\A/[\w/.\-~]*\z};
    return 0 if $path     =~ m{(?:\A|/)\.\.(?:/|\z)};
    return 1;
}

# --- what an account can reach -------------------------------------------------

sub _caps_for {
    my ($user) = @_;
    require Lazysite::Auth::Settings;
    no warnings 'once';
    local $Lazysite::Auth::Settings::AUTH_DIR = Lazysite::Paths::lazysite_dir($DOCROOT) . "/auth";
    return Lazysite::Auth::Settings::caps_for($user) || {};
}

sub _scopes_for {
    my ($user) = @_;
    require Lazysite::Auth::Settings;
    no warnings 'once';
    local $Lazysite::Auth::Settings::AUTH_DIR = Lazysite::Paths::lazysite_dir($DOCROOT) . "/auth";
    my @s = eval { Lazysite::Auth::Settings::resolve_user_scopes( $DOCROOT, $user ) };
    return @s;
}

sub _plugin_enabled {
    my ($script) = @_;
    require Lazysite::Manager::Plugins;
    no warnings 'once';
    local $Lazysite::Manager::Plugins::DOCROOT = $DOCROOT;
    return Lazysite::Manager::Plugins::plugin_enabled($script) ? 1 : 0;
}

sub _domains {
    require Lazysite::Manager::Domains;
    no warnings 'once';
    local $Lazysite::Manager::Domains::DOCROOT = $DOCROOT;
    my $r = eval { Lazysite::Manager::Domains::domains_list() };
    return ref $r eq 'HASH' ? @{ $r->{domains} || [] } : ();
}

sub _page_reachable {
    my ( $page, $caps ) = @_;
    my $p = $PAGES{$page} or return 0;
    return 0 unless $caps->{ui};
    return 0 if $p->{plugin} && !_plugin_enabled( $p->{plugin} );
    return 1 unless @{ $p->{caps} };
    return ( grep { $caps->{$_} } @{ $p->{caps} } ) ? 1 : 0;
}

sub _domain_reachable {
    my ( $host, $user ) = @_;
    my ($d) = grep { lc( $_->{host} // '' ) eq lc $host } _domains();
    return ( 0, "'$host' is not a domain this instance serves" ) unless $d;
    my @scopes = _scopes_for($user);
    return ( 1, $d ) unless @scopes;    # unbound: every domain
    my $cr = $d->{content_root} // '';
    require Lazysite::Manager::Common;
    return ( 0, "'$host' is outside the account's confinement" )
        if !length $cr
        || Lazysite::Manager::Common::outside_all_scopes( \@scopes, $cr );
    return ( 1, $d );
}

# SM774: does this path name a page on that domain, today? The same spellings
# the front end serves - `/x` is x.md (or x/index.md, or a legacy x.html,
# or a file as spelled), `/` is index.md - looked up through the private
# store first, as the front end does, so a gated page counts. Returns
# ( 1 ) or ( 0, why ).
sub _page_resolves {
    my ( $d, $path ) = @_;
    my $cr = $d->{content_root} // '';
    $cr =~ s{\A/+|/+\z}{}g;
    ( my $rel = $path ) =~ s{\A/+}{};
    my @cands;
    if ( !length $rel || $rel =~ m{/\z} ) { push @cands, "${rel}index.md", "${rel}index.html" }
    else { push @cands, "$rel.md", "$rel/index.md", "$rel.html", $rel }
    require Lazysite::Private;
    for my $c (@cands) {
        my $r = length $cr ? "$cr/$c" : $c;
        my ( $abs, $where ) = Lazysite::Private::resolve( $DOCROOT, $r );
        return 1 if $where && -f $abs;
    }
    my $host = $d->{is_primary} ? 'this site' : "'$d->{host}'";
    return ( 0, "no page at '$path' on $host - it may have been deleted or moved" );
}

# The dropdown, for ONE account, from that account's own grants.
sub start_page_choices {
    my ($user) = @_;
    my $caps   = _caps_for($user);
    my @pages  = map { { value => "manager:$_->{id}", label => $_->{label} } }
        grep { _page_reachable( $_->{id}, $caps ) } manager_pages();
    my @domains;
    for my $d ( _domains() ) {
        my $host = $d->{host} // '';
        next unless length $host;
        my ($ok) = _domain_reachable( $host, $user );
        next unless $ok;
        push @domains, {
            host => $host,
            label => $d->{is_primary} ? ( $d->{site_name} || 'this site' ) . ' (primary)' : $host,
        };
    }
    return { pages => \@pages, domains => \@domains };
}

# Refuse a start page the account cannot reach, at SET time. Returns the
# reason, or undef when it is fine. Empty clears and is always fine.
sub validate_start_page {
    my ( $user, $value ) = @_;
    return undef unless defined $value && length $value;
    my $p = parse_start_page($value)
        or return "a start page is 'manager:<page>' or 'domain:<host>|<path>' - got '$value'";
    if ( $p->{kind} eq 'manager' ) {
        return "'$p->{page}' is not a manager page a start page may name" unless $PAGES{ $p->{page} };
        return "'$user' cannot reach the manager page '$p->{page}' - it needs "
            . join( ' or ', @{ $PAGES{ $p->{page} }{caps} } )
            . ( $PAGES{ $p->{page} }{plugin} ? " (and the $PAGES{ $p->{page} }{plugin} plugin enabled)" : '' )
            unless _page_reachable( $p->{page}, _caps_for($user) );
        return undef;
    }
    return "the path '$p->{path}' is not a page path on this site (a leading slash, then letters, digits, / . - _)"
        unless _path_ok( $p->{path} );
    my ( $ok, $why ) = _domain_reachable( $p->{host}, $user );
    return $why unless $ok;
    my $d = $why;    # the domain row, on success
    ( $ok, $why ) = _page_resolves( $d, $p->{path} );
    return $why unless $ok;
    return undef;
}

# The users tool's `set USER start_page VALUE`: trims, validates against the
# account's own reach, stores or clears. Dies with the reason so the tool's
# caller sees it as every other setting's refusal; sets $DOCROOT for the call.
sub apply_start_page {
    my ( $all, $user, $value, $docroot ) = @_;
    local $DOCROOT = $docroot if defined $docroot && length $docroot;
    my $v = defined $value ? "$value" : '';
    $v =~ s/^\s+|\s+$//g;
    if ( !length $v ) { delete $all->{$user}{start_page}; return }
    my $why = validate_start_page( $user, $v );
    die "start_page refused: $why\n" if defined $why;
    $all->{$user}{start_page} = $v;
    return;
}

# The stored value, raw. settings-get returns the RESOLVED settings (grants),
# which is not where a preference lives; this reads the account's own record.
sub current_start_page {
    my ($user) = @_;
    require Lazysite::Auth::Settings;
    no warnings 'once';
    local $Lazysite::Auth::Settings::AUTH_DIR = Lazysite::Paths::lazysite_dir($DOCROOT) . "/auth";
    my $all = Lazysite::Auth::Settings::read_settings();
    return ( $all->{$user} || {} )->{start_page} // '';
}

# --- at sign-in -------------------------------------------------------------------

# Where this account lands when it signed in with no destination. Always
# returns { url => ... }; adds `unreachable => reason` when a set start page
# could not be honoured, and `set => 0` when none is set.
sub resolve_start_page {
    my ($user) = @_;
    require Lazysite::Auth::Settings;
    no warnings 'once';
    local $Lazysite::Auth::Settings::AUTH_DIR = Lazysite::Paths::lazysite_dir($DOCROOT) . "/auth";
    my $value = current_start_page($user);
    return { url => fallback_landing(), set => 0 } unless length $value;

    my $why = validate_start_page( $user, $value );
    return { url => fallback_landing( unreachable => 1 ), set => 1, unreachable => $why }
        if defined $why;

    my $p = parse_start_page($value);
    return { url => "/manager/$p->{page}", set => 1 } if $p->{kind} eq 'manager' && $p->{page} ne 'index';
    return { url => '/manager/', set => 1 } if $p->{kind} eq 'manager';

    my ( undef, $d ) = _domain_reachable( $p->{host}, $user );
    if ( $d->{is_primary} ) {
        return { url => $p->{path}, set => 1 };    # same host: a relative path
    }
    # ANOTHER HOST THIS INSTANCE SERVES. Absolute, so the browser changes
    # host; https because the instance's sites are. The host came from the
    # domains list, not from the caller - that is what makes this not an
    # open redirect.
    return { url => "https://$p->{host}$p->{path}", set => 1 };
}


# --- SM944 S23: the manager API's start-page actions, moved here from
# lazysite-manager-api.pl. Loaded anywhere the manager API has not set the
# request context, they refuse: the subject is nobody (t/unit/manager/205).
#
# SM724: the start page - read (the current value and the choices THIS account
# can reach) and set. Self-service for one's own account; another account's
# needs manage_users. The choices are computed from the TARGET's grants, never
# the caller's: an operator building the list from what they can see would
# offer pages the subject cannot open, which is a sign-in that lands on a 403.
sub _start_page_subject {
    my ($username) = @_;
    my $u = defined $username && length $username ? $username : $auth_user;
    $u =~ s/[^a-zA-Z0-9_.-]//g;
    # SM944 S23 (c), ruled 2026-10-09: no account, no subject. Outside a request
    # $auth_user is '' and this answered for account ''; so did a name that
    # sanitises to nothing, for a caller holding manage_users.
    return ( undef, { ok => 0, kind => 'forbidden',
            error => 'No account is named or signed in, so there is no start page to read or set.' } )
        unless length $u;
    return ( undef, { ok => 0, kind => 'forbidden',
            error => "Setting another account's start page needs the 'Users & groups' "
                . 'permission; you may set your own.' } )
        if $u ne $auth_user && !_user_caps($auth_user)->{manage_users};
    return ( $u, undef );
}

sub action_start_page {
    my ($username) = @_;
    my ( $u, $refused ) = _start_page_subject($username);
    return $refused if $refused;
    # In its own module: $DOCROOT is this package's, set by the dispatcher.
    my $current = Lazysite::Manager::StartPage::current_start_page($u);
    my $r       = Lazysite::Manager::StartPage::resolve_start_page($u);
    return {
        ok       => 1,
        username => $u,
        current  => $current,
        landing  => $r->{url},
        ( $r->{unreachable} ? ( unreachable => $r->{unreachable} ) : () ),
        choices  => Lazysite::Manager::StartPage::start_page_choices($u),
        fallback => Lazysite::Manager::StartPage::fallback_landing(),
    };
}

# SM944 S33 (ruled 2026-10-11, "Yes, S33a then groups"): start-page-set's
# dispatch branch, moved here from lazysite-manager-api.pl with its statements
# unchanged. It reads the request's body from Manager::Common's context
# (_json_body, S33a); action_start_page_set below refuses an empty subject.
sub dispatch_start_page_set {
    my $result;
    my $req = _json_body();
    # SM781: A MISSING VALUE IS NOT A CLEAR. The field sent the setting under
    # another key, got ok:1, and found the start page silently cleared - an
    # absent `value` read as an empty one. Clearing is `"value": ""`, said.
    $result = exists $req->{value}
        ? action_start_page_set( $req->{username}, $req->{value} )
        : { ok => 0, error => 'value is required (send it in the JSON body; an empty string clears the start page)' };
    return $result;
}

sub action_start_page_set {
    my ( $username, $value )   = @_;
    my ( $u,        $refused ) = _start_page_subject($username);
    return $refused if $refused;
    my $r = users_api( {
            action   => 'settings-set',
            username => $u,
            key      => 'start_page',
            value    => ( $value // '' ),
            actor    => $auth_user,
    } );
    return $r unless ref $r eq 'HASH' && $r->{ok};
    return { ok => 1, username => $u, start_page => ( $value // '' ) };
}

1;
