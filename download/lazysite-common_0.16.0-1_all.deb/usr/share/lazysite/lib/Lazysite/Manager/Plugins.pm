package Lazysite::Manager::Plugins;

# SM079: manager plugin, handler-config and form-target handlers. Plugins are
# probed and run via `qx($^X <plugin> --describe/--scan)`. Context ($DOCROOT,
# $action for log attribution) is set by the dispatcher.

use strict;
use warnings;
use JSON::PP                  qw(encode_json decode_json);
use File::Basename            qw(dirname);
use File::Path                qw(make_path);
use Cwd                       qw(realpath);
use Digest::SHA               qw(sha256_hex);
use Encode                    ();
use Lazysite::Util            qw(log_event);
use Lazysite::Manager::Common qw(write_file_checked);
use Exporter 'import';
use Lazysite::Paths ();

our @EXPORT_OK = qw(
    action_plugin_list action_plugin_enable action_plugin_disable
    action_plugin_read action_plugin_save action_plugin_action
    action_form_list dispatch_form_list
    action_form_delete
    action_form_submissions action_form_submission
    action_form_submission_delete action_form_submission_confirm
    action_form_submissions_delete_bulk
    action_form_submission_approve account_request_store
    resolve_plugin_script plugin_enabled
);

our $DOCROOT;

# SM293: this site's engine tree - beside the docroot once migrated,
# inside it before. Asked, never computed, so both layouts work on one
# code path and a site migrates by moving the directory.
sub _lz { return Lazysite::Paths::lazysite_dir($DOCROOT) }
our $action = '';

# SM255 (completion): every write to lazysite.conf goes through Common's single
# writer, which locks, writes atomically and records the change. This module
# used to write the file twice by hand - once for the plugins: block (no commit)
# and once for a Site-settings save (its own commit) - which is the same
# one-file-two-mechanisms split SM255 set out to remove, in the one module the
# original change missed.
#
# Each manager module carries its own $DOCROOT and the dispatcher sets it per
# request, so the shared writer must be pointed at ours for the duration of the
# write or it looks in the wrong docroot.
sub _write_conf_content {
    my ( $content, $message ) = @_;
    no warnings 'once';
    local $Lazysite::Manager::Common::DOCROOT = $DOCROOT;
    return Lazysite::Manager::Common::write_conf_content( $content, $message );
}

# === moved from lazysite-manager-api.pl (SM079a) ===

# SM152: the plugin registry - the canonical, authoritative enumeration of the
# scripts the manager may probe/run. Keys are the stable plugin identifiers
# ("plugins/<name>.pl", plus the two core descriptor scripts); values are the
# resolved absolute paths. This is the ONLY place a plugin identity maps to a
# filesystem path, and it is built by SCANNING the known locations - never from
# request input. A request names a plugin by its registry KEY; the key is looked
# up here. This is both the security boundary (SEC-2026-07: the old resolver
# interpolated the request `script` straight into a path with only a `-f` check,
# so `plugin-action {script:"../../x.pl"}` or `{script:"content/x.md"}` executed
# an arbitrary on-disk file as Perl via qx($^X ...) - authenticated RCE) and the
# canonical source of plugin data for the manager UI.
sub plugin_registry {
    my $base = Cwd::realpath("$DOCROOT/..");
    my %reg;
    return \%reg unless defined $base;

    # Core descriptor scripts: at the install root, or under cgi-bin/ on a
    # real deployment. They publish config schemas (the site config page).
    for my $core (qw(lazysite-processor.pl lazysite-auth.pl)) {
        for my $cand ( "$base/$core", "$base/cgi-bin/$core" ) {
            if ( -f $cand && -r $cand ) { $reg{$core} = $cand; last }
        }
    }

    # Installed plugins: plugins/<name>.pl. Name restricted to a plain filename
    # (no path separators), so a symlink/entry cannot smuggle a traversal key.
    if ( opendir my $pd, "$base/plugins" ) {
        for my $f ( sort grep { /\A[A-Za-z0-9_.-]+\.pl\z/ } readdir $pd ) {
            my $p = "$base/plugins/$f";
            $reg{"plugins/$f"} = $p if -f $p && -r $p && !-l $p;
        }
        closedir $pd;
    }
    return \%reg;
}

# SM409: the plugins: list in lazysite.conf, as a map. This parse used to
# live inline in action_plugin_list, where its only consumer was the LISTING -
# which is precisely how "disabled" came to mean a display state rather than a
# fact: nothing on any execution path ever read it.
sub _enabled_map {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my %enabled;
    my $conf_path = _lz() . "/lazysite.conf";
    if ( open my $fh, '<:utf8', $conf_path ) {
        my $in_plugins = 0;
        while (<$fh>) {
            chomp;
            # SM817: `extensions:` is the name, `plugins:` is the old one,
            # and a site keeps whichever it has. Both open the SAME list -
            # there is one registry, spelled two ways, so a site cannot end
            # up with two lists that disagree about what is enabled.
            if (/^(?:extensions|plugins)\s*:\s*$/) { $in_plugins = 1; next }
            if ( $in_plugins && /^\s+-\s+(.+)$/ ) {
                my $entry = $1;
                $entry =~ s/\s+$//;
                $enabled{$entry} = 1;
            }
            elsif ( $in_plugins && !/^\s/ ) { $in_plugins = 0 }
        }
        close $fh;
    }
    return \%enabled;
}

sub plugin_enabled { return _enabled_map()->{ $_[0] } ? 1 : 0 }

# SM409 / ADR 0009: DISABLED MEANS OFF - for plugins that opt into the
# contract. A descriptor that declares `contract` is gated: it EXECUTES only
# when its script appears in the plugins: list, and it defaults to disabled,
# because a contract plugin is born with the off switch (the data plugin is
# the first). A legacy descriptor (no `contract` key) is untouched: existing
# plugins keep running exactly as they always have, until each one's
# migration SM enables it explicitly to replicate its current effective
# state - the release manager's ruling, so that nothing in the field changes
# behaviour on upgrade.
#
# The gate refuses EXECUTION (actions, hooks). Config read/save stay open on
# a disabled plugin, deliberately: an operator must be able to configure a
# plugin before enabling it, and the enable flow itself is a config surface.
#
# SM765: A READ ANSWERS WHILE THE PLUGIN IS OFF. An action the descriptor
# marks `read: 1` runs on a disabled contract plugin, because "what is the
# runtime doing?" is a question an operator asks AFTER switching it off - when
# they come back, when a colleague asks, when something else looks wrong an
# hour later - and the only route to it then is the Status button, which
# answered "this plugin is disabled" and nothing else. The disable hook had
# already computed and shown the whole state seconds earlier; the same
# question through the same action a minute later was refused. Config read
# and save were open while disabled for the same reason since SM409: the
# gate exists to stop a disabled plugin DOING anything, and a read does not.
# A read that changes anything is a lie, and t/unit/manager/62 holds that a
# read on a disabled plugin leaves no witness.
#
# Returns undef when the plugin may run, or the refusal hash when it may not.
sub _gate_execution {
    my ( $script, $desc, $action ) = @_;
    return undef unless ref $desc eq 'HASH' && $desc->{contract};
    return undef if plugin_enabled($script);
    return undef if ref $action eq 'HASH' && $action->{read};
    log_event( 'WARN', 'plugin-gate', 'disabled plugin refused execution',
        plugin => $script );
    return { ok => 0,
        error => 'This plugin is disabled. A sysop can enable it on the '
            . 'Extensions page.' };
}

# Resolve a request-named plugin to its absolute path via the registry ONLY.
# An exact key match returns the canonical path; anything else (a traversal
# path, an arbitrary file, an unregistered name) returns undef and the caller
# reports "unknown plugin" - it never runs.
sub resolve_plugin_script {
    my ($script) = @_;
    return unless defined $script && length $script;
    return plugin_registry()->{$script};
}

# SM809: THE THREE PLUGIN ACTIONS TOOK A `plugin` PARAMETER AND IGNORED IT.
#
# Each declares `plugin` (query) and `script` (body), each received the first
# as $plugin_id, and each resolved on $script alone - so a caller who sent the
# parameter the declaration names got "Plugin not found", a sentence about the
# PLUGIN when the fault was the parameter. The field spent nine steps on it,
# one of them reading the manager UI's own JavaScript to learn the real
# contract, and reasonably concluded the plugin did not exist.
#
# Both spellings resolve now, and the refusal names what was missing and where
# it goes - the same shape SM773 gave the declared parameters, said by hand
# because this is an either/or that the declaration table cannot express.
sub _resolve_plugin_or_why {
    my ( $plugin_id, $script ) = @_;
    for my $cand ( $script, $plugin_id ) {
        next unless defined $cand && length $cand;
        my $full = resolve_plugin_script($cand);
        return ( $full, '' ) if $full;
    }

    # SM832: THE LISTING'S `id` IS NOW A KEY THE READER ACCEPTS. SM809 made the
    # `plugin` parameter reach this resolver, but the registry is keyed by script
    # path, so the value plugin-list labels `id` still missed - and the refusal
    # sent the caller back to plugin-list, whose `id` was the value just refused.
    # The field followed the error message literally and went round in a circle.
    #
    # NOT BY FILENAME. `plugins/<id>.pl` is right for twelve of the fourteen and
    # wrong for two - audit.pl publishes `link-audit` and log.pl publishes
    # `logging` - so the stem is only ever a GUESS, and it is confirmed against
    # the id the plugin itself declares before it is used. A guess that is not
    # confirmed falls through to asking every plugin, which is the slow path and
    # only runs when a caller has sent an id that is not also a filename.
    # SM839: FOR EITHER NAME THE CALLER USED. SM832 ran this for the `plugin`
    # parameter only, so plugin-save's body `script` - the route the missing-
    # argument error below advertises - still refused an id, and its refusal
    # told the caller to pass the id. It showed only for an extension whose id
    # is not its filename: link-audit, whose script is audit.pl.
    my $reg;
    for my $want ( grep { defined && /\A[A-Za-z0-9_.-]+\z/ } ( $script, $plugin_id ) ) {
        $reg //= plugin_registry();
        my $guess = "plugins/$want.pl";
        if ( my $full = $reg->{$guess} ) {
            my $desc = _describe($full);
            return ( $full, '' )
                if ref $desc eq 'HASH' && ( $desc->{id} // '' ) eq $want;
        }
        for my $rel ( sort keys %$reg ) {
            next if $rel eq $guess;
            my $desc = _describe( $reg->{$rel} );
            return ( $reg->{$rel}, '' )
                if ref $desc eq 'HASH' && ( $desc->{id} // '' ) eq $want;
        }
    }
    my $named = join ' or ', grep { defined && length } ( $script, $plugin_id );
    return ( undef,
        length $named
        ? "no extension '$named' is installed - call extension-list and pass an extension's `id` or its `_script`"
        : 'an extension is required (in the query string as ?plugin=<id>, or in the '
            . 'JSON body as {"script": "<id>"}); call extension-list for the ids' );
}

# SM1153 (oom-lab L-5): WHAT THE CACHED LIST WAS BUILT FROM. The list was
# trusted for 60 seconds on the cache file's age alone, so a set-up that listed
# extensions, then created the extensions directory, was told there were none
# until the cache was deleted by hand. This is the state of the registry's
# sources - the directory's presence and mtime, and each script's name, size and
# mtime - and the cache is used only while it is unchanged.
sub _plugin_list_state {
    my ($reg) = @_;
    my $base  = Cwd::realpath("$DOCROOT/..") // '';
    my @dir   = stat("$base/plugins");
    my @bits  = ( @dir ? "dir:$dir[9]" : 'dir:none' );
    for my $rel ( sort keys %{$reg} ) {
        my @st = stat( $reg->{$rel} );
        push @bits, join( ':', $rel, $st[7] // '-', $st[9] // '-' );
    }
    return join '|', @bits;
}

sub action_plugin_list {
    my $cache_file = _lz() . "/cache/plugin-list.cache";
    my $reg        = plugin_registry();
    my $state      = _plugin_list_state($reg);
    if ( -f $cache_file && ( time() - ( stat($cache_file) )[9] ) < 60 ) {
        open my $fh, '<', $cache_file or return { ok => 0, error => "cache read failed" };
        my $data   = do { local $/; <$fh> }; close $fh;
        my $parsed = eval { decode_json($data) };
        if ( $parsed && $parsed->{ok} && ( $parsed->{state} // '' ) eq $state ) {
            delete $parsed->{state};
            return $parsed;
        }
    }

    my %enabled = %{ _enabled_map() };

    # D022: plugins moved to plugins/ with the lazysite- prefix
    # dropped. lazysite-processor.pl and lazysite-auth.pl stay at
    # repo root (core) but expose --describe and are plugins in
    # the manager-UI sense — the site config page at config.md
    # drives its form from the processor's descriptor rather than
    # duplicating the schema. Every shipped plugin answers
    # --describe (payment-demo included, marked demo:true).
    my @plugins;

    # SM152: the registry is the single canonical enumeration - core descriptor
    # scripts + plugins/*.pl, each mapped to its resolved absolute path. Every
    # candidate is still validated by --describe below (a non-plugin .pl is
    # dropped); a new plugins/*.pl appears automatically. This is the same map
    # resolve_plugin_script uses, so what is LISTED is exactly what can be RUN.
    # ($reg is built above, with the state the cache is checked against.)

    for my $rel ( sort keys %$reg ) {
        my $full = $reg->{$rel};
        next unless -f $full && -r $full;

        # A PLUGIN THAT OVERRUNS IS DROPPED, AND IT USED TO BE DROPPED IN
        # SILENCE. `next if $@` removed it from the Plugin Manager with nothing
        # written anywhere - so on a loaded host a sysop watches a plugin
        # disappear from the list and has no way at all to find out why. Two
        # seconds is a generous budget for a --describe and a mean one for a
        # host under load.
        #
        # THE BUDGET SCALES UNDER MEASUREMENT. Devel::Cover makes every
        # subprocess start far slower than two seconds, so an instrumented run
        # dropped lazysite-processor.pl from its own plugin list - the
        # instrument changing the thing it measures, exactly as the tempdir
        # instrumentation did. It is the same principle: measurement must not
        # alter behaviour.
        my $budget
            = ( $INC{'Devel/Cover.pm'}
                || ( $ENV{PERL5OPT} // '' ) =~ /Devel::Cover/ ) ? 30 : 2;

        local $SIG{ALRM} = sub { die "timeout\n" };
        alarm($budget);
        my $json = eval { _describe_json($full) };
        alarm(0);
        if ( $@ || !$json ) {
            log_event( 'WARN', 'plugin-list',
                'a plugin did not describe itself in time and is not listed',
                plugin => $rel,
                why    => ( $@ ? "no answer within ${budget}s" : 'empty answer' ) );
            next;
        }

        my $desc = eval { decode_json($json) };
        next unless $desc && ref $desc eq 'HASH' && $desc->{id};
        # A plugin may mark itself unlisted (e.g. the payment demo helper): it
        # ships and works, but is not a user-facing toggle in the Plugin Manager.
        next if $desc->{unlisted};

        $desc->{_script}  = $rel;
        $desc->{_enabled} = $enabled{$rel} ? JSON::PP::true : JSON::PP::false;

        push @plugins, $desc;
    }

    @plugins = sort {
        ( $b->{_enabled} ? 1 : 0 ) <=> ( $a->{_enabled} ? 1 : 0 )
            || ( $a->{name} // '' ) cmp( $b->{name} // '' )
    } @plugins;

    # SM1153: NOTHING IS KEPT FOR A DIRECTORY THAT IS NOT THERE. An empty list
    # built because plugins/ does not exist yet is the list the lab was handed
    # for good; it answers this request and no later one.
    my $base      = Cwd::realpath("$DOCROOT/..") // '';
    my $cache_dir = dirname($cache_file);
    if ( -d "$base/plugins" ) {
        make_path($cache_dir) unless -d $cache_dir;
        if ( open my $fh, '>', $cache_file ) {
            print $fh encode_json( { ok => 1, state => $state, plugins => \@plugins } );
            close $fh;
        }
    }
    else {
        unlink $cache_file;
    }

    return { ok => 1, plugins => \@plugins };
}

# SM152/ADR 0009: the ONE way this module asks a plugin to describe itself.
# The path is always a registry value (resolve_plugin_script or the registry
# scan), never request text. Deliberately UNGATED - a descriptor is metadata,
# and _run_plugin_hook reads it on the disable path - and deliberately carrying
# no timeout of its own: action_plugin_list is the caller that budgets the
# probe, and it wraps this call in its own alarm so an overrun still dies there.
sub _describe_json {
    my ($full) = @_;
    my $out = qx($^X \Q$full\E --describe 2>/dev/null);
    return $out;
}

# The decoded descriptor, or undef when the script said nothing or said
# something that is not JSON. Returns exactly what decode_json returned, so a
# caller may test it as it always has.
sub _describe {
    my ($full) = @_;
    return eval { decode_json( _describe_json($full) ) };
}

# SM472: the declared modules this plugin cannot run without, that are absent.
#
# Reads the plugin's OWN declaration (ADR 0009 `owns.deps`) rather than a list
# kept here - a list here would be a second opinion about the same fact, and
# would go stale the first time a plugin gained a dependency.
#
# Returns a message naming what is missing, or undef.
# Is a command available and executable?
#
# PATH is read from the environment the CGI actually runs under, with a
# conservative fallback: a plugin check must not conclude "installed" because a
# login shell would have found it while the web server would not.
#
# No shell is involved. The caller checks the name against a strict pattern and
# this joins it to a directory, so nothing here reaches a command line.
sub _bin_on_path {
    my ($bin) = @_;
    return 0 unless defined $bin && length $bin;
    my $path = $ENV{PATH} // '/usr/local/bin:/usr/bin:/bin';
    for my $dir ( split /:/, $path ) {
        next unless length $dir;
        return 1 if -x "$dir/$bin" && !-d _;
    }
    return 0;
}

sub _missing_deps {
    my ( $script, $full, $desc ) = @_;
    # TLO-1: the caller may already hold the resolved path and the descriptor.
    # Counted, not tested for truth, so an undef descriptor passed in is not
    # quietly fetched again.
    $full = resolve_plugin_script($script) if @_ < 2;
    return undef unless $full;
    $desc = _describe($full) if @_ < 3;
    return undef unless ref $desc eq 'HASH' && ref $desc->{owns} eq 'HASH';

    my @deps = @{ $desc->{owns}{deps} || [] };

    # SM694: A PLUGIN MAY DEPEND ON A PROGRAM, NOT ONLY A MODULE.
    #
    # `deps` is checked by `require`, which answers for Perl modules and
    # nothing else. A plugin wrapping an external tool - pandoc, and whatever
    # follows it - had no way to declare what it needs, so SM472's rule ("a
    # plugin that cannot run is not enabled") could not protect it: the
    # operator would get a plugin that enables and then fails at first use,
    # which is the exact state SM472 exists to prevent.
    #
    # `bins` is that declaration for an executable. Same refusal, same shape of
    # message, same Debian hint - an operator should not have to learn a second
    # idiom because the missing thing happens to be a binary.
    my @bins = @{ $desc->{owns}{bins} || [] };
    return undef unless @deps || @bins;

    my ( @absent, @bare );
    require Lazysite::Plugins::Owns;
    for my $dep (@deps) {
        # SM747: an entry may name its package and an oldest version - the
        # grammar is Owns::parse_dep's, so the validator and this check read a
        # declaration the same way. A name the grammar refuses is skipped here
        # exactly as an unpatterned one always was: never interpolated.
        my ( $m, $pkg, $min ) = Lazysite::Plugins::Owns::parse_dep($dep);
        next unless defined $m && $m =~ /\A[A-Za-z][\w:]*\z/;   # never interpolate a name
        ( my $file  = "$m.pm" ) =~ s{::}{/}g;
        ( my $guess = lc $m )   =~ s{::}{-}g;
        my $install = defined $pkg ? "$pkg (>= $min)" : "lib$guess-perl";
        if ( eval { require $file; 1 } ) {
            # PRESENT AND TOO OLD is missing too: a module that loads and lacks
            # what the plugin calls fails at first use, the state SM472 refuses.
            next unless defined $min;
            next if eval { $m->VERSION($min); 1 };
            my $have = eval { $m->VERSION } // 'unversioned';
            push @absent, "$m $min or newer - this host has $have (Debian: $install)";
            push @bare,   $m;
            next;
        }
        push @absent, "$m (Debian: $install)";
        push @bare,   $m;
    }

    for my $b (@bins) {
        # A bare command name only - never a path, never a shell metacharacter.
        # This value comes from a plugin descriptor, and a lookup that
        # interpolated it would let a descriptor decide what gets executed.
        # The module branch guards its names for the same reason.
        next unless $b =~ /\A[A-Za-z0-9][A-Za-z0-9._-]*\z/;
        next if _bin_on_path($b);
        push @absent, "$b (a program, not a Perl module - Debian: $b)";
        push @bare,   $b;
    }

    return undef unless @absent;

    my $msg
        = 'This plugin needs '
        . join( ', ', @absent )
        . ' and they are not installed. It would enable and then fail on every '
        . 'request that used them, so it has been left off - install them and '
        . 'enable it again.';

    # SM711 half 2: the BARE NAMES come back alongside the prose.
    #
    # The audit row for a refused toggle said `plugin-enable / pandoc / fail`
    # with no reason - or, once a kind existed, `missing_deps`, which names the
    # CLASS of problem and not the thing that is missing. The release manager's
    # complaint was exactly that: "the logged error doesn't say which dep is
    # missing". The banner beside it carried the full explanation, so the
    # information existed and only the record lacked it.
    #
    # The prose cannot be reused for the trail: it is three sentences with
    # install advice in the middle, which is right for a person reading a
    # banner and wrong for a column an auditor scans. So the names travel
    # separately rather than being parsed back out of the sentence they were
    # formatted into.
    return ( $msg, \@bare );
}

sub action_plugin_enable {
    my ($script) = @_;
    $script =~ s/[^a-zA-Z0-9_.\/\-]//g;
    return { ok => 0, error => 'No script' } unless $script;
    # SM152: only a REGISTERED plugin can be enabled - so a stray name can never
    # be written into the conf `plugins:` list (and the on_enable hook only ever
    # runs a registry script).
    #
    # TLO-1: the registry is still SCANNED on this call - what it yields is
    # carried down to _missing_deps and _run_plugin_hook instead of being
    # looked up twice more. It is NOT cached across calls, which is the
    # property t/unit/manager/27 pins.
    my $full = plugin_registry()->{$script};
    return { ok => 0, error => "Unknown plugin: $script" } unless $full;

    # SM472: A PLUGIN THAT CANNOT RUN IS NOT ENABLED.
    #
    # ADR 0009 has a plugin DECLARE the modules it needs, and the SBOM gate
    # reads that list so nothing ships undeclared. Nothing was reading it at
    # the one moment it answers a question an operator has: can this work here?
    #
    # It was found the expensive way. The data plugin enabled cleanly on a host
    # without YAML::PP, listed its (empty) set of tables happily, and then
    # answered HTTP 500 to every attempt to declare one - because the parser is
    # only reached once there is something to parse. The field bisected five
    # variations of the request before concluding the write path was broken.
    # Every signal was honest and none of them said the word "YAML::PP".
    #
    # REFUSED RATHER THAN WARNED, because the alternative is a plugin that is
    # on and does not work - which is the state that produced those 500s. The
    # message names the module AND a package that provides it, so the refusal
    # is a next step rather than a dead end; install, then enable, which is the
    # right order anyway.
    #
    # ONE --describe for the whole action. The descriptor is read before the
    # conf gains the entry, and the hook below reads the same one: --describe
    # is run with no --docroot (see _describe_json), so a descriptor cannot
    # depend on this site's lazysite.conf and the write between them is
    # invisible to it.
    my $desc = _describe($full);
    my ( $missing, $absent ) = _missing_deps( $script, $full, $desc );
    if ($missing) {
        # SM711 half 2: `audit_detail` is the short, scannable form for the
        # trail. `error` stays the operator's sentence, because a banner and an
        # audit column want different things - and deriving one from the other
        # would mean parsing prose we had just finished formatting.
        return {
            ok           => 0,
            kind         => 'missing_deps',
            error        => $missing,
            audit_detail => 'missing_deps: ' . join( ', ', @{ $absent || [] } ),
        };
    }

    my $r = _update_plugins_conf( $script, 'add' );
    return $r unless $r->{ok};
    my $hook = _run_plugin_hook( $script, 'on_enable', $full, $desc );
    $r->{hook} = $hook if $hook;
    return $r;
}

sub action_plugin_disable {
    my ($script) = @_;
    $script =~ s/[^a-zA-Z0-9_.\/\-]//g;
    return { ok => 0, error => 'No script' } unless $script;
    my $r = _update_plugins_conf( $script, 'remove' );
    return $r unless $r->{ok};
    my $hook = _run_plugin_hook( $script, 'on_disable' );
    $r->{hook} = $hook if $hook;
    return $r;
}

# Field feedback (2026-07-11): enabling a plugin IS enabling its feature - a
# second Enable on the config page is a trap. A plugin may declare on_enable /
# on_disable in its descriptor (each names one of its own declared actions);
# the named action runs right after the Plugin-Manager toggle and its result
# travels back as `hook` for the page's status line. Hook ids resolve against
# the descriptor's actions, so - exactly as in action_plugin_action - only
# descriptor literals ever reach the command line. A failed hook never undoes
# the toggle: the plugin's own status action is the recovery surface.
sub _run_plugin_hook {
    my ( $script, $hook_key, $full_script, $desc ) = @_;
    # TLO-1: as _missing_deps - the enable path resolves and describes once and
    # hands both down; disable calls with two arguments and does its own.
    $full_script = resolve_plugin_script($script) if @_ < 3;
    return undef unless $full_script;
    $desc = _describe($full_script) if @_ < 4;
    return undef unless $desc && ref $desc eq 'HASH';

    # SM409: hooks are deliberately NOT gated. They run only from the toggle
    # actions themselves - on_enable right after the conf gains the entry (so
    # the plugin is enabled by then), and on_disable right after the conf
    # loses it, which is the plugin's SANCTIONED last run: its one chance to
    # stop what it started. Gating here would refuse exactly that cleanup.
    # Arbitrary execution goes through action_plugin_action, which is gated.
    my $id = $desc->{$hook_key};
    return undef unless defined $id && length $id;
    my ($action) = grep { ( $_->{id} // '' ) eq $id } @{ $desc->{actions} // [] };
    return { ok => 0, error => "$hook_key names an undeclared action '$id'" }
        unless $action && ( $action->{run} // '' ) eq 'action';
    local $ENV{LAZYSITE_ACTING_USER} = $Lazysite::Manager::Common::auth_user // '';
    my $args   = join ' ', map { quotemeta } ( '--action', $id );
    my $output = qx($^X \Q$full_script\E $args --docroot \Q$DOCROOT\E);
    return eval { decode_json($output) }
        // { ok => 0, error => 'hook produced no output' };
}

sub _update_plugins_conf {
    my ( $script, $op ) = @_;

    my $conf_path = _lz() . "/lazysite.conf";
    open my $fh, '<:utf8', $conf_path
        or return { ok => 0, error => "Cannot read lazysite.conf" };
    my $conf = do { local $/; <$fh> };
    close $fh;

    my @lines = split /\n/, $conf;
    my @plugins;
    my $in_plugins  = 0;
    my $found_block = 0;
    my @before;
    my @after;
    my $phase = 'before';

    # SM915: this matched `plugins:` ALONE, and SM817 had renamed the list to
    # `extensions:` saying both spellings open the same one - "a site cannot end
    # up with two lists that disagree about what is enabled". On a site that
    # adopted the new name the header and all its entries fell through to
    # @before, @plugins came out empty, and the rebuild below emitted a SECOND
    # list under the old spelling carrying only the script just added. Enabling
    # one extension gave the conf two lists; disabling one removed nothing from
    # a list it could not see and reported ok. Reproduced in tmp/sm915-repro.pl
    # before this fix: enable -> 2 lists, disable -> ok=1 and nothing removed.
    #
    # %headers_seen records the SPELLING, not just that a block exists, because
    # the rebuild has to write back the one the site already uses.
    my %headers_seen;
    for my $line (@lines) {
        if ( $line =~ /^(extensions|plugins)\s*:\s*$/ ) {
            $headers_seen{$1} = 1;
            $in_plugins       = 1;
            $found_block      = 1;
            $phase            = 'plugins';
            next;
        }
        if ($in_plugins) {
            if ( $line =~ /^\s+-\s+(.+)$/ ) {
                my $entry = $1;
                $entry =~ s/\s+$//;
                push @plugins, $entry;
                next;
            }
            elsif ( $line !~ /^\s/ ) {
                $in_plugins = 0;
                $phase      = 'after';
            }
            else { next }
        }
        if    ( $phase eq 'before' ) { push @before, $line }
        elsif ( $phase eq 'after' )  { push @after,  $line }
    }

    # SM915, RULED 2026-09-29: refuse when BOTH spellings are present, naming the
    # file. A conf in that state is what the defect above produced, and its two
    # lists disagree - the reader at plugin_enabled() merges them and sees
    # everything, while the others see one block and read the rest as disabled.
    # Merging them here would edit a list the operator did not ask to be edited
    # in this call, which is the same shape as the defect; leaving it alone keeps
    # a damaged conf damaged and silent, which is the state that was reported. So
    # it is handed back to be fixed deliberately, and the message says how.
    if ( keys %headers_seen > 1 ) {
        return {
            ok    => 0,
            error => "$conf_path carries both an `extensions:` and a `plugins:` "
                . 'list. They are one registry spelled two ways, so two blocks '
                . 'disagree about what is enabled. Merge them by hand into the '
                . 'one this site uses - keep `extensions:`, the current name - '
                . 'and then enable or disable again.',
        };
    }

    if ( $op eq 'add' ) {
        push @plugins, $script unless grep { $_ eq $script } @plugins;
    }
    elsif ( $op eq 'remove' ) {
        @plugins = grep { $_ ne $script } @plugins;
    }

    # Rebuild line-wise. (The old string concatenation lost the newline
    # between the last before-line and the first after-line whenever the
    # plugins block emptied - removing a site's only plugin glued two conf
    # keys into one corrupt line.)
    my @out = @before;
    if (@plugins) {
        # SM915: write back the header THIS SITE USES, which is the ruling - not
        # a hardcoded `plugins:`. Exactly one spelling can be in %headers_seen by
        # here, because two were refused above. A conf with no list at all gets
        # `extensions:`, the name SM817 introduced, rather than reviving the old
        # one on a site that never had it.
        my ($header) = keys %headers_seen;
        push @out, ( $header // 'extensions' ) . ':', map { "  - $_" } @plugins;
    }
    push @out, @after;
    my $new_conf = join( "\n", @out );
    $new_conf =~ s/\n{3,}/\n\n/g;
    $new_conf .= "\n" unless $new_conf =~ /\n$/;

    my ( $wok, $werr ) = _write_conf_content( $new_conf,
        ( $op eq 'add' ? "enable plugin $script" : "disable plugin $script" ) );
    return { ok => 0, error => "Cannot write lazysite.conf: $werr" }
        unless $wok;

    unlink _lz() . "/cache/plugin-list.cache";

    return { ok => 1, action => $op, script => $script };
}

# The one `key: value` reader this module uses. Comments and blank lines are
# dropped; every remaining line is split on its first colon. Returns EVERY pair
# the file carries - which keys are wanted, and whether a key with no value
# counts, is the caller's question and the two callers answer it differently.
sub _read_kv_lines {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my ($path) = @_;
    my %kv;
    if ( -f $path and open my $fh, '<:utf8', $path ) {
        while (<$fh>) {
            chomp;
            s/^\s+|\s+$//g;
            next if /^#/ || !length;
            my ( $k, $v ) = split /\s*:\s*/, $_, 2;
            $kv{$k} = $v if defined $k;
        }
        close $fh;
    }
    return \%kv;
}

# The whole file, or '' when there is no file to read. A file that exists and is
# empty reads as undef, exactly as the hand-written slurps it replaces did.
sub _slurp_or_empty {
    my ($path) = @_;
    my $content = '';
    if ( -f $path and open my $fh, '<:utf8', $path ) {
        $content = do { local $/; <$fh> };
        close $fh;
    }
    return $content;
}

sub action_plugin_read {
    local $_;    # SM420: while(<>) assigns the GLOBAL $_
    my ( $plugin_id, $script ) = @_;

    my ( $full_script, $why ) = _resolve_plugin_or_why( $plugin_id, $script );
    return { ok => 0, kind => 'invalid', field => 'plugin', error => $why }
        unless $full_script;

    my $desc = _describe($full_script)
        or return { ok => 0, error => 'Cannot describe plugin' };

    my $config_file = $desc->{config_file} // '';
    my %values;

    if ($config_file) {
        my $kv = _read_kv_lines("$DOCROOT/$config_file");
        for my $k ( keys %$kv ) {
            $values{$k} = $kv->{$k} if defined $kv->{$k};
        }
    }
    elsif ( $desc->{config_keys} ) {
        my %want = map { $_ => 1 } @{ $desc->{config_keys} };
        my $kv   = _read_kv_lines( _lz() . "/lazysite.conf" );
        for my $k ( keys %$kv ) {
            $values{$k} = $kv->{$k} if $want{$k};
        }
    }

    # Never return password fields
    for my $field ( @{ $desc->{config_schema} // [] } ) {
        delete $values{ $field->{key} } if ( $field->{type} // '' ) eq 'password';
    }

    return { ok => 1, values => \%values };
}

sub action_plugin_save {
    my ( $plugin_id, $script, $values, $add ) = @_;

    my ( $full_script, $why ) = _resolve_plugin_or_why( $plugin_id, $script );
    return { ok => 0, kind => 'invalid', field => 'plugin', error => $why }
        unless $full_script;

    my $desc = _describe($full_script)
        or return { ok => 0, error => 'Cannot describe plugin' };

    my %allowed     = map { $_->{key} => 1 } @{ $desc->{config_schema} // [] };
    my %is_password = map { $_->{key} => 1 }
        grep { ( $_->{type} // '' ) eq 'password' } @{ $desc->{config_schema} // [] };
    my %is_email = map { $_->{key} => 1 }
        grep { ( $_->{type} // '' ) eq 'email' } @{ $desc->{config_schema} // [] };
    my %safe;
    for my $k ( keys %$values ) {
        next unless $allowed{$k};

        # SM1108 (0.15.7 test plan U5): A BLANK PASSWORD IS "UNCHANGED", not
        # "clear it".
        #
        # The manager never sends a stored password back, so a form saved with
        # the field untouched posts it empty - and the field's own note says
        # "Leave blank to keep the current one". The save wrote `password: ` over
        # the stored value, reported it in `changed`, and the next send failed
        # "SMTP auth failed". Every extension with a `type: password` field read
        # the same way, so the rule is here and not in the one extension. There
        # is no explicit "clear it" (the form never offered one); a password is
        # removed by editing the extension's config file.
        next if $is_password{$k} && defined $values->{$k} && !ref $values->{$k} && $values->{$k} !~ /\S/;

        # SM838: A VALUE IS ONE LINE, and a line break in one is refused.
        #
        # Every value below is written as `key: value` on a line of its own, into
        # the extension's config file - or, for an extension declaring
        # config_keys, into lazysite.conf itself. Nothing stripped line breaks,
        # and the allowlist above checks only the KEY. So a value carrying one
        # added whatever lines followed it, past the allowlist: reproduced with a
        # single save to the Logging extension, whose log_level wrote
        # `alias.victim.example.allowed_groups: attackers` into lazysite.conf.
        # plugin-save needs manage_config; that key is behind manage_domains AND
        # manage_users by the SM647 ruling. The form never sends a newline; the
        # API accepts any string.
        #
        # REFUSED, NOT STRIPPED. Stripping would store something other than what
        # was sent and report success; a value that cannot be stored as sent is
        # an error the caller has to see.
        if ( defined $values->{$k} && !ref $values->{$k} && $values->{$k} =~ /[\r\n]/ ) {
            return { ok => 0, kind => 'invalid', field => $k,
                error => "'$k' contains a line break. Each setting is stored on one line, "
                    . 'so a value cannot contain one.' };
        }
        # SM1109: an `email` field holds exactly one address or nothing (empty
        # means "use the default"). The mail writer refuses anything else at
        # send time (SM1017); refusing it at SAVE time says so while the
        # operator is still on the form, not on the first failed send.
        if ( $is_email{$k} && defined $values->{$k} && !ref $values->{$k} && length $values->{$k} ) {
            require Lazysite::Mail;
            my ( $one, $why ) = Lazysite::Mail::one_address( $values->{$k} );
            return { ok => 0, kind => 'invalid', field => $k, error => "'$k' is refused: $why" }
                unless defined $one;
        }
        # SM1160: a field may name a validator, which says why a value cannot be stored
        # ('' when it can). Only a `validate_*` function of a Lazysite:: module is called,
        # so a descriptor cannot name an arbitrary one. Refused at SAVE, by name, with the
        # operator still on the form.
        if ( defined $values->{$k} && !ref $values->{$k} && length $values->{$k} ) {
            my ($fd) = grep { ( $_->{key} // '' ) eq $k } @{ $desc->{config_schema} // [] };
            my $vf   = $fd ? ( $fd->{validate} // '' ) : '';
            if ( my ( $mod, $fn ) = $vf =~ /\A(Lazysite(?:::\w+)+)::(validate_\w+)\z/ ) {
                ( my $file = "$mod.pm" ) =~ s{::}{/}g;
                my $code = eval { require $file; $mod->can($fn) };
                if ($code) {
                    my $why = $code->( $values->{$k}, _lz() );
                    return { ok => 0, kind => 'invalid', field => $k, error => "'$k' is refused: $why" }
                        if defined $why && length $why;
                }
            }
        }
        $safe{$k} = $values->{$k};
    }

    # n699 (OOM Lab L-4): `add` ADDS TO A LIST KEY, under the same lock as the save.
    #
    # { odoo_packs => 'Lab::Picking::Ops' } puts the namespace into the list the file
    # holds NOW and leaves the others in it. A client that installs an app by reading
    # `odoo_packs`, appending its own namespace and saving the whole value is a
    # read-modify-write across two requests: two of them drop each other's namespace,
    # and the dropped app's operations answer "no operation installed" until something
    # saves them again. Only a key the descriptor declares as a list (`list` is its
    # separator) takes it; an item is one plain token on one line.
    my %add;
    if ( ref $add eq 'HASH' && %$add ) {
        my %sep = map { $_->{key} => $_->{list} } grep { length( $_->{list} // '' ) } @{ $desc->{config_schema} // [] };
        for my $k ( sort keys %$add ) {
            return { ok => 0, kind => 'invalid', field => $k, error => "'$k' is not a list setting of this extension, so nothing can be added to it." }
                unless $sep{$k};
            my $sp = quotemeta $sep{$k};
            my @items = ref $add->{$k} eq 'ARRAY' ? @{ $add->{$k} } : split /\s*$sp\s*/, ( $add->{$k} // '' );
            @items = grep { defined && length } @items;
            for my $i (@items) {
                return { ok => 0, kind => 'invalid', field => $k, error => "an item to add to '$k' must be one plain value on one line." }
                    if ref $i || $i =~ /[\r\n]/ || $i =~ /$sp/ || $i =~ /\A\s|\s\z/;
            }
            $add{$k} = { sep => $sep{$k}, items => \@items } if @items;
        }
        return { ok => 0, kind => 'invalid', field => 'add', error => 'add is for an extension with its own config file' }
            if %add && !$desc->{config_file};
    }

    my $config_file = $desc->{config_file} // '';

    # Track which keys ACTUALLY changed - the UI posts the whole form, so
    # without a diff the audit says "8 settings" for a one-field edit.
    my @changed;
    my $apply = sub {
        my ( $content_ref, $k ) = @_;
        if ( ${$content_ref} =~ /^$k\s*:[ \t]*(.*)$/m ) {
            my $old = $1;
            push @changed, $k if $old ne ( $safe{$k} // '' );
            ${$content_ref} =~ s/^$k\s*:.*$/$k: $safe{$k}/m;
        }
        else {
            push @changed, $k if length( $safe{$k} // '' );
            ${$content_ref} .= "$k: $safe{$k}\n";
        }
        return;
    };

    if ($config_file) {
        # $plugin_conf, not $conf_path: this branch writes the PLUGIN'S OWN
        # config file, while the branch below writes lazysite.conf. They had the
        # same variable name, which reads as one thing written two ways.
        my $plugin_conf = "$DOCROOT/$config_file";
        my $dir         = dirname($plugin_conf);
        make_path($dir) unless -d $dir;

        # SM1172 (OOM Lab L-15, "saving odoo_packs while another app is
        # installed left the other app's operations answering 404 'no operation
        # installed'"): THE READ, THE CHANGE AND THE WRITE ARE ONE STEP. The write
        # was already atomic (temp + rename), but the file was read before it with
        # nothing held, so two overlapping saves both read the old file and the
        # second rename dropped the first's keys - an app's odoo_packs namespace
        # among them - until something saved it again. The lock is the one the
        # other read-modify-write stores take (Util::store_lock); readers stay
        # lock-free because the rename gives them a whole file either way.
        my $lock = Lazysite::Util::store_lock($plugin_conf)
            or return { ok => 0, error => "Cannot lock config: $!" };
        my $content = _slurp_or_empty($plugin_conf);

        # The list keys are merged into what the file holds NOW, inside the lock.
        for my $k ( sort keys %add ) {
            my $sp = quotemeta $add{$k}{sep};
            my $src = exists $safe{$k} ? $safe{$k} : ( $content =~ /^$k\s*:[ \t]*(.*)$/m ? $1 : '' );
            my @have = grep { length } split /\s*$sp\s*/, $src;
            my %seen = map  { $_ => 1 } @have;
            push @have, grep { !$seen{$_}++ } @{ $add{$k}{items} };
            $safe{$k} = join $add{$k}{sep}, @have;
        }

        $apply->( \$content, $_ ) for keys %safe;

        # A config carrying a password field must not be world-readable -
        # notify-xmpp.conf sits at the lazysite/ top level, outside the
        # mode-checked directories (2026-07-10 review, D6). SM1183: such a file
        # is CREATED 0660; it was written under the umask and chmod'ed after,
        # with the password in it for the gap between.
        my $has_secret = grep { ( $_->{type} // '' ) eq 'password' }
            @{ $desc->{config_schema} // [] };
        my ( $wok, $werr ) =
            $has_secret
            ? Lazysite::Util::write_private_atomic( $plugin_conf, Encode::encode( 'UTF-8', $content ), 0660 )
            : write_file_checked( $plugin_conf, $content );
        return { ok => 0, error => "Cannot write config: $werr" }
            unless $wok;
        close $lock;
    }
    elsif ( $desc->{config_keys} ) {
        my %want      = map { $_ => 1 } @{ $desc->{config_keys} };
        my $conf_path = _lz() . "/lazysite.conf";
        my $content   = _slurp_or_empty($conf_path);

        $apply->( \$content, $_ ) for grep { $want{$_} } keys %safe;

        # SM085: lazysite.conf is one of the two versioned config files, so a
        # Site-settings save is recorded. SM255 (completion): the writer records
        # it, rather than this branch committing its own write - that private
        # commit is exactly how the two mechanisms diverged. @changed still
        # shapes the MESSAGE, so a one-field edit does not read as "8 settings".
        my $msg = @changed
            ? 'edit lazysite/lazysite.conf (' . join( ', ', sort @changed ) . ')'
            : 'edit lazysite/lazysite.conf';
        my ( $wok, $werr ) = _write_conf_content( $content, $msg );
        return { ok => 0, error => "Cannot write lazysite.conf: $werr" }
            unless $wok;
    }

    # SM1164: a plugin may name an action to run after its config is saved (the Odoo
    # extension rewrites oomd's config and tells the daemon). Like on_enable it
    # resolves against the descriptor's declared actions, and a failure never
    # undoes the save.
    my $hook = @changed ? _run_plugin_hook( $script, 'on_save', $full_script, $desc ) : undef;
    return { ok => 1, changed => [ sort @changed ], ( $hook ? ( hook => $hook ) : () ) };
}

sub action_plugin_action {
    my ( $plugin_id, $script, $action_id, $req_params ) = @_;

    my ( $full_script, $why ) = _resolve_plugin_or_why( $plugin_id, $script );
    return { ok => 0, kind => 'invalid', field => 'plugin', error => $why }
        unless $full_script;

    my $desc = _describe($full_script)
        or return { ok => 0, error => 'Cannot describe plugin' };

    my ($action) = grep { $_->{id} eq $action_id } @{ $desc->{actions} // [] };

    # SM409: a contract plugin that is not enabled executes nothing - except a
    # declared read (SM765), which reports and does not act.
    if ( my $refused = _gate_execution( $script, $desc, $action ) ) { return $refused }

    return { ok => 0, error => 'Action not found' } unless $action;

    if ( $action->{link} ) {
        return { ok => 1, link => $action->{link} };
    }

    # SM085 (git-sync): the minimal generic extension for parameterised plugin
    # actions. An action that declares run:'action' in the descriptor is
    # invoked as `--action <id>` (the legacy default stays `--scan`), and may
    # declare `choices`; a request's params.choice is accepted ONLY when it
    # matches a declared choice id, so nothing request-controlled ever reaches
    # the command line - every argument below is a descriptor literal. The
    # acting user travels in the environment for the plugin's own attribution
    # (commits, snapshots, log lines). Action-mode stderr is NOT discarded:
    # the plugin's log_event lines belong in the server error log.
    my @argv     = ('--scan');
    my $redirect = '2>/dev/null';
    if ( ( $action->{run} // '' ) eq 'action' ) {
        @argv     = ( '--action', $action->{id} );
        $redirect = '';
        my $choice = ( ref $req_params eq 'HASH' ) ? $req_params->{choice} : undef;
        if ( defined $choice && length $choice ) {
            return { ok => 0, error => 'Unknown choice' }
                unless grep { ( $_->{id} // '' ) eq $choice }
                @{ $action->{choices} // [] };
            push @argv, '--choice', $choice;
        }
    }
    local $ENV{LAZYSITE_ACTING_USER} = $Lazysite::Manager::Common::auth_user // '';
    my $args   = join ' ', map { quotemeta } @argv;
    my $output = qx($^X \Q$full_script\E $args --docroot \Q$DOCROOT\E $redirect);
    my $result = eval { decode_json($output) }
        // { ok => 0, error => 'Action produced no output' };

    return $result;
}

# SM842: handlers, their bindings and the schedule are Lazysite::Handlers' -
# one reader and one writer for handlers.conf, where there were three parsers
# that disagreed. What stays here reads them through it.
sub _handlers_module {
    require Lazysite::Handlers;
    no warnings 'once';
    $Lazysite::Handlers::DOCROOT = $DOCROOT;
    return 'Lazysite::Handlers';
}

# SM214: enumerate the site's forms for a token client (or the manager) that can
# read submissions but cannot list plugins/handlers (those are cookie-only). A
# "form" is a lazysite/forms/<name>.conf, excluding the special handlers.conf and
# smtp.conf. Read-only and PII-free (names + handler types + row COUNTS only, never
# submission content), so it is safe on the read_submissions gate. Answers "what
# forms exist?" and "which deliver to email vs storage, and did any come in?".
sub action_form_list {
    my $dir      = _lz() . "/forms";
    my $handlers = _handlers_module()->can('read_handlers')->() // [];
    my %by_id    = map { $_->{id} => $_ } @$handlers;

    my @forms;
    opendir my $dh, $dir or return { ok => 1, forms => [] };
    for my $f ( sort readdir $dh ) {
        next unless $f =~ /^(.+)\.conf\z/;
        my $name = $1;
        next if Lazysite::Handlers::is_reserved_form($name);

        # handler ids this form's targets reference
        my @hids;
        if ( open my $cf, '<:utf8', "$dir/$f" ) {
            local $/;
            my $t = <$cf>;
            close $cf;
            my ($ids) = Lazysite::Handlers::parse_form_conf($t);
            @hids = @$ids;
        }
        my %seen;
        my @types = grep { !$seen{$_}++ }
            map { ( $by_id{$_} && $by_id{$_}{type} ) || 'unknown' } @hids;

        # submissions store: the file-target handler's path (default submissions/)
        # + <name>.jsonl. Count non-blank lines; never read the content.
        #
        # SM855: through Handlers::form_store_file, which is this logic moved
        # where both readers can reach it - MCP's read_form_submissions had its
        # own version that knew only the default directory, and answered an empty
        # success for a store this listing was already reporting as present.
        my $store = Lazysite::Handlers::form_store_file($name) // '';
        my ( $has, $rows ) = ( JSON::PP::false, 0 );
        if ( -f $store && open my $sf, '<', $store ) {
            $has = JSON::PP::true;
            while ( my $l = <$sf> ) { $rows++ if $l =~ /\S/ }
            close $sf;
        }

        push @forms,
            {
            name          => $name,
            handlers      => \@hids,
            handler_types => \@types,
            has_store     => $has,
            row_count     => $rows,     # SM227: the unambiguous name
            };
    }
    closedir $dh;

    # SM227: this listing returns COUNTS and never content, which is deliberate
    # least-privilege design. It also read as "the store is write-only" to a
    # partner, who then specified a replacement store rather than asking for the
    # grant that already reads it. Two things caused that. The `rows` key means a
    # COUNT here and an ARRAY OF ROWS in the sibling action_form_submissions - the
    # same name for two different things - so the count is `row_count`, and the
    # `rows` alias it kept for a release is gone (0.13.13, pre-stable: no aliases
    # kept alive). And a response that says nothing about its own scope leaves the
    # reader to guess:
    # the note names the companion action and the capability that unlocks it, so
    # the answer travels with the payload rather than living in a tool description
    # the reader has already moved past.
    return {
        ok    => 1,
        forms => \@forms,
        note  => 'Counts only - this action never returns submission content. To '
            . 'read the rows, call read_form_submissions (MCP) or form-submissions '
            . '(control API), which need the read_submissions capability. '
            . '"row_count" is the count.',
    };
}

# SM944 S33: form-list's dispatch branch, moved here from lazysite-manager-api.pl
# with its statements unchanged: the listing, filtered for a domain-confined
# caller to the forms it reaches (Manager::Common's form rule, read by full name).
sub dispatch_form_list {
    my $result;
    $result = action_form_list();
    # SM976 F2: a confined caller is shown the forms it reaches, and no other -
    # one walk of the site for every form's binding pages.
    if ( ref $result eq 'HASH' && ref $result->{forms} eq 'ARRAY'
        && Lazysite::Manager::Common::request_domain_confined() )
    {
        my $bound = Lazysite::Manager::Common::form_bindings();
        $result->{forms} = [ grep {
                Lazysite::Manager::Common::caller_may_reach_form( $_->{name}, bindings => $bound )
        } @{ $result->{forms} } ];
    }
    return $result;
}

# SM182: read a form-submissions store (<dir>/<form>.jsonl, one JSON record per
# line, as written by the form-handler local-storage target) and return it as a
# STRUCTURED table - columns + rows - so the manager can render it safely.
# Submissions are user-supplied, so values are returned verbatim (stringified)
# and the CLIENT escapes every cell; nothing is interpolated here. The store is a
# reserved lazysite/ file the raw editor refuses, which is why this dedicated,
# read-only, capability-gated view exists. Rows are capped (most recent) so a
# large store never floods the browser.
# SM182/SM187: confine a submissions-file argument to a .jsonl under the docroot.
# Returns ( $abs_path, $rel, undef ) or ( undef, undef, $error ).
# SM268 H1: the directories that legitimately hold submission stores - the
# default, plus the `path` of every configured file-target handler. Normalised
# and reserved-area-checked, so an operator cannot point a handler at
# lazysite/auth and turn this back into an arbitrary reader.
# SM422: PUBLIC, because it is now a shared definition rather than this
# module's private business. Common::carveout_refusal consults it so the read
# gate and the control API's form-submissions route agree about what a
# submission store IS - and a cross-package reach into a private sub is
# exactly what "use published APIs" exists to stop.
sub submission_store_dirs {
    my %dirs = ( 'lazysite/forms/submissions' => 1 );
    my $list = eval { _handlers_module()->can('read_handlers')->() } || [];
    for my $h (@$list) {
        next unless ref $h eq 'HASH';
        next unless ( $h->{type} // 'file' ) eq 'file';
        my $p = $h->{path};
        next unless defined $p && length $p;
        $p =~ s{^/+|/+$}{}g;
        next unless length $p;
        next if $p =~ m{(?:^|/)\.\.(?:/|$)};
        # A handler pointed at an engine-owned area is a misconfiguration, and
        # honouring it here would reintroduce the very read this fix closes.
        next if Lazysite::Manager::Common::path_is_reserved($p)
            && $p !~ m{\Alazysite/forms(?:/|\z)};
        $dirs{$p} = 1;
    }
    return keys %dirs;
}

sub _submissions_path {
    my ($file) = @_;
    ( my $rel = $file // '' ) =~ s{^/+}{};
    return ( undef, undef, 'Invalid submissions file' )
        unless $rel =~ /\.jsonl\z/ && $rel !~ m{(?:^|/)\.\.(?:/|$)};

    # SM268 H1: confine to the submission stores. This checked only "ends in
    # .jsonl, no .., inside the docroot" - so a token holding the LEAST
    # PRIVILEGE read capability (read_submissions, documented as "a read that
    # does not allow editing forms or handlers") could read ANY .jsonl under the
    # docroot. Reproduced: lazysite/auth/sessions.jsonl, which is the session
    # registry - operator usernames, their source IPs, User-Agents and session
    # ids - and another domain's leads file. The blocklist was never consulted
    # and the action is absent from %SCOPED_ACTION, so neither the reserved-area
    # guard nor dav_scope applied.
    #
    # The store directory is sysop-configurable (the file handler's `path`,
    # default lazysite/forms/submissions), so this admits the configured
    # directories rather than one hard-coded string - anything else would break
    # a site that moved its store. A file OUTSIDE every configured store is
    # refused whatever its extension.
    my %allowed = map { $_ => 1 } submission_store_dirs();
    my $dir     = $rel;
    $dir =~ s{/[^/]+\z}{};
    return ( undef, undef, 'Invalid submissions file' )
        unless length $dir && $allowed{$dir};

    # SM842: the store is where the file handler WRITES it - through the same
    # resolver, so a store under lazysite/ is found in the engine tree wherever
    # that tree is (SM293 can move it beside the docroot). Confined to the
    # docroot or the engine tree, whichever the store resolved into.
    ( my $leaf = $rel ) =~ s{.*/}{};
    my $abs  = _handlers_module()->can('store_path')->($dir) . "/$leaf";
    my $real = realpath( -e $abs ? $abs : dirname($abs) );
    my $lz   = _lz();
    my $lzr  = defined $lz ? realpath($lz) : undef;

    # N141E (SM852's MISS row, and the filing's guess about it was wrong).
    #
    # The row read: "Plugins::_rewrite_store (finds no store once its folder is
    # gated - fixed by S1, since it reads through store_path; to verify)". It
    # does read through store_path, and store_path resolves the gated store
    # correctly - into the private store beside the docroot. THEN THIS CHECK
    # REFUSED ITS OWN ANSWER, because it admitted two roots and the private
    # store is a third. So the store was found and then declared invalid, and
    # the operator was told "Invalid submissions file" about a file that is
    # there, with their rows unreadable and undeletable.
    #
    # Verified rather than assumed (tmp/diagnose-gated-store.pl): store_path
    # returns the private path, realpath agrees it exists, and it is not under
    # $DOCROOT/ - which is the whole of it.
    #
    # WHAT IS NOT WIDENED. SM268 H1's guard is the one that matters here - the
    # file must sit inside a CONFIGURED store directory - and it runs above,
    # unchanged. That is what stops a read_submissions token reaching
    # lazysite/auth/sessions.jsonl or another domain's leads. This check is the
    # second, weaker fence: which ROOTS a store may live in. The private store
    # is this site's own content, put there by this site's own protection
    # feature, so it belongs on the list beside the other two - matched the same
    # way, by exact root or a path beneath it, never by "somewhere outside".
    my $privr = do {
        require Lazysite::Private;
        my $p = Lazysite::Private::private_root($DOCROOT);
        defined $p ? realpath($p) : undef;
    };

    my $inside = defined $real
        && ( $real eq $DOCROOT
        || index( $real, "$DOCROOT/" ) == 0
        || ( defined $lzr   && ( $real eq $lzr   || index( $real, "$lzr/" ) == 0 ) )
        || ( defined $privr && ( $real eq $privr || index( $real, "$privr/" ) == 0 ) ) );

    return ( undef, undef, 'Invalid submissions file' ) unless $inside;
    return ( $abs,  $rel,  undef );
}

# A stable per-row id: a short hash of the raw JSONL line, so the UI can ask to
# delete a specific record without a line number that shifts as rows are removed.
#
# HASHED AS UTF-8 BYTES. Every reader opens the store with :utf8, so a line is a
# CHARACTER string, and sha256_hex dies on a character above U+00FF ("Wide
# character") and hashes a Latin-1 one as a different byte than the file holds.
# The id is the hash of the line as it is on disk, whatever the reader's layer.
sub _submission_row_id { return _handlers_module()->can('submission_row_id')->( $_[0] ) }

# A stored row, read from a CHARACTER string. decode_json wants UTF-8 BYTES, so
# on a :utf8-read line it refused every row holding a non-ASCII character as
# "malformed UTF-8" - and the table counted the row malformed and did not show
# it. SM904 made sure a value is STORED as the visitor typed it; this is the read
# half. A visitor named Herve-with-an-accent submitted and nobody saw it.
my $ROW_JSON = JSON::PP->new;
sub _decode_row { return eval { $ROW_JSON->decode( $_[0] ) } }

sub action_form_submissions {
    my ( $file, $form ) = @_;

    # SM862: THE FORM NAME IS AN ACCEPTED WAY TO ASK, and an absent parameter is
    # named rather than called invalid.
    #
    # This took `file` only - a relative path ending .jsonl inside a configured
    # store - so `form=<name>`, which is what MCP's read_form_submissions takes
    # and what `form-targets-read` takes on this very channel, arrived as no
    # parameter at all. _submissions_path then failed its .jsonl test and
    # answered "Invalid submissions file": a MISSING parameter reported as a BAD
    # VALUE, which sent a site agent looking at a value it had never sent. The
    # fourth time in one campaign (SM773's family).
    #
    # Resolved through Handlers, the same resolver MCP uses, so the two channels
    # cannot disagree about where a form's submissions live. RELATIVE, because
    # _submissions_path needs the configured directory rather than an absolute
    # path - which is the distinction SM855 split form_store_dir and
    # form_store_file apart for.
    if ( !( defined $file && length $file ) && defined $form && length $form ) {
        # SM870: A FORM THAT DOES NOT EXIST IS NOT AN EMPTY ONE.
        #
        # The store for an unknown form resolves to the DEFAULT directory, so the
        # path is well-formed and simply absent - and absent read as empty, so
        # this answered ok:true, total:0 naming a .jsonl that was never created.
        # SM855's own shape one level up: a wrong-place read reported as nothing
        # there. An operator approving registrations reads by form name, so a
        # renamed or mistyped form told them nobody had registered.
        #
        # The empty answer for a form that EXISTS with no submissions yet is
        # correct and is left alone - absent FORM and absent STORE are different
        # facts and only one is a refusal.
        my $fc = _handlers_module()->can('form_file')->($form);
        return { ok => 0, kind => 'not-found',
            error => "no form named '$form' - check the name against form-list" }
            unless defined $fc && -f $fc;

        my $dir = _handlers_module()->can('form_store_dir')->($form);
        $file = "$dir/$form.jsonl" if defined $dir && length $dir;
    }

    # NEITHER SENT. Answered by name, before the path validator gets a chance to
    # describe an absence as a malformed value.
    return { ok => 0, kind => 'missing-parameter',
        error => 'No submissions named. Pass `form` with the form\'s name, or '
            . '`file` with the path to its .jsonl store - `form` is the one to '
            . 'reach for, and is what the MCP tool takes.' }
        unless defined $file && length $file;

    my ( $abs, $rel, $err ) = _submissions_path($file);
    return { ok => 0, error => $err } if $err;
    return { ok => 1, file => $rel, columns => [], rows => [], total => 0, shown => 0 }
        unless -f $abs;

    open my $fh, '<:utf8', $abs
        or return { ok => 0, error => 'Cannot read submissions' };
    my $CAP = 500;
    my ( @rows, @raw, @cols, %seen, $total, $malformed );
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        next unless length $trim;
        $total++;
        my $rec = _decode_row($trim);
        if ( ref $rec ne 'HASH' ) { $malformed++; next }
        push @cols, $_ for grep { !$seen{$_}++ } keys %$rec;
        push @rows, $rec;
        push @raw,  $trim;
    }
    close $fh;

    if ( @rows > $CAP ) { @rows = @rows[ -$CAP .. -1 ]; @raw = @raw[ -$CAP .. -1 ] }
    # Stringify every value (a nested ref is JSON-encoded); the client escapes.
    # Each row carries a stable _id (raw-line hash) so it can be deleted.
    my @out = map {
        my ( $r, $raw ) = ( $rows[$_], $raw[$_] );
        +{ _id => _submission_row_id($raw),
            map {
                $_ => ( !defined $r->{$_} ? ''
                    : ref $r->{$_} ? $ROW_JSON->encode( $r->{$_} )  # characters, as above
                    :                "$r->{$_}" )
            } @cols
        }
    } 0 .. $#rows;

    # SM858: the field the form names as an account's address, when this store
    # is that form's - the viewer offers Approve only then. Absent otherwise.
    my ( undef, $account_email ) = _approval_form( $abs, $rel );

    return {
        ok        => 1,
        file      => $rel,
        columns   => \@cols,
        rows      => \@out,
        total     => ( $total || 0 ),
        shown     => scalar(@out),
        truncated => ( $total > $CAP ? 1 : 0 ),
        malformed => ( $malformed || 0 ),
        ( length $account_email ? ( account_email => $account_email ) : () ),
    };
}

# SM187: delete ONE handled submission row from a store, identified by the stable
# _id (raw-line hash) that action_form_submissions returns. Rewrites the .jsonl
# without the matched line, atomically (temp + rename). manage_forms-gated +
# audited by the dispatch wrapper. Returns { ok, deleted } or { ok=>0, error }.
# TL-20: the one atomic replacement the three submission editors share. Write
# the surviving lines to a sibling temp file and rename it over the store, so a
# concurrent reader sees the whole old file or the whole new one and never a
# half-written store. On a failure the temp file is removed, leaving the store
# as it was. Returns undef on success, or the caller's own error hash.
sub _rewrite_store {
    my ( $abs, $keep ) = @_;
    my $tmp = "$abs.tmp.$$";
    open my $out, '>:utf8', $tmp
        or return { ok => 0, error => 'Cannot write submissions' };
    print {$out} @$keep;
    close $out;
    rename $tmp, $abs
        or do { unlink $tmp; return { ok => 0, error => 'Cannot replace submissions' } };
    return undef;
}

sub action_form_submission_delete {
    my ( $file, $id ) = @_;
    my ( $abs, $rel, $err ) = _submissions_path($file);
    return { ok => 0, error => $err } if $err;
    return { ok => 0, error => 'A row id is required' }
        unless defined $id && $id =~ /\A[0-9a-f]{16}\z/;
    return { ok => 0, error => 'No such submissions store' } unless -f $abs;

    my $store_lock = Lazysite::Util::store_lock($abs) # SM961: across the read and the rewrite
        or return { ok => 0, error => "Cannot lock submissions: $!" };
    open my $fh, '<:utf8', $abs or return { ok => 0, error => 'Cannot read submissions' };
    my ( @keep, $deleted );
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        if ( !$deleted && length $trim && _submission_row_id($trim) eq $id ) {
            $deleted = 1;
            next;
        }
        push @keep, $line;
    }
    close $fh;
    return { ok => 0, error => 'Row not found' } unless $deleted;

    if ( my $e = _rewrite_store( $abs, \@keep ) ) { return $e }
    return { ok => 1, file => $rel, deleted => 1 };
}

# SM216: confirm a quarantined submission as legitimate - clear its _quarantined /
# _spam_reason flags on the stored row (by stable id), so it leaves the Quarantine
# filter. The row content is untouched; a false positive is recovered in one click.
# (Deleting a genuine spam row stays action_form_submission_delete.)
# SM938 D5: ONE SUBMISSION, BY ITS ID.
#
# A submission notice named the form and linked to a manager SECTION; the
# operator asked for "a link to the thing that happened". The file handler now
# reports the row it wrote (store + id) and the notice links here. Same path
# confinement and the same grant as the table (read_submissions) - this reads one
# row of what the table reads all of, and no more.
sub action_form_submission {
    my ( $file, $id ) = @_;
    return { ok => 0, kind => 'missing-parameter', field => 'file',
        error => 'file is required - the submissions store the row is in' }
        unless defined $file && length $file;
    return { ok => 0, kind => 'invalid', field => 'id',
        error => 'id is required: 16 hex characters, as the notice link and the table give it' }
        unless defined $id && $id =~ /\A[0-9a-f]{16}\z/;
    my ( $abs, $rel, $err ) = _submissions_path($file);
    return { ok => 0, error => $err } if $err;
    # SM953: the answer names the form and the id, never the store's path - the
    # owner's ruling on what a message may expose. The store is named for its form.
    ( my $form = $rel ) =~ s{\A.*/}{};
    $form =~ s/\.jsonl\z//;
    open my $fh, '<:utf8', $abs
        or return { ok => 0, kind => 'not-found', error => "no submissions for the form '$form'" };
    my $found;
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        next unless length $trim && _submission_row_id($trim) eq $id;
        $found = _decode_row($trim);
        last;
    }
    close $fh;
    # Not there is a fact worth its own words: it was deleted, or the link is
    # older than an edit to the row. Either way the store still opens.
    return { ok => 0, kind => 'not-found',
        error => "no submission $id on the form '$form' - it may have been deleted since the notice was sent" }
        unless ref $found eq 'HASH';
    my @fields = grep { !/\A_/ } sort keys %$found;
    my @meta   = grep { /\A_/ } sort keys %$found;
    my %out    = map {
        $_ => ( !defined $found->{$_} ? '' : ref $found->{$_} ? $ROW_JSON->encode( $found->{$_} ) : "$found->{$_}" )
    } keys %$found;
    return { ok => 1, file => $rel, id => $id, record => \%out, fields => \@fields, meta => \@meta };
}

sub action_form_submission_confirm {
    my ( $file, $id ) = @_;
    my ( $abs, $rel, $err ) = _submissions_path($file);
    return { ok => 0, error => $err } if $err;
    return { ok => 0, error => 'A row id is required' }
        unless defined $id && $id =~ /\A[0-9a-f]{16}\z/;
    return { ok => 0, error => 'No such submissions store' } unless -f $abs;

    my $store_lock = Lazysite::Util::store_lock($abs) # SM961: across the read and the rewrite
        or return { ok => 0, error => "Cannot lock submissions: $!" };
    open my $fh, '<:utf8', $abs or return { ok => 0, error => 'Cannot read submissions' };
    my ( @out, $confirmed );
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        if ( !$confirmed && length $trim && _submission_row_id($trim) eq $id ) {
            my $rec = _decode_row($trim);
            if ( ref $rec eq 'HASH' ) {
                delete @{$rec}{qw(_quarantined _spam_reason)};
                # Characters, not encode_json's bytes: the store is rewritten
                # through a :utf8 layer, which would encode them a second time.
                # Canonical, as the file handler writes it.
                push @out, JSON::PP->new->canonical->encode($rec) . "\n";
                $confirmed = 1;
                next;
            }
        }
        push @out, $line;
    }
    close $fh;
    return { ok => 0, error => 'Row not found' } unless $confirmed;

    if ( my $e = _rewrite_store( $abs, \@out ) ) { return $e }
    return { ok => 1, file => $rel, confirmed => 1 };
}

# SM858: WHICH FORM A STORE BELONGS TO, AND WHICH OF ITS FIELDS IS THE ADDRESS.
#
# The store is named for its form (<form>.jsonl, as the file handler writes it),
# and that is a CLAIM about the file, not a fact: two forms can share a store
# directory, and a store can sit in a directory its namesake form does not
# write to. So the form's own store - resolved through Handlers, as every other
# reader resolves it - must BE this file, or the form's `account_email:` says
# nothing about these rows. Returns ( $form, $field, $why ): $field '' when the
# store is not that form's or the form declares no address field, and $why says
# which, in words a refusal can carry.
sub _approval_form {
    my ( $abs, $rel ) = @_;
    ( my $form = $rel // '' ) =~ s{\A.*/}{};
    $form =~ s/\.jsonl\z//;
    my $none = "no form named '$form' writes this store";
    return ( $form, '', $none ) unless length $form && $form =~ /\A[A-Za-z0-9_-]+\z/;
    my $h  = _handlers_module();
    my $fc = $h->can('form_file')->($form);
    return ( $form, '', $none ) unless defined $fc && -f $fc;
    my $want = $h->can('form_store_file')->($form);
    return ( $form, '', "this store is not where the form '$form' writes its submissions" )
        unless defined $want && defined $abs && _same_store( $want, $abs );
    open my $fh, '<:utf8', $fc or return ( $form, '', "the form '$form' could not be read" );
    my $text = do { local $/; <$fh> };
    close $fh;
    my $field = $h->can('form_account_email')->($text);
    return ( $form, $field, length $field ? '' : "the form '$form' does not declare account_email:" );
}

# SM979: IS THIS THE STORE OF A FORM THAT REQUESTS ACCOUNTS? 1 or 0.
#
# What an approve_accounts holder may read: the rows approving reads, which are
# the rows of a form whose conf declares `account_email:` - and only from the
# store that form writes. Named by `file`, or by `form` resolved as
# action_form_submissions resolves it, so the two cannot reach different files.
# The same test the approval itself applies (_approval_form), so a store this
# answers 1 for is exactly a store whose rows can be approved.
sub account_request_store {
    my ( $file, $form ) = @_;
    if ( !( defined $file && length $file ) && defined $form && length $form ) {
        return 0 unless $form =~ /\A[A-Za-z0-9_-]+\z/;
        my $dir = _handlers_module()->can('form_store_dir')->($form);
        $file = "$dir/$form.jsonl" if defined $dir && length $dir;
    }
    return 0 unless defined $file && length $file;
    my ( $abs, $rel, $err ) = _submissions_path($file);
    return 0 if $err;
    my ( undef, $field ) = _approval_form( $abs, $rel );
    return ( defined $field && length $field ) ? 1 : 0;
}

# One store, however it was spelt: the same leaf in the same real directory.
sub _same_store {
    my ( $x, $y ) = @_;
    return 1 if $x eq $y;
    my ( $lx, $ly ) = map { ( my $l = $_ ) =~ s{\A.*/}{}; $l } $x, $y;
    return 0 unless $lx eq $ly;
    my ( $dx, $dy ) = map { realpath( dirname($_) ) } $x, $y;
    return ( defined $dx && defined $dy && $dx eq $dy ) ? 1 : 0;
}

# SM858: THE USERNAME, FROM THE ADDRESS - deterministic, and refused rather than
# guessed. SM673 recommended allocating the name at approval from the address,
# because a visitor-chosen name is both a collision problem and an
# account-existence oracle.
#
# The name is the address's local part, lowercased. Nothing is stripped,
# substituted or suffixed: a local part holding a character a username may not
# (cmd_add would silently DROP it, so `jo+hn` would become `john` - somebody
# else's name) is refused, naming the character. One address always yields one
# name, which is what makes a second approval of the same person collide with
# the first instead of creating a second account.
#
# Returns ( $name, undef ) or ( undef, $why ).
sub approval_username {
    my ($email) = @_;
    $email = '' unless defined $email;
    my ($local) = $email =~ /\A([^@\s]+)\@[^@\s]+\.[^@\s]+\z/;
    return ( undef, "'$email' is not an email address" ) unless defined $local;
    my $name = lc $local;
    return ( undef, "the address's local part '$local' cannot be a username: '$1' is not "
            . "allowed in one (letters, digits, '.', '_' and '-' only)" )
        if $name =~ /([^a-z0-9_.-])/;
    return ( undef, "the address's local part '$local' cannot be a username: it must start "
            . 'with a letter or a digit' )
        unless $name =~ /\A[a-z0-9]/;
    return ( undef, "the address's local part '$local' is longer than 64 characters, too long "
            . 'for a username' )
        if length $name > 64;
    return ( undef, "'local' is reserved - it is the sysadmin identity, not an account" )
        if $name eq 'local';
    return ( $name, undef );
}

# SM858: APPROVE AN ACCOUNT FROM A STORED SUBMISSION.
#
# The operator decides; the system does the typing. The address is the one the
# SUBMISSION holds in the field its form names (`account_email:`), never one the
# caller supplies, and the account is made by the users tool's account-approve -
# the verb the CLI and the Users API already use: no password, the flagged
# registration groups, the address recorded so `forgot` can reach it, a claim.
#
# NOTHING IS CREATED until every refusal has had its chance: a form without the
# declaration, a quarantined row, a row already approved, an address that is not
# one, a name the address cannot make, a name already taken (in any case), and
# an address another account already records - `forgot` resolves an address to
# the FIRST account holding it, so a second would be unreachable by its owner.
#
# AND APPROVING TWICE CANNOT MAKE TWO ACCOUNTS. The row is marked with the
# account it became, and the name is a function of the address, so even an
# unmarked row (a failed mark, a second row from the same person) arrives at an
# existing name and is refused.
#
# `users` is the caller's door to the users tool (users_api in the CGI);
# `by` is who approved, recorded on the row.
sub action_form_submission_approve {
    my ( $file, $id, %o ) = @_;
    my $users = $o{users};
    return { ok => 0, error => 'user management not available' } unless ref $users eq 'CODE';
    return { ok => 0, kind => 'missing-parameter', field => 'file',
        error => 'file is required - the submissions store the row is in' }
        unless defined $file && length $file;
    return { ok => 0, kind => 'invalid', field => 'id',
        error => 'id is required: 16 hex characters, as the table gives it' }
        unless defined $id && $id =~ /\A[0-9a-f]{16}\z/;
    my ( $abs, $rel, $err ) = _submissions_path($file);
    return { ok => 0, error => $err } if $err;

    my ( $form, $field, $nofield ) = _approval_form( $abs, $rel );
    return { ok => 0, kind => 'invalid',
        error => "$nofield, so these submissions are not account requests - nothing was created" }
        unless length $field;
    return { ok => 0, kind => 'not-found', error => "no submissions for the form '$form'" }
        unless -f $abs;

    my $store_lock = Lazysite::Util::store_lock($abs) # SM961: across the read and the rewrite
        or return { ok => 0, error => "Cannot lock submissions: $!" };
    open my $fh, '<:utf8', $abs or return { ok => 0, error => 'Cannot read submissions' };
    my $found;
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        next unless length $trim && _submission_row_id($trim) eq $id;
        $found = _decode_row($trim);
        last;
    }
    close $fh;
    return { ok => 0, kind => 'not-found',
        error => "no submission $id on the form '$form' - it may have been deleted or changed" }
        unless ref $found eq 'HASH';

    my $done = $found->{_approved_account};
    return { ok => 0, kind => 'conflict', user => "$done",
        error => "this submission was already approved as the account '$done' - nothing was created" }
        if defined $done && !ref $done && length $done;
    return { ok => 0, kind => 'invalid',
        error => 'this submission is quarantined - confirm it first if it is genuine, then '
            . 'approve it; nothing was created' }
        if $found->{_quarantined};

    my $email = $found->{$field};
    $email = '' unless defined $email && !ref $email;
    $email =~ s/^\s+|\s+$//g;
    return { ok => 0, kind => 'invalid', field => $field,
        error => "the submission has no '$field' value, which the form names as the account's "
            . 'address - nothing was created' }
        unless length $email;
    my ( $user, $why ) = approval_username($email);
    return { ok => 0, kind => 'invalid', field => $field,
        error => "$why - nothing was created. Create this account on the Users page with a "
            . 'name you choose.' }
        unless defined $user;

    # Taken, in ANY case: `John` and `john` are two names to the store and one
    # person to everybody reading a list of them.
    # P4: the one field this reads, not every account's derived settings - which
    # took 43 s for 695 accounts and outlasted the browser's request. An answer
    # that could not read the store is not a list of free names.
    my $d = $users->( { action => 'users-detail', fields => ['email'] } );
    return { ok => 0, error => 'the account store could not be read - nothing was created' }
        unless ref $d eq 'HASH' && $d->{ok} && ref $d->{users} eq 'ARRAY'
        && !( exists $d->{store_readable} && !$d->{store_readable} );
    for my $u ( @{ $d->{users} } ) {
        my $n = ref $u eq 'HASH' ? $u->{user} : $u;
        next unless defined $n && length $n;
        return { ok => 0, kind => 'conflict', user => $n,
            error => "an account named '$n' already exists, and '$email' makes the name "
                . "'$user' - nothing was created or changed. Create this account on the Users "
                . 'page with a name you choose.' }
            if lc $n eq $user;
        my $s = ref $u eq 'HASH' ? $u->{settings} : undef;
        my $e = ref $s eq 'HASH' ? $s->{email}    : undef;
        return { ok => 0, kind => 'conflict', user => $n,
            error => "the address '$email' is already recorded on the account '$n' - nothing "
                . 'was created. A second account with it could never fetch its own link.' }
            if defined $e && !ref $e && lc $e eq lc $email;
    }

    my $r = $users->( { action => 'account-approve', username => $user, email => $email } );
    return { ok => 0, error => 'user management gave no answer - check the Users page' }
        unless ref $r eq 'HASH';
    return { %$r, ok => 0 } unless $r->{ok};

    if ( my $e = _mark_approved( $abs, $id, $user, $o{by} ) ) {
        return { ok => 0, user => $user,
            error => "the account '$user' was created, but the submission could not be marked "
                . "approved ($e->{error}) - approving it again is refused by the name" };
    }
    # SM963: `unplaced` - the flagged groups account-approve could not put the
    # account in, each with its reason - goes back to the operator who pressed
    # the button; dropping it here would hide it again one layer up.
    return { ok => 1, file => $rel, id => $id, form => $form, user => $user, email => $email,
        group => $r->{group}, unplaced => ( ref $r->{unplaced} eq 'ARRAY' ? $r->{unplaced} : [] ),
        claim => $r->{claim}, path => $r->{path},
        ( defined $r->{url} ? ( url => $r->{url} ) : () ) };
}

# The row records the account it became, who approved it and when - which is
# what the viewer shows in place of the button, and what refuses a second
# approval of the same row by name before anything is asked of the users tool.
sub _mark_approved {
    my ( $abs, $id, $user, $by ) = @_;
    # SM961: NO lock taken here - the caller (action_form_submission_approve)
    # holds the store's lock from its read to this rewrite, so one approval
    # cannot interleave with another. A second flock on a new handle in the
    # same process would wait for itself.
    open my $fh, '<:utf8', $abs or return { ok => 0, error => 'Cannot read submissions' };
    my ( @out, $marked );
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        if ( !$marked && length $trim && _submission_row_id($trim) eq $id ) {
            my $rec = _decode_row($trim);
            if ( ref $rec eq 'HASH' ) {
                require POSIX;
                $rec->{_approved_account} = $user;
                $rec->{_approved_by}      = $by // '';
                $rec->{_approved_at} = POSIX::strftime( '%Y-%m-%dT%H:%M:%S', localtime );
                push @out, JSON::PP->new->canonical->encode($rec) . "\n";
                $marked = 1;
                next;
            }
        }
        push @out, $line;
    }
    close $fh;
    return { ok => 0, error => 'Row not found' } unless $marked;
    return _rewrite_store( $abs, \@out );
}

# SM187 v2: delete several rows in ONE atomic rewrite - bulk cleanup, e.g.
# clearing a spam batch out of a store. Same path confinement + stable-id
# matching as the single delete; UI-only (destructive PII). Unknown ids are
# simply not matched; the result reports how many requested ids were removed.
sub action_form_submissions_delete_bulk {
    my ( $file, $ids ) = @_;
    my ( $abs, $rel, $err ) = _submissions_path($file);
    return { ok => 0, error => $err } if $err;
    return { ok => 0, error => 'No row ids given' }
        unless ref $ids eq 'ARRAY' && @$ids;
    my %want;
    for my $id (@$ids) {
        return { ok => 0, error => 'A row id is malformed' }
            unless defined $id && $id =~ /\A[0-9a-f]{16}\z/;
        $want{$id} = 1;
    }
    return { ok => 0, error => 'No such submissions store' } unless -f $abs;

    my $store_lock = Lazysite::Util::store_lock($abs) # SM961: across the read and the rewrite
        or return { ok => 0, error => "Cannot lock submissions: $!" };
    open my $fh, '<:utf8', $abs or return { ok => 0, error => 'Cannot read submissions' };
    my ( @keep, $deleted );
    $deleted = 0;
    while ( my $line = <$fh> ) {
        ( my $trim = $line ) =~ s/\s+\z//;
        if ( length $trim && $want{ _submission_row_id($trim) } ) { $deleted++; next; }
        push @keep, $line;
    }
    close $fh;
    return { ok => 0, error => 'No matching rows' } unless $deleted;

    if ( my $e = _rewrite_store( $abs, \@keep ) ) { return $e }
    return { ok => 1, file => $rel, deleted => $deleted };
}

# SM632: the inverse of bind_form.
#
# `bind_form` writes lazysite/forms/<name>.conf and there was NO inverse on any
# token surface: not in the action registry, and delete_file refuses the path
# because lazysite/ is internal (correctly). So a capability a token may hold
# created an object no capability a token may hold could destroy, and
# registrations accumulated with nothing able to prune them - form-list counts a
# bound form with no store as a real form. That is the same create-without-delete
# asymmetry SM578 closed for site packages, on a different object.
#
# WHAT IT DELETES AND WHAT IT WILL NOT. The registration only. A form with
# STORED SUBMISSIONS is refused, because those are personal data and deleting
# their registration would orphan them - present on disk, absent from every
# listing, which is worse than leaving the form. Removing submissions is
# form-submission-delete, kept interactive on purpose (SM214: a human confirms a
# destructive operation on personal data, often on the only copy). An empty
# store is not a reason to refuse: there is nothing to orphan.
#
# Confirmation names the form, like data-table-drop. A destructive verb that
# takes only an id is one an agent fires by having the wrong id.
sub action_form_delete {
    my ( $name, $confirm ) = @_;

    return { ok => 0, error => 'form name required', kind => 'invalid' }
        unless defined $name && length $name;
    return { ok => 0, error => "invalid name '$name'", kind => 'invalid-path' }
        unless $name =~ /\A[A-Za-z0-9_-]+\z/;
    return { ok => 0, error => 'refusing to delete a reserved config',
        kind => 'invalid' }
        if _handlers_module()->can('is_reserved_form')->($name);

    my $conf = _lz() . "/forms/$name.conf";
    return { ok => 0, kind => 'no_such_form',
        error => "no form '$name' is registered" }
        unless -f $conf;

    # The row count comes from the SAME reader the listing uses, so a form that
    # looks empty in form-list cannot be refused here, or look full there and be
    # deleted here. Two counters for one question is how the halves disagree.
    my $listing = action_form_list();
    my ($rec)   = grep { $_->{name} eq $name } @{ $listing->{forms} || [] };
    my $rows    = $rec ? ( $rec->{row_count} // 0 ) : 0;
    if ( $rows > 0 ) {
        return { ok => 0, kind => 'has_submissions', rows => $rows,
            error => "'$name' has $rows stored submission"
                . ( $rows == 1 ? '' : 's' )
                . '. Deleting the registration would leave them on disk and out '
                . 'of every listing. Remove them in the manager first '
                . '(submission deletion is interactive by design), then delete '
                . 'the form.' };
    }

    unless ( defined $confirm && $confirm eq $name ) {
        return { ok => 0, kind => 'confirm', field => 'confirm',
            error => "Confirm by naming it exactly: {\"form\":\"$name\","
                . "\"confirm\":\"$name\"}" };
    }

    unlink $conf
        or return { ok => 0, error => "cannot remove the form config: $!" };
    log_event( 'INFO', $name, 'form registration deleted' );
    return { ok => 1, form => $name, removed => "lazysite/forms/$name.conf" };
}

1;
