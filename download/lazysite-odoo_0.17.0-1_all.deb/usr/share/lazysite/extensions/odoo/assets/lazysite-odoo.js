/* lazysite-odoo.js - SM747 D (OA6): the one place a page talks to the Odoo
 * endpoint, so that no page writes its own.
 *
 * WHY A SHIPPED HELPER. Every page that runs an Odoo binding would otherwise
 * write its own fetch, and each would get the same things wrong: fetch the
 * visitor token and forget to refresh it, loop on a refusal, show a sign-in box
 * that keeps the password in a variable or a URL, or put what Odoo returned into
 * the page as markup. It does eight things:
 *
 *   1. fetches the tokens (GET ?csrf=1) and sends the right one on every POST;
 *   2. on a CSRF refusal fetches fresh tokens and retries ONCE - never twice;
 *   3. on "sign in" (401, kind signin-required) asks the person to sign in and
 *      retries the call ONCE - never twice, so a wrong password cannot loop;
 *   4. signs a person in and out, including Odoo's own two-factor code step;
 *   5. fills regions of the page from a binding, as text;
 *   6. runs several calls in one request (`batch`, SM1146);
 *   7. shows who is signed in, from the tokens it already fetches (SM1145);
 *   8. sends a File (or Blob, or a list of them) in a binding call's params as
 *      multipart/form-data (SM1162), see `write` below;
 *   9. shows what a write left unknown - its request was sent and no answer came -
 *      with "check again", and the person's own "it was made" / "it was not made"
 *      where the server says they may (SM1277), see `showUnknown` below;
 *  10. shows which fields of an applied write Odoo did not keep (SM1347), see
 *      `showNotKept` below - the field names and the server's sentence, never a value.
 *
 * THE SECOND FACTOR (SM1157). An Odoo account with two-factor authentication
 * answers the password with { second_factor: 'totp' } and nothing else: the
 * server holds the half-open sign-in in its own signed HttpOnly cookie, and the
 * dialog changes to ask for the 6-digit code from the person's authenticator app.
 * A wrong code says so and asks again (Odoo counts the tries); a sign-in that has
 * run out sends the person back to the password. "Remember this device" is shown
 * only when the site offers it, and what Odoo returns for it goes into a cookie
 * this script cannot read. The code is handled as the password is: read from the
 * box, the box cleared at once, sent in one POST, never kept.
 *
 * THE PASSWORD. It is read from the box, sent in the body of one POST over
 * HTTPS to the page's own endpoint, and the box is cleared at once - before the
 * answer arrives. It is never in a URL, a cookie, a variable that outlives the
 * call, storage, the console or an event. The session it opens lives in an
 * HttpOnly cookie this script cannot read; this script never holds it.
 *
 * VALUES GO IN AS TEXT, ALWAYS, via textContent. Nothing here builds markup from
 * what Odoo returned, so a record whose name is a script tag renders as those
 * characters and does nothing. A field the server refused to draw (`refused`) is
 * not in `fields` and is not filled.
 *
 * NO DEPENDENCIES, NO CDN, NO BUILD, NO STORAGE: it serves from the site's own
 * origin and keeps nothing between page loads.
 *
 * THE MARKUP CONTRACT, for a region:
 *
 *   <div data-ls-odoo="shop-list" data-ls-odoo-limit="10">
 *     <template><li><span data-ls-field="name"></span></li></template>
 *     <p data-ls-empty>Nothing to show yet.</p>
 *   </div>
 *   <button data-ls-odoo-signin>Sign in to Odoo</button>
 *   <button data-ls-odoo-signout>Sign out</button>
 *   <span data-ls-odoo-name></span>
 *   <div data-ls-odoo-unknown></div>
 *
 * `data-ls-odoo-<name>="v"` on a region is the request field `<name>`.
 *
 * `<div data-ls-odoo-unknown>` is where a write() or confirm() whose answer left a
 * change unknown is drawn (SM1277): the changes, as text, and the buttons to settle
 * them. A page without one gets the answer from write() as before.
 *
 * `<div data-ls-odoo-not-kept>` is where a write(), confirm() or a settled resume
 * whose answer says Odoo did not keep a change is drawn (SM1347): one line per such
 * change, as text. Its data-ls-odoo-state says not-kept or kept.
 *
 * `<span data-ls-odoo-name>` is filled, as text, with the display name of the
 * person signed in to Odoo when the page loads (SM1145): from the answer to the
 * token fetch, which reads the identity cookie this script cannot read, so the
 * page costs no Odoo call to say who is here. It is left as it is when nobody is
 * signed in or the identity has lapsed (the next call that reaches Odoo
 * freshens it).
 */
(function (root) {
  'use strict';

  var API = {
    endpoint: '/cgi-bin/lazysite-odoo.pl',
    prompt: null            /* set below: asks the person to sign in */
  };
  var tokens = null;        /* { visitor_token, token, identity } for this page, in memory only */
  var pending = null;       /* the token fetch in flight, so two askers share one request */

  function doc() { return root.document; }

  /* SM1328 (ruling 52): the name the site gives Odoo, from the script tag the engine
   * adds (data-ls-odoo-display-name, '' for none); "Odoo" when the tag has none.
   * said(named, plain) is `named` with every {name} replaced by it, or `plain` when
   * the site gives no name - each text is written both ways, so neither has a hole. */
  function displayName() {
    var d = doc();
    var s = d && d.querySelector ? d.querySelector('script[data-ls-odoo-display-name]') : null;
    return s ? String(s.getAttribute('data-ls-odoo-display-name') || '') : 'Odoo';
  }
  function said(named, plain) {
    var n = displayName();
    return n ? named.split('{name}').join(n) : plain;
  }

  function url(query) {
    return API.endpoint + (query ? '?' + query : '');
  }

  function encodeQuery(params) {
    var out = [];
    Object.keys(params || {}).forEach(function (k) {
      var v = params[k];
      if (v === undefined || v === null) return;
      out.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)));
    });
    return out.join('&');
  }

  /* One request. Resolves { status, data } - never rejects on an HTTP status,
   * so a caller reads what the endpoint said; rejects only when it could not
   * ask at all. */
  function send(method, query, body, form, extra) {
    var opts = {
      method: method,
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { 'Accept': 'application/json' }
    };
    /* SM1223: the caller's Idempotency-Key, when the page gave one */
    if (extra) Object.keys(extra).forEach(function (k) { opts.headers[k] = extra[k]; });
    if (form) {
      /* SM1162: a FormData. No Content-Type here: the browser writes it, with the boundary. */
      opts.body = form;
    } else if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    return root.fetch(url(query), opts).then(function (res) {
      return res.text().then(function (text) {
        var data = null;
        try { data = JSON.parse(text); } catch (e) { data = null; }
        return { status: res.status, data: data };
      });
    });
  }

  /* The visitor token (and the session token, for a signed-in lazysite
   * account), fetched on demand and kept in memory only. */
  function getTokens(fresh) {
    if (tokens && !fresh) return Promise.resolve(tokens);
    /* SM1145: the name fill and a first POST both ask at load; one request answers both */
    if (pending && !fresh) return pending;
    var p = send('GET', 'csrf=1').then(function (r) {
      tokens = (r.data && r.data.ok) ? r.data : {};
      pending = null;
      return tokens;
    }, function (e) {
      pending = null;
      throw e;
    });
    pending = p;
    return p;
  }

  function withTokens(body, t) {
    var out = {};
    Object.keys(body).forEach(function (k) { out[k] = body[k]; });
    if (t && t.visitor_token) out.visitor_token = t.visitor_token;
    if (t && t.token) out.token = t.token;
    return out;
  }

  function isCsrf(r) { return r.status === 403 && r.data && r.data.kind === 'csrf'; }
  function isSignin(r) { return r.status === 401 && r.data && r.data.kind === 'signin-required'; }

  /* A POST with its token. A token the server calls stale is fetched again and
   * the POST sent once more - ONCE. */
  function post(body, hdr) {
    return getTokens(false).then(function (t) {
      return send('POST', '', withTokens(body, t), undefined, hdr).then(function (r) {
        if (!isCsrf(r)) return r;
        return getTokens(true).then(function (t2) {
          return send('POST', '', withTokens(body, t2), undefined, hdr);
        });
      });
    });
  }

  /* SM1223: opts.idempotencyKey is sent as the Idempotency-Key header of the one
   * call. A call sent again (a stale token, a sign-in) keeps it, so does a call the
   * page sends again after a failure: a repeat with the same key does not write
   * twice. The server checks its format (8 to 128 of letters, digits and . _ : -). */
  function keyHeader(opts) {
    return opts && opts.idempotencyKey !== undefined && opts.idempotencyKey !== null
      ? { 'Idempotency-Key': String(opts.idempotencyKey) } : undefined;
  }

  function get(params) { return send('GET', encodeQuery(params)); }

  /* SM1162: FILES. A File is a Blob. A value that is one (or a non-empty list of
   * them) is a file, and goes as a part of a multipart request; everything else
   * goes in the JSON part, as it always has. */
  function isBlob(v) { return !!root.Blob && v instanceof root.Blob; }
  function isFiles(v) {
    return isBlob(v) || (Array.isArray(v) && v.length > 0 && v.every(isBlob));
  }
  function splitFiles(params) {
    var plain = {}, files = {}, any = false;
    Object.keys(params || {}).forEach(function (k) {
      if (isFiles(params[k])) { files[k] = [].concat(params[k]); any = true; }
      else plain[k] = params[k];
    });
    return { plain: plain, files: any ? files : null };
  }

  /* One multipart POST: the JSON body (params and the token) as the part named
   * `json`, each file as a part named for its field. The binding is in the query
   * so the server knows its size cap before it reads the body. The FormData is
   * built afresh for each send, so a retry never reuses a spent one. */
  function formFor(binding, split, t) {
    var fd = new root.FormData();
    fd.append('json', JSON.stringify(withTokens({ binding: binding, params: split.plain }, t)));
    Object.keys(split.files).forEach(function (field) {
      split.files[field].forEach(function (b) { fd.append(field, b, b.name || 'file'); });
    });
    return fd;
  }

  function postFiles(binding, split, hdr) {
    var q = 'binding=' + encodeURIComponent(binding);
    return getTokens(false).then(function (t) {
      return send('POST', q, undefined, formFor(binding, split, t), hdr).then(function (r) {
        if (!isCsrf(r)) return r;
        return getTokens(true).then(function (t2) {
          return send('POST', q, undefined, formFor(binding, split, t2), hdr);
        });
      });
    });
  }

  /* The sign-in step of a call: if the endpoint says to sign in, ask the person
   * - once - and send the same call again - once. A cancelled or refused
   * sign-in ends it with the answer the endpoint gave. */
  function withSignin(attempt, opts) {
    return attempt().then(function (r) {
      if (!isSignin(r) || (opts && opts.prompt === false) || typeof API.prompt !== 'function') return r;
      return API.prompt(r.data && r.data.error).then(function (signedIn) {
        return signedIn ? attempt() : r;
      });
    });
  }

  /* run a READING binding: GET ?binding=ID&field=value */
  API.read = function (binding, params, opts) {
    var q = {}; Object.keys(params || {}).forEach(function (k) { q[k] = params[k]; });
    q.binding = binding;
    return withSignin(function () { return get(q); }, opts);
  };

  /* run a binding that may WRITE: POST {binding, params}. A write returns a
   * plan to confirm, or applies, as the binding says. */
  /* SM1162: a File, a Blob or a list of them among the params is sent as
   * multipart/form-data, the rest in its JSON part; the binding names which
   * request field is a file (file_params) and how large one may be. A binding
   * call with no file goes exactly as before. */
  API.write = function (binding, params, opts) {
    var split = splitFiles(params);
    if (split.files) {
      return withSignin(function () { return postFiles(binding, split, keyHeader(opts)); }, opts).then(autoUnknown).then(autoNotKept);
    }
    return withSignin(function () { return post({ binding: binding, params: params || {} }, keyHeader(opts)); }, opts)
      .then(autoUnknown).then(autoNotKept);
  };

  /* apply a plan this person made */
  API.confirm = function (plan, opts) {
    return withSignin(function () { return post({ plan: plan, confirm: true }, keyHeader(opts)); }, opts)
      .then(autoUnknown).then(autoNotKept);
  };

  /* SM1277 (rulings 10a, 10b): A WRITE WHOSE ANSWER NEVER CAME. An apply that left
   * a change `unknown` answers `run` (the run's handle) and `may_assume`. resume()
   * asks the endpoint to read the run back and finish it: POST {run, resume: true},
   * with opts.assumeDone / opts.assumeNotDone (change keys) when the person says a
   * change was, or was not, made. The server decides who may say so; a page only
   * offers it where the answer said `may_assume`. */
  API.resume = function (run, opts) {
    var body = { run: run, resume: true };
    if (opts && opts.assumeDone) body.assume_done = [].concat(opts.assumeDone);
    if (opts && opts.assumeNotDone) body.assume_not_done = [].concat(opts.assumeNotDone);
    return withSignin(function () { return post(body); }, opts);
  };

  /* The changes an answer says are still unknown: an apply's (its result's changes
   * with outcome unknown) or a resume refused unknown-outcome (its changes). */
  function unknownOf(data) {
    if (!data) return [];
    if (data.kind === 'unknown-outcome') return data.changes || [];
    var ch = (data.result && data.result.changes) || [];
    return ch.filter(function (c) { return c && c.outcome === 'unknown'; });
  }

  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  /* Draws, into `node`, what an answer left unknown - as text, never markup - with
   * "Check again", and "It was made" / "It was not made" for each change only when
   * the answer says this person may say. Each button resumes the run and draws the
   * answer it gets in the same place: settled, refused again (with the same
   * choices), or a new run left unknown. data-ls-odoo-state says which: unknown,
   * settled or stale. opts.onAnswer(r) is told each answer. */
  API.showUnknown = function (node, data, opts) {
    var d = doc();
    if (!d || !node) return;
    clear(node);
    if (!data || !data.run) { node.setAttribute('data-ls-odoo-state', 'stale'); return; }
    node.setAttribute('data-ls-odoo-state', 'unknown');
    var one = unknownOf(data).length === 1;
    node.appendChild(el('p', { role: 'status' }, said('It is not known whether {name} made '
      + (one ? 'this change.' : 'these changes.'),
      'It is not known whether ' + (one ? 'this change was' : 'these changes were') + ' made.')));
    var list = el('ul');
    var buttons = [];
    function go(o) {
      buttons.forEach(function (b) { b.disabled = true; });
      return API.resume(data.run, o).then(function (r) {
        if (opts && typeof opts.onAnswer === 'function') opts.onAnswer(r);
        var a = r.data || {};
        if (a.run && (a.unknown || a.kind === 'unknown-outcome')) { API.showUnknown(node, a, opts); return r; }
        clear(node);
        node.setAttribute('data-ls-odoo-state', a.ok ? 'settled' : 'stale');
        node.appendChild(el('p', { role: 'status' }, a.ok ? 'Done.' : (a.error || 'That did not work.')));
        notKeptOf(a).forEach(function (c) { node.appendChild(el('p', { role: 'status' }, String(c.note || ''))); });
        autoNotKept(r);
        return r;
      }, function () {
        buttons.forEach(function (b) { b.disabled = false; });
        node.setAttribute('data-ls-odoo-state', 'stale');
      });
    }
    unknownOf(data).forEach(function (c) {
      var name = c.key !== undefined && c.key !== null && c.key !== '' ? String(c.key) : String(c.seq);
      var li = el('li');
      li.appendChild(el('span', { 'data-ls-field': 'change' },
        [name, c.action, c.model].filter(function (x) { return x !== undefined && x !== null && x !== ''; }).join(' ')));
      if (data.may_assume === 1 || data.may_assume === true) {
        var made = el('button', { type: 'button' }, 'It was made');
        var not = el('button', { type: 'button' }, 'It was not made');
        made.addEventListener('click', function () { go({ assumeDone: [name] }); });
        not.addEventListener('click', function () { go({ assumeNotDone: [name] }); });
        li.appendChild(made);
        li.appendChild(not);
        buttons.push(made, not);
      }
      list.appendChild(li);
    });
    node.appendChild(list);
    var again = el('button', { type: 'button' }, 'Check again');
    again.addEventListener('click', function () { go({}); });
    buttons.push(again);
    node.appendChild(again);
  };

  /* A write or a confirm whose answer left a change unknown is drawn into the page's
   * [data-ls-odoo-unknown] element, when it has one. */
  function autoUnknown(r) {
    var d = doc();
    var a = r && r.data;
    if (!d || !a || !a.run || !(a.unknown || a.kind === 'unknown-outcome')) return r;
    var node = d.querySelector && d.querySelector('[data-ls-odoo-unknown]');
    if (node) API.showUnknown(node, a);
    return r;
  }

  /* SM1347 (ruling 103): the changes of an applied answer (a write, a confirm, a
   * resume's carried changes) that Odoo did not keep as asked. Each names its
   * fields (`not_kept`) and carries the server's sentence (`note`); the values asked
   * and found are never in the answer. */
  function notKeptOf(data) {
    var ch = (data && data.result && data.result.changes) || [];
    return ch.filter(function (c) { return c && c.not_kept && c.not_kept.length; });
  }
  API.notKept = notKeptOf;

  /* Draws, into `node`, as text, one line per change Odoo did not keep. */
  API.showNotKept = function (node, data) {
    if (!doc() || !node) return;
    clear(node);
    var list = notKeptOf(data);
    node.setAttribute('data-ls-odoo-state', list.length ? 'not-kept' : 'kept');
    list.forEach(function (c) { node.appendChild(el('p', { role: 'status' }, String(c.note || ''))); });
  };

  /* An applied answer is drawn into the page's [data-ls-odoo-not-kept], when it has one. */
  function autoNotKept(r) {
    var d = doc();
    var a = r && r.data;
    if (!d || !a || !a.result) return r;
    var node = d.querySelector && d.querySelector('[data-ls-odoo-not-kept]');
    if (node) API.showNotKept(node, a);
    return r;
  }

  /* sign a person in. The password is in this call's argument and the request
   * body and nowhere else; the caller clears its own box. Resolves the
   * endpoint's answer: { status, data } with data.identity.name on success. */
  /* SM1299 (ruling 37): a sign-in page's return. A button carrying
   * data-ls-odoo-next sends the page's own ?next= with the sign-in, and the
   * endpoint answers the same-site path to go to (the check /login's return goes
   * through, or '/'); the page goes there once the person is signed in. Only that
   * answer is followed: this script never decides a destination itself. */
  var afterSignin = { next: null, to: null };
  function withNext(body) {
    if (afterSignin.next !== null) body.next = afterSignin.next;
    return body;
  }
  function keepNext(r) {
    if (afterSignin.next !== null && r && r.data && r.data.signed_in && typeof r.data.next === 'string') afterSignin.to = r.data.next;
    return r;
  }

  API.signIn = function (login, password) {
    return post(withNext({ signin: true, login: login, password: password })).then(function (r) {
      password = null;
      return keepNext(r);
    });
  };

  /* the second request of a two-factor sign-in: the code for the half-open
   * sign-in the server holds. Like the password, it is in this call's argument
   * and the request body and nowhere else. */
  API.signInCode = function (code, remember) {
    return post(withNext({ signin_code: true, code: code, remember: remember ? true : false })).then(function (r) {
      code = null;
      return keepNext(r);
    });
  };

  API.signOut = function () {
    return post({ signout: true });
  };

  /* SM1146: several calls in ONE request - POST {calls: [{binding, params}, ...]},
   * at most ten (the endpoint says so beyond that). Each call is a {binding,
   * params} or a {plan, confirm: true}, and each is answered in order with its own
   * `status`: resolves { status: 200, data: { ok, results: [...] } }, a failing
   * call leaving the others as they were. A call the endpoint refused for a stale
   * token is sent again ONCE, with fresh tokens; one it refused for want of a
   * sign-in, once more after the person has been asked ONCE - and only those
   * calls, never the whole batch. */
  function isCsrfResult(x) { return !!x && x.status === 403 && x.kind === 'csrf'; }
  function isSigninResult(x) { return !!x && x.status === 401 && x.kind === 'signin-required'; }

  API.batch = function (calls, opts) {
    var list = (calls || []).slice();
    /* SM1162: a batch carries no files; each file goes in a write() of its own */
    var withFile = list.some(function (c) {
      return c && c.params && Object.keys(c.params).some(function (k) { return isFiles(c.params[k]); });
    });
    if (withFile) return Promise.reject(new Error('a batch carries no files: send each call with a file as its own write()'));
    function run(items) { return post({ calls: items }); }
    return run(list).then(function (r) {
      if (r.status !== 200 || !r.data || !r.data.results) return r;
      var results = r.data.results.slice();
      /* the calls `pred` picks are sent once more, if `before` says to */
      function redo(pred, before) {
        var idx = [];
        results.forEach(function (x, i) { if (pred(x)) idx.push(i); });
        if (!idx.length) return Promise.resolve();
        return before(results[idx[0]]).then(function (go) {
          if (!go) return;
          return run(idx.map(function (i) { return list[i]; })).then(function (r2) {
            if (r2.status !== 200 || !r2.data || !r2.data.results) return;
            idx.forEach(function (i, k) { results[i] = r2.data.results[k]; });
          });
        });
      }
      return redo(isCsrfResult, function () {
        return getTokens(true).then(function () { return true; });
      }).then(function () {
        return redo(isSigninResult, function (first) {
          if ((opts && opts.prompt === false) || typeof API.prompt !== 'function') return Promise.resolve(false);
          return API.prompt(first && first.error);
        });
      }).then(function () {
        r.data.results = results;
        return r;
      });
    });
  };

  /* SM1145: who is signed in to Odoo - { name } from the token fetch, or
   * null. Asks Odoo nothing. */
  API.who = function () {
    return getTokens(false).then(function (t) {
      return (t && t.identity) || null;
    }, function () { return null; });
  };

  /* fills every [data-ls-odoo-name] with the display name, as text; a page with
   * no such node makes no request for it */
  API.showName = function () {
    var d = doc();
    if (!d) return Promise.resolve();
    var nodes = d.querySelectorAll('[data-ls-odoo-name]');
    if (!nodes.length) return Promise.resolve();
    return API.who().then(function (id) {
      var named = !!(id && id.name);
      if (named) for (var i = 0; i < nodes.length; i++) nodes[i].textContent = String(id.name);
      banner(named);
    });
  };

  /* SM1160: the page's "Signed in as <name>" (the engine's odoo_signin_banner): the signed-in
   * part shows when there is a name, the sign-in link when there is not. Display only. */
  function banner(signedIn) {
    var d = doc();
    [].slice.call(d.querySelectorAll('[data-ls-odoo-in]')).forEach(function (n) { n.hidden = !signedIn; });
    [].slice.call(d.querySelectorAll('[data-ls-odoo-out]')).forEach(function (n) { n.hidden = !!signedIn; });
  }

  /* ---- the sign-in prompt -------------------------------------------------- */

  function el(tag, attrs, text) {
    var d = doc();
    var n = d.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    if (text !== undefined) n.textContent = text;
    return n;
  }

  /* Asks the person for their Odoo login and password. Resolves true when
   * signed in, false when they cancel or the sign-in is refused. ONE attempt per
   * ask: a refusal says so in the box and the person can try again, but each
   * try is a fresh ask from the person, never a loop in this script. */
  API.prompt = function (why) {
    var d = doc();
    if (!d || !d.body) return Promise.resolve(false);
    return new Promise(function (resolve) {
      var box = el('div', { role: 'dialog', 'aria-modal': 'true', 'aria-label': said('Sign in to {name}', 'Sign in'), 'data-ls-odoo-prompt': '' });
      var form = el('form', { autocomplete: 'on' });
      var msg = el('p', { role: 'alert' }, why || said('Sign in to {name} to continue.', 'Sign in to continue.'));
      var login = el('input', { type: 'text', name: 'login', autocomplete: 'username', 'aria-label': said('{name} login', 'Login'), required: 'required' });
      var pass = el('input', { type: 'password', name: 'password', autocomplete: 'current-password', 'aria-label': said('{name} password', 'Password'), required: 'required' });
      var go = el('button', { type: 'submit' }, 'Sign in');
      var no = el('button', { type: 'button' }, 'Cancel');
      [msg, login, pass, go, no].forEach(function (n) { form.appendChild(n); });
      box.appendChild(form);

      function close(result) {
        pass.value = '';
        if (box.parentNode) box.parentNode.removeChild(box);
        resolve(result);
      }

      function signedIn(r) {
        close(true);
        var who = doc().querySelectorAll('[data-ls-odoo-name]');
        for (var i = 0; i < who.length; i++) {
          who[i].textContent = (r.data.identity && r.data.identity.name) || '';
        }
      }

      /* The dialog's second step: ask for Odoo's code. The password fields go;
       * the sign-in itself is waiting at the server, not here. */
      function askCode(offerRemember) {
        var cform = el('form', { autocomplete: 'off' });
        var cmsg = el('p', { role: 'alert' }, 'Enter the 6-digit code from your authenticator app.');
        var code = el('input', { type: 'text', name: 'code', inputmode: 'numeric', autocomplete: 'one-time-code',
          maxlength: '12', 'aria-label': 'Authenticator code', required: 'required' });
        var remember = null;
        var rlabel = null;
        if (offerRemember) {
          remember = el('input', { type: 'checkbox', name: 'remember', id: 'ls-odoo-remember' });
          rlabel = el('label', { 'for': 'ls-odoo-remember' }, "Don't ask again on this device");
        }
        var verify = el('button', { type: 'submit' }, 'Verify');
        var cancel = el('button', { type: 'button' }, 'Cancel');
        [cmsg, code].concat(remember ? [remember, rlabel] : [], [verify, cancel]).forEach(function (n) { cform.appendChild(n); });
        box.removeChild(form);
        box.appendChild(cform);
        code.focus();

        cancel.addEventListener('click', function () {
          code.value = '';
          API.signOut().then(function () {}, function () {});   /* ends the half-open sign-in at Odoo */
          close(false);
        });
        cform.addEventListener('submit', function (ev) {
          ev.preventDefault();
          var c = code.value, rem = remember ? remember.checked : false;
          code.value = '';               /* gone from the page before the answer arrives */
          verify.disabled = true;
          API.signInCode(c, rem).then(function (r) {
            c = null;
            verify.disabled = false;
            if (r.status === 200 && r.data && r.data.ok) { signedIn(r); return; }
            if (r.data && r.data.kind === 'signin-required') {
              /* the half-open sign-in has run out: back to the password */
              box.removeChild(cform);
              box.appendChild(form);
              msg.textContent = r.data.error || 'The sign-in has run out. Sign in again.';
              login.focus();
              return;
            }
            cmsg.textContent = (r.data && r.data.error) || 'That code did not work.';
            code.focus();
          }, function () {
            c = null;
            verify.disabled = false;
            cmsg.textContent = said('{name} could not be reached. Try again.', 'No answer came. Try again.');
          });
        });
      }

      no.addEventListener('click', function () { close(false); });
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var l = login.value, p = pass.value;
        pass.value = '';                 /* gone from the page before the answer arrives */
        go.disabled = true;
        API.signIn(l, p).then(function (r) {
          p = null;
          go.disabled = false;
          if (r.status === 200 && r.data && r.data.ok && r.data.second_factor === 'totp') {
            askCode(r.data.remember_offered === 1 || r.data.remember_offered === true);
            return;
          }
          if (r.status === 200 && r.data && r.data.ok) { signedIn(r); return; }
          msg.textContent = (r.data && r.data.error) || 'That sign-in did not work.';
          login.focus();
        }, function () {
          p = null;
          go.disabled = false;
          msg.textContent = said('{name} could not be reached. Try again.', 'No answer came. Try again.');
        });
      });

      d.body.appendChild(box);
      login.focus();
    });
  };

  /* ---- regions ------------------------------------------------------------- */

  function fill(node, row, allowed) {
    var slots = node.querySelectorAll('[data-ls-field]');
    for (var i = 0; i < slots.length; i++) {
      var name = slots[i].getAttribute('data-ls-field');
      if (allowed && !Object.prototype.hasOwnProperty.call(allowed, name)) continue;
      var v = row[name];
      if (v === undefined) continue;
      slots[i].textContent = v === null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
    }
    return node;
  }

  function render(el_, rows, fields) {
    var tpl = el_.querySelector('template');
    if (!tpl) return;
    var empty = el_.querySelector('[data-ls-empty]');
    var frag = doc().createDocumentFragment();
    for (var i = 0; i < rows.length; i++) {
      frag.appendChild(fill(tpl.content.cloneNode(true), rows[i], fields));
    }
    var kill = [];
    for (var c = el_.firstChild; c; c = c.nextSibling) {
      if (c === tpl || (empty && c === empty)) continue;
      kill.push(c);
    }
    kill.forEach(function (n) { el_.removeChild(n); });
    el_.insertBefore(frag, empty || null);
    if (empty) empty.hidden = rows.length > 0;
    el_.setAttribute('data-ls-odoo-state', 'ready');
  }

  function params(el_) {
    var out = {};
    var attrs = el_.attributes;
    for (var i = 0; i < attrs.length; i++) {
      var m = /^data-ls-odoo-(.+)$/.exec(attrs[i].name);
      if (!m || /^(state|prompt|signin|signout|name|in|out|banner|unknown)$/.test(m[1])) continue;
      out[m[1]] = attrs[i].value;
    }
    return out;
  }

  /* exposed so a template author can fill a node the same way, and so the test
   * can hold that a field the server refused to draw is never filled */
  API.fill = fill;

  API.load = function (el_) {
    if (el_.getAttribute('data-ls-odoo-state') === 'loading') return Promise.resolve();
    el_.setAttribute('data-ls-odoo-state', 'loading');
    var prompt = el_.hasAttribute('data-ls-odoo-prompt');
    return API.read(el_.getAttribute('data-ls-odoo'), params(el_), { prompt: prompt }).then(function (r) {
      if (isSignin(r)) {
        /* Nothing is shown in place of what needs a sign-in; what was there stays. */
        el_.setAttribute('data-ls-odoo-state', 'signin-required');
        return;
      }
      var rep = r.data && r.data.report;
      if (r.status !== 200 || !r.data || !r.data.ok || !rep || !rep.rows) {
        el_.setAttribute('data-ls-odoo-state', 'stale');
        return;
      }
      render(el_, rep.rows, r.data.fields || null);
    }, function () {
      el_.setAttribute('data-ls-odoo-state', 'stale');
    });
  };

  /* the page's own ?next=, as text ('' when it has none) */
  function pageNext() {
    var m = /[?&]next=([^&#]*)/.exec((root.location && root.location.search) || '');
    if (!m) return '';
    try { return decodeURIComponent(m[1].replace(/\+/g, ' ')); } catch (e) { return ''; }
  }

  function start() {
    var d = doc();
    if (!d) return;
    API.showName();
    [].slice.call(d.querySelectorAll('[data-ls-odoo]')).forEach(function (el_) { API.load(el_); });
    [].slice.call(d.querySelectorAll('[data-ls-odoo-signin]')).forEach(function (b) {
      b.addEventListener('click', function (ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        afterSignin.next = b.hasAttribute('data-ls-odoo-next') ? pageNext() : null;
        afterSignin.to = null;
        API.prompt().then(function (ok) {
          if (ok && afterSignin.to !== null) { root.location.assign(afterSignin.to); return; }
          if (ok) {
            tokens = null;                                   /* the sign-in changed who this is */
            API.showName();
            [].slice.call(d.querySelectorAll('[data-ls-odoo]')).forEach(function (r) { API.load(r); });
          }
        });
      });
    });
    [].slice.call(d.querySelectorAll('[data-ls-odoo-signout]')).forEach(function (b) {
      b.addEventListener('click', function (ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        API.signOut().then(function () { root.location.reload(); });
      });
    });
  }

  root.LazysiteOdoo = API;
  if (root.document) {
    if (root.document.readyState === 'loading') {
      root.document.addEventListener('DOMContentLoaded', start);
    } else {
      start();
    }
  }
})(typeof window !== 'undefined' ? window : globalThis);
