---
title: "SM461: the all-files history overview is broken, and it is in the wrong place"
subtitle: "It fails with a JSON parse error while the data behind it is fine. And seeing it at all requires granting the Files app - full read and write over content - to anyone who only needs to know what changed."
brand: plain
standard-margins: true
status: shipped
status-note: "BUG HALF FIXED (PENDING), PLACEMENT HALF STILL OPEN, and the status stays `partial` for that reason. THE FIX: the overview parsed any response with r.json() and no status or content-type check, so a 500, an uncaught die or a proxy timeout page became 'JSON.parse: unexpected character at line 1 column 1' - a message that blames the DATA for a fault in the fetch, and sends an operator to look at their content. SM445 had fixed the 401 case in the shared wrapper; the rest of the class had not gone away. window.mgJson now checks status AND content type and reports what actually came back, and the overview is shown again (following whether content history is enabled, since a site without it can only answer 'not enabled'). STILL OPEN AND UNTOUCHED: seeing the overview requires the Files app, which is full read and write over content. An auditor who needs to know what changed should not need permission to change it, and whether that is a new capability or an existing one extended remains the release manager's call. PARTIAL in 0.10.22 (6e2d694): the card is HIDDEN, not fixed. The release manager's call, and the right one for a beta - an overview that reports a parse error against data it fetched successfully teaches an operator to distrust the panel, and there is nothing they can do about it. WHAT REMAINS, both halves, and neither is done: the fetch still has no status or content-type check, so any non-JSON body is still reported as malformed data; and the PLACEMENT argument is untouched - seeing the history still requires the Files app, which is full read and write over content. Destined for edge. ORIGINAL FILING FOLLOWS. FILED 2026-08-21 from the field, in two parts, and the SECOND is the reason to act. THE BUG: the 'Content history - all files' overview at the top of the Files app shows Loading... and then 'Error: JSON.parse: unexpected character at line 1 column 1'. THE DATA IS FINE - git-history-summary over the control API returns valid JSON on that site, 15,307 bytes, 131 files - so the fault is in the manager's request or its handling, not in the action. CONFIRMED IN THE SOURCE: the overview does fetch(...).then(r => r.json()).catch(e => 'Error: ' + e.message), with no status or content-type check, so ANY non-JSON body becomes a parse error attributed to the data. Column 1 is what JSON.parse says when handed something that is not JSON at all, usually HTML beginning with '<'; with a delay first that points at a timeout page, a login redirect, or an uncaught die. PARTLY IMPROVED ALREADY: SM445 taught the shared fetch wrapper to notice a 401 and say the session has expired, so that case is now diagnosed by a banner even though the panel still prints the parse error. A non-401 HTML body - a 500, a die, a proxy timeout - is still reported as if the JSON were malformed. Reproducing it needs a browser: every manager Files action is cookie-only, so the reporter could not make the failing call at all, and capturing the raw response body is the one-look answer. THE PLACEMENT IS THE OPERATOR'S POINT AND THE BETTER ONE. An all-files history overview is not a file operation - it is a report about the repository, sitting at the top of a file browser where nothing else shares its scope. content-history is ALREADY a plugin, in plugin-list with its own description and enable/disable, and it has no view; stats is the precedent for a plugin that owns one. THE ACCESS ARGUMENT IS THE STRONGEST PART: today, letting somebody see the history overview means giving them the Files app, which is full read and write over content. There is no way to say 'you may see what changed and when' without also saying 'you may edit anything'. An auditor or reviewer needs the first and not the second, and over-granting to satisfy a reporting need is how an estate acquires more editors than it meant to have. So the requirement is that seeing the history be grantable WITHOUT granting Files - analytics is the model, read-only, off by default, unlocking one view. Whether that is a new capability or an existing one extended is the release manager's call. KEEP AS IS: the per-file History panel. That one IS a file operation, it belongs beside the file, and its scope matches the app it sits in. CLOSED 2026-08-23 BY DECISION, AND THE DECISION DECLINES THE REQUIREMENT - which is worth stating rather than leaving as an absence. The field agent asked that seeing the history be grantable WITHOUT granting Files, on the analytics model. The release manager's answer is that the overview STAYS IN FILES and no new capability is created: the surface's readers already hold what it needs, so the permission question never arises. What that costs is exactly what was asked for - an operator who wants somebody to see the history overview must grant them Files, and there is no narrower grant. What it buys is not paying the nine-point parity cost DP-1 measured for a read-only view, and not widening manage_content by implication. If the narrower grant is wanted later it is a new filing with that as its whole subject, not a loose end on this one. THE BUG HALF SHIPPED in 0.10.26 (797aaff): a non-JSON body is no longer reported as malformed data."
---

# Two separate things

```datatable
columns: | Says | Actually
widths: 4cm | 6cm | X
bold: 1
tone: medium
---
The panel | `Error: JSON.parse: unexpected character at line 1 column 1` | the data is valid JSON, 131 files, fetched successfully over the API
The placement | a file operation | a report about the repository, gated behind full content write
```

# The bug: a parse error standing in for a cause

```javascript
fetch(API + '?action=git-history-summary')
  .then(function(r) { return r.json(); })          // no status, no content-type
  .catch(function(e) { body.innerHTML = 'Error: ' + e.message; });
```

Any non-JSON body becomes a parse error attributed to the data. Column 1 is
what `JSON.parse` says when handed something that is not JSON at all - usually
HTML - and the delay before it points at a timeout, a login redirect, or an
uncaught die.

**Partly improved already**: SM445 taught the shared wrapper to notice a 401
and say the session has expired, so that case now gets a banner. A non-401 HTML
body is still reported as though the JSON were malformed.

Reproducing it needs a browser - every manager Files action is cookie-only -
and the raw response body is the one-look answer.

# The placement, which is the part worth acting on

An all-files overview is a report about the repository. It sits at the top of a
file browser where nothing else shares its scope. `content-history` is already
a plugin with its own description and enable/disable, and no view of its own.
`stats` is the precedent.

::: widebox
**The access argument is the strongest part.** Letting somebody see the history
overview today means granting the Files app - full read and write over content.
There is no way to say *you may see what changed and when* without also saying
*you may edit anything*.

An auditor or a reviewer needs the first and not the second. Over-granting to
satisfy a reporting need is how an estate ends up with more editors than it
meant to have.
:::

So the requirement is that the history view be grantable **without** granting
Files. `analytics` is the model: read-only, off by default, unlocking one view.
Whether that is a new capability or an existing one extended is a decision, not
a detail.

# Not proposed

Moving the per-file History panel. That one IS a file operation, it belongs
beside the file, and its scope matches the app it sits in.
