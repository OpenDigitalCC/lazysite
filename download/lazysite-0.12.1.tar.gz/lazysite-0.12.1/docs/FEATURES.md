---
title: "Lazysite - Complete Feature Reference"
subtitle: "Everything lazysite has and does, and why - as of v0.12.1"
brand: plain
---

# What lazysite is

Lazysite is a Markdown-driven website engine and lightweight CMS written in
near-core Perl. You drop a `.md` file into a document root; on the first request
the processor renders it to HTML through a layout/theme, caches the result as a
sibling `.html`, and the web server serves that cache directly thereafter. There
is **no build step, no database, and no application server** - just CGI scripts, a
tree of Markdown, and a flat-file configuration. (For production speed the same
processor can run as a persistent per-site FastCGI pool - see Part X - but
plain CGI remains the default and the baseline.)

Around that core sits a full publishing and management stack: a browser-based
manager UI, a JSON control API, a WebDAV endpoint, an AI connector that speaks the
Model Context Protocol (MCP), built-in cookie authentication with OAuth 2.1 for
machine partners, per-file ownership and access control, an append-only audit
trail, theming with self-service activation (including one-call theme scaffolding
and an external-design ingestion path), first-class multi-site and multilingual
content, forms with pluggable delivery, the x402 payment protocol, and a
supply-chain-aware release pipeline.

## The single architectural idea

One sentence explains the shape of almost everything below:

> **One enforced core, many thin transports.**

Content is plain Markdown with YAML-ish front matter. The HTTP processor, WebDAV,
the MCP connector, the control API (and the proposed Gopher/Gemini servers) are all
**thin front-ends that translate a protocol into calls on the same shared action
handlers**. Every rule - capability checks, per-file ACLs, the deny-list, path
sanitisation, audit logging, cache invalidation - lives once, server-side, in that
core. A new access surface adds *no authority of its own*; it inherits correctness
for free. This is why the MCP connector's first version was ~300 lines, and why a
lock taken over WebDAV blocks a save in the manager UI, an ACL set in the UI gates
an MCP write, and every material change across all four doors lands in one audit
log tagged with its origin.

A second through-line: **publishing by AI partners is a first-class use case.** Many
features were driven by, and validated against, real Claude.ai and ChatGPT
connector sessions building real sites.

## Design constraints

- **Near-core Perl, minimal CPAN.** The processor runs on Text::MultiMarkdown +
  Template Toolkit + LWP + JSON::PP + Digest::SHA, all packaged by Debian. The only
  non-core *hard* extra is `Archive::Zip` (theme/zip handling); `DB_File` (rate
  limiting) and `Template::Plugin::JSON::Escape` (search index) are the other
  notable ones. The page processor (`lazysite-processor.pl`) is deliberately
  **self-contained** - it takes no project modules on its render path so it can be
  deployed as a single file.
- **Run-in-place or packaged.** The same code runs straight from a git checkout via
  the dev server, or installs into `cgi-bin/` + docroot via a manifest-driven,
  upgrade-aware installer.
- **Fail-closed on secrets, fail-open on availability.** Crypto/CSPRNG paths die
  rather than weaken; read-only settings consumers (is-this-account-disabled, rate
  stores) fail open so a corrupt file can't lock the operator out.

---

# Part I - The content model and processor

The processor (`lazysite-processor.pl`) is the heart: a single CGI that maps a URL
to a `.md`/`.url`/cached `.html` under the docroot, applies access control, renders,
caches, and emits the response.

## The request lifecycle

On each request the processor: localises `%ENV` (so per-request state can't leak
under a persistent interpreter); resolves the URL; denies the `lazysite/` system
directory outright; runs the **trust gate** (below); checks the manager-path gate;
sanitises the URI against traversal; runs the auth check, then the payment check,
then a preview-cookie check; serves from cache on the fast path; otherwise renders
the source. Managers bypass the cache so the injected admin bar is never baked into
anonymous HTML.

## Authoring: front matter

Front matter is the block between a leading `---` and the next `---`, parsed by a
deliberately minimal hand-rolled YAML-subset parser (zero non-core dependency, and
every value passes through a Template-Toolkit-directive stripper for safety). One
level of matching surrounding quotes is removed (`title: "Welcome"` → `Welcome`,
YAML semantics). Recognised keys:

| Key | Effect |
|---|---|
| `title`, `subtitle` | Page title/subtitle → `<title>`, `<h1>`, meta description, TT vars |
| `ttl` | Per-page cache lifetime in seconds; emits `Cache-Control: public, max-age=N` |
| `register` | List of registries this page joins (sitemap.xml, llms.txt, feeds, custom) |
| `tags` | Page tags, surfaced in `scan:`/registry objects |
| `date` | `YYYY-MM-DD` publication date for feeds and `scan:` sort (mtime fallback) |
| `tt_page_var` | Page-scoped Template-Toolkit variables (literal / `url:` / `scan:` / `${ENV}`) |
| `layout`, `theme` | Per-page layout/theme override (name or remote URL) |
| `raw` | Run the Markdown pipeline but emit **no layout wrapper** (default `text/plain`) |
| `api` | Body is **pure TT, no Markdown, no layout** - for clean JSON endpoints |
| `content_type` | Explicit `Content-type` header (with `raw`/`api`) |
| `query_params` | Allowlist of URL query params exposed as `[% query.x %]`; bypasses cache |
| `auth` | `required` / `optional` / `none` |
| `auth_groups` | Required group membership (also doubles as payment bypass groups) |
| `payment` + `payment_*` | x402 payment gating and its parameters |
| `search` | Include in the search index (defaults to the site `search_default`) |
| `form` | Names and enables a form on the page (must match `forms/NAME.conf`) |
| `aliases` | YAML list of old/alternate site-local URLs the page also answers to (301 → canonical) |
| `aliases_temp` | Same list syntax, but the redirect is a temporary 302 (SM134 follow-ups) |
| `nocache` | `true` renders the page fresh on every request, never served from or written to cache |

A single-pass memoised "peek" reads the front matter **once per request** (keyed by
`path:mtime`) - historically the same file was opened five times.

## Authoring: the Markdown pipeline and fenced constructs

Custom fenced blocks are expanded to HTML *before* Text::MultiMarkdown runs, in a
fixed order: forms → `:::` divs → includes → code fences → oEmbed → MultiMarkdown →
Template Toolkit + layout → link fix-ups. Inline `<script>` blocks are protected
from the Markdown engine and restored afterward, and spurious `<p>` wrappers that
MultiMarkdown puts around top-level block HTML (`<p><section>…`) are stripped.

- **`::: classname` boxes** → `<div class="classname">…</div>`. Class names are
  allow-list-validated; the box body is itself run through Markdown so headings and
  lists inside a box render properly. The default layout's CSS provides `widebox`,
  `textbox`, `marginbox`, `examplebox`.
- **`::: include`** pulls another local file or remote URL inline, with extension-
  aware handling (`.md` → recursively rendered, code files → syntax-fenced, others →
  escaped). A `ttl=N` modifier lets a remote include drive page cache lifetime, and
  TT-variable source paths are resolved in a second pass. No recursion (loop-safe).
- **` ```lang ` code fences** → escaped `<pre><code class="language-LANG">`.
- **`::: oembed`** embeds YouTube/Vimeo/PeerTube/Twitter/SoundCloud (with endpoint
  autodiscovery) and **bakes the result into the cached page** - no client-side API
  calls.
- **`::: form`** renders an accessible HTML form from a compact `name | label | rules`
  grammar. Field types: text, `email`, `tel`, `date`, `time`, `number` (with
  `min`/`max`), `url`, `password`, `textarea`, and `select:a,b,c` (multi-word options
  supported); plus `required`/`optional`, `max:N`, `pattern:"…"`, `placeholder:"…"`.
  Each form carries an HMAC time-token, a honeypot field, and an inline `fetch`-based
  submit handler that swaps to a success message - wired to a delivery handler (see
  Forms).
- **`::: qr data="…"`** renders a QR code for the given value (a link, a payment
  URL, a wifi string, …), with an optional `size="N"` in pixels. It is a built-in
  content component - available on any layout - drawn client-side from the shared,
  self-contained `/assets/qrcode.js` (bundled qrcode-generator, MIT; in the SBOM).
  The value is only ever computed into a matrix, never inserted as markup, so there
  is no injection surface. Pass the value in `data="…"` (not the fence body, which
  Markdown would reflow).

Built-in content components live under `lazysite/templates/components/` and are the
fallback for the `::: name` component syntax: a `::: name` fence resolves against the
active layout's `components/NAME.tt` first, then the built-in dir - so a layout can
override a built-in, and built-ins (like `qr`) work everywhere.

## Layouts and themes (decision D013)

Layouts and themes are split. A layout (`lazysite/layouts/NAME/layout.tt`) is the
structural HTML/Template-Toolkit skeleton; themes nest beneath it
(`layouts/NAME/themes/THEME/`) and supply CSS custom properties generated from
`theme.json` into a `:root { --theme-… }` block. A theme declares which layouts it is
compatible with and is **ignored (with a warning) against an incompatible layout**  - 
a broken theme is cosmetic, a broken layout breaks every page, so they are governed
by separate capabilities. Layouts and themes can be local or fetched from a remote
URL (cached, sandboxed, assets bundled). If no layout is installed at all, an
**embedded fallback layout** renders a complete, self-styled page - the site always
renders. The manager has its own dedicated, non-themeable layout.

## Generated outputs: registries, scan, search

Pages opt into **registries** via `register:`; each registry is a Template-Toolkit
template (`templates/registries/NAME.tt`) rendered to an output file  - 
`sitemap.xml`, `llms.txt`, `feed.rss`, `feed.atom`, or any custom one you drop in. A
recursive page scan collects registered pages; regeneration is TTL-gated (4h) and
only happens on a real render. The **`scan:` directive** turns
`scan:/path/**/*.md filter=… sort=…` into an array of page objects (url, title,
date, tags, excerpt, searchable) usable in any template - the basis for blog
indexes, card grids, and the search index.

## Remote content and dynamic data

A `.url` file contains a single URL; the processor fetches it, renders the remote
body through the full pipeline, and caches it - with a TTL so the refetch happens on
the *next* request after expiry, never blocking the current visitor. Site variables
in `lazysite.conf` can likewise be `url:` (fetched JSON usable via TT) or `scan:`
(directory scans). Allow-listed CGI environment variables interpolate into config
(`${SERVER_NAME}` etc.; the untrusted `HTTP_HOST` is deliberately excluded). Query
parameters declared by a page are exposed as `[% query.x %]` and make that response
uncacheable. The visitor's own IP is available as `[% client_ip %]` - the first hop
of `X-Forwarded-For` (the real client behind a reverse proxy) if present, else the
direct peer `REMOTE_ADDR`, sanitised to IP characters; because it is per-request it
is used on a `nocache: true` page (or a small `nocache` JSON endpoint fetched by
client-side script so the display page stays cached) (SM135).

## Multilingual language sets (SM179)

A site can carry several **sibling per-language content roots** - one docroot
subtree per language - bound together by a shared `lang_group` (settable per site
in `lazysite.conf`, on a domain via `domain-set`, on the CLI, and on the Domains
Add + Configure forms). Each root declares its own `lang` (`en`, `fr`, `th`, …),
which the processor threads through the response: `<html lang="…">`, a
`Content-Language` header, `hreflang` alternates plus an `x-default` (emitted in
both the layout `<head>` and `sitemap.xml`), and an engine-supplied
`[% languages %]` switcher structure a layout renders into a language menu (the
current language flagged, each sibling's URL resolved). A `lang:` value is
sanitised to a bare language tag before it reaches `<html lang>` or the header - the
0.8.0 review fixed a stored-XSS / response-header-injection path where an
unsanitised front-matter `lang:` from a content-only partner reached both
unescaped.

Chrome is localised too. Layout template strings resolve through `[% t %]` (a
per-language string table), `json:` site variables resolve **content-root-first**
(so a per-language data file overrides a shared one), and the engine's own emitted
pages - the bare 404, the no-`403.md` fallback, and the auth reject pages - are
localised from a built-in English table overlaid by `lazysite/i18n/<lang>.json`
(fail-closed: a missing string falls back to English; the 404 fallback escapes the
request URI). A `lang-status` action (gated `manage_content`) reports per-language
coverage, and `whoami` / the MCP discovery surface report a configured language set
even when `lang_group` is declared only on the domain aliases. A **conf-only change
now invalidates the page cache**, so a language or chrome edit is never served
stale under any process model, and per-host caches are listed and cleared per host
on the Cache page (SM179 P8).

## Caching

Rendered HTML is cached as a sibling `.html`, served when newer than its source (or
within a page `ttl`). Writes are **atomic** (temp-then-rename), **refuse zero-byte
output** (an empty cache file would permanently shadow regeneration), and are
**realpath-guarded** against symlink escapes. A separate content-type cache
preserves custom headers across cache hits, and Template Toolkit keeps an on-disk
compiled-template cache - an unwritable compile cache cannot break rendering: the
render retries once without it, a failed manager-layout render shows a loud error
banner naming the TT error (public pages keep the silent fallback chrome), and
`lazysite-check` probes `cache/tt` writability (`--fix` clears the tree - it is a
pure cache). The whole cache base can be relocated off the docroot via
`LAZYSITE_CACHE_DIR` (used by the dev server's browse mode so it writes nothing into
a tree it is merely viewing). `LAZYSITE_NOCACHE=1` forces a one-off uncached render.

Cache is bypassed for: `nocache: true` pages (rendered fresh every request, for
genuinely per-request content such as `[% client_ip %]`), query-param requests,
auth/payment-protected pages, and previews. **Alias redirects** are resolved on the
no-source-found path only, so a cached real page always takes precedence over an
alias (`aliases:` for 301s, `aliases_temp:` for 302s - SM134 + follow-ups).

## Render-time security

- **Path traversal**: URI sanitisation rejects null bytes, `..`, and dangerous
  characters; every read and write realpath-checks that the target stays inside the
  docroot.
- **No directory listing**: a directory resolves only if it contains `index.md`,
  else 404 - there is no autoindex anywhere in the processor.
- **System-dir & sidecar deny**: `/lazysite/*` → 403; `*.brief` authoring sidecars →
  404 (and excluded from scans/registries).
- **Template-injection defence**: front-matter values and resolved variables are
  stripped of `[%`/`%]`; every Template instance runs with `EVAL_PERL => 0`.
- **Script-capable `content_type` downgrade** (ADR 0006, 0.8.0): a `raw:`/`api:`
  page may not serve a script-capable type - `text/html`, XHTML or SVG is
  downgraded to `text/plain` at serve time, closing a stored-XSS path a
  content-only delegate could otherwise reach. 0.9.12 extended the same rule to the
  **write path**: the manager save and WebDAV PUT refuse such a page outright (415),
  so raw content stays themed and on the no-CDN policy rather than being caught only
  at render.
- **SSRF defence**: every outbound fetch (remote pages, includes, oEmbed, `url:`
  vars, remote layouts) is screened against loopback/private/link-local/metadata
  addresses before any network I/O.
- **Header spoof defence (the trust gate)**: the processor deletes client-supplied
  `X-Remote-*`/`X-Payment-*` headers unless a trusted source set them (see Auth).
- **Baseline response headers**: `X-Content-Type-Options: nosniff`,
  `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin`,
  and `Vary: Cookie`; protected pages are `no-store, private` and never cached.

## Engine-served system pages (SM201)

The engine's own pages - login, the credential-**claim** page, and the `402`/`403`/
`404` responses - are served from a protected **`lazysite/templates/system/`** tree
rather than depending on a copy inside the served content. Each route resolves
through a **three-tier fallback**: a content-root copy (so a site or a
content-rooted sub-domain may still override the look), then a docroot-root copy,
then the protected default. A deleted or never-seeded copy therefore **self-heals**
- a missing `/claim` page no longer 404s - and `lazysite-check` verifies each route
resolves.

---

# Part II - Authentication and identity

Authentication is provided by a thin wrapper CGI (`lazysite-auth.pl`) that sits in
front of the processor and manager: Apache routes everything through it
(`FallbackResource`), it validates a signed cookie, sets the trusted `X-Remote-*`
headers, then `exec`s the real target. The processor itself contains no auth code  - 
it only consumes the header contract.

## The session model

- **Signed cookies, no server-side session store on the request path.** The
  cookie carries an HMAC-signed `username:timestamp:sid:groups` payload - a
  stateless, tamper-evident session token with a short random session id
  (legacy 3-field cookies remain valid until natural expiry), `HttpOnly;
  SameSite=Lax`, `Secure` under HTTPS, 24-hour expiry, compared constant-time.
- **Sessions are visible and revocable** (SM141). Login appends one line (sid,
  user, time, IP, sanitised UA) to `lazysite/auth/sessions.jsonl` (24-hour
  self-pruning, loss-tolerant - a registry failure never blocks login), and
  cookie verification checks `lazysite/auth/revoked.json` (revoked sids +
  per-user `not_before`, which also kills pre-sid legacy cookies; an absent
  file costs one stat, a corrupt file fails open with a loud warning, never a
  lockout). The manager **Sessions** page lists live sessions and offers
  per-session Sign out and per-user Sign out everywhere; rotating the HMAC
  secret stays as the everyone-at-once lever.
- **Trusted headers + the trust gate.** Identity reaches the processor only as
  `X-Remote-User`/`-Groups`/`-Name`/`-Email` (names configurable). These are trusted
  *only* when a trusted source set them: the wrapper sets a one-shot trust signal
  after validating the cookie, and the processor's trust gate strips the headers
  otherwise. This two-signal model lets the built-in auth and an external auth proxy
  (Authentik/Authelia) share one header contract while staying spoof-proof; the edge
  web server is also expected to `RequestHeader unset` them (defence in depth).
- **CSRF.** Manager writes require an HMAC-over-(user, hour-bucket) token, accepted
  via header, JSON body, or query param, with a one-hour grace. The gate is keyed on
  **HTTP method** (every POST is a write) rather than an action allowlist, so a new
  write action can't be left unprotected. Static-token (API) clients are *exempt*
  (no cookie ⇒ no ambient authority ⇒ no CSRF vector), and combining cookie + token
  auth is refused so the exemption can't ride a browser session.

## Credentials

- **Store.** Flat files: `auth/users` (`username:hash`), `auth/groups`, and
  `auth/user-settings.json` (capabilities, expiry, TOTP, provenance). Editable by
  hand, the manager Users page, or `tools/lazysite-users.pl`.
- **Password hashing.** Salted iterated SHA-256 (100 000 iterations), constant-time
  verify, with transparent auto-rehash of any legacy unsalted hash on next login.
- **Machine tokens.** High-entropy `lzs_` bearer tokens (256-bit) used as the
  WebDAV/API/MCP password; stored hashed (single iteration suffices for a random
  secret, and avoids a 100k-iteration KDF on *every* WebDAV request), shown once,
  with a 24-hour default expiry.
- **Single-use secrets.** Setup/reset **claim** links and partner **pairing keys**
  are single-use, short-lived, hashed, and redeemed under a lock (no replay/races).
  The credential *holder* sets their own secret - the operator never sees it.
- **MFA (TOTP).** Optional RFC 6238 second factor (self-contained, no CPAN) plus
  recovery codes, with a replay-aware verification window.
- **Forgot-password.** Emails a setup link (gated on the SMTP plugin), always
  returning a generic response - no account/email enumeration.
- **Sub-user delegation.** A partner holding `create_sub_users` can mint scoped
  sub-accounts; onward delegation requires holding the capability itself (no
  escalation). An operator can **promote a sub-user to top level** (an
  operator-only clear of `managed_by`) and can separately set an explicit
  `scope_independent` flag that lifts the `created_by` scope ceiling; the
  provenance stamp is never rewritten (SM194). In the manager this is the
  **Content access** control - "Set by its own grants alone" - which also shows
  the chain of ancestors currently capping the account, so an operator can see
  whether the toggle would change anything (SM233).

Every gate runs *after* credential verification, so disabled/expired/MFA states
never act as an oracle for valid usernames or passwords. All randomness is CSPRNG
(`/dev/urandom`) and **fails closed**.

## OAuth 2.1 - the AI web path

Claude.ai's **web** connectors are OAuth-only (no static-bearer field), so
`lazysite-oauth.pl` + `Lazysite::Auth::OAuth` implement a minimal OAuth 2.1
authorization server: RFC 9728 + RFC 8414 discovery metadata, RFC 7591 dynamic
client registration, mandatory PKCE (S256), and access/refresh tokens. The consent
model reuses lazysite's one-time-code pattern: the operator mints a single-use
**connect code** from the Users page, the human pastes it at the consent screen to
prove they may act as that partner, and the issued token resolves to **the same
partner grant** (capabilities + ACLs) as a static bearer would. No secret is ever
typed into the third party. Tokens are stored hashed, short-lived, and
garbage-collected; the MCP server accepts either an OAuth access token or a
`partner:lzs_` static bearer and converges both on one enforcement path.

---

# Part III - Authorization: capabilities, ACLs, and the deny-list

Authorization is two layers - coarse per-actor **capabilities** and fine per-object
**ACLs** - both enforced in the shared core, plus a hard **deny-list**.

## Capabilities

Channel x action grants carried by **groups** (`groups-settings.json`, edited on
the manager Groups page); an account's rights are the union across its groups
(SM095, see `docs/adr/0003`). There are no per-account grants and no
inheritance - every grant is explicit. All four surfaces (manager UI, control
API, MCP, WebDAV) resolve through the one resolver
(`Lazysite::Auth::Settings::caps_for`); `whoami` reports the caller's full
effective set.

**Channels** (where you may operate):

| Capability | Gates |
|---|---|
| `ui` | The manager UI: login landing, the `/manager` gate, operator pages |
| `webdav` | The WebDAV publishing endpoint |
| `api` | The token control API |
| `mcp` | The MCP connector |

**Actions** (what you may do - you need a channel AND the action):

| Capability | Gates |
|---|---|
| `manage_content` | Content read/write (pages, assets) |
| `manage_nav` | Navigation read/save |
| `manage_forms` | Form configs and bindings |
| `manage_themes` | Theme activation and authoring under `lazysite/layouts/**` |
| `manage_layouts` | Layout activation and structure authoring |
| `manage_config` | `config-set`; site configuration + plugin registry |
| `manage_domains` | The multi-domain admin and portable site packages (split out of `manage_config`, SM160) |
| `manage_users` | User/group administration; the unrestricted operator bypass |
| `analytics` | Visitor-stats analysis (`analyse_visitors`) |
| `audit` | The audit trail (its own capability, split from analytics) |
| `notifications` | The manager notices bell - operator notifications such as form submissions and requests awaiting a response (SM136; seeded on `user-managers`) |
| `read_submissions` | Least-privilege read of stored form submissions, without the broader `manage_forms` (SM187) |
| `feedback` | Agent feedback over MCP (`submit_feedback`); off by default (0.9.0) |
| `create_sub_users` / `delegate_sub_user_creation` | Sub-account creation and onward delegation |

The per-account `ui` flag in `user-settings.json` survives only as the
human-vs-token account type (interactive login on/off), not as a capability.

Each MCP tool and control-API action declares its required capability; a token
client is confined to the control-API subset regardless of the cookie-manager
surface, and unknown actions are refused.

## Cross-plane consistency and service killswitches (0.9.0)

A surface-exposure audit across the four planes (cookie manager, control API, MCP,
WebDAV) drove two hardening changes that make authorisation uniform and explicit:

- **Cross-plane capability consistency.** The same resource was in places gated by
  different capabilities per plane. WebDAV nav/form editing now uses the
  fine-grained `manage_nav` / `manage_forms` (was `manage_config`), matching the
  API/MCP planes and the central `Capabilities` map. A drift-guard test pins the
  WebDAV `@DANGEROUS_EXT` list to its canonical source, and the capability-gate
  guarantee test fails the build if a capability-gated cookie mutator is ever left
  off the CSRF force-list (`site-backup-*` were capability-gated but not
  POST-forced - now closed). The grants resolved but not surfaced to the
  cookie-manager gate (`manage_domains` / `feedback` / `read_submissions`) all now
  take effect, pinned by a parity test.
- **Service killswitches.** Only WebDAV had the intended dual control (a conf
  killswitch plus a capability). The MCP server, OAuth server, control-API token
  path, and auth token-exchange were always-on and invisible. Each now has a conf
  killswitch (`mcp_enabled` / `oauth_enabled` / `control_api_enabled` /
  `token_exchange_enabled`), **default off**, read through one shared helper so the
  gates cannot drift, and surfaced as a toggle in the manager's **Services** section.
  A disabled surface refuses **before doing any work and discloses nothing** -
  MCP/OAuth refuse pre-auth including discovery; the control API refuses before
  verifying a token; a switched-off service answers `200 {ok:0,
  code:"service_disabled"}` rather than a misleading 404. This is the one BREAKING
  posture change of the 0.9 line: after upgrade an operator enables the surfaces it
  uses in Settings → Services; nothing is auto-migrated by design.

## Capability clarity in the manager

Several 0.9.x changes make the capability model legible rather than silent:

- **Grant-to-enable hints** (SM191): a capability-gated area a user cannot yet reach
  shows a hint telling an operator which capability to grant, rather than simply
  being absent.
- **Channel-surface ticks** (SM197): the permissions grid ticks only where a
  capability actually has a channel surface, so an impossible combination is never
  shown as available.
- **Inert-group warning** (SM198): a group carrying capabilities but no members is
  flagged as inert (it grants nothing until someone joins).
- **Dormant-capability indicators** (SM180): the Groups and Users capability grids
  flag a channel capability granted while its site service is switched off (a
  dormant grant that silently does nothing) - indicate, never block.

## Limiting who can see content

A site can restrict **a page, a file, a folder, or the whole site**, and the
restriction applies to visitors as well as to authors. The full reference,
including the resolution order and the per-channel table, is
`docs/architecture/access-control-model.md`.

There are two mechanisms, answering two questions:

Who may read a **page**
: `auth:` and `groups:` in the page's front matter, with `auth_default` in
  `lazysite.conf` as the site default.

Who may read or write a **path**
: the ACL store, `lazysite/auth/acls.json` - a file, a folder (covering
  everything beneath it), or `/` for the whole site including its assets.

**Protection is opt-in.** A file nobody has mentioned is public, and a site that
has never protected anything behaves exactly as it always did - which is what
made this safe to extend to existing sites. Note the corollary: `auth_default:
required` closes the **pages** and does not reach static files, so a wholly
private site wants a root ACL entry rather than the site default alone.

Two policies, differing in what a visitor gets:

- **Gated** - anonymous visitors are sent to sign in; the response is never
  stored by a shared cache.
- **Draft** - a 404, and absent from the sitemap, the feeds and search. Held-back
  content should not answer at guessable URLs, because a login form confirms the
  page exists.

Set it from the manager (Files -> a folder's actions, or the per-file
permissions editor), over MCP (`set_permissions`), or over the control API
(`acl-set`). One writer, so a section and a file are governed by the same store
and the same rules.

**Protected content is moved out of the document root**, into a private store
beside it, and moved back when the restriction is lifted. This is what makes the
restriction hold: there is nothing left in the served directory for a web server
to hand out, so no front-end rule is needed and none can be got wrong. A page's
notes travel with it, and any cached copy of the page is dropped.

A rule that names only who may **edit** leaves the content published - it
restricts authoring, not reading, and taking a public page offline to express
that would be the wrong answer.

The one exception is the **whole-site** rule, which cannot move anything: the
document root cannot be moved out of itself. It is enforced by the engine, and
the manager says so when you set one.

Backups include protected content, because a backup is how content is recovered.
Site packages and the content history do not - a package travels to another
organisation without the rules that govern the content, and a history can be
pushed to a remote. Both **report what they left behind** rather than leaving it
to be discovered.

**Verify it from outside**, because the front end decides whether a request ever
reaches the engine: `lazysite check --check-acl https://example.test` gates a
probe, fetches it anonymously under several file extensions, and fails if any
bytes come back. A plain `lazysite check` also fails if any protected file is
found sitting in the document root as well.

## Per-path ACLs: the model

The store maps a docroot-relative path to `{ owner, read:[…], write:[…] }`.
**No entry means allowed** (the account's namespace scope governs), the owner is
always allowed, and list entries may be a username or `@group` - matched
case-insensitively, with nested groups expanded. ACLs only ever *narrow* access,
and they bind identically across the manager, the control API, MCP and WebDAV
through one shared check, plus a module-free copy in the processor for the
public read path (ADR 0001; `t/lint/31` pins the pair).

The **two auth domains** differ in one respect: a cookie **operator** inside the
manager bypasses ACLs, but a **token/WebDAV/MCP partner is never an operator**
and is bound by per-file ownership like any external author - the linchpin that
stops external partners escalating. That bypass applies to the authoring
surfaces only, never to the anonymous read path. A partner's `@group`
memberships resolve from its account on every channel (SM288).

## The deny-list

A hard, exact-path deny set is never readable or writable through the content
tools: the HMAC secret, the user/group/settings files, and **any `*.pl` script**.
A config-driven layer adds blocked directories and extensions. The WebDAV
authoriser denies the whole `lazysite/` subtree **except** three gated carve-outs:
`nav.conf` (with `manage_nav` since 0.9.0), per-form `lazysite/forms/<name>.conf`
(with `manage_forms` since 0.9.0, but never `smtp.conf`/`handlers.conf` which hold
credentials), and
theme/layout authoring under `lazysite/layouts/**` (with the theme/layout
capabilities). `lazysite.conf` itself is never WebDAV-writable. The blocklist
applies on **reads too**, so script source can't be fetched. Failures return a
machine-readable `kind`: `blocked`, `blocked-config`, `not-found`, `permission`,
`binary`, `too-large`, `invalid-path`, or `exists`.

## Audit trail

A single append-only writer (`Lazysite::Audit`) records **material events only**  - 
state changes and security grants, never browsing - to `lazysite/logs/audit.log`,
used by every state-changing entry point. Each line is `ts | user | action | target
| ip | status | origin [| detail]`; `origin` distinguishes `ui` (cookie), `api`
(token), `dav`, `mcp`, `cli` (the users tool run from the shell, attributed to the
invoking OS identity), and `install`; `save` is recorded as `create` or `edit`;
failures record the reason. One entry per operation: each web surface audits its
own requests, and the users tool audits only when NOT driven through `--api`
(where the calling surface has already recorded the actor). Shell user management
(setup-sysop, add/remove/rename, credential and claim issue, group and
capability changes) is fully on the trail - secrets themselves never are. This is
deliberately **non-overlapping with the access log** - it answers *who changed
what, to what, when, from where, and the outcome*. The manager audit viewer
paginates (50/page), filters by user and by target (one file's history), links a
page target to its editor, and shows the failure reason on failed events.

The writer is failure-loud: the log is created umask-proof at `0664` (so the CLI
and the www-data CGI can always append to the same file via the setgid logs dir),
an owned file that lost its group-write bit self-heals on the next append, and a
write that still fails emits a WARN naming the lost action instead of vanishing.
The **Logging & forwarding** plugin can additionally forward each audit entry
(and, separately, application diagnostics) to syslog (`forward_audit` /
`forward_diagnostics` / `syslog_facility`) for an external collector -
best-effort, never blocking, with the on-disk log as the record.

---

# Part IV - Payment (x402)

A page marked `payment: required` is gated behind the **x402** HTTP payment
protocol. Verification follows the same trusted-header pattern as auth: an upstream
payment proxy sets `X-Payment-Verified: 1` (stripped by the same trust gate unless
trusted). Unpaid requests get `402 Payment Required` with an `X-Payment-Response`
JSON header describing the terms (amount converted to the asset's smallest unit,
USDC on Base by default), rendering a custom `402.md` if present. Authenticated
members of a page's `auth_groups` bypass payment entirely - membership substitutes
for per-article payment, reusing the auth-group machinery. A working demo ships
(`payment-demo.pl`).

---

# Part V - Publishing and management surfaces

The manager UI, control API, WebDAV, and MCP connector are four front-ends over the
same action handlers (`lib/Lazysite/Manager/*`), the same lock store, the same ACL
store, and the same audit log.

## The manager UI

A set of ordinary lazysite pages under a dedicated manager theme, calling the
control API over `fetch`. Access requires authentication plus the `ui`
capability granted through a group (SM138: the legacy `manager_groups` conf key
is retired - migrated groups received their capabilities explicitly). The pages:

- **Config** - schema-driven site settings (driven by the processor's own
  `--describe` descriptor), active layout/theme dropdowns, a plugin registry
  (tick to enable/disable discovered plugins), and - since 0.9.0 - a **Services**
  section whose toggles enable the remote surfaces (MCP / OAuth / control API /
  token exchange), each **off by default** (see Part III). The whole page now loads
  through `config-read` and saves each key through the audited, per-key `config-set`
  (SM042), retiring the legacy pseudo-plugin save path that silently dropped keys
  outside its schema - a parity guarantee test fails the build if the page's keys
  ever drift from the API's read/write sets.
- **Files** - a browser over the docroot with per-row metadata, create/upload/delete,
  a type filter, bulk select with zip download and bulk delete, an inline
  **permissions editor** (owner select + per-principal r/w chips drawn from a
  user/group picker), lock glyphs, and `.brief` sidecar controls.
- **Editor** - front-matter form + raw-YAML toggle + body editor + live preview,
  with a **collaborative edit lock** (auto-renewing, 5-minute timeout), **stale-lock
  take-over** (which refuses to clear a live WebDAV lock), and **mtime conflict
  detection**.
- **Nav editor** - drag-and-drop reorder, indent/outdent nesting, link-vs-heading
  toggle; saving rebuilds the all-pages cache (nav is on every page).
- **Plugins** - per-plugin config forms (password fields never returned), action
  buttons, and the **form handlers** + **form targets** UI.
- **Themes** - installed-themes panel (activate/deactivate/rename/delete),
  **preview** any theme in your session via a signed cookie, **upload** a theme zip,
  and **install from GitHub Releases** of the configured layouts repo.
- **Users** - add/remove/rename, set/clear passwords, group membership, a
  read-only **capability grid** (channel x action, derived from groups; edited
  on the Groups page), **2FA**, **Generate credential** (a one-shot `lzs_`
  token), WebDAV scope, and the **AI partner onboarding** flows (connect code
  for the web OAuth flow; pairing-key brief for Claude Code / scripts), plus
  account disable/enable/reassign. Sub-user management is scoped to the
  actor's own subtree; an operator can **promote a sub-user to top level**
  (clearing `managed_by`) and, separately, set an explicit `scope_independent`
  flag that lifts the `created_by` scope ceiling - the provenance stamp itself is
  never rewritten (SM194). A group change that would strip an account's last
  manager-access group raises a warning before it applies.
- **Groups** - the capability editor: each group carries its channel + action
  grants and a description; members inherit the union.
- **Sessions** - the live-session list (SM141): user, signed in, IP, device,
  a "this session" marker; per-session **Sign out** and per-user **Sign out
  everywhere**, plus secret rotation as the everyone-at-once option.
- **Cache** - list cached pages (with orphan badges), invalidate one or all.
- **Stats** - the visitor-statistics dashboard, reading lazysite's own
  first-party access log as the primary source (SM140; the server log is the
  fallback tier), plus the bad-URL blocker's blocked-IP list with unblock.
- **Audit** - the paginated, filterable audit viewer, timestamps in the viewer's
  local timezone.
- **Backups** - typed sections (Content / Full-system); create/download, with
  content restore in-app and full-system restore via the CLI; plus a **Site
  packages** panel (list / download / upload / apply / delete) for portable
  per-domain packages (see Domains and multi-site).
- **Domains** - the multi-domain admin (gated on `manage_domains`): add / configure
  / remove the ADDITIONAL first-class domains that share the instance, each with its
  own content root, per-domain SEO and language (`lang`/`lang_group`), and access
  control; per-domain **preview** (pre-DNS, server-side render), a **Check**
  (public-IP, cert SANs, proxy-aware, SSRF-guarded), and per-domain **Export site**
  to a portable package (see Domains and multi-site). The primary/default site
  lives in Site settings; the Domains page lists only the additional domains.

**Recent-change markers** (SM103): the Files and Users pages show a small dot on a
row changed within the last day (a `recent-changes` action reads the audit-log
tail), with a when / who / what tooltip. When the manager is enabled, the processor
injects a compact **admin bar** on site pages for managers (Manage, Edit-this-page,
Sign out, a no-password warning).

## The control API

A single CGI (`lazysite-manager-api.pl`), action by `?action=`, JSON responses. Two
mutually exclusive auth shapes (cookie/manager via the wrapper, or
`Authorization: Basic user:lzs_token`); the method-keyed CSRF gate; per-token
capability gating; and a per-token rate limit (token-bucket, burst 200 / refill
20·s⁻¹, HTTP 429 + `Retry-After`). The verbs cover file CRUD + lock/preview/upload/
download/zip, ACL get/set/remove, cache list/invalidate, allow-listed `config-set`,
the full theme/layout management set, artifact manifest/validate, users/principals
(proxied to the users tool), plugins/handlers/form-targets, nav read/save, backups,
SM071 preview grant/clear, `whoami`, `version`, `audit`, the session controls
(`sessions-list` / `session-revoke` / `user-revoke`, `manage_users`-gated and
not reachable by token clients), and `rotate-auth-secret` (the mass-logout
lever - rewrites the install HMAC secret, invalidating every session at once).

## File operations, locking, ACLs

The shared `Manager::Files` handlers underpin every surface: `list` (with size,
type, lock, ACL, and sidecar flags), `read` (refuses binary), `save` (lock + mtime-
conflict + ACL checks, cache + registry invalidation; a `nav.conf` save clears all
HTML), `delete` (no recursive delete), `mkdir`, and `move` (which carries the
`.brief` sidecar + generated `.html` and **re-keys the ACL**). A single lock store
(`manager/locks/`) is shared with WebDAV - a manager save respects a live WebDAV
lock and vice-versa - and theme/layout activation takes an artifact-level lock
across validate→snapshot→flip. Two more (SM096): `copy` **duplicates** a page (and
its `.brief`, the copy owned by its creator), and `migrate-to-local` turns a `.url`
remote page into a local `.md` by fetching the body through the shared,
SSRF-guarded `Lazysite::Fetch`. Saving or deleting a page maintains its
alias-redirect entries (`aliases:` 301 / `aliases_temp:` 302, SM134 + follow-ups),
and so do `move`, `copy`, migrate-to-local and WebDAV MOVE/COPY - a rename re-keys
the map without waiting for the next save. The Files page shows the current map in
a read-only Aliases card (alias → target with a 301/302 badge), backed by the
`aliases-list` read action (token clients: `manage_content`).

## Themes and layouts management

Activation is a careful, reversible operation: take a lock, **validate** the
candidate (theme.json present + non-empty compatible `layouts[]`; layout.tt
compiles), optional **optimistic-concurrency** check against a content-hash digest,
**snapshot** the outgoing version (with retention pruning), flip the pointer,
**invalidate only generated HTML**, and **mirror theme assets** to the public path.
Layout activation additionally enforces a compatible (layout, theme) pair. Themes
can be deleted/renamed/uploaded (zip, with zip-slip protection and strict
`theme.json` validation), or installed from **GitHub Releases** of a configurable
`layouts_repo` (with a lazy per-release content preview). The content-hash
**manifest** doubles as the optimistic-concurrency token and a drift detector.
Theme install no longer auto-activates (SM176) - installing lands the candidate,
activation stays a separate deliberate step.

The **layout catalogue** (`list_layout_catalogue` / the control-API
`layouts-manifest` action) lists every layout in the configured layouts repo,
installed or not, each with `name` / `version` / `default_theme` / `themes[]` /
`installed` and - since SM206 - a one-line `description` and optional style/audience
`tags`, so an author (or an agent) can choose a base layout by purpose without
installing and inspecting it. Absent description/tags degrade to empty, never an
error. See **Theme authoring and external-design ingestion** below for the
one-call theme scaffold, token-vocabulary discovery, and the Figma bridge that
build on this surface.

## Theme authoring and external-design ingestion (0.9.14)

Restyling a site, building a bespoke theme, or bringing a design in from an
external tool used to mean path-knowledge plus a five-step `write_file` sequence
with several documented sharp edges. 0.9.14 turns theme authoring into a first-class,
validated, discoverable workflow across the MCP connector, and adds a documented
method for ingesting an external design (Figma) with **no lazysite-side fetcher and
no stored third-party credentials**. Everything here is gated by the existing
`manage_themes` capability - no new capability, no new transport.

### The token contract, made explicit (SM203)

A layout's reference CSS consumes a small, regular set of CSS custom properties -
`var(--theme-colours-primary, …)`, `var(--theme-fonts-body, …)` and friends - which
a theme supplies through its `theme.json` `config` block (the processor turns each
`config` entry into a `--theme-GROUP-KEY` declaration in a `:root { … }` block,
stripping `;{}<>` from every value as it emits). Historically the *vocabulary* a
layout expects was discoverable only by reading an existing theme's `main.css` and
grepping for `var(--theme-`.

`layout.json` now carries an **optional, declarative `tokens` block** naming the
custom properties the layout's reference CSS consumes, grouped as the config is:

```json
"tokens": {
  "colours": ["primary", "text", "heading", "background", "border", "accent"],
  "fonts":   ["body", "heading", "code"]
}
```

It is **documentation-as-data, never enforced at render**: the `var(--theme-*,
<fallback>)` chain is unchanged, a theme may supply extra tokens or omit declared
ones, and the fallback covers any gap. A theme that mis-supplies the declared
tokens at activation logs a **non-fatal warning** (comparing declared vs supplied
sets) - the loose coupling is a designed property, so a mismatch is surfaced, never
rejected. The shipped layouts (the `lazysite-layouts` repo) carry these blocks.

### `theme_tokens` - token-vocabulary discovery (SM204)

A new MCP **read** tool (`manage_themes`, not audited) answers the first question
any restyling task asks - *what is the token vocabulary, and what do exemplar values
look like?* - in one call:

- given a **theme**, it returns that theme's parsed `config` (groups, keys, values)
  plus `name` / `version` / `layouts` from its `theme.json`;
- given a **layout** (no theme), it returns the layout's **declared** `tokens`
  block plus the layout's default theme `config` as exemplar values; if no block is
  declared it derives the vocabulary from the default theme and marks the result
  `derived: true`;
- given neither, it defaults to the active layout + active theme.

It reuses the existing theme readers and adds only the `theme.json` `config` parse
that `list_themes` does not do. It works standalone via the derived mode and is
richer once a layout declares its tokens.

### `create_theme` - one validated call to scaffold a theme (SM205)

A new MCP **write** tool (`manage_themes`, audited) collapses the whole scaffold
into a single validated call, retiring every sharp edge the old sequence carried
(nested directories, validation only at activation, assets that must live under
`assets/`). It validates **eagerly, before writing anything**:

- `name` sanitised to `[A-Za-z0-9_-]`;
- `config` values are ASCII strings free of `;{}<>` - **the same characters the
  render-time emitter strips** - so the author is told up front about a value that
  would otherwise be silently altered at render (a clarity safeguard, not a new
  security boundary - the render-time strip remains the enforcement);
- the target `layout` exists and is installed.

On failure it returns the existing `{ ok: 0, error, kind }` model with
`kind: "validation"` naming the failing rule, so an agent can fix without
re-reading docs. On success it scaffolds
`lazysite/layouts/LAYOUT/themes/NAME/` with a `theme.json` (`layouts: [LAYOUT]`,
`author` from the partner identity, default `version` `1.0.0`) and
`assets/main.css`. **When `css` is omitted it copies the layout's default theme
`main.css`** as the starting point - encoding *copy-nearest-and-adapt*: the
`config` tokens restyle the copy immediately through the `var(--theme-*)` chain,
and CSS craft can follow. An optional `activate: true` runs the existing
activate/mirror/cache-clear path. If the layout declares `tokens`, a coverage check
is returned as **warnings** (declared tokens the theme omits, with the fallback
values that will apply; supplied undeclared ones) - warn, never reject. The tool
returns created paths, warnings, and preview guidance (the source-CSS preview URL
before activation, the mirror URL after).

A folded-in fix removes the old *fix-then-must-reactivate* trap: a `theme.json`
written through the general `write_file` path now runs the **same theme validator
eagerly** and returns warnings, exactly as `write_file` already validates a page -
no need to reactivate a theme just to learn a value was rejected.

### `layout.tt` is readable text (SM202)

The binary/text decision is extension-based, and `.tt` was missing from the
editable-text allowlist, so `read_file` / the history View / WebDAV refused a
Template Toolkit `layout.tt` as binary. That blocked the sanctioned
**copy-nearest-layout-then-adapt** workflow (the active layout is write-locked, so
an author copies a sibling `layout.tt` and edits it - which requires reading it).
`.tt` is now an allowlisted text extension across all three read paths at once; a
genuine binary (`.png`, `.pdf`) is unaffected. The 23 shipped `layout.tt` files
were audited as clean UTF-8 - this was an allowlist gap, not file corruption.

### The `/docs/integrations/` namespace and the Figma helper (SM208)

A new **`/docs/integrations/`** documentation namespace (index + per-tool helper,
each registered for `llms.txt` and `sitemap.xml`, cross-linked from the
building-sites and layouts briefings and the AI-agent onboarding) documents how an
agent brings an **external source** into lazysite through the sanctioned channels.
Its first entry, **`/docs/integrations/figma`**, documents the **dual-MCP method**,
a locked design decision:

- The agent connects the **Figma MCP server** (source) and the **lazysite** MCP
  connection (destination) in one session and bridges them. Figma's
  `get_variable_defs` extracts the design's variables and styles and is **free on
  all Figma plans**, where the Variables REST API is Enterprise-gated -
  `get_metadata` / `get_screenshot` orient the work and check fidelity. There is
  therefore **no lazysite-side Figma fetcher, no stored Figma credentials, and no
  new transport** - the deliverable is documentation that makes the bridge reliable.
- The translation is deliberately **semantic, not pixel-repro** (an explicit
  anti-goal). *Identity* - palette, fonts, corner radius, content widths - transfers
  as tokens near-mechanically (role-named variables map straight onto the layout
  vocabulary via `theme_tokens`; value-named ones need a role assigned from the
  screenshots); fonts resolve to **bundled** faces, never a CDN; *rhythm and
  type-scale* are **rebuilt in authored CSS** (there are no theme slots for them by
  design); *structure* adapts the nearest layout (copy-and-stage); *content*
  becomes pages.
- Deployment points at both the MCP path
  (`create_theme` / `write_file` / `activate_theme` / `activate_layout`) and the
  WebDAV + control-API staging sequence, without duplicating the staging mechanics.

A **`build-from-figma`** recipe is registered in `describe_capabilities`, so the
method is discoverable from the connector itself.

## Plugins and form handlers

Plugins are discovered by probing scripts that answer `--describe` (a JSON
descriptor of config schema, actions, and provided capabilities), enabled via the
`plugins:` config block, configured through generated forms (password fields never
returned on read), and invoked via action buttons. **Form handlers** (`handlers.conf`)
define named delivery targets - `smtp` (envelope here, connection in `smtp.conf`,
delivered by `plugins/form-smtp.pl`), `file`, or `webhook` (JSON or Slack format)  - 
and a form is wired to one or more handlers by its `<form>.conf`. The credentials
and destinations live in operator-only config; an agent can *reference* a handler
but never see or set a destination.

## Notifications

Operator notifications (SM136) ride a shared write path (`Lazysite::Notify`):
every notice is appended to the manager bell store and - when the **notify-xmpp**
plugin is enabled - also delivered over **XMPP**, with one client config per site
like SMTP (sender JID + password + a recipient JID, an individual or a group-chat
room; best-effort and time-boxed, so delivery can never block or fail the
triggering action). The manager-header **bell** is gated by the `notifications`
capability (seeded on the `user-managers` group): the notices actions refuse
without it and the bell hides itself; it renders greyscale when nothing is unread
and coloured with an unread badge otherwise. Notices cover the
human-awaiting-a-response events: form submissions, a password-reset request when
no SMTP is configured (previously a silent dead-end), and agent feedback
submissions.

**The channel (SM231).** A notice declares a **type**, and the type decides how
it is rendered and where it goes. `lazysite/notify.conf` carries two keys per
type and one global:

```
route.submission:    bell,xmpp     # which endpoints this type reaches
emit.submission:     off           # silence a type without touching its caller
base_url:            https://...   # how a link is made absolute
```

The **bell is always written and is always the record** - a route that omits it
still gets it, because a notice nothing wrote down is not a notice. Types with no
entry follow their own default, so a site that never writes this file behaves
exactly as it did before.

A **link is now delivered.** A notice has always carried a `url` and it was
stored and dropped, so an operator was told that something happened and never
where to go. The body of each notice comes from a template, per type and per
endpoint, and the built-in one renders the site name, the message and an absolute
link. Override any of them by dropping a file at
`lazysite/notify-templates/<type>.<endpoint>.tt` - full Template Toolkit, with
`message`, `type`, `target`, `url`, `site` and `base` in scope. A template that
fails to render falls back to the plain message: a bad template must not silence
an alert.

**Emission is per caller.** A form that should announce itself does; the rest stay
quiet. Set `notify: off` in a form's own `.conf` to silence that form alone, or
`emit.submission: off` in `notify.conf` to silence the type site-wide. Both
default to on. This exists because volume is real - a three-day programme of 46
form steps across 15 participants is 690 notices where five were wanted - and
because the alternative (accumulate and send a digest) needs pending state and a
timer, which lazysite deliberately does not have.

The registered types are `submission`, `feedback`, `reset-request`,
`credential-expiring`, `backup-outcome`, `audit-finding` and `service-degraded`.
The last four are a declared vocabulary with no emitter yet - the platform learns
those things and has nowhere to say them. An **unregistered** type is still
delivered, on the generic template, with a warning in the log: refusing it would
lose an event because a caller arrived before a registry entry.

## Visitor analytics

**First-party analytics** (SM140): lazysite records its own traffic, so visitor
statistics work out of the box - no web-server log access, no ACLs, no vhost
changes, and no nginx-in-front-of-Apache undercount. The processor appends one
compact JSON line per request to `lazysite/logs/access-YYYYMMDD.jsonl`,
**anonymised at write**: a daily-salted visitor key, never the IP;
attacker-controlled fields sanitised against log injection; O_APPEND-atomic
appends; daily files pruned by retention (default 90 days); `first_party: off`
in `stats.conf` disables. The manager **Stats** page reads this log as the
primary source, and the AI analytics export (`analyse_visitors`, gated by the
`analytics` capability) ingests the same log - the tool never sees raw log
lines. The server-log parser remains the second tier - fallback and operator
diagnostics/enrichment - with a `source` field saying which tier answered, and
an existing-but-unreadable server log reported as exactly that rather than
"not found".

**Durable per-day store + trends** (SM213, 0.9.16+): the aggregates are stored
long-term as one small JSON file per day under `lazysite/stats/` (outside the
clearable cache), with monthly rollups and an index - so the data is durable,
per-day addressable and downloadable, with **no cap to hit and nothing for an
operator to configure**. The export distinguishes its two horizons explicitly so
the complete aggregates are never mistaken for the bounded recent event sample:
`data_from` states how far the aggregates reach, and `sample: {from, to, count}`
states what the raw event sample covers. `analyse_visitors` gains selectors -
`index` (the days + months index), `day=YYYY-MM-DD`, `month=YYYY-MM` - and the
Stats page shows a **month-on-month** trend. The raw event ring is now just a
recent-activity sample, not a limit on analysis. Classification is **visitor-level**:
a token that probes a non-existent path is marked a `scanner` and its whole session
(including a spoofed referrer) is pulled out of the people/referrer figures, not just
the probe; 404s split into plausible missing pages (kept by path) vs a junk
scanner-chorus count.

**Visitor trails** (SM393): the aggregates above answer *how many* took each step
but cannot answer *in what order* - and order is the one fact that cannot be
recomputed later, because once the bounded event ring rolls it is gone for good.
So the ordered sequence is now recorded per visit, per day, in its own files under
`lazysite/stats/trails/YYYY-MM-DD.json`: entry page, exit page, distinct-page
depth, the per-step gap (the dwell on the page being left), and the visitor class
as it was at the time. **This reverses an earlier deliberate design choice** and is
documented as a reversal, not an addition - the sequence aggregates were built
precisely so a flow could be reconstructed without retaining anybody's path.
The limits ship with the recording rather than after it: 40 steps per visitor, 2000
visitors per day, a stated retention (`trails_retention_days`, default 30) enforced
on **every** export including the ones with nothing new to write, and `trails: off`
to disable. Crawlers never open a visit and so leave no trail at all.

They are readable through the same gate as everything else (SM394):
`analyse_visitors` gains `trails=YYYY-MM-DD`, and `index` gains `trail_days` so a
caller can discover which days exist rather than guess - read from the directory
rather than the index file, because trails expire where the rollups do not and an
index entry would outlive the file it names. The reply is capped at 200 visits and
**states the size of the day as well as the size of the answer**, so a partial
sample is never mistaken for a whole one; a day with no trails says whether it was
never recorded or has expired, rather than falling through to the rollups' generic
"no stats for that day".

The manager **Stats** page shows them too (SM399): a *Visitor journeys* panel with
the routes visitors took, counted - three visits along the same path are one row
with a count of three - and the individual visits beneath, each step carrying the
gap before the next request. It shows the **order and nothing else**: entry pages,
exit pages and depth are already on that page from the aggregates over every visit,
and trails are capped and expiring, so a second differently-scoped copy of those
figures would disagree with the first on a busy site. The route counts cover the
whole day even when the visit list is capped, and the page says which is which.

**Generated registries are counted, and bounded** (SM389). Serving a sitemap or a
feed was the one served path that recorded nothing at all, so a crawler fetching
`/sitemap.xml` every few hours left no trace: the day rollup now carries
`registry_hits` and `registry_by`, on their own channel and deliberately **outside**
`pageviews` - a sitemap fetch is not a page view. Generation is also bounded: TTL
expiry used to be a stampede, with every request arriving after the expiry instant
running a full site scan concurrently, and a **non-blocking lock now picks one**
while the rest serve the file stale, which is what a TTL cache is for. Only a cold
start with nothing to serve makes the losers wait.

**Request bodies are bounded at both layers** (SM389). The front-door relay trusted
a declared `CONTENT_LENGTH` whatever it said, and slurped an **unbounded** body when
there was none - chunked transfer encoding, which the client chooses. Either sizes
a persistent FastCGI worker to the body permanently. The relay now caps at 64 MiB,
following `manager_upload_max_mb` **up** so raising the upload limit still works
(`front_max_body_mb` overrides), and refuses an oversize declared length before
allocating. The shipped Apache templates gained `LimitRequestBody` to match the
`client_max_body_size` every nginx template already carried - Apache buffers the
body before the engine sees it, so the engine's own cap cannot protect it.

**Privacy commitment.** lazysite **installs no trackers**: no analytics
JavaScript, no beacons, no analytics cookies, no fingerprinting, no third-party
requests. Analytics are derived only from data the server already receives while
serving a page, aggregated and IP-anonymised at write. The durable **day** files
hold aggregates only; the separate **trail** files above are the one per-visit
record the platform keeps, and they are pseudonymous, capped and expiring by
default rather than as an option. Visitor keys are daily-salted
so they cannot become long-term identifiers (returning-visitor signal exists only
within a salt period - the accepted cost). The scope of the assurance is precise:
lazysite ships nothing that instruments a visitor; a site owner remains free to add
their own scripts to their own pages, which lazysite cannot and does not control.

## Backups and overlay install

The manager Backups page (and the installer) take `tar.gz` snapshots of served
content (excluding the infra dir) tagged `preinstall` vs `manual`, with strict
name validation on download. This is the safety net for the **non-destructive
overlay install**: lazysite can be laid over a live HTML/SSI site without losing
content - the processor serves existing `.html`/`.shtml` directly and only renders a
`<page>.md` when present, so migration is page-by-page, and the one dangerous delete
(a shadowing `index.html`) fires only when it was the regenerable cache of a
pre-existing `index.md`.

The Backups page is organised into typed sections: **Content** (create / list /
in-app restore / download) and **Full-system**; its intro distinguishes the roles -
backups are disaster recovery (the full-system kind includes secrets), while
day-to-day content versioning lives in the Content history plugin, and theme/layout
version snapshots are managed on the Appearance page. A **full-system** backup captures the whole
site *including* the `lazysite/` infra (config, auth, forms, nav, themes/layouts) -
only the backups dir and regenerable caches are excluded. Because it carries the
auth secrets, in-app restore refuses a full backup; a system user restores it with
`install.pl --restore-full <file> --docroot X [--domain Y]`, where `--domain`
rewrites the site domain on restore - the **cross-domain migration** path (build on
a temporary domain, then move content, config and accounts to the final one).

## Domains and multi-site (SM151 family)

One lazysite instance hosts **many first-class domains**, not one site with
subsites. The multi-site plane (SM151) gives each domain its own content root under
the docroot, with per-host confinement, per-host caching (listed and cleared per
host on the Cache page), and per-host SEO and language. A **bare docroot** with no
matching domain root is excluded rather than served (SM151 §7). Sub-domains are
first-class peers, so theme/layout delete-safety and the language machinery account
for every domain (SM177).

- **Domains admin** (SM154, gated `manage_domains` - split out of `manage_config`
  by SM160). Add / configure / remove additional domains from the manager Domains
  page or the CLI; each domain carries its content root, `lang`/`lang_group`, SEO,
  and access control. A `domain-preview` renders a domain server-side **before DNS
  points at it**, and a `domain-check` runs a **proxy-aware, SSRF-guarded** health
  probe (public-IP match, certificate SANs, a distinct verdict for a coverage gap
  vs an unreachable host); `domain-check` refuses any probe whose resolved address
  is not public (blocking loopback, RFC1918, the metadata endpoint, CGNAT, IPv6
  ULA/link-local), closing DNS-rebinding and IP-literal paths.
- **Group-level domain binding** (SM155): a group can be delegated a domain, with
  first-class **aliases** and the pre-DNS preview, so an agency team manages its own
  domains without operator involvement. The "alias" concept on Add-domain is a
  *Copy settings from* pre-fill.
- **Domain access-control model** (SM165): a domain-owned access model with per-user
  locks - who may see and edit a given domain - layered on the capability + ACL core.
- **Portable site packages** (SM158, and the migration completeness work
  SM183/SM185/SM193). A single per-domain **package** captures a domain's content
  and presentation (excluding `lazysite/` infra, secrets, and every other domain's
  content) into a portable artefact - the interface for an **agency demo → client
  hand-off**. It is symmetric across surfaces: a package built by MCP is applied by
  a human and vice versa. In the manager, Domains gains **Export site** per domain
  and Backups gains the **Site packages** panel (list / download / upload / apply /
  delete) with an apply **preview** and a confirmation naming the target and the
  presentation keys it rewrites. Two read actions - `site-backup-inspect` (read the
  manifest without applying) and `site-backup-delete` - are `manage_domains` +
  scope-confined to the `lazysite-site-` namespace, so a full/content backup or a
  traversal path is unreachable. **Apply keeps the target's identity by default**
  (`site_url` / `site_name`), with an `adopt_identity` opt-in to take the source's;
  it **mirrors the layout's theme assets** so an applied site is styled immediately;
  and language (`lang`/`lang_group`) travels in the package. A token-client
  `site-backup-download` (`manage_domains`, namespace + scope confined) completes the
  create / download / upload / apply loop over MCP.

## Content history (git, SM085)

Opt-in per-file version history for the site content. ONE switch enables it:
ticking the **Content history plugin** on Plugin Manager runs its `on_enable`
hook (conf key `git_history: enabled` + the initial snapshot), and unticking
runs `on_disable` (recording paused, every version kept). The `git-init`
control-API action (gated on `manage_config`) and the plugin's Status /
Enable / Pause actions on Plugin Config drive the same `Lazysite::Git`
machinery - the config page is the inspection/recovery surface, not a second
required step. Enabling puts the docroot under git: the
repository lives at `lazysite/git/` (inside the never-served infra tree - no `.git`
under the docroot for a web server to leak) with the docroot as the work tree, and
the enabling act takes an **adoption commit** of the current site. From then on
every content write - manager save/delete/move/copy/migrate, upload, WebDAV
PUT/DELETE/MOVE/COPY, MCP writes (they route through the same handlers), nav and
site-config saves, and a content-backup restore - is an automatic commit with the
acting user as author (`user <user@lazysite>`) and the action as message ("edit
about.md", "move a.md -> b.md"); a batched operation is one commit. A git failure
never breaks the write (WARN + proceed), and a host without git degrades cleanly.

What is versioned: the content tree plus the two operator-authored config files
(`lazysite/lazysite.conf`, `lazysite/nav.conf`). Never versioned (written to
`GIT_DIR/info/exclude` at init): `lazysite/auth/`, `lazysite/forms/`,
`notify-xmpp.conf`, cache/logs/backups/locks, the repo itself, generated `*.html`
and `lazysite-assets/` mirrors - the exclude list is the security boundary that
makes the history safe to sync to a private remote later (the git-sync plugin
follow-up builds on the same `Lazysite::Git` core). `lazysite-check` probes the
repo permissions and FAILs if `lazysite/auth` is not excluded.

**Recording-health hardening (0.7.8, field defect dito.tech).** The repo is
initialised `--shared=group` (`core.sharedRepository=group`), so git itself keeps
every object dir and ref group-accessible regardless of the process umask - the
canonical shared-repo setting for the split www-data/site-user identity; the
in-place-rewritten scratch files (`COMMIT_EDITMSG`, an unwritable one is fatal to
a commit) are kept 0664 by the hook. Because a failed commit deliberately never
breaks the save, failure is made visible instead of silent: the engine touches
`lazysite/git/COMMIT_FAILED` on any commit failure (an add failing for an
*existing* path counts - that is repo trouble, not the tolerated
unmatched-pathspec case) and removes it on the next successful commit. Three
surfaces read the state: the content-history plugin's **status** action says
"recording is failing", the Files page's empty history panel suspects a failure
instead of pretending the file is new, and `lazysite-check` FAILs on any repo
path the CGI cannot use ("new file versions are silently not recorded"), WARNs
on the breadcrumb and on a missing `core.sharedRepository`, and `--fix` repairs
the modes and sets the config. The guarantee suite
(t/unit/lib/18-git-guarantee.t) pins a write-path registry (every manager/DAV
write action classified hooked-or-exempt), the shared-permissions promise, and
the full failure->recovery lifecycle across all surfaces.

Each file row on the Files page gains a **History** panel: the commit list (when /
who / what), a read-only **View** of any version, a unified **Diff** against the
current file, and **Restore** - which writes the old content back *through the
normal save path* (cache invalidation incl. host copies, alias reindexing, audit),
so the restore is itself the newest version and nothing is ever lost. Reads are
`git-history` / `git-show` / `git-status` (token: `manage_content`, audit-skipped);
`git-restore` shares the content grant and is audited. Full-system backups remain
the DR mechanism - they carry exactly what the history deliberately excludes.
History follows a rename and never leaks across a delete/recreate (SM175).

The content-history **status** is a genuine health probe (0.9.13), not a boolean:
it reports **enabled-and-healthy** vs **half-enabled/inconsistent** (config says on
but the repo or a hook is wrong) vs **degraded/paused**, so an operator can tell a
working history from one that is silently not recording.

**File list + revision statistics** (SM199). Beyond a single file's panel, a
**git-history-summary** action (and a `list_content_history` MCP tool) drive a
**History overview**, on the content-history plugin's row on the Plugin Config
page (SM664; it was on the Files page until 0.11.4): per-file **revision
count**, **first/last commit dates**, **last author**, and site totals across
the tracked tree - a who-changed-what-and-how-often view of the whole site.
Reading it needs **manage_content OR manage_config**, so an auditor reaches it
without being given the Files app. It is rename-aware and
leak-safe by the same rules as the per-file history.

**Remote sync (the git-sync plugin, opt-in).** With content history enabled, the
`git-sync` plugin syncs it with a private remote repository (a Forgejo/Gitea/etc.
project): configure the remote address (`https://host/path`, `git@host:path` or
`ssh://` - nothing else is accepted), branch and access token (password-typed, so
`lazysite/git-sync.conf` is 0660 and itself excluded from the versioned set) on
Plugin Config, then use the on-demand actions - **Test connection** (ls-remote:
reachable / signed-in / content-present in plain language), **Push** ("Pushed N
new changes"; refuses cleanly when the remote is ahead - never forces) and
**Pull** (a fast-forward just applies; when both sides changed, the operator sees
"These pages changed in both places: ..." and chooses **Keep mine** or **Take
theirs**, `merge -X ours/theirs` under the hood). Every apply is preceded by a
prerestore safety snapshot, invalidates the render caches (sibling `.html` +
host copies, wholesale - a pulled change can affect every page) and reindexes
aliases for the changed pages; outcomes are audited as `plugin-action git-sync
(push|pull ...)`. The https token is fed to git through a transient 0700
`GIT_ASKPASS` helper reading an environment variable - it never appears on a
command line, in the stored remote URL, in git config or in the helper file.
Operator-facing strings use no git vocabulary - changes, your copy, the remote
copy.

## Upload and download

Multipart upload (multiple files, size-capped and rate-limited *before* the body is
read, with per-file deny checks and atomic writes), streamed download (deny-checked,
`Content-Disposition: attachment`), and multi-file **zip download**. A content-type
table and an editable-text extension set decide what the editor treats as text vs a
binary download panel (`.htaccess` is intentionally binary).

---

# Part VI - WebDAV publishing

A self-contained CGI (`lazysite-dav.pl`) at `/dav`, reached directly (not through
the cookie wrapper - it does its own HTTP Basic auth), advertising **DAV class 1 +
2**. It is off by default (`webdav_enabled`), refuses Basic credentials over
plaintext unless HTTPS/loopback/explicitly allowed, authenticates against the user
DB with a per-IP failed-attempt limiter and brute-force delay, and enforces account
state, the `webdav` mechanism flag, the deny-list (on reads too), `dav_scope`, and
per-file ACLs (resolving the user's groups from the group file). It implements
`OPTIONS`/`PROPFIND` (Depth 0/1, ETags, a `lzs:sha256` live property computed only
when requested and only under layouts)/`PROPPATCH`/`GET`/`HEAD`/`PUT` (with
`If-Match`/`If-None-Match` conditionals)/`MKCOL`/`DELETE`/`COPY`/`MOVE`, and class-2
**locking** (exclusive, Depth-0, refreshable, per-user flood-guarded) on the lock
store shared with the manager. Throttled writes and locked resources always carry a
`Retry-After` (the documented retry contract). Standard clients work: `curl`,
`rclone`, davfs2, GNOME/KDE, and - because class-2 LOCK shipped from the start  - 
Windows Explorer and macOS Finder. There is no machine-account *type*; a bot is just
a user with `webdav:on, ui:off` and a scope.

---

# Part VII - The MCP AI connector

`lazysite-mcp.pl` exposes site maintenance as MCP tools an AI client can call.
Transport is **Streamable HTTP / JSON-RPC 2.0** (POST = request + JSON response; GET
→ 405; protocol `2025-11-25`); `initialize`/`tools/list` are open for discovery and
`tools/call` requires auth. It accepts the dual bearer shapes (static `partner:lzs_`
or OAuth access token), challenges unauthenticated calls with a `401` +
`WWW-Authenticate` pointing at the OAuth metadata, and **disambiguates** "sign-in
incomplete" vs "credential expired/revoked". A token client is never an operator, so
per-file ACLs bind it as over WebDAV; each tool declares a required capability;
reads are not audited, writes are recorded as material events.

The tools, by group (unauthenticated `tools/list` is filtered to the invocable
subset - see connector reliability below):

| Group | Tools |
|---|---|
| Identity | `whoami` (id, capabilities, active layout/theme, full tool manifest, auth method + expiry), `describe_capabilities` (the capability map + task recipes, incl. `build-from-figma`) |
| Read | `list_files`, `read_file` (reads a Template Toolkit `layout.tt` as text since SM202), `read_page` (parsed front matter + body), `list_pages`, `page_status` (will my edit reach visitors?), `search_files`, `preview_page` (server-side public render), `validate_page`, `audit_site`, `get_permissions`, `list_form_handlers`, `read_nav`, `list_layout_catalogue` (name/version/default_theme/`themes[]`/installed + description + tags, SM206), `theme_tokens` (token vocabulary + exemplar values, SM204), `read_form_submissions` (least-privilege submission read, `read_submissions`, SM187), `list_content_history` (per-file revision statistics, SM199) |
| Write | `write_file` (validates on write; a `theme.json` runs the theme validator eagerly, SM205), `create_page`, `delete_page` (removes `.brief`, reports dangling refs), `rename_page` (`update_links`), `replace_text` (no silent clobber), `copy_file`, `move_file`, `delete_file`, `set_permissions`, `bind_form`, `set_nav`, `create_theme` (one-call validated theme scaffold, SM205) |
| Site ops | `activate_theme`, `activate_layout`, `invalidate_cache` |
| Domains | `site_backup` (package a domain) and `site_apply` (apply a package - the migration step), both `manage_domains`-gated (SM158/SM193). The fuller transport (inspect / download / upload) and the domain admin itself (`domain-add`/`-set`/`-preview`/`-remove`) are control-API only |

`validate_page` runs pre-publish checks including a **public-data warning** (Wi-Fi
passwords, postcodes, phone numbers); `audit_site` finds broken links, orphans,
missing titles, stale HTML, and duplicate blocks; `preview_page` renders fresh **as a
public visitor** so verification stays in-channel. Each tool carries MCP
`readOnlyHint`/`destructiveHint`/`openWorldHint` annotations so clients drive
per-call approval (ChatGPT Plus/Pro = read-only; Business/Enterprise get writes with
an approval card). The connector is **supervised, not autonomous**: bound by
capabilities, ACLs, the deny-list, and the client's own approval. It is walled off
by construction - form/SMTP configs, auth files, scripts, and the manager are
denied with a machine-readable `kind`; user administration, secrets, and credential
minting are **not exposed at all**. An agent can *wire* a form to a vetted handler
(`bind_form`) but never set a destination or credential, and it can *read* form
submissions through the least-privilege `read_submissions` capability
(`read_form_submissions`) without holding the broader `manage_forms`.

**Connector reliability** (0.9.13). `tools/list` is now **capability-aware**: an
authenticated caller sees only the tools it can actually invoke (SM196), and
connected-detection flips at authorise time so a paired connector reports itself
connected. A `401` carries a distinct `data.reason` -
`sign-in-incomplete` / `credential-invalid` / `token-expired` / `token-invalid` -
so a client can tell "finish signing in" from "re-pair"; a rotated **expired** token
returns `reason=expired` with guidance to re-exchange a pairing key (the expired
signal is given only after the secret verifies, so it leaks nothing to a wrong
token). The operator **connect code** is valid for 30 minutes (was 15) with its
expiry surfaced, the onboarding copy is agent-neutral, and a `lazysite-check` probe
flags a remote service that is enabled but has a bad or absent `site_url` (the
broken-discovery-endpoint class). Since the 0.9.0 killswitches, the MCP surface is
**off by default** and refuses pre-auth (including discovery) when disabled,
disclosing nothing.

---

# Part VIII - Forms and delivery

A `:::form` on a page (named by the `form:` front-matter key) renders to an
accessible, CSRF-token-and-honeypot-protected HTML form that submits via `fetch` to
a handler CGI and swaps to a success message. Delivery is configured by the
operator: the form's `<form>.conf` references one or more named handlers in
`handlers.conf`, each of type `smtp` (with shared connection config in `smtp.conf`  - 
sendmail or authenticated SMTP with TLS), `file` (stored submissions), or `webhook`
(custom JSON or Slack-formatted). The forms docs cover the field grammar, the
webhook JSON contract, and SMTP setup. Credentials and destinations are
operator-only and deny-listed from every publishing surface.

**SMTP credentials and validation** (SM137): the connection config carries a
**password** field - typed once into the Plugin Config form or the handler wizard,
stored in the operator-only `smtp.conf`, never shown back; `password_file:` remains
as the alternative and is used only when no password is set. A **Validate SMTP
connection** action in the wizard's connection section runs a staged check against
the SAVED settings and names the failing stage - host (DNS), port (TCP reach, with
a plain probe first so a closed port is never mistaken for TLS), TLS (STARTTLS vs
implicit vs none, suggesting the mode to try), or auth (rejected with the server
code, or no password set). It never sends an email and is time-boxed.

**Multi-step (wizard) forms** (SM098): a `--- step ---` line (optionally titled,
`--- step: Title ---`) inside a `:::form` splits it into wizard steps rendered as
`<fieldset>`s with a Back/Next nav and per-step validation (the native constraint
API before advancing). The form still posts **once** with the same token and
honeypot - the steps are client-side presentation over one submission. Progressive
enhancement: with no JavaScript every step shows and the form still submits.

**Submissions viewer** (SM182, v2 SM187). Stored `file`-handler submissions live at
`lazysite/forms/submissions/<form>.jsonl` in the reserved `lazysite/` tree the file
editor refuses to open, so the data was unreachable from the UI. The plugin-config
**View submissions** button now opens the store in a scrollable **modal** table. A
`form-submissions` read action parses the store server-side (docroot-confined,
`.jsonl` only, no traversal), unions keys into columns, caps at the most-recent 500
rows, and returns values verbatim; the client **escapes every cell**, so a hostile
submission renders as inert text. A handled row can be **deleted**
(`manage_forms`, UI, audited, atomic rewrite keyed on a stable per-row id). A new
least-privilege **`read_submissions`** capability plus the `read_form_submissions`
MCP tool let an agent read submissions over API/MCP without the broader
`manage_forms`; both channels gate `form-submissions` on `manage_forms` **OR**
`read_submissions` at parity.

---

# Part IX - Typed data: tables, bindings and the write doors

A lazysite site can hold **declared, typed tables** as well as content files.
This is what the app examples rest on: a work queue, a stock list, a
reconciliation run are all rows in a table with a schema somebody wrote down,
rather than JSON somebody hopes stays well-formed.

Reference: `/docs/data-tables`. Authoring practice: `/docs/ai-briefing-data`.

## The descriptor is the schema

One YAML file per table under `lazysite/db/tables/<name>.yaml`, and the
**filename is the table name** - lower-case letters, digits and underscores.
The descriptor is the only place a table's shape is stated; nothing infers a
column from a row.

```yaml
title: Products
domain: shop.example.com     # which domain owns it, on a multi-domain instance
key: code
public: false
fields:
  code:  { type: text, required: true, max: 20, unique: true }
  price: { type: decimal, digits: 8, places: 2 }
  in_stock: { type: boolean, default: true }
```

| Key | What it settles |
|---|---|
| `key` | which field identifies a row; `id` if absent, and then auto-assigned |
| `fields` | the columns and their types - `text`, `integer`, `decimal`, `boolean`, `date`, `datetime`, `enum` |
| `required`, `max`, `unique`, `default` | per field, enforced on every write |
| `indexes` | what to index, for tables large enough to need it |
| `timestamps` | records when a row was created and changed |
| `default_order` | the sequence the table is in, said once instead of in every binding |
| `writable_by` | which accounts or groups may write, beyond holding the capability |
| `public` | whether an **anonymous visitor** may read it; closed by default |
| `domain` | which domain owns it - see domain scoping below |

A boolean key accepts `true`/`false`, `yes`/`no`, `on`/`off`, `1`/`0` in any
case, and refuses any other word rather than guessing. `public: no` reading as
true is the defect that made that rule explicit.

## Bindings put rows on a page

Front matter binds a page variable to a query. The page then renders rows with
no code of its own.

```yaml
tt_page_var:
  products: db:products(order=name,limit=20)
  total:    db:products.count()
```

| Binding | Answers |
|---|---|
| `db:products` | the whole table, in its declared order |
| `db:products(featured=true,limit=4)` | filtered, conditions AND-combined |
| `db:tasks(order=due)` / `(order=-due)` | ordered, ascending or descending |
| `db:tasks.count(done=false)` | a number, not a list |
| `db:products.field(price,code=SKU1)` | one value out of one row |

A binding carries a **row ceiling** and reports when it clamps, so a page that
outgrows its limit says so in the log rather than quietly showing a short list.
`items_total` beside `items.size` is how a page says "showing 200 of 250".

## Freshness is the page's `ttl:`, and modes currently do not differ

A table has **no timestamp that can prove a cached page still current** - the
store is written through WAL, so a row changes without the file's mtime moving.
So a `db:` binding withdraws the mtime proof of freshness, and the page's own
`ttl:` becomes the only bound it has: a page declaring one is served from cache
for that window, and a page declaring none is re-rendered on every request.

The descriptor grammar accepts `mode=snapshot` (the default), `mode=live` and
`mode=client`. **`snapshot` and `live` currently behave identically** -
withdrawing the mtime proof is the only thing the mode ever did, and since
SM604 every `db:` binding does it, because otherwise one `json:` binding on the
same page vouched for the table's freshness, which nothing can do. `client`
is genuinely different: no rows at render, the page's own script fetches them.

Choose a `ttl:` from how stale the data may be before it misleads someone. That
is the decision; the mode is not, today.

## Four doors write to a table, and they are not equivalent

| Door | Who | Notes |
|---|---|---|
| Control API `data-row-save` / `data-row-delete` | a grant holding `manage_data` | the operator and partner path |
| MCP `save_data_row` / `delete_data_row` | the same | the twin of the above; the two are pinned to agree |
| `/cgi-bin/lazysite-data.pl` | a signed-in **session**, not a partner token | the page's own script; a custom data app's route |
| A form handler of `type: db` or `type: table` | a visitor, through a form | operator-vetted mapping only; not settable inline |

The endpoint reads `order_by`, `order`, `limit` and `offset` **and no other
query parameter** - anything else is ignored rather than refused, so a filter
sent that way returns every row in a reply shaped like a filtered one. Filter
on the binding, or filter in your own script.

Every door applies the same type checks, `required`, `unique` and
`writable_by`. There is one implementation of what a value means.

## Domain scoping, on an instance serving several parties

`manage_data` is an **instance** capability and a table name is instance-wide -
there is one `lazysite/db/tables/` for the whole install. On a single-site
instance that is all there is to know.

Where one instance serves domains belonging to different people, a descriptor
names its owner with `domain:`. A caller confined by its grant then reaches
that domain's tables and **is not told the others exist** - the refusal for
another domain's table is word for word the one a missing table gets, so an
instance cannot be enumerated by guessing names.

**A table naming no domain stays reachable by any `manage_data` holder.** That
is deliberate: an instance carrying live tables loses nothing on upgrade, and
the protection is opt-in until an operator migrates. `lazysite-check` lists the
tables still to scope, and only on an instance where a domain actually confines
a group - several domains belonging to one person is not several parties.

## Dropping a table leaves a safety export

The irreversible verb is not, in practice. `data-table-drop` writes a **safety
export** of the rows before removing anything, so a drop that turns out to be
a mistake is recoverable. The export is listed by `data-safety-exports`, read
by `data-safety-export-read`, restored by `data-safety-export-restore` - and
deleted only by a grant holding `purge`, which is a different capability from
the one that dropped the table.

That split is the point: `manage_data` lists, `housekeeping` drops, `purge`
deletes the copy. One grant cannot both destroy a table and remove the evidence.

# Part X - Installation, deployment, and operations

## The installer

`install.sh` is a thin shim over `install.pl`, a ~960-line manifest-driven,
upgrade-aware, core-Perl installer. It reads a `release-manifest.json` (built from a
**classification** ruleset that decides where each file lands) and tracks installed
state in `lazysite/.install-state.json` (a SHA map). On upgrade, **code files are
always overwritten**, but **seed files are preserved if the operator edited them**
(detected by SHA), files dropped from the new manifest are removed if untouched, and
**a backup is taken before any change** (with configurable retention). `--dry-run`
previews the plan with zero filesystem changes; `--restore` rolls back to a backup
and invalidates the cache; runtime state (auth, logs, locks) is never touched.
Imperative post-steps create cgi-bin symlinks for plugin endpoints, mirror the
manager CSS, and seed fresh installs. Run as root, the installer also repairs
ownership - scoped to **root-owned files only**, aligned to the docroot owner and
the web-server group; it never re-owns CGI runtime files or operator content
(0.6.5/0.6.6; `lazysite-check --fix` performs the same scoped repair on a live
site).

Further flags: `--channel edge|beta|stable|certified` sets a site's `update_channel` (a standalone,
audited maintenance op); `--force` upgrades a site past its channel policy
for a specific out-of-channel build (audited as `upgrade-forced`); and
`--restore-full <file> [--domain NAME]` restores a full-system backup, optionally
rewriting the site domain - the cross-domain migration path.

## Packaged distribution (SM139)

Four Debian packages built from the same source (`debian/`, via
`tools/build-deb.sh`), replacing per-site sudo tarball installs:

- **`lazysite-common`** - the engine payload at `/usr/share/lazysite`, the
  **`lazysite` CLI** at `/usr/bin/lazysite`, man pages, the `lazysite@`
  FastCGI pool unit + `/etc/lazysite/pools/`, and the **site registry**
  (`/etc/lazysite/sites.d/`, one key=value file per site). Installing or
  upgrading the deb only refreshes the host payload - it never touches a
  site tree.
- **`lazysite-hestia`** - the HestiaCP integration: Apache web domain
  templates for both runtime patterns (`lazysite-cgi` and `lazysite-fcgi`)
  plus **`lazysite-hestia-domain`** (`add`/`remove`/`list`), the root-run
  panel integrator that prepares the 0551-locked domain layout as root, then
  **drops to the panel user** for `lazysite provision`, registers the site,
  and with `--fcgi` writes the pool config and enables `lazysite@<domain>` -
  one-command domain onboarding.
- **`lazysite-apache`** / **`lazysite-nginx`** - the plain-host webserver
  glue: commented vhost examples for both runtime patterns on each server
  (`vhost-cgi` = page misses through the CGI auth wrapper - Apache
  `FallbackResource`, nginx `try_files` + fcgiwrap; `vhost-fcgi` = anonymous
  pages to the per-site pool socket with the session-cookie carve-out to the
  CGI wrapper) plus **`lazysite-apache-vhost`** / **`lazysite-nginx-vhost`**
  (`add`/`remove`): root-run commands that render a domain's vhost into
  `sites-available/` - never touching site content, printing (never
  running) the enable/reload steps. Both ship
  [docs/reference/webserver-wiring.md](reference/webserver-wiring.md), the
  one wiring reference that also covers Caddy, lighttpd and the generic
  front-end contract for any other server.

The CLI enforces the load-bearing SM139 principle: **no root writes into site
trees**. `provision` and single-site `upgrade` refuse to run as root; only
`upgrade --all` may run as root, because it drops to each site's owner
(`sudo -u`) per site - ownership correct by construction, no chown-after
repair pass. Verbs: `provision`, `upgrade [--all]`, `sites`, `check`, `users`,
`dev`, `demo`, `version`. **`lazysite demo`** is the zero-argument try-it
path: it fresh-installs a scratch site (default `~/lazysite-demo`) as the
current user and serves it on the built-in dev server - no web server, no
configuration, removable with one `rm -rf`.

**Fleet channels and policy.** Each site carries `update_channel`
(the `edge < beta < stable < certified` ladder: the minimum release maturity it accepts)
and `update_policy` (`auto`/`manual`, default `manual`) in
`lazysite.conf`; `upgrade --all` skips `manual` sites and lets the installer's
channel gate decide `auto` sites. `--force` overrides both gates;
`--force-security` also overrides both fleet-wide but is honoured **only**
when the payload's release manifest declares `"security_critical": true`
(stamped with `build-manifest.pl --security-critical`) - the fleet answer to
"a security fix must reach every site now". `lazysite sites` lists the
registry with live channel/policy and installed versions.

## Persistent runtime: FastCGI worker pools (SM142)

The processor is **dual-mode**: invoked as plain CGI it behaves byte-identically
to before, but spawned with a FastCGI listen socket on fd 0 (the spawn-fcgi
convention; the SM139 pool unit) it services requests from a persistent accept
loop - modules compile once, per-request state resets inside the loop, and both
paths share one `handle_one_request`. Prefork is via FCGI::ProcManager
(`LAZYSITE_FCGI_WORKERS`) with worker recycling
(`LAZYSITE_FCGI_MAX_REQUESTS`, default 500); FCGI.pm is lazy-required, so the
CGI path gains no new dependency. **Measured: a cache-hit at 62.2 ms as CGI
serves in 0.4 ms pooled (155x)** - the CGI figure is almost entirely process
start, which the loop amortises away. One pool per site
(`tools/lazysite-pool.pl` binds `/run/lazysite/<site>.sock`, drops privileges,
execs the processor). The auth wrapper stays CGI (its exec design), so pooling
covers the anonymous visitor-facing hot path; see
`docs/architecture/performance.md`.

## Hestia deployment

A two-layer model: a Hestia Apache **web template** owns the vhost (survives
rebuilds), and `install.pl` owns the code/seed deploy. The vhost wires
`DirectoryIndex` → cached HTML, `FallbackResource` → the auth wrapper (not the
processor directly - that would break login), a rewrite that fronts the real cgi-bin
scripts with the wrapper, the **`RequestHeader unset X-Remote-*`/`X-Payment-*`
trust-strip**, the `/dav` ScriptAlias, a `Require all denied` on `/lazysite/`, a
`.brief` deny, and **`Options -Indexes`** (no directory listing). Since 0.7.2
the packaged flow (`lazysite-hestia` above: shipped templates +
`lazysite-hestia-domain`) is the install path -
`installers/hestia/INSTALL-RUNBOOK.md` is written around it; the hand-run
deploy/fleet-update scripts of the tarball era remain in-tree only for
existing deployments. On plain (non-panel) hosts the same two-layer model is
served by the `lazysite-apache`/`lazysite-nginx` glue packages above; for
Caddy, lighttpd or anything else,
[docs/reference/webserver-wiring.md](reference/webserver-wiring.md) states the
front-end contract with copy-paste snippets. (A Docker target is a
placeholder, not yet implemented.)

## The dev server

`tools/lazysite-server.pl` is a single-threaded HTTP host for local development. It
**defaults to no-cache** (edits show immediately), takes `--docroot`/`--port`/
`--processor`, routes auth/manager/WebDAV exactly as Apache does, forwards all
headers, and serves static files. Its **`--auto-index`** mode (SM091) turns *any*
tree of Markdown into a browsable site **writing nothing**: it generates a directory
index (folders + pages, labels from front-matter titles, README linked) for
directories lacking an `index.md`, injects a breadcrumb nav into every page, relocates
the processor cache to `/tmp`, and suppresses scaffolding seeding (also forced off by
`--no-seed`, and never done in a non-lazysite tree). It cleans up on `Ctrl-C`/kill.
Crucially, auto-index is **dev-only and off by default** - the production path never
lists a directory (processor 404 + Apache `-Indexes`), pinned by a test.

## Static site generation

`tools/build-static.sh <scheme://host> [out]` renders every page with the correct
base URL into a static tree (sources stripped from the output), suitable for GitHub
Pages, Netlify, or Cloudflare Pages.

---

# Part XI - Tooling, packaging, and supply chain

- **Release manifest** (`build-manifest.pl`) - deterministic classification of every
  shipped file with SHA + size + bucket; dies on unmatched files or path collisions;
  `--check` verifies a manifest against disk.
- **SBOM** (`manifest-to-sbom.pl`) - a CycloneDX 1.6 software bill of materials with a
  component per shipped file and per curated dependency (with Debian/RHEL/Alpine
  package names and licences). The **`--strict` drift gate** scans every script for
  `use`/`require` and **fails the release** if a dependency isn't declared - so a new
  dependency can't ship unaccounted-for. The product licence is **MIT**;
  dependencies carry their own declared licences, overwhelmingly Perl-core.
- **Release pipeline** (`release.sh`) - never touches `main`: clones fresh, checks
  out a commit, runs the **full test suite**, builds the manifest, runs the strict
  SBOM gate, builds a reproducible tarball via `git archive` (man pages included
  under `man/man1/`), records a SHA sidecar, and tags + pushes `vX.Y.Z`. Tags are
  the only stable identifiers; since the 0.4.x line, `main` is unstable and
  carries unreleased work with no per-release bump commit. Builds are **`edge`**
  by default; `--final` stamps `channel: stable` into the manifest - the
  certified releases that `stable`-channel sites accept. **0.7.0 is the first
  stable release**, opening the declared five-year support period
  (`docs/POLICY.md`).
- **Debian packaging** (`tools/build-deb.sh` + `debian/`) - builds
  `lazysite-common`, `lazysite-hestia`, `lazysite-apache` and `lazysite-nginx`
  (Part X); lintian-clean, smoke-tested from the extracted deb,
  template/packaging invariants pinned by `t/tools/30-hestia-pkg.t` and
  `t/tools/31-webserver-glue.t`.
- **Permissions doctor** (`lazysite-check.pl`) - the health/permissions checker
  (`lazysite check`): probes conf readability, cgi-bin executability, secrets
  modes (incl. the session registry/revocation files), manager layout presence,
  and group-execute traversal - all **evaluated as the CGI identity**
  (ownership+mode arithmetic, so a root run cannot pass files www-data cannot
  use); `--fix` re-runs every check afterwards and prints the **post-fix**
  report, with queued chmods on one path composing additively.
- **Versioning** (`bump-version.pl`) - promotes `NEXT_VERSION` into `VERSION` and
  advances the next, once per release.
- **User admin** (`lazysite-users.pl`) - the full credential/account/MFA/claim/
  pairing lifecycle as a CLI and a JSON `--api` (used by the manager Users page).
- **Offline bundle apply** (`lazysite-bundle-apply.pl`) - applies a network-less
  agent's single-JSON publishing bundle, deny-list-validated, dry-run by default.
- **Coverage** (`coverage.sh`) - measures the CGIs even though tests run them as
  subprocesses, enforcing declared floors: **75% statements / 62% branches**
  across the eight gated CGIs (three documented per-file branch overrides at
  60); an unmeasured gated CGI fails the gate rather than silently skipping.
- **Benchmark** (`bench.pl`) - a host-relative gate on the hot paths (render, token
  verify, password verify), failing only on a gross regression.

The test suite is large (thousands of tests across unit, integration, journey,
smoke, lint, and tools tiers) and is a release gate, alongside the `perlcritic`
(severity-3 + security) gate, the changed-code `perltidy` gate, a
`shellcheck -S error` gate, a secrets gate (every pattern self-tested against a
planted fixture), the **retired-terms lint** (a retired mechanism taught as
current anywhere in the docs fails the build), the coverage floors, and the
SBOM gate; `release.sh` refuses to run when the lint tools are absent.

---

# Part XII - The security model in one place

- **Header trust model.** The central threat is auth/payment header spoofing; the
  defence is the two-signal trust gate plus edge stripping. Headers are the universal
  contract so built-in and proxy auth interoperate without trusting the client.
- **Operator obligations (by design).** Strip client trust headers at the edge;
  grant the `ui` capability only to groups that should reach the manager (when
  NO group grants manager access at all, an unsecured/dev site treats any
  authenticated user as a manager); set a password for every
  non-localhost account (empty-password accounts work only from loopback); use
  HTTPS.
- **Two auth domains.** Cookie operators bypass ACLs inside the manager; token/
  WebDAV/MCP partners never do - they are bound by per-file ownership.
- **Secrets are operator-only on every surface.** SMTP/handler configs, the HMAC
  secret, user/group files, and all `.pl` are denied everywhere; forms can be *wired*
  but never *credentialed* by an agent.
- **No-leak invariants.** Credential check precedes all state gates; generic
  responses on forgot/claim/exchange; single-use + locked redemption; hashed-at-rest
  secrets shown once; constant-time compares throughout; atomic, zero-byte-refusing,
  symlink-guarded writes.
- **Session revocation** (SM141). The Sessions page revokes a single session
  (by sid) or all of a user's sessions (a per-user `not_before`, which also
  kills legacy pre-sid cookies); rotating the install HMAC secret remains the
  invalidate-everything-at-once lever. Enforcement is in the auth wrapper's
  cookie verification - the single enforcement point.
- **No directory listing in production**, ever (processor 404 + `Options -Indexes`),
  tested.
- **Manager access is interactive-only** (SM127). An account that can ACTUALLY use
  the interactive UI (holds the group-granted manager `ui` capability AND has
  interactive login enabled) is refused on the API and MCP transports, and a group
  may not combine `ui` with a remote (`api`/`mcp`) channel - so a leaked or
  misissued token on a manager account cannot drive the site remotely. The 0.9.0
  patch fixed a token-path regression in this gate: it no longer blocks
  **introspection** (`whoami` / `describe-capabilities` stay open per SM126/SM072),
  and no longer refuses a deliberate **agent account** that holds the capability but
  has interactive login DISABLED (`ui:false`) - the gate keys on genuine interactive
  usability, not the capability alone. A control-API token is also pinned as a
  per-site credential that cannot authenticate against another site's docroot.
- **Bad-URL auto-blocker** (SM128, on by default). `Lazysite::BadUrl` counts
  scanner-probe hits (`wp-login.php`, `.env`, `.git`, `*.php` on a Markdown site, …)
  per source IP in a rolling window and blocks at a threshold (default 10 / 3600s);
  enforced in the auth wrapper (403), blocked IPs listed + unblockable on the Stats
  page, auto-blocks audited.
- **SSRF guard** (`Lazysite::Fetch`). Every outbound fetch (`.url` pages,
  migrate-to-local, remote layouts) rejects loopback, RFC1918, link-local/metadata,
  IPv6 loopback/link-local, multicast and CGNAT targets. The `domain-check` probe
  (0.9.0) applies the same guard to a caller-influenced host, requiring every
  RESOLVED address to be public.
- **Manager file-path confinement** (F1, 0.9.9). The file-editor path blocklist is
  matched against the **canonical resolved path**, closing a traversal by which a
  content-authoring account could reach engine-owned files under `lazysite/`.
- **Download read-ACL / scope** (F2, 0.9.9). `file-download` / `file-zip-download`
  now enforce the same per-file read ACL and `dav_scope` confinement as `read`, so a
  delegated editor cannot pull a file restricted away from them; and the
  account/group roster (`principals`) is capability-gated
  (`manage_content` or `manage_domains`) so a user with no grant-related capability
  cannot enumerate every account and group.
- **Dormant-grant fix** (F3, 0.9.9). `manage_domains` / `feedback` /
  `read_submissions` were resolved but not surfaced to the cookie-manager
  capability gate, so a non-operator grant silently did nothing; all three now take
  effect, pinned by a parity test.
- **Atomic config + auth-store writes** (0.9.9, data-loss class). Concurrent config
  saves could truncate `lazysite.conf` to a single line, and the same
  truncate-before-lock race existed in the auth store. `write_file_checked` is now
  atomic (temp + rename, never unlinking the real file), `_write_conf_key` holds a
  lock across its read-modify-write, and every auth-store mutation
  (`write_users`/`write_groups`/`update_user_hash`/the MCP form-bind/the bad-URL
  caches) writes atomically and serialises on a store lock, so a reader never sees a
  truncated credential store and two concurrent edits cannot lose an update. Reads
  stay lock-free.
- **Manager trust gate** (0.8.0). The manager-API applies the same in-app trust gate
  as the processor, so client-supplied `X-Remote-*` identity headers are ignored
  unless the auth wrapper vouched for them - a backstop for an edge that fails to
  strip them (guarantee test `t/lint/13`, adversarial test
  `t/unit/manager/39-forged-identity.t`).
- **Backup-restore control-tree exclusion** (0.8.0). Backup restore excludes the
  `lazysite/` control tree on extraction, so a crafted content tarball cannot
  overwrite the auth/config namespace to escalate - defence-in-depth on top of the
  create-time exclude and the full-backup restore refusal.

---

# Part XIII - Why it is built this way

The recurring design principles, drawn from the feature-request record:

- **One enforced core, many thin transports.** Every front-end translates; nothing
  re-implements policy. This is the reason a third or fourth surface is cheap and
  consistent, and it is the explicit justification for the modular refactor (SM079)
  that made the MCP connector a thin layer.
- **Control by function, not account type.** There is no "bot account" - a partner
  is a user with capabilities, a scope, and ACLs. Capabilities grew from *real*
  needs (e.g. `manage_content` appeared when a partner needed themes-but-not-content).
- **Drafts, live, and backups are the same object** distinguished by a pointer - so
  "roll back a theme" is just "activate a backup", no new verbs.
- **Reference, don't read, for secrets** - agents operate on credentials they must
  never see (`bind_form`).
- **Safe by default, no mode to remember** - e.g. the overlay install narrowed a
  dangerous delete instead of adding an `--overlay` flag that could be forgotten;
  auto-index is dev-only so production can never accidentally list files.
- **The AI client is a fuzzer for the whole stack** - live partner sessions drove the
  ergonomics roadmap and surfaced latent processor bugs (block-Markdown in boxes,
  multi-word `select:`, the UTF-8 double-encode) that ordinary use had routed around.
- **Permanent decisions, not just deferrals** - the specs record *why* alternatives
  were rejected (Digest auth, `mod_dav_fs`, admin-chosen passwords, dead-property
  stores), so a future revisit must overturn a reason rather than rediscover it.

---

# Part XIV - Version history (feature timeline)

Newest first; releases are git tags.

- **0.12.1** (2026-09-03, STABLE) - **A patch carrying one code change, because
  a count found something the case could not.** The 0.12.0 plan asked how many
  pre-existing pages the template-parse guard would refuse; the field agent
  could not reach a stable site to answer, so the count was run across every
  tree in reach. 495 files carrying `[%`, seven refused - and **five of the
  seven were pages that parse.** The guard strips Markdown code before parsing
  so that an example is not read as a directive, but its indented-code half
  fired on any four-space indent with no idea whether it was inside a
  directive, so the continuation lines of a multi-line `[%# comment %]` were
  dropped along with the closing `%]`; the truncated comment then swallowed the
  directive after it. The page parsed and the renderer served it - only the
  guard's copy failed, and an affected page could not be saved by any supported
  route, **including to remove the construct that was never the problem.** An
  indented line is now a code block only where one may begin, after a blank
  line, which a directive continuation never follows. **False refusals 5 to 0.**
  The lesson under it is about method rather than parsing: the rule and its
  fixtures were correct about the case they were written from, and **the case
  was not the population.**

- **0.12.0** (2026-09-02, STABLE) - **The first stable since 0.11.7, and a minor
  bump rather than a patch because the line between them is not a set of fixes.**
  Six beta cuts in five days, every one tested from outside on a running fleet,
  and the same pattern held each time: **the defects that mattered were invisible
  to a green gate.** A PDF render with no caller at all - eleven sabotage tests
  passing against a function nothing invoked. Theme assets that had never reached
  a domain with its own content root, on every release since the asset mirror
  existed. A write guard present on one stack and absent on the other. A composed
  document that worked only on parts carrying no front matter, because the
  fixtures had described an easier case than the feature itself. And a protective
  refusal that had never executed once in its life. None was found by running the
  tests; all were found by an agent using the software on a real host. So the
  other half of this release is the machinery for noticing: a control declares
  its **impact**, so "red destroys" and "a destructive action confirms" can be
  checked rather than only written down; six **save behaviours** are a contract
  with Domains as the exemplar; the documentation has an **index** so it can be
  discovered without being read; there is a **tier to run before a branch leaves
  your hands**, chosen from timings; the coverage stage stops re-deriving an
  answer it already has; and an **error-string lint** earned by three separate
  leaks now catches the class at its source. One thing is deliberately not fixed
  and **not accepted**: `verify_token_ms` sits at about 1.48x its baseline on a
  quiet host, the cause understood and gated by a work counter, and the timing
  baseline is left un-recaptured because accepting it would make the slower
  number the definition of correct and clear the warning on the way out.
- **0.11.12** (2026-09-02, BETA) - **The composed document works on real pages,
  and the gate learns when not to run.** The previous release made the PDF render
  reachable at all; the field pass found it worked only on parts carrying no
  front matter, which is not what composing a document out of existing pages
  means - a part that is a page has front matter, and several of them killed the
  typesetter. A part behind a read ACL was also reported as missing rather than
  refused, even to a reader authorised to read it, because the existence check
  looked only where a public file lives and ran before the permission check - so
  the refusal that feature exists for had never once fired. **The more useful
  finding was why none of this failed the gate**: the fixtures composed from
  parts with no front matter and passed no resolver, so neither fault could
  appear in them. A fixture that describes an easier case than the real one does
  not fail - it passes, and keeps passing, and makes the suite look like
  coverage. The other two entries answer the question that produced that: what
  should run, and when. The coverage stage - two hours and twenty minutes of a
  two-and-a-half hour cut, and no discovery at all - now skips when every input
  that decides it is byte-identical to a run that passed, which fires on a
  promotion and correctly does not between two real releases. And there is a
  tier to run before a branch leaves your hands, chosen from timings rather than
  taste: four of the 110 lint files account for 65 of 88.8 seconds and the other
  102 run in 14.6 seconds combined, so 93% of the lints cost 16% of the time -
  and measured across this project's history, the lints are where the finds are.
- **0.11.11** (2026-09-02, BETA) - **Refusals that name what the caller can act
  on, a render that was never reachable, and CSS a whole class of domain had
  never received.** Four reports came back from the field saying, in different
  words, that the engine had declined to do something and not said why - a
  blocked upload answering only "Blocked target", a database error returning an
  absolute server path and the driver's own vocabulary, a capability gate naming
  the action but not the capability, a page that would not parse. **In every
  case the reason was already known at the point of refusal and thrown away.**
  Two entries are worse than a poor message. **The PDF render had no caller at
  all**: SM706 shipped the composed-document refusal, the per-part access check
  and the cache, and nothing on any surface invoked them - eleven sabotages
  passing against a function nobody could reach. **And theme assets had never
  reached a domain with its own content root**: such a domain serves
  `/lazysite-assets/` from that root while activation wrote only to the docroot,
  so it has been unstyled since the day it was created, on every release since
  the asset mirror existed. Both were found from outside, by an agent testing
  the running fleet, and neither could have been found by reading the code -
  which is the argument for that testing rather than a remark about it. Also:
  the practice documents move into the repository that ships them, with a guard
  that refuses to publish a client's name, and a generated index so the
  documentation can be discovered without being read.
- **0.11.10** (2026-09-01, BETA) - **The auth variables are escaped where they
  enter the render, and two refusals that say what the caller needs to know.**
  Promoted to beta because the 0.11.9 review round was tested and passed - the
  nested-group lockout proved on a real server with a grant reaching the
  capability only through a parent group, which is the one shape that could
  prove it. **The security fix was found while sizing something else**:
  `query.*` had been escaped at parse time for a long time, while `auth_user`,
  `auth_name`, `auth_email` and `auth_groups` came straight from the
  `X-Remote-*` headers and were escaped nowhere - two families in the same
  stash, documented in the same list, indistinguishable to an author. Found
  doing it: the admin bar concatenated the display name straight into HTML,
  with no template and so no filter to be wrong. The escaping went where the
  render variables are assembled and **not** at the auth boundary, because
  those same values are the input to access control and escaping them there
  would test an escaped value against an unescaped users file - a lockout
  rather than a leak, and invisible to any test whose fixture user has no
  character needing escaping. **A page whose template does not parse is now
  refused at the write**, where the author can still fix it, rather than
  rendering with every variable dead and one line in a log; 827 shipped pages
  were swept to prove the refusal catches only what it should. A capability
  refusal names the capability. Copy buttons have a colour of their own, being
  retrieval rather than commit, change or destroy.
- **0.11.9** (2026-08-31, EDGE) - **Ninety-four items from a live manager
  review, and a lockout that failed closed.** 0.11.8 shipped a visual layer;
  this is what that layer produced when a person used it, recorded one row per
  piece of feedback in `docs/review/`. **The defect that mattered most was not
  visual**: `local $/` scoped to a block rather than its sub meant the groups
  file was read as ONE line, so twenty-one groups became one and no nested group
  ever resolved - an account in `site-admins` was told "Manager access not
  permitted" though the shipped groups grant it through two levels. It failed
  CLOSED, a lockout rather than a leak, and every existing test put its user in
  a group holding the capability directly. **A composed document is refused, not
  quietly shortened**: a page rendered to PDF whose parts cannot all be read
  names the part and refuses, because a short PDF looks exactly like a finished
  one. The render is cached until one of its sources moves. Also: one expander
  idiom instead of four, narrow widths to 560px, blocked addresses moved to the
  plugin that does the blocking, and `whoami` saying WHERE a tool is callable.
  **Three fixes in this round changed nothing at all, silently** - an inline
  `style=` beating the sheet, a flex rule on an element the dense form makes a
  grid, and rules four hundred lines above what they had to beat - so a lint now
  holds a per-page ceiling on inline styles and a browser check looks at what
  rendered rather than at the source.
- **0.11.8** (2026-08-30, EDGE) - **A manager style an operator chooses, and a
  guide that is the stylesheet's contract.** Three sheets - `classic`, `modern`,
  `accessible` - selected by config, with `classic` the shipped default so an
  instance that never touches the setting sees the manager it had. The style
  guide is a page demonstrating every component, and a lint makes it a contract
  in BOTH directions: a class the guide names must have a rule, and a rule the
  sheet defines must appear in the guide - the second direction being how the
  manager came to have two expander idioms unnoticed. Barlow is bundled as 21
  `woff2` faces with its licence: no CDN, so an operator's manager does not
  phone a third party to render. A page can also become a branded PDF, and the
  data endpoint emits UTF-8 bytes and counts them - a familyhq holiday had been
  rendering as `Je?ne f?d?ral` because a character string reached a layer-less
  STDOUT.
- **0.11.7** (2026-08-29, STABLE) - **The feedback loop repaired, and three
  answers that were confidently wrong.** A lint now renders every manager page
  and checks the elements its script fetches actually survive - the gate had
  been unable to see a page at all, which is how a blank page shipped twice. A
  brief says WHEN it was true rather than implying now. An empty history says
  why it is empty instead of looking like a page nobody has edited. And
  `verify_token`'s drift was explained rather than absorbed into a new baseline,
  with a counter that can see it next time.
- **0.11.6** (2026-08-29, BETA) - **Two surfaces that disagreed about who may
  write.** `write_data` now honours a table's access rule, which the manager UI
  had been applying and the control API had not - the same question answered two
  ways by two code paths, which is the shape this release is about. The history
  overview applies the ACL to every entry rather than to the page it is shown
  on. An HTML comment stopped discarding the markup that followed it.
- **0.11.5** (2026-08-28, EDGE) - **An app's own users can write their own
  rows.** The row-level case the data plugin had not covered: an application's
  users, not the site's operators, writing to a table under a rule that names
  them. A visitor can be approved into a group in one step rather than three,
  and the operator never handles a password. A data table says who can read it,
  and a capability whose plugin is switched off says so instead of appearing
  available.
- **0.11.4** (2026-08-28, EDGE) - **Access control measured rather than reasoned
  about, and the instruments that did the measuring.** What every capability
  gate decides became a table that tests read as data, rather than a fact
  restated in each suite's own regex. A cookie-side gate can be proved by a
  test for the first time. A seeded group can be put back from its own row, a
  destructive verb needs the read it destroys, and a refused domain host says
  WHICH thing was wrong rather than that something was.
- **0.11.3** (2026-08-27, EDGE) - **Access control that is honest about itself,
  and one confinement gap closed.** A scopeless grant reaches no domain's table,
  where it had reached all of them. The vocabulary was settled and applied
  throughout: sysop is the app, sysadmin is the host, manager is the UI - three
  words that had been used interchangeably in an area where being approximate is
  expensive. A person has a name and an account has a login, and they stopped
  being the same field. The unlocks map is linted against the gate it describes.
- **0.11.2** (2026-08-26, EDGE) - **Roles an operator recognises, and
  `bind_form` finally has an inverse.** Binding a form wrote a change nothing
  could undo without editing the file by hand. The manager says the site is
  unwritable on its next write rather than failing silently, and a fleet of
  healthy sites stops reporting as though something were wrong.
- **0.11.1** (2026-08-26, STABLE) - **A tool run under sudo becomes the site
  owner before it writes.** Files created as root in a tree the web server must
  write to - the failure appearing later, somewhere else, as a permission error
  on a file nobody remembered creating.
- **0.11.0** (2026-08-26, STABLE) - **The release that checked its own
  instruments.** Four gates were found giving the wrong answer, and all four
  had been invisible because they either passed when they should not or failed
  for reasons that looked like somebody else's fault. The perltidy gate had
  been SKIPPING in every worktree - and every gate this project runs is run in
  a worktree - so it passed without examining a line, enforced only in the
  release build's staging clone. The bench baseline writer had been dead for
  eleven days, and each attempt DESTROYED the baseline it was replacing.
  Five stats tests failed for the ninety minutes after UTC midnight, daily,
  because they stamped their records at one instant and asked for the day of
  another. A release now refuses in a second, rather than nine minutes in,
  when the shipped practice briefing is stamped for a different version.
  **The correctness fix that matters most to a site**: one `json:` binding on
  a page stopped vouching for a `db:` binding on the same page - a table's
  rows had frozen indefinitely, with no warning, on a page split by how often
  its data changes, which is exactly what a careful author does. **And the
  reference stopped lying about caching**: `/docs/data-tables` said `live`
  mode is never cached; it is cached for the page's `ttl:` like any other,
  and an agent reasoned correctly from the wrong sentence and stopped a
  release to say so. Plus the four non-functional dimensions brought current
  for a stable cut - a re-captured performance baseline with its drift
  explained rather than absorbed, a timed restore rehearsal against the
  shipped artefact, this timeline, and a significant-change assessment
  covering twenty-five versions.
- **0.10.34** (2026-08-26, BETA) - **What a grant reaches, decided by the
  grant.** The four site-package verbs shared one confinement rule instead of
  four copies of it - `create` and `inspect` had been left open, so a token
  partner with no domain scope could not download a package but could build one
  for an unrelated domain on the same instance and read any manifest in full.
  The MCP twin went with them, and there the rule is stricter by construction:
  MCP has no cookie session, so there is no operator to exempt. A data table's
  `domain` is checked against the domains the instance actually serves at save
  time, and shows in both listings, so a migration of hand-typed hostnames
  cannot silently bind a table to a domain that does not exist.
- **0.10.33** (2026-08-25, EDGE) - **A grant decides what a partner reaches,
  and every surface says so.** A data table can belong to a domain: a confined
  caller reaches its own domain's tables and is not told the others exist, the
  refusal being word-for-word the one a missing table gets, so an instance
  cannot be enumerated by guessing names. A table naming no domain behaves
  exactly as before, so an instance carrying live tables loses nothing on
  upgrade. Package downloads are confined by the action rather than by whether
  a scope happens to be set. The capability floor stops describing the
  installation - internal paths withheld, plugin state answered only to a
  caller who may configure the site or holds what that plugin governs. A
  partner's brief is generated from its grant instead of typed, after one
  named seven capabilities where the account held seventeen. Housekeeping
  becomes a grant of its own in two tiers, `manage_briefs` is declared by the
  plugin that owns it, and a group says whether it is a role or a backend
  group.
- **0.10.32** (2026-08-25, EDGE) - **The review answered - every defect filed,
  fixed and tested.** Fifty-eight entries: the whole of a ten-part read-through
  of the engine, filed one defect at a time and closed the same way. A form can
  land in a data table. The link audit sees the root page. Cross-file seams
  became helpers, dead code came out, and a per-visitor binding that cost 3 ms
  came down to 0.8 ms. Eight of the review's own recommendations were refused
  on measurement rather than taste - each one tried, and each one shown to
  break something the reviewer had not run.
- **0.10.31** (2026-08-24, EDGE) - **The editors are modal, and the tidy
  tools.** The data manager's editors move into modals with the house frame,
  the descriptor form gains a YAML tab, and the safety-export tooling gets its
  tidy pass. Cut as the beta candidate.
- **0.10.30** (2026-08-24, EDGE) - **The briefs ring, the cap that reached the
  page, and the queue before the cut.** Briefs notify rather than wait to be
  found. A capability that had been reaching the rendered page is confined to
  the surfaces that own it.
- **0.10.29** (2026-08-24, EDGE) - **The consent banner, briefs out of band,
  and the twins agreeing.** A capability added after a group was seeded is
  never granted silently - the Groups page asks, and records the answer, so an
  upgrade cannot widen a grant on the operator's behalf. The brief store moves
  out of the content tree entirely. The API and MCP twins are pinned to answer
  alike.
- **0.10.28** (2026-08-23, EDGE) - **The field reports answered - menu,
  status, mirror, and the audit read.** Four things the field found: a menu
  that could not see every capability it gated on, a status that did not say
  what it had found, a theme mirror that went stale, and an audit read that
  needed a capability nobody had.
- **0.10.27** (2026-08-23, EDGE) - **The data manager, and a table that can
  finally be removed.** Dropping a table takes a safety export with it, so the
  irreversible verb stops being irreversible in practice.
- **0.10.26** (2026-08-22, EDGE) - **The data plugin becomes usable, and its
  second door gets a lock.** The direct data endpoint is gated the way the
  manager surface already was.
- **0.10.25** (2026-08-22, EDGE) - **A table can actually be declared.** The
  descriptor path completes: declare, migrate, and read back what was
  declared.
- **0.10.24** (2026-08-21, EDGE) - **DP-1 completes, and the plugin can be
  turned off.** A disabled plugin executes nothing - reads included, because a
  read is execution.
- **0.10.23** (2026-08-21, EDGE) - **The data plugin, end to end.** Typed data
  arrives: a declared schema, one place that decides what a value means, and a
  render path holding a handle it cannot write through.
- **0.10.22** (2026-08-21, BETA) - **The second beta, built from what the
  first one found.**
- **0.10.21** (2026-08-21, BETA) - **The multi-site fixes, pulled forward
  because edge could not test them.** Edge serves one domain; the defects were
  in the many-domain path, so the fixes went to the channel that could
  exercise them.
- **0.10.20** (2026-08-21, EDGE) - **What a week of real multi-site use turned
  up.** A page preview now knows which site it is previewing, and the rest of
  the per-domain seams a week of live use exposed.
- **0.10.19** (2026-08-20, BETA) - **The first promotion off the edge line.**
  Access rules now travel with content on every surface: deleting content
  drops its rules everywhere (previously only over WebDAV), and moving content
  carries them - which matters most for protected content, where a move to an
  ungated path used to relocate the file into the public document root with no
  rule following it. The access-rule store stays writable by the manager after
  a deploy (it was being locked out once per upgrade and repaired afterwards,
  so the only trace was a repair that always ran). The certified channel is
  wired end to end. Plus the content-history summary honouring scope, the
  visitor classifier answering per source rather than per address, an
  operator-settable asset cache lifetime, and a lint banning a Perl idiom that
  silently ate its caller's loop variable.
- **0.10.18** (2026-08-20, EDGE) - **The round the reviews drove.** A file
  upload could escape the content area into the engine's auth store and
  overwrite the cookie-signing secret while reporting success (SM418, found by
  a security review with a working reproduction); the content-history summary
  handed a scoped partner every other tenant's file inventory (SM419); an
  upgrade now invalidates rendered pages, so the first page an operator checks
  after upgrading reflects the build they installed (SM413 - a homepage had
  served the same render through four deployments). Visits and trails key per
  SOURCE rather than per address, so agents and people behind one NAT stop
  sharing a visit (SM417). Assets gain an operator-set cache lifetime (SM416).
  The outside-in ACL probe drops to the site user instead of refusing as root,
  so a deploy actually establishes whether the front end gates content
  (SM426). Plus the certified channel wired end to end (SM423), form delivery
  reaching parity across all three surfaces (SM421), and a lint banning a Perl
  idiom that silently ate its caller's loop variable (SM420).
- **0.10.17** (2026-08-19, EDGE) - **The beta candidate, built from the field's
  own findings.** The multi-domain site-package apply works: its safety snapshot
  scopes to the target's content root instead of tarring the whole docroot
  (SM412, field-diagnosed by the partner agent it blocked). The visitor
  classifier is askable without generating traffic (`--classify`, SM392).
  Session verification is one module with one chain (SM411), ready for the
  surfaces that cannot sit behind the auth wrapper. Contract plugins are born
  disabled and DISABLED MEANS OFF (SM409/ADR 0009); legacy plugins are
  untouched. Plus the 402 fix proven against its field case, the publish-flow
  trap named in the connector docs, and this timeline itself (SM407).
- **0.10.16** (2026-08-19, EDGE) - **The build says which commit it validated.**
  A release's manifest now carries `validated: {commit, files, tests}` naming the
  exact gated commit, mirrored in a committed `docs/releases/GATE-LOG.md` row
  (SM400) - so "is this build what it claims" is answerable from the artefact.
  Forms gain structured answers (SM401): `radio:`, `checklist:` and
  `checklist-qty:` rules alongside `select:`, with quoted multi-word options
  across all four. The form handler stops recording an identity it cannot verify
  (SM402): submission metadata now says how it was captured rather than naming an
  unverified account. The stats writers become atomic in the write, not just the
  rename (SM404) - a disk-full no longer promotes a truncated day file over a
  good one. And six standing decisions are recorded where they belong, including
  the seven-class visitor model (an assistant fetching for a person is a visit; a
  training crawler is not) and behaviour-beats-declaration (SM405, decided ahead
  of build).
- **0.10.15** (2026-08-19, EDGE) - **The security header set stops being a claim.**
  A Content-Security-Policy ships enforcing, with an operator dial and a
  hash-based allowance for the one inline script pattern shipped layouts use
  (SM379/SM380, SM384 fixing the hash on non-ASCII scripts). Every response path
  now passes the header choke point - including 402/403 (which also rendered
  into the wrong docroot on multi-domain instances), the registries, and the
  `.well-known` endpoints (SM381). Engine chrome resolves on content-rooted
  secondary domains (SM382). Engine-served statics revalidate (SM387). The
  release stage stamps VERSION and NEXT_VERSION together (SM383).
- **0.10.14** (2026-08-18, EDGE) - **A cache clear that deleted pages, and the
  second copies.** Anyone running 0.10.13 or earlier on a migrated site should
  take this one: `invalidate_cache("/")` DELETED the homepage rather than
  clearing it, and the defect repaired its own symptom on the next render.
  Alongside: the engine and the site side stop inlining scripts (SM352, the
  ground the CSP stands on), `preview a path as the public sees it`, the notice
  store readable remotely, release.sh reduced to two commands, and the coverage
  gate sharded so it runs at last.
- **0.10.13** (2026-08-17, EDGE) - **The control reported success, and had not
  done the work.** Cache invalidation now distinguishes cleared /
  nothing-cached / no-such-path instead of reporting success unconditionally
  (SM367). One answer per question whichever channel asked - API and MCP parity
  - with a published action reference. Visitor analytics gain device class and
  opt-in internal search terms (SM336), and a visit gains a boundary and a
  sequence, the ground the later trails stand on.
- **0.10.12** (2026-08-16, EDGE) - **The numbers say what they mean.** A
  statistics release from a partner-agent review of a live instance's own
  traffic: every item is a number that was reported confidently while
  describing something other than its name. The headline visitor number FALLS,
  and that is the fix. Aggregates carry their counting basis so a change of
  rules is distinguishable from a change of traffic (SM338).
- **0.10.11** (2026-08-16, EDGE) - **Protecting content works from the surfaces
  built to do it.** The 0.10.10 field pass measured SM283 closed from outside -
  every protected file gating, the whole store private - and found only the
  OPERATOR could get a site into that state: the partner-agent and API surfaces
  could not. This release is that, plus the structural change stopping it
  recurring.
- **0.10.10** (2026-08-15, EDGE) - **What the engine reports, and what a visitor
  actually receives.** Field-test follow-ups from the 0.10.9 pass: reporting
  surfaces aligned with served reality, the access pickers that name a person
  the same way in four places, and no operator action required - nothing here
  changes a rule or a stored format.
- **0.10.9** (2026-08-14, EDGE) - **The sweep that finishes the 0.10.8 move.**
  `lazysite acl reapply` (SM296/SM286) re-issues every stored access rule so its
  content actually leaves the document root - the upgrade action no package can
  perform, because protecting content moves it only on the ACT of protecting.
  Fixes a crash that left content stored-as-protected and still served
  (SM296: `File::Path::make_path` croaks, so the guard after it was
  unreachable). The FastCGI pool worker can now BE the front door (SM294),
  answering the hot path in-process (137x) and forking for the rest. `meta_desc`
  and `meta_title` front matter (SM300) separate a page's description from its
  visible subheading; `llms.txt` index-page links resolve (SM299);
  `regenerate-registries` reaches the control API (SM301); bundled docs stop
  crowding a site's own `llms.txt`. Plus the release compliance gate,
  `docs/compliance/`, and the fourth eight-dimension review.
- **0.10.8** (2026-08-13, EDGE) - **The front end stops making decisions.**
  Protecting content MOVES it out of the document root into a private store
  (SM286); the engine tree can move out too (SM293 step 2); the registries are
  generated on request rather than written to disk (step 3); the trust-header
  gate becomes an enforced application control rather than a front-end
  configuration requirement (step 4); and a front end can be ONE RULE, with
  `Lazysite::FrontDoor::route()` making every decision the vhost templates used
  to (step 5). SM248, SM268 H17 and SM283 were all the same cause - security
  living in configuration lazysite ships as a template, cannot test where it is
  installed, and mostly cannot see.
- **0.10.7** (2026-08-11, EDGE) - SM283's remedy: the missing Hestia **nginx
  proxy template**, which hands a static request back to the origin whenever an
  ACL store exists, with an `X-Lazysite-Front` observable checkable by curl with
  no credentials. Also `lazysite check --check-acl` (SM285), which lets a site
  prove its own gating from outside, and the access-control programme SM287-SM292
  - a root ACL entry that protects the whole site, real partner groups resolved
  on MCP and the control API, and one way to express access on every surface
  including a CLI verb.
- **0.10.5 / 0.10.6** (2026-08-10 / 2026-08-11, EDGE) - what an adversarial
  security review found and what it cost to prove, then the release that told an
  operator to do something it had not made safe.
- **0.10.1 - 0.10.4** (2026-07-27 - 2026-08-09, EDGE) - form spam controls and
  submissions tooling; what the platform knew and did not say; MCP surface parity
  with instructions no longer accepted quietly (SM239); and success reported for
  work that did not happen - the recurring defect class this line is named for.
- **0.10.0** (2026-07-27, STABLE) - promotes the 0.9.11-0.9.17 beta line to
  stable: durable stats store and trends, token-lifetime control, live-config AI
  discovery, sudo-safe permissions and repair, manager-UI polish.
- **0.9.15 - 0.9.17** (2026-07-25 - 2026-07-27, BETA) - manager UI polish
  (domains configure-modal, promote-in-dropdown, hints), token-lifetime control
  plus live-config AI discovery, and a durable stats store with trends.
- **0.9.14** (2026-07-24, EDGE) - **Theme authoring + external-design (Figma)
  ingestion**, plus operator features. `theme_tokens` (SM204) reads a layout/theme
  token vocabulary in one call; `create_theme` (SM205) is a validated one-call theme
  scaffold (copy-nearest-and-adapt when `css` is omitted) with eager `theme.json`
  validation on the `write_file` path; `layout.json` gains an optional declarative
  `tokens` block with a non-fatal activation warning (SM203); the layout catalogue
  carries description + tags (SM206); `layout.tt` reads as text (SM202); and a new
  `/docs/integrations/` namespace ships a **Figma dual-MCP helper** (SM208) - bridge
  the Figma MCP source and the lazysite MCP destination, transfer identity as tokens,
  rebuild rhythm in CSS, no lazysite-side Figma fetcher and no stored credentials,
  with a `build-from-figma` recipe in `describe_capabilities`. Operator features:
  promote a sub-user to top level + `scope_independent` (SM194); content-history
  file list + revision statistics (`git-history-summary` / `list_content_history` /
  a Files-page History overview, SM199). Fixes: the discovery check accepts the
  dynamic `${REQUEST_SCHEME}://${SERVER_NAME}` `site_url`; a passwordless/token-only
  account can be removed; a no-`ui` account at `/manager/` gets a clear terminal
  message instead of a login loop; a group change warns before removing an account's
  last manager-access group.
- **0.9.13** (2026-07-23, BETA) - Site integrity, capability clarity + connector
  reliability. Engine-served system pages (login/claim/40x moved to the protected
  `lazysite/templates/system/` tree, content-root → docroot → default fallback,
  self-healing, SM201); site-package migration completeness (token-client
  site-backup-download, identity-keep-on-apply with `adopt_identity` opt-in, theme
  asset mirror on apply, SM193); connector reliability (distinct 401 `data.reason`,
  30-minute connect code with surfaced expiry, fresh-chat guidance, SM200; connected
  detection + capability-aware `tools/list`, SM196); capability clarity
  (grant-to-enable hints SM191, channel-surface grid ticks SM197, inert-group
  warning SM198); and content-history status as a real health probe.
- **0.9.10 / 0.9.12** (2026-07-21 / 2026-07-23) - 0.9.10 STABLE promotes the hardened
  0.9.x line (carrying the 0.9.9 data-loss + security hardening) to stable; 0.9.12
  (superseding the withdrawn/burned 0.9.11) folds in field fixes - the `lzs_session`
  JS-marker login-loop cleared at both bounce points (SM188), the write path refusing
  a raw-mode script-capable content page on save/PUT (415, SM189, ADR 0006 extended),
  and `.well-known/oauth-*` returning 404 when OAuth is off (SM190 partial).
- **0.9.9** (2026-07-21, BETA) - **Data-loss + security hardening.** Atomic config +
  auth-store writes with store-lock serialisation (never a truncated
  `lazysite.conf`/credential store); manager file-path confinement against the
  canonical resolved path (F1 traversal); `file-download`/`file-zip-download` enforce
  read-ACL + `dav_scope` (F2); `principals` capability-gated; the dormant
  `manage_domains`/`feedback`/`read_submissions` grants surfaced (F3); a switched-off
  service answers `200 {ok:0, service_disabled}`; dormant-capability indicators
  (SM180). See the private advisory.
- **0.9.5-0.9.8** (2026-07-19 to 2026-07-20, BETA) - The **form-submissions viewer**:
  an in-manager escaped table (SM182), then v2 - a scrollable modal, per-row delete
  (`manage_forms`, audited), and agent read via the least-privilege `read_submissions`
  capability + `read_form_submissions` MCP tool (SM187). **Site-package migration in
  the UI** (SM183): Export-site per domain and a Backups Site-packages panel
  (list/download/upload/apply/delete) with an apply preview; language travels in a
  package and the default site is exportable (SM185). Plus the caps-within-session
  fix (a granted capability reflects without re-login).
- **0.9.4** (2026-07-19, STABLE) - Certifies the 0.9.x security-hardening line:
  cross-plane capability consistency; default-off service killswitches with a
  Services panel; the SM042 config-save migration onto `config-set`; the SM127
  token-path fix; the `domain-check` SSRF guard; tenant-token isolation; the
  capability-grid grantability fix; the form-targets data-loss fix; the nav-read
  path-leak fix; WebDAV PUT RFC-4918 409 compliance; and expired-token rotation
  guidance (0.9.2/0.9.3).
- **0.9.0** (2026-07-19, EDGE) - Cross-plane permission consistency + service
  killswitches. Every remote surface (MCP / OAuth / control API / token exchange) is
  now **off by default** behind a conf killswitch surfaced in Settings → Services
  (BREAKING, operator-recoverable); WebDAV nav/form editing needs
  `manage_nav`/`manage_forms`; the Config page saves each key through the audited
  `config-set` (SM042); plus the token-path regression fix, the `domain-check` SSRF
  guard and tenant-token isolation.
- **0.8.0** (2026-07-18, STABLE) - **Second stable release**, cut from 0.7.28 on the
  2026-07-18 eight-dimension review. Promotes the whole 0.7.x line to stable:
  first-class multi-site (SM151), the domain access-control model (SM165), content
  history that follows renames and never leaks across delete/recreate (SM175), and
  the complete multilingual language-set feature (SM179 P1-P8). Fixes the serious
  stored-XSS / response-header-injection path where a front-matter `lang:` reached
  `<html lang>`/`Content-Language` unescaped (now a bare language tag), a
  `domain-add` CRLF gap, the raw/api script-capable `content_type` downgrade, and
  the manager-API trust gate; a breadth security-testing pass added structural
  guarantee tests and negative tests (privilege-escalation confinement,
  path-traversal sweep, login-rate-limit fail-open). DoC signed at the cut.
- **0.7.28** (2026-07-18, BETA) - Multilingual completion + cache correctness +
  domains/manager UX. Engine-emitted chrome is localised (SM179 P8: the bare 404,
  the no-403.md fallback and the auth reject pages, via a built-in English table
  overlaid by `lazysite/i18n/<lang>.json`, fail-closed; the 404 fallback escapes
  the request URI). Language config is first-class - `lang`/`lang_group` settable
  via `domain-set`, the CLI and the Domains Add + Configure forms;
  `whoami`/`lang-status` detect a set even when `lang_group` is only on aliases;
  `lang-status` gated on `manage_content`. A conf-only change now invalidates the
  page cache (no more stale `Content-Language`/chrome under any process model);
  per-host caches are listed and cleared per host on the Cache page; the manager
  preview UTF-8 double-encode is fixed. The domain "alias" concept is retired for a
  "Copy settings from" pre-fill on Add domain. Manager UX consistency (token
  picker, Edit/Delete verbs, primary Save) and editor fixes (exit-to-folder,
  reserved-file warning). ADR 0008 records the stable compatibility-freeze scope.
- **0.7.27** (2026-07-18) - Multilingual language sets (SM179 P1-P7): sibling
  per-language content roots linked by a shared `lang_group`, with engine-supplied
  `[% languages %]` switcher data, `hreflang`/`x-default` (layout + sitemap),
  `<html lang>`/`Content-Language`, content-root-first `json:`, layout chrome
  strings (`[% t %]`), a `lang-status` coverage report, and whoami/MCP
  discoverability. Theme/layout delete-safety accounts for every domain
  (sub-domains as first-class peers, SM177); an audit-log domain target no longer
  opens in Files (SM178).
- **0.7.26** (2026-07-18) - Content history follows renames and never leaks across
  delete/recreate (SM175); a domain-owned access-control model with per-user locks
  (SM165); compound groups (group-of-groups, SM121); and a manager batch - theme
  install no longer auto-activates (SM176), nav-refresh signalling (SM168), the
  nav editor names its file (SM169), sub-user audit view (SM173).
- **0.7.24-0.7.25** (2026-07-18) - Site packages + `manage_domains` + nav
  domain-awareness (SM139 family); forms discoverability for agents (SM161); and a
  run of manager UI / key / WebDAV fixes (SM162-172).
- **0.7.18-0.7.23** (2026-07-16) - Group-level domain delegation (SM155) with a
  pre-DNS domain preview and first-class aliases; the domain config check +
  domains panel (public-IP, cert SANs, proxy-aware); Files breadcrumb fix.
- **0.7.3-0.7.17** (2026-07-10 to 2026-07-16) - First-class multi-site: many
  domains on one instance with per-host content roots and confinement (SM110 /
  SM151); WebDAV theme/layout authoring (SM071); session registry + revocation
  (SM141); and the run of edge fixes across auth, WebDAV, themes and the manager.
- **0.7.2** (2026-07-10) - Packaged distribution (SM139): the
  `lazysite-common` + `lazysite-hestia` debs, the `lazysite` CLI
  (provision/upgrade/sites, root-refusal by design, the site registry), fleet
  `update_policy` + `--force-security` (honoured only for manifests declaring
  `security_critical`), one-command Hestia onboarding
  (`lazysite-hestia-domain`, CGI + FastCGI templates), and the hardened
  `lazysite-check` (post-fix re-report, CGI-identity evaluation).
- **0.7.1** (2026-07-10) - Persistent runtime (SM142): the dual-mode FastCGI
  accept loop - per-site worker pools, modules compile once; measured
  cache-hit 62.2 ms CGI → 0.4 ms FCGI (155x); plain CGI byte-identical.
- **0.7.0** (2026-07-10) - **First stable release**, cut on completion of the
  2026-07-10 eight-dimension review resolution: seven refusal-level code
  fixes, the RELIABILITY.md SLO/RTO/RPO declarations, the pentest-gate ADR +
  significant-change register, the five-year support period + Declaration of
  Conformity, coverage floors ratcheted to 75/62 across eight gated CGIs, and
  the retired-terms/shellcheck lint gates.
- **0.6.10** (2026-07-10) - Backlog housekeeping: thirteen shipped items closed;
  SM139 (packaged distribution) promoted to next up; SM141 (session registry +
  revocation) scoped.
- **0.6.8-0.6.9** (2026-07-10) - First-party analytics (SM140): lazysite records
  its own anonymised access log and the Stats page reads it as the primary source
  (zero web-server setup); the AI analytics export (`analyse_visitors`) ingests
  the same log; the server log stays as the fallback/diagnostics tier; unhandled
  processor errors now answer a clean 500.
- **0.6.5-0.6.7** (2026-07-09) - **Breaking:** manager access granted by groups
  only - `ui` / `manage_users` capabilities; the legacy `manager_groups` conf key
  retired with an automatic migration (SM138). Robustness round: installer
  ownership repair scoped to root-owned files (0.6.6); TT compile-cache immunity
  with a loud manager-layout failure banner and a `lazysite-check` cache/tt probe
  (0.6.7); fresh-install self-heal (`setup-sysop` guarantees the admin group's
  capabilities) and manager UI field fixes (autofill, bell states).
- **0.6.2-0.6.4** (2026-07-08) - Notifications (SM136): the `notifications`
  capability, the manager bell, XMPP delivery via the notify-xmpp plugin, and
  human-event notices; SMTP password field + staged connection validation
  (SM137, Validate button placement fixed in 0.6.4).
- **0.6.1** (2026-07-07) - Multi-step (wizard) forms (SM098); full-system backup +
  cross-domain migration (`install.pl --restore-full --domain`) + a consolidated
  Backups page; page alias redirects (`aliases:`, SM134); recent-change markers on
  the Files/Users pages (SM103); the visitor's IP as `[% client_ip %]` with a
  `nocache:` flag (SM135).
- **0.6.0** (2026-07-04) - Stability milestone following the eight-dimension
  non-functional review; no code change from 0.5.41.
- **0.5.0-0.5.41** (2026-05 - 2026-07) - The 0.5.x line: WebDAV theme/layout
  authoring, group-based capabilities (SM095, channel × action), the MCP capability
  map + quickstarts (SM126), the STRIDE threat model and ADRs, the perlcritic
  severity-3 + perltidy gates, manager/remote separation (SM127), the bad-URL
  auto-blocker (SM128), migrate-to-local (SM096), and install channel controls.
  See `CHANGELOG.md` for the full per-release detail.
- **0.4.17** (2026-06-26) - Dev-server `--auto-index`: browse any tree of Markdown
  with zero writes; production never lists a directory, now test-locked.
- **0.4.16** (2026-06-25) - UTF-8 corruption fully fixed (the second encoding layer);
  `read_nav`/`set_nav` complete the page API.
- **0.4.15** - UTF-8 fix in JSON responders; front-matter quote stripping; page-aware
  MCP verbs (`create_page`/`delete_page`/`rename_page`); validate-on-write; MCP tools
  reference doc.
- **0.4.14** - Multi-word `select:` options; stale-lock take-over; file size in Files.
- **0.4.13** - Block Markdown inside `:::` boxes; `whoami` auth lifetime; audit
  targets link to the editor.
- **0.4.12** - Connector tools `preview_page`, full tool manifest in `whoami`,
  `copy_file`, `get_permissions`, `list_form_handlers`/`bind_form` (SM088); clearer
  401s + `kind`; nav-save clears all caches; audit-log usability.
- **0.4.11** - More form field types; safer connector tools (`replace_text`,
  `search_files`, `page_status`, `read_page`, `list_pages`, `validate_page` with the
  public-data warning, `audit_site`); generated-index refresh; audit pagination.
- **0.4.10** - Non-destructive overlay install; content backups + Backups page.
- **0.4.9** - Audit records material events only; `invalidate_cache`; reliability with
  slower assistants (512 KB read cap).
- **0.4.8** - Client-neutral connector (Claude.ai + ChatGPT; hints + output schemas);
  block-HTML `<p>` unwrap; `manage_content` capability.
- **0.4.7** - OAuth 2.1 authorization server for the connector.
- **0.4.6** - One-click Claude.ai setup; injection-resistant onboarding briefs.
- **0.4.5** - Users/Groups page layout fix.
- **0.4.4** - Audit WebDAV reads (quietable); MCP-vs-API onboarding docs.
- **0.4.3** - Files unified rights editor; `@group` ACLs over WebDAV; WebDAV + MCP
  writes in the audit trail (shared modules).
- **0.4.2** - Files-manager UI v2; richer audit (origin/target); Hestia `lib/` fix;
  **MCP server v1**.
- **0.4.1** - Files-manager overhaul; field-report fixes (theme-asset mirror, mixed
  form targets, audit target).
- **0.4.0** - Modular refactor (SM079) + security hardening + conformance milestone
  (perlcritic gate, SBOM gate, bench/secrets gates, `bump-version.pl`, five-audience
  docs, coverage instrumentation, fleet updater).
- **SM070–SM074** (rolled into the 0.4 line) - WebDAV publishing + per-user ACLs;
  WebDAV theme/layout management with self-service activation; self-service
  credentials + claims + TOTP + account expiry; per-file `.brief` sidecars; per-file
  ownership + ACLs.
- **0.3.0** (2026-04-23) - Release tooling split; SBOM/manifest generated per release;
  first upgrade-aware installer.
- **0.2.0–0.2.19** (2026-04) - Hardening + manager maturation: structured logging,
  the Config and Files apps, method-keyed CSRF, mass-logout, login rate limiting, the
  D013 layouts/themes reshape.
- **0.1.0** (2026-04-21) - Initial release: the Markdown→HTML processor with TT
  layouts/themes and scan/include/oembed; built-in + reverse-proxy auth; forms with
  an SMTP helper; the web manager; the x402 demo; the dev server; the test suite.

---

# Part XV - Roadmap

**Actionable now:**

- **SM085 - Git backend / changesets** - phase 1 SHIPPED (content history + the
  git-sync remote plugin, see Part V). What remains is phase 2: the transactional
  agent-changeset workflow (begin -> diff -> commit -> rollback) on the same core.
- **SM084-restore** - the in-manager "restore this snapshot" action (list/create/
  download already ship).
- **SM075 - Wildcard multi-tenant hosting** - many ephemeral sites under one wildcard
  vhost, auto-provisioned, with promote-to-permanent.

**Candidates / research:**

- **SM086 - Pandoc-construct renderers** - datatables, charts, boxes, definition
  lists, citations rendered for the web from the same source that makes a branded PDF.
- **SM089 - 3D-rendered layout** - a WebGL layout category, proving the rendering
  substrate itself is pluggable.
- **SM090 - Social syndication / POSSE** - ActivityPub + AT Proto, lazysite as the
  canonical store (publishing-format slice first).
- **SM092 - Gopher + Gemini services** - read-only public front-ends over the same
  content tree, the natural next "thin transports."

---

*This reference was synthesised from the lazysite source, the `starter/docs/`
documentation set, the `docs/feature-requests/` record, and the CHANGELOG. The
version it describes is named once, in the subtitle at the top - deliberately
once, because a document that dates itself twice is a document with two things
to keep in step. For the authoritative detail
of any feature, read the cited script or doc; for the "why", read the corresponding
`SMxxx` feature-request.*
