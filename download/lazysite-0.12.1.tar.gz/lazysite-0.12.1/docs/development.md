# Development

Developer-facing notes for the lazysite repo. User-facing docs live
under `starter/docs/` and ship inside every installation.

## Working with CC

The development assistant edits the working tree in place at
`/srv/projects/lazysite` and leaves it uncommitted. The operator
(with push rights) reviews and commits; releases are separate from
commits.

The previous `/home/claude/lazysite` sandbox + rsync arrangement was
retired 2026-05-22 (see CLAUDE.md). There is no separate sandbox copy
to sync from; commit.sh commits the in-place tree (SM070).

### Flow overview (SM063, in-place since SM070)

Two scripts, each doing one thing:

- **`tools/commit.sh`** - commits CC's in-place working-tree edits
  with CC's message and pushes to `origin/main`. No tagging, no
  version bump, no tarball build.
- **`tools/release.sh`** - cuts a tagged release from any
  commit on main. Fresh staging clone, full test suite, SBOM
  strictness gate, tarball, tag, push tag. Does not modify
  main.

Main is *unstable*: every commit lands, no gate, no version
bump. Tags are the stable identifiers. Pull a tag if you want
a stable version; pull main if you're developing.

### Commit convention (for CC)

CC writes one file per session:

- **`.commit-message.md`** at repo root. Entire file becomes
  the commit message body. Convention: short title-style first
  line (~72 chars), blank line, markdown body describing
  what changed and why. Example:

  ```
  SM063: split commit and release into two scripts

  Replaces pre-release.sh + make-release.sh. commit.sh handles
  rsync-and-push; release.sh handles test-tag-tarball. Main
  becomes unstable; tags are the stable identifiers.
  ```

Anything else CC used to produce (release-notes, prep scripts,
version-bump commits) is gone. One session, one file, one
commit.

### Running commit.sh

```
tools/commit.sh
```

Preconditions are verified up front (a git working tree, on
main, `origin/main` up to date, CC's `.commit-message.md`
present). Any failure aborts before committing.

The in-place working tree is expected to carry CC's edits;
commit.sh stages and commits them with `git add -A`.
`.commit-message.md` is gitignored, so it is never staged.

On success: commit lands on origin/main, CC's
`.commit-message.md` is deleted so the next session starts
clean.

If the working tree is clean (no edits), commit.sh exits 0
without committing and leaves `.commit-message.md` in place
for a future run.

## Releasing

Release produces a tarball, an `.sha256`, and a git tag
pointing at a commit on main. Tarballs live at
`/srv/projects/lazysite/dist/lazysite-VERSION.tar.gz`.

Main is never modified. Any commit on main is a potential
release target. Whatever `VERSION` says in the committed tree
is the committed value; the RELEASE version lives in the tag
name (`vX.Y.Z`), not a per-release commit.

### Where the gate runs, and why it matters

`release.sh` stages a clone and runs the **entire gate** in it - the full suite,
the perf bench and a Devel::Cover run. That last one is the constraint, and not
in the way anyone expects.

**Devel::Cover writes one directory per instrumented process.** This suite drives
real CGI subprocesses rather than mocking them, so a gate run produces hundreds
of thousands of small directories - two integration test files alone produce 53.
It exhausts a filesystem's **inodes**, not its bytes.

That is why the staging location is `${LAZYSITE_STAGE_DIR:-${TMPDIR:-/tmp}}` and
overridable with `--stage-dir`, and why the pre-flight check reads `df
--output=iavail` rather than free space. On this host `/tmp` is a 4.8G tmpfs with
a fixed 1,048,576 inodes; a release fills it while reporting 3% of bytes used, so
`df -h` looks healthy right up to the failure. **Build scratch belongs on `/srv`
here** - the root filesystem is small and `/tmp` cannot hold a gate run.

Point it once and forget it:

```bash
export LAZYSITE_STAGE_DIR=/srv/tmp
```

### Cutting a release

Interactive form - release.sh proposes the next patch bump
from the most recent `v*.*.*` tag and prompts (SM064):

```
tools/release.sh
# Latest tag: v0.2.19
# Release as 0.2.20 [Y/n/edit]?
```

Answers:

- `Y`, `y`, or empty → proceed with the proposed version.
- `n` → abort with no side effects.
- `edit` or `e` → prompt for a version string, validate as
  X.Y.Z, then proceed. Useful for minor or major bumps.

Non-interactive form - pass VERSION explicitly to skip the
prompt (matches 0.2.19 behaviour):

```
tools/release.sh 0.2.20
```

Both forms default to releasing `origin/main` HEAD. Tag
annotation is the target commit's own message.

Other forms:

```
tools/release.sh 0.2.20 --commit abc1234     # specific commit
tools/release.sh 0.2.20 --notes NOTES.md     # override annotation
tools/release.sh 0.2.20 --commit HEAD~3 --notes NOTES.md
```

### What release.sh does

1. Proposes / accepts VERSION (see above), verifies it's
   semver and the tag is unused.
2. Stages a fresh clone of `/srv/projects/lazysite` at
   `/tmp/lazysite-release-$$/`.
3. Checks out the target commit (detached HEAD in staging).
4. Runs the full Perl test suite via `prove -r t/`.
5. Runs `tools/manifest-to-sbom.pl --strict`. Aborts if any
   `use Some::Module` in shipped code is missing from
   `dist/config/sbom-deps.json`.
6. Builds the tarball via `git archive`. Content matches the
   target commit exactly; no staging-dir edits leak in.
7. Computes SHA-256, writes the `.sha256` sidecar.
8. Tags the commit in the ORIGIN working tree (not staging)
   so the tag is immediately pushable. Annotation from
   `--notes` file if given, else the commit's own message.
9. Pushes the tag.
10. Copies tarball + sha256 to `/srv/projects/lazysite/dist/`.
11. Removes the staging dir.

On any abort, the staging dir is retained and its path
printed so the operator can inspect what failed.

### No version-bump commit

Unlike the pre-SM063 flow, release.sh does NOT commit to
main. `VERSION` and `NEXT_VERSION` files in the committed
tree stay at whatever the last commit left them at. The
release identifier is the tag name. Operators looking for
"what version is this" run `git describe --tags` on a checkout
or read the tag.

This is intentional: the pre-SM063 flow shipped three
classes of regression (audit findings saved as
`.release-audit.md` while SM062 cleared the backlog) in
part because the release flow rsync'd, tested, committed,
tagged, and version-bumped in one tangled step. Separating
commit from release removes the coupling.

The files are still kept roughly current for human clarity (the 2026
seven-dimension review flagged them stuck at 0.2.18 while releases were at
0.3.x): run `tools/bump-version.pl` after a release to promote `NEXT_VERSION`
into `VERSION` and advance `NEXT_VERSION`. It does not commit - fold it into a
normal commit - and the **git tag remains the authoritative release
identifier**.

### Strict dependency check

`release.sh` runs `tools/manifest-to-sbom.pl --strict`. This:

1. Walks every file in `release-manifest.json` with `.pl` or `.pm`
   extension.
2. Parses every `use` and `require` statement.
3. Skips Perl pragmas (`strict`, `warnings`, `feature`, etc).
4. Fails the release if any module name is not listed in
   `dist/config/sbom-deps.json`.

Consequence: you cannot add a `use Some::Module` to shipped code
without also adding an entry for it to `sbom-deps.json`. This
prevents SBOM drift - the metadata stays in sync with what the
code actually imports.

### Adding a new dependency

1. Add the `use`/`require` in the code.
2. Open `dist/config/sbom-deps.json`.
3. Add an entry under `modules`:

   ```json
   "Some::Module": {
     "core": false,
     "license": "Artistic-1.0-Perl",
     "debian_pkg": "libsome-module-perl",
     "rhel_pkg": "perl-Some-Module",
     "alpine_pkg": "perl-some-module",
     "used_by": "what lazysite feature pulls this in"
   }
   ```

4. Run `tools/manifest-to-sbom.pl --strict` (or let the next
   `tools/release.sh` catch any omission) to confirm it passes.

If `license` is genuinely uncertain, use `"UNKNOWN"` and flag in
your commit message. Do not guess.

### Files involved

| File | Role |
|---|---|
| `VERSION` | Committed value, informational only under SM063. Release version lives in the tag name. |
| `NEXT_VERSION` | Vestigial under SM063. No longer consumed by the flow; still in the tree for historical reasons. |
| `release-manifest.json` | File catalogue with SHA-256 and install targets. Committed; checked by `--strict`. |
| `sbom.json` | CycloneDX SBOM covering source + direct deps. Committed; checked by `--strict`. |
| `tools/build-manifest.pl` | Manifest generator. |
| `tools/manifest-to-sbom.pl` | SBOM generator + strict dep check. |
| `tools/commit.sh` | In-place working tree → main push. SM063; in-place since SM070. |
| `tools/release.sh` | Test + tag + tarball. SM063. |
| `dist/config/classification.json` | Rules mapping repo paths to install targets and buckets. |
| `dist/config/sbom-deps.json` | Curated metadata (license, distro packages, used_by) for every module the code imports. |
| `dist/` | Release artefacts (tarball, .sha256). Root is gitignored; tarballs force-added. `dist/config/` is tracked. |

### Verifying an installed manifest

Once D021c lands, the installer writes the manifest under the
install root. Until then, you can verify a staged tarball:

```
tar xzf dist/lazysite-0.1.0.tar.gz -C /tmp
/tmp/lazysite-0.1.0/tools/build-manifest.pl \
    --staged /tmp/lazysite-0.1.0 \
    --out    /tmp/lazysite-0.1.0/release-manifest.json \
    --check
```

`--check` reads the existing manifest and verifies every listed file
exists with matching size and SHA-256. Exit 0 clean, non-zero with
a diff summary on mismatch.

### Manifest classification buckets

Each shipped file falls into one of three buckets:

- **code** - overwritten on every upgrade. Scripts, system theme,
  manager UI pages, vendored assets.
- **seed** - installed on a fresh install. On upgrade, the installer
  (D021c) overwrites only if the on-disk SHA matches the
  last-installed manifest entry, i.e. the operator has not edited
  the file. Landing pages, user docs, `.example` templates, feed
  templates.
- **runtime** - directories created by the installer at install time
  and never touched again. Per-install credentials, cache, logs,
  edit locks.

Rules and overrides are defined in
`dist/config/classification.json`. Adding a shipped file means
either matching an existing rule or adding a rule/override.

## Installer (install.pl)

`install.pl` at repo root is the real installer; `install.sh`
is a thin `exec perl install.pl "$@"` wrapper that preserves
the historic invocation. The Perl script reads
`release-manifest.json` at the tarball root and tracks
installed state at `{docroot}/lazysite/.install-state.json`.

### Three modes

The mode is decided by whether `.install-state.json` exists
at the destination:

- **fresh**: no state file. Walk the manifest, install
  everything, write state. No backup (nothing to back up).
- **upgrade**: state file present, manifest version differs.
  Compare manifest against state per-file: overwrite code
  always, preserve operator-edited seed, remove unedited
  orphans, leave edited orphans with a warning. Back up
  everything tracked in state before any changes.
- **reinstall**: state present, same version. Same logic as
  upgrade; used to recover from corruption or re-apply after
  manual edits.

## The tidy gate is changed-code-only, deliberately

`t/lint/06-tidy.t` runs `tools/tidy-check.pl`, which flags only lines a change
touched since the last release tag - not the whole tree. The existing tree keeps
its hand-formatting.

Written down here because it is surprising: running `perltidy` across the
repository produces a long list of files that are **not** defects and that the
project has decided against reformatting. A reviewer who does that and files the
result has measured a standard this project does not hold. New files should be
tidied wholesale; existing ones only where you touched them.

### Backup format

Pre-upgrade tarball at
`{docroot}/lazysite/backups/lazysite-backup-{YYYYMMDD-HHMMSS}-pre-{new-version}.tar.gz`.
Contains every file listed in the pre-upgrade
`.install-state.json` plus the state file itself. `tar`
shells out; backup paths are absolute (captured via
`--absolute-names`). Extract uses relative mode (no
`--absolute-names`) into a temp dir, and `install.pl`
iterates the state file's keys to copy each file to its
real destination.

Retention: `backup_retention` in `lazysite.conf`, default 3.
0 keeps all; negative is an error.

### Imperative post-steps

A few steps can't be captured declaratively in the manifest:

- `cgi-bin` symlinks for `form-handler.pl` and
  `payment-demo.pl` (Apache routes `/cgi-bin/<name>.pl` at
  the plugin files under `../plugins/`).
- Duplicating the manager CSS to a web-accessible path.
- Seeding `auth/users`, `auth/groups`, `nav.conf`, and
  `lazysite.conf` from their `.example` copies on fresh
  install.
- SGID on `{docroot}/lazysite/` so files created there
  inherit the group.

These stay as named subs inside `install.pl` rather than
growing the manifest schema. The manager CSS duplicate and
the `cgi-bin` symlinks are deliberately NOT tracked in
`.install-state.json` - they are derived from manifest-tracked
sources and rebuilt on every run, so tracking them would
cause a false "in stored but not in manifest" match on the
next upgrade.

### Restore

`install.pl --restore` takes the system back to a backed-up
state. Without `--backup PATH`, it picks the most recent
backup. Restore:

- Extracts the backup to a temp dir.
- Reads the backup's `.install-state.json`.
- For each file listed there, copies the backup content to
  the real destination, replacing whatever is there.
- Writes the backup's state file as the current state.
- Clears `{docroot}/lazysite/cache/` (rendered HTML may
  reference state that no longer matches).
- Leaves runtime state (auth users, logs, edit locks) alone.

No cascading-backup on restore: if you're restoring, you've
already decided.

### --dry-run

Prints the plan without touching the filesystem. Useful
before an upgrade to see which files will be preserved,
overwritten, or removed.
