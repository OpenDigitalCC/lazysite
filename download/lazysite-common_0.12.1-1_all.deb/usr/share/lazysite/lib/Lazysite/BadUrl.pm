package Lazysite::BadUrl;

# Bad-URL auto-blocker (SM128). Recognises the steady stream of
# vulnerability-scanner probes, counts them per source IP in a rolling window,
# and blocks an IP after a threshold. Enforcement lives in the auth wrapper
# (lazysite-auth.pl), which is in the request path for auth-wrapped sites; the
# block-check is deliberately cheap (a bare -f when nothing is blocked) so the
# common case adds almost nothing.
#
# Two small JSON stores under lazysite/cache/:
#   bad-url-blocked.json : { ip => { since, count, path } }  (created on 1st block)
#   bad-url-hits.json    : { ip => [ epoch, ... ] }          (rolling-window counters)

use strict;
use warnings;
use JSON::PP ();
use Fcntl    qw(:flock);
use Exporter 'import';
our @EXPORT_OK = qw(is_bad_url is_blocked record_and_check list_blocks block unblock);

# Built-in probe patterns. A lazysite site serves no PHP, so any .php is a probe.
# Mirrors the stats plugin's noise set (kept in sync by t/unit/lib/12-bad-url.t).
my $BAD_RE = qr{
    (?: ^ | / )
    (?: wp-login\.php | wp-admin | wp-includes | wp-content | xmlrpc\.php
      | phpmyadmin | \bpma\b | \.env | \.git | \.aws | \.ssh
      | vendor/ | boaform | eval-stdin | HNAP1 | setup\.cgi
      | owa/ | autodiscover | actuator | console/ )
  | \.php (?: $ | [?/] )
}xi;

my $BLOCK_CAP = 10_000;    # keep the blocked store bounded (drop oldest over this)
my $HIT_CAP   = 20_000;    # keep the hit store bounded (drop oldest IPs over this)

sub _blocked_path { return "$_[0]/lazysite/cache/bad-url-blocked.json" }
sub _hits_path    { return "$_[0]/lazysite/cache/bad-url-hits.json" }

# Does this request path look like a scanner probe? $extra is an optional arrayref
# of sysop-added substrings.
sub is_bad_url {
    my ( $path, $extra ) = @_;
    return 0 unless defined $path && length $path;
    return 1 if $path =~ $BAD_RE;
    if ( ref $extra eq 'ARRAY' ) {
        for my $p ( @{$extra} ) {
            next unless defined $p && length $p;
            return 1 if index( $path, $p ) >= 0;
        }
    }
    return 0;
}

# Cheap: no blocked store on disk means nothing is blocked.
sub is_blocked {
    my ( $docroot, $ip ) = @_;
    return 0 unless defined $ip && length $ip;
    my $f = _blocked_path($docroot);
    return 0 unless -f $f;
    my $b = _read_json($f);
    return ( ref $b eq 'HASH' && $b->{$ip} ) ? 1 : 0;
}

# Record one bad-URL hit for $ip and decide whether it is now blocked. Returns 1
# if the IP is blocked (freshly or already), 0 otherwise. Window/threshold come
# from %opt (defaults: 10 hits in 3600s). Atomic under flock.
sub record_and_check {
    my ( $docroot, $ip, $path, %opt ) = @_;
    return 0 unless defined $ip && length $ip;
    my $threshold = $opt{threshold} || 10;
    my $window    = $opt{window}    || 3600;
    my $now       = $opt{now}       || time();

    my $cache = "$docroot/lazysite/cache";
    return 0 unless -d $cache || mkdir $cache;

    # --- rolling-window hit counter (locked, atomic read-modify-write) ---
    my $count = 0;
    _locked_rmw( $docroot, _hits_path($docroot), sub {
            my ($hits) = @_;
            my @recent = grep { $_ > $now - $window } @{ $hits->{$ip} || [] };
            push @recent, $now;
            $hits->{$ip} = \@recent;
            $count = scalar @recent;

            # Bound the store: drop IPs whose most-recent hit is oldest.
            if ( keys %{$hits} > $HIT_CAP ) {
                my @by_age = sort { ( $hits->{$b}[-1] || 0 ) <=> ( $hits->{$a}[-1] || 0 ) } keys %{$hits};
                delete $hits->{$_} for @by_age[ $HIT_CAP .. $#by_age ];
            }
            return $hits;
    } );

    return 0 if $count < $threshold;

    # --- threshold reached: block the IP ---
    _update_blocked( $docroot, sub {
            my ($blk) = @_;
            $blk->{$ip} ||= { since => $now, count => $count, path => substr( $path // '', 0, 200 ) };
            $blk->{$ip}{count} = $count;
            if ( keys %{$blk} > $BLOCK_CAP ) {
                my @old = sort { ( $blk->{$a}{since} || 0 ) <=> ( $blk->{$b}{since} || 0 ) } keys %{$blk};
                delete $blk->{$_} for @old[ $BLOCK_CAP .. $#old ];
            }
            return $blk;
    } );
    return 1;
}

sub list_blocks {
    my ($docroot) = @_;
    my $b = _read_json( _blocked_path($docroot) );
    return {} unless ref $b eq 'HASH';
    return $b;
}

# SM704: block an address the operator names, rather than only one the
# threshold caught. An operator watching a probe in the access log should not
# have to wait for it to trip a counter.
#
# The shape matches what record_and_check writes, so the listing, the guard and
# unblock all treat a manual entry exactly like an automatic one - a manual
# block that needed its own handling everywhere would be a second kind of block.
# `by` records who, because "why is this address blocked" is the question asked
# later, and an automatic entry answers it with the path that tripped it.
sub block {
    my ( $docroot, $ip, %opt ) = @_;
    return 0 unless defined $ip && length $ip;
    return 0 if $ip =~ /[^0-9a-fA-F:.]/;    # an address, not a pattern
    my $added = 0;
    _update_blocked( $docroot, sub {
            my ($blk) = @_;
            return $blk if $blk->{$ip};     # already blocked; not an error
            $blk->{$ip} = {
                since => time,
                count => 0,
                path  => '(added by hand)',
                by    => ( defined $opt{by} ? $opt{by} : '' ),
            };
            $added = 1;
            return $blk;
    } );
    return $added;
}

sub unblock {
    my ( $docroot, $ip ) = @_;
    return 0 unless defined $ip && length $ip;
    my $removed = 0;
    _update_blocked( $docroot, sub {
            my ($blk) = @_;
            $removed = delete $blk->{$ip} ? 1 : 0;
            return $blk;
    } );
    return $removed;
}

# --- helpers ---------------------------------------------------------------

sub _read_json {
    my ($path) = @_;
    open my $fh, '<', $path or return undef;
    my $raw = do { local $/; <$fh> };
    close $fh;
    return ( defined $raw && length $raw ) ? eval { JSON::PP::decode_json($raw) } : undef;
}

# Locked read-modify-write of the blocked store via a callback.
sub _update_blocked {
    my ( $docroot, $mutate ) = @_;
    return _locked_rmw( $docroot, _blocked_path($docroot), $mutate );
}

# Serialised, atomic read-modify-write of a cache JSON store. The exclusive lock
# lives on a stable sidecar lockfile (NOT the data file) so it still serialises
# writers across the temp+rename - flock on the data file itself would not,
# because rename swaps the inode out from under the lock. temp+rename means a
# lock-free reader (_read_json) never catches a half-written store, and a crash
# mid-write leaves the previous store intact rather than truncated. $mutate gets
# the decoded hashref (or {}) and returns the hashref to persist.
sub _locked_rmw {
    my ( $docroot, $data, $mutate ) = @_;
    my $cache = "$docroot/lazysite/cache";
    return unless -d $cache || mkdir $cache;
    open my $lk, '>', "$cache/.bad-url.lock" or return;
    flock $lk, LOCK_EX or do { close $lk; return };

    my $cur = _read_json($data);
    $cur = {} unless ref $cur eq 'HASH';
    my $new = $mutate->($cur);

    my $tmp = "$data.tmp.$$";
    if ( open my $fh, '>', $tmp ) {
        print {$fh} JSON::PP::encode_json($new);
        if ( close $fh ) { rename $tmp, $data or unlink $tmp }
        else { unlink $tmp }
    }
    close $lk;    # release after the rename, so the RMW is fully serialised
    return $new;
}

1;
