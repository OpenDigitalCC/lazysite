package Lazysite::Data::Descriptor;

# SM447: field descriptors - load, validate, REJECT.
#
# The data layer's central claim is that an agent can persist and recall data
# without seeing SQL, and that typing is strict BECAUSE agents do the work.
# Everything downstream - the generated DDL, the bound-parameter DML, the
# migration diff, the form generation - reads its identifiers and its types
# from here. So this file is the boundary, and it has two jobs that must not
# be confused:
#
#   1. TYPING. A mistyped datum is corruption, not a cosmetic fault. This
#      deliberately inverts the theme layer's warn-only philosophy: a missing
#      theme token falls back gracefully; a wrong type does not.
#
#   2. IDENTIFIER SAFETY. Values reach SQL only as bound parameters, but
#      identifiers - table and column names - CANNOT be bound. They are
#      interpolated into generated statements. So the only thing standing
#      between a descriptor and an injected identifier is this validation,
#      and it runs at LOAD, once, rather than at query time, repeatedly.
#      Rejecting here means nothing downstream has to remember to escape.
#
# Errors follow the connector convention so an agent can act on them without
# parsing prose: { ok => 0, kind => 'descriptor'|'validation', error, field,
# rule }. `descriptor` faults are in the FILE; `validation` faults are in a
# VALUE offered against a loaded descriptor.
#
# YAML (pure Perl) rather than YAML::XS: the SBOM posture prefers a declared
# dependency without a compiled one, and descriptors are read once and cached,
# so parse speed decides nothing here.

use strict;
use warnings;
use Exporter qw(import);

our @EXPORT_OK = qw(load_descriptor TYPES);

# The v1 type set, kept deliberately tight - extended later only with cause.
# A type is present here or it is rejected; there is no permissive default,
# because a default is how an unknown type becomes a silent text column.
my %TYPE = map { $_ => 1 } qw(text integer decimal boolean date datetime enum);

# The list, not `return sort ...` - perlcritic severity 5, and it is right:
# `return sort` behaves differently in scalar context, so a caller writing
# `my $n = TYPES()` gets something undefined rather than a count.
sub TYPES {
    my @types = sort keys %TYPE;
    return @types;
}

# Identifiers: [a-z][a-z0-9_]* and nothing else.
#
# Not a style rule. These are interpolated into generated SQL because SQL
# cannot bind an identifier, so this pattern is the whole defence. It is
# deliberately narrower than any engine would accept - no quotes, no dots, no
# spaces, no capitals, no leading digit - so that a name which passes here
# needs no quoting or escaping in any dialect we generate for.
my $IDENT = qr/\A[a-z][a-z0-9_]*\z/;

# Reserved because the plugin owns them: `timestamps: true` creates them, and
# a descriptor declaring its own would collide with the ones we maintain.
my %RESERVED = map { $_ => 1 } qw(created_at updated_at);


sub _err {
    my ( $kind, $error, %extra ) = @_;
    return { ok => 0, kind => $kind, error => $error, %extra };
}

sub _bad_ident {
    my ($name) = @_;
    return 'a name is required' unless defined $name && length $name;
    return "'$name' must be lower-case letters, digits and underscores, "
        . 'starting with a letter'
        unless $name =~ $IDENT;
    return undef;
}

# SM519: NO MEANS NO. YAML::PP implements YAML 1.2, where `no`, `No`, `off`,
# `yes` and `on` are plain STRINGS - only `true`/`false` are booleans - and a
# flag tested with Perl truth reads `public: no` as public. That exposed rows
# to anonymous visitors, refused writes under `required: no`, and built an
# index under `unique: off`. So every boolean the descriptor reads comes
# through here, and the answer is 1, 0, or a refusal - never a guess.
#
# yes/no/on/off are honoured rather than refused: they are the natural
# spelling of the thing, and refusing them would be the surprising
# alternative. Case does not matter. A JSON::PP boolean (a descriptor that
# arrived through the API rather than a YAML file) is a boolean. Absent is
# false, because every flag here defaults closed. Anything else is refused
# with the message this file already promised.
#
# Returns ( value, undef ) or ( undef, 'must be true or false' ).
my %TRUE = map { $_ => 1 } qw(1 true yes on);

# SM586: the EMPTY STRING is false, because that is what YAML::PP hands back
# for a bare `false` - a defined, zero-length scalar. SM519 tested definedness
# and then membership, so the one spelling meaning "not public" matched
# neither set and was refused while `'false'`, `0` and `true` all passed. The
# key that says a table is private is the key that must never be fussy.
my %FALSE = map { $_ => 1 } ( qw(0 false no off), '' );

sub _bool {
    my ($v) = @_;
    return ( 0, undef ) unless defined $v;
    if ( ref $v ) {
        return ( ( $v ? 1 : 0 ), undef ) if ref $v eq 'JSON::PP::Boolean';
        return ( undef,          'must be true or false' );
    }
    my $word = lc $v;
    $word =~ s/\A\s+|\s+\z//g;
    return ( 1,     undef ) if $TRUE{$word};
    return ( 0,     undef ) if $FALSE{$word};
    return ( undef, 'must be true or false' );
}

# --- field-level descriptor checks -----------------------------------------
#
# Each returns an error string, or undef. Split per type so a new type adds
# one branch rather than editing a conditional nobody can read.
sub _check_field {
    my ( $name, $spec ) = @_;

    return "field '$name': must be a mapping of properties"
        unless ref $spec eq 'HASH';

    my $type = $spec->{type};
    return "field '$name': no type given (one of: " . join( ', ', TYPES() ) . ')'
        unless defined $type && length $type;
    return "field '$name': unknown type '$type' (one of: "
        . join( ', ', TYPES() ) . ')'
        unless $TYPE{$type};

    # F-5: `unique: true` - a field the site guarantees no two rows share,
    # without making it the key. The field agent could not say "slug is
    # unique" while keying on something else, and worked around it by keying
    # on the slug, which changes what a row IS in order to express a
    # constraint about one of its values.
    #
    # Both flags are written back normalised: Schema, Value and SQLite read
    # `$spec->{required}` directly, and they must see the same answer this
    # file gave.
    for my $k (qw(unique required)) {
        next unless exists $spec->{$k};
        my ( $val, $why ) = _bool( $spec->{$k} );
        return "field '$name': $k $why" if $why;
        $spec->{$k} = $val;
    }

    # F-4: WIDGET IS ONLY MEANINGFUL ON TEXT, and until now saying otherwise
    # was silently accepted - the existing check lives inside the `text` branch
    # below, so `widget: textarea` on an integer passed straight through and
    # became an editor hint nothing could honour.
    #
    # The vocabulary is NOT restated here. A second list of allowed widgets
    # would be a second answer to "which widgets exist", and the two would
    # disagree the first time one of them gained a value.
    return "field '$name': widget is only meaningful on a text field, and "
        . "'$name' is $type"
        if defined $spec->{widget} && $type ne 'text';

    if ( $type eq 'enum' ) {
        my $v = $spec->{values};
        return "field '$name': enum needs a values list"
            unless ref $v eq 'ARRAY' && @{$v};
        for my $val ( @{$v} ) {
            return "field '$name': enum values must be simple scalars"
                if ref $val;
            return "field '$name': enum values cannot be empty"
                unless defined $val && length $val;
        }
        my %seen;
        for my $val ( @{$v} ) {
            return "field '$name': duplicate enum value '$val'" if $seen{$val}++;
        }
        if ( defined $spec->{default} ) {
            return "field '$name': default '$spec->{default}' is not one of "
                . 'its enum values'
                unless grep { $_ eq $spec->{default} } @{$v};
        }
    }
    elsif ( $type eq 'decimal' ) {
        # Declared precision, because money must never be a float. Both parts
        # are required: a decimal without them is a float wearing a name.
        for my $k (qw(digits places)) {
            return "field '$name': decimal needs '$k'"
                unless defined $spec->{$k};
            return "field '$name': '$k' must be a non-negative whole number"
                unless $spec->{$k} =~ /\A\d+\z/;
        }
        return "field '$name': places ($spec->{places}) cannot exceed "
            . "digits ($spec->{digits})"
            if $spec->{places} > $spec->{digits};
    }
    elsif ( $type eq 'text' ) {
        if ( defined $spec->{max} ) {
            return "field '$name': max must be a positive whole number"
                unless $spec->{max} =~ /\A\d+\z/ && $spec->{max} > 0;
        }
        if ( defined $spec->{widget} ) {
            return "field '$name': widget must be 'input' or 'textarea'"
                unless $spec->{widget} =~ /\A(?:input|textarea)\z/;
        }
    }
    elsif ( $type eq 'integer' ) {
        for my $k (qw(min max)) {
            next unless defined $spec->{$k};
            return "field '$name': $k must be a whole number"
                unless $spec->{$k} =~ /\A-?\d+\z/;
        }
        return "field '$name': min cannot exceed max"
            if defined $spec->{min}
            && defined $spec->{max}
            && $spec->{min} > $spec->{max};
    }

    # `values` on a non-enum is almost certainly a mistake rather than
    # harmless surplus - it reads as a constraint and enforces nothing.
    return "field '$name': 'values' only applies to enum"
        if $type ne 'enum' && defined $spec->{values};

    return undef;
}

# --- whole-descriptor checks ------------------------------------------------
#
# DA-17: load_descriptor was one 135-line ladder of four unrelated checks, and
# a reader had to hold all of them to follow any one. Each is its own sub now.
#
# WHY THESE RETURN A FORMED ERROR rather than a message the way _check_field
# does: a field-level refusal always carries `rule => 'type'`, so its caller
# can add that one key for all of them. These four carry `field` and `rule`
# keys that DIFFER per branch - 'key', 'index', 'order', 'writable_by', and
# `field` present or absent - and those keys are read by the surfaces that
# report the refusal. A bare message would lose them.
#
# Each returns ( <the value it validated>, undef ) or ( undef, $err ).

# The key: 'id' means an auto integer the plugin owns and no field may
# shadow. Anything else must name a declared field.
sub _check_key {
    my ( $name, $raw, $fields ) = @_;
    my $key = defined $raw->{key} ? $raw->{key} : 'id';
    if ( my $why = _bad_ident($key) ) {
        return ( undef,
            _err( 'descriptor', "table '$name': key: $why", rule => 'key' ) );
    }
    if ( $key eq 'id' ) {
        return ( undef,
            _err( 'descriptor',
                "table '$name': 'id' is the automatic key and cannot also be a field",
                field => 'id', rule => 'key' ) )
            if $fields->{id};
    }
    else {
        return ( undef,
            _err( 'descriptor',
                "table '$name': key '$key' is not one of its fields",
                field => $key, rule => 'key' ) )
            unless $fields->{$key};

        # A natural key carries required+unique by implication, and saying so
        # here means the DDL generator does not have to infer it.
        return ( undef,
            _err( 'descriptor', "table '$name': key '$key' must be type text",
                field => $key, rule => 'key' ) )
            unless ( $fields->{$key}{type} // '' ) eq 'text';
    }
    return ( $key, undef );
}

# Indexes name declared fields, in order.
sub _check_indexes {
    my ( $name, $raw, $fields, $key ) = @_;
    my $indexes = $raw->{indexes} // [];
    return ( undef,
        _err( 'descriptor', "table '$name': indexes must be a list" ) )
        unless ref $indexes eq 'ARRAY';
    for my $ix ( @{$indexes} ) {
        return ( undef,
            _err( 'descriptor',
                "table '$name': each index must be a list of field names",
                rule => 'index' ) )
            unless ref $ix eq 'ARRAY' && @{$ix};
        for my $f ( @{$ix} ) {
            next if $fields->{$f};
            next if $key ne 'id' && $f eq $key;
            return ( undef,
                _err( 'descriptor',
                    "table '$name': index names '$f', which is not a field",
                    field => $f, rule => 'index' ) );
        }
    }
    return ( $indexes, undef );
}

# F-1: THE ORDER THE SITE MEANS. A gallery is an ordered list - somebody
# chose the sequence - and without this a bare `db:gallery` returns rows in
# whatever order the store hands back, which is insertion order until it is
# not. Saying it once in the descriptor beats repeating `order=` in every
# binding and getting it wrong in one of them.
#
# `-field` is descending, the same spelling the query grammar uses.
#
# Returns ( $field, $dir, undef ) - $field undef when none was declared.
sub _check_default_order {
    my ( $name, $raw, $fields, $key, $timestamps ) = @_;
    my $dord = $raw->{default_order};
    my ( $do_field, $do_dir ) = ( undef, 'asc' );
    return ( $do_field, $do_dir, undef ) unless defined $dord && length $dord;

    return ( undef, undef,
        _err( 'descriptor', "table '$name': default_order must be a "
                . 'field name, optionally prefixed with -', rule => 'order' ) )
        if ref $dord;
    ( $do_field = $dord ) =~ s/\A-// and $do_dir = 'desc';
    return ( undef, undef,
        _err( 'descriptor',
            "table '$name': default_order names '$do_field', which is not one "
                . 'of its fields',
            field => $do_field, rule => 'order' ) )
        unless $fields->{$do_field}
        || $do_field eq $key
        || ( $timestamps && $do_field =~ /\A(?:created_at|updated_at)\z/ );
    return ( $do_field, $do_dir, undef );
}

# SM677: is row auditing switched OFF for this table?
#
# Only an explicit off counts. A typo, a missing key, a `true`, a number - all
# leave the table AUDITED, because the failure this must not have is a
# descriptor that silently stops recording who changed what. Defaulting the
# other way would make a misspelling into a quiet loss of the audit trail.
sub _audit_rows_off {
    my ($raw) = @_;
    my $v = $raw->{audit_rows};
    return 0 unless defined $v;
    return ( lc "$v" eq 'off' || lc "$v" eq 'false' || "$v" eq '0' ) ? 1 : 0;
}

sub _check_writable_by {
    my ( $name, $raw ) = @_;
    my $wb = $raw->{writable_by} // [];
    return ( undef,
        _err( 'descriptor', "table '$name': writable_by must be a list" ) )
        unless ref $wb eq 'ARRAY';
    for my $g ( @{$wb} ) {
        return ( undef,
            _err( 'descriptor',
                "table '$name': writable_by group names must be plain names",
                rule => 'writable_by' ) )
            unless defined $g && !ref $g && $g =~ /\A[A-Za-z0-9_-]+\z/;
    }
    return ( $wb, undef );
}

# --- whole-descriptor load --------------------------------------------------
#
# The orchestrator. The ORDER the checks run in is part of the contract - a
# descriptor with two faults is told about the first one, and which one that
# is has to stay the same - so it is: fields, key, indexes, public,
# timestamps, default_order, writable_by.

sub load_descriptor {
    my ( $name, $raw ) = @_;

    if ( my $why = _bad_ident($name) ) {
        return _err( 'descriptor', "table name: $why", field => $name );
    }
    return _err( 'descriptor', "table '$name': descriptor must be a mapping" )
        unless ref $raw eq 'HASH';

    my $fields = $raw->{fields};
    return _err( 'descriptor', "table '$name': no fields declared" )
        unless ref $fields eq 'HASH' && %{$fields};

    for my $f ( sort keys %{$fields} ) {
        if ( my $why = _bad_ident($f) ) {
            return _err( 'descriptor', "table '$name': field name: $why",
                field => $f, rule => 'identifier' );
        }
        return _err( 'descriptor',
            "table '$name': '$f' is maintained by the plugin "
                . '(set timestamps: true to have it)',
            field => $f, rule => 'reserved' )
            if $RESERVED{$f};

        if ( my $why = _check_field( $f, $fields->{$f} ) ) {
            return _err( 'descriptor', "table '$name': $why",
                field => $f, rule => 'type' );
        }
    }

    my ( $key, $key_err ) = _check_key( $name, $raw, $fields );
    return $key_err if $key_err;

    my ( $indexes, $index_err ) = _check_indexes( $name, $raw, $fields, $key );
    return $index_err if $index_err;

    # SM476: `public` is the publication flag, and it DEFAULTS TO FALSE.
    #
    # Chosen while there was still no installed base to break - the plugin has
    # only ever shipped to edge, is born disabled, and the only tables in
    # existence were three test tables. A closed default costs nothing today
    # and cannot be chosen at all once this reaches stable.
    my ( $public, $public_why ) = _bool( $raw->{public} );
    return _err( 'descriptor', "table '$name': public $public_why",
        rule => 'public' )
        if $public_why;

    my ( $timestamps, $ts_why ) = _bool( $raw->{timestamps} );
    return _err( 'descriptor', "table '$name': timestamps $ts_why",
        rule => 'timestamps' )
        if $ts_why;

    my ( $do_field, $do_dir, $order_err )
        = _check_default_order( $name, $raw, $fields, $key, $timestamps );
    return $order_err if $order_err;

    my ( $wb, $wb_err ) = _check_writable_by( $name, $raw );
    return $wb_err if $wb_err;

    # SM593: which DOMAIN declared this table, on an instance carrying several.
    #
    # Optional, and its absence is not a default that means "everyone" - it
    # means the table predates the key, and the manager surface treats it
    # exactly as it did before. Validated as a hostname rather than passed
    # through, because it is compared against a configured domain's host and a
    # value that could never match would confine the table to nobody while
    # looking like it confined it to somebody.
    my $domain = $raw->{domain};
    $domain = '' unless defined $domain && !ref $domain;
    $domain =~ s/\A\s+|\s+\z//g;
    if ( length $domain && $domain !~ /\A[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?\z/ ) {
        return _err( "table '$name': domain '$domain' is not a hostname",
            kind => 'invalid', rule => 'domain' );
    }

    return {
        ok          => 1,
        table       => $name,
        title       => $raw->{title} // $name,
        key         => $key,
        auto_key    => ( $key eq 'id' ? 1 : 0 ),
        fields      => $fields,
        indexes     => $indexes,
        writable_by => $wb,
        # SM677: whether a ROW WRITE on this table writes an audit line.
        #
        # SM505 and SM465 each decided deliberately that a row action's audit
        # entry carries the row KEY - "someone edited that table" is half an
        # answer when the question the trail gets asked is which row. That
        # stands, and remains the DEFAULT: absent, undef, or anything other
        # than an explicit off leaves the table audited.
        #
        # The switch exists because a table with thousands of rows produces
        # thousands of lines, and the operator who has that table is the one
        # who knows it. `audit_rows: off` is theirs to set, per table, where the
        # volume is visible - rather than the engine guessing globally.
        audit_rows => ( _audit_rows_off($raw) ? 0 : 1 ),
        public      => $public,
        ( defined $do_field
            ? ( default_order => $do_field, default_order_dir => $do_dir )
            : () ),
        unique     => [ sort grep { $fields->{$_}{unique} } keys %{$fields} ],
        timestamps => $timestamps,
        ( length $domain ? ( domain => $domain ) : () ),
    };
}

1;
