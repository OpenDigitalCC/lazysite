package Lazysite::Auth::Acl;

# SM074 per-file ACL store (lazysite/auth/acls.json) and the ownership/allow
# checks, shared (SM079). Context is $DOCROOT, set by the script. The
# operator-bypass decision (_is_operator) is request-context-bound and stays in
# the manager, which combines it with _acl_allows here.

use strict;
use warnings;
use JSON::PP       ();
use File::Path     qw(make_path);
use File::Basename qw(dirname);
use Lazysite::Util ();    # SM289: secure_write_perms - root must not own this store
use Exporter 'import';
use Lazysite::Paths ();

# DA-19: loaded once at the top rather than `require`d in four subs.
# Settings depends only on Lazysite::Util, so there is no cycle back here.
use Lazysite::Auth::Settings ();

our @EXPORT_OK = qw(load_acls save_acls _acl_norm _to_list _acl_allows _acls_path
    _is_operator _acl_denied groups_for_user may_read_any_rule);

our $DOCROOT;    # set by the script

# SM293: this site's engine tree - beside the docroot once migrated,
# inside it before. Asked, never computed, so both layouts work on one
# code path and a site migrates by moving the directory.
sub _lz { return Lazysite::Paths::lazysite_dir($DOCROOT) }

# Manager auth-state, set per request by the dispatcher (the sysop-bypass
# decision). A token client is never a sysop; otherwise group-granted
# capabilities decide (SM138: the conf manager_groups fallback is retired).
our $auth_user  = '';
our $token_auth = 0;

# SM077: the requesting user's groups (for @group ACL entries), set per request
# by the dispatcher.
#
# WHAT EACH CHANNEL SETS - they do not agree, and this comment used to claim
# they did ("a token/WebDAV partner carries none"), which is false for WebDAV
# and was copied into the architecture doc and believed for a year:
#
#   lazysite-dav.pl         user_groups_for($user) - the account's REAL groups,
#                           so an @group entry DOES match a WebDAV partner
#   lazysite-mcp.pl         () - hard-zeroed, so an @group never matches
#   lazysite-manager-api.pl HTTP_X_REMOTE_GROUPS - the session's groups for a
#                           cookie client, empty for a token client
#
# SM288 made them agree. Every channel now assigns this from groups_for_user()
# below, except the manager's COOKIE path, which uses the session's groups from
# X-Remote-Groups as set by the auth wrapper. t/lint/35 pins that, because the
# previous state - dav resolving real groups, mcp hard-zeroing them, the token
# path reading a header a token cannot carry - was invisible until an operator
# said so.
our @user_groups;

# THE per-account group resolver for the ACL decision, on every channel.
#
# Before SM288 there were three answers: lazysite-dav.pl read the group file
# itself, lazysite-mcp.pl set the empty list with a comment calling it "the safe
# default", and lazysite-manager-api.pl took X-Remote-Groups - which a token
# client structurally cannot send. So the same account, in the same group,
# reading the same file under the same ACL, was ALLOWED over WebDAV and REFUSED
# over MCP. A group is a property of the account, not of the door it arrived
# through.
#
# Delegates to Settings::effective_groups, which is what the capability and
# domain-access resolvers already use, so "which groups is this user in" has one
# implementation for every question lazysite asks. AUTH_DIR is localised from
# this module's own request context - the same trick _groups_grant_cap uses
# below - so a caller that only sets Acl::DOCROOT needs to know nothing else.
sub groups_for_user {
    my ($user) = @_;
    return () unless defined $user    && length $user;
    return () unless defined $DOCROOT && length $DOCROOT;
    local $Lazysite::Auth::Settings::AUTH_DIR = _settings_dir();
    return Lazysite::Auth::Settings::effective_groups($user);
}

sub _acls_path { _lz() . "/auth/acls.json" }

# The directory Settings reads its stores from, for this module's request
# context. Four subs localise $Lazysite::Auth::Settings::AUTH_DIR to it so a
# caller that sets only Acl::DOCROOT needs to know nothing else; `local`
# belongs to the caller's scope, so this supplies the value, not the binding.
sub _settings_dir { return _lz() . "/auth" }

# A caller's own copy of the map. load_acls has ALWAYS handed back a fresh
# structure - it decoded the file on every call - and several callers rely on
# that: acl_drop_tree and acl_move_tree here, and the manager's acl actions,
# mutate what they were given before saving it. The memo below would otherwise
# hand every caller the same reference, and a mutation whose save FAILED would
# leave the process answering from a map that never reached the file.
sub _acls_copy {
    my ($m) = @_;
    my %out;
    for my $k ( keys %{$m} ) {
        my $e = $m->{$k};
        if ( ref $e eq 'HASH' ) {
            $out{$k} = {
                map {
                    $_ => (
                        ref $e->{$_} eq 'ARRAY' ? [ @{ $e->{$_} } ] : $e->{$_} )
                } keys %{$e}
            };
        }
        else {
            $out{$k} = $e;
        }
    }
    return \%out;
}

# MEMOISED ON (path, mtime, size), with the one-second guard (DAO-4). This file
# is read once per binding per visitor - Access::may_read reaches _acl_allows,
# which reaches here - and the JSON decode is pure Perl.
#
# HOW STALENESS IS PREVENTED:
#
#   1. save_acls replaces the file by rename, so mtime (and almost always
#      size) changes, and the key with it. A rule saved by another process is
#      seen by this one on the next read.
#   2. THE ONE-SECOND GUARD covers a same-second rewrite of the same length -
#      swapping one three-letter username for another does exactly that - which
#      would otherwise carry an identical key. mtime is one-second granular, so
#      a file younger than a second is read fresh every time.
#   3. save_acls clears this process's memo, because the (mtime,size) key
#      cannot see OUR OWN write within the granularity of the clock, and the
#      write and the next authorisation can be milliseconds apart. Same
#      reasoning as SM334's _settings_cache_clear.
#   4. Every caller gets its own copy, so a caller that mutates the map -
#      several do - cannot change what the next caller reads.
#
# This is an access-control store, so none of these four is decorative.
{
    my %_acls_cache;

    sub _acls_cache_clear { %_acls_cache = (); return }

    sub load_acls {
        my $path = _acls_path();
        return {} unless -f $path;

        my @st  = stat $path;
        my $key = @st ? "$path:$st[9]:$st[7]" : '';
        return _acls_copy( $_acls_cache{$key} )
            if length $key && exists $_acls_cache{$key};

        open my $fh, '<', $path or return {};
        my $raw = do { local $/; <$fh> };
        close $fh;
        my $m = eval { JSON::PP::decode_json( $raw // '{}' ) };
        return {} unless ref $m eq 'HASH';

        if ( length $key && @st && $st[9] < time() - 1 ) {
            %_acls_cache = () if keys %_acls_cache > 8;
            $_acls_cache{$key} = $m;
            return _acls_copy($m);
        }
        return $m;
    }
}

sub save_acls {
    my ($map) = @_;
    my $path  = _acls_path();
    my $dir   = dirname($path);
    make_path($dir) unless -d $dir;
    my $tmp = "$path.tmp.$$";
    open my $fh, '>', $tmp or return 0;
    print {$fh} JSON::PP->new->canonical->pretty->encode($map);
    close $fh;

    # SM215/SM289: never leave a root-owned acls.json behind.
    #
    # Every writer of this store used to be a CGI running as the site user, so a
    # bare chmod was enough. SM289 added a CLI verb, and root is a plausible
    # caller of a CLI - at which point a plain write leaves a file the CGI can no
    # longer update, and the manager silently loses the ability to change
    # permissions. That is the Class-B ownership drift SM215 fixed everywhere
    # else; this store was missed because nothing could reach it as root.
    #
    # secure_write_perms makes the file match its directory's owner and group,
    # which is the provisioned site user in every install shape.
    #
    # SM428: 0660, NOT 0640 - GROUP-WRITABLE.
    #
    # This store is written by TWO identities on a group-shared docroot: the
    # site user (CLI verbs, `acl reapply`) and the www-data CGI (the manager's
    # permissions UI). 0640 leaves it readable but not writable by the other
    # one, so whichever identity wrote it last takes the file away from the
    # other - and `lazysite check` says so in terms: "acls.json ... is not
    # writable by the CGI (www-data) - the manager cannot save it".
    #
    # It was reaching the field on EVERY DEPLOY. The upgrade's `acl reapply`
    # step rewrote the store as the site user, dropping it to 0640, and the
    # health pass that follows repaired it back to 0660 - so the defect was
    # invisible in the log except as a repair that ran every single time. A
    # repair that always runs is not a repair; it is a writer disagreeing with
    # its own checker, once per deploy, with a window in between where the
    # manager silently cannot save a permission change.
    #
    # 0660 matches the other auth files the same check requires group-write on
    # (users, groups) and matches the 2770 setgid directory they live in.
    # Nothing world-readable either way.
    Lazysite::Util::secure_write_perms( $tmp, oct '660' );
    my $ok = rename $tmp, $path;

    # DAO-4: this process must not answer from a memo it has just
    # superseded. The (mtime,size) key handles another process's write; this
    # handles our own, which is the case where a permission change and the
    # next authorisation are milliseconds apart.
    _acls_cache_clear();
    return $ok;
}

# --- CF-2: the ACL lifecycle, in one place -----------------------------------
#
# Deleting content must drop its rules; moving content must carry them. Both
# were true on ONE surface each and false on the other, in opposite directions:
# DAV's DELETE dropped entries and the manager's did not; the manager's move
# re-keyed and DAV's did not. The comment at lazysite-dav.pl claiming "the
# manager's delete has always done this" was simply wrong, so SM212's fix never
# reached the manager, MCP or the control API.
#
# The move half is the one with a confidentiality consequence. WebDAV resolves
# a gated path into the PRIVATE store, so a MOVE to an ungated destination
# physically relocates the bytes into the public docroot - and with no re-key,
# no rule follows them. Protected content becomes public through an ordinary
# operation, with no error and nothing to notice. That is the exact inverse of
# SM286: protecting content moves it, so moving content has to carry its
# protection.
#
# One definition here rather than four copies, because four copies is how the
# two surfaces came to disagree in the first place.

# Drop the entry for $key and every entry beneath it. Returns the number
# removed; saves only if something changed.
sub forget_path {
    my ($key) = @_;
    $key = _acl_norm($key);
    return 0 unless defined $key && length $key;
    my $acls    = load_acls();
    my $removed = 0;
    for my $k ( keys %$acls ) {
        next unless $k eq $key || index( $k, "$key/" ) == 0;
        delete $acls->{$k};
        $removed++;
    }
    return 0 unless $removed;
    save_acls($acls) or return 0;
    return $removed;
}

# Move the entry for $from to $to, with its descendants. Returns the number
# re-keyed.
#
# The STORE SYNC is deliberately the caller's, immediately after: the rule and
# the bytes must both move, but where the bytes go is a private-store decision
# with its own companions (the .brief sidecar, the stale render cache) that
# belongs with the mover rather than with the key. Every caller of this
# function must follow it with a sync against the NEW key - which settles both
# directions at once, into a gated folder and back out of one.
sub rekey_path {
    my ( $from, $to ) = @_;
    $from = _acl_norm($from);
    $to   = _acl_norm($to);
    return 0 unless defined $from && length $from && defined $to && length $to;
    return 0 if $from eq $to;

    my $acls  = load_acls();
    my $moved = 0;
    for my $k ( sort keys %$acls ) {
        my $nk;
        if    ( $k eq $from )                { $nk = $to }
        elsif ( index( $k, "$from/" ) == 0 ) { $nk = $to . substr( $k, length $from ) }
        else                                 { next }
        $acls->{$nk} = delete $acls->{$k};
        $moved++;
    }
    return 0 unless $moved;
    save_acls($acls) or return 0;
    return $moved;
}

# Strip leading slashes so an ACL key matches the manager's relative paths.
sub _acl_norm { my $r = shift; $r =~ s{^/+}{} if defined $r; return $r }

# Normalise a list value (arrayref or comma/space string) to an arrayref,
# or undef if not provided.
sub _to_list {
    my ($v) = @_;
    return undef unless defined $v;
    return [ grep { length } @$v ] if ref $v eq 'ARRAY';
    return [ grep { length } split /[,\s]+/, $v ];
}

# Does the ACL for $rel allow $user $mode access? No entry = allowed (the
# account's scope governs); owner always allowed; else membership of the
# mode's allow-list.
# SM268 H3: which entry governs $rel for $mode - exact, then the section's own
# landing page, then the LONGEST matching folder prefix.
#
# Folder scope was implemented only in the processor's module-free copy, so a
# "protected section" was protected on the anonymous read path and nowhere else:
# Acl::_acl_allows matched the exact key only, and the manager, MCP and WebDAV
# therefore granted full READ AND WRITE inside a section the sysop had gated.
# An adversarial review demonstrated it. One store answering two different
# questions depending on which surface asks is precisely what SM223 chose a
# single store to avoid.
#
# Only entries carrying a non-empty list for the mode participate, so an
# owner-only entry - which action_copy writes for every duplicated file - cannot
# beat an enclosing folder rule. It is not a tighter rule, it is no rule.
sub _acl_entry_for {
    my ( $map, $rel, $mode ) = @_;
    $rel = _acl_norm($rel) // '';

    my $governs = sub {
        my ($e) = @_;
        return 0 unless ref $e eq 'HASH';
        return 1 unless defined $mode && length $mode;
        return ( ref $e->{$mode} eq 'ARRAY' && @{ $e->{$mode} } ) ? 1 : 0;
    };

    return $map->{$rel} if $governs->( $map->{$rel} );

    if ( $rel =~ m{\A(.+)\.(?:md|url|html)\z} ) {
        my $stem = $1;
        return $map->{$stem} if $governs->( $map->{$stem} );
    }

    my $best;
    my $best_len = -1;
    for my $k ( keys %$map ) {
        next unless $governs->( $map->{$k} );
        ( my $p = $k ) =~ s{\A/+}{};
        $p =~ s{/+\z}{};
        next unless length $p;
        next unless index( $rel, "$p/" ) == 0;
        next unless length($p) > $best_len;
        $best     = $map->{$k};
        $best_len = length $p;
    }
    return $best if $best;

    # SM287: the SITE-WIDE rule, and it is the WEAKEST - checked only when
    # nothing more specific governs, so a public carve-out inside a private site
    # stays expressible (which is the common shape: everything private except
    # the landing page).
    #
    # Before this, a root entry did nothing under any spelling. Not by an
    # oversight in one branch: the loop above skips a zero-length prefix, and
    # even without that guard `index($rel, "$p/")` can never match an empty
    # prefix because _acl_norm has already stripped the leading slash from $rel.
    # So there was NO way to say "this whole site is private" - auth_default
    # governs pages and deliberately does not reach statics, and enumerating
    # top-level folders fails OPEN as content grows.
    #
    # '/' is what the writer stores. '' and '.' are accepted too: a hand-edited
    # store is a real interface here and all three plainly mean the same thing.
    # Glob spellings are NOT accepted - the store has no matching language, and
    # audit_site's acl_keys_matching_nothing surfaces a key that governs nothing.
    for my $rk ( '/', '', '.' ) {
        return $map->{$rk} if $governs->( $map->{$rk} );
    }
    return;
}

sub _acl_allows {
    my ( $rel, $mode, $user ) = @_;
    my $a = _acl_entry_for( load_acls(), $rel, $mode );
    return 1 unless $a;
    return 1 if defined $a->{owner} && defined $user && $a->{owner} eq $user;
    my $list = $a->{$mode};
    return 1 unless ref $list eq 'ARRAY' && @$list;
    # SM268 01-L1: case-insensitive, and compound-expanded - the same semantics
    # the processor's copy uses (t/lint/31 pins the pair) and the same ones
    # check_auth applies to `groups:` front matter. Three different answers to
    # "is this user in that group" on one request was the defect.
    my %grp = map { lc($_) => 1 }
        do {
        local $Lazysite::Auth::Settings::AUTH_DIR = _settings_dir();
        Lazysite::Auth::Settings::group_closure(@user_groups);
        };
    for my $entry (@$list) {
        next unless defined $entry && length $entry;
        if ( $entry =~ /\A\@(.+)\z/ ) {    # SM077: @group entry
            return 1 if $grp{ lc $1 };
        }
        elsif ( defined $user && $entry eq $user ) {
            return 1;
        }
    }
    return 0;
}

# Operator bypass (manager-only). A token (control-API) client is NEVER an
# sysop - per-file ACL ownership applies to it like any WebDAV partner. An
# unsecured site (no manager_groups) treats cookie clients as sysops; the
# 'local' user is always sysop; else manager-group membership decides. The
# token path never consults the client-influenceable X-Remote-Groups.
# SM095: does any of these groups carry capability $cap? Routed through the
# shared resolver helper (ADR 0001) - AUTH_DIR localised from this module's
# request context so callers that only set Acl::DOCROOT keep working.
sub _groups_grant_cap {
    my ( $cap, @groups ) = @_;
    return 0 unless @groups;
    local $Lazysite::Auth::Settings::AUTH_DIR = _settings_dir();
    return Lazysite::Auth::Settings::groups_grant_cap( $cap, @groups );
}

sub _is_operator {
    return 0 if $token_auth;
    return 1 if ( $auth_user // '' ) eq 'local';

    local $Lazysite::Auth::Settings::AUTH_DIR = _settings_dir();

    # SM095/SM138: unrestricted account management is the manage_users
    # capability, granted through a group. The legacy lazysite.conf
    # manager_groups fallback is RETIRED - the migration granted those groups
    # their capabilities explicitly.
    #
    # SM268 02-7: ask the STORE FIRST, then the header - not the header alone.
    #
    # The two sources disagree for a session whose group set changed after the
    # header was written, and the header is the stale one. Asking the store
    # first means a grant that exists NOW is honoured now, which is the
    # direction that matters: it is how a revoked grant stops applying and a
    # fresh one starts.
    #
    # The header is NOT dropped, though the review suggested it. It carries
    # group names for identities the local store does not know - a trusted
    # reverse proxy or SSO, where membership lives in the IdP and the account
    # may not exist here at all. t/unit/manager/16 asserts exactly that case
    # (an operator known only as X-Remote-Groups: managers), so removing the
    # header check trades a LOW consistency finding for a broken deployment.
    # It reaches this code only when the wrapper set LAZYSITE_AUTH_TRUSTED, so
    # it is vouched for; the remaining objection was staleness, and consulting
    # the store first is what answers that.
    if ( defined $auth_user && length $auth_user ) {
        my $caps = eval { Lazysite::Auth::Settings::caps_for($auth_user) } || {};
        return 1 if $caps->{manage_users};
    }
    my @ug = grep { length } split /[,\s]+/, ( $ENV{HTTP_X_REMOTE_GROUPS} // '' );
    return 1 if _groups_grant_cap( 'manage_users', @ug );

    # A site where no group grants manager access at all is unsecured/dev: any
    # authenticated user is an operator.
    return 1 unless Lazysite::Auth::Settings::site_grants_manager();
    return 0;
}

# SM464: may this caller READ any rule - the audit half of ownership, split
# from the right to modify.
#
# Ownership stays absolute for WRITES: acl-set on somebody else's rule is
# refused whoever asks, and nothing here touches that. But the person
# accountable for an estate's access control is precisely the person who did
# not set most of its rules, and the measured workarounds - take ownership
# (which CHANGES the rule under inspection) or read the store off disk (which
# bypasses everything and leaves no trace) - are worse than the read they
# route around.
#
# Who reads: an operator or a cookie-session holder of manage_users, which
# _is_operator already answers - and a TOKEN whose OWN GRANT carries
# manage_users. _is_operator refuses every token by design (a token is never
# an operator), and that stays; the token override is deliberately keyed on
# the grant the operator wrote for that partner, not on the account's group
# memberships, so holding it is an explicit per-grant decision and never a
# side effect of a group intended for the cookie UI (SM127).
our %token_caps;    # the token's OWN grant settings; set by the API/MCP entry
sub may_read_any_rule {
    return 1 if _is_operator();
    return 1 if $token_auth && $token_caps{manage_users};
    return 0;
}

# Combine operator bypass + the per-file allow check; returns a refusal hashref
# or undef if access is allowed.
sub _acl_denied {
    my ( $rel, $mode, $user ) = @_;
    return undef if _is_operator();
    return undef if _acl_allows( $rel, $mode, $user );
    return { ok => 0, error => "You do not have $mode access to this file", kind => 'permission' };
}

1;
