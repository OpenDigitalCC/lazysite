package Lazysite::Manager::Upload;

# SM079: manager file upload / download / zip-download handlers, the
# content-type + text-extension tables, and the upload rate limiter. Context
# ($DOCROOT, $LAZYSITE_DIR, $auth_user) is set by the dispatcher. DB_File,
# Archive::Zip and File::Temp are required inline (optional deps).

use strict;
use warnings;
use Fcntl          qw(O_RDWR O_CREAT);
use POSIX          qw(strftime);
use File::Basename qw(basename);
use File::Path     qw(make_path);
use Cwd            qw(realpath);
use Lazysite::Util qw(log_event);
use Lazysite::Manager::Common
    qw(validate_path is_blocked_path is_blocked_config respond upload_limits outside_all_scopes);
use Lazysite::Auth::Acl qw(_acl_denied);
use Exporter 'import';

our @EXPORT_OK = qw(
    action_file_upload action_file_download action_file_zip_download collect_zip_paths
    check_upload_rate parse_multipart_body sanitise_upload_filename
    detect_content_type is_editable_text
);

our $DOCROOT;
our $LAZYSITE_DIR;
our $auth_user = '';

our %CONTENT_TYPE_MAP = (
    md    => 'text/plain; charset=utf-8',
    txt   => 'text/plain; charset=utf-8',
    html  => 'text/html; charset=utf-8',
    htm   => 'text/html; charset=utf-8',
    css   => 'text/css; charset=utf-8',
    js    => 'text/javascript; charset=utf-8',
    json  => 'application/json; charset=utf-8',
    jsonl => 'application/jsonl; charset=utf-8',
    xml   => 'application/xml; charset=utf-8',
    yaml  => 'text/yaml; charset=utf-8',
    yml   => 'text/yaml; charset=utf-8',
    csv   => 'text/csv; charset=utf-8',
    png   => 'image/png',
    jpg   => 'image/jpeg',
    jpeg  => 'image/jpeg',
    gif   => 'image/gif',
    webp  => 'image/webp',
    svg   => 'image/svg+xml',
    ico   => 'image/vnd.microsoft.icon',
    pdf   => 'application/pdf',
    zip   => 'application/zip',
);

our %TEXT_EXTENSIONS = map { $_ => 1 } qw(
    md url txt html htm css js json jsonl xml tt
    yaml yml csv tsv conf ini log pl pm
    sh bash env example brief
);

sub check_upload_rate {
    my ( $username, $content_length ) = @_;
    my $limits = upload_limits();

    return { ok => 1 }
        if $limits->{rate_count} == 0
        && $limits->{rate_bytes} == 0;

    my $rate_dir  = "$LAZYSITE_DIR/manager";
    my $rate_path = "$rate_dir/.upload-rate.db";
    make_path($rate_dir) unless -d $rate_dir;

    my %db;
    # Note: no assignment of the tie return value - holding a
    # reference to the tied object would trigger "untie attempted
    # while inner references still exist" on the untie below.
    eval { require DB_File; 1 } or do {
        log_event( 'WARN', 'file-upload', 'rate DB tie failed',
            path => $rate_path, error => "DB_File unavailable: $@" );
        return { ok => 1 };
    };
    eval {
        no warnings 'once';
        tie %db, 'DB_File', $rate_path, O_RDWR | O_CREAT, 0o600,
            $DB_File::DB_HASH;
    };
    unless ( tied %db ) {
        log_event( 'WARN', 'file-upload', 'rate DB tie failed',
            path => $rate_path, error => ( $@ || 'tie returned empty' ) );
        return { ok => 1 };    # fail open
    }

    my $hour      = int( time() / 3600 );
    my $count_key = "$username:$hour:count";
    my $bytes_key = "$username:$hour:bytes";

    my $cur_count = $db{$count_key} || 0;
    my $cur_bytes = $db{$bytes_key} || 0;

    if ( $limits->{rate_count} > 0
        && $cur_count >= $limits->{rate_count} ) {
        untie %db;
        log_event( 'WARN', 'file-upload',
            'rate limit exceeded (count)',
            user  => $username,  hour  => $hour,
            count => $cur_count, limit => $limits->{rate_count} );
        return { ok => 0,
            error => "Upload rate limit reached "
                . "($limits->{rate_count} per hour)" };
    }

    if ( $limits->{rate_bytes} > 0
        && $cur_bytes + $content_length > $limits->{rate_bytes} ) {
        untie %db;
        log_event( 'WARN', 'file-upload',
            'rate limit exceeded (bytes)',
            user      => $username,  hour  => $hour,
            bytes     => $cur_bytes, limit => $limits->{rate_bytes},
            requested => $content_length );
        return { ok => 0,
            error => "Upload size limit reached for this hour" };
    }

    # Reserve up-front. CONTENT_LENGTH includes multipart overhead so
    # this slightly over-counts, which is the safe direction. Counted
    # per request, not per file: a ten-file upload in one request
    # costs one count slot.
    $db{$count_key} = $cur_count + 1;
    $db{$bytes_key} = $cur_bytes + $content_length;

    for my $k ( keys %db ) {
        if ( $k =~ /:(\d+):/ ) {
            delete $db{$k} if $1 < $hour - 1;
        }
    }

    untie %db;
    return { ok => 1 };
}

sub parse_multipart_body {
    my ( $body, $content_type ) = @_;

    my ( $q_boundary, $u_boundary ) = $content_type =~
        m{multipart/form-data.*?boundary=(?:"([^"]+)"|([^;\s]+))}i;
    my $boundary = $q_boundary // $u_boundary // '';
    return () unless length $boundary;

    my @parts;
    # Relies on well-formed boundaries - a boundary string appearing
    # inside a payload would corrupt parsing. This is the documented
    # multipart assumption; browsers pick random-looking boundaries
    # that make collision vanishingly unlikely.
    for my $chunk ( split /--\Q$boundary\E(?:--)?\r?\n?/, $body ) {
        next unless length $chunk;
        next unless $chunk =~ /\r?\n\r?\n/;

        my ( $headers, $content ) = split /\r?\n\r?\n/, $chunk, 2;
        next unless defined $content;

        $content =~ s/\r?\n\z//;

        my %part;
        if ( $headers =~ /Content-Disposition:\s*[^;]+;(.+)/i ) {
            my $disp = $1;
            ( $part{name} )     = $disp =~ /\bname="([^"]*)"/;
            ( $part{filename} ) = $disp =~ /\bfilename="([^"]*)"/;
        }
        if ( $headers =~ /Content-Type:\s*(\S+)/i ) {
            $part{type} = $1;
        }
        $part{data} = $content;
        push @parts, \%part if defined $part{name};
    }
    return @parts;
}

sub sanitise_upload_filename {
    my ($name) = @_;
    return '' unless defined $name;
    $name =~ s{.*[/\\]}{};         # basename only
    return '' if $name =~ /\0/;    # null bytes
    return '' if $name eq '' || $name eq '.' || $name eq '..';
    $name =~ s/[\x00-\x1f]//g;     # strip control chars
    return $name;
}

sub action_file_upload {
    my ( $rel_dir, $body ) = @_;

    my $ctype = $ENV{CONTENT_TYPE} // '';
    unless ( $ctype =~ m{^multipart/form-data}i ) {
        return { ok => 0, error => "Expected multipart body" };
    }

    $rel_dir //= '/';
    $rel_dir =~ s{^/+}{};
    $rel_dir =~ s{/+$}{};

    # SM418: REJECT `..` IN THE TARGET DIRECTORY, before anything resolves it.
    #
    # This handler used to confine on the RAW request string while the OS
    # resolved `..` at write time - so `content/../lazysite/auth` passed every
    # check here (the -d test and the realpath boundary both SUCCEED, because
    # lazysite/auth really is inside the docroot) and the blocklist then
    # string-matched `content/../lazysite/auth/.secret` against a guard anchored
    # `\Alazysite/`, which does not match a string starting `content/`.
    # Reproduced: an upload overwrote the cookie-signing secret and the handler
    # reported ok:1. An unscoped manage_content editor could mint operator
    # sessions from it.
    #
    # The same class as SEC-2026-07 F1, which validate_path fixed for every
    # other file-write handler; this one never called it. Per-file validation
    # below is the real gate - this is the upfront refusal so a traversal
    # attempt is ONE clear error rather than one per file.
    return { ok => 0, error => "Invalid target directory" }
        if $rel_dir =~ m{(?:\A|/)\.\.(?:/|\z)};

    my $full_dir = length $rel_dir ? "$DOCROOT/$rel_dir" : $DOCROOT;

    unless ( -d $full_dir ) {
        return { ok => 0, error => "Target is not a directory" };
    }
    my $real = realpath($full_dir);
    unless ( $real && ( $real eq $DOCROOT || index( $real, "$DOCROOT/" ) == 0 ) ) { # SEC-2026-07 (H3)
        return { ok => 0, error => "Invalid target directory" };
    }

    my @parts = parse_multipart_body( $body, $ctype );
    my @files = grep { defined $_->{filename}
            && length $_->{filename} } @parts;

    unless (@files) {
        return { ok => 0, error => "No files in upload" };
    }

    my $overwrite = 0;
    for my $p (@parts) {
        if ( ( $p->{name} // '' ) eq 'overwrite'
            && ( $p->{data} // '' ) eq '1' ) {
            $overwrite = 1;
        }
    }

    my @saved;
    my @skipped;
    my @errors;

    for my $file (@files) {
        my $fname = sanitise_upload_filename( $file->{filename} );
        unless ( length $fname ) {
            push @errors, { name => $file->{filename},
                error => 'Invalid filename' };
            next;
        }

        my $rel_request = length $rel_dir ? "$rel_dir/$fname" : $fname;

        # SM418: THROUGH validate_path, exactly as action_save_binary does.
        # It rejects `..`, resolves symlinks, checks the docroot boundary and -
        # the part that matters here - returns the CANONICAL rel, which is what
        # the blocklist must string-match. A raw concatenation is not a path,
        # it is a request, and the two differ precisely when it matters.
        #
        # It also resolves the PRIVATE store (resolve_for_write): before this,
        # an upload into a gated section wrote a public copy beside protected
        # content, half-publishing the section through an operation nobody
        # thinks of as a permission change (SM286's whole point).
        my $v = validate_path($rel_request);
        unless ( $v->{ok} ) {
            push @errors, { name => $fname,
                error => $v->{error} // 'Invalid path' };
            next;
        }
        my $rel_target  = $v->{rel};
        my $full_target = $v->{full};

        # SM730: name the rule. The blockers return a reason now, and an
        # operator who has legitimately prepared a template needs to know the
        # refusal is deliberate and permanent - otherwise the next move is to
        # try to work around it.
        if ( my $why = is_blocked_path($rel_target)
            || is_blocked_config( $rel_target, 1 ) ) {
            push @errors, { name => $fname, error => $why };
            next;
        }

        if ( -e $full_target && !$overwrite ) {
            push @skipped, $fname;
            next;
        }

        my $tmp = "$full_target.tmp.$$";
        open my $fh, '>', $tmp or do {
            push @errors, { name => $fname,
                error => "Cannot write: $!" };
            next;
        };
        binmode $fh;
        unless ( print {$fh} $file->{data} ) {
            my $err = "$!";
            close $fh;
            unlink $tmp;
            push @errors, { name => $fname,
                error => "Write failed: $err" };
            next;
        }
        unless ( close $fh ) {
            my $err = "$!";
            unlink $tmp;
            push @errors, { name => $fname,
                error => "Close failed: $err" };
            next;
        }

        unless ( rename $tmp, $full_target ) {
            my $err = "$!";
            unlink $tmp;
            push @errors, { name => $fname,
                error => "Cannot rename: $err" };
            next;
        }

        my @st = stat $full_target;
        push @saved, {
            name  => $fname,
            path  => $rel_target,
            size  => $st[7] // 0,
            mtime => $st[9] // 0,
        };

        log_event( 'INFO', 'file-upload', 'file uploaded',
            path => $rel_target, size => $st[7] // 0,
            user => $auth_user );

        if ( $full_target =~ /\.md$/ ) {
            ( my $cache = $full_target ) =~ s/\.md$/.html/;
            unlink $cache if -f $cache;
            # SM110: drop the per-alias-host copies of this page's render too.
            Lazysite::Util::unlink_host_copies( $DOCROOT, $cache );
        }
    }

    # SM085: a multi-file upload is ONE content-history commit (instant no-op
    # when the feature is off; a git failure never fails the upload).
    if (@saved) {
        require Lazysite::Git;
        my @paths = map { $_->{path} } @saved;
        my $msg   = @paths == 1 ? "upload $paths[0]"
            :   'upload ' . scalar(@paths) . ' files';
        Lazysite::Git::commit_paths( $DOCROOT, $auth_user, $msg, @paths );
    }

    # ok=1 means the request was processed. The client inspects
    # saved/skipped/errors to decide what to show. Returning ok=0
    # when all files were skipped-no-overwrite would make the
    # client show "Upload failed" instead of the overwrite prompt.
    return {
        ok      => 1,
        saved   => \@saved,
        skipped => \@skipped,
        errors  => \@errors,
    };
}

sub detect_content_type {
    my ($path) = @_;
    my ($ext)  = $path =~ /\.([^.\/]+)$/;
    return 'application/octet-stream' unless defined $ext;
    return $CONTENT_TYPE_MAP{ lc $ext }
        // 'application/octet-stream';
}

sub is_editable_text {
    my ($path) = @_;
    my ($ext)  = $path =~ /\.([^.\/]+)$/;
    return 1 unless defined $ext;    # no extension: assume text
    return $TEXT_EXTENSIONS{ lc $ext } ? 1 : 0;
}

# The attachment response: the header stack and the sysread/syswrite loop
# that were written out three times in this engine - twice here and once in
# Backups' backup-download - byte for byte the same. (A fourth copy lives in
# lazysite-manager-api.pl and folds in with that file.)
#
# binmode STDOUT BEFORE local $|, and both before anything is printed:
# syswrite bypasses Perl's stdio buffer, so without autoflush the print-ed
# headers land in stdout AFTER the body bytes. The filename loses the bytes
# that would break out of the header field, as each copy did for itself.
#
# Returns 1 once the body is written, 0 if the file could not be opened -
# which is after the headers have gone, so what a caller says about that is
# its own business and stays with the caller.
sub stream_attachment {
    my ( $path, $ctype, $filename, $size ) = @_;
    ( my $safe = $filename ) =~ s/[\r\n"\\]//g;

    binmode STDOUT;
    local $| = 1;
    print "Status: 200 OK\r\n";
    print "Content-Type: $ctype\r\n";
    print "Content-Length: $size\r\n";
    print "Content-Disposition: attachment; filename=\"$safe\"\r\n";
    print "Cache-Control: no-store, private\r\n";
    print "\r\n";

    open my $fh, '<', $path or return 0;
    binmode $fh;
    my $buf;
    while ( my $n = sysread( $fh, $buf, 65536 ) ) {
        syswrite STDOUT, $buf, $n;
    }
    close $fh;
    return 1;
}

sub action_file_download {
    my ($rel_path) = @_;

    my $result = validate_path($rel_path);
    unless ( $result->{ok} ) {
        respond( { ok => 0, error => $result->{error} } );
        return;
    }

    # SM019 decision point: consult is_blocked_path on download so a
    # manager cannot grab lazysite/auth/.secret (or any .pl) through
    # this action just because action_read blocks them. The briefing
    # did not specify this; added for parity with read/save/delete.
    if ( is_blocked_path( $result->{rel} ) ) {
        respond( { ok => 0, error => "Path is blocked" } );
        return;
    }
    # SM019c: config block list applies to downloads too, so a
    # caller cannot siphon the manager UI or any other configured
    # sensitive directory via this surface.
    if ( is_blocked_config( $result->{rel} ) ) {
        respond( { ok => 0, error => "Path is blocked by config" } );
        return;
    }
    # SEC-2026-07 (F2 audit): download bypassed the read ACL that action_read
    # enforces, so a non-operator could grab a file another owner restricted to
    # someone else. Enforce the same read gate here. (dav_scope confinement for
    # this single-path action is applied at dispatch via %SCOPED_ACTION.)
    if ( my $d = _acl_denied( $result->{rel}, 'read', $auth_user ) ) {
        respond($d);
        return;
    }

    my $full = $result->{full};

    unless ( -f $full ) {
        respond( { ok => 0, error => "File not found" } );
        return;
    }
    if ( -d $full ) {
        respond( { ok => 0, error => "Not a file" } );
        return;
    }

    my $basename = basename($full);
    my $ctype    = detect_content_type($full);
    my $size     = ( stat $full )[7] // 0;

    log_event( 'DEBUG', 'file-download', 'file downloaded',
        path => $result->{rel}, size => $size,
        user => $auth_user );

    stream_attachment( $full, $ctype, $basename, $size );
    return;
}

sub collect_zip_paths {
    my @paths;
    for my $pair ( split /&/, $ENV{QUERY_STRING} // '' ) {
        my ( $k, $v ) = split /=/, $pair, 2;
        next unless defined $k && defined $v;
        next unless $k eq 'paths' || $k eq 'paths[]';
        $v =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
        $v =~ s/\+/ /g;
        push @paths, $v if length $v;
    }
    return @paths;
}

sub action_file_zip_download {
    my ($scopes)  = @_;    # SEC-2026-07 (F2): the request's resolved dav_scopes
    my @requested = collect_zip_paths();
    unless (@requested) {
        respond( { ok => 0, error => "No files selected" } );
        return;
    }

    my $max_total = upload_limits()->{max_bytes} * 10;

    require Archive::Zip;
    Archive::Zip->import(qw(:ERROR_CODES));

    my $zip   = Archive::Zip->new();
    my $total = 0;
    my $added = 0;

    for my $rel (@requested) {
        my $vr = validate_path($rel);
        unless ( $vr->{ok} ) {
            log_event( 'WARN', 'file-zip-download',
                'skipped (invalid path)',
                path => $rel, user => $auth_user );
            next;
        }
        if ( is_blocked_path( $vr->{rel} ) ) {
            log_event( 'WARN', 'file-zip-download',
                'skipped (blocked path)',
                path => $rel, user => $auth_user );
            next;
        }
        # SM019c: config block list applies to zip-download too,
        # mirroring single-file download.
        if ( is_blocked_config( $vr->{rel} ) ) {
            log_event( 'WARN', 'file-zip-download',
                'skipped (blocked by config)',
                path => $rel, user => $auth_user );
            next;
        }
        # SEC-2026-07 (F2 audit): the read ACL and dav_scope confinement that
        # action_read applies were skipped here, so a non-sysop (or a
        # scope-confined editor) could bulk-download files they may not read.
        # Skip any path the caller cannot read, or that lies outside their scope.
        if ( _acl_denied( $vr->{rel}, 'read', $auth_user ) ) {
            log_event( 'WARN', 'file-zip-download', 'skipped (read ACL denied)',
                path => $rel, user => $auth_user );
            next;
        }
        if ( ref $scopes eq 'ARRAY'
            && @$scopes
            && outside_all_scopes( $scopes, $vr->{rel} ) )
        {
            log_event( 'WARN', 'file-zip-download', 'skipped (outside dav_scope)',
                path => $rel, user => $auth_user );
            next;
        }

        my $full = $vr->{full};
        unless ( -f $full ) {
            log_event( 'WARN', 'file-zip-download',
                'skipped (not a file)',
                path => $rel, user => $auth_user );
            next;
        }

        my $size = ( stat $full )[7] // 0;
        $total += $size;
        if ( $total > $max_total ) {
            respond( { ok => 0, error => "Total size exceeds limit" } );
            return;
        }

        $zip->addFile( $full, $vr->{rel} );
        $added++;
    }

    unless ($added) {
        respond( { ok => 0, error => "No valid files" } );
        return;
    }

    require File::Temp;
    my $tmp = File::Temp->new(
        TEMPLATE => 'lazysite-zip-XXXXXX',
        SUFFIX   => '.zip',
        TMPDIR   => 1,
    );
    my $tmp_path = $tmp->filename;

    unless ( $zip->writeToFileNamed($tmp_path) == 0 ) {    # AZ_OK
        respond( { ok => 0, error => "Zip write failed" } );
        return;
    }

    my $zip_size = ( stat $tmp_path )[7] // 0;
    my $ts       = strftime( '%Y%m%d-%H%M%S', localtime );
    my $fname    = "lazysite-files-$ts.zip";

    log_event( 'INFO', 'file-zip-download', 'zip downloaded',
        count => $added, size => $zip_size,
        user  => $auth_user );

    stream_attachment( $tmp_path, 'application/zip', $fname, $zip_size );
    return;
}

1;
