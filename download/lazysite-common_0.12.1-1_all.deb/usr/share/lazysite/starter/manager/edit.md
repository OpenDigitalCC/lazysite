---
title: Edit
auth: manager
search: false
query_params:
  - path
  - new
---

<div id="editor-root" class="mg-editor-root">
<link rel="stylesheet" href="/manager/assets/cm/codemirror.min.css?v=[% lazysite_version %]">
<style>
.mg-main { padding:0; max-width:none; }
.mg-main h1 { display:none; }
/* Critical editor layout, inlined so the editor is usable even if the external
   manager.css is stale or fails to load (it is copied to /manager/assets/ at
   install time; a missing copy would otherwise collapse the panes to zero - the
   "page ends at extra, no edit box" symptom). */
#editor-root.mg-editor-root { position: fixed; inset: 48px 0 0 0; display: flex;
  flex-direction: column; background: var(--mg-bg, #fff); z-index: 40; }
#ed-main.mg-editor-main { display: flex; flex: 1 1 auto; min-height: 0; overflow: hidden; }
#ed-editor-pane.mg-editor-pane { display: flex; flex-direction: column; min-width: 0; }
.mg-stack-section { display: flex; flex-direction: column; min-height: 0; }
/* A collapsed section is its summary bar and nothing more; an open one takes
   the space it needs. Without this the flex-basis applies either way and a
   closed section still reserves 24vh of empty pane. */
details.mg-stack-section > summary { cursor: pointer; list-style: none; }
details.mg-stack-section > summary::-webkit-details-marker { display: none; }
details.mg-stack-section > summary::before { content: '\25B8'; margin-right: 0.35rem;
  display: inline-block; transition: transform 0.12s; }
details.mg-stack-section[open] > summary::before { transform: rotate(90deg); }
#ed-meta-section { min-height: 0; flex: 0 0 auto; }
/* Sized by its CONTENT up to a ceiling, not to a fixed band. Six lines of
   front matter took 24vh either way, so the pane ended in dead space with a
   rule under it and the content pane started lower than it needed to. */
#ed-meta-section[open] { flex: 0 0 auto; min-height: 48px; max-height: 40vh; }
#ed-meta-section[open] .CodeMirror { height: auto; min-height: 3rem; max-height: 36vh; }
#ed-content-section { flex: 0 0 auto; min-height: 0; }
#ed-content-section[open] { flex: 1 1 auto; min-height: 20vh; }
#ed-perms-section { flex: 0 0 auto; }
#ed-perms-section[open] { max-height: 46vh; overflow: auto; }
.mg-stack-header { display: flex; align-items: baseline; gap: 0.4rem; padding: 0.25rem 0.5rem;
  font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.04em;
  color: var(--mg-text-muted, #6b7280); background: var(--mg-surface-alt, #f3f4f6); }
.mg-stack-header .mg-stack-hint { text-transform: none; letter-spacing: 0; opacity: 0.7; font-size: 0.7rem; }
#ed-yaml-cm.mg-cm-yaml, #ed-content-cm.mg-cm-content { flex: 1 1 auto; min-height: 0; overflow: hidden; }
#ed-meta-section .CodeMirror, #yaml-fallback { height: 100%; min-height: 0; }
#ed-content-cm .CodeMirror, #content-fallback { height: 100%; min-height: 0; }
#ed-vsplit.mg-vsplit { flex: 0 0 6px; cursor: row-resize; background: var(--mg-border, #d1d5db); }
#ed-vsplit.mg-vsplit:hover { background: var(--mg-text-light, #9ca3af); }
#ed-preview-pane.mg-preview-pane { display: flex; flex-direction: column; min-width: 0; }

/* THE SWITCH EXISTS ONLY WHERE THE PANES CANNOT SHARE. Above 1000px both fit
   and the divider does the job; below it, half of a narrow window is unusable
   twice over, so one pane is shown at a time and this chooses which. */
.mg-pane-switch { display: none; }
@media (max-width: 1000px) {
    .mg-pane-switch { display: flex; gap: 6px; padding: 6px 8px;
        border-bottom: 1px solid var(--mg-border); background: var(--mg-surface-alt); }
    #ed-main.mg-editor-main { flex-direction: column; }
    #ed-divider.mg-editor-divider { display: none; }
    #editor-root[data-pane="edit"] #ed-preview-pane { display: none; }
    #editor-root[data-pane="preview"] #ed-editor-pane { display: none; }
    #ed-editor-pane.mg-editor-pane, #ed-preview-pane.mg-preview-pane { flex: 1 1 auto; min-height: 0; }
}
#ed-preview-frame { flex: 1 1 auto; min-height: 50vh; width: 100%; border: 0; }
#ed-save-btn.dirty { background:var(--mg-accent); color:var(--mg-accent-text); border-color:var(--mg-accent); font-weight:600; }
#ed-filepath a { color:var(--mg-accent); text-decoration:none; }
#ed-filepath a:hover { text-decoration:underline; }
.mg-cache-notice {
  background: var(--mg-warning-bg);
  color: var(--mg-text);
  border-bottom: 1px solid var(--mg-warning);
  padding: 0.4rem 0.75rem;
  font-size: 0.85rem;
}
.mg-cache-notice a { color: var(--mg-accent); text-decoration: underline; }
</style>

<div class="mg-editor-toolbar">
<a href="/manager/files" class="mg-btn mg-btn-sm mg-editor-back" title="Back to Files (Esc)">&#8592; Files</a>
<span id="ed-filepath" class="mg-editor-path" data-path="[% query.path %]" data-new="[% query.new %]">[% query.path %]</span>
<span id="ed-lock-dot" class="mg-lock-dot" title=""></span>
<span id="ed-lock-label" style="font-size:0.8rem;color:var(--mg-text-muted);"></span>
<span style="flex:1;"></span>
<span style="font-size:0.75rem;color:var(--mg-text-light);">Ctrl+S</span>
<button id="ed-save-btn" class="mg-btn mg-btn-primary" onclick="savePage()" disabled>Save</button>
<button class="mg-btn" onclick="refreshPreview()">Preview</button>
<a id="ed-view-link" href="#" target="_blank" class="mg-btn">View page</a>
<a id="ed-download-btn" class="mg-btn mg-btn-sm" href="#" download>Download</a>
</div>

<div id="ed-cache-notice" class="mg-cache-notice" style="display:none;"></div>

<div id="json-render" class="mg-card" style="display:none">
  <div class="mg-card-header">
    <span class="mg-card-title" id="json-render-title">Preview</span>
  </div>
  <div class="mg-card-body" id="json-render-body"></div>
</div>

<div id="ed-main" class="mg-editor-main">
<div id="ed-editor-pane" class="mg-editor-pane">
<details id="ed-fm-section" class="mg-fm-section" open>
<summary>Front matter fields</summary>
<div class="mg-fm-fields">
<div class="mg-field"><label style="width:60px;">title</label><input type="text" id="fm-title" oninput="syncFmField('title',this.value)"></div>
<div class="mg-field"><label style="width:60px;">subtitle</label><input type="text" id="fm-subtitle" oninput="syncFmField('subtitle',this.value)"></div>
<div class="mg-field"><label style="width:60px;">auth</label><select id="fm-auth" onchange="syncFmField('auth',this.value)"><option value="">--</option><option value="none">none</option><option value="optional">optional</option><option value="required">required</option></select></div>
<div class="mg-field"><label style="width:60px;">search</label><select id="fm-search" onchange="syncFmField('search',this.value)"><option value="">default</option><option value="true">true</option><option value="false">false</option></select></div>
</div>
</details>
<details id="ed-meta-section" class="mg-stack-section" ontoggle="edRefreshEditors()">
<summary class="mg-stack-header">Metadata<span class="mg-stack-hint">YAML front matter</span></summary>
<div id="ed-yaml-cm" class="mg-cm-yaml"></div>
</details>
<div id="ed-vsplit" class="mg-vsplit" title="Drag to resize Metadata / Content"></div>
<details id="ed-content-section" class="mg-stack-section" ontoggle="edRefreshEditors()" open>
<summary class="mg-stack-header">Content<span class="mg-stack-hint">Markdown</span></summary>
<div id="ed-content-cm" class="mg-cm-content"></div>
</details>
<details id="ed-perms-section" class="mg-stack-section" ontoggle="loadEditorPerms()">
<summary class="mg-stack-header">Access<span class="mg-stack-hint">owner, and who may read or write this file</span></summary>
<div id="ed-perms-body" class="mg-expand-body">Loading&hellip;</div>
</details>
</div>
<div id="ed-pane-switch" class="mg-pane-switch">
  <button type="button" class="mg-btn mg-btn-sm" id="ed-pane-edit" onclick="edPane('edit')">Edit</button>
  <button type="button" class="mg-btn mg-btn-sm" id="ed-pane-preview" onclick="edPane('preview')">Preview</button>
</div>
<div id="ed-divider" class="mg-editor-divider" title="Drag to resize"></div>
<div id="ed-preview-pane" class="mg-preview-pane">
<div class="mg-preview-toolbar"><span>Preview</span><span id="ed-preview-status" style="font-style:italic;">Save to preview</span><button class="mg-btn mg-btn-sm" onclick="refreshPreview()">Reload preview</button></div>
<iframe id="ed-preview-frame" class="mg-preview-frame" src="about:blank"></iframe>
</div>
</div>

<div class="mg-editor-statusbar">
<span id="ed-pos">Ln 1, Col 1</span>
<span id="ed-words">0 words</span>
<span id="ed-dirty" class="mg-editor-dirty"></span>
<span id="ed-saved" class="mg-editor-saved"></span>
</div>

</div>

<script src="/manager/assets/cm/codemirror.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/overlay.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/xml.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/markdown.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/yaml.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/htmlmixed.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/css.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/javascript.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/perl.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/shell.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/matchbrackets.min.js?v=[% lazysite_version %]"></script>
<script src="/manager/assets/cm/closebrackets.min.js?v=[% lazysite_version %]"></script>

<script>
var API = '/cgi-bin/lazysite-manager-api.pl';
// SM709: from the toolbar element's data attributes, not interpolated into
// this script. Inside <script> no HTML entity is decoded, so a path or flag
// carrying an escaped character arrived here as the entity text; in an
// attribute the parser decodes it and JS gets the real value. See the note in
// starter/docs/auth.md - this is the idiom for every value a page's script
// needs from the request or the viewer.
var edPathEl = document.getElementById('ed-filepath');
var filePath = edPathEl.dataset.path || '';
var isNew = (edPathEl.dataset.new || '') === '1';
// Exiting the editor should return to the file's OWN folder, not the Files root.
var backFolder = filePath ? filePath.replace(/\/?[^\/]*$/, '') : '';
var backUrl = '/manager/files' + (backFolder ? '?path=' + encodeURIComponent(backFolder) : '');
(function () { var b = document.querySelector('.mg-editor-back'); if (b) b.setAttribute('href', backUrl); })();
// Reserved control-area files (the lazysite/ tree, CGI scripts) are not editable
// via Files by design - manage them through their dedicated manager pages. The
// editor warns rather than opening a blank box on a blocked read.
function isReservedPath(p) {
  p = String(p || '').replace(/^\/+/, '');
  return /^lazysite\//i.test(p) || /^cgi-bin\//i.test(p) || /\.(?:pl|cgi)$/i.test(p);
}
var isMdFile = filePath && /\.md$/i.test(filePath);
var isHtmlFile = filePath && /\.html$/i.test(filePath);
var readOnly = false;
var fileMtime = null;
var isDirty = false;
// SM170: the CodeMirror change handler fires markDirty() on the INITIAL
// setValue() during load, which used to set the shared dirty-guard (and reset
// only isDirty, not the guard) - so leaving the editor always warned "unsaved".
// markDirty is suppressed until the content has finished loading.
var editorReady = false;
var lockRenewTimer = null;
var yamlCm = null;
var contentCm = null;

// --- TT overlay modes ---
if (typeof CodeMirror !== 'undefined') {

var TT_OPEN = '[' + '%';
var TT_CLOSE = '%' + ']';
var ttOverlay = {
  token: function(stream) {
    if (stream.match(TT_OPEN)) {
      while (!stream.eol()) { if (stream.match(TT_CLOSE)) break; stream.next(); }
      return 'tt-variable';
    }
    while (stream.next() != null) { if (stream.match(TT_OPEN, false)) break; }
    return null;
  }
};

CodeMirror.defineMode('markdown-tt', function(config) {
  return CodeMirror.overlayMode(
    CodeMirror.getMode(config, { name: 'markdown', xml: true }), ttOverlay);
});

CodeMirror.defineMode('htmlmixed-tt', function(config) {
  return CodeMirror.overlayMode(
    CodeMirror.getMode(config, 'htmlmixed'), ttOverlay);
});

}

function getModeForPath(path) {
  if (!path) return 'text';
  if (path.match(/\.md$/))    return 'markdown-tt';
  if (path.match(/\.tt$/))    return 'htmlmixed-tt';
  if (path.match(/\.ya?ml$/)) return 'yaml';
  if (path.match(/\.conf$/))  return 'yaml';
  if (path.match(/\.json$/))  return { name: 'javascript', json: true };
  if (path.match(/\.css$/))   return 'css';
  if (path.match(/\.pl$/))    return 'perl';
  if (path.match(/\.sh$/))    return 'shell';
  return 'text';
}

// --- Init editors ---
function initEditors() {
  if (typeof CodeMirror === 'undefined') {
    // Fallback: plain textareas
    document.getElementById('ed-yaml-cm').innerHTML =
      '<textarea id="yaml-fallback" style="width:100%;height:60px;font:12px monospace;"></textarea>';
    document.getElementById('ed-content-cm').innerHTML =
      '<textarea id="content-fallback" style="width:100%;height:400px;font:14px monospace;"></textarea>';
    yamlCm = {
      getValue: function() { return document.getElementById('yaml-fallback').value; },
      setValue: function(v) { document.getElementById('yaml-fallback').value = v; },
      on: function(ev, fn) { document.getElementById('yaml-fallback').addEventListener('input', fn); }
    };
    contentCm = {
      getValue: function() { return document.getElementById('content-fallback').value; },
      setValue: function(v) { document.getElementById('content-fallback').value = v; },
      getCursor: function() { return { line: 0, ch: 0 }; },
      setOption: function(opt, val) {
        if (opt === 'readOnly') {
          document.getElementById('content-fallback').disabled = val ? true : false;
        }
      },
      on: function(ev, fn) { document.getElementById('content-fallback').addEventListener('input', fn); }
    };
    return;
  }

  yamlCm = CodeMirror(document.getElementById('ed-yaml-cm'), {
    mode: 'yaml', lineNumbers: false, lineWrapping: true, tabSize: 2
  });
  yamlCm.on('change', function() { markDirty(); });

  contentCm = CodeMirror(document.getElementById('ed-content-cm'), {
    mode: getModeForPath(filePath),
    lineNumbers: true, lineWrapping: true, tabSize: 2,
    matchBrackets: true, autoCloseBrackets: true,
    extraKeys: {
      'Ctrl-S': savePage, 'Cmd-S': savePage,
      'Ctrl-P': refreshPreview, 'Cmd-P': refreshPreview
    }
  });
  contentCm.on('change', function() { markDirty(); updateStatus(); });
  contentCm.on('cursorActivity', updateStatus);
}

// --- Status bar ---
function updateStatus() {
  if (!contentCm || !contentCm.getCursor) return;
  var cur = contentCm.getCursor();
  document.getElementById('ed-pos').textContent = 'Ln ' + (cur.line+1) + ', Col ' + (cur.ch+1);
  var text = contentCm.getValue();
  var words = text.trim() ? text.trim().split(/\s+/).length : 0;
  document.getElementById('ed-words').textContent = words + ' words';
}

// --- Dirty state ---
function markDirty() {
  if (!editorReady) return;   // SM170: ignore change events from the initial load
  if (!isDirty) {
    isDirty = true;
    document.getElementById('ed-save-btn').classList.add('dirty');
    document.getElementById('ed-save-btn').disabled = false;
    document.getElementById('ed-dirty').textContent = 'unsaved';
    mgDirtyGuard.set('editor');
  }
}
function clearDirty() {
  isDirty = false;
  document.getElementById('ed-save-btn').classList.remove('dirty');
  document.getElementById('ed-dirty').textContent = '';
  document.getElementById('ed-saved').textContent = 'Saved ' + new Date().toLocaleTimeString();
  mgDirtyGuard.clear('editor');
}

// --- Front matter ---
function parseFrontMatter(content) {
  var m = content.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!m) return { yaml: '', body: content };
  return { yaml: m[1], body: m[2] };
}

function populateFmFields(yaml) {
  var get = function(key) {
    var m = yaml.match(new RegExp('^' + key + '\\s*:\\s*(.+)$', 'm'));
    return m ? m[1].trim() : '';
  };
  document.getElementById('fm-title').value = get('title');
  document.getElementById('fm-subtitle').value = get('subtitle');
  document.getElementById('fm-auth').value = get('auth') || '';
  document.getElementById('fm-search').value = get('search') || '';
  var extra = yaml.split('\n').filter(function(l) {
    return !l.match(/^(title|subtitle|auth|search)\s*:/);
  });
  yamlCm.setValue(extra.join('\n').trim());
}

function syncFmField(key, val) { markDirty(); }

function buildYaml() {
  var parts = [];
  var t = document.getElementById('fm-title').value.trim();
  var s = document.getElementById('fm-subtitle').value.trim();
  var a = document.getElementById('fm-auth').value;
  var sr = document.getElementById('fm-search').value;
  if (t) parts.push('title: ' + t);
  if (s) parts.push('subtitle: ' + s);
  if (a) parts.push('auth: ' + a);
  if (sr) parts.push('search: ' + sr);
  var extra = yamlCm.getValue().trim();
  if (extra) parts.push(extra);
  return parts.join('\n');
}

function buildContent() {
  return '---\n' + buildYaml() + '\n---\n' + contentCm.getValue();
}

// --- Lock ---
function acquireLock() {
  if (!filePath || isNew) return;
  fetch(API + '?action=lock&path=' + encodeURIComponent(filePath))
    .then(function(r) { return r.json(); })
    .then(function(data) {
      var dot = document.getElementById('ed-lock-dot');
      var lbl = document.getElementById('ed-lock-label');
      if (data.locked && data.locked_by) {
        dot.className = 'lock-dot locked';
        // A stale lock (e.g. an editor left open across a restart) can't be
        // waited out without the 5-min TTL, so offer to take it over. The server
        // still refuses a live WebDAV lock.
        lbl.innerHTML = 'Locked by ' + String(data.locked_by).replace(/[<>&"]/g, '') +
          ' <button class="mg-btn mg-btn-sm" onclick="takeOverLock()">Take over</button>';
        document.getElementById('ed-save-btn').disabled = true;
      } else {
        dot.className = 'lock-dot editing'; lbl.textContent = '';
        lockRenewTimer = setInterval(function() {
          fetch(API + '?action=renew-lock&path=' + encodeURIComponent(filePath));
        }, 60000);
      }
    }).catch(function() {});
}

// Clear a stale lock and re-acquire it. The server refuses a live WebDAV lock.
function takeOverLock() {
  mgConfirm('Take over this file? Any unsaved edits in the other session may be lost.', { danger: true, ok: 'Take over' }).then(function(__ok) {
    if (!__ok) return;
    fetch(API + '?action=unlock&path=' + encodeURIComponent(filePath), { method: 'POST' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.ok) { acquireLock(); }
      else { mgToast(d.error || 'Could not clear the lock (it may be a live WebDAV lock).', 'error'); }
    })
    .catch(function() {});
  });
}

// --- Load ---
function loadFile() {
  // Build the editor unconditionally and FIRST, so the edit box always renders -
  // even when no file path arrived (empty query.path) or a later setup step
  // hiccups. Previously an empty path returned here before initEditors(), leaving
  // the full-screen overlay covering the page with no visible edit box.
  initEditors();
  if (!filePath) {
    if (contentCm) contentCm.setValue(
      '# No file selected\n\nOpen a file from the Files page to edit it.\n');
    var nb = document.getElementById('ed-save-btn'); if (nb) nb.disabled = true;
    var nf = document.getElementById('ed-fm-section'); if (nf) nf.style.display = 'none';
    return;
  }
  // A reserved control-area file: warn and stop, don't open the editor / take a
  // lock / attempt a (blocked) read.
  if (isReservedPath(filePath)) {
    document.getElementById('ed-filepath').innerHTML = buildBreadcrumb(filePath)
      + ' <span style="color:var(--mg-danger,#b00);font-weight:600;"> &mdash; system file (read-only)</span>';
    if (contentCm) {
      contentCm.setValue(
        'This file is part of the lazysite control area (lazysite/) and cannot be edited here.\n\n'
        + 'Manage these settings through their dedicated manager pages instead:\n'
        + '  • lazysite.conf  →  Config / Domains\n'
        + '  • nav.conf       →  Navigation\n'
        + '  • users, groups  →  Users\n\n'
        + 'The reserved lazysite/ tree is not editable via Files by design.');
      if (contentCm.setOption) contentCm.setOption('readOnly', true);
    }
    var sb = document.getElementById('ed-save-btn'); if (sb) sb.disabled = true;
    var fm = document.getElementById('ed-fm-section'); if (fm) fm.style.display = 'none';
    var pv = document.getElementById('ed-preview-pane'); if (pv) pv.style.display = 'none';
    var dv = document.getElementById('ed-divider'); if (dv) dv.style.display = 'none';
    return;
  }
  document.getElementById('ed-filepath').innerHTML = buildBreadcrumb(filePath);
  var viewPath = filePath.replace(/\.md$/, '').replace(/\/index$/, '/');
  if (viewPath.charAt(0) !== '/') viewPath = '/' + viewPath;
  document.getElementById('ed-view-link').href = viewPath;

  // SM019: Download button is useful for every file type, so wire
  // it for every path. For binary files the whole toolbar is hidden
  // below and replaced by the binary panel's big Download button.
  var dl = document.getElementById('ed-download-btn');
  if (dl) {
    dl.href = API + '?action=file-download&path=' + encodeURIComponent(filePath);
    dl.setAttribute('download', filePath.split('/').pop());
  }

  if (!isMdFile) {
    document.getElementById('ed-fm-section').style.display = 'none';
    document.getElementById('ed-preview-pane').style.display = 'none';
    document.getElementById('ed-divider').style.display = 'none';
    document.getElementById('ed-editor-pane').style.width = '100%';
  }

  if (isNew) {
    yamlCm.setValue('');
    contentCm.setValue('\n## Content\n\nPage content here.\n');
    populateFmFields('title: New Page\nsubtitle: ');
    document.getElementById('ed-save-btn').disabled = false;
    editorReady = true;   // SM170
    return;
  }

  if (isHtmlFile) {
    checkHtmlCacheThenLoad();
    return;
  }

  // SM115: append-only data (form submissions, .jsonl) opens read-only - editing the
  // whole file would clobber records appended concurrently. Edit anyway is explicit.
  if (isAppendOnlyData(filePath)) {
    readOnly = true;
    showDataNotice();
    loadContent();
    return;
  }

  acquireLock();
  loadContent();
}

function isAppendOnlyData(p) {
  return /\/forms\/submissions\//.test(p) || /\.jsonl$/i.test(p);
}

function showDataNotice() {
  var el = document.getElementById('ed-cache-notice');
  if (el) {
    el.innerHTML = 'Append-only data (form submissions). Read-only to protect records '
      + 'being written concurrently. '
      + '<a href="#" onclick="enableDataEdit();return false;">Edit anyway</a>';
    el.style.display = '';
  }
}

function enableDataEdit() {
  readOnly = false;
  if (contentCm) contentCm.setOption('readOnly', false);
  if (yamlCm)    yamlCm.setOption('readOnly', false);
  var btn = document.getElementById('ed-save-btn');
  if (btn) { btn.disabled = false; btn.style.display = ''; }
  var el = document.getElementById('ed-cache-notice');
  if (el) el.style.display = 'none';
}

function checkHtmlCacheThenLoad() {
  var mdPath = filePath.replace(/\.html$/i, '.md');
  fetch(API + '?action=read&path=' + encodeURIComponent(mdPath))
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.ok) {
        readOnly = true;
        showCacheNotice(mdPath);
        loadContent();
      } else {
        acquireLock();
        loadContent();
      }
    })
    .catch(function() {
      acquireLock();
      loadContent();
    });
}

function showCacheNotice(mdPath) {
  var el = document.getElementById('ed-cache-notice');
  var escPath = mdPath.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  el.innerHTML = 'This is a cached page. Editing is disabled. ' +
    '<a href="/manager/edit?path=' + encodeURIComponent(mdPath) + '">Edit source: ' + escPath + '</a>';
  el.style.display = '';
  document.getElementById('ed-save-btn').style.display = 'none';
}

// --- JSON / JSONL read-only preview above the raw editor ---
// SM017: when the file being edited is a .json or .jsonl file,
// render a pretty-printed preview above the CodeMirror editor.
// Non-JSON files hide the preview card entirely. The raw editor
// remains the authoritative write surface; the preview is
// display-only and re-rendered after a successful save.

// --- Access, in the editor -------------------------------------------------
//
// The same ownership and rights the Files listing shows behind its expander,
// brought to where the file is being edited: changing who may read a page
// should not mean leaving it, finding it in a listing and opening a different
// panel. It reuses window.mgRights (SM678) rather than growing a second rights
// editor, and loads on FIRST open only - a section nobody expands costs no
// request.
var edPermsLoaded = false;

function loadEditorPerms() {
  var sec = document.getElementById('ed-perms-section');
  if (!sec || !sec.open) return;
  // CodeMirror measures itself when its pane resizes; opening or closing a
  // section changes the other panes, so both are refreshed either way.
  edRefreshEditors();
  if (edPermsLoaded) return;
  edPermsLoaded = true;

  var body = document.getElementById('ed-perms-body');
  if (!filePath) { body.textContent = 'Save the file first.'; return; }
  var dir = filePath.replace(/\/?[^\/]*$/, '');

  Promise.all([
    fetch(API + '?action=list&path=' + encodeURIComponent(dir || '/')).then(function (r) { return r.json(); }),
    fetch(API + '?action=principals').then(function (r) { return r.json(); })
      .catch(function () { return { ok: false }; })
  ]).then(function (res) {
    var list = res[0], pr = res[1];
    if (!list || !list.ok) { body.textContent = (list && list.error) || 'Could not read this folder.'; return; }
    var me = null, entries = list.entries || [];
    for (var i = 0; i < entries.length; i++) {
      if (entries[i].path === filePath) { me = entries[i]; break; }
    }
    if (!me) { body.textContent = 'This file is not in the listing yet.'; return; }
    edPermsRender(me, (pr && pr.ok && pr) || { users: [], groups: [] });
  }).catch(function (e) { body.textContent = 'Could not load access: ' + e.message; });
}

function edPermsRender(f, pr) {
  var body = document.getElementById('ed-perms-body');
  var names = []
    .concat((pr.users || []).map(function (u) { return typeof u === 'string' ? u : u.name; }))
    .concat((pr.groups || []).map(function (g) { return '@' + (typeof g === 'string' ? g : g.name); }));

  var opts = '<option value="">(no owner)</option>';
  for (var i = 0; i < names.length; i++) {
    opts += '<option value="' + esc(names[i]) + '"' + (f.owner === names[i] ? ' selected' : '') + '>' + esc(names[i]) + '</option>';
  }

  // One chip per principal that has any right on this file.
  var have = {}, chips = '';
  (f.read || []).forEach(function (n) { have[n] = have[n] || {}; have[n].r = 1; });
  (f.write || []).forEach(function (n) { have[n] = have[n] || {}; have[n].w = 1; });
  Object.keys(have).sort().forEach(function (n) {
    chips += (window.mgRights ? mgRights.chip(n, !!have[n].r, !!have[n].w)
                              : '<span class="mg-chip" data-name="' + esc(n) + '">' + esc(n) + '</span>');
  });

  var add = '<option value="">+ add person or @group&hellip;</option>';
  for (var j = 0; j < names.length; j++) {
    if (!have[names[j]]) add += '<option value="' + esc(names[j]) + '">' + esc(names[j]) + '</option>';
  }

  body.innerHTML =
      '<div class="mg-perms-owner"><label>Owner</label>'
    +   '<select class="mg-perm-owner">' + opts + '</select></div>'
    + '<div class="mg-perms-rights-label">People &amp; groups with access</div>'
    + '<div class="mg-rights">' + chips + '</div>'
    + '<div class="mg-rights-add"><select class="mg-rights-pick" onchange="edAddPrincipal(this)">' + add + '</select></div>'
    + '<div class="mg-perms-hint">Toggle <b>r</b> / <b>w</b> per person. Nobody listed = open within the account scope; '
    +   'no owner and nobody listed clears the rule.</div>'
    + '<div class="mg-perms-actions">'
    +   '<a class="mg-perms-history" href="/manager/audit?target=' + encodeURIComponent(filePath) + '">&#128340; Audit</a>'
    +   '<button class="mg-btn mg-btn-primary mg-perms-save" onclick="edSavePerms()">Save access</button>'
    + '</div>';
}

function edAddPrincipal(sel) {
  var name = sel.value;
  if (!name) return;
  sel.value = '';
  var host = document.getElementById('ed-perms-body').querySelector('.mg-rights');
  if (!host) return;
  host.insertAdjacentHTML('beforeend',
    window.mgRights ? mgRights.chip(name, true, false)
                    : '<span class="mg-chip" data-name="' + esc(name) + '">' + esc(name) + '</span>');
  var opt = sel.querySelector('option[value="' + name.replace(/"/g, '') + '"]');
  if (opt) opt.parentNode.removeChild(opt);
}

function edSavePerms() {
  var body = document.getElementById('ed-perms-body');
  var owner = (body.querySelector('.mg-perm-owner') || {}).value || '';
  var read = [], write = [];
  var chips = body.querySelectorAll('.mg-rights .mg-chip');
  for (var i = 0; i < chips.length; i++) {
    var name = chips[i].getAttribute('data-name');
    var on = chips[i].querySelectorAll('.mg-chip-right.on');
    for (var j = 0; j < on.length; j++) {
      if (on[j].getAttribute('data-right') === 'r') read.push(name);
      if (on[j].getAttribute('data-right') === 'w') write.push(name);
    }
  }
  var action = (!owner && !read.length && !write.length) ? 'acl-remove' : 'acl-set';
  var payload = action === 'acl-set' ? { owner: owner, read: read, write: write } : {};
  fetch(API + '?action=' + action + '&path=' + encodeURIComponent(filePath), {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).then(function (r) { return r.json(); }).then(function (d) {
    if (!d || !d.ok) { showStatus((d && d.error) || 'Could not save access', true); return; }
    showStatus(action === 'acl-remove' ? 'Access rule removed.' : 'Access saved.');
  }).catch(function (e) { showStatus('Could not save access: ' + e.message, true); });
}

// Both editors re-measure when a section opens or closes, or CodeMirror keeps
// the height it had when its pane was a different size.
// NARROW IS ONE PANE AT A TIME. Side by side, each pane gets half of a window
// that was already too narrow for one - so the editor and the preview were both
// unusable rather than one being usable. The switch appears only where the
// panes cannot share, and the choice is remembered for the session.
function edPane(which) {
  var root = document.getElementById('editor-root');
  if (!root) return;
  root.setAttribute('data-pane', which);
  try { sessionStorage.setItem('mg-ed-pane', which); } catch (e) {}
  var e = document.getElementById('ed-pane-edit');
  var p = document.getElementById('ed-pane-preview');
  if (e) e.classList.toggle('mg-btn-primary', which === 'edit');
  if (p) p.classList.toggle('mg-btn-primary', which === 'preview');
  edRefreshEditors();
}

(function () {
  var want = 'edit';
  try { want = sessionStorage.getItem('mg-ed-pane') || 'edit'; } catch (e) {}
  document.addEventListener('DOMContentLoaded', function () { edPane(want); });
})();

function edRefreshEditors() {
  setTimeout(function () {
    if (window.yamlCm) yamlCm.refresh();
    if (window.contentCm) contentCm.refresh();
  }, 0);
}

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function buildBreadcrumb(path) {
  var parts = String(path || '').replace(/^\/+/, '').split('/').filter(Boolean);
  var crumbs = ['<a href="/manager/files" class="mg-bc-root" title="Files root">&#128193;</a>'];
  var cumulative = '';
  for (var i = 0; i < parts.length - 1; i++) {
    cumulative += '/' + parts[i];
    crumbs.push('<a href="/manager/files?path=' +
      encodeURIComponent(cumulative) + '">' + esc(parts[i]) + '</a>');
  }
  if (parts.length) {
    crumbs.push('<span>' + esc(parts[parts.length - 1]) + '</span>');
  }
  return crumbs.join(' &rsaquo; ');
}

function hideJsonPreview() {
  var card = document.getElementById('json-render');
  if (card) card.style.display = 'none';
}

function renderJson(content) {
  var card  = document.getElementById('json-render');
  var title = document.getElementById('json-render-title');
  var body  = document.getElementById('json-render-body');
  if (!card || !body) return;

  var parsed;
  try { parsed = JSON.parse(content); }
  catch (e) { hideJsonPreview(); return; }

  title.textContent = 'Preview';
  // textContent (not innerHTML) on the <pre> removes every XSS
  // vector: no user-controlled bytes enter the DOM as markup.
  var pre = document.createElement('pre');
  pre.className = 'mg-json-pre';
  pre.textContent = JSON.stringify(parsed, null, 2);
  body.innerHTML = '';
  body.appendChild(pre);
  card.style.display = '';
}

function renderJsonl(content) {
  var card  = document.getElementById('json-render');
  var title = document.getElementById('json-render-title');
  var body  = document.getElementById('json-render-body');
  if (!card || !body) return;

  var lines = (content || '').split(/\n/);
  var rows = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    if (!line || !line.replace(/\s+/g, '').length) continue;
    try { rows.push(JSON.parse(line)); } catch (e) { /* skip malformed line */ }
  }
  var total = rows.length;
  if (total === 0) { hideJsonPreview(); return; }

  // Performance: cap the rendered table at 100 rows.
  var MAX = 100;
  var truncated = total > MAX;
  if (truncated) rows = rows.slice(0, MAX);

  // Column order: natural form fields first (alphabetical),
  // then leading-underscore internal fields (_submitted last).
  var seen = {};
  var natural = [];
  var meta = [];
  for (var i = 0; i < rows.length; i++) {
    for (var k in rows[i]) {
      if (!Object.prototype.hasOwnProperty.call(rows[i], k)) continue;
      if (seen[k]) continue;
      seen[k] = true;
      if (/^_/.test(k)) { meta.push(k); } else { natural.push(k); }
    }
  }
  natural.sort();
  meta.sort(function(a, b) {
    if (a === '_submitted') return 1;
    if (b === '_submitted') return -1;
    return a.localeCompare(b);
  });
  var columns = natural.concat(meta);

  title.textContent = 'Preview - ' + total + ' submission' + (total === 1 ? '' : 's');

  var html = '<table class="mg-table"><thead><tr>';
  for (var i = 0; i < columns.length; i++) {
    html += '<th>' + esc(columns[i]) + '</th>';
  }
  html += '</tr></thead><tbody>';

  for (var i = 0; i < rows.length; i++) {
    html += '<tr>';
    for (var j = 0; j < columns.length; j++) {
      var val = rows[i][columns[j]];
      // _submitted is an ISO timestamp produced by the form
      // handler; render it in the viewer's locale.
      if (columns[j] === '_submitted' && val) {
        var d = new Date(val);
        if (!isNaN(d.getTime())) val = d.toLocaleString();
      }
      if (val === undefined || val === null) {
        val = '';
      } else if (typeof val === 'object') {
        // Nested structures: serialise so we don't emit [object Object]
        try { val = JSON.stringify(val); } catch (e) { val = String(val); }
      } else {
        val = String(val);
      }
      html += '<td>' + esc(val) + '</td>';
    }
    html += '</tr>';
  }
  html += '</tbody></table>';

  if (truncated) {
    html += '<p class="mg-jsonl-more">Showing ' + MAX
         +  ' of ' + total + ' submissions.</p>';
  }

  body.innerHTML = html;
  card.style.display = '';
}

// Dispatcher: pick a renderer based on the path extension,
// or hide the preview for anything else.
function updateJsonPreview(content) {
  if (!filePath) { hideJsonPreview(); return; }
  var ext = filePath.split('.').pop().toLowerCase();
  if      (ext === 'json')  renderJson(content);
  else if (ext === 'jsonl') renderJsonl(content);
  else                      hideJsonPreview();
}

// SM019: binary-file landing page. Replaces the editor + preview
// pane (#ed-main) with a download card and hides the toolbar /
// statusbar so the user sees only the Download action. #editor-root
// is left intact so view.tt page chrome still renders.
function renderBinaryPanel(path) {
  var main = document.getElementById('ed-main');
  if (main) {
    main.innerHTML =
      '<div class="mg-card">' +
        '<div class="mg-card-header">Binary file</div>' +
        '<div class="mg-card-body">' +
          '<p>This file cannot be edited in the browser. ' +
             'Download it to edit locally.</p>' +
          '<a class="mg-btn mg-btn-primary" href="' + API +
             '?action=file-download&path=' + encodeURIComponent(path) +
             '" download>Download</a>' +
        '</div>' +
      '</div>';
  }
  var toolbar = document.querySelector('.mg-editor-toolbar');
  if (toolbar) toolbar.style.display = 'none';
  var statusbar = document.querySelector('.mg-editor-statusbar');
  if (statusbar) statusbar.style.display = 'none';
}

function loadContent() {
  fetch(API + '?action=read&path=' + encodeURIComponent(filePath))
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.binary) {
        renderBinaryPanel(filePath);
        return;
      }
      if (!data.ok) {
        document.getElementById('ed-saved').textContent = data.error || 'Load failed';
        return;
      }
      fileMtime = data.mtime;
      if (isMdFile) {
        var parts = parseFrontMatter(data.content);
        populateFmFields(parts.yaml);
        contentCm.setValue(parts.body);
      } else {
        contentCm.setValue(data.content);
      }
      if (readOnly) {
        contentCm.setOption('readOnly', true);
      }
      isDirty = false;
      editorReady = true;   // SM170: real edits from here on mark dirty
      updateStatus();
      updateJsonPreview(data.content);
      if (isMdFile) setTimeout(refreshPreview, 500);
    });
}

// --- Save ---
function savePage() {
  var content = isMdFile ? buildContent() : contentCm.getValue();
  document.getElementById('ed-save-btn').disabled = true;
  document.getElementById('ed-dirty').textContent = 'Saving...';

  fetch(API + '?action=save&path=' + encodeURIComponent(filePath), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: content, mtime: fileMtime })
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    if (data.ok) {
      if (typeof mgClearWarning === 'function') mgClearWarning();
      fileMtime = data.mtime;
      clearDirty();
      if (isMdFile) refreshPreview();
      // Re-render the JSON/JSONL preview with the content that
      // was just saved, not what was on disk at load time.
      updateJsonPreview(contentCm.getValue());
    } else if (data.conflict) {
      if (typeof mgShowWarning === 'function') mgShowWarning('Conflict: modified externally', true);
      document.getElementById('ed-dirty').textContent = 'Conflict: modified externally';
      document.getElementById('ed-save-btn').disabled = false;
    } else {
      if (typeof mgShowWarning === 'function') mgShowWarning(data.error || 'Save failed', true);
      document.getElementById('ed-dirty').textContent = data.error || 'Save failed';
      document.getElementById('ed-save-btn').disabled = false;
    }
  })
  .catch(function(e) {
    if (typeof mgShowWarning === 'function') mgShowWarning('Save failed: ' + e.message, true);
    document.getElementById('ed-save-btn').disabled = false;
  });
}

// --- Preview ---
function isRawOrApi() {
  var yaml = buildYaml();
  return /^api\s*:\s*true/mi.test(yaml) || /^raw\s*:\s*true/mi.test(yaml);
}

function refreshPreview() {
  if (!isMdFile) return;
  var url = filePath.replace(/\.md$/, '').replace(/\/index$/, '/');
  if (url.charAt(0) !== '/') url = '/' + url;
  url += '?_t=' + Date.now();
  var frame = document.getElementById('ed-preview-frame');
  document.getElementById('ed-preview-status').textContent = 'Loading...';

  if (isRawOrApi()) {
    // Fetch as text and display with highlighting
    fetch(url)
      .then(function(r) { return r.text(); })
      .then(function(text) {
        // Strip CGI headers if present
        text = text.replace(/^(Status:.*\n)?(Content-type:.*\n)?(Cache-Control:.*\n)*\n?/i, '');
        var escaped = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        var isJson = /^\s*[\[{]/.test(text);
        if (isJson) {
          try { escaped = JSON.stringify(JSON.parse(text), null, 2)
                  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); } catch(e) {}
        }
        frame.srcdoc = '<html><body style="margin:0;padding:12px;font:13px/1.5 ui-monospace,monospace;background:var(--mg-surface);color:var(--mg-text);white-space:pre-wrap;word-break:break-all;">' + escaped + '</body></html>';
        document.getElementById('ed-preview-status').textContent = 'Raw output';
      })
      .catch(function() {
        document.getElementById('ed-preview-status').textContent = 'Preview failed';
      });
    return;
  }

  // Normal HTML preview in iframe
  frame.onload = function() { document.getElementById('ed-preview-status').textContent = ''; };
  frame.removeAttribute('srcdoc');
  frame.src = url;
}

// --- Divider ---
(function() {
  var div = document.getElementById('ed-divider');
  var main = document.getElementById('ed-main');
  var pane = document.getElementById('ed-editor-pane');
  var dragging = false;
  div.addEventListener('mousedown', function() {
    dragging = true;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    var rect = main.getBoundingClientRect();
    var pct = ((e.clientX - rect.left) / rect.width) * 100;
    pane.style.width = Math.max(20, Math.min(80, pct)) + '%';
  });
  document.addEventListener('mouseup', function() {
    dragging = false;
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  });
})();

// --- Metadata / Content vertical splitter ---
// Drag to resize the Metadata (YAML) editor against the Content editor, so a
// YAML-heavy page can make Metadata the main surface and a prose page can shrink
// it. CodeMirror needs a refresh after its container resizes.
(function() {
  var vs   = document.getElementById('ed-vsplit');
  var pane = document.getElementById('ed-editor-pane');
  var meta = document.getElementById('ed-meta-section');
  if (!vs || !pane || !meta) return;
  var dragging = false;
  vs.addEventListener('mousedown', function() {
    dragging = true;
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    var top  = meta.getBoundingClientRect().top;
    var rect = pane.getBoundingClientRect();
    var px = Math.max(40, Math.min(rect.bottom - top - 80, e.clientY - top));
    meta.style.flex = '0 0 ' + px + 'px';
    if (yamlCm && yamlCm.refresh) yamlCm.refresh();
    if (contentCm && contentCm.refresh) contentCm.refresh();
  });
  document.addEventListener('mouseup', function() {
    dragging = false;
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  });
})();

// --- Unload ---
// The unsaved-changes warning comes from the shared mgDirtyGuard in the manager
// layout (markDirty/clearDirty above register with it). Lock release lives on
// pagehide, which fires only when the page REALLY goes away: cancelling the
// leave prompt keeps the lock and the renew timer, confirming the leave
// releases the lock as before. (Previously the release beacon fired from the
// same handler as the prompt, so a cancelled leave silently lost the lock.)
window.addEventListener('pagehide', function() {
  if (lockRenewTimer) clearInterval(lockRenewTimer);
  if (filePath && !isNew) {
    // sendBeacon bypasses the window.fetch CSRF wrapper, so include the
    // token in the URL. window.LAZYSITE_CSRF is populated by view.tt.
    var url = API + '?action=unlock&path=' + encodeURIComponent(filePath);
    if (window.LAZYSITE_CSRF) url += '&csrf_token=' + encodeURIComponent(window.LAZYSITE_CSRF);
    navigator.sendBeacon(url);
  }
});

// --- Keyboard shortcut (global) ---
document.addEventListener('keydown', function(e) {
  if ((e.ctrlKey || e.metaKey) && e.key === 's') {
    e.preventDefault();
    if (!readOnly) savePage();
  }
});

// --- Boot ---
// Esc returns to Files (the sidebar is hidden behind the full-screen editor),
// but only when there is nothing unsaved - a dirty editor stays put.
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape' && !isDirty) { location.href = backUrl; }
});

loadFile();
</script>
