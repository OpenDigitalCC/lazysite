---
title: Appearance
auth: manager
search: false
query_params:
  - action
  - theme
---

<div id="status" class="mg-status"></div>

<!-- WHAT YOU HAVE, THEN WHERE MORE COMES FROM. The catalogue and the repo
     setting used to sit above this: the page opened on a list of things the
     operator could download, and the thing they came to change - which layout
     and theme this site is using - was below it, off the bottom on a laptop.
     Ordered by how often each is wanted. -->
<div class="mg-card">
<div class="mg-card-header"><span class="mg-card-title">Installed layouts &amp; themes</span>
<button id="lzs-stop-preview" class="mg-btn mg-btn-sm" onclick="clearPreview()" style="display:none">Stop preview</button></div>
<div class="mg-card-body">
<p class="mg-card-subtitle" style="margin:0 0 8px 0;">The layout is the page structure; the theme is its colours and fonts. Activating one sets the site default for all visitors and clears the page cache. This is the single place to switch layout or theme.</p>
<div id="installed">
<div class="mg-row"><span class="mg-file-name">Loading...</span></div>
</div>
</div>
</div>

<div class="mg-card">
<div class="mg-card-header">
<span class="mg-card-title">Browse the repo</span>
<button class="mg-btn mg-btn-sm" onclick="loadCatalogue()">Refresh</button>
</div>
<div class="mg-card-body">
<p class="mg-card-subtitle" style="margin:0 0 8px 0;">Layouts available in the repo. Installing a layout pulls its default theme; expand to install other themes.</p>
<div id="catalogue"><span class="mg-empty">Click Refresh to load the catalogue.</span></div>
</div>
</div>

<div class="mg-card">
<div class="mg-card-header"><span class="mg-card-title">Upload a theme</span></div>
<div class="mg-card-body">
<p class="mg-card-subtitle" style="margin:0 0 8px 0;">A .zip with <code>theme.json</code> at its root and an <code>assets/</code> subtree. Installs under the active layout. (Layouts install from the catalogue.)</p>
<!-- .mg-line, which wraps. A file input is unusually wide and does not
     shrink, so this row as a nowrap flex put Upload 44px off the side of a
     420px screen with nothing to scroll to it. -->
<div class="mg-line">
<input type="file" id="theme-file" accept=".zip">
<button class="mg-btn" onclick="uploadTheme()">Upload</button>
</div>
</div>
</div>

<div class="mg-card">
<div class="mg-card-header"><span class="mg-card-title">Layouts repo</span></div>
<div class="mg-card-body">
<p class="mg-card-subtitle" style="margin:0 0 8px 0;">Where layouts and themes are downloaded from. Leave the default, or point at your own fork. See the <a href="/docs/features/configuration/remote-layouts">docs</a>.</p>
<!-- A .mg-field stacks label above control, so four loose children made a
     column and Save rendered 560px wide, the width of the field. The control
     here is an input WITH a button: .mg-line is the row idiom for that. -->
<div class="mg-field" style="margin:0;">
<label for="layouts-repo-input">Repo</label>
<div class="mg-line">
<input type="text" id="layouts-repo-input" class="mg-inp" placeholder="OpenDigitalCC/lazysite-layouts" oninput="markRepoDirty()">
<button class="mg-btn mg-btn-primary mg-btn-sm" onclick="saveLayoutsRepo()">Save</button>
<span id="repo-dirty" class="mg-note mg-note-info" style="display:none">&#9679; Unsaved changes &mdash; click Save</span>
</div>
</div>
</div>
</div>

<script>
var API = '/cgi-bin/lazysite-manager-api.pl';
var ACTIVE_LAYOUT = '';
var ACTIVE_THEME  = '';

function showStatus(msg, isError) {
  var el = document.getElementById('status');
  if (isError) {
    if (typeof mgShowWarning === 'function') mgShowWarning(msg, true);
    if (el) { el.textContent = ''; el.className = 'mg-status'; }
    return;
  }
  if (typeof mgClearWarning === 'function') mgClearWarning();
  if (!el) return;
  if (!msg) { el.textContent = ''; el.className = 'mg-status'; return; }
  el.className = 'mg-status mg-status-success';
  el.textContent = msg;
  setTimeout(function() { showStatus(''); }, 3000);
}

function escHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// --- Load everything: active state, installed layouts, grouped themes ---
function loadAll() {
  showStatus('');
  Promise.all([
    fetch(API + '?action=themes-list-all').then(function(r){ return r.json(); }),
    fetch(API + '?action=layouts-available').then(function(r){ return r.json(); })
  ]).then(function(res) {
    var ta = res[0] || {}, la = res[1] || {};
    ACTIVE_LAYOUT = ta.active_layout || '';
    ACTIVE_THEME  = ta.active || '';
    var themes  = ta.themes || [];                 // [{name, layout, used_by}]
    var layouts = (la.layouts || []).slice();      // [name]
    LAYOUT_USED = la.layout_usage || {};           // SM234: layout -> [hosts]

    // Group themes by layout; union layout names so empty layouts show too.
    // SM234: keep each theme's domain usage, keyed layout+theme, so a theme a
    // sub-domain pins can be marked in use rather than offered for deletion.
    var byLayout = {};
    THEME_USED = {};
    for (var i = 0; i < themes.length; i++) {
      (byLayout[themes[i].layout] = byLayout[themes[i].layout] || []).push(themes[i].name);
      THEME_USED[themes[i].layout + ' ' + themes[i].name] = themes[i].used_by || [];
    }
    for (var k in byLayout) { if (layouts.indexOf(k) < 0) layouts.push(k); }
    layouts.sort();

    renderInstalled(layouts, byLayout);
  }).catch(function(e) { showStatus('Failed to load: ' + e.message, true); });
}

// SM234: domain usage, captured at load. "active" means the site-wide default;
// a theme or layout a registered sub-domain pins is a DIFFERENT state - equally
// undeletable, and previously indistinguishable from a free one, so the operator
// pressed Delete and learned it was protected from the error that came back.
var LAYOUT_USED = {};   // layout -> [hosts]
var THEME_USED  = {};   // "layout theme" -> [hosts]

// The blockers, named ONCE. Field feedback on the first cut: the badge and a
// trailing meta line both said "in use by <hosts>", the long host list could not
// wrap (mg-file-meta is nowrap) so it ran off the panel, and the badge sat inside
// mg-handler-group-label, which is text-transform:uppercase - so domain names
// were SHOUTED at full length. One short badge carries it now, the full list is
// on hover, and the actions area says only why the button is absent.
function usedBadge(hosts) {
  if (!hosts || !hosts.length) return '';
  var title = hosts.join(', ');
  var text  = hosts.length === 1 ? 'in use: ' + hosts[0]
                                 : 'in use by ' + hosts.length + ' domains';
  // text-transform is reset inline: this badge is rendered inside an uppercase
  // label and a domain name in caps is both ugly and harder to read.
  return ' <span class="mg-tag" style="text-transform:none;letter-spacing:0"'
    + ' title="' + escHtml(title) + '">' + escHtml(text) + '</span>';
}

// --- Installed layouts & themes (the single switch + management control) ---
function renderInstalled(layouts, byLayout) {
  var box = document.getElementById('installed');
  if (!layouts.length) {
    box.innerHTML = '<div class="mg-row"><span class="mg-file-name mg-empty">'
      + 'No layouts installed - install one from the catalogue above.</span></div>';
    return;
  }
  // Active layout first.
  layouts = layouts.slice().sort();
  if (ACTIVE_LAYOUT && layouts.indexOf(ACTIVE_LAYOUT) >= 0) {
    layouts = [ACTIVE_LAYOUT].concat(layouts.filter(function(l){ return l !== ACTIVE_LAYOUT; }));
  }
  var html = '';
  var allBackups = [];   // {layout, name, path} - collapsed into one panel below
  for (var g = 0; g < layouts.length; g++) {
    var L = layouts[g], isActiveL = (L === ACTIVE_LAYOUT);
    html += '<div class="mg-handler-group" style="margin:0.5rem;">';
    html += '<div class="mg-handler-group-header">';
    html += '<span class="mg-handler-group-label">' + escHtml(L);
    if (isActiveL) html += ' <span class="mg-tag mg-tag-on">active</span>';
    var lUsed = (LAYOUT_USED[L] || []).filter(function(h){ return h !== '(default)'; });
    if (!isActiveL) html += usedBadge(lUsed);
    html += '</span><div class="mg-handler-item-actions">';
    if (isActiveL) {
      html += '<span class="mg-file-meta">active - cannot delete</span>';
    } else if (lUsed.length) {
      html += '<button class="mg-btn mg-btn-change mg-btn-sm mg-btn-change" onclick="activateLayout(\'' + escHtml(L) + '\')">Activate</button>';
      html += '<span class="mg-file-meta">cannot delete</span>';
    } else {
      html += '<button class="mg-btn mg-btn-change mg-btn-sm mg-btn-change" onclick="activateLayout(\'' + escHtml(L) + '\')">Activate</button>';
      var tc = ((byLayout[L] || []).length);
      html += '<button class="mg-btn mg-btn-sm mg-btn-danger" onclick="deleteLayout(\'' + escHtml(L) + '\',' + tc + ')">Delete</button>';
    }
    html += '</div></div>';

    var allThemes = (byLayout[L] || []).slice().sort();
    var themes = [];
    for (var bi = 0; bi < allThemes.length; bi++) {
      if (isBackupName(allThemes[bi])) {
        allBackups.push({ layout: L, name: allThemes[bi],
          path: 'lazysite/layouts/' + L + '/themes/' + allThemes[bi] });
      } else {
        themes.push(allThemes[bi]);
      }
    }
    if (!themes.length) {
      html += '<div class="mg-handler-item"><span class="mg-empty">No themes for this layout.</span></div>';
    }
    for (var i = 0; i < themes.length; i++) {
      var t = themes[i], isActiveT = (isActiveL && t === ACTIVE_THEME);
      html += '<div class="mg-handler-item"><div class="mg-handler-item-header">';
      html += '<span class="mg-handler-name">' + escHtml(t) + '</span>';
      if (isActiveT) html += '<span class="mg-tag mg-tag-on">active</span>';
      var tUsed = (THEME_USED[L + ' ' + t] || []).filter(function(h){ return h !== '(default)'; });
      if (!isActiveT) html += usedBadge(tUsed);
      html += '<span style="flex:1;"></span><div class="mg-handler-item-actions">';
      if (!isActiveT) {
        html += '<button class="mg-btn mg-btn-sm" onclick="previewTheme(\'' + escHtml(t) + '\',\'' + escHtml(L) + '\')">Preview</button>';
      }
      if (isActiveL) {
        if (isActiveT) {
          html += '<button class="mg-btn mg-btn-sm" onclick="deactivateTheme()">Deactivate</button>';
        } else {
          html += '<button class="mg-btn mg-btn-change mg-btn-sm mg-btn-change" onclick="activateThemeOnly(\'' + escHtml(t) + '\')">Activate</button>';
          if (tUsed.length) {
            html += '<span class="mg-file-meta">cannot delete</span>';
          } else {
            html += '<button class="mg-btn mg-btn-sm mg-btn-danger" onclick="deleteTheme(\'' + escHtml(t) + '\')">Delete</button>';
          }
        }
      }
      html += '</div></div></div>';
    }
    html += '</div>';
  }
  html += renderBackupsPanel(allBackups);
  box.innerHTML = html;
}

function isBackupName(n) { return /-backup-\d{8}T\d{6}Z/.test(n); }

// All old theme/layout snapshots folded into ONE collapsed panel: a count, a
// batch "delete all", and per-item delete. Keeps the installed list clean.
function renderBackupsPanel(backups) {
  if (!backups.length) return '';
  // Newest first: the name carries a sortable -backup-YYYYMMDDTHHMMSSZ stamp.
  var stamp = function(b) { var m = /-backup-(\d{8}T\d{6}Z)/.exec(b.name); return m ? m[1] : ''; };
  backups = backups.slice().sort(function(a, b) { return stamp(b).localeCompare(stamp(a)); });
  var h = '<details class="mg-handler-group" style="margin:0.5rem;">';
  h += '<summary style="cursor:pointer;padding:0.5rem;font-weight:600;">'
     + 'Backups (' + backups.length + ') – old theme/layout snapshots</summary>';
  h += '<div style="padding:0.3rem 0.6rem;">';
  h += '<div style="font-size:0.8rem;color:var(--mg-text-muted);margin:0 0 0.4rem;">Snapshots kept when a '
     + 'layout or theme is switched or deleted. Safe to remove; the active layout is never touched.</div>';
  h += '<button class="mg-btn mg-btn-sm mg-btn-danger" onclick="purgeAllBackups()">Delete all backups</button>';
  for (var i = 0; i < backups.length; i++) {
    var b = backups[i];
    h += '<div class="mg-handler-item"><div class="mg-handler-item-header">';
    h += '<span class="mg-handler-name">' + escHtml(b.layout) + ' / ' + escHtml(b.name) + '</span>';
    h += '<span style="flex:1;"></span><div class="mg-handler-item-actions">';
    h += '<button class="mg-btn mg-btn-sm mg-btn-danger" onclick="deleteBackup(\'' + escHtml(b.path) + '\')">Delete</button>';
    h += '</div></div></div>';
  }
  h += '</div></details>';
  return h;
}

function deleteBackup(path) {
  fetch(API + '?action=artifact-backups-delete&path=' + encodeURIComponent(path), { method: 'POST' })
    .then(function(r){ return r.json(); })
    .then(function(d){
      if (d.ok) { showStatus('Backup deleted.'); loadAll(); }
      else { showStatus(d.error || 'Delete failed.', true); }
    });
}

function purgeAllBackups() {
  mgConfirm('Delete ALL layout/theme backups? This removes every snapshot on disk '
    + '(the active layout and theme are never touched).', { ok: 'Delete all' }).then(function(ok) {
    if (!ok) return;
    fetch(API + '?action=artifact-backups-delete', { method: 'POST' })
      .then(function(r){ return r.json(); })
      .then(function(d){
        if (d.ok) { showStatus('Removed ' + d.deleted + ' backup(s).'); loadAll(); }
        else { showStatus(d.error || 'Delete failed.', true); }
      });
  });
}

function activateLayout(name) {
  mgConfirm('Activate layout "' + name + '"? Its default theme is used; cached pages clear.',
    { ok: 'Activate' }).then(function(ok) {
    if (!ok) return;
    fetch(API + '?action=layout-activate&path=' + encodeURIComponent(name), { method: 'POST' })
      .then(function(r){ return r.json(); }).then(function(d) {
        if (!d.ok) { showStatus(d.error, true); return; }
        showStatus('Layout "' + name + '" activated.'); loadAll();
      }).catch(function(e){ showStatus('Error: ' + e.message, true); });
  });
}

function deleteLayout(name, themeCount) {
  var extra = themeCount > 0
    ? ' This also deletes its ' + themeCount + ' theme' + (themeCount === 1 ? '' : 's') + '.'
    : '';
  mgConfirm('Delete layout "' + name + '"?' + extra + ' A backup is kept. This cannot be undone from the UI.',
    { danger: true, ok: 'Delete' }).then(function(ok) {
    if (!ok) return;
    fetch(API + '?action=layout-delete&path=' + encodeURIComponent(name), { method: 'POST' })
      .then(function(r){ return r.json(); }).then(function(d) {
        if (!d.ok) { showStatus(d.error, true); return; }
        var n = (d.themes_removed || []).length;
        showStatus('Deleted layout "' + name + '"'
          + (n ? ' and ' + n + ' theme' + (n === 1 ? '' : 's') : '') + '.');
        loadAll();
      }).catch(function(e){ showStatus('Error: ' + e.message, true); });
  });
}

function activateThemeOnly(name) {
  fetch(API + '?action=theme-activate&path=' + encodeURIComponent(name), { method: 'POST' })
    .then(function(r){ return r.json(); }).then(function(d) {
      if (!d.ok) { showStatus(d.error, true); return; }
      showStatus('Theme "' + name + '" activated.'); loadAll();
    }).catch(function(e){ showStatus('Error: ' + e.message, true); });
}

function deactivateTheme() {
  mgConfirm('Deactivate theme and use the built-in fallback?', { ok: 'Deactivate' }).then(function(ok) {
    if (!ok) return;
    // SM247: deactivation is now explicit - an empty path alone is an error,
    // because it is what a mistyped parameter looks like.
    fetch(API + '?action=theme-activate&path=&deactivate=1', { method: 'POST' })
      .then(function(r){ return r.json(); }).then(function(d) {
        if (!d.ok) { showStatus(d.error, true); return; }
        showStatus('Theme deactivated.'); loadAll();
      }).catch(function(e){ showStatus('Error: ' + e.message, true); });
  });
}

function deleteTheme(name) {
  mgConfirm('Delete theme "' + name + '"? This cannot be undone.', { danger: true, ok: 'Delete' }).then(function(ok) {
    if (!ok) return;
    fetch(API + '?action=theme-delete&path=' + encodeURIComponent(name), { method: 'POST' })
      .then(function(r){ return r.json(); }).then(function(d) {
        if (!d.ok) { showStatus(d.error, true); return; }
        showStatus('Theme deleted.'); loadAll();
      }).catch(function(e){ showStatus('Error: ' + e.message, true); });
  });
}

function previewTheme(name, layout) {
  fetch(API + '?action=preview-grant&layout=' + encodeURIComponent(layout)
            + '&theme=' + encodeURIComponent(name), { method: 'POST' })
    .then(function(r){ return r.json(); }).then(function(d) {
      if (!d.ok) { showStatus(d.error, true); return; }
      showStatus('Previewing "' + name + '" - opening the site in a new tab.');
      syncStopPreview(); window.open('/', '_blank');
    }).catch(function(e){ showStatus('Error: ' + e.message, true); });
}

function clearPreview() {
  fetch(API + '?action=preview-clear', { method: 'POST' })
    .then(function(r){ return r.json(); }).then(function(d) {
      if (!d.ok) { showStatus(d.error, true); return; }
      showStatus('Preview cleared.'); syncStopPreview();
    }).catch(function(e){ showStatus('Error: ' + e.message, true); });
}

function syncStopPreview() {
  var on = /(?:^|;\s*)lzs_preview_active=1(?:;|$)/.test(document.cookie);
  var btn = document.getElementById('lzs-stop-preview');
  if (btn) btn.style.display = on ? '' : 'none';
}

// --- Upload a theme ---
function uploadTheme() {
  var fi = document.getElementById('theme-file');
  if (!fi.files.length) { showStatus('Select a .zip file first.', true); return; }
  var file = fi.files[0];
  if (!/\.zip$/i.test(file.name)) { showStatus('File must be a .zip archive.', true); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    fetch(API + '?action=theme-upload&filename=' + encodeURIComponent(file.name),
      { method: 'POST', body: e.target.result })
      .then(function(r){ return r.json(); }).then(function(d) {
        if (!d.ok) { showStatus(d.error, true); return; }
        showStatus('Theme uploaded: ' + (d.name || file.name));
        fi.value = ''; loadAll();
      }).catch(function(err){ showStatus('Upload failed: ' + err.message, true); });
  };
  reader.readAsArrayBuffer(file);
}

// --- Layouts repo setting ---
function loadLayoutsRepo() {
  fetch(API + '?action=layouts-repo-get').then(function(r){ return r.json(); })
    .then(function(d) {
      var input = document.getElementById('layouts-repo-input');
      if (input && d && d.ok && d.value) input.value = d.value;
    }).catch(function(){});
}

// SM118 pattern (field report): the repo field is this page's one explicit-save
// control, so flag unsaved edits via the shared mgDirtyGuard (manager layout).
// loadLayoutsRepo() populates it programmatically, which doesn't fire oninput.
function markRepoDirty()  { mgDirtyGuard.set('layouts-repo', 'repo-dirty'); }
function clearRepoDirty() { mgDirtyGuard.clear('layouts-repo'); }

function saveLayoutsRepo() {
  var input = document.getElementById('layouts-repo-input');
  if (!input) return;
  var value = (input.value || '').trim();
  fetch(API + '?action=layouts-repo-set', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ value: value })
  }).then(function(r){ return r.json(); }).then(function(d) {
    if (!d.ok) { showStatus(d.error || 'Save failed.', true); return; }
    clearRepoDirty();
    showStatus(value ? ('Layouts repo saved: ' + value) : 'Layouts repo cleared.');
  }).catch(function(e){ showStatus('Error: ' + e.message, true); });
}

// --- Browse the repo catalogue (manifest) ---
function loadCatalogue() {
  var box = document.getElementById('catalogue');
  box.innerHTML = '<span class="mg-empty">Loading catalogue...</span>';
  fetch(API + '?action=layouts-manifest').then(function(r){ return r.json(); })
    .then(function(d) {
      if (!d.ok) { box.innerHTML = ''; showStatus(d.error || 'Could not load catalogue.', true); return; }
      renderCatalogue(d.layouts || []);
    }).catch(function(e){ box.innerHTML = ''; showStatus('Error: ' + e.message, true); });
}

function renderCatalogue(layouts) {
  var box = document.getElementById('catalogue');
  if (!layouts.length) { box.innerHTML = '<span class="mg-empty">No layouts in the repo manifest.</span>'; return; }
  var html = '';
  for (var i = 0; i < layouts.length; i++) {
    var L = layouts[i];
    var cid = 'cat-' + L.name.replace(/[^A-Za-z0-9_-]/g, '_');
    html += '<div class="mg-row">';
    html += '<span class="mg-file-name">' + escHtml(L.name) + '</span>';
    if (L.version) html += '<span class="mg-tag">' + escHtml(L.version) + '</span>';
    if (L.installed) html += '<span class="mg-tag mg-tag-on">installed</span>';
    html += '<div class="mg-file-actions">';
    html += '<button class="mg-btn mg-btn-sm" onclick="toggleCat(\'' + cid + '\')">Themes</button>';
    if (L.installed) {
      html += '<button class="mg-btn mg-btn-change mg-btn-sm" onclick="installLayout(\'' + escHtml(L.name) + '\',\'\',true)">Update</button>';
    } else {
      html += '<button class="mg-btn mg-btn-change mg-btn-sm mg-btn-change" onclick="installLayout(\'' + escHtml(L.name) + '\',\'\')">Install</button>';
    }
    html += '</div></div>';
    // Per-theme rows (install a specific theme into the layout).
    html += '<div id="' + cid + '" hidden style="margin:0 0 0.5rem 1rem;">';
    var ths = L.themes || [];
    for (var j = 0; j < ths.length; j++) {
      var t = ths[j];
      html += '<div class="mg-row"><span class="mg-file-name">' + escHtml(t.name) + '</span>';
      if (t.name === L.default_theme) html += '<span class="mg-file-meta">default</span>';
      html += '<div class="mg-file-actions">';
      if (t.installed) {
        html += '<span class="mg-tag mg-tag-on">installed</span>';
      } else {
        html += '<button class="mg-btn mg-btn-change mg-btn-sm" onclick="installLayout(\''
          + escHtml(L.name) + '\',\'' + escHtml(t.name) + '\')">Install</button>';
      }
      html += '</div></div>';
    }
    html += '</div>';
  }
  box.innerHTML = html;
}

function toggleCat(id) { var el = document.getElementById(id); if (el) el.hidden = !el.hidden; }

function installLayout(layout, theme, update) {
  var label = 'layout "' + layout + '"' + (theme ? ' / theme "' + theme + '"' : ' (default theme)');
  var verb = update ? 'Update' : 'Install';
  mgConfirm(verb + ' ' + label + '? It will be installed but not activated - use its Activate button when you want to switch to it.', { ok: verb }).then(function(ok) {
    if (!ok) return;
    showStatus(verb + 'ing ' + label + '...');
    fetch(API + '?action=layout-install', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ layout: layout, theme: theme, update: update ? true : false })
    }).then(function(r){ return r.json(); }).then(function(d) {
      if (!d.ok) { showStatus(d.error || 'Install failed.', true); return; }
      var n = (d.themes_installed || []).length;
      var msg = 'Installed ' + layout + ' with ' + n + ' theme' + (n === 1 ? '' : 's');
      if (d.theme_errors && d.theme_errors.length) {
        showStatus(msg + ' - ' + d.theme_errors.join('; '), true);
      } else {
        showStatus(msg + (d.activated ? ' and activated.' : ' - use Activate to switch to it.'));
      }
      loadAll(); loadCatalogue();
    }).catch(function(e){ showStatus('Install failed: ' + e.message, true); });
  });
}

loadAll();
loadLayoutsRepo();
syncStopPreview();
</script>
