#!/usr/bin/perl
# audit.pl - link audit for lazysite docroots
# Reports orphaned pages (exist but not linked) and broken links
#
# Usage: perl plugins/audit.pl [options] [docroot]
#
# Options:
#   --exclude path,path,...   comma-separated canonical paths to exclude
#   --exclude-file FILE       file containing one exclusion per line
#   --scan                    write Markdown report and output JSON
#   --describe                print plugin descriptor JSON and exit
#   --docroot PATH            set docroot explicitly

use strict;
use warnings;
use File::Find;
use File::Basename qw(dirname basename);
use POSIX          qw(strftime);
use File::Path     qw(make_path);
use Cwd            qw(abs_path);

my $LOG_COMPONENT = 'audit';

# --- Image and asset extensions to ignore as link targets ---

my %IGNORE_EXT = map { $_ => 1 } qw(
    svg png jpg jpeg gif webp ico bmp tiff
    pdf zip tar gz bz2 xz
    css js woff woff2 ttf eot
    mp4 mp3 ogg webm
);

# --- Parse arguments ---

my %exclude;
my $DOCROOT;
my $SCAN_MODE = 0;

while (@ARGV) {
    my $arg = shift @ARGV;
    if ( $arg eq '--describe' ) {
        print_describe();
        exit 0;
    }
    elsif ( $arg eq '--scan' ) {
        $SCAN_MODE = 1;
    }
    elsif ( $arg eq '--docroot' ) {
        $DOCROOT = shift @ARGV;
    }
    elsif ( $arg eq '--exclude' ) {
        my $list = shift @ARGV or die "Missing value for --exclude\n";
        $exclude{$_} = 1 for split /,/, $list;
    }
    elsif ( $arg eq '--exclude-file' ) {
        my $file = shift @ARGV          or die "Missing value for --exclude-file\n";
        open( my $fh, '<:utf8', $file ) or die "Cannot read $file: $!\n";            # L-6
        while (<$fh>) {
            chomp;
            s/^\s+|\s+$//g;
            $exclude{$_} = 1 if length;
        }
        close $fh;
    }
    else {
        $DOCROOT = $arg unless $DOCROOT;
    }
}

$DOCROOT = abs_path( $DOCROOT || '.' );
die "Docroot not found: $DOCROOT\n" unless -d $DOCROOT;
# SM540: the forwarding conf peek looks under DOCUMENT_ROOT; --docroot is it.
$ENV{DOCUMENT_ROOT} //= $DOCROOT;

# Always exclude these from orphan report
$exclude{'404'} = 1;
$exclude{''}    = 1;

# --- Main ---

log_event( 'INFO', $DOCROOT, 'audit started' );

my $results = collect_audit_results();

log_event( 'INFO', $DOCROOT, 'audit complete', pages => scalar keys %{ $results->{pages} } );

if ($SCAN_MODE) {
    run_scan($results);
}
else {
    print_report($results);
}

# --- Collect results ---

sub collect_audit_results {
    my %pages;
    my %sources;
    my %inbound;
    my %outbound;

    find( sub {
            return unless -f;
            return unless /\.(md|url)$/;
            my $rel = _rel_of($File::Find::name);
            return if $rel =~ m{^lazysite/};
            return if $rel =~ m{(^|/)\.};
            my $canon = canonical($rel);
            $pages{$canon}   = 1;
            $sources{$canon} = $rel;
            # .url files are themselves reachable entry points
            push @{ $inbound{$canon} }, 'url-entrypoint' if /\.url$/;
    }, $DOCROOT );

    find( sub {
            return unless -f && /\.md$/;
            my $rel = _rel_of($File::Find::name);
            return if $rel =~ m{^lazysite/};
            return if $rel =~ m{(^|/)\.};
            extract_links( $File::Find::name, $rel, \%inbound, \%outbound );
            extract_scan_refs( $File::Find::name, $rel, \%inbound );
    }, $DOCROOT );

    find( sub {
            return unless -f && /\.url$/;
            my $rel = _rel_of($File::Find::name);
            return if $rel =~ m{(^|/)\.};
            ( my $html_path = $File::Find::name ) =~ s/\.url$/.html/;
            if ( -f $html_path ) {
                extract_links( $html_path, $rel, \%inbound, \%outbound );
            }
    }, $DOCROOT );

    if ( -d "$DOCROOT/lazysite/templates" ) {
        find( sub {
                return unless -f && /\.tt$/;
                my $rel = _rel_of($File::Find::name);
                return if $rel =~ m{(^|/)\.};
                extract_links( $File::Find::name, $rel, \%inbound, \%outbound );
        }, "$DOCROOT/lazysite/templates" );
    }

    my @orphans;
    for my $canon ( sort keys %pages ) {
        next if $exclude{$canon};
        push @orphans, $canon unless $inbound{$canon};
    }

    my %seen_broken;
    my @broken;
    for my $source ( sort keys %outbound ) {
        for my $target ( @{ $outbound{$source} } ) {
            next if $pages{$target};
            ( my $with_index = $target ) =~ s{/index$}{};
            next if $pages{$with_index};
            # SM558: a bare `index` (and index.html, which the collector has
            # already stripped to `index`) is the ROOT page - the same mapping
            # canonical() applies to index.md, whose key is the empty string.
            next if $target eq 'index' && $pages{''};
            next if $seen_broken{"$source->$target"}++;
            push @broken, { source => $source, target => $target };
        }
    }

    return {
        pages    => \%pages,
        sources  => \%sources,
        broken   => \@broken,
        orphaned => \@orphans,
    };
}

# --- Scan mode ---

sub run_scan {
    my ($results) = @_;

    my $report_dir = "$DOCROOT/manager";
    make_path($report_dir) unless -d $report_dir;

    my $report_path = "$report_dir/audit-report.md";
    my $report_url  = '/manager/audit-report';

    write_audit_report( $report_path, $results );
    log_event( 'INFO', $DOCROOT, 'report written', path => $report_path );

    my $cache = "$report_dir/audit-report.html";
    unlink $cache if -f $cache;
    # SM110: drop any per-alias-host copies of the report render too
    # (standalone plugin - inline rather than the Lazysite::Util helper).
    my $hosts_dir = "$DOCROOT/lazysite/cache/hosts";
    if ( opendir( my $hd, $hosts_dir ) ) {
        for my $h ( readdir $hd ) {
            next if $h =~ /^\./;
            my $copy = "$hosts_dir/$h/manager/audit-report.html";
            unlink $copy if -f $copy;
        }
        closedir $hd;
    }

    require JSON::PP;
    print JSON::PP::encode_json( {
            ok         => 1,
            report_url => $report_url,
            broken     => scalar @{ $results->{broken} },
            orphaned   => scalar @{ $results->{orphaned} },
    } );
}

sub _h {
    my $s = shift;
    $s = '' unless defined $s;
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/"/&quot;/g;
    return $s;
}

sub write_audit_report {
    my ( $path, $results ) = @_;

    my $now     = POSIX::strftime( '%Y-%m-%d %H:%M:%S', localtime );
    my $now_iso = POSIX::strftime( '%Y-%m-%dT%H:%M:%S', localtime );

    my $broken   = $results->{broken}   // [];
    my $orphaned = $results->{orphaned} // [];
    my $b_count  = scalar @$broken;
    my $o_count  = scalar @$orphaned;

    my $md = "---\ntitle: Link Audit Report\nsubtitle: $now\ndate: $now_iso\n";
    $md .= "auth: required\nauth_groups:\n  - lazysite-admins\nsearch: false\n---\n\n";

    # Wrap the whole report in an mg-card so the standalone
    # /manager/audit-report page matches the visual weight of other
    # manager sections. markdown="1" on the outer and body divs tells
    # Text::MultiMarkdown to keep parsing headings, lists and tables
    # inside as Markdown (block-HTML content is otherwise left raw).
    $md .= qq(<div class="mg-card" markdown="1">\n);
    $md .= qq(<div class="mg-card-header">\n);
    $md .= qq(<span class="mg-card-title">Link Audit Report</span>\n);
    $md .= qq(<span class="mg-card-subtitle">$now</span>\n);
    $md .= qq(</div>\n);
    # Pure HTML body (no markdown="1") so the mg-table markup below renders
    # verbatim and matches the Stats / Users pages.
    $md .= qq(<div class="mg-card-body">\n\n);

    # Summary tiles - same shape as the stats page (mg-stat-tiles).
    my $b_label = 'Broken link' .   ( $b_count == 1 ? '' : 's' );
    my $o_label = 'Orphaned page' . ( $o_count == 1 ? '' : 's' );
    $md .= qq(<div class="mg-stat-tiles">\n);
    $md .= qq(  <div class="mg-stat-tile"><div class="mg-stat-value">$b_count</div>)
        . qq(<div class="mg-stat-label">$b_label</div></div>\n);
    $md .= qq(  <div class="mg-stat-tile"><div class="mg-stat-value">$o_count</div>)
        . qq(<div class="mg-stat-label">$o_label</div></div>\n);
    $md .= qq(</div>\n\n);

    if ( $b_count == 0 && $o_count == 0 ) {
        $md .= qq(<p class="mg-empty">&#10003; No broken links or orphaned pages found.</p>\n);
    }

    if ( $b_count > 0 ) {
        $md .= qq(<div class="mg-sec">Broken internal links</div>\n);
        $md .= qq(<table class="mg-table">\n)
            . qq(<thead><tr><th>Page</th><th>Broken link</th><th></th></tr></thead>\n<tbody>\n);
        for my $item (@$broken) {
            my $page_md = $item->{source};
            $page_md =~ s{^/}{};
            $page_md .= '.md' unless $page_md =~ /\.\w+$/;
            my $edit_url = _edit_url($page_md);

            # Display text keeps the file path (with .md) so the table reads like
            # what the author sees in the editor; the link target is the live URL.
            my $page_url = $item->{source};
            $page_url = "/$page_url" unless $page_url =~ m{^/};
            $page_url =~ s/\.md$//;
            $page_url =~ s{/index$}{/};
            $page_url = '/' if $page_url eq '';

            $md .= qq(<tr><td><a href=") . _h($page_url) . qq(">) . _h($page_md) . qq(</a></td>)
                . qq(<td><code>/) . _h( $item->{target} ) . qq(</code></td>)
                . qq(<td><a class="mg-btn mg-btn-sm" href=") . _h($edit_url) . qq(">Edit</a></td></tr>\n);
        }
        $md .= qq(</tbody>\n</table>\n\n);
    }

    if ( $o_count > 0 ) {
        $md .= qq(<div class="mg-sec">Orphaned pages</div>\n);
        $md .= qq(<p class="mg-hint">Pages that exist but are not linked from any other page.</p>\n);
        $md .= qq(<table class="mg-table">\n)
            . qq(<thead><tr><th>Page</th><th></th></tr></thead>\n<tbody>\n);
        for my $page (@$orphaned) {
            my $page_md = $page;
            $page_md .= '.md' unless $page_md =~ /\.\w+$/;
            my $edit_url = _edit_url($page_md);
            # Orphaned $page is already the URL form (canonical); link it to itself.
            $md .= qq(<tr><td><a href="/) . _h($page) . qq(">/) . _h($page) . qq(</a></td>)
                . qq(<td><a class="mg-btn mg-btn-sm" href=") . _h($edit_url) . qq(">Edit</a></td></tr>\n);
        }
        $md .= qq(</tbody>\n</table>\n\n);
    }

    # Close mg-card-body and mg-card
    $md .= qq(</div>\n</div>\n);

    open my $fh, '>:utf8', $path or die "Cannot write report: $!\n";
    print $fh $md;
    close $fh;
}

# --- CLI report ---

sub print_report {
    my ($results) = @_;
    my $broken    = $results->{broken};
    my $orphaned  = $results->{orphaned};
    my $pages     = $results->{pages};
    my $sources   = $results->{sources};

    print "lazysite link audit: $DOCROOT\n";
    print "=" x 60 . "\n\n";

    print "ORPHANED PAGES (" . scalar(@$orphaned) . ")\n";
    print "Exist but are not linked from any scanned file.\n\n";
    if (@$orphaned) {
        printf "  %-40s  %s\n", "/$_", $sources->{$_} // '' for @$orphaned;
    }
    else { print "  None found.\n"; }

    print "\nBROKEN LINKS (" . scalar(@$broken) . ")\n";
    print "Links pointing to pages that do not exist.\n\n";
    if (@$broken) {
        for my $b ( sort { $a->{source} cmp $b->{source} } @$broken ) {
            printf "  %-40s  -> /%s\n", $b->{source}, $b->{target};
        }
    }
    else { print "  None found.\n"; }

    print "\nSUMMARY\n";
    printf "  Source pages:    %d\n", scalar keys %$pages;
    printf "  Orphaned:        %d\n", scalar @$orphaned;
    printf "  Broken links:    %d\n", scalar @$broken;
    print "\n";
}

# --- Plugin descriptor ---

sub print_describe {
    require JSON::PP;
    print JSON::PP::encode_json( {
            id            => 'link-audit',
            name          => 'Link Audit',
            description   => 'Scan for broken internal links and orphaned pages',
            version       => '1.0',
            config_file   => '',
            config_schema => [],
            actions       => [
                {
                    id    => 'run',
                    label => 'Run audit',
                    confirm => 'This will scan all pages and may take a moment on large sites.',
                    endpoint    => 'plugin-action',
                    on_complete => 'open_url',
                    result_key  => 'report_url',
                }
            ],
    } );
}

# --- Utilities ---

# A found path, relative to the docroot. The SKIPS deliberately stay with each
# caller: the .url walk does NOT skip lazysite/ and the others do, which is a
# real divergence and not this helper's to decide.
sub _rel_of {
    my ($abs) = @_;
    ( my $rel = $abs ) =~ s{^\Q$DOCROOT\E/}{};
    return $rel;
}

sub canonical {
    my ($rel) = @_;
    $rel =~ s/\.(md|url|html)$//;
    $rel =~ s{/index$}{};
    $rel =~ s{^index$}{};
    $rel =~ s{/$}{};
    return $rel;
}

sub extract_links {
    my ( $path, $label, $inbound, $outbound ) = @_;

    open( my $fh, '<:utf8', $path ) or return;
    my $content = do { local $/; <$fh> };
    close $fh;

    my @raw_links;
    while ( $content =~ /\[(?:[^\]]*)\]\(([^)]+)\)/g ) {
        push @raw_links, $1;
    }
    while ( $content =~ /(?:href|src)\s*=\s*["']([^"']+)["']/g ) {
        push @raw_links, $1;
    }

    for my $link (@raw_links) {
        next if $link =~ /\[%/;
        next if $link =~ m{^https?://};
        next if $link =~ m{^mailto:};
        next if $link =~ m{^#};
        next if $link =~ m{^data:};
        next if $link eq 'about:blank';

        $link =~ s/[?#].*$//;
        next unless length $link;

        if ( $link =~ /\.(\w+)$/ ) {
            next if $IGNORE_EXT{ lc($1) };
        }

        $link =~ s{^/}{};
        next if $link =~ m{^assets/};

        $link =~ s/\.(html|md|url)$//;
        $link =~ s{/$}{};
        next unless length $link;

        push @{ $inbound->{$link} },   $label;
        push @{ $outbound->{$label} }, $link;
    }
}

# Parse tt_page_var frontmatter block for scan:/path patterns and mark
# every matching .md file as reachable in %inbound. Mirrors resolve_scan
# in lazysite-processor.pl so pages included via scan aren't orphaned.
sub extract_scan_refs {
    my ( $path, $label, $inbound ) = @_;

    open( my $fh, '<:utf8', $path ) or return;
    my @lines = <$fh>;
    close $fh;

    return unless @lines && $lines[0] =~ /^---\s*$/;

    my $in_tt_vars = 0;
    for my $i ( 1 .. $#lines ) {
        last if $lines[$i] =~ /^---\s*$/;

        if ( $lines[$i] =~ /^tt_page_var\s*:\s*$/ ) {
            $in_tt_vars = 1;
            next;
        }
        next unless $in_tt_vars;
        # Leaving the tt_page_var block when an unindented key appears
        if ( $lines[$i] =~ /^\S/ ) { $in_tt_vars = 0; next }

        if ( $lines[$i] =~ /^\s+\w[\w-]*\s*:\s*scan:(\S+)/ ) {
            resolve_scan_for_audit( $1, $label, $inbound );
        }
    }
}

sub resolve_scan_for_audit {
    my ( $pattern, $label, $inbound ) = @_;
    return unless $pattern =~ m{^/};
    my $fs_pattern = $DOCROOT . $pattern;
    return unless $fs_pattern =~ /\.md$/;

    my @files;
    if ( $fs_pattern =~ m{\*\*} ) {
        my ( $base, $rest ) = $fs_pattern =~ m{^(.*?)/\*\*/(.*)$};
        if ( defined $base && defined $rest && -d $base ) {
            my $file_re = $rest;
            $file_re =~ s/\./\\./g;
            $file_re =~ s/\*/.*/g;
            $file_re = qr/\A${file_re}\z/;
            my @queue = ($base);
            while ( my $dir = shift @queue ) {
                opendir( my $dh, $dir ) or next;
                for my $entry ( readdir($dh) ) {
                    next if $entry =~ /^\./;
                    my $p = "$dir/$entry";
                    if    ( -d $p )              { push @queue, $p }
                    elsif ( $entry =~ $file_re ) { push @files, $p }
                }
                closedir($dh);
            }
        }
    }
    else {
        @files = glob($fs_pattern);
    }

    for my $f (@files) {
        my $rel   = _rel_of($f);
        my $canon = canonical($rel);
        push @{ $inbound->{$canon} }, "scan:$label";
    }
}

# The manager's edit link for a source file.
sub _edit_url {
    my ($page_md) = @_;
    return '/manager/edit?path=' . uri_encode("/$page_md");
}

sub uri_encode {
    my ($str) = @_;
    $str =~ s/([^a-zA-Z0-9_.~-])/sprintf('%%%02X', ord($1))/ge;
    return $str;
}

# --- Logging ---

sub log_event {
    my ( $level, $context, $message, %extra ) = @_;
    my $min_level = $ENV{LAZYSITE_LOG_LEVEL} // 'INFO';
    my %rank      = ( DEBUG => 0, INFO => 1, WARN => 2, ERROR => 3 );
    return if ( $rank{$level} // 1 ) < ( $rank{$min_level} // 1 );
    my $ts     = strftime( '%Y-%m-%d %H:%M:%S', localtime );
    my $format = $ENV{LAZYSITE_LOG_FORMAT} // 'text';
    if ( $format eq 'json' ) {
        my $pairs = join ',',
            map { '"' . _json_str($_) . '":"' . _json_str( $extra{$_} ) . '"' }
            keys %extra;
        my $json = '{"ts":"' . $ts . '"'
            . ',"level":"' . _json_str($level) . '"'
            . ',"component":"' . _json_str($LOG_COMPONENT) . '"'
            . ',"context":"' . _json_str($context) . '"'
            . ',"message":"' . _json_str($message) . '"'
            . ( $pairs ? ",$pairs" : '' )
            . '}';
        print STDERR "$json\n";
        _forward_diag( $level, $json );
    }
    else {
        my $extras = join ' ',
            map { "$_=" . $extra{$_} } keys %extra;
        my $line = "[$ts] [$level] [$LOG_COMPONENT] [$context] $message";
        $line .= " $extras" if $extras;
        print STDERR "$line\n";
        _forward_diag( $level, $line );
    }
}

# SM540: a best-effort copy of the line to syslog through Lazysite::Util's
# forward_line, so `forward_diagnostics: true` covers this plugin's
# diagnostics as the docs promise. The module tree is located at runtime (the
# SM473 lesson: `prove -l` puts lib/ on @INC and a real install does not) and
# the require is eval-guarded, the SM425 posture: a missing lib costs the
# operator a syslog copy, never a submission - STDERR has the line either way.
sub _forward_diag {
    my ( $level, $line ) = @_;
    my %prio = ( DEBUG => 'debug', INFO => 'info', WARN => 'warning', ERROR => 'err' );
    eval {
        unless ( $INC{'Lazysite/Util.pm'} ) {
            require Cwd;
            require File::Basename;
            my $bin = File::Basename::dirname( Cwd::abs_path(__FILE__) );
            for my $cand ( "$bin/lib", "$bin/../lib", "$bin/../../lib" ) {
                if ( -d "$cand/Lazysite" ) { unshift @INC, $cand; last }
            }
            require Lazysite::Util;
        }
        Lazysite::Util::forward_line( 'diag', $prio{$level} // 'info', $line );
        1;
    };
    return;
}

sub _json_str {
    my ($s) = @_;
    $s //= '';
    $s =~ s/\\/\\\\/g;
    $s =~ s/"/\\"/g;
    $s =~ s/\n/\\n/g;
    $s =~ s/\r/\\r/g;
    $s =~ s/\t/\\t/g;
    return $s;
}
